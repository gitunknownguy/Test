﻿[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "list.txt"
)


$csv = Import-Csv -Path $csvFileName -Delimiter ","


$logFileName = "log_$([guid]::NewGuid()).log"
. ".\AciProxy.ps1"


#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import from a csv file
# It must has AltPan in the CSV file
#
#############################################################################

LogFile "log file: $($logFileName)"

foreach ($line in $csv) {
    $ret = GetAccountId $line.AltPan
    if($account.customerId -eq ""){
        LogFile "Can't find Account by AltPan: $($line.AltPan)"

        continue
    }

    LogFile("AltPan: $($line.AltPan), accountId: $($ret.accountId)")

    $apps = (GetPlasticAndApplications $ret.accountId)

    $maxIssueNo = 0
    $maxPlasticIssueNo = ""
    $endDate = ""
    $plasticId = ""
    $normalIssueNo = ""
    $updateEps = $false


    foreach($a in $apps)
    {
        $Number = [int]($a.plasticIssueNo.replace("+",""))
        $manualStatus = $a.manualStatus

        if($Number -eq 0)
        {
            continue
        }

        if($Number -gt $maxIssueNo)
        {
            $maxIssueNo = $Number
            $maxPlasticIssueNo = $a.plasticIssueNo
            $plasticId = $a.plasticId
            $endDate = $a.EndDate
        }

        if($manualStatus -eq "")
        {
            $normalIssueNo = $a.plasticIssueNo
        }
    }

    LogFile "MaxIssueNo: $($maxIssueNo) EndDate: $($endDate) NormalId: $($normalIssueNo)"

    foreach($a in $apps)
    {
        if($a.manualStatus -eq "CLOS")
        {
            continue
        }

        $Number = [int]($a.plasticIssueNo.replace("+",""))
        if($Number -ne $maxIssueNo -and $a.EndDate -eq $endDate)
        {
            $updateEps = $true
            LogFile "Remove $($a.plasticIssueNo)"

            $setCardRequest = @{        
                statusCode = "CLOS";
                plasticId = $plasticId;
                issueNumber = $a.plasticIssueNo;
            }
            LogFile ($setCardRequest | ConvertTo-Json)
            SetCardStatus $setCardRequest
        }
    }

    if($updateEps -eq $true -and $normalIssueNo -ne "")
    {
        $forceUpdateRequest = @{        
            plasticId = $plasticId;
            issueNumber = $normalIssueNo;
        }
	
	    LogFile ($forceUpdateRequest | ConvertTo-Json)

        ForceUpdate $forceUpdateRequest
    }
    
}


