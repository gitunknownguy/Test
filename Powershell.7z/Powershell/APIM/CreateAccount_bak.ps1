[cmdletbinding()]
param(
[string]$baseUrl = "https://prod-gen-apim.go2bankonline.net/aciproxy/v1/",
#[string]$key = "",#QA
[string]$key = "cc485ab07bcc464592d5ec91ad543cf1",#Prod
[string]$csvFileName = "p1_20231207.csv"
)

#$defaultContactId = "001B020200000003" #QA
$defaultContactId = "001B01F700000003" #Prod

$logFileName = "log_$([guid]::NewGuid()).log"

. ".\AciProxy.ps1"

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
#
#############################################################################

LogFile "log file: $($logFileName)"

Add-Type -Path ".\Gdot.Common.DataAccess.dll"
$csv = Import-Csv -Path $csvFileName -Delimiter ","

function RandomNumeric()
{
    param(
        [int]$len
    )

    $Numeric = "1234567890";

    $sb = New-Object System.Text.StringBuilder;
    for ($i = 0; $i -lt $len; $i++)
    {
        $pos = Get-Random -Minimum 0 -Maximum $Numeric.Length
        $c = $Numeric[$pos]
        
        $sb.Append($c) | Out-Null
    }

    return $sb.ToString();
}

$data = @()
foreach ($line in $csv) 
{
    #write-host $line
    $row = @{}

    $creditCheck = @()
    foreach($cCheck in $line.creditCheckDefinitions.split(','))
    {
        if($creditCheck.Count -eq 0)
        {
            $creditCheck += @{
                creditCheckDefinitionId = $cCheck;
                creditLimit = "0";
                lastCreditLimitChangeDate = "2020-01-01";
                institutionId = "GDOT";
                overlimitFlag = "1";
                wholeAccountCreditRule = "0";
                currencyCode = "840";
            };
        }
        else
        {
            $creditCheck += @{
                creditCheckDefinitionId = $cCheck;
                creditLimit = "0";
                lastCreditLimitChangeDate = "2020-01-01";
                institutionId = "GDOT";
                overlimitFlag = "0";
                wholeAccountCreditRule = "1";
                currencyCode = "840";
            };
        }       
    }

    $createAccountBody = @{
        agreement = @{
            institutionId = "GDOT"
        };
        account = @{
            openDate = ([System.DateTime]::Today.AddDays(-1).ToString("yyyy-MM-dd"));
            accountTypeId = $line.accounttypeid;
            contactId = $defaultContactId;
            corporateAccount = "0"
            currencyCode = "840";
            cycleLength = "1";
            cycleLengthUnits = "MNTH";
            cyclicalStatementFrequency = "NVER";
            inStructureFlag = "0";
            institutionId = "GDOT";
            productId = $line.productid;
            preferredCycleDay = $line.billcycleday;
            accountNumber = $line.ddaaccountnumber;
            routingNumber = $line.routingnunber;

        };
        accountCreditDataList = $creditCheck;
        sequence = @(
            @{
                deviceIssue = @{
                    deactivatePreviousDeviceOnFirstUseFlag = "0";
                    deviceStyleId = $line.devicestyleid;
                    embosserName1 = $line.embossingline1;
                    embosserName2 = $line.embossingline2;
                    paymentDeviceId = $line.paymentdeviceid;
                    PackageId = $line.packageid;
                    outputFileEmbossingVendorId = "EXCL";
                };
                application = @{
                    alternativePAN = $line.altpan;
                    pan = $line.pan.Substring(0, $line.pan.Length - 1) + "C";
                    endDate = $line.expdate;
                };

            };
        )
    };

    LogFile ($createAccountBody | ConvertTo-Json -Depth 10)

    
   #$createAccRes =  CreateAccount $createAccountBody
   #
   #if($createAccRes.status -eq "false")
   #{
   #    LogFile ("account creation failed", $row | ConvertTo-Json -Depth 10)
   #    continue
   #}
   #else 
   #{
   #    $row.Add("altpan", $line.altpan)
   #    $row.Add("accountRefNo", $createAccRes.accountRefNo)
   #}
   #$data += [PSCustomObject]$row
}

$data | export-csv -Path CreateAccount-Gen.csv -NoTypeInformation
