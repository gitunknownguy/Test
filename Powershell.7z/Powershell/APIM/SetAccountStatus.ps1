﻿[cmdletbinding()]
param(
[string]$baseUrl = "https://prod-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "09222023_setaccountstatus.csv"
)


$csv = Import-Csv -Path $csvFileName -Delimiter ","

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import from a csv file, call SetAccountStatus API
# It must has ACIAccountExternalID,StatusCode in the CSV file
#
#############################################################################

function GetRequestId {
    $requestId = [guid]::NewGuid();

    Write-Host "RequestId:$($requestId)"

    return $requestId
}

$ApplicationList = New-Object System.Collections.ArrayList;

foreach ($line in $csv) {
    $url1 = $baseUrl + "account-management/account/status"

    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    $body = @{        
        statusCode = $line.StatusCode;
        accountReferenceNumber = $line.ACIAccountExternalID
    }

    $body

    $response = Invoke-RestMethod $url1 -Method 'PUT' -Headers $headers -Body ($body | ConvertTo-Json)
    $response
    
}

$fileName = "setcardstatus_$([guid]::NewGuid()).csv"

Write-Host "CSV: $($fileName)"

