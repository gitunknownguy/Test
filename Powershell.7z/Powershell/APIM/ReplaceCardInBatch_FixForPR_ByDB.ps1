[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "list.txt"
)

. ".\AciProxy.ps1"

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import from a csv file, call ReplaceCard API / Set Card Status / Update EPS
# It must has AltPan in the CSV file
#
# This script is for PR mode to add the missing card in ACI side
# CardProxy,EndDate,IsActive
# 
#############################################################################

#$logFileName = "log_$([guid]::NewGuid()).log"
LogFile "log file: $($logFileName)"

if((Test-Path -Path $csvFileName) -eq $false)
{
    LogFile "Can't find CSV File: $($csvFileName)"
    return;
}

function DoReplaceCard
{
    param
    (
        [PSCustomObject]$cardDetail,
        [string]$endDate,
        [string]$manualStatus
    )

    $body = @{        
        plasticId = $cardDetail.id;
        plasticIssueNo = $cardDetail.plasticIssueNo;
        embosserName1 = $cardDetail.embosserName1;
        embosserName2 = $cardDetail.embosserName2;
        cardDispatchMethod = $cardDetail.cardDispatchMethod;
        deviceStyleId = $cardDetail.deviceStyleId;
        paymentDeviceId= $cardDetail.paymentDeviceId;
        endDate= $endDate;
        manualStatus = $manualStatus;
        replaceCardFeeWaiver = $true;
        dispatchFeeWaiver= $true;
        overrideDispatIndicator= $true;
        outputFileEmbossingVendorId = "EXCL";
    }

    #ReplaceCard $body
}

function DoSetCardStatus()
{
    param
    (
        [PSCustomObject]$cardDetail,
        [string]$cardStatus
    )

    $body = @{        
        statusCode = $cardStatus;
        plasticId = $cardDetail.plasticId;
        issueNumber = $cardDetail.plasticIssueNo;
    }

    #SetCardStatus $body
}

$csv = Import-Csv -Path $csvFileName -Delimiter ","
$cards = $csv | Group-Object -Property {$_.CardProxy} -NoElement

foreach($card in $cards)
{
    $cardProxy = $card.Name

    LogFile "CardProxy: $($cardProxy)"

    $items = $csv | Where-Object {$_.CardProxy -eq $cardProxy}

    $ret = GetAccountId $cardProxy
    if($account.customerId -eq ""){
        LogFile "Can't find Account by CardProxy: $($cardProxy)"

        continue
    }

    LogFile("CardProxy: $($cardProxy), accountId: $($ret.accountId)")

    $aciCards = (GetPlasticAndApplications $ret.accountId | Where-Object {$_.plasticIssueNo -ne "+0000"});
    if($aciCards.Length -eq 0)
    {
        LogFile "CardProxy: $($cardProxy) can't find a card."
        continue
    }


    $firstEndDate = $aciCards[0].endDate;

    $isFindFirstItem = $false
    $aciCardIndex = 0
    foreach($dbItem in $items)
    {
        LogFile "CardProxy: $($cardProxy), $($dbItem.EndDate)  $($dbItem.IsActive) ,start to process"

        if($isFindFirstItem -eq $false)
        {
            if($dbItem.EndDate -ne $firstEndDate)
            {
                continue;
            }
            $isFindFirstItem = $true
            LogFile "CardProxy: $($cardProxy) , First DB Card $($dbItem.EndDate)"
        }

        $isFindAciCard = $false
        for (; $aciCardIndex -lt $aciCards.Count; ) 
        {
            $aciCard = $aciCards[$aciCardIndex]
            $aciCardIndex++

            if($dbItem.EndDate -ne $aciCard.EndDate)
            {
                if($aciCard.manualStatus -eq "" -or $aciCard.manualStatus -eq "ACTP")
                {
                    LogFile "CardProxy: $($cardProxy),Not match found close card, DB: $($dbItem.EndDate) ACI $($aciCard.plasticIssueNo)"
                    #close card
                    DoSetCardStatus $aciCard "CLOS"
                }

                continue
            }

            $isFindAciCard = $true
            LogFile "CardProxy: $($cardProxy), Find match card, DB: $($dbItem.EndDate) ACI $($aciCard.plasticIssueNo) , ACI status $($aciCard.manualStatus)"
            break;
        }

        if ($isFindAciCard -eq $true) 
        {
            if($dbItem.IsActive -eq $true)
            {
                if($aciCard.manualStatus -eq "ACTP")
                {
                    LogFile "CardProxy: $($cardProxy), ACI status $($aciCard.manualStatus), set to normal."
                    DoSetCardStatus $aciCard ""
                }
            }
            else
            {
                if($aciCard.manualStatus -eq "")
                {
                    LogFile "CardProxy: $($cardProxy), ACI status $($aciCard.manualStatus), set to ACTP."
                    DoSetCardStatus $aciCard "ACTP"
                }
            }

            continue
        }
        else 
        {
            # replace card
            
            $newCardStatus = "ACTP"
            if($dbItem.IsActive -eq $true)
            {
                $newCardStatus = ""
            }

            LogFile "CardProxy: $($cardProxy), order card, $($dbItem.EndDate) $($newCardStatus)"

            DoReplaceCard $aciCard $dbItem.EndDate $newCardStatus
        }
    }

    $normalCard = GetFirstNormalCard $ret.accountId
    if($normalCard.PlasticId -eq "")
    {
        LogFile("CardProxy: $($cardProxy) not find a normal card")
        continue;
    }

    $body = @{        
        plasticId = $normalCard.plasticId;
        issueNumber = $normalCard.plasticIssueNo;
    }
	
	LogFile ($body | ConvertTo-Json)

    ForceUpdate $body
}
