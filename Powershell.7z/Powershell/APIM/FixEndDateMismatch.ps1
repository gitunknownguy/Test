﻿[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "end.txt"
)


$csv = Import-Csv -Path $csvFileName -Delimiter ","


$logFileName = "log_$([guid]::NewGuid()).log"
. ".\AciProxy.ps1"


#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import from a csv file
# It must has AltPan,CurrentEndDate,LastEndDate in the CSV file
#
#############################################################################

LogFile "log file: $($logFileName)"

foreach ($line in $csv) {
    $ret = GetAccountId $line.AltPan
    if($account.customerId -eq ""){
        LogFile "Can't find Account by AltPan: $($line.AltPan)"

        continue
    }

    LogFile "AltPan: $($line.AltPan), accountId: $($ret.accountId)"

    $apps = (GetPlasticAndApplications $ret.accountId)

    # precondition check

    # if more than one pan under an account, we might need check it manually.
    $panGroup = @($apps | Where-Object { $_.plasticIssueNo -ne 0 } | Group-Object -Property {$_.alternativePAN} -NoElement) 
    if($panGroup.Length -gt 1)
    {
        LogFile "AltPan: $($line.AltPan) have more than one pan"
        continue
    }

    # if more than one normal card under an account, we might need check it manually.
    $normalGroup = @($apps | Where-Object { $_.plasticIssueNo -ne 0 -and $_.manualStatus -eq ""} ) 
    if($panGroup.Length -gt 1)
    {
        LogFile "AltPan: $($line.AltPan) have more than one normal card"
        continue
    }

    $normalCard = $null

    $lastCard = $apps[$apps.Length - 1]
    if($normalGroup.Length -eq 1)
    {
        $normalCard = $normalGroup[0]
    }

    if($lastCard.endDate -ne $line.LastEndDate)
    {
        #Replace a new card

        $body = @{        
                    plasticId=$lastCard.id;
                    plasticIssueNo=$lastCard.plasticIssueNo;
                    embosserName1=$lastCard.embosserName1;
                    embosserName2=$lastCard.embosserName2;
                    cardDispatchMethod=$lastCard.cardDispatchMethod;
                    deviceStyleId=$lastCard.deviceStyleId;
                    paymentDeviceId=$lastCard.paymentDeviceId;
                    endDate=$line.LastEndDate;
                    manualStatus="ACTP";
                    replaceCardFeeWaiver=$true;
                    dispatchFeeWaiver=$true;
                    overrideDispatIndicator=$true;
                    outputFileEmbossingVendorId = "EXCL";
                }

        LogFile ($body | ConvertTo-Json)

        ReplaceCard $body

        $apps = (GetPlasticAndApplications $ret.accountId)
        $lastCard = $apps[$apps.Length - 1]
    }

    # for each cards
    foreach($a in $apps)
    {
        $Number = [int]($a.plasticIssueNo.replace("+",""))
        $manualStatus = $a.manualStatus

        LogFile “$($a.plasticIssueNo) start, manualStatus: $($manualStatus)”

        if($Number -eq 0)
        {
            LogFile "Skip Number -eq 0"
            continue
        }

        if($a.endDate -eq $line.CurrentEndDate)
        {
            if($a.manualStatus -ne "")
            {

                LogFile “$($a.plasticIssueNo), update to normal”

                $setCardRequest = @{        
                    statusCode = "";
                    plasticId = $plasticId;
                    issueNumber = $a.plasticIssueNo;
                }
                LogFile ($setCardRequest | ConvertTo-Json)
                SetCardStatus $setCardRequest
            }
        }
        elseif($a.plasticIssueNo -eq $lastCard.plasticIssueNo) 
        {
            LogFile “$($a.plasticIssueNo), skip last card”

            continue
        }
        else
        {
            if($a.manualStatus -eq "ACTP")
            {
                LogFile “$($a.plasticIssueNo), Clost ACTP card”

                $setCardRequest = @{        
                    statusCode = "CLOS";
                    plasticId = $lastCard.id;
                    issueNumber = $a.plasticIssueNo;
                }
                LogFile ($setCardRequest | ConvertTo-Json)
                SetCardStatus $setCardRequest
            }            
        }
    }


    if($normalCard -ne $null)
    {
        $forceUpdateRequest = @{        
            plasticId = $lastCard.id;
            issueNumber = $normalCard.plasticIssueNo;
        }
	
	    LogFile ($forceUpdateRequest | ConvertTo-Json)

        ForceUpdate $forceUpdateRequest
    }
}
    


