﻿[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "forceupdateepsByNormalCard.csv"
)


$csv = Import-Csv -Path $csvFileName -Delimiter ","


$logFileName = "log_$([guid]::NewGuid()).log"
. ".\AciProxy.ps1"


#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import from a csv file, call ForceUpdateEps API
# It must has AltPan in the CSV file
#
#############################################################################

LogFile "log file: $($logFileName)"

foreach ($line in $csv) {
    $ret = GetAccountId $line.AltPan
    if($account.customerId -eq ""){
        LogFile "Can't find Account by AltPan: $($line.AltPan)"

        continue
    }

    LogFile("AltPan: $($line.AltPan), accountId: $($ret.accountId)")


    $card = GetFirstNormalCard $ret.accountId

    if($card.PlasticId -eq "")
    {
        LogFile("AltPan: $($line.AltPan) not find a normal card")
        continue;
    }


    $body = @{        
        plasticId = $card.plasticId;
        issueNumber = $card.plasticIssueNo;
    }
	
	LogFile ($body | ConvertTo-Json)

    ForceUpdate $body
    
}


