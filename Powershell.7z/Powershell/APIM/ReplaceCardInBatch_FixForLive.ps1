[cmdletbinding()]
param(
[string]$baseUrl = "https://prod-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "cc485ab07bcc464592d5ec91ad543cf1",
[string]$csvFileName = "ReplaceCard.csv"
)

$logFileName = "log_$([guid]::NewGuid()).log"

. ".\AciProxy.ps1"

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import from a csv file, call ReplaceCard API
# It must has AltPan,EndDate in the CSV file
#
# This script is for PR mode to add the missing card in ACI side
# 
#
#############################################################################

LogFile "log file: $($logFileName)"

if((Test-Path -Path $csvFileName) -eq $false)
{
    LogFile "Can't find CSV File: $($csvFileName)"
    return;
}


$csv = Import-Csv -Path $csvFileName -Delimiter ","


foreach ($line in $csv) 
{
    $ret = GetAccountId $line.AltPan
    if($account.customerId -eq ""){
        LogFile "Can't find Account by AltPan: $($line.AltPan)"

        continue
    }

    LogFile("AltPan: $($line.AltPan), accountId: $($ret.accountId)")

    $lastCard = GetLastCard $ret.accountId $line.AltPa

    if($lastCard.endDate -eq $line.EndDate)
    {
        LogFile "AltPan: $($line.AltPan), last card end date is equal to the date in file $($lastCard.plasticIssueNo)" "warm"
        continue;
    }


    $cardDetail = GetCardDetail $lastCard.plasticId $lastCard.plasticIssueNo
    LogFile "LastCard $($cardDetail.plasticIssueNo)"

    $body = @{        
            plasticId=$cardDetail.id;
            plasticIssueNo=$cardDetail.plasticIssueNo;
            embosserName1=$cardDetail.embosserName1;
            embosserName2=$cardDetail.embosserName2;
            cardDispatchMethod=$cardDetail.cardDispatchMethod;
            deviceStyleId=$cardDetail.deviceStyleId;
            paymentDeviceId=$cardDetail.paymentDeviceId;
            endDate=$line.EndDate;
            manualStatus="ACTP";
            replaceCardFeeWaiver=$true;
            dispatchFeeWaiver=$true;
            overrideDispatIndicator=$true;
            #outputFileEmbossingVendorId = "EXCL";
        }

    LogFile ($body | ConvertTo-Json)

    #ReplaceCard $body

}















