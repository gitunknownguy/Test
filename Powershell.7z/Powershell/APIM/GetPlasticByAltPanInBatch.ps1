﻿[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "Test.csv"
)


$csv = Import-Csv -Path $csvFileName -Delimiter ","

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import altpan from a csv file, then call APIM to get plastic info and export a csv file
# It must has a "AltPan" column in the CSV file
#
#############################################################################

$logFileName = "log_$([guid]::NewGuid()).csv"


. ".\AciProxy.ps1"

LogFile "log file: $($logFileName)"

$result = New-Object System.Collections.ArrayList

function ProcessEachLine() {
    param (
        [hashtable]$record
    )
    $ret = GetAccountId $record.AltPan 
    if($ret.customerId -eq ""){
        continue
    }

    LogFile("accountId: $($ret.accountId)")

    $record.Add("accountId",$ret.accountId)

    $apps = (GetPlasticAndApplications $ret.accountId)
    
    $items = @()

    foreach($app in $apps)
    {
        $item = @{
            plasticId = $app.plasticId;
            plasticIssueNo = $app.plasticIssueNo;
            manualStatus = $app.manualStatus;
            pan = $app.pan.Replace("******","_");
            endDate = $app.endDate;
            productionStatus = $app.productionStatus;
            issueReason = $app.issueReason;
            paymentDeviceId = $app.paymentDeviceId;
            deviceStyleId = $app.deviceStyleId;
            cardRegisteredFlag = $app.cardRegisteredFlag;
        }
        $items += ([PSCustomObject]$item)
    }

    return $items
}


foreach ($line in $csv) {
    $record = @{AltPan=$line.AltPan}    
    
    $processResult = ProcessEachLine $record

    $processResult | ForEach-Object {$result += $_}
    
}


#$result | ConvertTo-Json -Depth 10

$result  | ConvertTo-Csv -NoTypeInformation

$csvFileName = "GetPlasticByAltPan_$([guid]::NewGuid()).csv"
LogFile "export to csv: $($csvFileName)"

$result  | Export-Csv -NoTypeInformation -Path $csvFileName