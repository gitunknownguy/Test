﻿[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "forceupdateepsByNormalCard.csv"
)


$csv = Import-Csv -Path $csvFileName -Delimiter ","


$logFileName = "log_$([guid]::NewGuid()).log"
. ".\AciProxy.ps1"


#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import from a csv file, to check if an account has more then 1 ACTP cards.
# Then will save into a check file that contains all matched results.
# It must has AltPan in the CSV file
#
#############################################################################

LogFile "log file: $($logFileName)"

$outputFile = "checkresult_$([guid]::NewGuid()).log"

LogFile $outputFile 
Add-Content $outputFile -Value "AltPan"


$result = New-Object System.Collections.ArrayList

foreach ($line in $csv) {
    $ret = GetAccountId $line.AltPan
    if($account.customerId -eq ""){
        LogFile "Can't find Account by AltPan: $($line.AltPan)"

        continue
    }

    LogFile("AltPan: $($line.AltPan), accountId: $($ret.accountId)")


    $cards = GetPlasticAndApplications $ret.accountId

    #Write-Host ($cards | ConvertTo-Json)

    $group = @($cards | Where-Object { $_.manualStatus -eq "" -or $_.manualStatus -eq "ACTP" } | Group-Object -Property {$_.endDate} -NoElement) 

    foreach($groupItem in $group)
    {
        if($groupItem.Count -gt 1)
        {
            LogFile  "$($line.AltPan): EndDate: $($groupItem.Name) has $($groupItem.Count)"
            $result.Add($line.AltPan) | Out-Null
            Add-Content $outputFile -Value $line.AltPan
            break
        }
    }


    #$actpItems = @($cards | Where-Object -Property manualStatus -eq "ACTP") 
    
    #LogFile  "$($line.AltPan): has ACTP: $($actpItems.Count)"
    #
    #if($actpItems.Count -gt 1)
    #{
    #    $result.Add($line.AltPan) | Out-Null
    #}
}


#$result | ForEach-Object {Add-Content $outputFile -Value $_}