[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "UpdateCustomerProfileIn.csv"
)

$logFileName = "log_$([guid]::NewGuid()).log"

. ".\AciProxy.ps1"



#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import from a csv file, call ReplaceCard API
# It must has AltPan,familyName,firstName in the CSV file
#
#############################################################################

LogFile "log file: $($logFileName)"

function UpdateCustomerProfile
{
    param (
        [hashtable]$body
    )

    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    $url = $baseUrl + "account-management/customerprofile/$($body.id)"
    $url
    $bodyString=$body | ConvertTo-Json
    $bodyString
    $response = Invoke-RestMethod $url -Method 'PUT' -Headers $headers -Body ($body | ConvertTo-Json)

    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("Update Customer Profile: $($response.subStatusCode) $($response.message) $($response.subErrorMessage)");
        return $false;
    }

    return $true
}


$csv = Import-Csv -Path $csvFileName -Delimiter ","


foreach ($line in $csv) 
{
    $account = GetAccountId $line.AltPan
    if($account.accountId -eq ""){
        LogFile "Can't find Account by AltPan: $($line.AltPan)"
        continue
    }

    LogFile("AltPan: $($line.AltPan), accountId: $($account.accountId)")

   $customerProfile= GetCustomerProfile $account.customerId

    if($customerProfile.id -eq ""){
        LogFile "Can't find CustomerProfile by contactCustomerId: $($account.contactCustomerId)"
        continue
    }

   $customerProfile.familyName=$line.familyName
   $customerProfile.firstName=$line.firstName

   
   UpdateCustomerProfile $customerProfile

}
