$csv = Import-Csv -Path Test.csv -Delimiter ","
$url = "https://qa-cbs-eastus-apim.go2bankonline.net/aciproxy/v1/"

foreach($line in $csv)
{
    $body = ($line | ConvertTo-Json)

    #$body
    
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("Content-Type", "application/json")

    $response = Invoke-RestMethod $url -Method 'POST' -Headers $headers -Body $body
    $response | ConvertTo-Json
}