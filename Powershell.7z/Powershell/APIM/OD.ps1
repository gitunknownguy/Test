﻿[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "od.csv"
)


$csv = Import-Csv -Path $csvFileName -Delimiter ","

$logFileName = "log_$([guid]::NewGuid()).log"

. ".\AciProxy.ps1"

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import from a csv file, call updatecreditlimithistory API
# It must has AltPan,CreditLimit in the CSV file
#
#############################################################################


foreach ($line in $csv) {
    
    $ret = GetAccountId $line.AltPan
    if($account.customerId -eq ""){
        LogFile "Can't find Account by AltPan: $($line.AltPan)"
        continue
    }

    $body = @{
        institutionId = "GDOT";
        accountId = $ret.accountId;
        creditCheckDefinitionId = "D001";
        currencyCode = "840";
        endDate = "2400-12-31";
        creditLimit = 100*$line.CreditLimit;
        currentTypeIndicator = "1";
    }

    LogFile ($body | ConvertTo-Json)

    UpdateCreditLimit $body
}

$fileName = "od_$([guid]::NewGuid()).csv"

Write-Host "CSV: $($fileName)"

