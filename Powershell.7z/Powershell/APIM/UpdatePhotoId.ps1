﻿[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "UpdatePhotoId.csv"
)


$csv = Import-Csv -Path $csvFileName -Delimiter ","

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import from a csv file, call SetCardStatus API
# It must has AltPan,PhotoId in the CSV file
#
#############################################################################

$fileName = "UpdatePhotoId_$([guid]::NewGuid()).csv"

. ".\AciProxy.ps1"


function ProcessEachLine() {
    param (
        [hashtable]$record
    )
    $account = GetAccountId $record.AltPan 
    if($account.customerId -eq ""){
        continue
    }

    LogFile("accountId: $($account.accountId)")

    $card = GetLastCard $account.accountId $AltPan

    LogFile ($card | ConvertTo-Json)


}

$myArray = New-Object System.Collections.ArrayList

foreach ($line in $csv) {
    

    $record = @{}
    $record['AltPan'] = $line.AltPan
    $record['PhotoId'] = $line.PhotoId

    LogFile("Start to process $($record.AltPan), $($record.PhotoId)")

    #ProcessEachLine($recode)
}



Write-Host "CSV: $($fileName)"

