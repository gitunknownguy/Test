﻿[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "list.txt"
)


$csv = Import-Csv -Path $csvFileName -Delimiter ","

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import from a csv file, call  API
# It must has AltPan,AciPackID in the CSV file
#
#############################################################################

#$fileName = "UpdateContact_$([guid]::NewGuid()).csv"

. ".\AciProxy.ps1"

function DoReplaceCard
{
    param
    (
        [PSCustomObject]$cardDetail,
        [string]$packageId
    )

    $body = @{        
        plasticId = $cardDetail.id;
        plasticIssueNo = $cardDetail.plasticIssueNo;
        embosserName1 = $cardDetail.embosserName1;
        embosserName2 = $cardDetail.embosserName2;
        cardDispatchMethod = $cardDetail.cardDispatchMethod;
        deviceStyleId = $cardDetail.deviceStyleId;
        paymentDeviceId= $cardDetail.paymentDeviceId;
        endDate= $cardDetail.endDate;
        manualStatus = "ACTP";
        replaceCardFeeWaiver = $true;
        dispatchFeeWaiver= $true;
        overrideDispatIndicator= $true;
        outputFileEmbossingVendorId = $null;
        packageId = $packageId;
    }

    ReplaceCard $body
}

function DoSetCardStatus()
{
    param
    (
        [PSCustomObject]$cardDetail,
        [string]$cardStatus
    )

    $body = @{        
        statusCode = $cardStatus;
        plasticId = $cardDetail.id;
        issueNumber = $cardDetail.plasticIssueNo;
    }

    Write-Host ($body | ConvertTo-Json)

    SetCardStatus $body
}

function DoUpdateCardDetail
{
    param
    (
        [PSCustomObject]$cardDetail
    )

    $updateCardBody = @{

        activationDate=$cardDetail.activationDate;
        activationMethod=$cardDetail.activationMethod;
        associatedMemoFlag=$cardDetail.associatedMemoFlag;
        authenticationTokenRequiredFlag=$cardDetail.authenticationTokenRequiredFlag;
        cardDispatchMethod=$cardDetail.cardDispatchMethod;
        cardMailerContactId=$cardDetail.cardMailerContactId;
        cardMailerInsertCode=$cardDetail.cardMailerInsertCode;
        cardRegisteredFlag=1;
        deactivatePreviousDeviceOnFirstUseFlag=$cardDetail.deactivatePreviousDeviceOnFirstUseFlag;
        deviceStyleId=$cardDetail.deviceStyleId;
        embosserName1=$cardDetail.embosserName1;
        endDate=$cardDetail.endDate;
        id=$cardDetail.id
        institutionId="GDOT";
        issueDate=$cardDetail.issueDate;
        issueReason=$cardDetail.issueReason;
        lastUpdateNo=$cardDetail.lastUpdateNo;
        manualStatus=$cardDetail.manualStatus;
        overrideCardDispatchMethodFlag=$cardDetail.overrideCardDispatchMethodFlag;
        overrideCardMailerContactId=$null;
        overrideCardMailerContactStartDate="1800-01-01";
        overrideCardMailerContactEndDate="1800-01-01";
        paymentDeviceId=$cardDetail.paymentDeviceId;
        photocardFlag=$cardDetail.PhotocardFlag;
        plasticIssueNo= $cardDetail.plasticIssueNo;
        plasticTransferOnActivationFlag=$cardDetail.plasticTransferOnActivationFlag;
        productionStatus= $cardDetail.productionStatus;
        productionStatusChangeDate=$cardDetail.productionStatusChangeDate;
        reissueNumber=$cardDetail.reissueNumber;
        replacementCounter=$cardDetail.replacementCounter;
        startDate=$cardDetail.startDate;
        statusCodeChangeDate=$cardDetail.statusCodeChangeDate;
        technicalFallbackAllowedFlag="0";
        secondaryCardholderNameLine1=$cardDetail.secondaryCardholderNameLine1;
        secondaryCardholderNameLine2=$cardDetail.secondaryCardholderNameLine2;
        secondaryCardholderSequenceNumber=$cardDetail.secondaryCardholderSequenceNumber;
    }

    LogFile "Start Update Card Detail"
    #LogFile ($updateCardBody | ConvertTo-Json)

    UpdateCardDetail $updateCardBody $cardDetail.id
}

function DoForceUpdate
{
    param
    (
        [string]$accountId
    )


    $normalCard = GetFirstNormalCard $accountId
    if($normalCard.PlasticId -eq "")
    {
        LogFile("CardProxy: $($cardProxy) not find a normal card")
        continue;
    }

    $body = @{        
        plasticId = $normalCard.plasticId;
        issueNumber = $normalCard.plasticIssueNo;
    }
	
	LogFile ($body | ConvertTo-Json)

    ForceUpdate $body
}

foreach ($line in $csv) {
    $ret = GetAccountId $line.AltPan
    if($account.customerId -eq ""){
        LogFile "Can't find Account by AltPan: $($line.AltPan)"

        continue
    }

    LogFile("AltPan: $($line.AltPan), accountId: $($ret.accountId)")

    $lastCard = GetLastCard $ret.accountId $line.AltPan

    $cardDetail = GetCardDetail $lastCard.plasticId $lastCard.plasticIssueNo
    LogFile "LastCard $($cardDetail.plasticIssueNo)"

    DoUpdateCardDetail $cardDetail

    DoReplaceCard $cardDetail $line.AciPackID

    DoSetCardStatus $cardDetail "CLOS"

    DoForceUpdate $ret.accountId

}


