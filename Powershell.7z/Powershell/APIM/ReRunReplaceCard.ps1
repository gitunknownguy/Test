[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "rerun.csv"
)

$csv = Import-Csv -Path $csvFileName -Delimiter ","

. ".\AciProxy.ps1"

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
#
#############################################################################


foreach ($line in $csv) {
    $json = $line.requestBody_CF

    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    $url = $baseUrl + "card-management/card/replace"
    $response = Invoke-RestMethod $url -Method 'POST' -Headers $headers -Body $json

    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("Replace Card: $($response.subStatusCode) $($response.message) $($response.subErrorMessage)");        
    }

    Write-Host "true"
}