[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "reg.txt"
)

$logFileName = "log_$([guid]::NewGuid()).log"

. ".\AciProxy.ps1"

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
#
#############################################################################

LogFile "log file: $($logFileName)"


$csv = Import-Csv -Path $csvFileName -Delimiter ","

function RandomNumeric()
{
    param(
        [int]$len
    )

    $Numeric = "1234567890";

    $sb = New-Object System.Text.StringBuilder;
    for ($i = 0; $i -lt $len; $i++)
    {
        $pos = Get-Random -Minimum 0 -Maximum $Numeric.Length
        $c = $Numeric[$pos]
        
        $sb.Append($c) | Out-Null
    }

    return $sb.ToString();
}


foreach ($line in $csv) 
{
    #write-host $line

    $ret = GetAccountId $line.cardproxy

    LogFile "AltPan: $($line.cardproxy), accountId: $($ret.accountId)"

    $card = GetLastCard $ret.accountId $line.CardProxy

    LogFile "AltPan: $($line.cardproxy), $($card.plasticIssueNo) $($card.plasticIssueNo)"

    $pan = GetPan $card.plasticId $card.plasticIssueNo

    $r1 = RandomNumeric 13
    $r2 = RandomNumeric 13
    $addressReferenceNumber = "1$($r1)";
    $customerRefNo = "2$($r2)";

    $registerCardBody = @{
        pan = $pan.pan;
        contactAddress = @{
            institutionId= "GDOT";
            addressLine1= $line.addressline1;
            addressLine2 = $line.addressline2;
            addressLine3 = $null;
            city = $line.cityname;
            county = $line.State;
            country= "USA";
            postcode=$line.zippostalcode;
            addressType="PRVT";
            addressReferenceNumber=$addressReferenceNumber
        };
        customer= @{
            institutionId="GDOT";
            corporate="0";
            familyName=$line.familyname;
            firstName=$line.firstname;
            dob="2000-01-01";
            languageId="ENGL";
            customerRefNo=$customerRefNo;
            associatedMemoFlag= "0";
            customerType= "CONT";
            customerDeceasedFlag= "0";
            customerReferenceNumberType= "NORM";
            socialSecurityNumberType= "SSNO";
            vip= "0";
            lastMaintenanceTypeFlag= "0";
        };
        additionalCustomerDetail=@{
            institutionId = Constants.InstitutionId;
            sex = "FEML";
            maritalStatus = "SNGL";
            emailAddress = "default@greendotcorp.com";
            securityDataId = "PSWD";
            residencyStatus = "RESI";
            workPermitStatus = "NREQ";
            occupationCode = "PERM";
            applicationScoreDate = "2023-12-19"
        }
    };

    LogFile ($registerCardBody | ConvertTo-Json -Depth 10)

    RegisterCardBody $registerCardBody

}















