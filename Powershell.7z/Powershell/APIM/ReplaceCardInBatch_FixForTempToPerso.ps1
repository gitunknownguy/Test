[cmdletbinding()]
param(
[string]$baseUrl = "https://prod-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "cc485ab07bcc464592d5ec91ad543cf1",
[string]$csvFileName = "perso.txt"
)

$logFileName = "log_$([guid]::NewGuid()).log"

. ".\AciProxy.ps1"

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import from a csv file, call ReplaceCard API
# It must has NewAltPan,OldAltPan,EndDate in the CSV file
#
# This script is for PR mode to add the missing card in ACI side
# 
#
#############################################################################

LogFile "log file: $($logFileName)"

if((Test-Path -Path $csvFileName) -eq $false)
{
    LogFile "Can't find CSV File: $($csvFileName)"
    return;
}


$csv = Import-Csv -Path $csvFileName -Delimiter ","


foreach ($line in $csv) 
{
    $retOld = GetAccountId $line.OldAltPan
    if($retOld.customerId -eq ""){
        LogFile "Can't find Account by AltPan: $($line.OldAltPan)"

        continue
    }

    LogFile("AltPan: $($line.OldAltPan), accountId: $($retOld.accountId)")

    $retNew = GetAccountId $line.NewAltPan
    if($retNew.customerId -eq ""){
        LogFile "Can't find Account by AltPan: $($line.NewAltPan)"

        continue
    }

    LogFile("AltPan: $($line.OldAltPan), accountId: $($retNew.accountId)")

    $lastNewCard = GetLastCard $retNew.accountId $line.NewAltPan

    $lastOldCard = GetLastLostCard $retOld.accountId $line.OldAltPan


    if($lastNewCard.endDate -eq $line.EndDate)
    {
        LogFile "AltPan: $($line.NewAltPan), last card end date is equal to the date in file" "warm"
        continue;
    }


    $oldCardDetail = GetCardDetail $lastOldCard.plasticId $lastOldCard.plasticIssueNo

    LogFile "oldCardDetail $($oldCardDetail.plasticIssueNo)"

    $newCardDetail = GetCardDetail $lastNewCard.plasticId $lastNewCard.plasticIssueNo

    LogFile "newCardDetail $($newCardDetail.plasticIssueNo)"

    $body = @{        
            plasticId=$newCardDetail.id;
            plasticIssueNo=$newCardDetail.plasticIssueNo;
            embosserName1=$oldCardDetail.embosserName1;
            embosserName2=$oldCardDetail.embosserName2;
            cardDispatchMethod=$oldCardDetail.cardDispatchMethod;
            deviceStyleId=$oldCardDetail.deviceStyleId;
            paymentDeviceId=$oldCardDetail.paymentDeviceId;
            endDate=$line.EndDate;
            manualStatus="ACTP";
            replaceCardFeeWaiver=$true;
            dispatchFeeWaiver=$true;
            overrideDispatIndicator=$true;
            outputFileEmbossingVendorId = "EXCL";
        }

    LogFile ($body | ConvertTo-Json)

    ReplaceCard $body

}















