[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$AltPan = "1264120005569319",
[string]$PlasticIssueNo = "+0003",
[string]$NewAltPan = "1264120005569312",
[string]$NewPan = "5264120008627981C",
[string]$EndDate = "2028-05-05"
)

#{
#    "pan": null,
#    "issueNumber": "2",
#    "plasticId": "01BD00002BA58FA5",
#    "statusCode": "LOST",
#    "deviceIssues": [{
#            "embosserName1": "KENDALLMERRIWEATHER",
#            "embosserName2": null,
#            "endDate": "2027-09-30",
#            "paymentDeviceId": "EZJ2",
#            "manualStatus": "ACTP",
#            "cardDispatchMethod": "REG",
#            "deviceStyleId": "0036",
#            "outputFileEmbossingVendorId": "EXCL",
#            "applications": [{
#                    "alternativePAN": "999999112907366",
#                    "pan": "499119000269895C"
#                }
#            ]
#        }
#    ]
#}

$logFileName = "log_$([guid]::NewGuid()).csv"

. ".\AciProxy.ps1"

LogFile "log file: $($logFileName)"

$ret = GetAccountId $AltPan
if($account.customerId -eq ""){
    continue
}

LogFile("accountId: $($ret.accountId)")

$cards = GetPlasticAndApplications $ret.accountId

$reportCard = $null
foreach($card in $cards)
{
    if($card.plasticIssueNo -eq $PlasticIssueNo)
    {
        $reportCard = $card
        break;
    }
}

if($reportCard -ne $null)
{
    #LogFile "Find the report L/S card $($reportCard | ConvertTo-Json)"


    $body = @{
        issueNumber = $reportCard.plasticIssueNo;
        plasticId = $reportCard.plasticId;
        statusCode = "LOST";
        deviceIssues = @(@{
            embosserName1 = $reportCard.embosserName1;
            endDate = $EndDate;
            paymentDeviceId = $reportCard.paymentDeviceId;
            manualStatus = "ACTP";
            cardDispatchMethod = $reportCard.cardDispatchMethod;
            deviceStyleId = $reportCard.deviceStyleId;
            outputFileEmbossingVendorId = "EXCL";
            applications = @(@{
                alternativePAN = $NewAltPan;
                pan = $NewPan
            })
        });
    }

    $body | ConvertTo-Json -Depth 10

    ReportLS $body
}