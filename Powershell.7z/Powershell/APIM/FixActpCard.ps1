﻿[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "list.txt"
)


$csv = Import-Csv -Path $csvFileName -Delimiter ","


$logFileName = "log_$([guid]::NewGuid()).log"
. ".\AciProxy.ps1"


#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import from a csv file
# It must has AltPan in the CSV file
#
#############################################################################

LogFile "log file: $($logFileName)"

foreach ($line in $csv) {
    $ret = GetAccountId $line.AltPan
    if($account.customerId -eq ""){
        LogFile "Can't find Account by AltPan: $($line.AltPan)"

        continue
    }

    LogFile("AltPan: $($line.AltPan), accountId: $($ret.accountId)")

    $apps = (GetPlasticAndApplications $ret.accountId)

    $actpNo = ""
    $plasticId = ""
    $needFix = $false
    $normalIssueNo = ""

    #check if there is a normal card 
    foreach($a in $apps)
    {
        $Number = [int]($a.plasticIssueNo.replace("+",""))
        $manualStatus = $a.manualStatus

        if($Number -eq 0)
        {
            continue
        }

        if($manualStatus -eq "")
        {
            $normalIssueNo = $a.plasticIssueNo
        }
    }

    if($normalIssueNo -ne "")
    {
        LogFile "AltPan: $($AltPan) has a normal card, skip."
        continue
    }

    #get first actp card with PIN set 
    foreach($a in $apps)
    {
        $Number = [int]($a.plasticIssueNo.replace("+",""))
        $manualStatus = $a.manualStatus

        if($Number -eq 0)
        {
            continue
        }

        if($manualStatus -eq "ACTP" -and $a.pinSetFlag -eq "1")
        {
            $actpNo = $a.plasticIssueNo
            $plasticId = $a.plasticId

            $needFix = $true

            break
        }
    }

    LogFile "ACTP No: $($actpNo) needFix: $($needFix)"

    

    if($needFix -eq $true)
    {
        $setCardRequest = @{        
            statusCode = "";
            plasticId = $plasticId;
            issueNumber = $actpNo;
        }
        LogFile ($setCardRequest | ConvertTo-Json)
        SetCardStatus $setCardRequest


        $forceUpdateRequest = @{        
            plasticId = $plasticId;
            issueNumber = $actpNo;
        }
	
	    LogFile ($forceUpdateRequest | ConvertTo-Json)

        ForceUpdate $forceUpdateRequest
    }
    
}


