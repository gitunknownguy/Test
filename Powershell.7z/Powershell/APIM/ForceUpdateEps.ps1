﻿[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "forceupdateeps.csv"
)


$csv = Import-Csv -Path $csvFileName -Delimiter ","

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import from a csv file, call ForceUpdateEps API
# It must has PlasticId,IssueNumber in the CSV file
#
#############################################################################

function GetRequestId {
    $requestId = [guid]::NewGuid();

    Write-Host "RequestId:$($requestId)"

    return $requestId
}

$ApplicationList = New-Object System.Collections.ArrayList;

foreach ($line in $csv) {
    $url1 = $baseUrl + "card-management/card/force/base24"

    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    $body = @{        
        plasticId = $line.PlasticId;
        issueNumber = $line.IssueNumber;
    }

    $body
    $response = Invoke-RestMethod $url1 -Method 'PUT' -Headers $headers -Body ($body | ConvertTo-Json)
    $response
    
}

$fileName = "forceupdateeps_$([guid]::NewGuid()).csv"

Write-Host "CSV: $($fileName)"

