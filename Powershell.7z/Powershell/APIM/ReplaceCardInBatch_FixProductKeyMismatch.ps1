[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "list.txt"
)

$logFileName = "log_$([guid]::NewGuid()).log"

. ".\AciProxy.ps1"

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import from a csv file, call ReplaceCard API
# It must has AltPan,PlasticId,DeviceStyleId,PaymentDeviceId in the CSV file
#
# This script is for PR mode to add the missing card in ACI side
# 
#
#############################################################################

<#
ApiManagementGatewayLogs
| where OperationId =='replacecard' and ApimSubscriptionId =='Aciproxy-PAL-Subscription' 
| extend json_ = parse_json(requestBody_CF)
| extend plasticId_ = json_.plasticId, deviceStyleId_=json_.deviceStyleId,paymentDeviceId_ = json_.paymentDeviceId
| where plasticId_ in ("01FB000058D81285")
| project TimeGenerated,plasticId_,deviceStyleId_,paymentDeviceId_
| order by TimeGenerated desc 
#>

LogFile "log file: $($logFileName)"

if((Test-Path -Path $csvFileName) -eq $false)
{
    LogFile "Can't find CSV File: $($csvFileName)"
    return;
}


$csv = Import-Csv -Path $csvFileName -Delimiter ","


foreach ($line in $csv) 
{
    $ret = GetAccountId $line.AltPan
    if($account.customerId -eq ""){
        LogFile "Can't find Account by AltPan: $($line.AltPan)"

        continue
    }

    LogFile("AltPan: $($line.AltPan), accountId: $($ret.accountId)")

    $lastCard = GetLastCard $ret.accountId $AltPan

    if($lastCard.deviceStyleId -eq $line.DeviceStyleId -or $lastCard.paymentDeviceId -eq $line.PaymentDeviceId)
    {
        LogFile "AltPan: $($line.AltPan), last card DeviceStyleId/paymentDeviceId is equal to the date in file" "warm"
        continue;
    }


    $cardDetail = GetCardDetail $lastCard.plasticId $lastCard.plasticIssueNo
    LogFile "LastCard $($cardDetail.plasticIssueNo)"

    $body = @{        
            plasticId=$cardDetail.id;
            plasticIssueNo=$cardDetail.plasticIssueNo;
            embosserName1=$cardDetail.embosserName1;
            embosserName2=$cardDetail.embosserName2;
            cardDispatchMethod=$cardDetail.cardDispatchMethod;
            deviceStyleId=$line.DeviceStyleId;
            paymentDeviceId=$line.PaymentDeviceId;
            endDate=$cardDetail.EndDate;
            manualStatus=$cardDetail.manualStatus;
            replaceCardFeeWaiver=$true;
            dispatchFeeWaiver=$true;
            overrideDispatIndicator=$true;
            outputFileEmbossingVendorId = "EXCL";
        }

    LogFile ($body | ConvertTo-Json)

    #ReplaceCard $body


    $setCardRequest = @{        
        statusCode = "CLOS";
        plasticId = $cardDetail.id;
        issueNumber = $cardDetail.plasticIssueNo;
    }
    LogFile ($setCardRequest | ConvertTo-Json)
    #SetCardStatus $setCardRequest

    $normalCard = GetFirstNormalCard $ret.accountId

    if($normalCard.PlasticId -eq "")
    {
        LogFile("AltPan: $($line.AltPan) not find a normal card")
        continue;
    }

    $forceUpdateBody = @{        
        plasticId = $normalCard.plasticId;
        issueNumber = $normalCard.plasticIssueNo;
    }
	
	LogFile ($forceUpdateBody | ConvertTo-Json)

    #ForceUpdate $forceUpdateBody

}















