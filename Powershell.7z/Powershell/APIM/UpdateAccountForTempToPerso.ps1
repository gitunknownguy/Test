﻿[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "updateaccount.txt"
)


$csv = Import-Csv -Path $csvFileName -Delimiter ","

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import from a csv file, call update account API
# It must has  in the CSV file
#
#############################################################################

#$fileName = "log_$([guid]::NewGuid()).txt"

. ".\AciProxy.ps1"

function RandomNumeric()
{
    param(
        [int]$len
    )

    $Numeric = "1234567890";

    $sb = New-Object System.Text.StringBuilder;
    for ($i = 0; $i -lt $len; $i++)
    {
        $pos = Get-Random -Minimum 0 -Maximum $Numeric.Length
        $c = $Numeric[$pos]
        
        $sb.Append($c) | Out-Null
    }

    return $sb.ToString();
}

foreach ($line in $csv) {
    $retOld = GetAccountId $line.OldAltPan
    if($retOld.customerId -eq ""){
        LogFile "Can't find Account by AltPan: $($line.OldAltPan)"

        continue
    }

    LogFile("AltPan: $($line.OldAltPan), accountId: $($retOld.accountId)")

    $retNew = GetAccountId $line.NewAltPan
    if($retNew.customerId -eq ""){
        LogFile "Can't find Account by AltPan: $($line.NewAltPan)"

        continue
    }

    LogFile("AltPan: $($line.OldAltPan), accountId: $($retNew.accountId)")

    $body1 = @{
        accountTypeId = $retOld.accountTypeId;# old account
        cycleLength = "1";
        cycleLengthUnits = "MNTH";
        institutionId = "GDOT";
        lastUpdateNo = $retOld.lastUpdateNo;# new account
        id = $retOld.accountId;# new account
        productId = $retOld.productId;#old account
        preferredCycleDay = $line.billCycle;
        ddaAccountNumber = ""#$line.ACHReference;
        routingNumber = ""#$line.ABARoutingNumber;
    };

    $body1 | ConvertTo-Json

    #UpdateAccount $body1


    $body2 = @{
        accountTypeId = $retOld.accountTypeId;# old account
        cycleLength = "1";
        cycleLengthUnits = "MNTH";
        institutionId = "GDOT";
        lastUpdateNo = $retNew.lastUpdateNo;# new account
        id = $retNew.accountId;# new account
        productId = $retOld.productId;#old account
        preferredCycleDay = $line.billCycle;
        ddaAccountNumber = $line.ACHReference;
        routingNumber = $line.ABARoutingNumber;
    };

    $body2 | ConvertTo-Json

    #UpdateAccount $body2
}

