[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "set.txt"
)

. ".\AciProxy.ps1"

$csv = Import-Csv -Path $csvFileName -Delimiter ","

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import from a csv file, call SetCardStatus API
# It must has AltPan,From,To in the CSV file
#
#############################################################################

function DoSetCardStatus()
{
    param
    (
        [PSCustomObject]$cardDetail,
        [string]$cardStatus
    )

    $body = @{        
        statusCode = $cardStatus;
        plasticId = $cardDetail.id;
        issueNumber = $cardDetail.plasticIssueNo;
    }

    Write-Host ($body | ConvertTo-Json)

    SetCardStatus $body
}

function DoForceUpdate
{
    param
    (
        [string]$accountId
    )


    $normalCard = GetFirstNormalCard $accountId
    if($normalCard.PlasticId -eq "")
    {
        LogFile("CardProxy: $($cardProxy) not find a normal card")
    }

    $body = @{        
        plasticId = $normalCard.plasticId;
        issueNumber = $normalCard.plasticIssueNo;
    }
	
	LogFile ($body | ConvertTo-Json)

    ForceUpdate $body
}


foreach ($line in $csv) {
    $ret = GetAccountId $line.AltPan
    if($account.customerId -eq ""){
        LogFile "Can't find Account by AltPan: $($line.AltPan)"

        continue
    }

    LogFile("AltPan: $($line.AltPan), accountId: $($ret.accountId)")

    $cards = GetPlasticAndApplications $ret.accountId

    $selectedCards = $cards | Where-Object {$_.manualStatus -eq $line.From}

    if($selectedCards.length -ne 1)
    {
        LogFile("AltPan: $($line.AltPan), accountId: $($ret.accountId) select cards count not equal 1")
        continue;
    }

    $card = $selectedCards

    DoSetCardStatus $card $line.To

    DoForceUpdate $ret.accountId
}