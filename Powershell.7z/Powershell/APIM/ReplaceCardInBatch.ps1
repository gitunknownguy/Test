[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "ReplaceCard.csv"
)

$logFileName = "log_$([guid]::NewGuid()).log"

. ".\AciProxy.ps1"

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import from a csv file, call ReplaceCard API
# It must has AltPan,EndDate in the CSV file
#
#############################################################################

LogFile "log file: $($logFileName)"


$csv = Import-Csv -Path $csvFileName -Delimiter ","


foreach ($line in $csv) 
{
    $ret = GetAccountId $line.AltPan
    if($account.customerId -eq ""){
        LogFile "Can't find Account by AltPan: $($line.AltPan)"

        continue
    }

    LogFile("AltPan: $($line.AltPan), accountId: $($ret.accountId)")

    $lastCard = GetLastCard $ret.accountId $AltPan

    $cardDetail = GetCardDetail $lastCard.plasticId $lastCard.plasticIssueNo
    LogFile "LastCard $($cardDetail.plasticIssueNo)"

    $body = @{        
            plasticId=$cardDetail.id;
            plasticIssueNo=$cardDetail.plasticIssueNo;
            embosserName1=$cardDetail.embosserName1;
            embosserName2=$cardDetail.embosserName2;
            cardDispatchMethod=$cardDetail.cardDispatchMethod;
            deviceStyleId=$cardDetail.deviceStyleId;
            paymentDeviceId=$cardDetail.paymentDeviceId;
            endDate=$line.EndDate;
            manualStatus="ACTP";
            replaceCardFeeWaiver=$true;
            dispatchFeeWaiver=$true;
            overrideDispatIndicator=$true;
            outputFileEmbossingVendorId = "EXCL";
        }

    LogFile ($body | ConvertTo-Json)

    ReplaceCard $body

}















