[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$altPan = "1344560003876162"
)


#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/
. ".\AciProxy.ps1"


$url1 = $baseUrl + "account-management/accountdr/$($altPan)"
    
Write-Host $url1

$headers = @{}
$headers.Add("Content-Type", "application/json") 
$headers.Add("Ocp-Apim-Subscription-Key", $key)
$requestId = GetRequestId
$headers.Add("X-Request-ID", $requestId)

$response = Invoke-RestMethod $url1 -Method 'GET' -Headers $headers

Write-Host ($response | ConvertTo-Json -Depth 10)