[cmdletbinding()]
param(
    [string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
    [string]$csvFileName = "debit.csv",
    [string]$env = "qa"
)

$MyInvocation.MyCommand.Path | Split-Path | Push-Location
$csv = Import-Csv -Path $csvFileName -Delimiter ","

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import from a csv file, call Add tpk history API
# It must has CardProxy,Transamount,ProcesssorTransCode,AuditId,Description in the CSV file
#
#############################################################################

#$fileName = "log_$([guid]::NewGuid()).txt"

function LogFile {
    param (
        [string]$log,
        [string]$level = "info"
    )

    switch -exact ($level.ToLower()) {
        'info' {
            Write-Host $log
            break
        }
        'warn' {
            Write-Warning $log
            break
        }
        'error' {
            Write-Error $log
            break
        }    
        'verb' {
            Write-Verbose $log -Verbose
            break
        }
        default {
            Write-Host $log
            break
        }
    }

    if ($logFileName -eq $null) {
        return
    }

    Add-Content $logFileName -Value $log | Out-Null
}


function GetKey {
    param (
        [string]$env
    )

    switch -exact ($env.ToLower()) {
        'qa' {
            $root = 'https://gssactutl.qa.nextestate.com/AzureProxy/V1/keyvault/apimkeys/Aciproxy-DataFix-Subscription/qa'
            break
        }
        'prod' {
            $root = 'https://gssactutl.dc1.greendotcorp.com/AzureProxy/V1/keyvault/apimkeys/Aciproxy-DataFix-Subscription/prod'
            break
        }
        default {
            return "";
        }
    }

    $requestId = [guid]::NewGuid();
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("RequestId", $requestId)
    $result = Invoke-RestMethod $root -Credential $credential -Method 'GET' -Headers $headers -UseDefaultCredentials
    return $result.primaryKey;
}

function GetAccountId {
    param (
        [string]$AltPan
    )
    $url1 = $baseUrl + "account-management/accountdr/$($AltPan)"
    
    Write-Host $url1
    
    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $headers.Add("X-Request-ID", $requestId)

    $response = Invoke-RestMethod $url1 -Method 'GET' -Headers $headers

    
    if ($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000") {
        LogFile("$($AltPan), GetAccount: $($response.subStatusCode) $($response.message)");
        return @{
            accountId        = ""
            customerId       = ""
            accountTypeId    = ""
            accountRefNo     = ""
            productId        = ""
            lastUpdateNo     = ""
            contactAddressId = ""
        }
    }


    $accountId = $response.rawResponse.DR008011.'repeatingGroupOut-1'.'repeatingGroupInstanceOut-1'[0].GeDmAccountDR008011Subset0001.id
    $customerId = $response.rawResponse.DR008011.GeDmCustomerContactAddressDR008011Subset0001.customerId
    $accountTypeId = $response.rawResponse.DR008011.'repeatingGroupOut-1'.'repeatingGroupInstanceOut-1'[0].GeDmAccountDR008011Subset0001.accountTypeId
    $accountRefNo = $response.rawResponse.DR008011.'repeatingGroupOut-1'.'repeatingGroupInstanceOut-1'[0].GeDmAccountDR008011Subset0001.accountRefNo
    $productid = $response.rawResponse.DR008011.'repeatingGroupOut-1'.'repeatingGroupInstanceOut-1'[0].GeDmAccountDR008011Subset0001.productId
    $lastUpdateNo = $response.rawResponse.DR008011.'repeatingGroupOut-1'.'repeatingGroupInstanceOut-1'[0].GeDmAccountDR008011Subset0001.lastUpdateNo
    $contactAddressId = $response.rawResponse.DR008011.GeDmCustomerContactAddressDR008011Subset0001.contactAddressId
    $applicationId = $response.rawResponse.DR008011.GeDmArgumentBlockDR008011Subset0001.systemKey1

    return @{
        accountId        = $accountId;
        customerId       = $customerId;
        accountTypeId    = $accountTypeId;
        accountRefNo     = $accountRefNo;
        productId        = $productid;
        lastUpdateNo     = $lastUpdateNo;
        contactAddressId = $contactAddressId
        applicationId    = $applicationId
    }
}

function GetPan {
    param (
        [string]$plasticId,
        [string]$plasticIssueNo
    )

    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $headers.Add("X-Request-ID", $requestId)

    
    $url = $baseUrl + "card-management/cards/card-record/$($plasticId)?issueNumber=$($plasticIssueNo)"
    $response = Invoke-RestMethod $url -Method 'GET' -Headers $headers

    if ($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000") {
        LogFile("Get Card record: $($response.subStatusCode) $($response.message)");
        return "";
    }

    $result = @{
        endDate        = $response.rawResponse.DR010506.GeDmDeviceIssueDR010506Subset0001.endDate;
        manualStatus   = $response.rawResponse.DR010506.GeDmDeviceIssueDR010506Subset0001.manualStatus;
        pan            = $response.rawResponse.DR010506."repeatingGroupOut-1"."repeatingGroupInstanceOut-1"[0].GeDmApplicationDR010506Subset0001.pan;
        alternativePAN = $response.rawResponse.DR010506."repeatingGroupOut-1"."repeatingGroupInstanceOut-1"[0].GeDmApplicationDR010506Subset0001.alternativePAN;
    }

    return $result
}

function GetLastCard {
    param (
        [string]$accountId,
        [string]$altPan
    )

    $url = $baseUrl + "account-management/$($accountId)/all/plastics-and-applications"
    
    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $headers.Add("X-Request-ID", $requestId)

    $response = Invoke-RestMethod $url -Method 'GET' -Headers $headers

    
    if ($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000") {
        LogFile("$($AltPan), Get Plastics: $($response.subStatusCode) $($response.message)");
        return "";
    }

    $plasticId = ""
    $maxIssueNo = 0
    $maxPlasticIssueNo = ""
    $endDate = ""
    $deviceStyleId = ""
    $paymentDeviceId = ""
    $manualStatus = ""

    foreach ($plastic in $response.rawResponse.CR010004."repeatingGroupOut-1"."repeatingGroupInstanceOut-1") {
        $aPan = $plastic.GeDmApplicationCR010004Subset0001.alternativePAN

        $plasticId = $plastic.GeDmApplicationCR010004Subset0001.plasticId    
        $plasticIssueNo = $plastic.GeDmApplicationCR010004Subset0001.plasticIssueNo	
        $Number = [int]($plastic.GeDmApplicationCR010004Subset0001.plasticIssueNo.replace("+", ""))

        LogFile("GetLastCard: $($aPan),$($plasticId),$($Number)")

        if ($aPan -ne $altPan) {
            continue
        }

        if ($Number -gt $maxIssueNo) {
            $maxIssueNo = $Number
            $maxPlasticIssueNo = $plasticIssueNo

            $plasticIssueNo = $plastic.GeDmApplicationCR010004Subset0001.plasticIssueNo
            $endDate = $plastic.GeDmDeviceIssue.endDate
            $deviceStyleId = $plastic.GeDmDeviceIssue.deviceStyleId
            $paymentDeviceId = $plastic.GeDmDeviceIssue.paymentDeviceId
            $manualStatus = $plastic.GeDmDeviceIssue.manualStatus
        }
    }

    return @{
        plasticId       = $plasticId;
        plasticIssueNo  = $plasticIssueNo;
        endDate         = $endDate;
        deviceStyleId   = $deviceStyleId;
        paymentDeviceId = $paymentDeviceId;
        manualStatus = $manualStatus
    }

}

function DoAdjustment {
    param (
        [hashtable]$body,
        [string]$auditId
    )

    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $headers.Add("X-Request-ID", $requestId)
    $headers.Add("X-Audit-Id", $auditId )
    $url = $baseUrl + "card-management/card/balance"

    $response = Invoke-RestMethod $url -Method 'POST' -Headers $headers -Body ($body | ConvertTo-Json -Depth 10)

    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("Adjustment: $($response.subStatusCode) $($response.message)");
        return $false;
    }

    return $true
    
}

$key = GetKey $env


foreach ($line in $csv) {
    $requestId = [guid]::NewGuid();

    $cardProxy = $line.CardProxy;
    Write-Host "cp:$($cardProxy) start"

    $account = GetAccountId $cardProxy
    if ($account.customerId -eq "") {
        LogFile "Can't find Account by AltPan: $($cardProxy)"

        continue
    }

    LogFile("AltPan: $($cardProxy), accountId: $($account.accountId)")

    $lastCard = GetLastCard $account.accountId $line.CardProxy

    if ($lastCard.manualStatus -ne "SOLD") {
        Write-Host "cp:$($cardProxy), card status not equeal to SOLD, status: $($lastCard.manualStatus)"
        continue
    }

    $pan = GetPan $lastCard.plasticId $lastCard.plasticIssueNo

    $comment = "UID:$($line.RequestId);CMT:$($line.Description)"

    $body = @{
        pan                 = $pan.pan;
        amount              = [System.Int32]::Parse($line.Transamount);
        currencyCode        = "840";
        transactionCode     = $line.ProcesssorTransCode;
        description         = $line.Description;
        chequeNo            = 1;
        accountId           = $account.accountId;
        applicationId       = $account.applicationId;
        issueNumber         = 1;
        domain              = "INAI";
        extendedDescription = $comment;
    }

    Write-Host "cp:$($cardProxy)" ($body | ConvertTo-Json)

    DoAdjustment $body $line.AuditId
}








