﻿[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$AltPan = "160622111842"
)

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/
. ".\AciProxy.ps1"


$ret = GetAccountId $AltPan 
if($ret.customerId -eq ""){
    continue
}

Write-Host "accountId: $($ret.accountId) $($ret.accountTypeId)"

$apps = (GetPlasticAndApplications $ret.accountId)
    
$items = @()

foreach($app in $apps)
{
    $item = @{
        plasticId = $app.plasticId;
        plasticIssueNo = $app.plasticIssueNo;
        manualStatus = $app.manualStatus;
        pan = $app.pan.Replace("******","_");
        endDate = $app.endDate;
        productionStatus = $app.productionStatus;
        issueReason = $app.issueReason;
        paymentDeviceId = $app.paymentDeviceId;
        deviceStyleId = $app.deviceStyleId;
        cardRegisteredFlag = $app.cardRegisteredFlag;
    }
    $items += ([PSCustomObject]$item)
}

#$result | ConvertTo-Json -Depth 10

$items  | ConvertTo-Csv -NoTypeInformation