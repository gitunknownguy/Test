﻿[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "regcard.txt"
)


$csv = Import-Csv -Path $csvFileName -Delimiter ","

. ".\AciProxy.ps1"

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import from a csv file, call UdateCardRegisterStatus API
# It must has PlasticId,IssueNumber in the CSV file
#
#############################################################################


foreach ($line in $csv) {
    Write-Host $line.PlasticId

    $pan = GetPan $line.PlasticId $line.IssueNumber
    $url1 = $baseUrl + "card-management/register/status"

    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    $body = @{        
        pan = $pan.pan
    }

    $response = Invoke-RestMethod $url1 -Method 'PUT' -Headers $headers -Body ($body | ConvertTo-Json)
    $response
    
}
