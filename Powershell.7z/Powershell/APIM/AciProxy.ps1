function LogFile {
    param (
        [string]$log,
        [string]$level = "info"
    )

    switch -exact ($level.ToLower())
    {
        'info'
        {
            Write-Host $log
            break
        }
        'warn'
        {
            Write-Warning $log
            break
        }
        'error'
        {
            Write-Error $log
            break
        }    
        'verb'
        {
            Write-Verbose $log -Verbose
            break
        }
        default
        {
            Write-Host $log
            break
        }
    }

    if($logFileName -eq $null)
    {
        return
    }

    Add-Content $logFileName -Value $log | Out-Null
}

function GetKey {
    param (
        [string]$env
    )

    switch -exact ($env.ToLower())
    {
        'qa'
        {
            $root = 'https://gssactutl.qa.nextestate.com/AzureProxy/V1/keyvault/apimkeys/Aciproxy-DataFix-Subscription/qa'
            break
        }
        'prod'
        {
            $root = 'https://gssactutl.dc1.greendotcorp.com/AzureProxy/V1/keyvault/apimkeys/Aciproxy-DataFix-Subscription/prod'
            break
        }
        default
        {
            return "";
        }
    }

    $requestId = [guid]::NewGuid();
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("RequestId", $requestId)
    $result = Invoke-RestMethod $root -Credential $credential -Method 'GET' -Headers $headers -UseDefaultCredentials
    return $result.primaryKey;
}

function GetRequestId {
    $requestId = [guid]::NewGuid();

    LogFile("RequestId:$($requestId)")

    return $requestId
}

function GetAccountId {
    param (
        [string]$AltPan
    )
    $url1 = $baseUrl + "account-management/accountdr/$($AltPan)"
    
    Write-Host $url1
    
    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    $response = Invoke-RestMethod $url1 -Method 'GET' -Headers $headers

    
    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("$($AltPan), GetAccount: $($response.subStatusCode) $($response.message)");
        return @{
            accountId = ""
            customerId = ""
            accountTypeId=""
            accountRefNo=""
            productId=""
            lastUpdateNo=""
            contactAddressId=""
        }
    }


    $accountId = $response.rawResponse.DR008011.'repeatingGroupOut-1'.'repeatingGroupInstanceOut-1'[0].GeDmAccountDR008011Subset0001.id
    $customerId = $response.rawResponse.DR008011.GeDmCustomerContactAddressDR008011Subset0001.customerId
    $accountTypeId = $response.rawResponse.DR008011.'repeatingGroupOut-1'.'repeatingGroupInstanceOut-1'[0].GeDmAccountDR008011Subset0001.accountTypeId
    $accountRefNo = $response.rawResponse.DR008011.'repeatingGroupOut-1'.'repeatingGroupInstanceOut-1'[0].GeDmAccountDR008011Subset0001.accountRefNo
    $productid = $response.rawResponse.DR008011.'repeatingGroupOut-1'.'repeatingGroupInstanceOut-1'[0].GeDmAccountDR008011Subset0001.productId
    $lastUpdateNo = $response.rawResponse.DR008011.'repeatingGroupOut-1'.'repeatingGroupInstanceOut-1'[0].GeDmAccountDR008011Subset0001.lastUpdateNo
    $contactAddressId =$response.rawResponse.DR008011.GeDmCustomerContactAddressDR008011Subset0001.contactAddressId

    return @{
        accountId = $accountId;
        customerId = $customerId;
        accountTypeId = $accountTypeId;
        accountRefNo=$accountRefNo;
        productId=$productid;
        lastUpdateNo=$lastUpdateNo;
        contactAddressId=$contactAddressId
    }
}

function GetContactAddress {
    param (
        [string]$contactAddressId
    )
    $url1 = $baseUrl + "account-management/address/$($contactAddressId)?institutionId=GDOT"
    
    Write-Host $url1
    
    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    $response = Invoke-RestMethod $url1 -Method 'GET' -Headers $headers

    
    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("$($contactAddressId), GetContactAddress: $($response.subStatusCode) $($response.message)");
        return @{
            id = ""
            lastUpdateNo=""
        }
    }

    $address=$response.rawResponse.GR033001.GeDmContactAddress

     $result = @{}
     $address.psobject.properties | Foreach { $result[$_.Name] = $_.Value }

    return $result
}

function GetCustomerProfile {
    param (
        [string]$customerId
    )
    $url1 = $baseUrl + "account-management/customerprofile/$($customerId)?institutionId=GDOT"

    Write-Host $url1
    
    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    $response = Invoke-RestMethod $url1 -Method 'GET' -Headers $headers

    
    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("$($customerId), GetCustomerProfile: $($response.subStatusCode) $($response.message)");
        return @{
            id = ""
            customerRefNo=""
        }
    }

    $customerProfile=$response.rawResponse.GR019001.GeDmCustomer

     $result = @{}
     $customerProfile.psobject.properties | Foreach { $result[$_.Name] = $_.Value }

    return $result
}

function GetPlasticAndApplications
{
    param (
        [string]$accountId
    )

    $url = $baseUrl + "account-management/$($accountId)/all/plastics-and-applications"

    Write-Host $url
    
    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    $response = Invoke-RestMethod $url -Method 'GET' -Headers $headers

    
    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("$($AltPan), Get Plastics: $($response.subStatusCode) $($response.message)");
        return "";
    }


    $allPlastics = @()

    foreach($plastic in $response.rawResponse.CR010004."repeatingGroupOut-1"."repeatingGroupInstanceOut-1")
    {
        $a = $plastic.GeDmApplicationCR010004Subset0001;
        $d = $plastic.GeDmDeviceIssue

        $p = @{

        }
        $a.psobject.properties | Foreach { $p[$_.Name] = $_.Value }
        $d.psobject.properties | Foreach { $p[$_.Name] = $_.Value }

        $allPlastics+=($p)
    }

    return $allPlastics
}

function GetLastCard {
    param (
        [string]$accountId,
        [string]$altPan
    )

    $url = $baseUrl + "account-management/$($accountId)/all/plastics-and-applications"
    
    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    $response = Invoke-RestMethod $url -Method 'GET' -Headers $headers

    
    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("$($AltPan), Get Plastics: $($response.subStatusCode) $($response.message)");
        return "";
    }

    $plasticId = ""
    $maxIssueNo = 0
    $maxPlasticIssueNo = ""
	$endDate = ""
    $deviceStyleId = ""
    $paymentDeviceId = ""
    $manualStatus = ""

    foreach($plastic in $response.rawResponse.CR010004."repeatingGroupOut-1"."repeatingGroupInstanceOut-1")
    {
        $aPan = $plastic.GeDmApplicationCR010004Subset0001.alternativePAN

        $plasticId = $plastic.GeDmApplicationCR010004Subset0001.plasticId    
		$plasticIssueNo = $plastic.GeDmApplicationCR010004Subset0001.plasticIssueNo	
        $Number = [int]($plastic.GeDmApplicationCR010004Subset0001.plasticIssueNo.replace("+",""))

        

        LogFile("$($aPan),$($plasticId),$($Number)")

        if($aPan -ne $altPan)
        {
            continue
        }

        if($Number -gt $maxIssueNo)
        {
            $maxIssueNo = $Number
            $maxPlasticIssueNo = $plasticIssueNo

            $plasticIssueNo = $plastic.GeDmApplicationCR010004Subset0001.plasticIssueNo
		    $endDate = $plastic.GeDmDeviceIssue.endDate
            $deviceStyleId = $plastic.GeDmDeviceIssue.deviceStyleId
            $paymentDeviceId = $plastic.GeDmDeviceIssue.paymentDeviceId
            $manualStatus = $plastic.GeDmDeviceIssue.manualStatus
        }
    }

    return @{
        plasticId = $plasticId;
        plasticIssueNo = $plasticIssueNo;
		endDate = $endDate;
        deviceStyleId = $deviceStyleId;
        paymentDeviceId = $paymentDeviceId;
    }

}

function GetLastLostCard {
    param (
        [string]$accountId,
        [string]$altPan
    )

    $url = $baseUrl + "account-management/$($accountId)/all/plastics-and-applications"
    
    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    $response = Invoke-RestMethod $url -Method 'GET' -Headers $headers

    
    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("$($AltPan), Get Plastics: $($response.subStatusCode) $($response.message)");
        return "";
    }

    $plasticId = ""
    $maxIssueNo = 0
    $maxPlasticIssueNo = ""
	$endDate = ""
    $deviceStyleId = ""
    $paymentDeviceId = ""
    $manualStatus = ""

    foreach($plastic in $response.rawResponse.CR010004."repeatingGroupOut-1"."repeatingGroupInstanceOut-1")
    {
        $Number = [int]($plastic.GeDmApplicationCR010004Subset0001.plasticIssueNo.replace("+",""))
        $manualStatus = $plastic.GeDmDeviceIssue.manualStatus
        

        LogFile("$($Number),$($manualStatus)")

        if($Number -gt $maxIssueNo -and $manualStatus -eq "LOST")
        {
            $maxIssueNo = $Number
            $maxPlasticIssueNo = $plasticIssueNo

            $plasticIssueNo = $plastic.GeDmApplicationCR010004Subset0001.plasticIssueNo
            $plasticId = $plastic.GeDmApplicationCR010004Subset0001.plasticId
		    $endDate = $plastic.GeDmDeviceIssue.endDate
            $deviceStyleId = $plastic.GeDmDeviceIssue.deviceStyleId
            $paymentDeviceId = $plastic.GeDmDeviceIssue.paymentDeviceId
            
        }
    }

    return @{
        plasticId = $plasticId;
        plasticIssueNo = $plasticIssueNo;
		endDate = $endDate;
        deviceStyleId = $deviceStyleId;
        paymentDeviceId = $paymentDeviceId;
    }

}

function GetFirstNormalCard {
    param (
        [string]$accountId
    )

    $url = $baseUrl + "account-management/$($accountId)/all/plastics-and-applications"

    Write-Host $url
    
    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    $response = Invoke-RestMethod $url -Method 'GET' -Headers $headers

    
    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("$($accountId), Get Plastics: $($response.subStatusCode) $($response.message)");
        return @{
                plasticId = "";
                plasticIssueNo = ""
            };
    }

    $plasticId = ""
    $maxIssueNo = 0
    $maxPlasticIssueNo = ""

    foreach($plastic in $response.rawResponse.CR010004."repeatingGroupOut-1"."repeatingGroupInstanceOut-1")
    {
        $aPan = $plastic.GeDmApplicationCR010004Subset0001.alternativePAN

        $plasticId = $plastic.GeDmApplicationCR010004Subset0001.plasticId
        $plasticIssueNo = $plastic.GeDmApplicationCR010004Subset0001.plasticIssueNo
        $Number = [int]($plastic.GeDmApplicationCR010004Subset0001.plasticIssueNo.replace("+",""))
        $manualStatus = $plastic.GeDmDeviceIssue.manualStatus

        LogFile("$($aPan),$($plasticId),$($plasticIssueNo),$($manualStatus)")

        if($manualStatus -eq "")
        {
            return @{
                plasticId = $plasticId;
                plasticIssueNo = $plasticIssueNo
            }
        }
    }

    foreach($plastic in $response.rawResponse.CR010004."repeatingGroupOut-1"."repeatingGroupInstanceOut-1")
    {
        $aPan = $plastic.GeDmApplicationCR010004Subset0001.alternativePAN

        $plasticId = $plastic.GeDmApplicationCR010004Subset0001.plasticId
        $plasticIssueNo = $plastic.GeDmApplicationCR010004Subset0001.plasticIssueNo
        $Number = [int]($plastic.GeDmApplicationCR010004Subset0001.plasticIssueNo.replace("+",""))
        $manualStatus = $plastic.GeDmDeviceIssue.manualStatus

        LogFile("$($aPan),$($plasticId),$($plasticIssueNo),$($manualStatus)")

        if($manualStatus -eq "ACTP")
        {
            return @{
                plasticId = $plasticId;
                plasticIssueNo = $plasticIssueNo
            }
        }
    }	
    return @{
        plasticId = "";
        plasticIssueNo = ""
    }

}


function GetApplications
{
    param (
        [string]$accountId
    )

    $appList = New-Object System.Collections.ArrayList 

    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    
    $url = $baseUrl + "account-management/$($accountId)/applications"
    $response = Invoke-RestMethod $url -Method 'GET' -Headers $headers

    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("Get applications: $($response.subStatusCode) $($response.message)");
        return $appList;
    }
   
    
    foreach ($app in $response.rawResponse.CR016002.'repeatingGroupOut-1'.'repeatingGroupInstanceOut-1')
    {

        $item = @{
            accountId = $app.GeDmApplicationCR016002Subset0001.accountId;
            pan = $app.GeDmApplicationCR016002Subset0001.pan;
            plasticId = $app.GeDmApplicationCR016002Subset0001.plasticId;
            plasticIssueNo = $app.GeDmApplicationCR016002Subset0001.plasticIssueNo;
            manualStatus = $app.GeDmApplicationCR016002Subset0001.manualStatus;
            alternativePAN = $app.GeDmApplicationCR016002Subset0001.alternativePAN;
            endDate = $app.GeDmApplicationCR016002Subset0001.endDate;
            startDate = $app.GeDmApplicationCR016002Subset0001.startDate;
            productId = $app.GeDmApplicationCR016002Subset0001.productId;
        }

        $newItem = $appList.Add($item)
    }

    return $appList
}

function GetPan 
{
    param (
        [string]$plasticId,
        [string]$plasticIssueNo
    )

    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    
    $url = $baseUrl + "card-management/cards/card-record/$($plasticId)?issueNumber=$($plasticIssueNo)"
    $response = Invoke-RestMethod $url -Method 'GET' -Headers $headers

    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("Get Card record: $($response.subStatusCode) $($response.message)");
        return "";
    }

    $result = @{
        endDate = $response.rawResponse.DR010506.GeDmDeviceIssueDR010506Subset0001.endDate;
        manualStatus = $response.rawResponse.DR010506.GeDmDeviceIssueDR010506Subset0001.manualStatus;
        pan = $response.rawResponse.DR010506."repeatingGroupOut-1"."repeatingGroupInstanceOut-1"[0].GeDmApplicationDR010506Subset0001.pan;
        alternativePAN = $response.rawResponse.DR010506."repeatingGroupOut-1"."repeatingGroupInstanceOut-1"[0].GeDmApplicationDR010506Subset0001.alternativePAN;
    }

    return $result
}

function GetCVV 
{
    param (
        [string]$accountId
    )

    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    
    $url = $baseUrl + "card-management/cards/card-record/$($plasticId)?issueNumber=$($plasticIssueNo)"
    $response = Invoke-RestMethod $url -Method 'GET' -Headers $headers

    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("Get CVV: $($response.subStatusCode) $($response.message)");
        return "";
    }


}

function GetCardDetail
{
    param (
        [string]$plasticId,
        [string]$plasticIssueNo
    )

    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    
    $url = $baseUrl + "card-management/cards/$($plasticId)?issueNumber=$($plasticIssueNo)"
    $response = Invoke-RestMethod $url -Method 'GET' -Headers $headers

    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("Get Card Detail: $($response.subStatusCode) $($response.message)");
        return "";
    }

    $card = $response.rawResponse.GR010003.GeDmDeviceIssueGR010003Subset0001

    $ht = @{}
    $card.psobject.properties | Foreach { $ht[$_.Name] = $_.Value }

    return $ht
}

function ReplaceCard
{
    param (
        [hashtable]$body
    )

    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    $url = $baseUrl + "card-management/card/replace"
    $response = Invoke-RestMethod $url -Method 'POST' -Headers $headers -Body ($body | ConvertTo-Json)

    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("Replace Card: $($response.subStatusCode) $($response.message) $($response.subErrorMessage)");
        return $false;
    }

    return $true
}

function ReportLS
{
    param (
        [hashtable]$body
    )

    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)
    $url = $baseUrl + "card-management/card/reportloststolen"

    $response = Invoke-RestMethod $url -Method 'PUT' -Headers $headers -Body ($body | ConvertTo-Json -Depth 10)

    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("Replace Card: $($response.subStatusCode) $($response.message)");
        return $false;
    }

    return $true
}

function UpdateCreditLimit
{
    param (
        [hashtable]$body
    )

    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)
    $url = $baseUrl + "account-management/creditlimithistory"

    $response = Invoke-RestMethod $url -Method 'PUT' -Headers $headers -Body ($body | ConvertTo-Json -Depth 10)

    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("Replace Card: $($response.subStatusCode) $($response.message)");
        return $false;
    }

    return $true
}

function UpdateCardDetail
{
    param (
        [hashtable]$body,
        [string]$plasticId
    )

    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)
    $url = $baseUrl + "/card-management/card/$($plasticId)"

    $response = Invoke-RestMethod $url -Method 'PUT' -Headers $headers -Body ($body | ConvertTo-Json -Depth 10)

    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("UpdateCardDetail: $($response.subStatusCode) $($response.message) ");
        return $false;
    }

    return $true

}

function ForceUpdate
{
    param (
        [hashtable]$body
    )

    $url1 = $baseUrl + "card-management/card/force/base24"

    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    $response = Invoke-RestMethod $url1 -Method 'PUT' -Headers $headers -Body ($body | ConvertTo-Json)

    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("ForceUpdate: $($response.subStatusCode) $($response.message) ");
        return $false;
    }

    return $true
}

function SetCardStatus
{
    param (
        [hashtable]$body
    )

    $url1 = $baseUrl + "card-management/card/status"

    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    $response = Invoke-RestMethod $url1 -Method 'PUT' -Headers $headers -Body ($body | ConvertTo-Json)
    
    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("SetCardStatus: $($response.subStatusCode) $($response.message) ");
        return $false;
    }

    return $true
}

function CreateAccount
{
    param (
        [hashtable]$body
    )

    $url1 = $baseUrl + "account-management/account/add-with-sggentities"

    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    $response = Invoke-RestMethod $url1 -Method 'POST' -Headers $headers -Body ($body | ConvertTo-Json -Depth 10)
    
    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("CreateAccount: $($response.subStatusCode) $($response.message) ");
        return $false;
    }

    return $true

}

function RegisterCardBody
{
    param (
        [hashtable]$body
    )

    $url1 = $baseUrl + "card-management/card/register"

    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    $response = Invoke-RestMethod $url1 -Method 'POST' -Headers $headers -Body ($body | ConvertTo-Json -Depth 10)
    
    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("RegisterCardBody: $($response.subStatusCode) $($response.message) ");
        return $false;
    }

    return $true

}

function UpdateCardRegisterStatus
{
    param (
        [hashtable]$body
    )

    $url1 = $baseUrl + "card-management/register/status"

    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    $response = Invoke-RestMethod $url1 -Method 'PUT' -Headers $headers -Body ($body | ConvertTo-Json -Depth 10)
    
    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("UpdateCardRegisterStatus: $($response.subStatusCode) $($response.message) ");
        return $false;
    }

    return $true

}

function UpdateCardStatus
{
    param (
        [hashtable]$body
    )

    $url1 = $baseUrl + "card-management/card/status"

    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    $response = Invoke-RestMethod $url1 -Method 'PUT' -Headers $headers -Body ($body | ConvertTo-Json -Depth 10)
    
    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("UpdateCardRegisterStatus: $($response.subStatusCode) $($response.message) ");
        return $false;
    }

    return $true
}

function UpdateAccount 
{
    param (
        [hashtable]$body
    )

    $url1 = $baseUrl + "/account-management/account/$($body.Id)"

    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    $response = Invoke-RestMethod $url1 -Method 'PUT' -Headers $headers -Body ($body | ConvertTo-Json -Depth 10)
    
    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("UpdateAccount: $($response.subStatusCode) $($response.message) ");
        return $false;
    }

    return $true
}

function AddTPKHistory
{
    param (
        [hashtable]$body
    )

    $url1 = $baseUrl + "/account-management/account/addtpkhistory"

    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    $response = Invoke-RestMethod $url1 -Method 'POST' -Headers $headers -Body ($body | ConvertTo-Json -Depth 10)
    
    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("AddTPKHistory: $($response.subStatusCode) $($response.message) ");
        return $false;
    }

    return $true

}

function UpdateContactAddress {
    param (
        [hashtable]$body,
        [string]$addressId
    )

    $url1 = $baseUrl + "/account-management/address/$($addressId)"

    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    $response = Invoke-RestMethod $url1 -Method 'POST' -Headers $headers -Body ($body | ConvertTo-Json -Depth 10)
    
    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        LogFile("UpdateContactAddress: $($response.subStatusCode) $($response.message) ");
        return $false;
    }

    return $true
    
}