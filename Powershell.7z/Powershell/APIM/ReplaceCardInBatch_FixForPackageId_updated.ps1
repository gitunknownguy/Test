[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "ReplaceCardOp-0920.csv"
)

$logFileName = "log_$([guid]::NewGuid()).log"

. ".\AciProxy.ps1"

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import from a csv file, call ReplaceCard API
# It must has CardProxy,DispatchMethodCodeCardMailer,ACIPackIDCode,VendorID in the CSV file
#
# This script is for PR mode to add the missing card in ACI side
# 
#
#############################################################################

LogFile "log file: $($logFileName)"

if((Test-Path -Path $csvFileName) -eq $false)
{
    LogFile "Can't find CSV File: $($csvFileName)"
    return;
}


$csv = Import-Csv -Path $csvFileName -Delimiter ","


function DoSetCardStatus()
{
    param
    (
        [PSCustomObject]$cardDetail,
        [string]$cardStatus
    )

    $body = @{        
        statusCode = $cardStatus;
        plasticId = $cardDetail.id;
        issueNumber = $cardDetail.plasticIssueNo;
    }

    Write-Host ($body | ConvertTo-Json)

    SetCardStatus $body
}

function DoForceUpdate
{
    param
    (
        [string]$accountId
    )


    $normalCard = GetFirstNormalCard $accountId
    if($normalCard.PlasticId -eq "")
    {
        LogFile("CardProxy: $($cardProxy) not find a normal card")
        continue;
    }

    $body = @{        
        plasticId = $normalCard.plasticId;
        issueNumber = $normalCard.plasticIssueNo;
    }
	
	LogFile ($body | ConvertTo-Json)

    ForceUpdate $body
}


foreach ($line in $csv) 
{
    $ret = GetAccountId $line.CardProxy
    if($account.customerId -eq ""){
        LogFile "Can't find Account by AltPan: $($line.CardProxy)"

        continue
    }

    LogFile("AltPan: $($line.AltPan), accountId: $($ret.accountId)")

    $lastCard = GetLastCard $ret.accountId $line.CardProxy

    #if($lastCard.endDate -eq $line.EndDate)
    #{
    #    LogFile "AltPan: $($line.AltPan), last card end date is equal to the date in file $($lastCard.plasticIssueNo)" "warm"
    #    continue;
    #}

   


    $cardDetail = GetCardDetail $lastCard.plasticId $lastCard.plasticIssueNo
    LogFile "LastCard $($cardDetail.plasticIssueNo) $($lastCard.endDate)"


    

    $body = @{        
            plasticId=$cardDetail.id;
            plasticIssueNo=$cardDetail.plasticIssueNo;
            embosserName1=$cardDetail.embosserName1;
            embosserName2=$cardDetail.embosserName2;
            cardDispatchMethod=$line.DispatchMethodCodeCardMailer;
            deviceStyleId=$cardDetail.deviceStyleId;
            paymentDeviceId=$cardDetail.paymentDeviceId;
            endDate=$cardDetail.EndDate;
            manualStatus="ACTP";
            replaceCardFeeWaiver=$true;
            dispatchFeeWaiver=$true;
            overrideDispatIndicator=$true;
            packageId=$line.ACIPackIDCode;
            outputFileEmbossingVendorId = $line.VendorID;
        }

    LogFile ($body | ConvertTo-Json)


    ReplaceCard $body

    DoSetCardStatus $cardDetail "CLOS"

    DoForceUpdate $ret.accountId
}















