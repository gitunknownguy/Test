[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "p1.csv"
)

$logFileName = "log_$([guid]::NewGuid()).log"

. ".\AciProxy.ps1"

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
#
#############################################################################

LogFile "log file: $($logFileName)"


$csv = Import-Csv -Path $csvFileName -Delimiter ","

function RandomNumeric()
{
    param(
        [int]$len
    )

    $Numeric = "1234567890";

    $sb = New-Object System.Text.StringBuilder;
    for ($i = 0; $i -lt $len; $i++)
    {
        $pos = Get-Random -Minimum 0 -Maximum $Numeric.Length
        $c = $Numeric[$pos]
        
        $sb.Append($c) | Out-Null
    }

    return $sb.ToString();
}


foreach ($line in $csv) 
{
    #write-host $line


    $createAccountBody = @{
        agreement = @{
            institutionId = "GDOT"
        };
        account = @{
            openDate = ([System.DateTime]::Today.AddDays(-1).ToString("yyyy-MM-dd"));
            accountTypeId = $line.accounttypeid;
            contactId = "00FE024400000001";
            corporateAccount = "0"
            currencyCode = "840";
            cycleLength = "1";
            cycleLengthUnits = �MNTH�;
            cyclicalStatementFrequency = "NVER";
            inStructureFlag = "0";
            institutionId = "GDOT";
            productId = $line.productid;
            preferredCycleDay = $line.billcycleday;
            accountNumber = $line.ddaaccountnumber;
            routingNumber = $line.routingnunber;

        };
        accountCreditData = @{
            creditCheckDefinitionId = "D002";
            creditLimit = "0";
            lastCreditLimitChangeDate = "2020-01-01";
            institutionId = "GDOT";
            overlimitFlag = "0";
            wholeAccountCreditRule = "1";

        };
        sequence = @(
            @{
                deviceIssue = @{
                    deactivatePreviousDeviceOnFirstUseFlag = "0";
                    deviceStyleId = $line.devicestyleid;
                    embosserName1 = $line.embossingline1;
                    embosserName2 = $line.embossingline2;
                    paymentDeviceId = $line.paymentdeviceid;
                };
                application = @{
                    alternativePAN = $line.alternative_pan;
                    pan = $line.pan;
                    endDate = $line.expirationdate.Insert(4,'-').insert(7,'-');
                }
            }
        )
    };

    

    LogFile ($createAccountBody | ConvertTo-Json -Depth 10)

    
    CreateAccount $createAccountBody

    $r1 = RandomNumeric 13
    $r2 = RandomNumeric 13
    $addressReferenceNumber = "1$($r1)";
    $customerRefNo = "1$($r2)";

    $registerCardBody = @{
        pan = $line.pan;
        contactAddress = @{
            institutionId= "GDOT";
            addressLine1= $line.addressline1;
            addressLine2 = $line.addressline2;
            addressLine3 = $line.addressline3;
            city = $line.cityname;
            county = "";
            country=$line.countrycode;
            postcode=$line.zippostalcode;
            phone=$line.work_phone_num;
            fax=$null;
            associatedMemoFlag= "0";
            addressType="PRVT";
            addressReferenceNumber=$addressReferenceNumber
            lastUpdateNo= ""
        };
        customer= @{
            institutionId="GDOT";
            corporate="0";
            familyName=$line.familyname;
            firstName=$line.firstname;
            middleInitials=$line.middleinitials;
            knownAs="";
            prefixTitle= "";
            suffixTitle= "";
            dob=$line.dateofbirth.Insert(4,'-').insert(7,'-');;
            languageId="ENGL";
            socialSecurityNumber=$line.ssn;
            customerRefNo=$customerRefNo;
            associatedMemoFlag= "0";
            customerType= "CUST";
            customerDeceasedFlag= "0";
            customerReferenceNumberType= "NORM";
            socialSecurityNumberType= "SSNO";
            vip= "0";
            lastMaintenanceTypeFlag= "0";
        };
        additionalCustomerDetail=@{
            sex="FEML";
            maritalStatus="SNGL";
            noDependants="";
            mobilePhone=$line.mobile_phone_num;
            emailAddress= $line.emailaddress;
            securityData= "";
            securityDataId= "MMNE";
            employerName= "";
            workPhoneNo =$null;
            workFaxNo= "";
            nationality= "";
            PhotoIdNo= "";
            residencyStatus= "RESI";
            workPermitStatus= "NREQ";
            occupationCode= "PERM";
            applicationScore= "";
            applicationScoreDate= "2022-10-30";
            employeeIdNumber= $null;
            costCentre= $null;
            departmentName= $null;
            customerVATNumber= "";
            institutionId= "GDOT";
            lastMaintenanceTypeFlag= "0";
            lastUpdateNo ="";
        }
    };

    LogFile ($registerCardBody | ConvertTo-Json -Depth 10)

    RegisterCardBody $registerCardBody

    $updateCardRegisterStatusBody = @{
        pan = $line.pan;
    }

    LogFile ($updateCardRegisterStatusBody | ConvertTo-Json -Depth 10)

    UpdateCardRegisterStatus $updateCardRegisterStatusBody


    $updateCardStatusBody = @{
        pan = $line.pan;
        statusCode = ""
    }

    LogFile ($updateCardStatusBody | ConvertTo-Json -Depth 10)

    UpdateCardStatus $updateCardStatusBody

}















