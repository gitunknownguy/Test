[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "ReplaceCard.csv"
)

$logFileName = "log_$([guid]::NewGuid()).log"

. ".\AciProxy.ps1"

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import from a csv file, call ReplaceCard API
# It must has AltPan,ContactId in the CSV file
#
#############################################################################

LogFile "log file: $($logFileName)"


$csv = Import-Csv -Path $csvFileName -Delimiter ","


foreach ($line in $csv) 
{
    $ret = GetAccountId $line.AltPan
    if($account.customerId -eq ""){
        LogFile "Can't find Account by AltPan: $($line.AltPan)"

        continue
    }

    LogFile("AltPan: $($line.AltPan), accountId: $($ret.accountId)")

    $lastCard = GetLastCard $ret.accountId $AltPan

    $cardDetail = GetCardDetail $lastCard.plasticId $lastCard.plasticIssueNo
    LogFile "LastCard $($cardDetail.plasticIssueNo)"


    $updateCardBody = @{

        activationDate=$cardDetail.activationDate;
        activationMethod=$cardDetail.activationMethod;
        associatedMemoFlag=$cardDetail.associatedMemoFlag;
        authenticationTokenRequiredFlag=$cardDetail.authenticationTokenRequiredFlag;
        cardDispatchMethod=$cardDetail.cardDispatchMethod;
        cardMailerContactId=$cardDetail.cardMailerContactId;
        cardMailerInsertCode=$cardDetail.cardMailerInsertCode;
        cardRegisteredFlag=1;
        deactivatePreviousDeviceOnFirstUseFlag=$cardDetail.deactivatePreviousDeviceOnFirstUseFlag;
        deviceStyleId=$cardDetail.deviceStyleId;
        embosserName1=$cardDetail.embosserName1;
        endDate=$cardDetail.endDate;
        id=$cardDetail.id
        institutionId="GDOT";
        issueDate=$cardDetail.issueDate;
        issueReason=$cardDetail.issueReason;
        lastUpdateNo=$cardDetail.lastUpdateNo;
        manualStatus=$cardDetail.manualStatus;
        overrideCardDispatchMethodFlag=$cardDetail.overrideCardDispatchMethodFlag;
        overrideCardMailerContactId=$line.ContactId;
        overrideCardMailerContactStartDate="2023-07-17";
        overrideCardMailerContactEndDate="2023-07-23";  
        paymentDeviceId=$cardDetail.paymentDeviceId;
        photocardFlag=$cardDetail.PhotocardFlag;
        plasticIssueNo= $cardDetail.plasticIssueNo;
        plasticTransferOnActivationFlag=$cardDetail.plasticTransferOnActivationFlag;
        productionStatus= $cardDetail.productionStatus;
        productionStatusChangeDate=$cardDetail.productionStatusChangeDate;
        reissueNumber=$cardDetail.reissueNumber;
        replacementCounter=$cardDetail.replacementCounter;
        startDate=$cardDetail.startDate;
        statusCodeChangeDate=$cardDetail.statusCodeChangeDate;
        technicalFallbackAllowedFlag="0";


    }

    LogFile ($updateCardBody | ConvertTo-Json)

    UpdateCardDetail $updateCardBody $cardDetail.id


    

}















