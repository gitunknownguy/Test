﻿[cmdletbinding()]
param(
#[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$baseUrl = "https://prod-gen-apim.go2bankonline.net/aciproxy/v1",
[string]$key = "cc485ab07bcc464592d5ec91ad543cf1",
#[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "account_regratde_test.csv"
)


$csv = Import-Csv -Path $csvFileName -Delimiter ","

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import from a csv file, call Add tpk history API
# It must has AltPan,AccountTypeId,ProductId in the CSV file
#
#############################################################################

#$fileName = "log_$([guid]::NewGuid()).txt"

. ".\AciProxy.ps1"

foreach ($line in $csv) {
    $ret = GetAccountId $line.AltPan
    if($ret.customerId -eq ""){
        LogFile "Can't find Account by AltPan: $($line.alternative_pan)"

        continue
    }

    LogFile("alternative_pan: $($line.alternative_pan), accountId: $($ret.accountId)")

    $body = @{
        accountTypeId = $line.AccountTypeId;
        accountId = $ret.accountId;
        productId = $line.ProductId;
        institutionId = "GDOT";
    };

    $body | ConvertTo-Json

    #AddTPKHistory $body
}

