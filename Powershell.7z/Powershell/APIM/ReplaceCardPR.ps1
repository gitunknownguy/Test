[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$AltPan = "1264120005569319",
[string]$EndDate = "2028-05-05"
)

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

$logFileName = "log_$([guid]::NewGuid()).log"

. ".\AciProxy.ps1"

LogFile "log file: $($logFileName)"

$ret = GetAccountId $AltPan
if($account.customerId -eq ""){
    continue
}

LogFile("accountId: $($ret.accountId)")

$lastCard = GetLastCard $ret.accountId $AltPan

$cardDetail = GetCardDetail $lastCard.plasticId $lastCard.plasticIssueNo
LogFile "LastCard $($cardDetail.plasticIssueNo)"

$body = @{        
        plasticId=$cardDetail.id;
        plasticIssueNo=$cardDetail.plasticIssueNo;
        embosserName1=$cardDetail.embosserName1;
        embosserName2=$cardDetail.embosserName2;
        cardDispatchMethod=$cardDetail.cardDispatchMethod;
        deviceStyleId=$cardDetail.deviceStyleId;
        paymentDeviceId=$cardDetail.paymentDeviceId;
        endDate=$endDate;
        manualStatus="ACTP";
        replaceCardFeeWaiver=$true;
        dispatchFeeWaiver=$true;
        overrideDispatIndicator=$true;
        outputFileEmbossingVendorId = "EXCL";
    }

$body

#ReplaceCard $body



