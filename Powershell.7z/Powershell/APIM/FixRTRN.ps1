﻿[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "list.txt"
)


$csv = Import-Csv -Path $csvFileName -Delimiter ","

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import from a csv file, call Add tpk history API
# It must has AltPan in the CSV file
#
#############################################################################

#$fileName = "log_$([guid]::NewGuid()).txt"

. ".\AciProxy.ps1"

function DoSetCardStatus()
{
    param
    (
        [PSCustomObject]$cardDetail,
        [string]$cardStatus
    )

    LogFile "Start DoSetCardStatus"

    $body = @{        
        statusCode = $cardStatus;
        plasticId = $cardDetail.id;
        issueNumber = $cardDetail.plasticIssueNo;
    }

    Write-Host ($body | ConvertTo-Json)

    SetCardStatus $body
}

function DoForceUpdate
{
    param
    (
        [string]$accountId
    )

    LogFile "Start DoForceUpdate"

    $normalCard = GetFirstNormalCard $accountId
    if($normalCard.PlasticId -eq "")
    {
        LogFile("CardProxy: $($cardProxy) not find a normal card")
        continue;
    }

    $body = @{        
        plasticId = $normalCard.plasticId;
        issueNumber = $normalCard.plasticIssueNo;
    }
	
	LogFile ($body | ConvertTo-Json)

    ForceUpdate $body
}

foreach ($line in $csv) {
    $ret = GetAccountId $line.AltPan
    if($ret.customerId -eq ""){
        LogFile "Can't find Account by AltPan: $($line.AltPan)"

        continue
    }

    LogFile("AltPan: $($line.AltPan), accountId: $($ret.accountId)")

    $aciCards = (GetPlasticAndApplications $ret.accountId | Where-Object {$_.plasticIssueNo -ne "+0000"});
    if($aciCards.Length -eq 0)
    {
        LogFile "CardProxy: $($cardProxy) can't find a card."
        continue
    }

    foreach($card in $aciCards)
    {
        if($card.manualStatus -eq 'RTRN')
        {
            DoSetCardStatus $card 'ACTP'
        }
    }

    DoForceUpdate $ret.accountId
}

