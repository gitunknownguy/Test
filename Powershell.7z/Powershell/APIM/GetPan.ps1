﻿[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$plasticId = "0217000000CB71C4",
[string]$plasticIssueNo = "+0001"
)

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

$logFileName = "log_$([guid]::NewGuid()).csv"


. ".\AciProxy.ps1"

$pan = GetPan $plasticId $plasticIssueNo

$pan | ConvertTo-Json

$ret = GetAccountId $pan.alternativePAN 

$apps = (GetPlasticAndApplications $ret.accountId)
    
$items = @()

foreach($app in $apps)
{
    $item = @{
        plasticId = $app.plasticId;
        plasticIssueNo = $app.plasticIssueNo;
        manualStatus = $app.manualStatus;
        pan = $app.pan.Replace("******","_");
        endDate = $app.endDate;
        productionStatus = $app.productionStatus;
        issueReason = $app.issueReason
    }
    $items += ([PSCustomObject]$item)
}

#$result | ConvertTo-Json -Depth 10

$items  | ConvertTo-Csv -NoTypeInformation