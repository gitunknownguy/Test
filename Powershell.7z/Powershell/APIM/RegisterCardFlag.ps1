﻿[cmdletbinding()]
param(
[string]$baseUrl = "https://prod-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "cc485ab07bcc464592d5ec91ad543cf1",
[string]$csvFileName = "regcard.csv"
)


$csv = Import-Csv -Path $csvFileName -Delimiter ","

. ".\AciProxy.ps1"

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import from a csv file, call UdateCardRegisterStatus API
# It must has PlasticId,IssueNumber in the CSV file
#
#############################################################################


foreach ($line in $csv) {

    #write-host $line

    $ret = GetAccountId $line.cardproxy

    LogFile "AltPan: $($line.cardproxy), accountId: $($ret.accountId)"

    $card = GetLastCard $ret.accountId $line.CardProxy

    LogFile "AltPan: $($line.cardproxy), $($card.plasticIssueNo) $($card.plasticIssueNo)"

    $pan = GetPan $card.plasticId $card.plasticIssueNo
    


    $url1 = $baseUrl + "card-management/register/status"

    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $requestId = GetRequestId
    $headers.Add("X-Request-ID", $requestId)

    $body = @{        
        pan = $pan.pan
    }

    $response = Invoke-RestMethod $url1 -Method 'PUT' -Headers $headers -Body ($body | ConvertTo-Json)
    $response
    
}
