[cmdletbinding()]
param(
[string]$baseUrl = "https://prod-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "5775afc68f9b4f1d86951f972ab11480",
#[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
#[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "254_reactivate.csv"
)

$logFileName = "log_$([guid]::NewGuid()).log"
$resultFile ="AccounrRefNo.csv"

. ".\AciProxy.ps1"

#https://prod-gen-apim.go2bankonline.net/aciproxy/v1/

#############################################################################
#
# Import from a csv file, call ReplaceCard API
# It must has AltPan in the CSV file
#
# This script is for PR mode to add the missing card in ACI side
# 
#
#############################################################################

LogFile "log file: $($logFileName)"

if((Test-Path -Path $csvFileName) -eq $false)
{
    LogFile "Can't find CSV File: $($csvFileName)"
    return;
}


$csv = Import-Csv -Path $csvFileName -Delimiter ","


foreach ($line in $csv) 
{
    $ret = GetAccountId $line.AltPan
    if($account.customerId -eq ""){
        LogFile "Can't find Account by AltPan: $($line.AltPan)"

        continue
    }

    Add-Content -Path $resultFile -Value "$($line.AltPan),$($ret.accountRefNo)"

}















