[cmdletbinding()]
param(
[string]$email = "$([System.Environment]::UserName)@greendotcorp.com",
[string]$pass = ""
)

#######################################################################################
# 
# READ ME
# 
# What to do in this script:
# 1. Sign into ActiveBatch
# 2. List folder under QA 
# 3. List Job under each folder
#
#
######################################################################################

$headersLogin = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$headersLogin.Add("Content-Type", "application/json")

$body = @"
{
  `"jobScheduler`": `"g1npactbat02.nextestate.com`",
  `"username`": `"$($email)`",
  `"password`": `"$($pass)`",
  `"validFor`": `"02:00:00`"
}
"@

$response = Invoke-RestMethod 'https://g1npactbat02.nextestate.com/activebatch/api/v1/login' -Method 'POST' -Headers $headersLogin -Body $body

$token = $response.token


$headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$headers.Add("Authorization", $token)

$envs = Invoke-RestMethod 'https://g1npactbat02.nextestate.com/activebatch/api/v1/objects?searchPath=/QA Environment/&objectTypes=folder&limit=1000&recursive=false' -Method 'GET' -Headers $headers

foreach($env in $envs)
{
    $jobs = Invoke-RestMethod "https://g1npactbat02.nextestate.com/activebatch/api/v1/objects?searchPath=$($env.key.path)&objectTypes=folder&limit=1000&recursive=false" -Method 'GET' -Headers $headers


    foreach($folder in $jobs)
    {
        #Write-Host "$($folder.key.path) "

        $url = "https://g1npactbat02.nextestate.com/activebatch/api/v1/objects?searchPath=$($folder.key.path)&objectTypes=job&limit=1000"
        #Write-Host $url

        $jobs = Invoke-RestMethod "https://g1npactbat02.nextestate.com/activebatch/api/v1/objects?searchPath=$($folder.key.path)&objectTypes=job&limit=1000" -Method 'GET' -Headers $headers


        foreach($job in $jobs)
        {
            #write-host $job
            Write-Host "$($env.key.name),$($folder.key.name),$($job.key.name),$($job.nextRunDateTime)"
        }

        #return
    }

}

