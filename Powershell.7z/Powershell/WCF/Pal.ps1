Add-Type -Path ".\WcfClientDll.dll"

$bind = New-Object System.ServiceModel.WSHttpBinding;
$bind.Security.Mode = [System.ServiceModel.SecurityMode]::None;
$addr = New-Object System.ServiceModel.EndpointAddress("http://G2Q4LGYIPSCOM01/ProcessorTransmission/ProcessorTransmission.svc")
$client = New-Object Gdot.ProcessorTransmission.Client.ProcessorTransmissionClient($bind,$addr)
$client.Open()

$config = $client.GetConfig()

Write-Host ($config | ConvertTo-Json)
#
#$client.Close()
#$client.Dispose()
