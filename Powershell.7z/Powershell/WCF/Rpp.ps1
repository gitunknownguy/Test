$MyInvocation.MyCommand.Path | Split-Path | Push-Location

Add-Type -Path ".\WcfClientDll.dll"

[System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true} ;


$bind = New-Object System.ServiceModel.BasicHttpBinding([System.ServiceModel.BasicHttpSecurityMode]::TransportCredentialOnly);

$bind.Security.Transport.ClientCredentialType = [System.ServiceModel.HttpClientCredentialType]::Ntlm;

$addr = New-Object System.ServiceModel.EndpointAddress("http://GDCSVCV3/RegistrationPostProcessor/RegistrationPostProcessor.svc")
$client = New-Object Gdot.RegistrationPostProcessor.Client.RegistrationPostProcessorWebClient($bind,$addr)

$client.ClientCredentials.Windows.AllowedImpersonationLevel = [System.Security.Principal.TokenImpersonationLevel]::Impersonation;
$client.ClientCredentials.Windows.AllowNtlm = $true

$client.Open()

$config = $client.HealthCheck()

Write-Host ($config | ConvertTo-Json)
#
#$client.Close()
#$client.Dispose()
