﻿[cmdletbinding()]
param(
[string]$baseUrl = "https://bossvc.qa.uw2.gdotawsnp.com/cbsprocessormanager/v1/",
[string]$csvFileName = "AccountId.csv"
)


$csv = Import-Csv -Path $csvFileName -Delimiter ","

#https://bossvc.prod.uw2.gdotawspd.com/CBSProcessorManager/v1/
#https://bossvc-gbr.prod.uw2.gdotawspd.com/CBSProcessorManager/v1/
#https://bossvc-intuit.prod.uw2.gdotawspd.com/CBSProcessorManager/v1/

#############################################################################
#
# Import from a csv file, then call CPM GetAccountBalance to trigger a backfill
# It must has ProgramCode,AccountIdentifier,ProductCode,CardProxy colume in the CSV file 
#
#############################################################################

function GetRequestId {
    $requestId = [guid]::NewGuid();

    Write-Host "RequestId:$($requestId)"

    return $requestId
}

$fileName = "backfill_$([guid]::NewGuid()).csv"

Set-Content $fileName null

foreach ($line in $csv) {
    $url1 = $baseUrl + "programs/$($line.ProgramCode)/card/ActivateProspectSampleCard"

    $headers = @{}
    
    
    $headers.Add("Content-Type", "application/json")    

    $requestId = GetRequestId

    $body = @{
        header = @{
            requestId = $requestId;
            UseACIShadowEnvironment = $false
        };
        ProductCode = $line.ProductCode;
        AccountIdentifier = $line.AccountIdentifier;
        programCode = $line.ProgramCode;
        CardProxy = $line.CardProxy;
        PaymentInstrumentType = 3;
        CardStockCode = "EM99"        
    }
    
    $response = Invoke-RestMethod $url1 -Method 'POST' -Headers $headers -Body ($body | ConvertTo-Json)

    $response

    Add-Content $fileName -Value ($response | ConvertTo-Json)
}



Write-Host "CSV: $($fileName)"

