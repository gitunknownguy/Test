﻿[cmdletbinding()]
param(
[string]$baseUrl = "https://bossvc.qa.uw2.gdotawsnp.com/cbsprocessormanager/v1/",
[string]$csvFileName = "ordercard.csv"
)


$csv = Import-Csv -Path $csvFileName -Delimiter ","

#https://bossvc.prod.uw2.gdotawspd.com/CBSProcessorManager/v1/
#https://bossvc-gbr.prod.uw2.gdotawspd.com/CBSProcessorManager/v1/
#https://bossvc-intuit.prod.uw2.gdotawspd.com/CBSProcessorManager/v1/

#############################################################################
#
# Import from a csv file, then call CPM GetAccountBalance to trigger a backfill
# It must has 
# ProgramCode,AccountIdentifier,PaymentIdentifierIdentifier,PaymentInstrumentIdentifier,ProductMaterialType 
# colume in the CSV file 
#############################################################################

function GetRequestId {
    $requestId = [guid]::NewGuid();

    Write-Host "RequestId:$($requestId)"

    return $requestId
}

foreach ($line in $csv) {
    $url1 = $baseUrl + "programs/$($line.ProgramCode)/card/ordercard"
    $headers = @{}
    
    
    $headers.Add("Content-Type", "application/json")    

    $requestId = GetRequestId

    $body = @{
        header = @{
            requestId = $requestId
        };
        programCode = $line.ProgramCode;
        AccountIdentifier = $line.AccountIdentifier;
        paymentIdentifierIdentifier = $line.PaymentIdentifierIdentifier;
        paymentInstrumentIdentifier = $line.PaymentInstrumentIdentifier;
        productMaterialType = $line.ProductMaterialType;
        deliveryMethod = 1; #Regular: 1, Rush: 2, Overnight:3 , USPSExpeditedOvernight: 4
        NeedEmbossing = $true;
        Override10DayLimit = $true;
        OverrideDispatIndicator = $true;
        #ReplacementReason = 1;
        WaiveFee = $true;
        WaiveOvernightFee = $true;
    }

    $body | ConvertTo-Json
    
    $response = Invoke-RestMethod $url1 -Method 'POST' -Headers $headers -Body ($body | ConvertTo-Json)

    $response | ConvertTo-Json

}


