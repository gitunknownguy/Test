function GetPanByCardReferenceID {
    param (
        [System.Data.SqlClient.SqlConnection]$sqlConn,
        [string]$id
    )
    
    $sqlParam = @{
        "@pCardReferenceID"=$CardReferenceID
    }
    
    $sp = [System.Data.CommandType]::StoredProcedure
    $ds = ExecReadDateTables $sqlConn "GetSerialNbrByCardReferenceId" $sqlParam $sp
    
    $serialNbr = $ds.SerialNbr
    

    return $serialNbr;
}

function UpdateNecAccount {
    param (
        [System.Data.SqlClient.SqlConnection]$sqlConn,
        [string]$id,
        [string]$accountRefNo
    )

    $sqlParam = @{
        "@CardReferenceID"=$id;
        "@AccountRefNo"=$accountRefNo
    }
    
    $sp = [System.Data.CommandType]::Text
    ExecNonQuery $sqlConn "UPDATE dbo.Account SET AciAccountExternalId=@AccountRefNo WHERE AccountKey=
    (SELECT TOP(1) a.AccountKey FROM dbo.Account AS a INNER JOIN dbo.Card c ON c.AccountKey = a.AccountKey WHERE c.CardReferenceID=@CardReferenceID ORDER BY a.AccountKey DESC)
    " $sqlParam $sp | Out-Null
    
}

function GetMembershipByCardReferenceID {
    param (
        [System.Data.SqlClient.SqlConnection]$sqlConn,
        [string]$id
    )

    $inputDt = New-Object System.Data.DataTable

    $col = New-Object System.Data.DataColumn "CardReferenceID"
    $inputDt.Columns.Add($col)

    $dr = $inputDt.NewRow()
    $dr["CardReferenceID"] = $id
    $inputDt.Rows.Add($dr)
    
    $sqlParam = @{
        "@pListOfCardReferenceID"= $inputDt
    }
    
    $sp = [System.Data.CommandType]::StoredProcedure
    $result = ExecReadDateTables $sqlConn "GetMembershipByCardReferenceID" $sqlParam $sp

    $arr = @();

    if ($result.Rows.Count -eq 1) {
        $arr+=($result.MembershipTypeKey)
    }else{
        foreach ($item in $result[1]) {
            $key = $item["MembershipTypeKey"]
            Write-Host $key
            $arr+=($key)
        }
    }

    
    
    return $arr;
}

function GetProcessorProductInfo {
    param (
        [System.Data.SqlClient.SqlConnection]$sqlConn,
        [string]$id,
        [int]$pProcessorProductTypeKey
    )
    
    $sqlParam = @{
        "@pCardReferenceID"=$id;
        "@pProcessorProductTypeKey"=$pProcessorProductTypeKey
    }
    
    $sp = [System.Data.CommandType]::StoredProcedure
    $ds = ExecReadDateTables $sqlConn "GetProcessorProductCodesByCardReferenceID" $sqlParam $sp
    
    $arr = [System.Collections.ArrayList]::new()

    if($ds.Rows.Count -eq 0 )
    {
        return ,$arr;
    }
    elseif ($ds.Rows.Count -eq 1) {
        $null = $arr.Add(@{
            ProductKey = $ds.ProductKey;
            ProcessorProductKey = $ds.ProcessorProductKey;
            ProcessorProduct = $ds.ProcessorProduct;
        })
    }
    else{
        foreach ($item in $ds) {
            $null = $arr.Add(@{
                ProductKey = $item.ProductKey;
                ProcessorProductKey = $item.ProcessorProductKey;
                ProcessorProduct = $item.ProcessorProduct;
            })
        }
    }

    return ,$arr;
}

function GetACIProcessorProductDefinition {
    param (
        [System.Data.SqlClient.SqlConnection]$sqlConn,
        [int]$productKey,
        [string]$processorProduct,
        [string]$bin
    )

    $sqlParam = @{
        "@pProductKey"=$productKey;
        "@pProcessorProduct"=$processorProduct
    }
    
    $sp = [System.Data.CommandType]::StoredProcedure
    $ds = ExecReadDateTables $sqlConn "GetACIProcessorProductDefinition" $sqlParam $sp

    $arr = [System.Collections.ArrayList]::new()

    if($ds.Rows.Count -eq 0 )
    {
        return ,$arr;
    }
    elseif ($ds.Rows.Count -eq 1) {
        $null = $arr.Add($ds)
    }
    else{
        foreach ($item in $ds) {
            $null = $arr.Add($item)
        }
    }

    $def = $arr | Where-Object {$_.BIN -eq $bin}

    return $def;
    
}

function GetPlasticByCardReferenceID {
    param (
        [System.Data.SqlClient.SqlConnection]$sqlConn,
        [string]$id
    )

    $sqlParam = @{
        "@CardReferenceID"=$id;
    }
    
    $sp = [System.Data.CommandType]::StoredProcedure
    $ds = ExecReadDateTables $sqlConn "GetPlasticByCardReferenceID" $sqlParam $sp

    $arr = [System.Collections.ArrayList]::new()

    if($ds.Rows.Count -eq 0 )
    {
        return ,$arr;
    }
    elseif ($ds.Rows.Count -eq 1) {
        $null = $arr.Add($ds)
    }
    else{
        foreach ($item in $ds) {
            $null = $arr.Add($item)
        }
    }

    return $arr;
}

function GetCardExternalIDByCardReferenceIDs {
    param (
        [System.Data.SqlClient.SqlConnection]$sqlConn,
        [string]$id
    )

    $inputDt = New-Object System.Data.DataTable

    $col = New-Object System.Data.DataColumn "CardReferenceID"
    $inputDt.Columns.Add($col)

    $dr = $inputDt.NewRow()
    $dr["CardReferenceID"] = $id
    $inputDt.Rows.Add($dr)
    
    $sqlParam = @{
        "@typeCardReferenceID"= $inputDt
    }
    
    $sp = [System.Data.CommandType]::StoredProcedure
    $ds = ExecReadDateTables $sqlConn "GetCardExternalIDByCardReferenceIDs" $sqlParam $sp
    
    if($ds.Rows.Count -eq 0 )
    {
        return $null;
    }
    elseif ($ds.Rows.Count -eq 1) {
        return $ds.CardExternalID;
    }
    else{
        foreach ($item in $ds) {
            return $item.CardExternalID;
        }
    }
}

function RandomNumeric()
{
    param(
        [int]$len
    )

    $Numeric = "1234567890";

    $sb = New-Object System.Text.StringBuilder;
    for ($i = 0; $i -lt $len; $i++)
    {
        $pos = Get-Random -Minimum 0 -Maximum $Numeric.Length
        $c = $Numeric[$pos]
        
        $sb.Append($c) | Out-Null
    }

    return $sb.ToString();
}

function UpdateAccountTranslationByCardRefId {
    param (
        [System.Data.SqlClient.SqlConnection]$sqlConn,
        [string]$id,
        [string]$accountRefNo,
        [string]$aciSystemId
    )

    $sqlParam = @{
        "@pCardReferenceId"=$id;
        "@pACIAccountExternalID"=$accountRefNo;
        "@pACIAccountSystemKey"=$aciSystemId
    }
    
    $sp = [System.Data.CommandType]::StoredProcedure
    ExecNonQuery $sqlConn "UpdateAccountTranslationByCardRefId" $sqlParam $sp
}