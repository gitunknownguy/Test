[cmdletbinding()]
param(
[string]$baseUrl = "https://qa-gen-apim.go2bankonline.net/aciproxy/v1/",
[string]$key = "28f615072a694f2999322a2b6edcdfdf",
[string]$csvFileName = "cid.csv",
[string]$NECDBHost = "GDCQA4SQL",
[string]$PDSHost = "G2QA4IPSSQL01"
)

$defaultContactId = "001B020200000003" #QA
#$defaultContactId = "001B01F700000003" #Prod

$MyInvocation.MyCommand.Path | Split-Path | Push-Location

$csv = Import-Csv -Path $csvFileName -Delimiter ","

$NecDb = "Data Source=$($NECDBHost);initial Catalog=NEC;Integrated Security=SSPI;Encrypt=True;TrustServerCertificate=True"
$PdsDb = "Data Source=$($PDSHost);initial Catalog=PDS;Integrated Security=SSPI;Encrypt=True;TrustServerCertificate=True"

. "..\DB\DbService.ps1"
. ".\LegacyDbFunction.ps1"

Add-Type -Path "..\DB\Gdot.Common.DataAccess.dll"

$encryptClass = new-object Gdot.Common.DataAccess.EncryptClass

$sqlConnNec = New-Object System.Data.SqlClient.SqlConnection
$sqlConnNec.ConnectionString = $NecDb
$sqlConnNec.Open()

$sqlConnPds = New-Object System.Data.SqlClient.SqlConnection
$sqlConnPds.ConnectionString = $PdsDb
$sqlConnPds.Open()

function CreateAccount
{
    param (
        [hashtable]$body
    )

    $url1 = $baseUrl + "account-management/account/add-with-sggentities"

    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)

    

    Write-Host "RequestId : $($requestId)"

    $headers.Add("X-Request-ID", $requestId)

    $response = Invoke-RestMethod $url1 -Method 'POST' -Headers $headers -Body ($body | ConvertTo-Json -Depth 10)
    
    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        Write-Host "CreateAccount: $($response.subStatusCode) $($response.message) "
        return $false;
    }

    return $response
}

function GetAccountId {
    param (
        [string]$AltPan
    )
    $url1 = $baseUrl + "account-management/accountdr/$($AltPan)"
    
    Write-Host $url1
    
    $headers = @{}
    $headers.Add("Content-Type", "application/json") 
    $headers.Add("Ocp-Apim-Subscription-Key", $key)
    $headers.Add("X-Request-ID", $requestId)

    $response = Invoke-RestMethod $url1 -Method 'GET' -Headers $headers

    
    if($response.statusCode -ne "0" -or $response.subStatusCode -ne "+000000000")
    {
        Write-Host "$($AltPan), GetAccount: $($response.subStatusCode) $($response.message)";
        return @{
            accountId = ""
            customerId = ""
            accountTypeId=""
            accountRefNo=""
            productId=""
            lastUpdateNo=""
            contactAddressId=""
        }
    }


    $accountId = $response.rawResponse.DR008011.'repeatingGroupOut-1'.'repeatingGroupInstanceOut-1'[0].GeDmAccountDR008011Subset0001.id
    $customerId = $response.rawResponse.DR008011.GeDmCustomerContactAddressDR008011Subset0001.customerId
    $accountTypeId = $response.rawResponse.DR008011.'repeatingGroupOut-1'.'repeatingGroupInstanceOut-1'[0].GeDmAccountDR008011Subset0001.accountTypeId
    $accountRefNo = $response.rawResponse.DR008011.'repeatingGroupOut-1'.'repeatingGroupInstanceOut-1'[0].GeDmAccountDR008011Subset0001.accountRefNo
    $productid = $response.rawResponse.DR008011.'repeatingGroupOut-1'.'repeatingGroupInstanceOut-1'[0].GeDmAccountDR008011Subset0001.productId
    $lastUpdateNo = $response.rawResponse.DR008011.'repeatingGroupOut-1'.'repeatingGroupInstanceOut-1'[0].GeDmAccountDR008011Subset0001.lastUpdateNo
    $contactAddressId =$response.rawResponse.DR008011.GeDmCustomerContactAddressDR008011Subset0001.contactAddressId

    return @{
        accountId = $accountId;
        customerId = $customerId;
        accountTypeId = $accountTypeId;
        accountRefNo=$accountRefNo;
        productId=$productid;
        lastUpdateNo=$lastUpdateNo;
        contactAddressId=$contactAddressId
    }
}

foreach ($line in $csv) {
    $CardReferenceID = $line.CardReferenceID

    write-host "CardReferenceID: $CardReferenceID"

    $requestId = [guid]::NewGuid();

    $serialNbr = GetPanByCardReferenceID $sqlConnNec $CardReferenceID
    $pan = $encryptClass.DecMC($serialNbr);

    if ($null -eq $pan) {
        Write-Host "pan not found"
        continue;
    }

    Write-Host $"pan: $pan"

    $aciAccount = GetAccountId $pan
    if ($aciAccount.accountId -ne "") {
        Write-Host "Account already exists. accountRefNo: $($aciAccount.accountRefNo)"

        UpdateNecAccount $sqlConnNec $CardReferenceID $aciAccount.accountRefNo

        continue;
    }

    $bin = $pan.Substring(0,6)
    $bin

    $memberShipps = GetMembershipByCardReferenceID $sqlConnNec $CardReferenceID

    $item9 = $memberShipps | Where-Object {$_ -eq 9}

    if($item9.Count -gt 0)
    {
        #NPNR
        $products = GetProcessorProductInfo $sqlConnNec $CardReferenceID 3 
    }
    else {
        #Perso

        $products = GetProcessorProductInfo $sqlConnNec $CardReferenceID 2 

    }

    if (0 -eq $products.Count) {
        $products = GetProcessorProductInfo $sqlConnNec $CardReferenceID 1 
    }

    if(0 -eq $products.Count)
    {
        Write-Host "product not found"
        continue;
    }

    $product = $products[0]
    $aciProductDefinition = GetACIProcessorProductDefinition $sqlConnNec $product.ProductKey $product.ProcessorProduct $bin

    $plastics = GetPlasticByCardReferenceID $sqlConnNec $CardReferenceID
    $plastic = ($plastics | Sort-Object {$_.PlasticKey})[0]

    $expDate = $plastic.ExpirationDate.ToString("yyyy-MM-dd")

    $cardProxy = GetCardExternalIDByCardReferenceIDs $sqlConnPds $CardReferenceID
    $cardProxy = $cardProxy.Trim()


    $creditCheck = @()

    $creditArray = $aciProductDefinition.ACICreditCheckDefinitionID.Split(',')
    $sortedArray = $creditArray | Sort-Object -Descending

    foreach($cCheck in $sortedArray)
    {
        if($creditCheck.Count -eq 0)
        {
            $creditCheck += @{
                creditCheckDefinitionId = $cCheck;
                creditLimit = "0";
                lastCreditLimitChangeDate = "2020-01-01";
                institutionId = "GDOT";
                overlimitFlag = "1";
                wholeAccountCreditRule = "1";
                currencyCode = "840";
            };
        }
        else
        {
            $creditCheck += @{
                creditCheckDefinitionId = $cCheck;
                creditLimit = "0";
                lastCreditLimitChangeDate = "2020-01-01";
                institutionId = "GDOT";
                overlimitFlag = "0";
                wholeAccountCreditRule = "0";
                currencyCode = "840";
            };
        }       
    }

    $createAccountBody = @{
        agreement = @{
            institutionId = "GDOT"
        };
        account = @{
            openDate = ([System.DateTime]::Today.AddDays(-1).ToString("yyyy-MM-dd"));
            accountTypeId = $aciProductDefinition.ACIAccountType;
            contactId = $defaultContactId;
            corporateAccount = "0"
            currencyCode = "840";
            cycleLength = "1";
            cycleLengthUnits = "MNTH";
            cyclicalStatementFrequency = "NVER";
            inStructureFlag = "0";
            institutionId = "GDOT";
            productId = $aciProductDefinition.ACIProductID;
            preferredCycleDay = "1";

        };
        accountCreditDataList = $creditCheck;
        sequence = @(
            @{
                deviceIssue = @{
                    deactivatePreviousDeviceOnFirstUseFlag = "0";
                    deviceStyleId = $aciProductDefinition.ACIDeviceStyleID;
                    embosserName1 = "GDOT";
                    embosserName2 = "Valued Customer";
                    paymentDeviceId = $aciProductDefinition.ACIPaymentDeviceID;
                    #PackageId = $aciProductDefinition.packageid;
                    outputFileEmbossingVendorId = "EXCL";
                };
                application = @{
                    alternativePAN = $cardProxy;
                    pan = $pan.Substring(0, $pan.Length - 1) + "C";
                    endDate = $expDate;
                };

            };
        )
    };

    Write-Host ($createAccountBody | ConvertTo-Json -Depth 10)


    $createAccRes =  CreateAccount $createAccountBody

    if ($createAccRes -eq $false) {
        Write-Host "Create account failed."
        continue; 
    }

    $createAccRes | ConvertTo-Json -Depth 10

    $accountRefNo = $createAccRes.rawResponse.DR008001.GeDmAccountDR008001Subset0001.accountRefNo
    $aciSystemId = $createAccRes.rawResponse.DR008001.GeDmAccountDR008001Subset0001.id
    UpdateNecAccount $sqlConnNec $CardReferenceID $accountRefNo
    UpdateAccountTranslationByCardRefId $sqlConnPds $CardReferenceID $accountRefNo $aciSystemId

    #UpdateAccountTranslationByCardRefId
    #UpdateCardHolderTranslationByCardRefId
}

$sqlConnNec.Close();
$sqlConnPds.Close();







