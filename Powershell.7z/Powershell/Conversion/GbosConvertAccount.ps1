$scriptPath = $MyInvocation.MyCommand.Path | Split-Path
Set-Location -Path $scriptPath


