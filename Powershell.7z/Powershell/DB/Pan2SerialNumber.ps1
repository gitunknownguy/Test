[cmdletbinding()]
param(
[string]$InputText = '4115190008619036' #K[$h}TGjoH
)

Add-Type -Path ".\Gdot.Common.DataAccess.dll"
$encryptClass = new-object Gdot.Common.DataAccess.EncryptClass

if ($InputText -match '\d+') {
    Write-Host $encryptClass.EncMC($InputText);
}
else {
    Write-Host $encryptClass.DecMC($InputText);
}


