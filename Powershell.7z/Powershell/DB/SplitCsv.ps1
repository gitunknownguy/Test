[cmdletbinding()]
param(
[string]$csvFile = '230909_no_state.txt',
[int]$rowInOneFile = 100
)


$content = Get-Content -Path $csvFile

$fileId = 1;
$row = 1;
$fileName = [System.IO.Path]::GetFileNameWithoutExtension($csvFile);
$ext = [System.IO.Path]::GetExtension($csvFile);

$newFileName = "$($fileName)_$($fileId).$($ext)"

Add-Content -Path $newFileName $content[0]

for ($i = 1; $i -lt $content.Length; $i++,$row++) {
    Add-Content -Path $newFileName $content[$i]

    if($row -eq $rowInOneFile)
    {
        $fileId++;
        $newFileName = "$($fileName)_$($fileId).$($ext)"
        $row = 0

        Add-Content -Path $newFileName $content[0]
    }
}

