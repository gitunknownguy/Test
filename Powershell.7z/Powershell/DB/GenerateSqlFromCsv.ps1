[cmdletbinding()]
param(
[string]$csvFileName = "C:\Users\qijiong.zhao\Downloads\p.txt",
[int]$batchCount = 10000
)

$csv = Import-Csv -Path $csvFileName -Delimiter ","

$randomNumber = Get-Random -Minimum 100 -Maximum 999
$tmpTableName = "##temp$($randomNumber)"

$sbCreateTable = [System.Text.StringBuilder]::new()
$sbInsertTable = [System.Text.StringBuilder]::new()
$sbCreateTable.AppendLine("--select * from $($tmpTableName);") | Out-Null
$sbCreateTable.AppendLine("--drop table if exists $($tmpTableName);") | Out-Null
$sbCreateTable.AppendLine("create temp table $($tmpTableName)(") | Out-Null
$sbInsertTable.AppendLine("insert into $($tmpTableName) values") | Out-Null

$outPutFile = "$($tmpTableName).txt"



$colName = New-Object System.Collections.ArrayList
$members = $csv | Get-Member

for ($i = 0; $i -lt $members.Count; $i++) {
    $m = $members[$i];

    if($m.MemberType -ne "NoteProperty")
    {
        continue;
    }
    $colName.Add($m.Name) | Out-Null

    if($i -eq ($members.Count - 1))
    {
        $sbCreateTable.AppendLine("[$($m.Name)] varchar(1000)") | Out-Null
    }
    else {
        $sbCreateTable.AppendLine("[$($m.Name)] varchar(1000),") | Out-Null
    }
}

$sbCreateTable.AppendLine(");") | Out-Null

Add-Content $outPutFile $sbCreateTable.ToString()

$rowInMemory = 0;



for($l=0;$l -lt $csv.Count; $l+=1)
{
    $rowInMemory+=1
    $sbInsertTable.Append("(") | Out-Null
    
    $ht = @{}

    $line = $csv[$l]
    $line.psobject.properties | Foreach { $ht[$_.Name] = $_.Value }

    for($c=0;$c -lt $ht.Count ; $c += 1)
    {
        if($c -eq ($ht.Count - 1))
        {
            
            $sbInsertTable.Append("'$($ht[$colName[$c]])'") | Out-Null
        }
        else
        {
            $sbInsertTable.Append("'$($ht[$colName[$c]])',") | Out-Null
        }        
    }
    if($rowInMemory -eq $batchCount -or $l -eq $csv.Count - 1)
    {
        $sbInsertTable.AppendLine(");") | Out-Null

        Write-Host "$($l) / $($csv.Count)"

        Add-Content $outPutFile $sbInsertTable.ToString()

        $sbInsertTable.Clear() | Out-Null
        $rowInMemory = 0
        $sbInsertTable.AppendLine("insert into $($tmpTableName) values") | Out-Null
    }
    else
    {
        $sbInsertTable.AppendLine("),") | Out-Null
    }
}

if($rowInMemory -gt 0)
{
    Add-Content $outPutFile $sbInsertTable.ToString()
}
