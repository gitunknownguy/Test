[cmdletbinding()]
param(
    [string]$CardProxy = "3199531991",
    [string]$Bin = "",
    [string]$dbHost = 'adhocsql'
)

$MyInvocation.MyCommand.Path | Split-Path | Push-Location

#############################################################################
#
# Import from a csv file
# CSV file must has a head line and at least 2 date line
# script will use a random table name and output to console
#
#############################################################################

$Db = "Data Source=$($dbHost);initial Catalog=tempdb;Integrated Security=SSPI;Encrypt=True;TrustServerCertificate=True"

. ".\DbService.ps1"
. ".\LegacyDbFunction.ps1"


$sqlConn = New-Object System.Data.SqlClient.SqlConnection
$sqlConn.ConnectionString = $Db
$sqlConn.Open()

$csv = Import-Csv -Path $csvFileName -Delimiter ","

foreach ($line in $csv) {
    $CardReferenceId = GetCardReferenceIdByCardProxy $sqlConn $line.CardProxy

    if ($null -eq $CardReferenceId) {
        Write-Host "Can't find Card Reference Id by CardProxy $($CardReferenceId) => $($line.CardProxy)"

        continue;
    }

    $memberShip = GetMembershipByCardReferenceID $sqlConn $CardReferenceId

    Write-Host "CardReferenceId: $($CardReferenceId) memberShip $($memberShip)"

    if ($null -eq $memberShip) {
        Write-Host "Can't find membership $($line.CardProxy)"
        continue;
    }

    if ($memberShip -eq "9") {
        $ProcessorProductCode = GetProcessorProductCodesByCardReferenceID $sqlConn $CardReferenceId 3

        if ($null -eq $ProcessorProductCode) {
            $ProcessorProductCode = GetProcessorProductCodesByCardReferenceID $sqlConn $CardReferenceId 1
        }
    }
    else {
        $ProcessorProductCode = GetProcessorProductCodesByCardReferenceID $sqlConn $CardReferenceId 2
    }

    if ($null -eq $ProcessorProductCode) {
        Write-Host "Can't find ProcessorProductCode $($line.CardProxy)"
        continue;
    }

    $productkey = $ProcessorProductCode[0]
    $processorProduct = $ProcessorProductCode[1]

    Write-Host "productkey: $($productkey) processorProduct: $($processorProduct)"

    $aciProductDefinition = GetACIProcessorProductDefinition $sqlConn $productkey $processorProduct $Bin

    Write-Host $"result: $($line.CardProxy) ACIProductID $($aciProductDefinition[0]) ACIAccountType $($aciProductDefinition[1])"
}




$sqlConn.Dispose()