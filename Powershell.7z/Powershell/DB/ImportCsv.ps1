[cmdletbinding()]
param(
[string]$csvFileName = "file.csv",
[string]$dbHost = 'devbosdbag.awsnp.gdotawsnp.com'
)

$Db = "Data Source=$($dbHost);initial Catalog=tempdb;Integrated Security=SSPI;Encrypt=True;TrustServerCertificate=True"


$csv = Import-Csv -Path $csvFileName -Delimiter ","

$randomNumber = Get-Random �Minimum 100 -Maximum 999
$tmpTableName = "##temp$($randomNumber)"

Write-Host "TableName: $($tmpTableName)"


function ExecNonQuery()
{
    param(
        [System.Data.SqlClient.SqlConnection]$sqlConn,
        [string]$query,
        [hashtable]$params
    )

    $sqlcmd = $sqlConn.CreateCommand()
    $sqlcmd = New-Object System.Data.SqlClient.SqlCommand
    $sqlcmd.Connection = $sqlConn

    foreach($key in $params.Keys){    
        #Write-Host "$($key) $($params[$key])"

        $newItem = $sqlcmd.Parameters.AddWithValue($key,$params[$key])
    }
    
    $sqlcmd.CommandText = $query
    $sqlcmd.CommandType = [System.Data.CommandType]::Text
    
    return $sqlcmd.ExecuteNonQuery()
}

$sbCreateTable = [System.Text.StringBuilder]::new()
$sbInsertTable = [System.Text.StringBuilder]::new()
$sbCreateTable.AppendLine("create table $($tmpTableName)(") | Out-Null
$sbInsertTable.AppendLine("insert $($tmpTableName) values") | Out-Null

$colName = New-Object System.Collections.ArrayList

foreach ($m in ($csv | Get-Member)) 
{
    if($m.MemberType -ne "NoteProperty")
    {
        continue;
    }
    $colName.Add($m.Name) | Out-Null
    $sbCreateTable.AppendLine("[$($m.Name)] varchar(1000),") | Out-Null
}

$sbCreateTable.AppendLine(")") | Out-Null

$sqlConn = New-Object System.Data.SqlClient.SqlConnection
$sqlConn.ConnectionString = $Db
$sqlConn.Open()

#$sbCreateTable.ToString()

ExecNonQuery $sqlConn $sbCreateTable.ToString() @{}

$rowInMemory = 0;
$batchCount = 1000;


for($l=0;$l -lt $csv.Count; $l+=1)
{
    $rowInMemory+=1
    $sbInsertTable.Append("(") | Out-Null
    
    $ht = @{}

    $line = $csv[$l]
    $line.psobject.properties | Foreach { $ht[$_.Name] = $_.Value }

    for($c=0;$c -lt $ht.Count ; $c += 1)
    {
        if($c -eq ($ht.Count - 1))
        {
            
            $sbInsertTable.Append("'$($ht[$colName[$c]])'") | Out-Null
        }
        else
        {
            $sbInsertTable.Append("'$($ht[$colName[$c]])',") | Out-Null
        }        
    }
    if($rowInMemory -eq $batchCount -or $l -eq $csv.Count - 1)
    {
        $sbInsertTable.AppendLine(")") | Out-Null

        Write-Host "$($l) / $($csv.Count)"

        #$sbInsertTable.ToString()
        ExecNonQuery $sqlConn $sbInsertTable.ToString() @{}

        $sbInsertTable.Clear() | Out-Null
        $rowInMemory = 0
        $sbInsertTable.AppendLine("insert $($tmpTableName) values") | Out-Null
    }
    else
    {
        $sbInsertTable.AppendLine("),") | Out-Null
    }
}



if($rowInMemory -gt 0)
{
    ExecNonQuery $sqlConn $sbInsertTable.ToString() @{}
}



#$sqlConn.Dispose()