function GetCardReferenceIdByCardProxy
{
    param(
        [System.Data.SqlClient.SqlConnection]$sqlConn,
        [string] $CardProxy   
    )


    $sqlGetCardReferenceIdByCardProxy = "
DECLARE @pCardReferenceID UNIQUEIDENTIFIER;

select top 1 ct.CardExternalID, CONVERT(varchar(10), p.ExpirationDate,120) ExpirationDate
,p.EmbossType,p.CRVRemovalDate,p.IsActive, c.CardReferenceID
from CCDW_NCD..Card c (nolock)
left join CCDW_NCD..Customer c2 (nolock) on c.CustomerKey=c2.CustomerKey
left join CCDW_NCD..Account a (nolock) on c2.AccountKey=a.AccountKey
left join CCDW_NCD..Plastic p on p.CardKey=c.CardKey
left join PDS_View..CardTranslation ct (nolock) on ct.CardReferenceID=c.CardReferenceID
where ct.CardExternalID='$($CardProxy)'
"
    
    $tables = ExecReadDateTables $sqlConn $sqlGetCardReferenceIdByCardProxy 

    if($tables[0].Rows.Count -eq 0)
    {
        return $null;
    }

    $CardReferenceID = $tables[0].Rows[0]["CardReferenceID"]

    return $CardReferenceID
}

function GetMembershipByCardReferenceID
{
    param(
        [System.Data.SqlClient.SqlConnection]$sqlConn,
        [string] $CardProxy   
    )

    $sqlGetMembershipByCardReferenceID = "

SET NOCOUNT ON;

DECLARE @pCardReferenceID UNIQUEIDENTIFIER;
DECLARE @pProcessorProductTypeKey INT

SET @pCardReferenceID = '$($CardReferenceID)';

DECLARE @MembershipTypeKey SMALLINT;


SELECT @MembershipTypeKey = m.MembershipTypeKey
FROM CCDW_NCD..Card crd WITH (NOLOCK)
    INNER JOIN CCDW_NCD..CustomerMembership cm WITH (NOLOCK)
        ON cm.CustomerKey = crd.CustomerKey
    INNER JOIN CCDW_NCD..Membership m WITH (NOLOCK)
        ON m.MembershipKey = cm.MembershipKey
    INNER JOIN CCDW_NCD..MembershipFeature msf WITH (NOLOCK)
        ON msf.MembershipKey = m.MembershipKey
WHERE cm.StartDate <= GETDATE()
        AND cm.EndDate > GETDATE()
        AND crd.CardReferenceID = @pCardReferenceID;

select @MembershipTypeKey


"

    $tables = ExecReadDateTables $sqlConn $sqlGetMembershipByCardReferenceID 

    if($tables[0].Rows.Count -eq 0)
    {
        return $null;
    }
 
    $MembershipTypeKey = $tables[0].Rows[0][0]
    return $MembershipTypeKey;
}

function GetProcessorProductCodesByCardReferenceID
{
    param(
        [System.Data.SqlClient.SqlConnection]$sqlConn,
        [string] $pCardReferenceID,
        [string] $pProcessorProductTypeKey
    )

    $sql = "
DECLARE @pCardReferenceID uniqueidentifier;
DECLARE @pProcessorProductTypeKey int;
DECLARE @pIsNPNR INT;
set @pIsNPNR=0;

set @pCardReferenceID='$($pCardReferenceID)';
set @pProcessorProductTypeKey=$($pProcessorProductTypeKey)

DECLARE @PPUSubscriptionTypeValue INT,
        @VIPBlackSuscriptionValue INT,
        @SuccessfulfCardDesignRequest INT,
        @rowcount INT,
        @Today AS SMALLDATETIME,
        @AccountKey INT,
        @IsUberBalanceBoost INT;

SET @PPUSubscriptionTypeValue = 11;
SET @VIPBlackSuscriptionValue = 6;
SET @SuccessfulfCardDesignRequest = 2;
SET @Today = GETDATE();
DECLARE @SubscritpionTypekey INT = 25; --Uber Balance Boost    

DECLARE @subscription TABLE
(
    Subscriptionkey INT
);
DECLARE @CustomCardCardDesignKey TABLE
(
    CardDesignKey INT,
    CardDesign VARCHAR(100)
);
-- insert only the CardDesignKeys for the true CustomCards that are applicable to PTS  
INSERT @CustomCardCardDesignKey
(
    CardDesignKey,
    CardDesign
)
SELECT 7,
       'Bamboo Custom'
UNION
SELECT 11,
       'Walmart Custom Card'
UNION
SELECT 18,
       'Green Dot Custom Card'
UNION
SELECT 43,
       'Uber Custom';

IF (@pProcessorProductTypeKey IS NULL)
    SET @pProcessorProductTypeKey = 2; -- DEFAULT TO PERSO  

DECLARE @ProductKey SMALLINT; -- change to support current C# code TLW 04/26/2016  
DECLARE @CardActivationDate DATETIME;

SELECT @ProductKey = c.ProductKey,
       @CardActivationDate = c.CardActivationDate
FROM CCDW_NCD..Card c
WHERE c.CardReferenceID = @pCardReferenceID;

DECLARE @PaidbyCheck TABLE
(
    PaymentProgramTypeKey INT
);
INSERT @PaidbyCheck
(
    PaymentProgramTypeKey
)
VALUES
(1  ); --Check Cashing  

SELECT @AccountKey = AccountKey
FROM CCDW_NCD..Card
WHERE CardReferenceID = @pCardReferenceID;

--get cardfeatures  
-- check if the card has VIP and/or PPU subscriptions  
SELECT c.CardReferenceID,
       c.ProductKey,
       RetailerKey,
       CustomerKey,
       -1 CardDesignkey,
       CAST(' ' AS VARCHAR(100)) Carddesign,
       CASE
           WHEN as1.AccountKey IS NULL THEN
               0
           ELSE
               1
       END IsVIPBlack,
       CASE
           WHEN as2.AccountKey IS NULL THEN
               0
           ELSE
               1
       END IsPayPerUse,
       0 IsCashAccess,
       CAST(0 AS BIT) iscustomcard,
       0 IsUberBalanceBoost
INTO #cardfeature
FROM CCDW_NCD..Card c WITH (NOLOCK)
    INNER JOIN CCDW_NCD..Product p WITH (NOLOCK)
        ON c.ProductKey = p.ProductKey
    LEFT JOIN CCDW_NCD..Account_Subscription as1 WITH (NOLOCK)
        ON c.AccountKey = as1.AccountKey
           AND as1.SubscriptionKey = @VIPBlackSuscriptionValue
           AND as1.EndDate > @Today
           AND as1.StartDate <> as1.EndDate
    LEFT JOIN
    (
        SELECT AccountKey
        FROM CCDW_NCD..Account_Subscription as1 WITH (NOLOCK)
            JOIN CCDW_NCD..Subscription s WITH (NOLOCK)
                ON s.SubscriptionKey = as1.SubscriptionKey
                   AND s.SubscriptionTypeKey = @PPUSubscriptionTypeValue
                   AND as1.EndDate > @Today
                   AND as1.StartDate <> as1.EndDate
    ) as2
        ON c.AccountKey = as2.AccountKey
WHERE c.CardReferenceID = @pCardReferenceID;


-- Check for IsUberBalanceBoost  

UPDATE #cardfeature -- works because the accountkey and cardreference are from the same card  
SET IsUberBalanceBoost = SubScriptionDetailValue
FROM CCDW_NCD..Account_Subscription a WITH (NOLOCK)
    INNER JOIN CCDW_NCD..Subscription s
        ON a.SubscriptionKey = s.SubscriptionKey
           AND a.StartDate <= @Today
           AND a.EndDate > @Today
    INNER JOIN CCDW_NCD..SubscriptionType st
        ON s.SubscriptionTypeKey = st.SubscriptionTypeKey
    INNER JOIN CCDW_NCD..SubscriptionDetail s1 WITH (NOLOCK)
        ON s1.SubscriptionKey = a.SubscriptionKey
           AND s1.SubScriptionDetailTypeKey = 12
WHERE AccountKey = @AccountKey;


-- check if the card has CardDesign  
-- if yes, retrieve the CardDesignKey of the lastest card design request with an approved image  
UPDATE cf
SET CardDesignkey = e.CardDesignkey,
    cf.Carddesign = e.CardDesign,
    cf.iscustomcard = CASE
                          WHEN e.CardDesignkey IN
                               (
                                   SELECT CardDesignKey FROM @CustomCardCardDesignKey
                               ) THEN
                              1
                          ELSE
                              0
                      END
FROM CCDW_NCD..Card c
    INNER JOIN #cardfeature cf
        ON cf.CardReferenceID = c.CardReferenceID
    JOIN
    (
        SELECT c.ProductKey,
               acdr.AccountKey,
               LastAccountCardDesignRequestKey = MAX(acdr.AccountCardDesignRequestKey),
               ImageStatusKey
        FROM CCDW_NCD..[Card] AS c WITH (NOLOCK)
            INNER JOIN CCDW_NCD..AccountCardDesignRequest AS acdr WITH (NOLOCK)
                ON acdr.AccountKey = c.AccountKey
            INNER JOIN CCDW_NCD..AccountCardDesignRequest_CardDesignImage a WITH (NOLOCK)
                ON acdr.AccountCardDesignRequestKey = a.AccountCardDesignRequestKey
            INNER JOIN CCDW_NCD..CardDesignImage cdi
                ON cdi.CardDesignImageKey = a.CardDesignImageKey
        WHERE cdi.ImageStatusKey = 4
              AND c.CardReferenceID = @pCardReferenceID
        GROUP BY c.ProductKey,
                 acdr.AccountKey,
                 ImageStatusKey
    ) b
        ON c.AccountKey = b.AccountKey
    JOIN CCDW_NCD..AccountCardDesignRequest_CardDesignImage a WITH (NOLOCK)
        ON b.LastAccountCardDesignRequestKey = a.AccountCardDesignRequestKey
    JOIN CCDW_NCD..CardDesignImage d
        ON a.CardDesignImageKey = d.CardDesignImageKey
           AND d.ImageStatusKey = 4 -- approved image  
    JOIN CCDW_NCD..CardDesign e
        ON d.CardDesignKey = e.CardDesignkey
    LEFT JOIN CCDW_NCD..CardDesignGallery_CardDesignImage f
        ON d.CardDesignImageKey = f.CardDesignImageKey
    LEFT JOIN CCDW_NCD..CardDesignGallery g
        ON f.CardDesignGalleryKey = g.CardDesignGalleryKey
WHERE c.CardReferenceID = @pCardReferenceID;

-- for temp and non-NPNR card, check for cash access qualification  
IF @pIsNPNR = 0
   AND @pProcessorProductTypeKey = 1 --if NPNR card there is no cash access (check cashing)  
BEGIN
    UPDATE a
    SET IsCashAccess = 1
    FROM #cardfeature a
        JOIN CCDW_NCD..RetailerSales rs
            ON a.CustomerKey = rs.CustomerKey
               AND rs.IsSwipeReload = 0
               AND rs.IsVoid = 0
        JOIN @PaidbyCheck pc
            ON rs.PaymentProgramTypeKey = pc.PaymentProgramTypeKey;
END;

-- check for approved image exists  
-- if not exist set CardDesignkey back to -1  
DECLARE @OLDCardReferenceID UNIQUEIDENTIFIER; ---- for session context  
SET @OLDCardReferenceID = @pCardReferenceID;
DECLARE @catchtable TABLE
(
    ProductKey INT,
    CardDesignKey INT,
    IsStandardCardDesign BIT,
    ImageStatusKey SMALLINT,
    ImageReferenceID VARCHAR(50),
    CardDesignImageKey INT,
    Path VARCHAR(255),
    ImageToken VARCHAR(36)
);


WITH LastCardDesignRequest AS   
(    
		SELECT c.ProductKey,  
			   acdr.AccountKey,  
			   LastAccountCardDesignRequestKey = MAX(acdr.AccountCardDesignRequestKey)  
		FROM CCDW_NCD..[Card] AS c WITH (NOLOCK)  
		INNER JOIN CCDW_NCD..AccountCardDesignRequest AS acdr WITH (NOLOCK)   
ON acdr.AccountKey = c.AccountKey  
		INNER JOIN  CCDW_NCD..AccountCardDesignRequest_CardDesignImage AS acdri WITH (NOLOCK)   
ON acdri.AccountCardDesignRequestKey = acdr.AccountCardDesignRequestKey   
		INNER JOIN CCDW_NCD..CardDesignImage AS cdi WITH (NOLOCK)   
ON cdi.CardDesignImageKey = acdri.CardDesignImageKey  
AND cdi.ImageStatusKey = 4 -- Image Approved  
		WHERE c.CardReferenceID = @pCardReferenceID         
		GROUP BY c.ProductKey, acdr.AccountKey  
) 
INSERT @catchtable
SELECT  lcdr.ProductKey,  
		cd.CardDesignKey,  
		cd.IsStandardCardDesign,  
		cdi.ImageStatusKey,  
		cdi.ImageReferenceID,  
		cdi.CardDesignImageKey,  
		cdi.[Path],  
CDI.ImageToken  
  FROM LastCardDesignRequest lcdr  
  INNER JOIN  CCDW_NCD..AccountCardDesignRequest_CardDesignImage AS acdri WITH (NOLOCK)   
		ON acdri.AccountCardDesignRequestKey = lcdr.LastAccountCardDesignRequestKey   
  INNER JOIN CCDW_NCD..CardDesignImage AS cdi WITH (NOLOCK)   
		ON cdi.CardDesignImageKey = acdri.CardDesignImageKey  
AND cdi.ImageStatusKey = 4 -- Image Approved  
  INNER JOIN CCDW_NCD..CardDesign AS cd WITH (NOLOCK)   
		ON cd.CardDesignKey = cdi.CardDesignKey  

IF @@ROWCOUNT < 1
BEGIN
    UPDATE #cardfeature
    SET CardDesignkey = -1
    WHERE CardReferenceID = @pCardReferenceID;
END;

-- for VIP, set CardDesignKey to 1  
UPDATE #cardfeature
SET CardDesignkey = 1
WHERE IsVIPBlack = 1;
----------------------------  


--get ppf  
-- get all ProcessorProducts associated with the card ProductKey, as well as their ProcessorProductFeatures  
SELECT pp.ProcessorProductKey,
       pp.ProcessorProduct,
       ProcessorProductTypeKey,
       p.ProductKey,
       CASE
           WHEN ppf1.ProcessorProductFeatureTypeKey = 1 THEN
               ppf1.FeatureDetailValue
           ELSE
               -1
       END CardDesignKey,
       CASE
           WHEN ppf2.ProcessorProductFeatureTypeKey = 3 THEN
               1
           ELSE
               0
       END IsPayPerUse,  -- PPU  
       CASE
           WHEN ppf3.ProcessorProductFeatureTypeKey = 4
                AND ppf3.FeatureDetailValue = 1 THEN
               1
           ELSE
               0
       END ISCashAccess, --Check Cashing  
       CASE
           WHEN ppf4.ProcessorProductFeatureTypeKey = 2 THEN
               1
           ELSE
               0
       END IsVIPBlack,   -- VIP  
       0 NoFeatures,
       ppf1.ProcessorProductFeatureTypeKey,
       CAST(ISNULL(cd.IsStandardCardDesign, 1) AS BIT) IsStandardCardDesign,
       0 IsUberBalanceBoost
INTO #ppf
FROM CCDW_NCD..ProcessorProduct pp
    JOIN CCDW_NCD..ProcessingProductDefinition ppd
        ON pp.ProcessorProductKey = ppd.ProcessorProductKey
    LEFT JOIN CCDW_NCD..ProcessorProductFeature ppf1
        ON pp.ProcessorProduct = ppf1.ProcessorProduct
           AND ppf1.ProcessorProductFeatureTypeKey = 1 -- carddesign  
    LEFT JOIN CCDW_NCD..CardDesign cd
        ON ppf1.FeatureDetailValue = cd.CardDesignkey
    LEFT JOIN CCDW_NCD..ProcessorProductFeature ppf2
        ON pp.ProcessorProduct = ppf2.ProcessorProduct
           AND ppf2.ProcessorProductFeatureTypeKey = 3 -- PayPerUse  
    LEFT JOIN CCDW_NCD..ProcessorProductFeature ppf3
        ON pp.ProcessorProduct = ppf3.ProcessorProduct
           AND ppf3.ProcessorProductFeatureTypeKey = 4 -- CheckCashing  
    LEFT JOIN CCDW_NCD..ProcessorProductFeature ppf4
        ON pp.ProcessorProduct = ppf4.ProcessorProduct
           AND ppf4.ProcessorProductFeatureTypeKey = 2 -- VIP  
    JOIN CCDW_NCD.. Product_ProcessorProduct ppp
        ON pp.ProcessorProductKey = ppp.ProcessorProductKey
           AND ISNULL(@CardActivationDate, GETDATE())
           BETWEEN ppp.ActivationBeginDate AND ppp.ActivationEndDate
    JOIN CCDW_NCD..Product p
        ON ppp.ProductKey = p.ProductKey
WHERE p.ProductKey = @ProductKey
      AND pp.ProcessorProductTypeKey = @pProcessorProductTypeKey;

--update IsUberBalanceBoost  
UPDATE a
SET IsUberBalanceBoost = ppf_UNB.FeatureDetailValue
FROM CCDW_NCD..Product_ProcessorProduct ppp
    JOIN #ppf a
        ON ppp.ProcessorProductKey = a.ProcessorProductKey
    JOIN CCDW_NCD..ProcessorProduct pp
        ON ppp.ProcessorProductKey = pp.ProcessorProductKey
    JOIN CCDW_NCD..ProcessingProductDefinition ppd
        ON pp.ProcessorProductKey = ppd.ProcessorProductKey
    LEFT JOIN CCDW_NCD..ProcessorProductFeature ppf_UNB
        ON pp.ProcessorProduct = ppf_UNB.ProcessorProduct
           AND ppf_UNB.ProcessorProductFeatureTypeKey = 6
WHERE ppf_UNB.FeatureDetailValue IS NOT NULL
      AND ppp.ProductKey = @ProductKey
      AND pp.ProcessorProductTypeKey = @pProcessorProductTypeKey;


--Emily get mataches  
--get matched ProcessorProduct  
-- top match: one that has the exact same set of features as the card  
SELECT 1 sortorder,                             -- exact match  
       ProcessorProductKey,
       @ProductKey ProductKey,
       a.ProcessorProduct,
       @pProcessorProductTypeKey ProcessorProductTypeKey,
       0 ProcessorProductFeatureTypeKey,        -- maintain signiture  
       'NA' ProcessorProductFeatureType,        -- maintain signiture  
       a.IsUberBalanceBoost FeatureDetailValue, -- maintain signiture  
       a.IsStandardCardDesign,                  -- maintain signiture  
       b.iscustomcard AllowCustomCardDesign     -- maintain signiture  
INTO #newmatch2
FROM #ppf a
    JOIN #cardfeature b
        ON b.IsCashAccess = a.ISCashAccess
           AND b.IsPayPerUse = a.IsPayPerUse
           AND b.CardDesignkey = a.CardDesignKey
           AND b.IsVIPBlack = a.IsVIPBlack
           AND a.IsUberBalanceBoost = b.IsUberBalanceBoost
ORDER BY b.CardDesignkey;
SET @rowcount = @@ROWCOUNT;

-- 2nd match: one that has no features, i.e. default ProcessorProduct  
INSERT #newmatch2
(
    sortorder,
    ProcessorProductKey,
    ProductKey,
    ProcessorProduct,
    ProcessorProductTypeKey,
    ProcessorProductFeatureTypeKey, -- maintain signiture  
    ProcessorProductFeatureType,    -- maintain signiture  
    FeatureDetailValue,             -- maintain signiture  
    IsStandardCardDesign,           -- maintain signiture  
    AllowCustomCardDesign           -- maintain signiture  
)
SELECT 2 sortorder,                      -- default processor product (no features)  
       a.ProcessorProductKey,
       @ProductKey ProductKey,
       b.ProcessorProduct,
       @pProcessorProductTypeKey,
       0 ProcessorProductFeatureTypeKey, -- maintain signiture  
       'NA' ProcessorProductFeatureType, -- maintain signiture  
       0 FeatureDetailValue,             -- maintain signiture  
       0 IsStandardCardDesign,           -- maintain signiture  
       0 AllowCustomCardDesign           -- maintain signiture  
FROM CCDW_NCD..Product_ProcessorProduct a
    JOIN CCDW_NCD..ProcessorProduct b
        ON a.ProcessorProductKey = b.ProcessorProductKey
           AND b.ProcessorProductTypeKey = @pProcessorProductTypeKey
           AND ISNULL(@CardActivationDate, GETDATE())
           BETWEEN a.ActivationBeginDate AND a.ActivationEndDate
WHERE a.ProductKey = @ProductKey
      AND
      (
          SELECT COUNT(*)
          FROM CCDW_NCD..ProcessorProductFeature c
          WHERE c.ProcessorProduct = b.ProcessorProduct
      ) = 0;

-- 3rd match: one that has at least one feature in common with the card  
INSERT #newmatch2
(
    sortorder,
    ProcessorProductKey,
    ProductKey,
    ProcessorProduct,
    ProcessorProductTypeKey,
    ProcessorProductFeatureTypeKey, -- maintain signiture  
    ProcessorProductFeatureType,    -- maintain signiture  
    FeatureDetailValue,             -- maintain signiture  
    IsStandardCardDesign,           -- maintain signiture  
    AllowCustomCardDesign           -- maintain signiture  
)
SELECT 3 sortorder,                             -- partial match  
       ProcessorProductKey,
       @ProductKey ProductKey,
       a.ProcessorProduct,
       @pProcessorProductTypeKey ProcessorProductTypeKey,
       0 ProcessorProductFeatureTypeKey,        -- maintain signiture  
       'NA' ProcessorProductFeatureType,        -- maintain signiture  
       a.IsUberBalanceBoost FeatureDetailValue, -- maintain signiture  
       a.IsStandardCardDesign,                  -- maintain signiture  
       b.iscustomcard AllowCustomCardDesign     -- maintain signiture  
FROM #ppf a
    JOIN #cardfeature b
        ON b.IsCashAccess = a.ISCashAccess
           AND
           (
               b.IsPayPerUse = a.IsPayPerUse
               OR b.CardDesignkey = a.CardDesignKey
               OR b.IsVIPBlack = a.IsVIPBlack
               OR b.IsUberBalanceBoost = a.IsUberBalanceBoost
           )
ORDER BY b.CardDesignkey;
SET @rowcount = @@ROWCOUNT;

-- 4th match: any ProcessorProduct that is associated with the card ProductKey  
INSERT #newmatch2
(
    sortorder,
    ProcessorProductKey,
    ProductKey,
    ProcessorProduct,
    ProcessorProductTypeKey,
    ProcessorProductFeatureTypeKey, -- maintain signiture  
    ProcessorProductFeatureType,    -- maintain signiture  
    FeatureDetailValue,             -- maintain signiture  
    IsStandardCardDesign,           -- maintain signiture  
    AllowCustomCardDesign           -- maintain signiture  
)
SELECT 4 sortorder,                      -- any processorproduct for the product  
       a.ProcessorProductKey,
       @ProductKey ProductKey,
       b.ProcessorProduct,
       @pProcessorProductTypeKey,
       0 ProcessorProductFeatureTypeKey, -- maintain signiture  
       'NA' ProcessorProductFeatureType, -- maintain signiture  
       0 FeatureDetailValue,             -- maintain signiture  
       0 IsStandardCardDesign,           -- maintain signiture  
       0 AllowCustomCardDesign           -- maintain signiture  
FROM CCDW_NCD..Product_ProcessorProduct a
    JOIN CCDW_NCD..ProcessorProduct b
        ON a.ProcessorProductKey = b.ProcessorProductKey
           AND b.ProcessorProductTypeKey = @pProcessorProductTypeKey
           AND ISNULL(@CardActivationDate, GETDATE())
           BETWEEN a.ActivationBeginDate AND a.ActivationEndDate
WHERE a.ProductKey = @ProductKey;


-- return the best match ProcessorProduct  
SELECT TOP 1
       a.ProductKey,
       a.ProcessorProductKey,
       a.ProcessorProduct,
       a.ProcessorProductTypeKey,
       a.ProcessorProductFeatureTypeKey,
       a.ProcessorProductFeatureType,
       a.FeatureDetailValue,
       a.IsStandardCardDesign,
       a.AllowCustomCardDesign
FROM #newmatch2 a
    JOIN CCDW_NCD..ProcessingProductDefinition b -- make sure there is a fab five  
        ON b.ProcessorProductKey = a.ProcessorProductKey
ORDER BY a.sortorder;
        
    "
    $tables = ExecReadDateTables $sqlConn $sql 
    if($tables[0].Rows.Count -eq 0)
    {
        return $null;
    }

    $productKey = $tables[0].Rows[0]["ProductKey"];
    $processorProduct = $tables[0].Rows[0]["ProcessorProduct"]
    
    return @($productKey,$processorProduct);
}

function GetCardAttributesByProcessorProduct
{

param(
        [System.Data.SqlClient.SqlConnection]$sqlConn,
        [string] $ProcessorProduct   
    )

    $sqlGetMembershipByCardReferenceID = "

SET NOCOUNT ON;


DECLARE @PackageBillofMaterials VARCHAR(100);
DECLARE @ProcessingAccountClassificationCode VARCHAR(100);

select   
@ProcessingAccountClassificationCode=PAC.ProcessingAccountClassificationCode,  
@PackageBillofMaterials=PCP.PackageBillofMaterials  
from CCDW_NCD..processorproduct pp  
join CCDW_NCD..ProcessingProductDefinition ppd  
on pp.processorproductkey = ppd.processorproductkey  
join CCDW_NCD..ProcessingAccountClassification PAC  
on PPD.ProcessingAccountClassificationKey = PAC.ProcessingAccountClassificationKey  
join CCDW_NCD..ProcessingCardClassification PCC  
on PPD.ProcessingCardClassificationKey = PCC.ProcessingCardClassificationKey  
join CCDW_NCD..ProcessingLimitPackage PLP  
on PPD.ProcessingLimitPackageKey = PLP.ProcessingLimitPackageKey  
join CCDW_NCD..ProcessingFeePackage PFP  
on PPD.ProcessingFeePackageKey = PFP.ProcessingFeePackageKey  
join CCDW_NCD..ProcessingCollateralPackage PCP  
on PPD.ProcessingCollateralPackageKey = PCP.ProcessingCollateralPackageKey  
where PP.ProcessorProduct = '$($ProcessorProduct)';

select @ProcessingAccountClassificationCode,@PackageBillofMaterials;
"

    $tables = ExecReadDateTables $sqlConn $sqlGetMembershipByCardReferenceID 

    if($tables[0].Rows.Count -eq 0)
    {
        return $null;
    }

    $ProcessingAccountClassificationCode = $tables[0].Rows[0][0]
    $PackageBillofMaterials = $tables[0].Rows[0][1]
    $list= @($ProcessingAccountClassificationCode,$PackageBillofMaterials)
	
    return ($list);

}


function GetAllACIPackIDCode
{

param(
        [System.Data.SqlClient.SqlConnection]$sqlConn,
        [string] $gdPackId
    )

    $sqlGetAllACIPackIDCode = "

SET NOCOUNT ON;
    SELECT ACIPackIDCode--,VendorCode
        FROM CCDW_NCD..ACIPackIDCode where IsActive=1 and GDPackID='$($gdPackId)'; 
"

    $tables = ExecReadDateTables $sqlConn $sqlGetAllACIPackIDCode 

    if($tables[0].Rows.Count -eq 0)
    {
        return $null;
    }
    $AciPackCode = $tables[0].Rows[0][0]
    #$VendorCode = $table[0].Rows[0][1]
    
    return @($AciPackCode,"");
}

function GetACIProcessorProductDefinition
{
    param(
        [System.Data.SqlClient.SqlConnection]$sqlConn,
        [string] $productKey,
        [string] $processorProduct,
        [string] $bin
    )

    $sql = "
    SET NOCOUNT ON;  
    SELECT apd.ACIProductID,  
    apd.ACIAccountType,  
    apd.ACIPaymentDeviceID,  
    apd.ACIDeviceStyleID,  
    apd.ACICreditCheckDefinitionID,  
    apd.ProductKey,  
    apd.ProcessorProductKey,  
apd.BIN,  
apd.IsDefaultBIN  
FROM CCDW_NCD..ACIProductDefinition apd  
INNER JOIN CCDW_NCD..ProcessorProduct pp  
ON apd.ProcessorProductKey = pp.ProcessorProductKey  
AND pp.ProcessorProduct = '$($processorProduct)'  
WHERE apd.ProductKey = $($productKey);  
    "

    $tables = ExecReadDateTables $sqlConn $sql 

    if($tables[0].Rows.Count -eq 0)
    {
        return $null;
    }

    if($bin -ne '')
    {
        for ($i = 0; $i -lt $tables[0].Rows.Count; $i++) {
            $row = $tables[0].Rows[$i];

            $b = $row["BIN"]
            if ($b -eq $bin) {
                return @(
                    $row["ACIProductID"],
                    $row["ACIAccountType"],
                    $row["ACIPaymentDeviceID"],
                    $row["ACIDeviceStyleID"],
                    $row["ACICreditCheckDefinitionID"],
                    $row["ProductKey"],
                    $row["ProcessorProductKey"],
                    $row["BIN"],
                    $row["IsDefaultBIN"]
                );
            }
        }

        return $null;
    }

    return @(
        $tables[0].Rows[0]["ACIProductID"],
        $tables[0].Rows[0]["ACIAccountType"],
        $tables[0].Rows[0]["ACIPaymentDeviceID"],
        $tables[0].Rows[0]["ACIDeviceStyleID"],
        $tables[0].Rows[0]["ACICreditCheckDefinitionID"],
        $tables[0].Rows[0]["ProductKey"],
        $tables[0].Rows[0]["ProcessorProductKey"],
        $tables[0].Rows[0]["BIN"],
        $tables[0].Rows[0]["IsDefaultBIN"]
    );
}
