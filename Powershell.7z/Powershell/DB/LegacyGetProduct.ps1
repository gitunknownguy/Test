[cmdletbinding()]
param(
[string]$CardProxy = "3199531991",
[string]$Bin = "",
[string]$dbHost = 'adhocsql'
)

#############################################################################
#
# Import from a csv file
# CSV file must has a head line and at least 2 date line
# script will use a random table name and output to console
#
#############################################################################

$Db = "Data Source=$($dbHost);initial Catalog=tempdb;Integrated Security=SSPI;Encrypt=True;TrustServerCertificate=True"

. ".\DbService.ps1"
. ".\LegacyDbFunction.ps1"


$sqlConn = New-Object System.Data.SqlClient.SqlConnection
$sqlConn.ConnectionString = $Db
$sqlConn.Open()


$CardReferenceId = GetCardReferenceIdByCardProxy $sqlConn $CardProxy

if($null -eq $CardReferenceId)
{
    Write-Host "Can't find Card Reference Id by CardProxy $($CardReferenceId) => $($CardProxy)"

    return
}

$memberShip = GetMembershipByCardReferenceID $sqlConn $CardReferenceId

Write-Host "CardReferenceId: $($CardReferenceId) memberShip $($memberShip)"

if($null -eq $memberShip)
{
    return
}

if($memberShip -eq "9")
{
    $ProcessorProductCode = GetProcessorProductCodesByCardReferenceID $sqlConn $CardReferenceId 3

    if($null -eq $ProcessorProductCode)
    {
        $ProcessorProductCode = GetProcessorProductCodesByCardReferenceID $sqlConn $CardReferenceId 1
    }
}
else
{
    $ProcessorProductCode = GetProcessorProductCodesByCardReferenceID $sqlConn $CardReferenceId 2
}

if($null -eq $ProcessorProductCode)
{
    Write-Host "GetProcessorProductCodesByCardReferenceID return null"
    return
}

$productkey = $ProcessorProductCode[0]
$processorProduct = $ProcessorProductCode[1]

Write-Host "productkey: $($productkey) processorProduct: $($processorProduct)"

$aciProductDefinition = GetACIProcessorProductDefinition $sqlConn $productkey $processorProduct $Bin

Write-Host ($aciProductDefinition | ConvertTo-Json)

$cardAttributesList = GetCardAttributesByProcessorProduct $sqlConn $processorProduct

$ProcessingAccountClassificationCode = $cardAttributesList[0]
$PackageBillofMaterials = $cardAttributesList[1] 

$packageId=""

if ($null -eq $PackageBillofMaterials)
{
	return $null
}
$dictionary = @{}
$AccountClassificationCode = "AAH:EMV,VAH:EMV,VAE:MAG,AAE:MAG,EV1:MAG,V1E:MAG,VAC:MAG,AAC:MAG,VAM:MAG,PAA:MAG,WAH:EMV,XAH:EMV"
$AccountClassificationCodesplitArray = $AccountClassificationCode.Split(",")

foreach ($str in $AccountClassificationCodesplitArray) {
    $temp =  $str.Split(":")
    $dictionary[$temp[0]] = $temp[1]
}


if($PackageBillofMaterials.Length -gt 4)
{
	$packageId = $PackageBillofMaterials
}
elseif($dictionary.Contains($ProcessingAccountClassificationCode))
{
    $value = $dictionary[$ProcessingAccountClassificationCode]

    $packageId = $PackageBillofMaterials + $value + "00"

    if($productkey -eq "7676" -or 
        $productkey -eq "7460" -or 
        $productkey -eq "1700" -or 
        $productkey -eq "1701" -or 
        $productkey -eq "7945" -or 
        $productkey -eq "7946"
        )
    {
        $packageId = $PackageBillofMaterials + "MAG00"
    }
}

$aciPackCode = GetAllACIPackIDCode $sqlConn $packageId

Write-Host ($aciPackCode | ConvertTo-Json)


$sqlConn.Dispose()