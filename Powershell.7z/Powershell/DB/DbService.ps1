function ExecReadDateTables()
{
    param(
        [System.Data.SqlClient.SqlConnection]$sqlConn,
        [string]$query,
        [hashtable]$params,
        [System.Data.CommandType] $commandType = [System.Data.CommandType]::Text
    )

    $sqlcmd = $sqlConn.CreateCommand()
    $sqlcmd = New-Object System.Data.SqlClient.SqlCommand
    $sqlcmd.Connection = $sqlConn

    foreach($key in $params.Keys){    
        #Write-Host "$($key) $($params[$key])"

        $null = $sqlcmd.Parameters.AddWithValue($key,$params[$key])
    }
    $sqlcmd.CommandText = $query
    $sqlcmd.CommandType = $commandType
    
    $adp = New-Object System.Data.SqlClient.SqlDataAdapter $sqlcmd
    
    $data = New-Object System.Data.DataSet
    $row = $adp.Fill($data)

    return ,$data.Tables

}

function ExecNonQuery()
{
    param(
        [System.Data.SqlClient.SqlConnection]$sqlConn,
        [string]$query,
        [hashtable]$params,
        [System.Data.CommandType] $commandType = [System.Data.CommandType]::Text
    )

    $sqlcmd = $sqlConn.CreateCommand()
    $sqlcmd = New-Object System.Data.SqlClient.SqlCommand
    $sqlcmd.Connection = $sqlConn

    foreach($key in $params.Keys){    
        #Write-Host "$($key) $($params[$key])"

        $newItem = $sqlcmd.Parameters.AddWithValue($key,$params[$key])
    }
    
    $sqlcmd.CommandText = $query
    $sqlcmd.CommandType = $commandType
    
    return $sqlcmd.ExecuteNonQuery()
}