[cmdletbinding()]
param(
[string]$DbGBOS = �Data Source=devbosdbag.awsnp.gdotawsnp.com;initial Catalog=GBOS;Integrated Security=SSPI;Encrypt=True;TrustServerCertificate=True�,
[string]$csvFileName = "DBFixReportLS.csv"
)

$sqlConn = New-Object System.Data.SqlClient.SqlConnection
$sqlConn.ConnectionString = $DbGBOS
$sqlConn.Open()


$sqlcmd = $sqlConn.CreateCommand()
$sqlcmd = New-Object System.Data.SqlClient.SqlCommand
$sqlcmd.Connection = $sqlConn
$sqlcmd.Parameters.Add("","")
$query = ��
$sqlcmd.CommandText = $query

$adp = New-Object System.Data.SqlClient.SqlDataAdapter $sqlcmd

$data = New-Object System.Data.DataSet
$adp.Fill($data) | Out-Null
$data.Tables[0]


$sqlConn.Dispose()