[cmdletbinding()]
param(
[string]$DBHost = "devbosdbag.awsnp.gdotawsnp.com",
[string]$csvFileName = "DBFixReportLS.csv"
)


$DbGBOS = "Data Source=$($DBHost);initial Catalog=GBOS;Integrated Security=SSPI;Encrypt=True;TrustServerCertificate=True;Column Encryption Setting=enabled"


function ExecNonQuery()
{
    param(
        [System.Data.SqlClient.SqlConnection]$sqlConn,
        [string]$query,
        [hashtable]$params
    )

    $sqlcmd = $sqlConn.CreateCommand()
    $sqlcmd = New-Object System.Data.SqlClient.SqlCommand
    $sqlcmd.Connection = $sqlConn

    foreach($key in $params.Keys){    
        #Write-Host "$($key) $($params[$key])"

        $newItem = $sqlcmd.Parameters.AddWithValue($key,$params[$key])
    }
    
    $sqlcmd.CommandText = $query
    $sqlcmd.CommandType = [System.Data.CommandType]::StoredProcedure
    
    return $sqlcmd.ExecuteNonQuery()
}

function ExecReadDateTables()
{
    param(
        [System.Data.SqlClient.SqlConnection]$sqlConn,
        [string]$query,
        [hashtable]$params
    )

    $sqlcmd = $sqlConn.CreateCommand()
    $sqlcmd = New-Object System.Data.SqlClient.SqlCommand
    $sqlcmd.Connection = $sqlConn

    foreach($key in $params.Keys){    
        #Write-Host "$($key) $($params[$key])"

        $newItem = $sqlcmd.Parameters.AddWithValue($key,$params[$key])
    }
    $sqlcmd.CommandText = $query
    $sqlcmd.CommandType = [System.Data.CommandType]::StoredProcedure
    
    $adp = New-Object System.Data.SqlClient.SqlDataAdapter $sqlcmd
    
    $data = New-Object System.Data.DataSet
    $row = $adp.Fill($data)

    return $data.Tables

}

$sqlConn = New-Object System.Data.SqlClient.SqlConnection
$sqlConn.ConnectionString = $DbGBOS
$sqlConn.Open()

 
$tables = ExecReadDateTables $sqlConn 'GetPaymentInstrumentByPaymentIdentifierProxy' @{
    PaymentIdentifierProxy='8408833559'
}

$tables[0].Rows[0]["PaymentIdentifierProxy"]


#ExecNonQuery $sqlConn "InsPaymentInstrumentForCBS" @{
#    ChangeBy="NEXTESTATE\svc_bos_core";
#    PaymentInstrumentIdentifier=[guid]::NewGuid();
#    PaymentIdentifierKey=49079;
#    PaymentInstrumentTypeKey=3;
#    PaymentInstrumentStatusKey=2;
#    EncryptedExpirationDate='072027';
#    HasEmbossedName=$true;
#    IssuedDateTime=[DateTime]::Today;
#    CardStock=123;
#}

$sqlConn.Dispose()