[cmdletbinding()]
param(
[string]$hex = "7E0800001F8B080000000000000ABD55CD6B1341149F978F36D88AC5828A8A2CD88BC2AEB333BBB33B82689A346DC0B6A15B8B7A324D96B448B3251B947A2AFD4FEAD98320A2474F5E3CE85D8A7F86088ACEEC779AB4CDC98124FBF67DCCFBF8FD5E8A0881B3D8D6E63D5F73B69A3DB7AD55BC9D1DAFAB2DBBBEDFEC6C773B5AA3E7B584E0F5165EB8DDBED3DA72779ADAB2DF59DFDB757DADE1F97DB7BDE2F65F7ABDE78145B5D96F4E218029A98A14304B31C6BA4E18C58C28E181192E8F65EB8CE916A68682D0A7EE879937DF4B30C718A3AED1E26A9B50AE1A9B2E53B9456D55C7A4855BB6C13609851242E8DBCF49EFF3D77737E07E1EA1A2A8E7EE19F5D477FD5070A35AD217326D115204811AE4CBD52A4C349CF5BAB30A97AB58AD592AB65456532B4CADD4D479AAEA0B088A8B4F4565489857EA08AE124CA88AB98AC5B7A599B666724D942E4E14386F1B1872180394A42DE698C20426A66DF240FF040E024B29C40FA1341D5A632BB08502B1B0295EBF2DC47A718968B34EC2DBE0E862A498081D5126F2AC619814EB26B6C500E2794C536230824D422DD95C864DC362E27DE2A51C4E464F337AE4149FD1115B95B2B3A4941B8DDBCBF5CA5279E1A1B2BCBAB65617AA8D6DBFA954B77B6EAB7F2CD2F8A752561E39E5B0A30727F58ACBE124AD961D1E89C574185F767FCF0531324E424A2F805C650DAEE722E15C3AF1CCC4A48D6CD371848B36E994521D1B16352937B0E8AF02858D957525F41B00104901C4383E5D79AA162E182C18AE6D51AE332B046370615E0026C9B720468E03E1FC603F072494A15DFC9B3057609B8A0F17F814E988270239D316100F13C9991C60714CABA224E2DFE80C302D7E29D11D5134E0EB89448D1DF66FB24347E4990648E28F95D3505F42F88D427F060D099786FA9801DE9508B35862960BCCC4540CB682DC75F77EBD7A7CA7F86735718E16479043320104531976415E72E4D26822FE1F824A4095872A3FEBEC5F7BF6F15650CF83F7937B473F4A693FE3211E1F46388B8261133E7A22F1AE94500F38371461143FD1A8053B0484B8FDC9FE88B725C4AA334B869CAA67ECC3152F921ADAB6231DC724958209E7446E83103CC19F93584DE9E61FF81F40B0DFE8BC96DD3E71898C7971B86932F5FD03C9CB09DB7E080000"
)

function Convert-HexStringToByteArray {
    ################################################################
    #.Synopsis
    # Convert a string of hex data into a System.Byte[] array. An
    # array is always returned, even if it contains only one byte.
    #.Parameter String
    # A string containing hex data in any of a variety of formats,
    # including strings like the following, with or without extra
    # tabs, spaces, quotes or other non-hex characters:
    # 0x41,0x42,0x43,0x44
    # \x41\x42\x43\x44
    # 41-42-43-44
    # 41424344
    # The string can be piped into the function too.
    ################################################################
    [CmdletBinding()]
    Param ( [Parameter(Mandatory = $True, ValueFromPipeline = $True)] [String] $String )
 
    #Clean out whitespaces and any other non-hex crud.
    $String = $String.ToLower() -replace '[^a-f0-9\\,x\-\:]', "
 
#Try to put into canonical colon-delimited format.
$String = $String -replace '0x|\x|\-|,',':'
 
#Remove beginning and ending colons, and other detritus.
$String = $String -replace '^:+|:+$|x|\',"
 
    #Maybe there's nothing left over to convert...
    if ($String.Length -eq 0) { , @() ; return }
 
    #Split string with or without colon delimiters.
    if ($String.Length -eq 1)
    { , @([System.Convert]::ToByte($String, 16)) }
    elseif (($String.Length % 2 -eq 0) -and ($String.IndexOf(":") -eq -1))
    { , @($String -split '([a-f0-9]{2})' | foreach-object { if ($_) { [System.Convert]::ToByte($_, 16) } }) }
    elseif ($String.IndexOf(":") -ne -1)
    { , @($String -split ':+' | foreach-object { [System.Convert]::ToByte($_, 16) }) }
    else
    { , @() }
    #The strange ",@(...)" syntax is needed to force the output into an
    #array even if there is only one element in the output (or none).
}
Add-Type -Path ".\Gd.Bos.Shared.Common.dll"


$buff = Convert-HexStringToByteArray $hex


$steam = [Gd.Bos.Shared.Common.Messaging.Compression.ObjectCompression]::DecompressObject($buff)

$version = 11;

$steam.Seek(0,0)
$ent = [Gd.Bos.Shared.Common.Messaging.ProcessorEventSchema.Contract.IProcessorEvent][Gd.Bos.Shared.Common.Messaging.Serialization.FastDeserializer]::Deserialize($steam,$version)

$entBuff = [byte[]]$ent.MessageBytes

$msgMs = New-Object -TypeName System.IO.MemoryStream
$msgMs.Write($entBuff)
$msgMs.Seek(0,0)

$msg = [Gd.Bos.Shared.Common.Messaging.Serialization.FastDeserializer]::Deserialize($msgMs,$version)

$xml = [Gd.Bos.Shared.Common.Messaging.IpsMessageSchema.Serializer]::Serialize($msg)

Write-Host $xml