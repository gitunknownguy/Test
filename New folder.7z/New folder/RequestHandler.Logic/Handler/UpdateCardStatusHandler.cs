﻿using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class UpdateCardStatusHandler : CommandHandlerBase<UpdateCardStatusRequest, UpdateCardStatusResponse>
    {
        private readonly IPaymentInstrumentService _paymentInstrumentService;

        public UpdateCardStatusHandler(IPaymentInstrumentService paymentInstrumentService)
        {
            _paymentInstrumentService = paymentInstrumentService;
        }

        public override void SetDomainContext(UpdateCardStatusRequest request)
        {
        }

        public override Task<UpdateCardStatusResponse> VerifyIdentifiers(UpdateCardStatusRequest request)
        {
            return Task.FromResult(new UpdateCardStatusResponse { ResponseHeader = new ResponseHeader() });
        }

        public override Task<UpdateCardStatusResponse> Handle(UpdateCardStatusRequest request)
        {
            try
            {
                if (request.RequestHeader.RequestId == Guid.Empty)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId,
                        $"{nameof(request)}.RequestHeader.RequestId must be specified");
                }

                if (string.IsNullOrWhiteSpace(request.PaymentIdentifierProxy) ||
                    string.IsNullOrWhiteSpace(request.CardStatus) ||
                    string.IsNullOrWhiteSpace(request.CardStatusReason) ||
                    string.IsNullOrWhiteSpace(request.Source))
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_CardStatusUpdate_Parameters,
                        "A required UpdateCardStatus parameter was missing.");
                }

                _paymentInstrumentService.UpdateCardStatus(request);

                return Task.FromResult(new UpdateCardStatusResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "success"
                    }
                });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpdateCardStatusResponse>(e, request));
            }
        }
    }
}
