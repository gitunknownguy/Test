﻿using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.PInstantIssue;
using System;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.Common.Enum;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.Shared.Common.Core.Data;
using Microsoft.Data.SqlClient;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using PaymentInstrumentAttribute = Gd.Bos.Shared.Common.Core.Common.Enum.PaymentInstrumentAttributes;

namespace RequestHandler.Logic.Handler
{
    public class InstantIssueUpdateCardStatusHandler : CommandHandlerBase<InstantIssueUpdateCardRequest, InstantIssueUpdateCardResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IPaymentInstrumentService _paymentInstrumentService;
        private readonly IAccountService _accountService;
        private readonly IDataAccess _dataAccess;
        private readonly IPaymentIdentifierRepository _paymentIdentifierRepository;
        public InstantIssueUpdateCardStatusHandler(
            IValidateIdentifier validateIdentifier,
            IPaymentInstrumentService paymentInstrumentService,
            IAccountService accountService,
            IPaymentIdentifierRepository paymentIdentifierRepository,
            IDataAccess dataAccess)
        {
            _dataAccess = dataAccess;
            _validateIdentifier = validateIdentifier;
            _paymentInstrumentService = paymentInstrumentService;
            _accountService = accountService;
            _paymentIdentifierRepository = paymentIdentifierRepository;
        }

        public override void SetDomainContext(InstantIssueUpdateCardRequest request)
        {
            // Check if the request has AccountNumber or accountIdentifier
            if (!Guid.TryParse(request.AccountIdentifier, out var newGuid))
            {
                SqlParameter[] parameters = new[]
                {
                        new SqlParameter() {ParameterName = "AccountReferenceNumber", Value = request.AccountIdentifier},
                };

                using var reader = _dataAccess.ExecuteReader("[CRM].[GetAccountInfoByAccountReferenceNumber]",
                    _dataAccess.CreateConnection(), parameters);
                if (reader.Read())
                {

                    request.AccountIdentifier = reader.GetGuid(reader.GetOrdinal("AccountIdentifier")).ToString();
                }
                else
                {
                    throw new ValidationException(10, 0, "Account Not Found.");
                }
            }

            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            DomainContext.Current.PaymentInstrumentIdentifier = request.PaymentInstrumentIdentifier;
        }

        public override Task<InstantIssueUpdateCardResponse> VerifyIdentifiers(InstantIssueUpdateCardRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidatePaymentInstrumentIdentifier(DomainContext.Current.AccountIdentifier, DomainContext.Current.PaymentInstrumentIdentifier);
                return Task.FromResult(new InstantIssueUpdateCardResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<InstantIssueUpdateCardResponse>(e, request));
            }
        }

        public override Task<InstantIssueUpdateCardResponse> Handle(InstantIssueUpdateCardRequest request)
        {
            try
            {
                var message = "Success";
              
                InstantIssueUpdateCardResponse updatePaymentInstrumentsResponse = null;

                // Get Account to check the status
                var accountResponse = _accountService.GetAccount(request.AccountIdentifier);
                if (accountResponse.AccountStatus.Equals(AccountStatus.Normal))
                {
                    // Get paymentIdentifier
                    var paymentIdentifier = _paymentIdentifierRepository.GetPaymentIdentifierByPaymentInstrumentIdentifier(request.PaymentInstrumentIdentifier, out _);
                    if (paymentIdentifier != null)
                    {
                        // Update or create PrintStatus
                        //_paymentIdentifierRepository.InsertPaymentInstrumentDetail(paymentIdentifier.PaymentInstrument.PaymentIntrumentKey, (short)PaymentInstrumentAttribute.Printed, isPrinted);

                        _paymentIdentifierRepository.InsPaymentInstrumentDetailByBatch(paymentIdentifier.PaymentInstrument.PaymentIntrumentKey, request.IssuedStatus, request.IssuedDateTime, request.LocationId, request.PrinterId, request.UserId);

                        updatePaymentInstrumentsResponse = new InstantIssueUpdateCardResponse
                        {
                            ResponseHeader = new ResponseHeader
                            {
                                ResponseId = request.RequestHeader.RequestId,
                                StatusCode = 0,
                                SubStatusCode = 0,
                                Message = message
                            }
                        };
                    }
                    else
                    {
                        message = "The user doesn't have any payment Identifier";

                        updatePaymentInstrumentsResponse = new InstantIssueUpdateCardResponse
                        {
                            ResponseHeader = new ResponseHeader
                            {
                                ResponseId = request.RequestHeader.RequestId,
                                StatusCode = 205,
                                SubStatusCode = 1001,
                                Message = message
                            },
                        };
                    }
                }
                else
                {
                    message = "Account status is not healthy";

                    updatePaymentInstrumentsResponse = new InstantIssueUpdateCardResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 205,
                            SubStatusCode = 1002,
                            Message = message
                        },
                    };
                }

                return Task.FromResult(updatePaymentInstrumentsResponse);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<InstantIssueUpdateCardResponse>(e, request));
            }
        }
    }
}
