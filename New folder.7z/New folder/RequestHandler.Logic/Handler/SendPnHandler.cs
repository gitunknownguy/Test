﻿using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Services.BillPay;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Cassandra.Contract;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Utils;
using NLog;
using RequestHandler.Core.Domain.Model.PublishNotification;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Cassandra;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transactions;
using RequestHandler.Core.Utils;
using AccountHolder = RequestHandler.Core.Domain.Model.PublishNotification.AccountHolder;
using BillPayTransfer = RequestHandler.Core.Domain.Model.PublishNotification.BillPayTransfer;
using PaymentInstrument = RequestHandler.Core.Domain.Model.PublishNotification.PaymentInstrument;
using Purse = RequestHandler.Core.Domain.Model.PublishNotification.Purse;
using Transaction = RequestHandler.Core.Domain.Model.PublishNotification.Transaction;
using User = RequestHandler.Core.Domain.Model.PublishNotification.User;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers.Events;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Cosmos.Contract;
using System.Runtime.InteropServices;

namespace RequestHandler.Logic.Handler
{
    [ExcludeFromCodeCoverage(Justification = "Due to time constraint on migration we need to revisit")]
    public class SendPnHandler : CommandHandlerBase<SendPnRequest, SendPnResponse>
    {
        private readonly INotificationService _notificationPublisher;

        private readonly IAccountRepository _accountRepository;

        private readonly IUserRepository _userRepository;

        private readonly ITransferRepository _transferRepository;

        private readonly IAccountBalanceRepository _accountBalanceRepository;

        private readonly ITransactionsRepository _transactionsRepository;

        private readonly IPaymentInstrumentService _paymentInstrumentService;

        private readonly IBillPayService _billPayService;

        private readonly IEnrollmentDataAccess _enrollmentDataAccess;

        private readonly ICassandraAccess _cassandraAccess;

        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();

        private readonly ICosmosAccess _cosmosAccess;

        private readonly IRequestHandlerSettings _configurationProvider;

        public SendPnHandler(INotificationService notificationPublisher,
            IAccountRepository accountRepository,
            IUserRepository userRepository,
            ITransferRepository transferRepository,
            IPaymentInstrumentService paymentInstrumentService,
            IBillPayService billPayService,
            ITransactionsRepository transactionsRepository,
            IAccountBalanceRepository accountBalanceRepository,
            IEnrollmentDataAccess enrollmentDataAccess,
            ICassandraAccess cassandraAccess, 
            ICosmosAccess cosmosAccess, 
            IRequestHandlerSettings configurationProvider)
        {
            _notificationPublisher = notificationPublisher;
            _accountRepository = accountRepository;
            _userRepository = userRepository;
            _transferRepository = transferRepository;
            _paymentInstrumentService = paymentInstrumentService;
            _billPayService = billPayService;
            _transactionsRepository = transactionsRepository;
            _accountBalanceRepository = accountBalanceRepository;
            _enrollmentDataAccess = enrollmentDataAccess;
            _cassandraAccess = cassandraAccess;
            _cosmosAccess = cosmosAccess;
            _configurationProvider = configurationProvider;
        }

        public override void SetDomainContext(SendPnRequest request)
        {
        }

        public override Task<SendPnResponse> VerifyIdentifiers(SendPnRequest request)
        {
            return Task.FromResult(new SendPnResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<SendPnResponse> Handle(SendPnRequest request)
        {
            var response = new SendPnResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success",
                    Details = "Success"
                }
            };

            ValidateRequest(request);

            return Task.FromResult(response);
        }

        private void ValidateRequest(SendPnRequest request)
        {
            switch (request.EventType)
            {
                case EventType.AccountUpdated:
                case EventType.FraudAlert:
                    if (request.EventId.HasValue)
                    {
                        Task.Run(() => GetDataFromCassandra(request));
                    }
                    else
                    {
                        if (request.Account == null)
                            throw new ValidationException(400, 0, $"request malformed for event type: {request.EventType}");

                        var account = _accountRepository.GetByAccountIdentifier(request.Account.AccountIdentifier);

                        if (account == null)
                            throw new ValidationException(400, 0, $"Account not for : {request.Account.AccountIdentifier}");

                        var accountEvent = new Core.Domain.Model.PublishNotification.Account
                        {
                            AccountIdentifier = account.AccountIdentifier.ToString(),
                            Status = account.AccountStatus.ToString().FirstCharToLowerCase(),
                            AccountStatusChangedDateTime = account.AccountStatusChangedDateTime.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
                            StatusReasons = account.AccountStatusReasons.Select(reason => reason.ToString().FirstCharToLowerCase()).ToList(),
                            ddInfo = new DDInfo()
                            {
                                AccountNumber = account.AccountNumber,
                                RoutingNumber = account.RoutingNumber
                            },
                            AccountHolders = new List<AccountHolder>()
                        };

                        var getEnrollmentResponse = _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(
                            request.Account.AccountIdentifier,
                            request.ProgramCode,
                            false);

                        if (getEnrollmentResponse.Account == null)
                            throw new ValidationException(400, 0, $"Enrollment not found for Account Identifier:{request.Account.AccountIdentifier}, Request id: {request.RequestHeader.RequestId}");

                        accountEvent.AccountCycleDay = getEnrollmentResponse.Account.AccountCycleDay;

                        var accountHolder = new AccountHolder();

                        foreach (var holder in account.AccountHolders)
                        {
                            var userRepo = _userRepository.GetUser(request.Account.AccountIdentifier, account.UserIdentifier);
                            var firstUser = userRepo.First();
                            var userIdentity = firstUser.Identities.First();

                            accountHolder.User = new User
                            {
                                FirstName = firstUser.FirstName,
                                LastName = firstUser.LastName,
                                DobStatus = firstUser.IsDobVerified.HasValue ? "verified" : "notVerified",
                                Last4Identity = userIdentity.Last4Identity,
                                IdentityType = userIdentity.IdentityType.ToString().FirstCharToLowerCase(),
                                UserIdentifier = firstUser.UserIdentifier.ToString().FirstCharToLowerCase(),
                                IsPrimaryAccountHolder = firstUser.IsPrimaryAccountHolder,
                                Status = UserStatus.Active
                            };

                            var accountHolders = getEnrollmentResponse.Account.AccountHolders.FirstOrDefault(
                                h => string.Equals(h.AccountHolderIdentifier, holder.AccountHolderIdentifier.ToString(), StringComparison.CurrentCultureIgnoreCase));

                            if (accountHolders != null)
                            {
                                var kycData = accountHolders.User?.KycStateData;
                                accountHolder.User.KycStateData = new Core.Domain.Model.PublishNotification.KycStateData
                                {
                                    OfacStatus = kycData?.KycStatus.FirstCharToLowerCase(),
                                    KycStatus = kycData?.KycStatus.FirstCharToLowerCase(),
                                    KycPendingGate = kycData?.PendingKycGate.FirstCharToLowerCase()
                                };
                            }

                            var paymentInstruments = _paymentInstrumentService.GetPaymentInstruments(
                                request.Account.AccountIdentifier, account.UserIdentifier.ToString());

                            if (paymentInstruments.Any())
                            {
                                var instrumentsList = new List<PaymentInstrument>();

                                foreach (var instrument in paymentInstruments)
                                {
                                    var paymentInstrument = new PaymentInstrument
                                    {
                                        PaymentInstrumentIdentifier = instrument.PaymentInstrument.PaymentInstrumentIdentifier,
                                        PaymentIdentifier = instrument.PaymentInstrument.PaymentIdentifier,
                                        PaymentInstrumentType = instrument.PaymentInstrument.PaymentInstrumentType.ToString().FirstCharToLowerCase(),
                                        IsPinSet = instrument.PaymentInstrument.IsPinSet,
                                        Last4Pan = instrument.PaymentInstrument.Last4Pan,
                                        ActivatedDateTime = instrument.PaymentInstrument.ActivatedDateTime?.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.FFFZ"),
                                        IssuedDateTime = instrument.PaymentInstrument.IssuedDateTime?.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.FFFZ")
                                    };

                                    var paymentInstrumentStatus = StatusMapper.GetPaymentInstrumentStatus(instrument.PaymentIdentifierStatus, instrument.PaymentInstrumentStatus);
                                    paymentInstrument.Status = paymentInstrumentStatus.ToString().FirstCharToLowerCase();

                                    var paymentInstrumentStatusReasons = StatusMapper.GetPaymentInstrumentStatusReasons(
                                        instrument.PaymentIdentifierStatus,
                                        instrument.PaymentInstrumentStatus, instrument.PaymentInstrumentStatusReason,
                                        instrument.PaymentIdentifierStatusReason);

                                    if (paymentInstrumentStatusReasons != null && paymentInstrumentStatusReasons.Any())
                                    {
                                        paymentInstrument.PaymentInstrumentStatusReasons = new List<string>();
                                        foreach (var reason in paymentInstrumentStatusReasons)
                                        {
                                            paymentInstrument.PaymentInstrumentStatusReasons.Add(reason.ToString().FirstCharToLowerCase());
                                        }
                                    }
                                    else
                                    {
                                        paymentInstrument.PaymentInstrumentStatusReasons = null;
                                    }

                                    instrumentsList.Add(paymentInstrument);
                                }

                                accountHolder.PaymentInstruments = instrumentsList;
                            }

                            accountEvent.AccountHolders.Add(accountHolder);
                        }

                        _notificationPublisher.PublishNotificationGeneric(EventType.AccountUpdated, request.ProgramCode, request.Account.AccountIdentifier, accountEvent);
                    }

                    break;

                case EventType.BillPayTransfer:
                    if (request.EventId.HasValue)
                    {
                        Task.Run(() => GetDataFromCassandra(request));
                    }
                    else
                    {
                        if (request.BillPayTransfer == null)
                            throw new ValidationException(400, 0, $"request malformed for event type: {request.EventType}");

                        if (request.BillPayTransfer.PaymentIdentifier == null ||
                            request.BillPayTransfer.TransferIdentifier == null)
                            throw new ValidationException(400, 0, $"Payment identifier and transfer identifier are required.");

                        var getPaymentResponse = _billPayService.GetPayment(new GssGetPaymentRequest
                        {
                            AccountIdentifier = request.Account.AccountIdentifier,
                            PartnerId = request.ProgramCode,
                            PaymentIdentifier = request.BillPayTransfer.PaymentIdentifier
                        });

                        if (getPaymentResponse == null)
                            throw new ValidationException(400, 0, $"Bill pay service did not return response for Account id: {request.Account.AccountIdentifier}, Payment id: {request.BillPayTransfer.PaymentIdentifier},Request id: {request.RequestHeader.RequestId}");

                        var transfer = _transferRepository.GetByTransferIdentifier(
                            TransferIdentifier.FromString(request.BillPayTransfer.TransferIdentifier), false,
                            request.ProgramCode);

                        if (transfer == null)
                            throw new ValidationException(400, 0, $"Bill Pay Transfer not found for the TransferIdentifier: {request.BillPayTransfer.TransferIdentifier}, Request id: {request.RequestHeader.RequestId}");

                        var billPayEvent = new BillPayTransferEvent
                        {
                            AccountIdentifier = request.Account.AccountIdentifier
                        };

                        var billPayTransfer = new BillPayTransfer
                        {
                            PaymentIdentifier = request.BillPayTransfer.PaymentIdentifier,
                            TransferIdentifier = request.BillPayTransfer.TransferIdentifier,
                            TransferStatus = transfer.TransferStatus.ToString().FirstCharToLowerCase(),
                            Amount = transfer.Amount,
                            PayeeIdentifier = getPaymentResponse.PayeeIdentifier,
                            PaymentStatus = getPaymentResponse.PaymentStatus,
                            PaymentDate = getPaymentResponse.PaymentDate,
                            DeliveryDate = getPaymentResponse.DeliveryDate,
                            PaymentMemo = getPaymentResponse.PaymentMemo,
                            Note = getPaymentResponse.Note,
                            ConfirmationNumber = getPaymentResponse.ConfirmationNumber,
                            PayeeName = getPaymentResponse.PayeeName,
                            FrequencyType = getPaymentResponse.FrequencyType.ToString().FirstCharToLowerCase()
                        };

                        billPayEvent.BillPayTransfer = billPayTransfer;

                        _notificationPublisher.PublishNotificationGeneric(EventType.BillPayTransfer, request.ProgramCode,
                            request.Account.AccountIdentifier, billPayEvent);
                    }

                    break;

                case EventType.Transaction:
                    if (request.EventId.HasValue)
                    {
                        Task.Run(() => GetDataFromCassandra(request));
                    }
                    else
                    {
                        if (request.Transactions == null || request.Account == null || request.Transactions.Count < 1)
                            throw new ValidationException(400, 0, $"request malformed for event type: {request.EventType}, Request id: {request.RequestHeader.RequestId}");

                        var account = _accountRepository.GetByAccountIdentifier(request.Account.AccountIdentifier);

                        var accountInfo = _accountRepository.GetAccountStatusAndBalancesByAccountIdentifier(AccountIdentifier.FromString(request.Account.AccountIdentifier));
                        var balance = accountInfo.Purses.FirstOrDefault();
                        if (balance == null)
                            throw new ValidationException(400, 0, $"Balance not found for account: {request.Account.AccountIdentifier}, Request id: {request.RequestHeader.RequestId}");
                        var accountHolder = accountInfo.AccountHolders.FirstOrDefault();
                        if (accountHolder == null)
                            throw new ValidationException(400, 0, $"Account holder not found for account: {request.Account.AccountIdentifier}, Request id: {request.RequestHeader.RequestId}");

                        var transactionEvent = new TransactionEvent
                        {
                            Account = new TransactionAccount
                            {
                                Identifier = account.AccountIdentifier.ToString(),
                                State = accountInfo.AccountStatus.ToString().FirstCharToLowerCase(),
                                ConsumerProfileIdentifier = accountHolder.UserIdentifier.ToString(),
                                ConsumerProfileKey = accountHolder.ConsumerProfileKey,
                                Balance = new Balance
                                {
                                    AvailableBalance = balance.AvailableBalance,
                                    CurrentBalance = balance.CurrentBalance,
                                    AvailableBalanceAsOfDate = balance.AvailableBalanceAsOfDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
                                    CurrentBalanceAsOfDate = balance.CurrentBalanceAsOfDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
                                }
                            },
                            Transactions = new List<Transaction>()
                        };


                        foreach (var transaction in request.Transactions)
                        {
                            var fullTransaction = _transactionsRepository.GetFullTransactionByTransactionIdentifier(Guid.Parse(transaction.TransactionIdentifier));

                            var postTransactions = fullTransaction["PostTransaction"];
                            var postInternalTransactions = fullTransaction["PostInternalTransaction"];

                            var newTransaction = new Transaction();

                            if (postTransactions.Count == 0 && postInternalTransactions.Count == 0)
                            {
                                // if post transaction and post internal transaction are not present, then it must be Authorize Transaction
                                newTransaction = _transactionsRepository.GetAuthorizeTransactionByTransactionIdentifier(
                                    account.AccountIdentifier, Guid.Parse(transaction.TransactionIdentifier));

                                if (newTransaction.TransactionIdentifier == null)
                                {
                                    throw new ValidationException(400, 0, $"Transaction not found for Account: {request.Account.AccountIdentifier}, Transaction: {transaction.TransactionIdentifier}, Request id: {request.RequestHeader.RequestId}");
                                }

                                if (!newTransaction.Fee.Any())
                                {
                                    newTransaction.Fee = null;
                                }

                                newTransaction.ProgramCode = accountInfo.ProgramCode;
                                newTransaction.UserIdentifier = accountHolder.UserIdentifier.ToString();
                            }
                            else
                            {
                                if (postTransactions.Any())
                                {
                                    newTransaction = postTransactions.First();
                                    newTransaction.UserIdentifier = accountHolder.UserIdentifier.ToString();
                                }

                                if (postInternalTransactions.Any())
                                {
                                    newTransaction = postInternalTransactions.First();
                                }
                            }

                            transactionEvent.Transactions.Add(newTransaction);

                            _notificationPublisher.PublishNotificationGeneric(EventType.Transaction, request.ProgramCode,
                                request.Account.AccountIdentifier, transactionEvent);

                            transactionEvent.Transactions = new List<Transaction>();
                        }
                    }
                    break;

                case EventType.UserUpdate:
                    if (request.UserUpdate == null)
                        throw new ValidationException(400, 0, $"request malformed for event type: {request.EventType}");
                    break;

                case EventType.StatementReady:
                    if (request.Statement == null)
                        throw new ValidationException(400, 0, $"request malformed for event type: {request.EventType}");
                    break;

                case EventType.MailTracking:
                    if (request.DeliveryStatus == null)
                        throw new ValidationException(400, 0, $"request malformed for event type: {request.EventType}");
                    break;

                case EventType.CardUpdate:
                    if (request.EventId.HasValue)
                    {
                        Task.Run(() => GetDataFromCassandra(request));
                    }
                    else
                    {
                        if (request.PaymentInstrument == null)
                            throw new ValidationException(400, 0, $"request malformed for event type: {request.EventType}");

                        var account = _accountRepository.GetByAccountIdentifier(request.Account.AccountIdentifier);

                        var paymentInstruments = _paymentInstrumentService.GetPaymentInstruments(
                            request.Account.AccountIdentifier,
                            account.UserIdentifier.ToString());

                        var paymentInstrument = _paymentInstrumentService.GetPaymentIdentifier(
                            request.Account.AccountIdentifier,
                            request.PaymentInstrument.PaymentInstrumentIdentifier);

                        var instrument = paymentInstruments.FirstOrDefault(p =>
                            string.Equals(p.PaymentInstrument.PaymentInstrumentIdentifier, request.PaymentInstrument.PaymentInstrumentIdentifier, StringComparison.CurrentCultureIgnoreCase));

                        if (instrument == null)
                            throw new ValidationException(400, 0, $"Payment Instrument not found for : {request.PaymentInstrument.PaymentInstrumentIdentifier}");

                        var instrumentInfo = new CardUpdatePaymentInstrument
                        {
                            AccountIdentifier = request.Account.AccountIdentifier,
                            PaymentInstrumentIdentifier = instrument.PaymentInstrument.PaymentInstrumentIdentifier,
                            PaymentIdentifier = instrument.PaymentInstrument.PaymentIdentifier,
                            PaymentInstrumentType = instrument.PaymentInstrument.PaymentInstrumentType.ToString().FirstCharToLowerCase(),
                            IsPinSet = instrument.PaymentInstrument.IsPinSet,
                            Last4Pan = instrument.PaymentInstrument.Last4Pan,
                            ActivatedDateTime = instrument.PaymentInstrument.ActivatedDateTime?.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ"),
                            IssuedDateTime = instrument.PaymentInstrument.IssuedDateTime?.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ"),
                            UserIdentifier = instrument.PaymentInstrument.UserIdentifier,
                            EmbossedName = paymentInstrument.PaymentInstrument.EmbossedName
                        };

                        var paymentInstrumentStatus = StatusMapper.GetPaymentInstrumentStatus(instrument.PaymentIdentifierStatus, instrument.PaymentInstrumentStatus);
                        instrumentInfo.Status = paymentInstrumentStatus.ToString().FirstCharToLowerCase();

                        var paymentInstrumentStatusReasons = StatusMapper.GetPaymentInstrumentStatusReasons(
                            instrument.PaymentIdentifierStatus,
                            instrument.PaymentInstrumentStatus, instrument.PaymentInstrumentStatusReason,
                            instrument.PaymentIdentifierStatusReason);

                        if (paymentInstrumentStatusReasons != null && paymentInstrumentStatusReasons.Any())
                        {
                            instrumentInfo.PaymentInstrumentStatusReasons = new List<string>();
                            foreach (var reason in paymentInstrumentStatusReasons)
                            {
                                instrumentInfo.PaymentInstrumentStatusReasons.Add(reason.ToString().FirstCharToLowerCase());
                            }
                        }
                        else
                        {
                            instrumentInfo.PaymentInstrumentStatusReasons = null;
                        }

                        _notificationPublisher.PublishNotificationGeneric(EventType.CardUpdate, request.ProgramCode, request.Account.AccountIdentifier, instrumentInfo);
                    }

                    break;

                case EventType.Mfa:
                    if (request.MfaCode < 1 || request.Account == null || request.UserUpdate == null)
                        throw new ValidationException(400, 0, $"request malformed for event type: {request.EventType}");
                    break;

                case EventType.SinglePhaseTransfer:

                    if (request.EventId.HasValue)
                    {
                        Task.Run(() => GetDataFromCassandra(request));
                    }
                    else
                    {
                        ISinglePhaseTransferPNMessage message = request as ISinglePhaseTransferPNMessage;

                        if (message == null || message.SinglePhaseTransfers == null || !message.SinglePhaseTransfers.Any())
                            throw new ValidationException(400, 0, $"request malformed for event type: {request.EventType}, need at least 1 SinglePhaseTransfer, Request id: {request.RequestHeader.RequestId}, no tranfers found");

                        if (message.AccountIdentifier == null || string.IsNullOrEmpty(message.AccountIdentifier))
                            throw new ValidationException(400, 0, $"Tranfers need a valid AccountIdentifier Request id: {request.RequestHeader.RequestId}");

                        _notificationPublisher.PublishNotificationGeneric(EventType.SinglePhaseTransfer, request.ProgramCode, Guid.NewGuid().ToString(), message.SinglePhaseTransfers);
                    }
                    break;

                case EventType.OCTA2AOutTransfer:

                    if (request.GFTTransfer == null)
                    {
                        throw new ValidationException(400, 0, $"request malformed for event type: {request.EventType}, gftTransfer object cannot be null, Request id: {request.RequestHeader.RequestId}, no tranfers found");
                    }
                    if (request.AccountIdentifier == null || string.IsNullOrEmpty(request.AccountIdentifier))
                    {
                        throw new ValidationException(400, 0, $"Tranfers need a valid AccountIdentifier Request id: {request.RequestHeader.RequestId}");
                    }

                    if (request.Saf != null && request.Saf.InStoreAndForwardQueue == true)
                    {
                        //include saf object for publishing
                        _notificationPublisher.PublishNotification(request.ProgramCode, request.AccountIdentifier, request.RequestHeader.RequestId.ToString(), request.Saf, request.GFTTransfer, EventType.OCTA2AOutTransfer);
                    }
                    else
                    {
                        _notificationPublisher.PublishNotificationGeneric(EventType.OCTA2AOutTransfer, request.ProgramCode, request.AccountIdentifier, request.GFTTransfer);
                    }
                    break;

                case EventType.DirectDepositSwitch:
                    if (request.DirectDepositSwitch == null)
                    {
                        throw new ValidationException(400, 0, $"request malformed for event type: {request.EventType}, DirectDepositSwitch object cannot be null, Request id: {request.RequestHeader.RequestId}");
                    }
                    if (request.AccountIdentifier == null || string.IsNullOrEmpty(request.AccountIdentifier))
                    {
                        throw new ValidationException(400, 0, $"DirectDepositSwitch need a valid AccountIdentifier Request id: {request.RequestHeader.RequestId}");
                    }
                    request.DirectDepositSwitch.AccountIdentifier = request.AccountIdentifier;
                    _notificationPublisher.PublishNotificationGeneric(EventType.DirectDepositSwitch, request.ProgramCode, request.AccountIdentifier, request.DirectDepositSwitch);
                    break;
                case EventType.PaperCheck:
                    if (request.PaperCheckPNMessage == null)
                    {
                        throw new ValidationException(400, 0, $"request malformed for event type: {request.EventType}, PaperCheckPNMessage object cannot be null, Request id: {request.RequestHeader.RequestId}");
                    }
                    if (request.AccountIdentifier == null || !Guid.TryParse(request.AccountIdentifier, out Guid accountIdentifier))
                    {
                        throw new ValidationException(400, 0, $"PaperCheck need a valid AccountIdentifier Request id: {request.RequestHeader.RequestId}");
                    }
                    PaperCheckEvent paperCheckEvent = new PaperCheckEvent()
                    {
                        AccountIdentifier = request.AccountIdentifier.ToLower(),
                        TransactionAmount = request.PaperCheckPNMessage.TransactionAmount,
                        TransactionDescription = request.PaperCheckPNMessage.TransactionDescription,
                        CheckNumber = request.PaperCheckPNMessage.CheckNumber,
                        AssociatedTransactionIdentifier = request.PaperCheckPNMessage.AssociatedTransactionIdentifier,
                        EventDateTime = DateTime.Now,
                        StatusReason = request.PaperCheckPNMessage.StatusReason,
                        Status = request.PaperCheckPNMessage.Status,
                        TransactionType = "paperCheck"
                    };
                    _notificationPublisher.PublishNotification(DomainContext.Current.ProgramCode.ToString(), paperCheckEvent, EventType.PaperCheck);
                    break;
                case EventType.AchTransfer:
                    if (request.Transfer == null)
                    {
                        throw new ValidationException(400, 0, $"request malformed for event type: {request.EventType}, Transfer object cannot be null, Request id: {request.RequestHeader.RequestId}");
                    }

                    _notificationPublisher.PublishNotification(DomainContext.Current.ProgramCode.ToString(), request.Transfer, EventType.AchTransfer, request.Saf);
                    break;
                case EventType.AFTTransfer:

                    CheckAFTTransferRequest(request);

                    _notificationPublisher.PublishNotification(DomainContext.Current.ProgramCode.ToString(), request.RequestHeader.RequestId.ToString(), request.AFTTransfer, EventType.AFTTransfer);
                    break;
                case EventType.AdjustmentFinalStatus:

                    CheckAdjustmentPNRequest(request);
                    var adjustmentCallBackEvent = new AdjustmentCallBackEvent
                    {
                        AdjustmentIdentifier = request.Adjustment.AdjustmentIdentifier,
                        AccountIdentifier = request.Adjustment.AccountIdentifier,
                        EventDateTime = request.Adjustment.EventDateTime,
                        Amount = request.Adjustment.Amount,
                        Currency = request.Adjustment.Currency,
                        AdjustmentType = request.Adjustment.AdjustmentType,
                        AdjustmentDescription = request.Adjustment.AdjustmentDescription,
                        Fee = request.Adjustment.Fee,
                        FinalStatus = (FinalStatus)request.Adjustment.FinalStatus
                    };
                    _notificationPublisher.PublishNotification(request.ProgramCode, adjustmentCallBackEvent, EventType.AdjustmentFinalStatus);

                    break;
                
                case EventType.p2pTransfer:
                    if (!string.Equals(request.ProgramCode, "sec", StringComparison.OrdinalIgnoreCase))
                        throw new ValidationException(400, 0, $"invalid request for event type: {request.EventType}, ProgramCode {request.ProgramCode} is not registered, Request id: {request.RequestHeader.RequestId}");
                    if (request.P2P is null)
                        throw new ValidationException(400, 0, $"request malformed for event type: {request.EventType}, P2P object cannot be null, Request id: {request.RequestHeader.RequestId}");
                    
                    if (!Guid.TryParse(request.AccountIdentifier, out _))
                        throw new ValidationException(400, 0, $"P2P needs a valid GUID AccountIdentifier, Request id: {request.RequestHeader.RequestId}");
                    if (request.P2P.Transfer is null)
                        throw new ValidationException(400, 0, $"P2P needs a valid Transfer, Request id: {request.RequestHeader.RequestId}");
                    if (request.P2P.Source is null)
                        throw new ValidationException(400, 0, $"P2P needs a valid Source, Request id: {request.RequestHeader.RequestId}");
                    if (request.P2P.Target is null)
                        throw new ValidationException(400, 0, $"P2P needs a valid Target, Request id: {request.RequestHeader.RequestId}");
                    if (!Guid.TryParse(request.P2P.Transfer.TransferIdentifier, out _))
                        throw new ValidationException(400, 0, $"P2P needs a valid GUID TransferIdentifier, Request id: {request.RequestHeader.RequestId}");
                    if (string.IsNullOrEmpty(request.P2P.Transfer.TransferStatus))
                        throw new ValidationException(400, 0, $"P2P needs a valid TransferStatus, Request id: {request.RequestHeader.RequestId}");
                    if (!Guid.TryParse(request.P2P.Source.Identifier, out _))
                        throw new ValidationException(400, 0, $"P2P needs a valid GUID Source Identifier, Request id: {request.RequestHeader.RequestId}");
                    if (!Guid.TryParse(request.P2P.Source.LinkId, out _))
                        throw new ValidationException(400, 0, $"P2P needs a valid GUID Source LinkId, Request id: {request.RequestHeader.RequestId}");
                    if (!Guid.TryParse(request.P2P.Target.Identifier, out _))
                        throw new ValidationException(400, 0, $"P2P needs a valid GUID Target Identifier, Request id: {request.RequestHeader.RequestId}");
                    if (!Guid.TryParse(request.P2P.Target.LinkId, out _))
                        throw new ValidationException(400, 0, $"P2P needs a valid GUID Target LinkId, Request id: {request.RequestHeader.RequestId}");
                    
                    _notificationPublisher.PublishNotificationGeneric(EventType.p2p, request.ProgramCode, request.AccountIdentifier, request.P2P);
                    
                    break;

                case EventType.IdvDocumentUpload:
                    if (request.IdvDocumentUploadPnMessage == null)
                    {
                        throw new ValidationException(400, 0, $"request malformed for event type: {request.EventType}, IdvDocumentUploadPnMessage cannot be null, Request id: {request.RequestHeader.RequestId}");
                    }

                    if (string.IsNullOrWhiteSpace(request.IdvDocumentUploadPnMessage.EventType) ||
                        string.IsNullOrWhiteSpace(request.IdvDocumentUploadPnMessage.RegistrationToken))
                    {
                        throw new ValidationException(400, 0, $"request malformed for event type: {request.EventType}, Either IdvDocumentUploadPnMessage.EventType or RegistrationToken is null, Request id: {request.RequestHeader.RequestId}");
                    }

                    _notificationPublisher
                        .PublishNotification(DomainContext.Current.ProgramCode.ToString(),
                            request.RequestHeader.RequestId.ToString(), request.IdvDocumentUploadPnMessage,
                            EventType.IdvDocumentUpload);
                    break;

                case EventType.OverdraftNotification:
                    if (request.OverDraftPNMessage == null)
                    {
                        throw new ValidationException(400, 0, $"request malformed for event type: {request.EventType}, overDraftPNMessage object cannot be null, Request id: {request.RequestHeader.RequestId}");
                    }
                    if (request.OverDraftPNMessage.AccountIdentifier == null || !Guid.TryParse(request.OverDraftPNMessage.AccountIdentifier, out Guid odaccountIdentifier))
                    {
                        throw new ValidationException(400, 0, $"overdraftNotification need a valid AccountIdentifier,Request id: {request.RequestHeader.RequestId}");
                    }
                    _notificationPublisher.PublishNotificationGeneric(EventType.OverdraftNotification, request.ProgramCode,
                               request.OverDraftPNMessage.AccountIdentifier, request.OverDraftPNMessage);
                    break;
                case EventType.AffiliateTransfer:
                    if (request.AffiliateTransfer == null)
                    {
                        throw new ValidationException(400, 0, $"request malformed for event type: {request.EventType}, transfer object cannot be null, Request id: {request.RequestHeader.RequestId}");
                    }
                    if (request.AffiliateTransfer.AccountIdentifier == null || !Guid.TryParse(request.AffiliateTransfer.AccountIdentifier, out Guid transferAccountIdentifier))
                    {
                        throw new ValidationException(400, 0, $"transfer need a valid AccountIdentifier,Request id: {request.RequestHeader.RequestId}");
                    }
                    _notificationPublisher.PublishNotificationGeneric(EventType.AffiliateTransfer, request.ProgramCode,
                               request.AffiliateTransfer.AccountIdentifier, request.AffiliateTransfer);
                    break;
                default:
                    throw new ValidationException(400, 0, $"request malformed for event type: {request.EventType}");
            }
        }

        private void CheckAFTTransferRequest(SendPnRequest request)
        {
            var exceptionCode = (int)System.Net.HttpStatusCode.BadRequest;
            var exceptionSubCode = 0;
            if (request.AFTTransfer == null)
            {
                throw new ValidationException(exceptionCode, exceptionSubCode, $"request malformed for event type: {request.EventType}, Transfer object cannot be null, Request id: {request.RequestHeader.RequestId}");
            }

            if ( string.IsNullOrEmpty(request.AFTTransfer.AftTransferType))
            {
                throw new ValidationException(exceptionCode, exceptionSubCode, $"AFTTransfer need a valid AftTransferType Request id: {request.RequestHeader.RequestId}");
            }

            if (string.IsNullOrEmpty(request.AFTTransfer.TransferId))
            {
                throw new ValidationException(exceptionCode, exceptionSubCode, $"AFTTransfer need a valid TransferId Request id: {request.RequestHeader.RequestId}");
            }

            if (string.IsNullOrEmpty(request.AFTTransfer.AccountIdentifier))
            {
                throw new ValidationException(exceptionCode, exceptionSubCode, $"AFTTransfer need a valid AccountIdentifier Request id: {request.RequestHeader.RequestId}");
            }

            if (string.IsNullOrEmpty(request.AFTTransfer.TransactionAmount))
            {
                throw new ValidationException(exceptionCode, exceptionSubCode, $"AFTTransfer need a valid TransactionAmount Request id: {request.RequestHeader.RequestId}");
            }

            if (string.IsNullOrEmpty(request.AFTTransfer.TransferStatus))
            {
                throw new ValidationException(exceptionCode, exceptionSubCode, $"AFTTransfer need a valid TransferStatus Request id: {request.RequestHeader.RequestId}");
            }
        }

        private async Task GetDataFromCassandra(SendPnRequest sendPnRequest)
        {
            try
            {
                var sql = $"select * from pn.events " +
                    $"where event_status='failed' " +
                    $"and event_type='{sendPnRequest.EventType.ToString().ToLower()}' " +
                    $"and program_code='{sendPnRequest.ProgramCode.ToLower()}' " +
                    $"and event_id={sendPnRequest.EventId};";

                RowSet rowSet;
                
                rowSet = await _cosmosAccess.ExecuteStatementAsync(sql);

                var result = rowSet.SingleOrDefault();
                if (result == null)
                {
                    _logger.Info($"Cosmos did not return any data for eventId: {sendPnRequest.EventId} and requestId: {sendPnRequest.RequestHeader.RequestId} ");
                    return;
                }

                var eventStatus = result.GetValue<string>("event_status");
                var eventType = result.GetValue<string>("event_type");
                var programCode = result.GetValue<string>("program_code");
                var eventId = Guid.NewGuid();
                var delivered = result.GetValue<bool>("delivered");
                var deliveryDate = result.GetValue<DateTime>("delivery_date");
                if (!delivered)
                {
                    deliveryDate = DateTime.MinValue;
                }
                var accountId = result.GetValue<Guid>("account_id");
                var eventJson = result.GetValue<string>("event_json");
                var isTimeOut = result.GetValue<bool>("is_timeout");
                var latestEventStatus = result.GetValue<string>("latest_event_status");
                var partnerUrl = result.GetValue<string>("partner_url");
                var eventDateTime = TimeZoneInfo.ConvertTime(DateTime.Now, TimeZoneInfo.Local, TimeZoneInfo.Utc).ToString("yyyy-MM-dd HH:mm:sszzz");
                var eventDate = DateTimeOffset.Parse(eventDateTime);
                var eventDateBucket = eventDate.Date.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);

                _logger.Info($"New eventId generated is {eventId} for requestId: {sendPnRequest.RequestHeader.RequestId}");

                const string insertTransaction = "INSERT into pn.events (event_status, event_type, program_code, event_id, delivered, delivery_date, event_date, account_id, event_json, http_status_code, is_timeout, last_retry_date, latest_event_status, partner_url) " +
                                                        "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

                var parameters = new object[] { eventStatus, eventType.ToLower(), programCode, eventId, delivered, deliveryDate, eventDate, accountId, eventJson, 503, isTimeOut,
                    new DateTime(1970, 1, 1), latestEventStatus, partnerUrl };

                await _cosmosAccess.ExecuteStatementAsync(insertTransaction, parameters);

                const string insertEventDeliveryStatusV3 = "INSERT into pn.event_delivery_status_v3 (" +
                    "event_status, " +
                    "event_type, " +
                    "program_code, " +
                    "event_id, " +
                    "delivered, " +
                    "delivery_date, " +
                    "event_date, " +
                    "account_id, " +
                    "event_json, " +
                    "http_status_code, " +
                    "is_timeout, " +
                    "last_retry_date, " +
                    "latest_event_status, " +
                    "partner_url, " +
                    "request_id, " +
                    "event_date_bucket) " +
                    "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

                parameters = new object[] { eventStatus, eventType.ToLower(), programCode, eventId, delivered, deliveryDate, eventDate, accountId, eventJson, 503, isTimeOut,
                    new DateTime(1970, 1, 1), latestEventStatus, partnerUrl, sendPnRequest.RequestHeader.RequestId, eventDateBucket };

                await _cosmosAccess.ExecuteStatementAsync(insertEventDeliveryStatusV3, parameters);
            }
            catch (Exception exception)
            {
                _logger.Error(exception.Message + " eventId " + sendPnRequest.EventId + " eventType " + sendPnRequest.EventType);
                throw new RequestHandlerException(503, 0, "An error occurred while accessing Cassandra");
            }
        }

        private void CheckAdjustmentPNRequest(SendPnRequest request)
        {
            var exceptionCode = (int)System.Net.HttpStatusCode.BadRequest;
            var exceptionSubCode = 0;

            if (request.Adjustment == null)
            {
                throw new ValidationException(exceptionCode, exceptionSubCode, $"request malformed for event type: {request.EventType}, Request id: {request.RequestHeader.RequestId}");
            }
            if (request.Adjustment.AdjustmentIdentifier.IsNullOrEmpty())
            {
                throw new ValidationException(exceptionCode, exceptionSubCode, $"Adjustment need a valid AdjustmentIdentifier, Request id: {request.RequestHeader.RequestId}");
            }
            if (request.Adjustment.AccountIdentifier.IsNullOrEmpty())
            {
                throw new ValidationException(exceptionCode, exceptionSubCode, $"Adjustment need a valid AccountIdentifier, Request id: {request.RequestHeader.RequestId}");
            }
            if (request.Adjustment.EventDateTime == DateTime.MinValue)
            {
                throw new ValidationException(exceptionCode, exceptionSubCode, $"Adjustment need a valid EventDateTime, Request id: {request.RequestHeader.RequestId}");
            }
            if (request.Adjustment.Currency.IsNullOrEmpty())
            {
                throw new ValidationException(exceptionCode, exceptionSubCode, $"Adjustment need a valid Currency, Request id: {request.RequestHeader.RequestId}");
            }
        }
    }
}
