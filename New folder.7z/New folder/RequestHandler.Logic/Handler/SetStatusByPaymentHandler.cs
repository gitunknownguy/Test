﻿using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System;
using System.Threading.Tasks;

namespace RequestHandler.Logic.Handler
{
    public class SetStatusByPaymentHandler : CommandHandlerBase<SetStatusByPaymentRequest, SetStatusByPaymentResponse>
    {
        private readonly ISccAccountStatusService _sccAccountStatusService;
        private readonly IValidateIdentifier _validateIdentifier;

        public SetStatusByPaymentHandler(
            IValidateIdentifier validateIdentifier,
            ISccAccountStatusService sccAccountStatusService

        )
        {
            _validateIdentifier = validateIdentifier;
            _sccAccountStatusService = sccAccountStatusService;
        }

        public override void SetDomainContext(SetStatusByPaymentRequest request)
        {
            DomainContext.Current.AccountIdentifier = request?.AccountIdentifier;
        }

        public override Task<SetStatusByPaymentResponse> VerifyIdentifiers(SetStatusByPaymentRequest request)
        {
            return Task.FromResult(new SetStatusByPaymentResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override async Task<SetStatusByPaymentResponse> Handle(SetStatusByPaymentRequest request)
        {
            try
            {
                await _sccAccountStatusService.SetAccountStatusByPayment(request);

                var response = new SetStatusByPaymentResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request?.RequestHeader?.RequestId ?? Guid.NewGuid(),
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                };

                return response;
            }
            catch (Exception e)
            {
                return e.HandleException<SetStatusByPaymentResponse>(e, request);
            }
        }
    }
}
