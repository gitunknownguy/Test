﻿using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using NLog;
using System;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using System.Linq;
using System.Runtime.CompilerServices;

[assembly:InternalsVisibleTo("Tests")]
namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class UpdateIdentityHandler : CommandHandlerBase<UpdateIdentityRequest, UpdateIdentityResponse>
    {
        private readonly IUserService _userService;
        private readonly IBaasConfiguration _baasConfiguration;
        private readonly IRiskService _riskService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ITokenizerService _tokenizerService;
        private readonly IAccountService _accountService;
        internal static ILogger _logger = LogManager.GetCurrentClassLogger();

        public UpdateIdentityHandler(IUserService userService,
            IValidateIdentifier validateIdentifier,
            IBaasConfiguration baasConfiguration,
            IRiskService riskService,
            ITokenizerService tokenizerService,
            IAccountService accountService)
        {
            _userService = userService;
            _validateIdentifier = validateIdentifier;
            _baasConfiguration = baasConfiguration;
            _riskService = riskService;
            _tokenizerService = tokenizerService;
            _accountService = accountService;
        }

        public override void SetDomainContext(UpdateIdentityRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
            {
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            }

            if (!string.IsNullOrEmpty(request.UserIdentifier))
            {
                DomainContext.Current.UserIdentifier = request.UserIdentifier;
            }
        }

        public override Task<UpdateIdentityResponse> VerifyIdentifiers(UpdateIdentityRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier,
                    DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidateConsumerProfileIdentifier(DomainContext.Current.AccountIdentifier,
                    DomainContext.Current.UserIdentifier);
                return Task.FromResult(new UpdateIdentityResponse()
                {
                    ResponseHeader =
                        new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader()
                });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpdateIdentityResponse>(e, request));
            }
        }

        public override Task<UpdateIdentityResponse> Handle(UpdateIdentityRequest request)
        {
            var identityType = (IdentityType)Enum.Parse(typeof(IdentityType), request.IdentityType, true);

            if (identityType == IdentityType.ITIN && 
                ((string.IsNullOrEmpty(request.Identity) || !Regex.IsMatch(request.Identity, "^9[0-9]{8}$"))))
            {
                throw new VerifyIdentityTokenException(761, 0, "Invalid ITIN");
            }

            var userProfile =
                _accountService.GetAccountPrimaryConsumerProfileAnyToken(request.AccountIdentifier,
                    Guid.Parse(request.UserIdentifier));

            var account = _accountService.GetAccountByAccountIdentifier(request.AccountIdentifier);

            // Tokenize ssn
            string tokenizedSSn = _tokenizerService.TokenizeSsn(request.Identity, request.ProgramCode);

            // Verify Ssn in Fruad team
            var verifyResponse = _riskService.VerifyIdentityToken(userProfile, account, request.UserIdentifier,
                tokenizedSSn, request.ProgramCode, identityType);

            if (verifyResponse.ResponseCode != "0")
            {
                _logger.Error("Error when calling RiskService.VerifyIdentityToken: {0}, {1}, {2}",
                    verifyResponse.ResponseDescription, verifyResponse.Errors?.FirstOrDefault()?.ErrorDescription,
                    verifyResponse.VerificationDetail?.Reason);
                throw new VerifyIdentityTokenException(5, 110, "Declined by Fraud check");
            }

            // Add Or Update Identity
            _userService.AddOrUpdateConsumerIdentity(userProfile.ConsumerProfileKey, request.AccountIdentifier,
                request.UserIdentifier, request.Identity, tokenizedSSn, identityType);

            var response = new UpdateIdentityResponse
            {
                ResponseHeader = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                },
            };

            return Task.FromResult(response);
        }
    }
}
