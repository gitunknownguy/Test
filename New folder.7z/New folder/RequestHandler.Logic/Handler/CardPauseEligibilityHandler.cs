﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.RequestHandler.Logic.Queue;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Service;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class CardPauseEligibilityHandler : CommandHandlerBase<CardPauseEligibilityRequest, CardPauseEligibilityResponse>
    {
        private readonly IPaymentInstrumentService _paymentInstrumentService;
        private readonly IValidateIdentifier _validateIdentifier;

        public CardPauseEligibilityHandler(IPaymentInstrumentService paymentInstrumentService, IValidateIdentifier validateIdentifier)
        {
            _paymentInstrumentService = paymentInstrumentService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(CardPauseEligibilityRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            if (!string.IsNullOrEmpty(request.PaymentInstrumentIdentifier))
                DomainContext.Current.PaymentInstrumentIdentifier = request.PaymentInstrumentIdentifier;
        }

        public override Task<CardPauseEligibilityResponse> VerifyIdentifiers(CardPauseEligibilityRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                if (!string.IsNullOrEmpty(request.PaymentInstrumentIdentifier))
                    _validateIdentifier.ValidatePaymentInstrumentIdentifier(DomainContext.Current.AccountIdentifier, DomainContext.Current.PaymentInstrumentIdentifier);
                return Task.FromResult(new CardPauseEligibilityResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CardPauseEligibilityResponse>(e, request));
            }
        }

        public override Task<CardPauseEligibilityResponse> Handle(CardPauseEligibilityRequest request)
        {
            try
            {
                var response = _paymentInstrumentService.ValidateCardPauseEligibility(
                    AccountIdentifier.FromString(request.AccountIdentifier),
                    request.PaymentInstrumentIdentifier,
                    request.ProgramCode);

                response.ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                };
                return Task.FromResult(response);

            }

            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CardPauseEligibilityResponse>(e, request));
            }
        }

    }
}
