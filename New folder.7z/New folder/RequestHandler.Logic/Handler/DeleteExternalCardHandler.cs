﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.ExternalCard;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class DeleteExternalCardHandler : CommandHandlerBase<DeleteExternalCardRequest, BaseResponse>
    {
        public DeleteExternalCardHandler(IExternalCardService externalCardService, IIftDataAccess IFTDataAccess, IValidateIdentifier validateIdentifier)
        {
            _externalCardService = externalCardService;
            _IFTDataAccess = IFTDataAccess;
            _validateIdentifier = validateIdentifier;
        }


        public override void SetDomainContext(DeleteExternalCardRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<BaseResponse> VerifyIdentifiers(DeleteExternalCardRequest request)
        {
            _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);

            return Task.FromResult(new BaseResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<BaseResponse> Handle(DeleteExternalCardRequest request)
        {
            _externalCardService.DeleteExternalCard(request.AccountIdentifier, request.ExternalCardIdentifier);
            return Task.FromResult(new BaseResponse()
            {
                ResponseHeader = new ResponseHeader()
                {
                    Message = "Success",
                    ResponseId = request.RequestHeader.RequestId
                }
            });
        }

        private readonly IExternalCardService _externalCardService;
        private readonly IIftDataAccess _IFTDataAccess;
        private readonly IValidateIdentifier _validateIdentifier;
    }
}
