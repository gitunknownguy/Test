﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetFundFulfillmentMrdcTransferHandler : CommandHandlerBase<GetFundFulfillmentMrdcTransferRequest, GetFundFulfillmentMrdcTransferResponse>
    {
        private static string unspecifiedGuid = Guid.Empty.ToString();
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ITransferService _transferService;

        public GetFundFulfillmentMrdcTransferHandler(ITransferService transferService, IValidateIdentifier validateIdentifier)
        {
            _transferService = transferService;
            _validateIdentifier = validateIdentifier;
        }
        public override void SetDomainContext(GetFundFulfillmentMrdcTransferRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetFundFulfillmentMrdcTransferResponse> VerifyIdentifiers(GetFundFulfillmentMrdcTransferRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetFundFulfillmentMrdcTransferResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetFundFulfillmentMrdcTransferResponse>(e, request));
            }
        }

        public override Task<GetFundFulfillmentMrdcTransferResponse> Handle(GetFundFulfillmentMrdcTransferRequest request)
        {
            try
            {
                if (request.RequestHeader.RequestId == Guid.Empty)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId,
                        $"{nameof(request)}.RequestHeader.RequestId must be specified");
                }

                if (string.IsNullOrEmpty(request.AccountIdentifier) || request.AccountIdentifier == unspecifiedGuid)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier,
                        $"{nameof(request)}.TransferIdentifier must be specified");
                }

                var response = _transferService.GetFundFulfillmentMrdcTransfer(request);
                return Task.FromResult(new GetFundFulfillmentMrdcTransferResponse()
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = response.ResponseHeader.StatusCode,
                        SubStatusCode = response.ResponseHeader.SubStatusCode,
                        Message = response.ResponseHeader.Message,
                        //Details = response.ResponseHeader.Details
                    },
                    Transfer = response?.Transfer,
                });
            }

            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetFundFulfillmentMrdcTransferResponse>(e, request));
            }
        }
    }
}
