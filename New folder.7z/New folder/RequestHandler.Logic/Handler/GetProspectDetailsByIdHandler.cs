﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment.Exceptions;
using Gd.Bos.RequestHandler.Core.Domain.Services.Dcpp;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Caching.Contract;
using RequestHandler.Core.Application;
using RequestHandler.Core.Domain.Services;
using RequestHandler.Core.Domain.Services.Dcpp;
using RequestHandler.Core.Domain.Services.ProspectApi;
using GetProspectDetailsByIdRequest = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.GetProspectDetailsByIdRequest;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetProspectDetailsByIdHandler : CommandHandlerBase<GetProspectDetailsByIdRequest, GetProspectDetailsByIdResponse>
    {
        private ISampleCardService _sampleCardService;

        public GetProspectDetailsByIdHandler(ISampleCardService sampleCardService)
        {
            _sampleCardService = sampleCardService;
        }

        public override void SetDomainContext(GetProspectDetailsByIdRequest request)
        {

        }

        public override Task<GetProspectDetailsByIdResponse> Handle(GetProspectDetailsByIdRequest request)
        {
            if (request.RequestHeader == null)
            {
                request.RequestHeader = new RequestHeader()
                {
                    RequestId = Guid.NewGuid()
                };
            }

            var response = new GetProspectDetailsByIdResponse()
            {
                ResponseHeader = new ResponseHeader()
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                }
            };
            try
            {
                response = _sampleCardService.GetProspectDetailsById(request);
                return Task.FromResult(response);

            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetProspectDetailsByIdResponse>(e, request));
            }
        }

        public override Task<GetProspectDetailsByIdResponse> VerifyIdentifiers(GetProspectDetailsByIdRequest request)
        {
            if (string.IsNullOrEmpty(request?.ProspectIdentifier))
            {
                return Task.FromResult(new GetProspectDetailsByIdResponse()
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        StatusCode = 601,
                        SubStatusCode = 0,
                        Message = $"Prospect record is not found for {request?.ProspectIdentifier}"
                    }
                });
            }

            return Task.FromResult(new GetProspectDetailsByIdResponse()
            {
                ResponseHeader = new ResponseHeader()
            });
        }
    }
}
