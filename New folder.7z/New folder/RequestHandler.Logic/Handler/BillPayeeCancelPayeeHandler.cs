﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.BillPay;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class BillPayeeCancelPayeeHandler : CommandHandlerBase<BillPayDeletePayeeRequest, BillPayDeletePayeeResponse>
    {
        private readonly IBillPayService _billPayService;
        private readonly IValidateIdentifier _validateIdentifier;

        public BillPayeeCancelPayeeHandler(IBillPayService billPayService, IValidateIdentifier validateIdentifier)
        {
            _billPayService = billPayService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(BillPayDeletePayeeRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<BillPayDeletePayeeResponse> VerifyIdentifiers(BillPayDeletePayeeRequest request)
        {
            _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 3, 105);
            return Task.FromResult(new BillPayDeletePayeeResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<BillPayDeletePayeeResponse> Handle(BillPayDeletePayeeRequest request)
        {
            try
            {
                var response = _billPayService.CancelBillPayPayee(request.ProgramCode, request.AccountIdentifier, request.PayeeIdentifier);
                BillPayDeletePayeeResponse result = default(BillPayDeletePayeeResponse);

                if (response?.ErrorCode == "0")
                {
                    result = new BillPayDeletePayeeResponse()
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 0,
                            SubStatusCode = 0,
                            Message = "success"
                        },

                        PaymentStatus = response.PayeeStatus.ToLower()
                    };
                }
                else
                {
                    result = new BillPayDeletePayeeResponse()
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            SubStatusCode = 0,
                            Message = response.ErrorMessage
                        },
                    };
                    if (!string.IsNullOrEmpty(response.ErrorCode) && int.TryParse(response.ErrorCode, out var tempErrorCode))
                    {
                        result.ResponseHeader.StatusCode = tempErrorCode;
                    }
                    else
                    {
                        result.ResponseHeader.StatusCode = 0; //Default
                    }
                }
                return Task.FromResult(result);
            }
            catch (Exception ex)
            {
                return Task.FromResult(ex.HandleException<BillPayDeletePayeeResponse>(ex, request));
            }
        }
    }
}
