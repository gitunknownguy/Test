﻿using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Model.User.PreInterventions;
using Gd.Bos.RequestHandler.Core.Domain.Model.User.PreInterventions.Impls;
using Gd.Bos.RequestHandler.Core.Domain.Services.Crypto;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Core.Infrastructure.DataAccesses;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Caching;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using RequestHandler.Core.Application;
using RequestHandler.Core.Infrastructure;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.Shared.Common.Locking.ApiLock;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using GetAciPackageRequest = RequestHandler.Core.Domain.Services.AciRetailApi.GetAciPackageRequest;
using RequestHeader = Gd.Bos.Shared.Common.Contract.Message.Request.RequestHeader;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using RequestHandler.Core.Domain.Services.CNAPI;
using AccountHolder = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.AccountHolder;
using KycStateData = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData;
using RequestHandler.Core.Infrastructure.Enrollment;
using RH = RequestHandler.Core.Domain.Services.AciRetailApi;
using Org.BouncyCastle.Asn1.Ocsp;
using System.Runtime.InteropServices;
using Gd.Bos.Shared.Common.Core.Common.Data;
using Gd.Bos.Shared.Common.Core.Common.Enum;
using Gd.Bos.Shared.Common.CoreApi.Contract.Message.Request;
using PaymentInstrumentType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PaymentInstrumentType;
using RequestHandler.Core.Domain.Model.Inventory;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using PaymentInstrument = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PaymentInstrument;

namespace RequestHandler.Logic.Handler
{
    public class PreSignupEnrollmentHandler : CommandHandlerBase<PreSignupEnrollmentRequest, PreSignupEnrollmentResponse>
    {

        private readonly IRequestDataAccess _requestDataAccess;
        private readonly IEnrollmentDataAccess _enrollmentDataAccess;
        private readonly IEnrollmentService _enrollmentService;
        private readonly ITempCardEnrollmentService _tempCardEnrollmentService;
        private readonly ICryptoService _cryptoService;
        private readonly IIdempotentService _idempotentService;
        private readonly IAccountService _accountService;
        private readonly ILazyCache _lazyCache;
        private readonly IAgreementDataAccess _agreementRepository;
        private readonly INotificationService _notificationPublisher;
        private readonly IWelcomeNotificationService _welcomeNotificationService;
        private readonly ILockService _lockService;
        private readonly IAddressIntervention _addressIntervention;
        private readonly IProductService _productService;
        private readonly IProgramRepository _programRepository;
        private readonly IAccountRepository _accountRepository;
        private readonly ITokenizerService _tokenizerService;
        private readonly IBaasConfiguration _baasConfiguration;

        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IGatewayService _gatewayService;
        private readonly ICNAPIService _cNAPIService;
        private readonly IAciRetailService _aciRetailService;
        private readonly IPriorityNotificationService _priorityNotificationService;
        private readonly IInstantIssueCardInventoryRepository _instantIssueCardInventoryRepository;
        private readonly IPaymentIdentifierRepository _paymentIdentifierRepository;


        public PreSignupEnrollmentHandler(IRequestDataAccess requestDataAccess,
            IEnrollmentDataAccess enrollmentDataAccess,
            IEnrollmentService enrollmentService, ICryptoService cryptoService,
            IIdempotentService idempotentService,
            IAccountService accountService,
            ILazyCache lazyCache, IAgreementDataAccess agreementRepository,
            INotificationService notificationPublisher,
            IAddressIntervention addressIntervention,
            IWelcomeNotificationService welcomeNotificationService, ILockService lockService,
            IProductService productService, IProgramRepository programRepository, ITokenizerService tokenizerService,
            IBaasConfiguration baasConfiguration,
            IEnrollRepository enrollRepository,
            IValidateIdentifier validateIdentifier,
            IGatewayService gatewayService, IAciRetailService aciRetailService,
            ITempCardEnrollmentService tempCardEnrollmentService,
            IPriorityNotificationService priorityNotificationService,
            IInstantIssueCardInventoryRepository instantIssueCardInventoryRepository,
            IPaymentIdentifierRepository paymentIdentifierRepository,
            IAccountRepository accountRepository
        )
        {
            _requestDataAccess = requestDataAccess;
            _enrollmentDataAccess = enrollmentDataAccess;
            _enrollmentService = enrollmentService;
            _cryptoService = cryptoService;
            _idempotentService = idempotentService;
            _accountService = accountService;
            _lazyCache = lazyCache;
            _agreementRepository = agreementRepository;
            _notificationPublisher = notificationPublisher;
            _welcomeNotificationService = welcomeNotificationService;
            _lockService = lockService;
            _addressIntervention = addressIntervention;
            _productService = productService;
            _programRepository = programRepository;
            _tokenizerService = tokenizerService;
            _baasConfiguration = baasConfiguration;
            _validateIdentifier = validateIdentifier;
            _gatewayService = gatewayService;
            _aciRetailService = aciRetailService;
            _tempCardEnrollmentService = tempCardEnrollmentService;
            _accountRepository = accountRepository;
            _priorityNotificationService = priorityNotificationService;
            _instantIssueCardInventoryRepository = instantIssueCardInventoryRepository;
            _paymentIdentifierRepository=paymentIdentifierRepository;
        }

        public async override Task<PreSignupEnrollmentResponse> Handle(PreSignupEnrollmentRequest request)
        {
            try
            {
                string enrollmentRequestIdentifier = null;
                RH.GetAciPackageResponse packageDetails = new RH.GetAciPackageResponse();

                if (request.RequestHeader.Options != null && request.RequestHeader.Options.ContainsKey("X-GD-EnrollmentRequestIdentifier"))
                {
                    enrollmentRequestIdentifier = request.RequestHeader.Options["X-GD-EnrollmentRequestIdentifier"].ToString();
                }

                #region "Request Id"

                var accountLimit = new AccountLimit();
                var newAccountIdentifier = Guid.NewGuid();

                var existingRequestAccountIdentifier = _requestDataAccess.InsertRequestId(RequestType.Enroll,
                    request.RequestHeader.RequestId, newAccountIdentifier);
                #endregion

                #region Validate_VerificationRequest_Expiration

                var verificationRequest = _tempCardEnrollmentService.GetVerificationRequestByIdentifier(new Guid(request.Card.RegistrationToken));

                if (verificationRequest.VerificationRequestKey == 0)
                {
                    return new PreSignupEnrollmentResponse()
                    {
                        ResponseHeader = new ResponseHeader()
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 400,
                            SubStatusCode = 340,
                            Message = "Registration token not found",
                            Details = "Registration token not found"
                        }
                    };
                }

                if (verificationRequest.PaymentIdentifierKey != 0)
                {
                    var accountProduct =
                        _accountRepository.GetAccountProductByAccountHolderKey(verificationRequest.AccountHolderKey);
                    var cardInventoryByAccount =
                        _instantIssueCardInventoryRepository.GetInstantIssueCardInventoryByAccountIdentifier(
                            Guid.Parse(accountProduct.accountIdentifier));
                    var enrollmentResponse = _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(
                        accountProduct.accountIdentifier, request.ProgramCode,
                        true);
                    if ((string.IsNullOrWhiteSpace(cardInventoryByAccount) &&
                         !string.IsNullOrWhiteSpace(request.Card.ExternalId)))
                    {
                        var getAciPackageResponse =await _aciRetailService.GetPackageDetailsById(new GetAciPackageRequest()
                        {
                            ExternalId = request.Card.ExternalId,
                            RequestHeader = new RequestHeader()
                            {
                                RequestId = request.RequestHeader.RequestId
                            }
                        });
                        var paymentIdentifier =
                            _paymentIdentifierRepository.GetPaymentIdentifiersByPaymentIdentifierProxy(
                                getAciPackageResponse
                                    .AlternativePan, false);
                        if (paymentIdentifier.FirstOrDefault()?.PaymentIdentifierKey== verificationRequest.PaymentIdentifierKey)
                        {
                            _instantIssueCardInventoryRepository.InsertInstantIssueCardInventory(
                                Guid.Parse(enrollmentResponse.Account.AccountIdentifier), request.Card.ExternalId);
                            return new PreSignupEnrollmentResponse()
                            {
                                ResponseHeader =
                                    new ResponseHeader()
                                    {
                                        ResponseId = request.RequestHeader.RequestId,
                                        StatusCode = 0,
                                        SubStatusCode = 0,
                                        Message = "Success"
                                    },
                                Status = enrollmentResponse.Account.Status,
                                CustomerReferenceNumber = enrollmentResponse.Account.CustomerReferenceNumber,
                                AccountHolders = enrollmentResponse.Account.AccountHolders,
                                AccountIdentifier = enrollmentResponse.Account.AccountIdentifier,
                                AccountCycleDay = enrollmentResponse.Account.AccountCycleDay,
                            };
                        }
                    }

                    if (cardInventoryByAccount == request.Card.ExternalId ||
                        (string.IsNullOrWhiteSpace(cardInventoryByAccount) &&
                         string.IsNullOrWhiteSpace(request.Card.ExternalId)))
                    {
                        return new PreSignupEnrollmentResponse()
                        {
                            ResponseHeader =
                                new ResponseHeader()
                                {
                                    ResponseId = request.RequestHeader.RequestId,
                                    StatusCode = 0,
                                    SubStatusCode = 0,
                                    Message = "Success"
                                },
                            Status = enrollmentResponse.Account.Status,
                            CustomerReferenceNumber = enrollmentResponse.Account.CustomerReferenceNumber,
                            AccountHolders = enrollmentResponse.Account.AccountHolders,
                            AccountIdentifier = enrollmentResponse.Account.AccountIdentifier,
                            AccountCycleDay = enrollmentResponse.Account.AccountCycleDay,
                    };
                    }
                    else
                    {

                        return new PreSignupEnrollmentResponse()
                        {
                            ResponseHeader = new ResponseHeader()
                            {
                                ResponseId = request.RequestHeader.RequestId,
                                StatusCode = 400,
                                SubStatusCode = 342,
                                Message = "The registration token is already linked to a card"
                            }
                        };
                    }
                }

                int tokenExpirationMinutes = _baasConfiguration.GetTokenExpiredMinutes(request.ProgramCode);
                //Since tokenExpiredMinutes is only for pls I added this
                //Validation for testing register card with dayforce
                //TODO: remove when pls ACI setup is ready
                tokenExpirationMinutes = tokenExpirationMinutes == 0 ? 20 : tokenExpirationMinutes;

                if (DateTime.Now > verificationRequest.ChangeDate.AddMinutes(tokenExpirationMinutes))
                {
                    return new PreSignupEnrollmentResponse()
                    {
                        ResponseHeader = new ResponseHeader()
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 400,
                            SubStatusCode = 341,
                            Message = "Registration token has been expired",
                            Details = "Registration token has been expired"
                        }
                    };
                }

                if (verificationRequest.StatusKey != (short)Gd.Bos.Shared.Common.Core.Common.Enum.AccountHolderCure.Healthy)
                {
                    return new PreSignupEnrollmentResponse()
                    {
                        ResponseHeader = new ResponseHeader()
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 400,
                            SubStatusCode = 342,
                            Message = $"Registration token status is not healthy",
                            Details = $"Registration token status is not healthy"
                        }
                    };
                }


                #endregion

                #region Get_Request_Data_From_Cassandra
                request = _tempCardEnrollmentService.MapRequestFromCassandra(request);
                #endregion

                #region "Get_Aci_Package_Info"

                if (string.IsNullOrEmpty(request.Card.ExternalId) && !request.Card.IsPerso)
                {
                    return new PreSignupEnrollmentResponse()
                    {
                        ResponseHeader = new ResponseHeader()
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 400,
                            SubStatusCode = 5022,
                            Message = "ExternalID can not be empty",
                            Details = "ExternalID can not be empty"
                        }
                    };
                }

                if (string.IsNullOrEmpty(request.Card.ProductMaterialType))
                {
                    return new PreSignupEnrollmentResponse()
                    {
                        ResponseHeader = new ResponseHeader()
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 400,
                            SubStatusCode = 6181,
                            Message = "Product material type can not be empty",
                            Details = "Product material type can not be empty"
                        }
                    };
                }

                //Verify ProductId for Temp Card
                if (!request.Card.IsPerso)
                {
                    packageDetails =await _aciRetailService.GetPackageDetailsById(new GetAciPackageRequest()
                    {
                        ExternalId = request.Card.ExternalId,
                        RequestHeader = new RequestHeader()
                        {
                            RequestId = request.RequestHeader.RequestId
                        }
                    });

                    if (packageDetails.ResponseHeader.StatusCode != 0)
                    {
                        return new PreSignupEnrollmentResponse()
                        {
                            ResponseHeader = new ResponseHeader
                            {
                                ResponseId = packageDetails.ResponseHeader.ResponseId,
                                StatusCode = packageDetails.ResponseHeader.StatusCode,
                                SubStatusCode = packageDetails.ResponseHeader.SubStatusCode,
                                Message = packageDetails.ResponseHeader.Message
                            },
                        };
                    }

                    if (string.IsNullOrEmpty(packageDetails.AlternativePan))
                    {
                        return new PreSignupEnrollmentResponse()
                        {
                            ResponseHeader = new ResponseHeader
                            {
                                ResponseId = packageDetails.ResponseHeader.ResponseId,
                                StatusCode = 400,
                                SubStatusCode = 5025,
                                Message = "ExternalId not found."
                            },
                        };
                    }

                    if (!string.IsNullOrEmpty(packageDetails.Status))
                    {
                        return new PreSignupEnrollmentResponse()
                        {
                            ResponseHeader = new ResponseHeader
                            {
                                ResponseId = packageDetails.ResponseHeader.ResponseId,
                                StatusCode = 400,
                                SubStatusCode = 5012,
                                Message = "ExternalId already used."
                            },
                        };
                    }

                    if (packageDetails.ExpirationDate < DateTime.Now)
                    {
                        return new PreSignupEnrollmentResponse()
                        {
                            ResponseHeader = new ResponseHeader
                            {
                                ResponseId = packageDetails.ResponseHeader.ResponseId,
                                StatusCode = 400,
                                SubStatusCode = 5013,
                                Message = "ExternalId expired."
                            },
                        };
                    }

                    //Validate if external proxy already exists in GBOS table
                    var accounts = _accountRepository.GetAccountByPaymentIdentifierProxyList(new List<string> { packageDetails.AlternativePan });
                    if (accounts.Count() > 0)
                    {
                        return new PreSignupEnrollmentResponse()
                        {
                            ResponseHeader = new ResponseHeader
                            {
                                ResponseId = packageDetails.ResponseHeader.ResponseId,
                                StatusCode = 400,
                                SubStatusCode = 5055,
                                Message = "ExternalId already used."
                            },
                        };
                    }
                }
                #endregion

                var userIdentifyingData = request.UserCreationData?.IdentifyingData?.ToDomain(false, true);

                #region "Limit_Verifications"
                //Validate Identity limit
                var detokenizeIdentityResponse = _tokenizerService.DeTokenizeIdentity(userIdentifyingData.IdentityValue);
                accountLimit = _accountService.AccountLimitVerification(detokenizeIdentityResponse.Value, userIdentifyingData.IdentityValue, userIdentifyingData?.IdentityType.ToString(), true, request.AccountCreationData?.ProductCode, request.ProgramCode);
                if (accountLimit.ResponseCode == "260")
                    throw new RequestHandlerException(2, 60, "Number of Active Accounts Exceeded.");
                else if (accountLimit.ResponseCode == "261")
                    throw new RequestHandlerException(2, 61, "Number of Activated Accounts over Lifetime exceeded.");

                //Validate phone limit
                var number = !string.IsNullOrEmpty(request.UserCreationData?.PhoneNumbers.FirstOrDefault(p => p.IsDefault)?.Number) ? request.UserCreationData?.PhoneNumbers.FirstOrDefault(p => p.IsDefault)?.Number : request.UserCreationData?.PhoneNumbers.FirstOrDefault()?.Number;
                accountLimit = _accountService.PhoneLimitVerification(number, "PhoneNumber", request.AccountCreationData?.ProductCode, request.ProgramCode);
                accountLimit.ResponseCode = accountLimit.ResponseCode ?? "0";
                if (accountLimit.ResponseCode != "0")
                    _lazyCache?.Value?.Set(request.RequestHeader?.RequestId.ToString(), accountLimit.ResponseCode, new TimeSpan(1, 0, 0, 0));
                #endregion

                if (request.AccountCreationData == null)
                {
                    throw new ArgumentNullException("Enroll: AccountCreationData");
                }

                #region "Fill_Data_from_Payload"

                var response = new PreSignupEnrollmentResponse();
                var userName = new UserName(request.UserCreationData?.ProfileData?.FirstName,
                    request.UserCreationData?.ProfileData?.MiddleName, request.UserCreationData?.ProfileData?.LastName);

                var email = request.UserCreationData?.Email?.ToDomain();

                var businessAccount = request.UserCreationData?.BusinessData?.ToDomain();
                if (businessAccount != null)
                {
                    businessAccount.AccountType = request.AccountCreationData?.AccountType;
                    if (businessAccount.BusinessType == 0)
                        throw new ValidationException(600, 0, "Invalid BusinessType");
                }

                var businessAddress = request.UserCreationData?.BusinessData?.BusinessAddress?.ToDomain();

                var addresses =
                    request.UserCreationData?.ProfileData?.Addresses?.ToDomain();

                var phoneNumbers =
                    request.UserCreationData?.PhoneNumbers?.ToDomain();

                var agreement =
                    _agreementRepository.GetAgreementsByProductCode(request.AccountCreationData.ProductCode);

                var terms = request.AccountCreationData.TermsAcceptances?.ToDomain(agreement);

                var homeAddress = addresses.FirstOrDefault(add => add.AddressTypeKey == (short)AddressType.Home);

                if (businessAddress != null && homeAddress.IsDefault == false)
                {
                    businessAddress.IsBusinessAddressForPostal = true;
                }
                _addressIntervention.SetHomeAddressToDefault(addresses);

                _addressIntervention.ValidAddresses(addresses, true);

                #endregion

                #region validation PMT
                if (!string.IsNullOrEmpty(request.Card.ProductMaterialType))
                {
                    var pmtWhiteList = _baasConfiguration.GetPmtWhiteList(request.ProgramCode);
                    if (pmtWhiteList != null)
                    {
                        if (!pmtWhiteList.Any(p =>
                                p.Equals(request.Card.ProductMaterialType, StringComparison.CurrentCultureIgnoreCase)))
                        {
                            return new PreSignupEnrollmentResponse()
                            {
                                ResponseHeader = new ResponseHeader()
                                {
                                    ResponseId = request.RequestHeader.RequestId,
                                    StatusCode = 400,
                                    SubStatusCode = 1705,
                                    Message = "Invalid ProductMaterialType"
                                }
                            };
                        }
                    }
                }
                #endregion

                #region "enroll"

                var enrollResponse = _tempCardEnrollmentService.PreSignUpEnroll(
                    request,
                    packageDetails,
                    newAccountIdentifier.ToString(),
                    userName,
                    userIdentifyingData,
                    email,
                    addresses,
                    phoneNumbers,
                    terms,
                    request.Card.ProductMaterialType,
                    businessAccount,
                    businessAddress,
                    true //setting override flag to true for now until there is a product level configuration
                    );

                #endregion

                #region "Retrieve_From_Enroll"

                var newUser = enrollResponse.Item2;
                var newAccount = enrollResponse.Item1;
                var newPaymentIdentifier = enrollResponse.Item3;
                var newAccountBalance = enrollResponse.Item4;
                var privateCardData = enrollResponse.Item5;

                string errorCode = _lazyCache?.Value?.Get<string>(request.RequestHeader?.RequestId.ToString());
                if (!string.IsNullOrEmpty(errorCode) && errorCode != "0")
                {
                    response.ResponseHeader = response.ResponseHeader.GetResponseHeader(errorCode, request.RequestHeader.RequestId);
                }
                else
                {
                    response.ResponseHeader = response.ResponseHeader.GetResponseHeader(newAccount.ErrorCode.ToString(), request.RequestHeader.RequestId);
                    _lazyCache?.Value?.Set(request.RequestHeader?.RequestId.ToString(), newAccount.ErrorCode.ToString(), new TimeSpan(1, 0, 0, 0));
                }

                response.AccountIdentifier = newAccount.AccountIdentifier.ToString();
                response.CustomerReferenceNumber = newAccount.CustomerAccountNumber;
                response.Status = newAccount.AccountStatus.ToString().ToLower();


                DateTime accountStatusDateChange = newAccount.AccountStatusChangedDateTime;
                accountStatusDateChange = accountStatusDateChange.ToUniversalTime();
                response.AccountStatusChangedDateTime =
                    accountStatusDateChange.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");


                if (newAccount.AccountStatusReasons?.Count > 0)
                {
                    response.StatusReasons = new List<string>();

                    foreach (Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountStatusReason statusReason in newAccount
                        .AccountStatusReasons)
                    {
                        response.StatusReasons.Add(statusReason.ToString());
                    }
                }

                response.DirectDepositInformation = new DirectDepositInformation
                {
                    AccountNumber = newAccount.AccountNumber,
                    RoutingNumber = newAccount.RoutingNumber
                };


                if (newAccountBalance != null)
                {
                    response.Purses = new List<Purse>();
                    var purse = new Purse
                    {
                        PurseIdentifier = newAccountBalance.AccountBalanceIdentifier.ToString(),
                        PurseType = PurseType.Primary,
                        AvailableBalance = newAccountBalance.AvailableBalance,
                        LedgerBalance = newAccountBalance.CurrentBalance,
                        AvailableBalanceAsOfDateTime = newAccountBalance.AvailableBalanceAsOfDate,
                        LedgerBalanceAsOfDateTime = newAccountBalance.CurrentBalanceAsOfDate,
                        Status = newAccountBalance.Status
                    };
                    response.Purses.Add(purse);
                }

                response.AccountHolders = new List<AccountHolder>();
                var accountHolder = new AccountHolder();

                foreach (Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolder ah in newAccount.AccountHolders)
                {
                    accountHolder.User = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.User
                    {
                        UserIdentifier = newUser.UserIdentifier.ToString(),
                        Status = UserStatus.Active,
                        IsPrimaryAccountHolder = true,
                        KycStateData = new KycStateData
                        {
                            OfacStatus = ah.kycStateData.OfacStatus.ToString().ToLower(),
                            KycStatus = ah.kycStateData.KycStatus.ToString().ToLower(),
                            PendingKycGate = ah.kycStateData.KycPendingGate.ToLower()
                        }
                    };


                    if (newPaymentIdentifier != null)
                    {
                        accountHolder.PaymentInstruments = new List<PaymentInstrument>();
                        var paymentInstrument = new PaymentInstrument();
                        //PaymentInstrumentStatus paymentInstrumentStatus;
                        Enum.TryParse(newPaymentIdentifier.PaymentInstrument.Status, out PaymentInstrumentStatus paymentInstrumentStatus);

                        paymentInstrument.PaymentIdentifier = newPaymentIdentifier.PaymentIdentifierIdentifier.ToString();
                        paymentInstrument.PaymentInstrumentIdentifier = newPaymentIdentifier?.PaymentInstrument
                            .PaymentInstrumentIdentifier.ToString();
                        paymentInstrument.PaymentInstrumentType =
                            newPaymentIdentifier.PaymentInstrument.PaymentInstrumentType;
                        paymentInstrument.Status = paymentInstrumentStatus;
                        paymentInstrument.IsPinSet = newPaymentIdentifier.PaymentInstrument.PinSetDate.HasValue;
                        paymentInstrument.Last4Pan = newPaymentIdentifier?.PaymentInstrument.Last4Pan;
                        paymentInstrument.ActivatedDateTime = newPaymentIdentifier?.PaymentInstrument.ActivatedDateTime;
                        paymentInstrument.IssuedDateTime = newPaymentIdentifier?.PaymentInstrument.IssuedDateTime;

                        if (privateCardData != null)
                        {
                            paymentInstrument.PrivateCardData =
                                new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PrivateCardData
                                {
                                    Pan = privateCardData?.Pan,
                                    Cvv = privateCardData?.Cvv,
                                    ExpirationDate = new CardExpirationDate
                                    {
                                        CardExpirationMonth = privateCardData?.CardExpirationDate.CardExpirationMonth,
                                        CardExpirationyear = privateCardData?.CardExpirationDate.CardExpirationYear
                                    }
                                };

                            if (paymentInstrument.PaymentInstrumentType == PaymentInstrumentType.Virtual)
                                paymentInstrument.IsPrivateDataViewable = "true";
                        }

                        accountHolder.PaymentInstruments.Add(paymentInstrument);
                    }

                    response.AccountHolders.Add(accountHolder);
                }

                var accountResp = _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(newAccount.AccountIdentifier.ToString(), request.ProgramCode, false);
                response.AccountCycleDay = accountResp.Account.AccountCycleDay;

                await _notificationPublisher.PublishNotification(request.ProgramCode, accountResp.Account, EventType.AccountUpdated, request.RequestHeader.RequestId.ToString());
                if (accountResp.Account.Status == "normal")
                {
                    _welcomeNotificationService.RaiseWelcomeNotification(request.ProgramCode, accountResp.Account.AccountIdentifier, request.RequestHeader.RequestId);

                    Task.Run(async () =>
                    {
                        var getActivationTokenInBuxResponse = await _gatewayService.GetActivationTokenInBux(request.ProgramCode, response.AccountIdentifier,
                            request.RequestHeader.RequestId, userIdentifyingData.IdentityType.ToString(),
                            userIdentifyingData.IdentityCountryCode);
                        SendCnMessageRequest sendCnMessageRequest = new SendCnMessageRequest
                        {
                            RequestHeader = new RequestHeader { RequestId = request.RequestHeader.RequestId },
                            AccountIdentifier = response.AccountIdentifier,
                            NotificationType = (int)CnNotificationType.CardActivationUrl,
                            ProgramCode = request.ProgramCode,
                            ProductCode = request.AccountCreationData.ProductCode,
                            Attributes = new MessageAttribute[]
                            {
                                new MessageAttribute(){Name="FirstName",Value = request.UserCreationData.ProfileData.FirstName},
                                new MessageAttribute(){Name = "URL",Value = getActivationTokenInBuxResponse.Url}
                            },
                            Contacts = new[]
                            {
                                new MessageContact {ChannelType = "1", ContactValue = phoneNumbers?.FirstOrDefault(it=>it.IsDefault)?.Number},
                                new MessageContact {ChannelType = "2", ContactValue = request.UserCreationData.Email.EmailAddress}
                            }
                        };
                        await _priorityNotificationService.PublishPriorityNotification(request.ProgramCode,
                            sendCnMessageRequest);

                    });
                }
                else if (_accountService.IsDeclinedAccount(accountResp.Account))
                    _welcomeNotificationService.RaiseUnwelcomeNotification(request.ProgramCode, accountResp.Account.AccountIdentifier, request.RequestHeader.RequestId);

                return response;
                #endregion
            }
            catch (InvalidProductMaterialException e)
            {
                var response = new PreSignupEnrollmentResponse()
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 4,
                        SubStatusCode = 312,
                        Message = e.Message
                    },
                };
                return response;
            }
            catch (Exception e)
            {
                return e.HandleException<PreSignupEnrollmentResponse>(e, request);
            }
        }

        public override void ReleaseLock(PreSignupEnrollmentRequest request)
        {
            _lockService.ReleaseApiLock(OptionsContext.Current.GetString("requestId"));
            _lockService.ReleaseApiLock(DomainContext.Current.RegistrationToken);
            if (!string.IsNullOrEmpty(DomainContext.Current.CardExternalId))
            {
                _lockService.ReleaseApiLock("CardExternalId_" + DomainContext.Current.CardExternalId);
            }
        }
        public override async Task<PreSignupEnrollmentResponse> ObtainLock(PreSignupEnrollmentRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock(OptionsContext.Current.GetString("requestId"));
                await _lockService.ObtainApiLock(DomainContext.Current.RegistrationToken);
                if (!string.IsNullOrEmpty(DomainContext.Current.CardExternalId))
                {
                    await _lockService.ObtainApiLock("CardExternalId_" + DomainContext.Current.CardExternalId);
                }

                return new PreSignupEnrollmentResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<PreSignupEnrollmentResponse>(e, request);
            }
        }
        public override void SetDomainContext(PreSignupEnrollmentRequest request)
        {
            DomainContext.Current.RegistrationToken = request.Card.RegistrationToken;
            DomainContext.Current.CardExternalId = request.Card.ExternalId;
        }

        public override Task<PreSignupEnrollmentResponse> VerifyIdentifiers(PreSignupEnrollmentRequest request)
        {
            request = _tempCardEnrollmentService.MapRequestFromCassandra(request);

            _validateIdentifier.ValidateProduct(ProgramCode.FromString(request.ProgramCode),
                ProductCode.FromString(request.AccountCreationData.ProductCode));
            return Task.FromResult(new PreSignupEnrollmentResponse() { ResponseHeader = new ResponseHeader() });
        }

        private EnrollRequest MapTempCardEnrollment(PreSignupEnrollmentRequest PrePrintedEnrollmentRequest)
        {
            return new EnrollRequest()
            {
                RequestHeader = PrePrintedEnrollmentRequest.RequestHeader,
                ProgramCode = PrePrintedEnrollmentRequest.ProgramCode,
                ContactVerificationIdentifiers = PrePrintedEnrollmentRequest.ContactVerificationIdentifiers,
                UserCreationData = PrePrintedEnrollmentRequest.UserCreationData,
                AccountCreationData = PrePrintedEnrollmentRequest.AccountCreationData,
                ExecuteKycFlag = PrePrintedEnrollmentRequest.ExecuteKycFlag,
                RequestPhysicalCardFlag = PrePrintedEnrollmentRequest.RequestPhysicalCardFlag,
                OverrideAddressStandardization = PrePrintedEnrollmentRequest.OverrideAddressStandardization,
                FraudData = PrePrintedEnrollmentRequest.FraudData
            };
        }
    }
}
