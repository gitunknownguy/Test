﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;

namespace RequestHandler.Logic.Handler
{
    public class GetProductMaterialTypesHandler : CommandHandlerBase<GetProductMaterialTypesRequest, GetProductMaterialTypesResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IProductService _productService;
        private readonly IBaasConfiguration _baasConfiguration;

        // ReSharper disable once ConvertToPrimaryConstructor
        public GetProductMaterialTypesHandler(IValidateIdentifier validateIdentifier,
            IProductService productService,
            IBaasConfiguration baasConfiguration)
        {
            _validateIdentifier = validateIdentifier;
            _productService = productService;
            _baasConfiguration = baasConfiguration;
        }

        public override void SetDomainContext(GetProductMaterialTypesRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.ProgramCode))
                return;
            
            DomainContext.Current.ProgramCode = ProgramCode.FromString(request.ProgramCode);
        }

        public override Task<GetProductMaterialTypesResponse> VerifyIdentifiers(GetProductMaterialTypesRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetProductMaterialTypesResponse { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetProductMaterialTypesResponse>(e, request));
            }
        }

        public override Task<GetProductMaterialTypesResponse> Handle(GetProductMaterialTypesRequest request)
        {
            try
            {
                var pmtList = _productService.GetProductMaterialTypeByProcessor(request.ProgramCode, request.ProcessorKey);

                var pmtWhiteList = _baasConfiguration.GetPmtWhiteList(request.ProgramCode);
                if (pmtWhiteList == null || pmtWhiteList.Count == 0)
                {
                    return Task.FromResult(GetResponse());
                }

                var response = GetResponse();
                response.ProductMaterialTypes = pmtList.Where(pmt => pmtWhiteList.Contains(pmt.ProductMaterialType)).ToList();

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task
                    .FromResult(e.HandleException<GetProductMaterialTypesResponse>(e, request));
            }

            GetProductMaterialTypesResponse GetResponse()
            {
                return new GetProductMaterialTypesResponse
                {
                    ProductMaterialTypes = [],
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    }
                };
            }
        }
    }
}
