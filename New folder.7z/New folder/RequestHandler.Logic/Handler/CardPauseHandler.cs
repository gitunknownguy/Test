﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;


namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class CardPauseHandler : CommandHandlerBase<CardPauseRequest, CardPauseResponse>
    {
        private readonly IPaymentInstrumentService _paymentInstrumentService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ILockService _lockService;

        public CardPauseHandler(IPaymentInstrumentService paymentInstrumentService, IValidateIdentifier validateIdentifier, ILockService lockService)
        {
            _paymentInstrumentService = paymentInstrumentService;
            _validateIdentifier = validateIdentifier;
            _lockService = lockService;
        }

        public override void SetDomainContext(CardPauseRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            DomainContext.Current.PaymentInstrumentIdentifier = request.PaymentInstrumentIdentifier;
        }

        public override Task<CardPauseResponse> VerifyIdentifiers(CardPauseRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidatePaymentInstrumentIdentifier(DomainContext.Current.AccountIdentifier, DomainContext.Current.PaymentInstrumentIdentifier);
                return Task.FromResult(new CardPauseResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CardPauseResponse>(e, request));
            }
        }

        public override async Task<CardPauseResponse> ObtainLock(CardPauseRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock("Card_" + DomainContext.Current.AccountIdentifier);
                return new CardPauseResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<CardPauseResponse>(e, request);
            }
        }

        public override Task<CardPauseResponse> Handle(CardPauseRequest request)
        {
            try
            {
                _paymentInstrumentService.CardPause(AccountIdentifier.FromString(request.AccountIdentifier),
                    PaymentInstrumentIdentifier.FromString(request.PaymentInstrumentIdentifier),
                    request.ProgramCode,
                    request.LifeCycleEventType,
                    request.Notes, request.RequestHeader?.Source);

                var response = new CardPauseResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                };

                return Task.FromResult(response);

            }
            catch (Exception e)
            {
                CardPauseResponse response = new CardPauseResponse();

                if (e.Message.Contains("CARDSTATUSCHANGE_INVALIDSTATUSCHANGE") || e.Message.Contains("CARDSTATUS_CHANGE_NEW_OLD_STATUS_RSN_CODE_CANNOT_BE_EQUAL"))
                {
                    response = new CardPauseResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 4,
                            SubStatusCode = 314,
                            Message = "Card already blocked.  Statuses updated."
                        },
                    };
                    return Task.FromResult(response);
                }
                else
                {
                    return Task.FromResult(e.HandleException<CardPauseResponse>(e, request));
                }
            }
        }

        public override void ReleaseLock(CardPauseRequest request)
        {
            _lockService.ReleaseApiLock("Card_" + DomainContext.Current.AccountIdentifier);
        }
    }
}
