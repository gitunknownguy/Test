﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Newtonsoft.Json;
using NLog;
using RequestHandler.Core.Domain.Model.User;
using UserProfile = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.UserProfile;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class ValidateSsnHandler : CommandHandlerBase<ValidateSsnRequest, ValidateSsnResponse>
    {
        private readonly IUserService _userService;
        private readonly IValidateIdentifier _validateIdentifier;

        public ValidateSsnHandler(IUserService userService,
            IValidateIdentifier validateIdentifier)
        {
            _userService = userService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(ValidateSsnRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<ValidateSsnResponse> VerifyIdentifiers(ValidateSsnRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new ValidateSsnResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<ValidateSsnResponse>(e, request));
            }
        }

        public override Task<ValidateSsnResponse> Handle(ValidateSsnRequest request)
        {
            ValidateSsnResult result;
            ValidateSsnResponse response = new ValidateSsnResponse();
            try
            {
                result = _userService.ValidateSsn(request.ProgramCode, request.AccountIdentifier, request.UserIdentifier, request.SsnHashCode);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<ValidateSsnResponse>(e, request));
            }

            response.MismatchCount = result.MismatchCount;
            if (result.IsMatch)
            {
                response.ResponseHeader = new ResponseHeader()
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                };
            }
            else
            {
                response.ResponseHeader = new ResponseHeader()
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 760,
                    SubStatusCode = 0,
                    Message = "Invalid SSN"
                };
            }

            return Task.FromResult(response);
        }
    }
}