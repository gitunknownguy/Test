﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Interest;
using Gd.Bos.RequestHandler.Core.Domain.Services.InterestRate;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class LinkAccountHandler : CommandHandlerBase<LinkAccountRequest, LinkAccountResponse>
    {
        public LinkAccountHandler(IValidateIdentifier validateIdentifier, IAccountService accountService)
        {
            _validateIdentifier = validateIdentifier;
            _accountService = accountService;

        }

        public override void SetDomainContext(LinkAccountRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.PrimaryAccountIdentifier;
        }
        public override Task<LinkAccountResponse> VerifyIdentifiers(LinkAccountRequest request)
        {
            _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
            _validateIdentifier.ValidateProgramCode(request.LinkAccountIdentifier, DomainContext.Current.ProgramCode);
            _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 5, 105);
            return Task.FromResult(new LinkAccountResponse { ResponseHeader = new ResponseHeader() });
        }

        public override Task<LinkAccountResponse> Handle(LinkAccountRequest request)
        {

            var accountLink =
                _accountService.LinkAccount(request.PrimaryAccountIdentifier, request.LinkAccountIdentifier, request.LinkAccountType, request.EndDate);

            var result = new LinkAccountResponse
            {
                PrimaryAccountIdentifier = accountLink.PrimaryAccountIdentifier,
                LinkAccountIdentifier = accountLink.LinkAccountIdentifier,
                AccountLinkType = accountLink.AccountLinkType,
                StartDate = accountLink.StartDate?.ToString(),
                EndDate = accountLink.EndDate?.ToString(),

                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                }
            };

            return Task.FromResult(result);
        }

        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IAccountService _accountService;
    }
}
