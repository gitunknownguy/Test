﻿using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using NLog;
using RequestHandler.Core.Infrastructure;
using System;
using System.Threading.Tasks;

namespace RequestHandler.Logic.Handler
{
    public class AchFraudAccountsHandler : CommandHandlerBase<AchFraudAccountsRequest, AchFraudAccountsResponse>
    {
        private static readonly Logger _logger = LogManager.GetCurrentClassLogger();
        private readonly IAmmAccountStatusNotificationService _ammAccountStatusNotificationService;

        public AchFraudAccountsHandler(IAmmAccountStatusNotificationService ammAccountStatusNotificationService)
        {
            _ammAccountStatusNotificationService = ammAccountStatusNotificationService;
        }

        public override void SetDomainContext(AchFraudAccountsRequest request)
        {
        }

        public override Task<AchFraudAccountsResponse> VerifyIdentifiers(AchFraudAccountsRequest request)
        {
            return Task.FromResult(new AchFraudAccountsResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<AchFraudAccountsResponse> Handle(AchFraudAccountsRequest request)
        {
            try
            {
                foreach (var account in request.FraudAccounts)
                {
                    SendAmmAccountStatusNotification(
                        request.ProgramCode,
                        account.AccountIdentifier,
                        AmmAccountStatusNotificationType.SccAccountReturnedByAch,
                        account.BankAccountReferenceId);
                }

                var response = new AchFraudAccountsResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                };

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AchFraudAccountsResponse>(e, request));
            }
        }

        private void SendAmmAccountStatusNotification(
            string programCode,
            string accountIdentifier,
            AmmAccountStatusNotificationType notificationType,
            string bankAccountReferenceId)
        {
            var request = new AmmAccountStatusNotificationRequest
            {
                RequestHeader = new RequestHeader()
                {
                    RequestId = Guid.NewGuid()
                },
                ProgramCode = programCode,
                AccountIdentifier = accountIdentifier,
                NotificationType = notificationType,
                BankAccountReferenceId = bankAccountReferenceId
            };
            try
            {
                _ammAccountStatusNotificationService.PublishNotification(request).GetAwaiter().GetResult();
            }
            catch (Exception ex)
            {
                _logger.Info($"ProgramCode:{request?.ProgramCode}, AccountIdentifier:{request?.AccountIdentifier},BankAccountReferenceId:{request?.BankAccountReferenceId}: {ex.Message}");
            }
        }
    }
}
