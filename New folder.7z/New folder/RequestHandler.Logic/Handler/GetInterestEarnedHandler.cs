﻿using Gd.Bos.RequestHandler.Logic.Queue;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Service;
using RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Logic.Extension;

namespace RequestHandler.Logic.Handler
{
    public class GetInterestEarnedHandler : CommandHandlerBase<GetInterestEarnedRequest, GetInterestEarnedResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ITransactionService _transactionService;

        public GetInterestEarnedHandler(IValidateIdentifier validateIdentifier,
            ITransactionService transactionService)
        {
            _validateIdentifier = validateIdentifier;
            _transactionService = transactionService;
        }

        public override Task<GetInterestEarnedResponse> Handle(GetInterestEarnedRequest request)
        {
            var response = new GetInterestEarnedResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                }
            };

            try
            {
                response.InterestEarned = _transactionService.GetInterestFeeEarned(Guid.Parse(request.AccountIdentifier),
                    Guid.Parse(request.PurseIdentifier), request.StartDate, request.EndDate);
                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetInterestEarnedResponse>(e, request));
            }

        }

        public override void SetDomainContext(GetInterestEarnedRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetInterestEarnedResponse> VerifyIdentifiers(GetInterestEarnedRequest request)
        {
            _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
            return Task.FromResult(new GetInterestEarnedResponse { ResponseHeader = new ResponseHeader() });
        }
    }
}
