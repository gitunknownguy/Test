﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.ProgramFunding;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers.Exceptions;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Exceptions;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Contract.Exceptions;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Logic;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using RequestHandler.Core.Application;
using RequestHandler.Core.Domain.Services.GlobalFundTransfer.Contracts;
using FeeDefinitionOverride = RequestHandler.Core.Domain.Services.GlobalFundTransfer.Contracts.FeeDefinitionOverride;
using TransferEndPoint = RequestHandler.Core.Domain.Services.GlobalFundTransfer.Contracts.TransferEndPoint;
using TransferRequest = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.TransferRequest;
using TransferRoute = RequestHandler.Core.Domain.Services.GlobalFundTransfer.Contracts.TransferRoute;
using TransferType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class TransferHandler : CommandHandlerBase<TransferRequest, TransferResponse>
    {
        private readonly Core.Domain.Model.Account.IAccountRepository _accountRepository;
        private readonly Core.Domain.Model.Account.IAccountHolderRepository _accountHolderRepository;
        private readonly string _customTransactionDescriptionSuffix = "#";
        private readonly IBaasConfiguration _baasConfiguration;
        private readonly IGiftA2AInService _giftA2AInService;

        public TransferHandler(ITransferService transferService, IValidateIdentifier validateIdentifier,
            ILockService lockService, Core.Domain.Model.Account.IAccountRepository accountRepository, Core.Domain.Model.Account.IAccountHolderRepository accountHolderRepository,
            IBaasConfiguration baasConfiguration, IGiftA2AInService giftA2AInService)
        {
            _transferService = transferService;
            _validateIdentifier = validateIdentifier;
            _lockService = lockService;
            _accountRepository = accountRepository;
            _accountHolderRepository = accountHolderRepository;
            _baasConfiguration = baasConfiguration;
            _giftA2AInService = giftA2AInService;
        }

        public override void SetDomainContext(TransferRequest request)
        {
            DomainContext.Current.Initiator = request.Initiator;
            if (!string.IsNullOrEmpty(request.TransferRoute.SourceTransferEndPoint.Identifier)
                && request.TransferRoute.SourceTransferEndPoint.TransferEndPointType != EndpointType.Card)
                DomainContext.Current.AccountIdentifier = request.TransferRoute.SourceTransferEndPoint.Identifier;

            if (!string.IsNullOrEmpty(request.TransferRoute.TargetTransferEndPoint.Identifier)
                && request.TransferRoute.TargetTransferEndPoint.TransferEndPointType != EndpointType.Card)
                DomainContext.Current.ReferencedAccountIdentifier = request.TransferRoute.TargetTransferEndPoint.Identifier;

            if (request.TransferType == TransferType.Purse || request.TransferType == TransferType.CblPayment || request.TransferType == TransferType.CblRefund)
            {
                DomainContext.Current.AccountIdentifier = request.Initiator;
                DomainContext.Current.ReferencedAccountIdentifier = request.Initiator;
            }
            
            if(request.TransferType == TransferType.BillPay && request.AuthorizationType == Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.AuthorizationType.Reject)
            {
                DomainContext.Current.AccountIdentifier = request.Initiator;
                DomainContext.Current.ReferencedAccountIdentifier = request.Initiator;
            }

            if (request.TransferRoute.SourceTransferEndPoint.TransferEndPointType == EndpointType.ProgramFundingSource)
                DomainContext.Current.ProgramFundingIdentifier = ProgramFundingIdentifier.FromString(request.TransferRoute.SourceTransferEndPoint.Identifier);

            if (request.TransferRoute.TargetTransferEndPoint.TransferEndPointType == EndpointType.ProgramFundingSource)
                DomainContext.Current.ProgramFundingIdentifier = ProgramFundingIdentifier.FromString(request.TransferRoute.TargetTransferEndPoint.Identifier);
        }

        public override Task<TransferResponse> VerifyIdentifiers(TransferRequest request)
        {
            // GBOS-61089 bypassing validations for transfer types Disbursement External and A2AOut
            // Source and Target Identifiers are GSS link ids for these transfer types
            if (request.TransferType == TransferType.A2AIn)
            {
                try
                {
                    _validateIdentifier.ValidateAccountInHealthyStatus(request.TransferRoute.TargetTransferEndPoint.Identifier);
                }
                catch (Exception e)
                {
                    return Task.FromResult(e.HandleException<TransferResponse>(e, request));
                }
            }
            else if (request.TransferType != TransferType.DisbursementExternal
                && request.TransferType != TransferType.A2AOut
                && request.TransferType != TransferType.PartnerA2A  //GBOS-61490: Create new TransferTypes to support GFT
                && request.TransferType != TransferType.PartnerP2P
                && request.TransferType != TransferType.PartnerA2AIn)
            {
                try
                {
                    _validateIdentifier.ValidateProgramFunding(DomainContext.Current.ProgramFundingIdentifier,
                        DomainContext.Current.ProgramCode);
                    _validateIdentifier.ValidateProgramCode(DomainContext.Current.Initiator,
                        DomainContext.Current.ProgramCode);
                    _validateIdentifier.ValidatePartner_AccountIdProgramCode(DomainContext.Current.AccountIdentifier,
                        DomainContext.Current.ProgramCode);
                    _validateIdentifier.ValidatePartner_AccountIdProgramCode(
                        DomainContext.Current.ReferencedAccountIdentifier, DomainContext.Current.ProgramCode);
                }
                catch (Exception e)
                {
                    return Task.FromResult(e.HandleException<TransferResponse>(e, request));
                }
            }
            return Task.FromResult(new TransferResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override async Task<TransferResponse> ObtainLock(TransferRequest request)
        {
            try
            {
                var lockId = DomainContext.Current.Initiator.ToString();

                if (request.TransferType == TransferType.DisbursementIn)
                    lockId = DomainContext.Current.ReferencedAccountIdentifier.ToString();

                await _lockService.ObtainApiLock($"Transfer_{lockId}");

                return new TransferResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<TransferResponse>(e, request);
            }
        }

        public override Task<TransferResponse> Handle(TransferRequest request)
        {
            try
            {
                Tuple<TransferStatus, List<Account>> response = null;

                if (request.RequestHeader.RequestId == Guid.Empty)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId, $"{nameof(request)}.RequestHeader.RequestId must be specified");
                }

                if (string.IsNullOrEmpty(request.TransferIdentifier) || request.TransferIdentifier == UnspecifiedGuid)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier, $"{nameof(request)}.TransferIdentifier must be specified");
                }

                request.TransferIdentifier = request.TransferIdentifier.ToLower();

                if (request.TransferType != TransferType.Purse
                    && request.TransferType != TransferType.CblPayment
                    && request.TransferType != TransferType.CblRefund
                    && request.TransferType != TransferType.ECashSend
                    && request.TransferType != TransferType.IFTSend
                    && request.Initiator != request.TransferRoute.SourceTransferEndPoint.Identifier
                    && request.Initiator != request.TransferRoute.TargetTransferEndPoint.Identifier)
                    throw new InvalidInitiatorException("Initiator does not match the source or target account.");

                if (request.TransferType == TransferType.DisbursementIn)
                {
                    // validate the account
                    var status = _accountRepository.GetStatus(Guid.Parse(request.TransferRoute.TargetTransferEndPoint.Identifier));

                    if (status.accountStatus == Core.Domain.Model.Account.AccountStatus.Restricted)
                    {
                        if (status.accountStatusReasons.Any(s =>
                            s == Core.Domain.Model.Account.AccountStatusReason.healthy ||
                            s == Core.Domain.Model.Account.AccountStatusReason.spendDown ||
                            s == Core.Domain.Model.Account.AccountStatusReason.customerInitiatedSpendDown)
                         )
                        {
                            return Task.FromResult(new TransferResponse
                            {
                                ResponseHeader = new ResponseHeader
                                {
                                    ResponseId = request.RequestHeader.RequestId,
                                    StatusCode = 3,
                                    SubStatusCode = 100,
                                    Message = "Account is " + status.accountStatus
                                }
                            });
                        }
                    }
                }

                if (request.TransferType == TransferType.A2AIn)
                {
                    var a2aLimitationRequest = new CheckGiftA2AInLimitationRequest()
                    {
                        RequestHeader = request.RequestHeader,
                        AccountIdentifier = request.Initiator,
                        AdjustmentType = AdjustmentType.NetworkCardLoad,
                        Amount = request.TransferRoute.TransactionAmount,
                        ProgramCode = request.ProgramCode,
                    };

                    var restrictedResult = _giftA2AInService.CheckLimitation(a2aLimitationRequest);

                    if (restrictedResult.IsRestricted)
                    {
                        return Task.FromResult(new TransferResponse
                        {
                            ResponseHeader = new ResponseHeader
                            {
                                ResponseId = request.RequestHeader.RequestId,
                                StatusCode = 4200,
                                SubStatusCode = restrictedResult.LimitType == Shared.Common.Logic.FeatureLimitsFees.Contract.Enum.LimitType.TransferIn ? 977 : 991,
                                Message = restrictedResult.ResponseHeader.Message
                            },
                            TransferStatus = TransferStatus.Failed.ToString(),
                        });
                    }
                }

                int statusCode = 0;

                try
                {
                    switch (request.TransferType)
                    {
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.DisbursementIn:
                            response = HandleDisbursementIn(request);
                            break;
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.DisbursementOut:
                            response = HandleDisbursementOut(request);
                            break;
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.AchOut:
                            response = HandleAchOut(request);
                            break;
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.AchPull:
                            response = HandleAchPull(request);
                            break;
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.Purse:
                            response = HandlePurseToPurse(request);
                            break;
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.CblPayment:
                            response = HandleCblPayment(request);
                            break;
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.CblPaymentByAchPull:
                            response = HandleCblPaymentByAchPull(request);
                            break;
                        case TransferType.CblRefund:
                            response = HandleCblRefund(request);
                            break;
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.PeerPayment:
                            response = HandlePeerPayments(request);
                            break;
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.ECashLoad:
                            response = HandleECashLoad(request);
                            break;
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.BillPay:
                            response = HandleBillpay(request);
                            break;
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.ECashSend:
                            response = HandleECashSend(request);
                            break;
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.IFTLoad:
                            response = HandleIFTLoad(request);
                            break;
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.IFTSend:
                            response = HandleIFTSend(request);
                            break;
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.IFTOut:
                            response = HandleIFTOut(request);
                            break;
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.SwipeReload:
                            response = HandleSwipeReload(request);
                            break;
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.MrdcTransfer:
                            var responseMrdcTransfer = HandleMrdcTransfer(request);
                            return Task.FromResult(new TransferResponse
                            {
                                ResponseHeader = new ResponseHeader
                                {
                                    ResponseId = request.RequestHeader.RequestId,
                                    StatusCode = responseMrdcTransfer.Item4.StatusCode,
                                    SubStatusCode = responseMrdcTransfer.Item4.SubStatusCode,
                                    Message = responseMrdcTransfer.Item4.Message
                                },
                                TransferIdentifier = request.TransferIdentifier,
                                TransferStatus = responseMrdcTransfer.Item1.ToString().ToLower(),
                                Accounts = responseMrdcTransfer.Item2,
                                CheckDeposit = responseMrdcTransfer.Item3
                            });
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.SCCPayment:
                            response = HandleSccPayment(request);
                            break;
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.SccPaymentByAchPull:
                            response = HandleSccPaymentByAchPull(request);
                            break;
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.SCCFunding:
                            response = HandleSccFunding(request);
                            break;
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.CreditLineIncrease:
                            response = TransferCreditLineIncrease(request);
                            break;
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.CreditLineDecrease:
                            response = HandleSccWithdrawal(request);
                            break;
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.DisbursementExternal:
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.A2AOut:
                        //GBOS-61490: Create new TransferTypes to support GFT
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.PartnerA2A:
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.PartnerP2P:
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.PartnerA2AIn:
                            response = HandleDisbursementExternal(request);
                            break;
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.A2AIn:
                            request.TransferRoute.TargetTransferEndPoint.TransferEndPointType = EndpointType.BaaSAccount;
                            var responseA2AIn = HandleDisbursementExternalOfA2AIn(request);
                            if (responseA2AIn.Item2 == null)
                            {
                                response = new Tuple<TransferStatus, List<Account>>(responseA2AIn.Item1, null);
                            }
                            else
                            {
                                var exceptionResponse = responseA2AIn.Item2.HandleException<TransferResponse>(responseA2AIn.Item2, request);
                                exceptionResponse.TransferIdentifier = request.TransferIdentifier;
                                exceptionResponse.TransferStatus = responseA2AIn.Item1.GetDescription().ToLower();
                                return Task.FromResult(exceptionResponse);
                            }
                            break;
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.UnLoad:
                            response = HandleUnLoad(request);
                            break;
                        case Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.InitialLoad:
                            response = HandleInitialLoad(request);
                            break;
                        default:
                            throw new InvalidTransferTypeException($"Invalid Transfer Type.");
                    }
                }
                catch (TransferException ex)
                {
                    if (ex.IsPending && (request.TransferType == TransferType.DisbursementIn || request.TransferType == TransferType.DisbursementOut))
                        statusCode = 12;
                    else
                        throw;
                }
                catch (NullCustomerReferenceIdException e)
                {
                    return Task.FromResult(new TransferResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = e.Code,
                            SubStatusCode = e.SubCode,
                            Message = e.Message
                        }
                    });
                }

                if (response != null && response.Item1 == TransferStatus.Pending && (request.TransferType == TransferType.DisbursementIn || request.TransferType == TransferType.DisbursementOut))
                    statusCode = 12;

                return Task.FromResult(new TransferResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = statusCode,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                    TransferIdentifier = request.TransferIdentifier,
                    TransferStatus = response?.Item1.GetDescription().ToLower(),
                    Accounts = response?.Item2
                });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<TransferResponse>(e, request));
            }
        }

        private Tuple<TransferStatus, List<Account>> HandleDisbursementIn(TransferRequest request)
        {
            TransferRequestValidation.HandleDisbursementInValidation(request);

            if (!string.IsNullOrWhiteSpace(request.TransferDescription))
            {
                request.TransferDescription = request.TransferDescription + _customTransactionDescriptionSuffix;
            }

            return _transferService.TransferDisbursementIn(
                request.TransferIdentifier,
                request.Initiator,
                request.AuthorizationType.ToString(),
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.SourceTransferEndPoint.Identifier,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.ProgramCode,
                request.PartnerReferenceData,
                false,
                request.TransferDescription);
        }

        private Tuple<TransferStatus, List<Account>> HandleDisbursementOut(TransferRequest request)
        {
            TransferRequestValidation.HandleDisbursementOutValidation(request);

            if (!string.IsNullOrWhiteSpace(request.TransferDescription))
            {
                request.TransferDescription = request.TransferDescription + _customTransactionDescriptionSuffix;
            }

            return _transferService.TransferDisbursementOut(
                request.TransferIdentifier,
                request.Initiator,
                request.AuthorizationType.ToString(),
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.SourceTransferEndPoint.Identifier,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.ProgramCode,
                request.PartnerReferenceData,
                false,
                request.TransferDescription);
        }

        private Tuple<TransferStatus, List<Account>> HandleAchOut(TransferRequest request)
        {
            TransferRequestValidation.HandleAchOutValidation(request);

            if (!string.IsNullOrWhiteSpace(request.TransferDescription))
            {
                request.TransferDescription = request.TransferDescription + _customTransactionDescriptionSuffix;
            }

            BankAccount bankAccount = request.TransferRoute.TargetTransferEndPoint.BankAccount;

            return _transferService.TransferAchOut(
                request.TransferIdentifier,
                request.Initiator,
                request.AuthorizationType.ToString(),
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.SourceTransferEndPoint.Identifier,
                request.TransferRoute.RecurringType,
                request.TransferRoute.BankAccountVerificationMethod,
                request.TransferRoute.BankAccountVerificationDate,
                request.TransferRoute.BankAccountAuthorizationDate,
                bankAccount?.AccountNumber ?? String.Empty,
                bankAccount?.RoutingNumber ?? String.Empty,
                bankAccount?.BankName ?? String.Empty,
                bankAccount?.FirstName ?? String.Empty,
                bankAccount?.LastName ?? String.Empty,
                bankAccount?.BusinessName ?? String.Empty,
                bankAccount?.AccountType ?? String.Empty,
                request.ProgramCode,
                false,
                request.UserIdentifier,
                request.TransferRoute.TargetTransferEndPoint.BankAccountReferenceId,
                request.TransferDescription,
                request.DeviceType);
        }


        private Tuple<TransferStatus, List<Account>> HandleAchPull(TransferRequest request)
        {
            TransferRequestValidation.HandleAchPullValidation(request);

            if (!string.IsNullOrWhiteSpace(request.TransferDescription))
            {
                request.TransferDescription = request.TransferDescription + _customTransactionDescriptionSuffix;
            }

            Core.Domain.Model.Account.BankAccount bankAccount;
            if (String.IsNullOrEmpty(request.TransferRoute.SourceTransferEndPoint.BankAccountReferenceId))
            {
                bankAccount = new Core.Domain.Model.Account.BankAccount()
                {
                    AccountNumber = request.TransferRoute.SourceTransferEndPoint.BankAccount.AccountNumber,
                    RoutingNumber = request.TransferRoute.SourceTransferEndPoint.BankAccount.RoutingNumber,
                    AccountType = request.TransferRoute.SourceTransferEndPoint.BankAccount.AccountType,
                    BankName = request.TransferRoute.SourceTransferEndPoint.BankAccount.BankName,
                    BusinessName = request.TransferRoute.SourceTransferEndPoint.BankAccount.BusinessName,
                    FirstName = request.TransferRoute.SourceTransferEndPoint.BankAccount.FirstName,
                    LastName = request.TransferRoute.SourceTransferEndPoint.BankAccount.LastName
                };
            }
            else
            {
                bankAccount = new Core.Domain.Model.Account.BankAccount()
                {
                    BankAccountReferenceId = request.TransferRoute.SourceTransferEndPoint.BankAccountReferenceId
                };
            }

            return _transferService.TransferAchPull(
                request.TransferIdentifier,
                request.Initiator,
                request.AuthorizationType.ToString(),
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.TransferRoute.RecurringType,
                request.TransferRoute.BankAccountVerificationMethod,
                request.TransferRoute.BankAccountVerificationDate,
                request.TransferRoute.BankAccountAuthorizationDate,
                bankAccount,
                request.VerificationIdentifier,
                request.ProgramCode,
                false,
                request.TransferDescription,
                request.TransferRoute.DeliveryType,
                request.DeviceType,
                request.UserIdentifier);
        }

        private Tuple<TransferStatus, List<Account>> HandleCblPaymentByAchPull(TransferRequest request)
        {
            TransferRequestValidation.HandleAchPullValidation(request);

            if (!string.IsNullOrWhiteSpace(request.TransferDescription))
            {
                request.TransferDescription = request.TransferDescription + _customTransactionDescriptionSuffix;
            }

            Core.Domain.Model.Account.BankAccount bankAccount;
            if (String.IsNullOrEmpty(request.TransferRoute.SourceTransferEndPoint.BankAccountReferenceId))
            {
                bankAccount = new Core.Domain.Model.Account.BankAccount()
                {
                    AccountNumber = request.TransferRoute.SourceTransferEndPoint.BankAccount.AccountNumber,
                    RoutingNumber = request.TransferRoute.SourceTransferEndPoint.BankAccount.RoutingNumber,
                    AccountType = request.TransferRoute.SourceTransferEndPoint.BankAccount.AccountType,
                    BankName = request.TransferRoute.SourceTransferEndPoint.BankAccount.BankName,
                    BusinessName = request.TransferRoute.SourceTransferEndPoint.BankAccount.BusinessName,
                    FirstName = request.TransferRoute.SourceTransferEndPoint.BankAccount.FirstName,
                    LastName = request.TransferRoute.SourceTransferEndPoint.BankAccount.LastName
                };
            }
            else
            {
                bankAccount = new Core.Domain.Model.Account.BankAccount()
                {
                    BankAccountReferenceId = request.TransferRoute.SourceTransferEndPoint.BankAccountReferenceId
                };
            }

            return _transferService.TransferCblPaymentByAchPull(
                request.TransferIdentifier,
                request.Initiator,
                request.AuthorizationType.ToString(),
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.TransferRoute.RecurringType,
                request.TransferRoute.BankAccountVerificationMethod,
                request.TransferRoute.BankAccountVerificationDate,
                request.TransferRoute.BankAccountAuthorizationDate,
                bankAccount,
                request.VerificationIdentifier,
                request.ProgramCode,
                false,
                request.TransferDescription,
                request.TransferRoute.DeliveryType);
        }

        private Tuple<TransferStatus, List<Account>> HandleSccPaymentByAchPull(TransferRequest request)
        {
            TransferRequestValidation.HandleAchPullValidation(request);

            if (request.SourceSystem == 0)
                request.SourceSystem = SourceSystem.Partner;

            if (!string.IsNullOrWhiteSpace(request.TransferDescription))
            {
                request.TransferDescription = request.TransferDescription + _customTransactionDescriptionSuffix;
            }

            return _transferService.TransferSccPaymentByAchPull(
                request.TransferIdentifier,
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.SourceTransferEndPoint.BankAccountReferenceId,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.ProgramCode,
                false,
                request.SourceSystem == SourceSystem.AMM,
                request.SourceSystem, request.TimezoneOffset);
        }


        private Tuple<TransferStatus, List<Account>, CheckDeposit, ResponseHeader> HandleMrdcTransfer(TransferRequest request)
        {
            TransferRequestValidation.HandleMrdcTransferValidation(request);

            Check check = request.TransferRoute.SourceTransferEndPoint.Check;

            var response = _transferService.TransferMrdc(
                request.TransferIdentifier,
                request.Initiator,
                request.AuthorizationType.ToString(),
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.RequestHeader,
                request.ProgramCode,
                check,
                false,
                request.TransferRoute.DeliveryType);

            Tuple<TransferStatus, List<Account>, CheckDeposit, ResponseHeader> result = new Tuple<TransferStatus, List<Account>, CheckDeposit, ResponseHeader>(response.Item1, response.Item2, response.Item3, response.Item5);
            return result;
        }

        private Tuple<TransferStatus, List<Account>> HandleSwipeReload(TransferRequest request)
        {
            TransferRequestValidation.HandleSwipeReloadValidation(request);

            if (request.IsReversal)
            {
                if (_baasConfiguration.IsAllowNegativeBalanceInReversal(request.ProgramCode))
                {
                    return _transferService.TransferSwipeReloadReversalForPLS(
                       request.TransferIdentifier,
                       request.Initiator,
                       request.TransferRoute.TransactionAmount,
                       request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.MerchantName,
                       request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.StoreNumber,
                       request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.City,
                       request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.State,
                       request.TransferRoute.SourceTransferEndPoint.Identifier,
                       request.ProgramCode,
                       false,
                       request.TransferDescription);
                }
                else
                {
                    return _transferService.TransferSwipeReloadReversal(
                        request.TransferIdentifier,
                        request.Initiator,
                        request.TransferRoute.TransactionAmount,
                        request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.MerchantName,
                        request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.StoreNumber,
                        request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.City,
                        request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.State,
                        request.TransferRoute.SourceTransferEndPoint.Identifier,
                        request.ProgramCode,
                        false,
                        request.TransferDescription);
                }
            }

            return _transferService.TransferSwipeReload(
                request.TransferIdentifier,
                request.Initiator,
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.MerchantName,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.StoreNumber,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.City,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.State,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.ProgramCode,
                false,
                request.TransferDescription);
        }

        private Tuple<TransferStatus, List<Account>> HandlePurseToPurse(TransferRequest request)
        {
            TransferRequestValidation.HandlePurseToPurseValidation(request);

            if (request.SourceSystem != 0)
            {

                if (!(request.SourceSystem == SourceSystem.Partner
                      || request.SourceSystem == SourceSystem.AMM
                      || request.SourceSystem == SourceSystem.IVR
                      || request.SourceSystem == SourceSystem.CRM))
                    throw new TransferValidationException(3, 121, "Invalid sourceSystemType.");
                if (request.SourceSystem == SourceSystem.AMM)
                {
                    return _transferService.TransferPurseToPurse(
                        request.TransferIdentifier,
                        request.Initiator,
                        request.TransferRoute.TransactionAmount,
                        request.TransferRoute.SourceTransferEndPoint.Identifier,
                        request.TransferRoute.TargetTransferEndPoint.Identifier,
                        request.ProgramCode,
                        false,
                        true,
                        request.SourceSystem,
                        false,
                        request.IsRoundUp,
                        request.LinkedTransactionIdentifier,
                        request.TransferDescription,
                        request.SourceTransactionIdentifier);
                }
                else
                {
                    return _transferService.TransferPurseToPurse(
                        request.TransferIdentifier,
                        request.Initiator,
                        request.TransferRoute.TransactionAmount,
                        request.TransferRoute.SourceTransferEndPoint.Identifier,
                        request.TransferRoute.TargetTransferEndPoint.Identifier,
                        request.ProgramCode,
                        false,
                        false,
                        request.SourceSystem,
                        false
                    );
                }
            }

            return _transferService.TransferPurseToPurse(
                request.TransferIdentifier,
                request.Initiator,
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.SourceTransferEndPoint.Identifier,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.ProgramCode,
                false
               );
        }

        private Tuple<TransferStatus, List<Account>> HandleCblPayment(TransferRequest request)
        {
            bool isSystemGenerated;
            var sourceSystem = request.SourceSystem;
            switch (request.SourceSystem)
            {
                case SourceSystem.Partner:
                case SourceSystem.CRM:
                case SourceSystem.IVR:
                case SourceSystem.Web:
                case SourceSystem.App:
                    isSystemGenerated = false;
                    break;
                case SourceSystem.AMM:
                    isSystemGenerated = true;
                    break;
                default:
                    isSystemGenerated = false;
                    sourceSystem = SourceSystem.Partner;
                    break;
            }

            return _transferService.TransferCblPayment(
               request.TransferIdentifier,
               request.Initiator,
               request.TransferRoute.TransactionAmount,
               request.ProgramCode,
               false,
               isSystemGenerated,
               sourceSystem
              );
        }

        private Tuple<TransferStatus, List<Account>> HandleCblRefund(TransferRequest request)
        {
            bool isSystemGenerated;
            var sourceSystem = request.SourceSystem;
            switch (request.SourceSystem)
            {
                case SourceSystem.Partner:
                case SourceSystem.CRM:
                case SourceSystem.IVR:
                case SourceSystem.Web:
                case SourceSystem.App:
                    isSystemGenerated = false;
                    break;
                case SourceSystem.AMM:
                    isSystemGenerated = true;
                    break;
                default:
                    isSystemGenerated = false;
                    sourceSystem = SourceSystem.Partner;
                    break;
            }

            return _transferService.TransferCblRefund(
                request.TransferIdentifier,
                request.Initiator,
                request.TransferRoute.TransactionAmount,
                request.ProgramCode,
                false,
                isSystemGenerated,
                sourceSystem
            );
        }

        private Tuple<TransferStatus, List<Account>> HandlePeerPayments(TransferRequest request)
        {
            TransferRequestValidation.HandlePeerPaymentValidation(request);

            if (request.SourceSystem == 0)
                request.SourceSystem = SourceSystem.Partner;

            return _transferService.PeerPayments(
                request.Initiator,
                request.TransferIdentifier,
                request.AuthorizationType,
                request.Memo,
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.SourceTransferEndPoint.Identifier,
                request.TransferRoute.SourceTransferEndPoint.HandleData?.Handle,
                request.TransferRoute.SourceTransferEndPoint.HandleData?.FirstName,
                request.TransferRoute.SourceTransferEndPoint.HandleData?.LastName,
                request.TransferRoute.SourceTransferEndPoint.HandleData?.UserName,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.TransferRoute.TargetTransferEndPoint.TransferEndPointType,
                request.TransferRoute.TargetTransferEndPoint.HandleData?.Handle,
                request.TransferRoute.TargetTransferEndPoint.HandleData?.FirstName,
                request.TransferRoute.TargetTransferEndPoint.HandleData?.LastName,
                request.TransferRoute.TargetTransferEndPoint.HandleData?.UserName,
                request.ProgramCode,               
                false,
                request.DeviceDetails,
                request.SourceSystem == SourceSystem.AMM,
                request.SourceSystem);
        }

        private Tuple<TransferStatus, List<Account>> HandleECashLoad(TransferRequest request)
        {
            TransferRequestValidation.HandleECashLoadValidation(request);

            return _transferService.TransferECashLoad(
                request.TransferIdentifier,
                request.Initiator,
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.MerchantName,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.StoreNumber,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.City,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.State,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.ProgramCode,
                false);
        }

        private Tuple<TransferStatus, List<Account>> HandleECashSend(TransferRequest request)
        {
            TransferRequestValidation.HandleECashSendValidation(request);

            return _transferService.TransferECashSend(
                request.TransferIdentifier,
                request.Initiator,
                request.AuthorizationType,
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.MerchantName,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.StoreNumber,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.City,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.State,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.TransferRoute.TargetTransferEndPoint.TransferEndPointType,
                request.TransferRoute.TargetTransferEndPoint.HandleData?.Handle,
                request.TransferRoute.TargetTransferEndPoint.HandleData?.FirstName,
                request.TransferRoute.TargetTransferEndPoint.HandleData?.LastName,
                request.TransferRoute.TargetTransferEndPoint.HandleData?.UserName,
                request.ProgramCode,
                request.Memo,
                false);
        }

        private Tuple<TransferStatus, List<Account>> HandleIFTLoad(TransferRequest request)
        {
            TransferRequestValidation.HandleIFTLoadValidation(request);

            return _transferService.TransferIFTLoad(
                request.Initiator,
                request.TransferIdentifier,
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.SourceTransferEndPoint.Identifier,
                request.TransferRoute.SourceTransferEndPoint.CardData.Cvv,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.ProgramCode,
                false,
                request.FraudData,
                request.AuthorizationType);
        }

        private Tuple<TransferStatus, List<Account>> HandleIFTSend(TransferRequest request)
        {
            TransferRequestValidation.HandleIFTSendValidation(request);

            return _transferService.TransferIFTSend(
                request.Initiator,
                request.TransferIdentifier,
                request.TransferRoute.TransactionAmount,
                request.AuthorizationType,
                request.TransferRoute.SourceTransferEndPoint.Identifier,
                request.TransferRoute.SourceTransferEndPoint.CardData.Cvv,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.TransferRoute.TargetTransferEndPoint.TransferEndPointType,
                request.TransferRoute.TargetTransferEndPoint.HandleData?.Handle,
                request.TransferRoute.TargetTransferEndPoint.HandleData?.FirstName,
                request.TransferRoute.TargetTransferEndPoint.HandleData?.LastName,
                request.TransferRoute.TargetTransferEndPoint.HandleData?.UserName,
                request.ProgramCode,
                request.Memo,
                false,
                request.FraudData);
        }

        private Tuple<TransferStatus, List<Account>> HandleIFTOut(TransferRequest request)
        {
            TransferRequestValidation.HandleIFTOutValidation(request);

            return _transferService.TransferIFTOut(
                request.Initiator,
                request.TransferIdentifier,
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.SourceTransferEndPoint.Identifier,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.TransferRoute.TargetTransferEndPoint.CardData?.Cvv,
                request.ProgramCode,
                false);
        }

        private Tuple<TransferStatus, List<Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Account>> HandleBillpay(TransferRequest request)
        {
            if (request.IsReversal)
            {
                return
                    _transferService.ReverseBillPay(
                        request.TransferIdentifier,
                        request.TransferRoute.TargetTransferEndPoint.Identifier,
                        request.TransferRoute.SourceTransferEndPoint.BillPayData?.PaymentIdentifier,
                        request.AuthorizationType.ToString(),
                        request.ProgramCode
                        );



            }

            bool sendFailurePN = request.TransferRoute?.TargetTransferEndPoint?.BillPayData?.SendFailurePN == true;

            return
                _transferService.TransferBillPay(
                    request.TransferIdentifier,
                    request.Initiator,
                    request.TransferRoute.TargetTransferEndPoint.BillPayData?.PaymentIdentifier,
                    request.AuthorizationType.ToString(),
                    request.TransferRoute.TransactionAmount,
                    request.TransferRoute.SourceTransferEndPoint.Identifier,
                    request.ProgramCode,
                    request.TransferRoute?.TargetTransferEndPoint?.BillPayData?.PayeeName,
                    sendFailurePN);
        }

        private Tuple<TransferStatus, List<Account>> HandleSccPayment(TransferRequest request)
        {
            TransferRequestValidation.HandleSCCPaymentValidation(request);

            if (request.SourceSystem == 0)
                request.SourceSystem = SourceSystem.Partner;

            return _transferService.TransferSccPayment(
                request.Initiator,
                request.TransferIdentifier,
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.SourceTransferEndPoint.Identifier,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.ProgramCode,
                false,
                request.SourceSystem == SourceSystem.AMM,
                request.SourceSystem, request.TimezoneOffset);
        }

        private Tuple<TransferStatus, List<Account>> HandleSccFunding(TransferRequest request)
        {
            TransferRequestValidation.HandleSCCFundingValidation(request);

            return _transferService.TransferSCCFunding(
                request.TransferIdentifier,
                request.Initiator,
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.SourceTransferEndPoint.Identifier,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.ProgramCode,
                request.AuthorizationType,
                false,
                request.RequestHeader.RequestId.ToString());
        }

        private Tuple<TransferStatus, List<Account>> HandleSccWithdrawal(TransferRequest request)
        {
            TransferRequestValidation.HandleSCCFundingValidation(request);

            return _transferService.TransferSccWithdrawal(
                request.TransferIdentifier,
                request.Initiator,
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.SourceTransferEndPoint.Identifier,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.ProgramCode,
                request.AuthorizationType,
                false,
                request.RequestHeader.RequestId.ToString());
        }
        private Tuple<TransferStatus, List<Account>> HandleUnLoad(TransferRequest request)
        {
            TransferRequestValidation.HandleUnLoadValidation(request);

            if (request.IsReversal)
                return _transferService.TransferUnLoadReversal(
                    request.TransferIdentifier,
                    request.Initiator,
                    request.TransferRoute.TransactionAmount,
                    request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.MerchantName,
                    request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.StoreNumber,
                    request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.City,
                    request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.State,
                    request.TransferRoute.TargetTransferEndPoint.Identifier,
                    request.ProgramCode,
                    false,
                    request.TransferDescription);

            return _transferService.TransferUnLoad(
                request.TransferIdentifier,
                request.Initiator,
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.MerchantName,
                request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.StoreNumber,
                request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.City,
                request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.State,
                request.TransferRoute.SourceTransferEndPoint.Identifier,
                request.ProgramCode,
                false,
                request.TransferDescription);
        }
        private Tuple<TransferStatus, List<Account>> HandleInitialLoad(TransferRequest request)
        {
            TransferRequestValidation.HandleInitialLoadValidation(request);

            if (request.IsReversal)
                return _transferService.TransferInitialLoadReversal(
                    request.TransferIdentifier,
                    request.Initiator,
                    request.TransferRoute.TransactionAmount,
                    request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.MerchantName,
                    request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.StoreNumber,
                    request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.City,
                    request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.State,
                    request.TransferRoute.SourceTransferEndPoint.Identifier,
                    request.ProgramCode,
                    false,
                    request.TransferDescription);

            return _transferService.TransferInitialLoad(
                request.TransferIdentifier,
                request.Initiator,
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.MerchantName,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.StoreNumber,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.City,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.State,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.ProgramCode,
                false,
                request.TransferDescription);
        }
        private Tuple<TransferStatus, List<Account>> HandleDisbursementExternal(TransferRequest request)
        {
            var gftTransferRequest = MapCreateFundTransferRequest(request);

            var forterVerificationConfig = _baasConfiguration.GetForterVerificationConfiguration(request.ProgramCode, request.TransferType.ToString());
            if (forterVerificationConfig != null && forterVerificationConfig.Enabled.Value)
            {
                Core.Domain.Model.Account.AccountHolder accountholder = _accountHolderRepository.GetAccountHoldersByAccountIdentifier(request.Initiator).FirstOrDefault(x => x.IsPrimary);
                if (accountholder != null)
                {
                    gftTransferRequest.AccountHolderIdentifier = accountholder.AccountHolderIdentifier.ToString();
                }
            }

            var gftResponse = _transferService.CreateFundTransfer(gftTransferRequest);

            if (gftResponse == null)
            {
                throw new TransferException(
                    new BaseException(4214, 1514,
                        "Response is null or details are empty from down stream service"));
            }

            if (gftResponse.ResponseDetails != null && gftResponse.ResponseDetails.Count > 0
                                                    && gftResponse.ResponseDetails.First().Code != 0)
            {
                throw new TransferException(
                    new BaseException(gftResponse.ResponseDetails.First().Code,
                        gftResponse.ResponseDetails.First().SubCode,
                        gftResponse.ResponseDetails.First().Description));
            }
            TransferStatus status = TransferStatus.NotStarted;
            switch (gftResponse.Transfer?.TransferStatus.ToLower())
            {
                case "pending":
                    status = TransferStatus.Pending;
                    break;
                case "completed":
                    status = TransferStatus.Completed;
                    break;
                case "failed":
                    status = TransferStatus.Failed;
                    break;
                case "declined":
                    status = TransferStatus.Declined;
                    break;
                case "cancelled":
                    status = TransferStatus.Canceled;
                    break;
                case "expired":
                    status = TransferStatus.Expired;
                    break;
                case "pendingcomplete":
                case "pending complete":
                    {
                        status = TransferStatus.PendingComplete;
                        break;
                    }
                case "pendingvoid":
                case "pending void":
                    {
                        status = TransferStatus.PendingVoid;
                        break;
                    }
            }

            return new Tuple<TransferStatus, List<Account>>(status, null);
        }

        private Tuple<TransferStatus, TransferException> HandleDisbursementExternalOfA2AIn(TransferRequest request)
        {
            var gftTransferRequest = MapCreateFundTransferRequest(request);

            var forterVerificationConfig = _baasConfiguration.GetForterVerificationConfiguration(request.ProgramCode, request.TransferType.ToString());
            if (forterVerificationConfig != null && forterVerificationConfig.Enabled.Value)
            {
                Core.Domain.Model.Account.AccountHolder accountholder = _accountHolderRepository.GetAccountHoldersByAccountIdentifier(request.Initiator).Find(x => x.IsPrimary);
                if (accountholder != null)
                {
                    gftTransferRequest.AccountHolderIdentifier = accountholder.AccountHolderIdentifier.ToString();
                }
            }

            var gftResponse = _transferService.CreateFundTransfer(gftTransferRequest);

            if (gftResponse == null)
            {
                throw new TransferException(
                    new BaseException(4214, 1514,
                        "Response is null or details are empty from down stream service"));
            }

            TransferStatus status = TransferStatus.NotStarted;
            switch (gftResponse.Transfer?.TransferStatus.ToLower())
            {
                case "pending":
                    status = TransferStatus.Pending;
                    break;
                case "completed":
                    status = TransferStatus.Completed;
                    break;
                case "failed":
                    status = TransferStatus.Failed;
                    break;
                case "declined":
                    status = TransferStatus.Declined;
                    break;
                case "canceled":
                    status = TransferStatus.Canceled;
                    break;
                case "expired":
                    status = TransferStatus.Expired;
                    break;
                case "pendingcomplete":
                case "pending complete":
                    {
                        status = TransferStatus.PendingComplete;
                        break;
                    }
                case "pendingvoid":
                case "pending void":
                    {
                        status = TransferStatus.PendingVoid;
                        break;
                    }
            }

            TransferException errorInfo = null;
            if (gftResponse.ResponseDetails != null && gftResponse.ResponseDetails.Count > 0
                                                    && gftResponse.ResponseDetails[0].Code != 0)
            {
                errorInfo = new TransferException(
                    new BaseException(gftResponse.ResponseDetails[0].Code,
                        gftResponse.ResponseDetails[0].SubCode,
                        gftResponse.ResponseDetails[0].Description));
            }

            return new Tuple<TransferStatus, TransferException>(status, errorInfo);
        }

        private static CreateFundTransferRequest MapCreateFundTransferRequest(TransferRequest request)
        {
            CreateFundTransferRequest gftTransferRequest = new CreateFundTransferRequest
            {
                ProgramCode = request.ProgramCode,
                RequestId = request.RequestHeader.RequestId.ToString(),
                Initiator = request.Initiator,
                TransferId = request.TransferIdentifier,
                TransferType = Enum.GetName(typeof(TransferType), request.TransferType),
                TransferRoute = new TransferRoute()
                {
                    TransactionAmount = request.TransferRoute.TransactionAmount,
                    TransactionDescription = request.TransferDescription,
                    WaiveFee = request.TransferRoute.WaiveFee,
                    FeeDefinitionOverride = request.TransferRoute.FeeDefinitionOverride == null ? null : new FeeDefinitionOverride
                    {
                        FixedFeeAmount = request.TransferRoute.FeeDefinitionOverride.FixedFeeAmount,
                        PercentageFeeAmount = request.TransferRoute.FeeDefinitionOverride.PercentageFeeAmount,
                        MinFeeAmount = request.TransferRoute.FeeDefinitionOverride.MinFeeAmount,
                        MaxFeeAmount = request.TransferRoute.FeeDefinitionOverride.MaxFeeAmount
                    },
                    PartnerReferenceData = request.PartnerReferenceData,
                    SourceTransferEndPoint = new TransferEndPoint
                    {
                        Currency = request.TransferRoute.SourceTransferEndPoint.Currency,
                        Identifier = request.TransferRoute.SourceTransferEndPoint.Identifier,
                        TransferEndPointType = request.TransferRoute.SourceTransferEndPoint.TransferEndPointType.ToString(),
                    },
                    TargetTransferEndPoint = new TransferEndPoint
                    {
                        Currency = request.TransferRoute.TargetTransferEndPoint.Currency,
                        Identifier = request.TransferRoute.TargetTransferEndPoint.Identifier,
                        TransferEndPointType = request.TransferRoute.TargetTransferEndPoint.TransferEndPointType.ToString(),
                    }
                },
                FraudData = request.FraudData
            };

            return gftTransferRequest;
        }

        private Tuple<TransferStatus, List<Account>> TransferCreditLineIncrease(TransferRequest request)
        {
            TransferRequestValidation.HandleCreditLineIncrease(request);

            return _transferService.TransferCreditLineIncrease(
                request.TransferIdentifier,
                request.Initiator,
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.SourceTransferEndPoint.Identifier,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.ProgramCode,
                request.AuthorizationType,
                false,
                request.RequestHeader.RequestId.ToString());
        }


        public override void ReleaseLock(TransferRequest request)
        {
            var lockId = DomainContext.Current.Initiator.ToString();

            if (request.TransferType == TransferType.DisbursementIn)
                lockId = DomainContext.Current.ReferencedAccountIdentifier.ToString();
            _lockService.ReleaseApiLock("Transfer_" + lockId);
        }

        private readonly ITransferService _transferService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ILockService _lockService;
        private static readonly string UnspecifiedGuid = Guid.Empty.ToString();
    }
}


