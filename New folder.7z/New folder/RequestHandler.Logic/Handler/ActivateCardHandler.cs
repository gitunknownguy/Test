﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment.Exceptions;
using Gd.Bos.RequestHandler.Core.Domain.Services.Dcpp;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using RequestHandler.Logic;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Logic.Exceptions;
using System.Linq;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request;
using NLog;
using System.Collections.Generic;
using Gd.Bos.Shared.Common.Core.CareCoreApi.Contract.Data.Enum;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Newtonsoft.Json;
using RequestHandler.Core.Application;
using RequestHandler.Core.Domain.Services.RetailCard;
using RequestHandler.Core.Domain.Services.RetailCard.Model;
using AccountHolderCure = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolderCure;
using CardExpirationDate = Gd.Bos.RequestHandler.Core.Domain.Services.Dcpp.CardExpirationDate;

namespace Gd.Bos.RequestHandler.Logic.Handler
{

    public class ActivateCardHandler : CommandHandlerBase<ActivateCardRequest, ActivateCardResponse>
    {
        private readonly IPaymentInstrumentService _paymentInstrumentService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IUserService _userService;
        private readonly ITokenizerService _tokenizerService;
        private readonly IAccountService _accountService;
        private readonly IVerificationService _verificationService;
        private readonly IPaymentIdentifierRepository _paymentIdentifierRepository;
        private readonly IAccountRepository _accountRepository;
        private readonly IDcppService _dcppService;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        private readonly IWelcomeNotificationService _welcomeNotificationService;
        private readonly IProductRepository _productRepository;
        private readonly ICustomerNotificationService _customerNotificationService;
        private readonly IAccountHolderRepository _accountHolderRepository;
        private readonly IRetailCardService _retailCardService;
        private readonly IBaasConfiguration _baasConfiguration;

        public ActivateCardHandler(IPaymentInstrumentService paymentInstrumentService, IValidateIdentifier validateIdentifier, IAccountService accountService, IUserService userService,
            ITokenizerService tokenizerService, IVerificationService verificationService, IPaymentIdentifierRepository paymentIdentifierRepository, IAccountRepository accountRepository, IDcppService dcppService, IWelcomeNotificationService welcomeNotificationService,
            IProductRepository productRepository, ICustomerNotificationService customerNotificationService, IAccountHolderRepository accountHolderRepository, IRetailCardService retailCardService,
            IBaasConfiguration baasConfiguration)
        {
            _paymentInstrumentService = paymentInstrumentService;
            _validateIdentifier = validateIdentifier;
            _userService = userService;
            _tokenizerService = tokenizerService;
            _accountService = accountService;
            _verificationService = verificationService;
            _paymentIdentifierRepository = paymentIdentifierRepository;
            _accountRepository = accountRepository;
            _dcppService = dcppService;
            _welcomeNotificationService = welcomeNotificationService;
            _productRepository = productRepository;
            _customerNotificationService = customerNotificationService;
            _accountHolderRepository = accountHolderRepository;
            _retailCardService = retailCardService;
            _baasConfiguration = baasConfiguration;
        }

        public override void SetDomainContext(ActivateCardRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            if (!string.IsNullOrEmpty(request.Pan))
                DomainContext.Current.PlainTextPAN = request.Pan;
            if (!string.IsNullOrEmpty(request.PaymentInstrumentIdentifier))
                DomainContext.Current.PaymentInstrumentIdentifier = request.PaymentInstrumentIdentifier;
        }

        public override Task<ActivateCardResponse> VerifyIdentifiers(ActivateCardRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 4, 105);
                if (!string.IsNullOrEmpty(request.Pan))
                    _validateIdentifier.ValidatePAN(DomainContext.Current.AccountIdentifier, DomainContext.Current.PlainTextPAN);
                if (!string.IsNullOrEmpty(request.PaymentInstrumentIdentifier))
                    _validateIdentifier.ValidatePaymentInstrumentIdentifier(DomainContext.Current.AccountIdentifier, DomainContext.Current.PaymentInstrumentIdentifier);
                if (!string.IsNullOrEmpty(request.Source))
                    _validateIdentifier.ValidateSystemSource(request.Source);
                return Task.FromResult(new ActivateCardResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<ActivateCardResponse>(e, request));
            }
        }

        public override Task<ActivateCardResponse> Handle(ActivateCardRequest request)
        {
            try
            {
                var accountRefID = request?.AccountIdentifier;
                var response = new ActivateCardResponse();
                var expr = new CardExpirationDate()
                {
                    CardExpirationMonth = request.Expiration?.CardExpirationMonth,
                    CardExpirationYear = request.Expiration?.CardExpirationyear
                };
                try
                {
                    //lowhurdle flow
                    if (request.IdentifyingData != null)
                    {
                        // get customer information
                        var customerInfo =
                            _userService.GetUser(AccountIdentifier.FromGuid(Guid.Parse(accountRefID)), null)
                                ?.FirstOrDefault(x => x.IsPrimaryAccountHolder);
                        if (customerInfo == null)
                        {
                            throw new UpdateUserProfileException("No primary account holder info identified.");
                        }

                        var userIdentifyingData = request.IdentifyingData?.ToDomain();

                        var account = _accountService.GetAccount(request.AccountIdentifier);

                        //Account Limit Verification(ssn)
                        if (string.IsNullOrEmpty(userIdentifyingData.OnBoardingId))
                        {
                            var accountLimit = _accountService.AccountLimitVerification(userIdentifyingData.Ssn, string.Empty, userIdentifyingData.GetIdentityTypeKey().ToString(), false, account.Product.ProductCode.ToString(), request.ProgramCode);
                            accountLimit.ResponseCode = accountLimit.ResponseCode ?? "0";
                            AccountLimitValidateExceptionMapping(accountLimit);
                        }

                        if (!customerInfo.Identities.Exists(x =>
                            x.IdentityType == Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.IdentityType.SSN))
                        {
                            //Tokenize ssn
                            string tokenizedSSn =
                                _tokenizerService.TokenizeSsn(userIdentifyingData?.Ssn, request.ProgramCode);

                            // Add Or Update Identity
                            _userService.AddOrUpdateConsumerIdentity(customerInfo.ConsumerProfileKey,
                                request.AccountIdentifier, customerInfo.UserIdentifier, userIdentifyingData?.Ssn,
                                tokenizedSSn);

                        }

                        if (customerInfo.DateOfBirth == null)
                        {
                            //update encrypted dob
                            _userService.UpdateEncryptedDOB(customerInfo.UserIdentifier,
                                userIdentifyingData?.DateOfBirth);
                        }

                        //payfone,kyc2,enroll fonebook
                        var primaryCardHolder = account.AccountHolders.Single(x => x.IsPrimary);

                        var productName = _productRepository.GetNameByProductCode(account.Product.ProductCode, ProgramCode.FromString(request.ProgramCode));

                        Kyc(primaryCardHolder.AccountHolderCure,
                            request.AccountIdentifier,
                            customerInfo.UserIdentifier.ToString(),
                            userIdentifyingData.OnBoardingId,
                            request.ProgramCode,
                            account.Product.ProductCode,
                            productName);

                        //GBOS-47452 - we already registered during temp card activation flow and do not want to double enroll for retail card customers.
                        // but we do want to trigger Perso activation for Retailcard
                        if (Configuration.Current.RetailCardProductCode?.Split(',').Contains(account.Product.ProductCode.ToString()) == true)
                        {
                            _logger.Debug($"RetailCard - skip notification enrollment and welcome notification for retailcard during Perso activation flow. RequestId:{request.RequestHeader.RequestId},AccountIdentifier:{request.AccountIdentifier}");
                        }
                        else
                        {
                            //GBOS-45252 Modify Low Hurdle Enrollment to enroll customer into SMS notifications upon success
                            var phone = (customerInfo.PhoneNumbers?.FirstOrDefault(p => p.IsDefault)) ??
                                        (customerInfo.PhoneNumbers?.FirstOrDefault());
                            _customerNotificationService.EnrollNotificationsWhenKycApprovedAsync(
                                account.AccountIdentifier.ToString(), request.ProgramCode,
                                account.Product.ProductCode.ToString(), phone?.Number,
                                customerInfo?.Email?.EmailAddress, request.RequestHeader.RequestId);
                            //send welcome email
                            _welcomeNotificationService.RaiseWelcomeNotification(request.ProgramCode,
                                AccountIdentifier.FromGuid(Guid.Parse(accountRefID)), request.RequestHeader.RequestId);
                        }

                        //setbillcycle
                        var accountDetail = _accountRepository.GetAccountDetails(request.AccountIdentifier, ProgramCode.FromString(request.ProgramCode));
                        //if billcycle has not been set
                        if (accountDetail[0].Item1 == 0)
                        {
                            _accountService.SetBillCycle(request.RequestHeader.RequestId, request.AccountIdentifier, request.ProgramCode);
                        }

                        _paymentIdentifierRepository.UpdateAccountStatusAndStatusReason(account);
                    }
                    
                    if (!string.IsNullOrEmpty(request.PaymentInstrumentIdentifier) &&
                        _baasConfiguration.IsWhiteLabelEnrollment(request.ProgramCode))
                    {
                        var account = _accountService.GetAccount(request.AccountIdentifier);
                        //if accountstatus is pending and cure is healthy
                        if (account.AccountStatus == Core.Domain.Model.Account.AccountStatus.Pending &&
                            account.AccountHolders.Single(x => x.IsPrimary).AccountHolderCure ==
                            AccountHolderCure.Healthy)
                        {
                            _paymentIdentifierRepository.UpdateAccountStatusAndStatusReason(account);
                        }
                    }

                    var tuple =
                        _paymentInstrumentService
                            .GetPaymentIdentifierInfoByAccountIdentifier(request.AccountIdentifier);
                    var retailAccount = tuple.Item1;
                    List<PaymentIdentifierInfo> paymentIdentifierInfoList = tuple.Item2;
                    List<PaymentInstrumentInfo> paymentInstrumentInfoList = tuple.Item3;
                    List<PaymentInstrumentAllInfo> allPaymentInstruments = null;

                    bool isRetailProduct = false;
                    //We need to be able to tell if it's a retail account, and if so, get GetAllPaymentInstrumentList before we activate the perso card, to be able to tell if a perso has been activated before. 
                    if (retailAccount?.Product != null && Configuration.Current.RetailCardProductCode.Split(',').Contains(retailAccount.Product.ProductCode.ToString()))
                    {
                        isRetailProduct = true;
                        allPaymentInstruments = _paymentIdentifierRepository.GetAllPaymentInstrumentListInfoByAccountIdentifier(request.AccountIdentifier);
                    }

                    var acceptMinors = _baasConfiguration.IsAcceptMinorEnrollment(request.ProgramCode, retailAccount?.Product?.ProductCode?.ToString());

                    string paymentInstrumentIdentifier = _paymentInstrumentService.ActivateCard(request.AccountIdentifier, request.Pan,
                        expr, request.Cvv, request.ProgramCode, request.PaymentInstrumentIdentifier, request.Source, acceptMinors);

                    response = new ActivateCardResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 0,
                            SubStatusCode = 0,
                            Message = "Success"
                        },
                        CardActivated = true,
                        PaymentIntrumentIdentifier = paymentInstrumentIdentifier
                    };

                    try
                    {
                        //retailcard 
                        if (isRetailProduct)
                        {
                            var paymentIdentifierData = paymentIdentifierInfoList.FirstOrDefault(a => a.IsTemp);
                            if (paymentIdentifierData != null)
                            {
                                //Update Legacy Retailcard Temp PaymentIdentifier status to Closed
                                _accountHolderRepository.UpdatePaymentIdentifierStatusAndReason(
                                    paymentIdentifierData.PaymentIdentifierKey, PaymentIdentifierStatus.Closed, null);

                                var paymentInstrumentInfo = paymentInstrumentInfoList.Where(a =>
                                    a.PaymentIdentifierKey == paymentIdentifierData.PaymentIdentifierKey).ToList();
                                if (paymentInstrumentInfo.Count > 0)
                                {
                                    foreach (var instrumentInfo in paymentInstrumentInfo)
                                    {
                                        //update retail temp payment instrument as deactivated as we got Perso activated now.
                                        instrumentInfo.PaymentInstrumentStatus = PaymentInstrumentStatus.Deactivated;
                                    }

                                    _accountHolderRepository.UpdPaymentInstrumentStatuses(paymentInstrumentInfo);
                                }

                                //This is temp card we are marking inactive
                                _accountHolderRepository.UpdateAccountHolderPaymentIdentifier(
                                    paymentIdentifierData.PaymentIdentifierKey, false);
                                _logger.Debug(
                                    $"RetailCard - Deactivate Temp PaymentIdentifier,instrument and AccountHolder mapping. PaymentIdentifier:{paymentIdentifierData.PaymentIdentifierKey}, RequestId:{request.RequestHeader.RequestId},AccountIdentifier:{request.AccountIdentifier}");
                                //Need to transfer balance from temp to perso by calling GSS

                                var paymentInstrumentTempInfo = paymentInstrumentInfo.FirstOrDefault(a =>
                                    a.PaymentIdentifierKey == paymentIdentifierData.PaymentIdentifierKey);

                                MigrateTempCardAccount(request, paymentInstrumentTempInfo?.PaymentInstrumentIdentifier);
                            }
                            else
                            {
                                bool migrateAccount = true;

                                //Need to check the non temp cards, and see if any payment identifiers have been activated. If non of them have, we need to migrate the account. 
                                var persoCards = allPaymentInstruments.Where(pi => pi.PaymentIdentifierIsTemp == false);

                                foreach (PaymentInstrumentAllInfo paymentInstrumentAllInfo in persoCards)
                                {
                                    _logger.Debug(
                                        $"RetailCard - Checking if Migration is needed, AccountIdentifier:{request.AccountIdentifier}, RequestId:{request.RequestHeader.RequestId}, PaymentInstrument.ActivatedDateTime: {paymentInstrumentAllInfo.PaymentInstrument.ActivatedDateTime}");
                                    if (paymentInstrumentAllInfo.PaymentInstrument.ActivatedDateTime != null)
                                    {
                                        migrateAccount = false;
                                        //No need to go through all the cards if we don't need to migrate the account.
                                        break;
                                    }
                                }

                                if (migrateAccount)
                                {
                                    _logger.Debug(
                                        $"RetailCard - Migrating Account For Lost/Stolen, AccountIdentifier:{request.AccountIdentifier}, RequestId:{request.RequestHeader.RequestId}");
                                    var paymentInstrumentInfo = allPaymentInstruments.FirstOrDefault(a => a.PaymentIdentifierIsTemp);

                                    if (paymentInstrumentInfo?.PaymentInstrument?.PaymentInstrumentIdentifier != null)
                                    {
                                        MigrateTempCardAccount(request, Guid.Parse(paymentInstrumentInfo?.PaymentInstrument?.PaymentInstrumentIdentifier));
                                    }
                                    else
                                    {
                                        MigrateTempCardAccount(request, null);
                                    }
                                }
                                else
                                {
                                    _logger.Debug(
                                        $"RetailCard - Unable to deactivate Legacy Temp RetailCard PaymentIdentifier for AccountIdentifier:{request.AccountIdentifier}, RequestId:{request.RequestHeader.RequestId}");
                                }


                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.Error(ex, $"RetailCard - Unable to deactivate Legacy Temp RetailCard PaymentIdentifier for AccountIdentifier:{request.AccountIdentifier}, RequestId:{request.RequestHeader.RequestId}");

                    }

                }
                catch (AtmPinNotSetException atmEx)
                {
                    response = new ActivateCardResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 1,
                            SubStatusCode = 322,
                            Message = "Physical Card cannot be activated unless the ATM Pin has been set.",
                            Details = atmEx.Message
                        },
                        ActivationStatus = "atmPinNotSet",
                        CardActivated = false,
                    };
                }

                return Task.FromResult(response);
            }
            catch (DcppException e)
            {
                var response = new ActivateCardResponse();
                if (e.SubCode == 309 && e.Code == 4)
                {
                    response.ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = e.Code,
                        SubStatusCode = e.SubCode,
                        Message = "A Payment Instrument must be in a notActivated state to be activated.",
                        Details = "A different card must be activated."
                    };
                    return Task.FromResult(response);
                }

                return Task.FromResult(e.HandleException<ActivateCardResponse>(e, request));
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<ActivateCardResponse>(e, request));
            }
        }

        private void MigrateTempCardAccount(ActivateCardRequest request, Guid? paymentInstrumentIdentifier)
        {
            var transferRetailTempCardBalanceResponse = _retailCardService.TransferRetailTempCardBalance(request.ProgramCode,
                request.AccountIdentifier,
                new MigrateAccountRequest()
                {
                    ProgramCode = request.ProgramCode,
                    RequestId = request.RequestHeader.RequestId
                });


            if (transferRetailTempCardBalanceResponse.StatusCode != 0)
            {
                _logger.Error(
                    $"Invalid Response from TransferRetailTempCardBalance: {JsonConvert.SerializeObject(transferRetailTempCardBalanceResponse)}");
                throw new Exception("Invalid Response from TransferRetailTempCardBalance call");
            }

            _retailCardService.DeactivateLegacyTempCard(new DeactivateRetailTempCardRequest
            {
                RequestHeader = request.RequestHeader,
                DestinationAccountIdentifier = Guid.Parse(request.AccountIdentifier),
                PaymentInstrumentIdentifier = paymentInstrumentIdentifier.Value,
                ProgramCode = request.ProgramCode,
                RequestId = request.RequestHeader.RequestId
            });

        }

        private void AccountLimitValidateExceptionMapping(AccountLimit accountLimit)
        {
            if (accountLimit.ResponseCode == "260")
                throw new RequestHandlerException(2, 60, "Number of Active Accounts Exceeded.");
            else if (accountLimit.ResponseCode == "267")
                throw new RequestHandlerException(2, 67, "7 day opened account limit exceeded.");
            else if (accountLimit.ResponseCode == "268")
                throw new RequestHandlerException(2, 68, "30 day opened account limit exceeded.");
        }

        private void Kyc(AccountHolderCure cure,
            string accountIdentifier,
            string userIdentifier,
            string onBoardingId,
            string programCode,
            ProductCode productCode,
            string productName)
        {
            switch (cure)
            {
                case AccountHolderCure.Healthy:
                    break;
                case AccountHolderCure.Unknown:
                    CreateVerifyRequest createVerifyRequest = new CreateVerifyRequest();

                    createVerifyRequest.AccountIdentifier = accountIdentifier;
                    createVerifyRequest.UserIdentifier = userIdentifier;
                    createVerifyRequest.CipLevel = null;
                    createVerifyRequest.OnboardingId = onBoardingId;
                    createVerifyRequest.ProgramCode = programCode;
                    createVerifyRequest.EnablePhoneVerification = true;

                    createVerifyRequest.CustomData = new Dictionary<string, object>
                        {
                            { "ProductCode",  productCode.ToString()},
                            { "ProductName", productName}
                        };
                    var kycStateData = _verificationService.PostEnrollmentFraudVerification(createVerifyRequest);

                    if (kycStateData.KycPendingGate != "healthy")
                    {
                        throw new RequestHandlerException(4, 386, "KYC2 verification failed.");
                    }

                    break;
                default:
                    throw new RequestHandlerException(4, 386, "KYC2 verification failed.");
            }
        }
    }
}
