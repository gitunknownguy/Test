﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;


namespace RequestHandler.Logic.Handler
{
    public class CblReverseHandler : CommandHandlerBase<CblReverseLoanRequest, CblReverseLoanResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ICreditBuilderLoanService _creditBuilderLoanService;

        public CblReverseHandler(IValidateIdentifier validateIdentifier, ICreditBuilderLoanService creditBuilderLoanService)
        {
            _validateIdentifier = validateIdentifier;
            _creditBuilderLoanService = creditBuilderLoanService;
        }

        public override void SetDomainContext(CblReverseLoanRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
            {
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            }

        }

        public override Task<CblReverseLoanResponse> VerifyIdentifiers(CblReverseLoanRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(request.AccountIdentifier, DomainContext.Current.ProgramCode);

                return Task.FromResult(new CblReverseLoanResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CblReverseLoanResponse>(e, request));
            }
        }

        public override async Task<CblReverseLoanResponse> Handle(CblReverseLoanRequest request)
        {
            try
            {
                var response = await _creditBuilderLoanService.ReverseLoan(request);

                return response;
            }
            catch (Exception e)
            {
                return e.HandleException<CblReverseLoanResponse>(e, request);
            }
        }
    }
}