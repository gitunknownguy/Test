﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class CblPaymentHandler : CommandHandlerBase<CblPaymentRequest, CblPaymentResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ICreditBuilderLoanService _creditBuilderLoanService;

        public CblPaymentHandler(IValidateIdentifier validateIdentifier,
            ICreditBuilderLoanService creditBuilderLoanService)
        {
            _validateIdentifier = validateIdentifier;
            _creditBuilderLoanService = creditBuilderLoanService;
        }

        public override void SetDomainContext(CblPaymentRequest request)
        {
            DomainContext.Current.ProgramCode = ProgramCode.FromString(request.ProgramCode);
            DomainContext.Current.AccountIdentifier = AccountIdentifier.FromString(request.AccountIdentifier);
        }

        public override Task<CblPaymentResponse> VerifyIdentifiers(CblPaymentRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new CblPaymentResponse { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CblPaymentResponse>(e, request));
            }
        }

        public override async Task<CblPaymentResponse> Handle(CblPaymentRequest request)
        {
            try
            {
                var response = await _creditBuilderLoanService.Payment(request);

                return response;
            }
            catch (Exception e)
            {
                return e.HandleException<CblPaymentResponse>(e, request);
            }
        }
    }
}