﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using RequestHandler.Core.Application;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class CblOpenLoanHandler : CommandHandlerBase<CblOpenLoanRequest, CblOpenLoanResponse>
    {
        private readonly ILockService _lockService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ICreditBuilderLoanService _cblService;

        public CblOpenLoanHandler(
            ILockService lockService,
            IValidateIdentifier validateIdentifier,
            ICreditBuilderLoanService cblService
        )
        {
            _lockService = lockService;
            _validateIdentifier = validateIdentifier;
            _cblService = cblService;
        }

        public override void SetDomainContext(CblOpenLoanRequest request)
        {
            DomainContext.Current.ReferencedAccountIdentifier = request.AccountIdentifier;
            DomainContext.Current.ProgramCode = ProgramCode.FromString(request.ProgramCode);
        }

        public override Task<CblOpenLoanResponse> VerifyIdentifiers(CblOpenLoanRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.ReferencedAccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new CblOpenLoanResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CblOpenLoanResponse>(e, request));
            }
        }

        public override async Task<CblOpenLoanResponse> ObtainLock(CblOpenLoanRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock(OptionsContext.Current.GetString("requestId"));
                await _lockService.ObtainApiLock(request.AccountIdentifier);

                return new CblOpenLoanResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<CblOpenLoanResponse>(e, request);
            }
        }

        public override async Task<CblOpenLoanResponse> Handle(CblOpenLoanRequest request)
        {
            return await _cblService.OpenLoan(request);
        }

        public override void ReleaseLock(CblOpenLoanRequest request)
        {
            _lockService.ReleaseApiLock(OptionsContext.Current.GetString("requestId"));
            _lockService.ReleaseApiLock(request.AccountIdentifier);
        }


        private const string OfacDeclinedMessage = "OFAC Match.";
        private const string UserNotFoundMessage = "User Not Found";
        private const string AbilityToPayCheckFailedMessage = "Ability To Pay Check Failed";
        private const string ExceedFraudLimitReason = "Customers may not open more than one GO2bank Secured Credit Card account at any given time.";
    }
}