﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class CblEligibilityHandler : CommandHandlerBase<CblEligibilityCheckRequest, CblEligibilityCheckResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IEligibilityCheckService _eligibilitiesService;

        public CblEligibilityHandler(IValidateIdentifier validateIdentifier, IEligibilityCheckService eligibilitiesService)
        {
            _validateIdentifier = validateIdentifier;
            _eligibilitiesService = eligibilitiesService;
        }
        public override void SetDomainContext(CblEligibilityCheckRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<CblEligibilityCheckResponse> VerifyIdentifiers(CblEligibilityCheckRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(request.AccountIdentifier, DomainContext.Current.ProgramCode);

                return Task.FromResult(new CblEligibilityCheckResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CblEligibilityCheckResponse>(e, request));
            }
        }

        public override Task<CblEligibilityCheckResponse> Handle(CblEligibilityCheckRequest request)
        {
            try
            {
                var response = _eligibilitiesService.CreditBuilderLoanEligibility(request.ProgramCode, request.AccountIdentifier);
                response.ResponseHeader.ResponseId = request.RequestHeader.RequestId;

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CblEligibilityCheckResponse>(e, request));
            }
        }

    }
}