﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class CblCancelScheduledPaymentHandler : CommandHandlerBase<CblCancelScheduledPaymentRequest, CblCancelScheduledPaymentResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ICreditBuilderLoanService _cblService;

        public CblCancelScheduledPaymentHandler(IValidateIdentifier validateIdentifier, ICreditBuilderLoanService cblService)
        {
            _validateIdentifier = validateIdentifier;
            _cblService = cblService;
        }

        public override void SetDomainContext(CblCancelScheduledPaymentRequest request)
        {
            if (!string.IsNullOrEmpty(request.ProgramCode))
                DomainContext.Current.ProgramCode = ProgramCode.FromString(request.ProgramCode);
        }

        public override Task<CblCancelScheduledPaymentResponse> VerifyIdentifiers(CblCancelScheduledPaymentRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(request.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new CblCancelScheduledPaymentResponse { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CblCancelScheduledPaymentResponse>(e, request));
            }
        }

        public override async Task<CblCancelScheduledPaymentResponse> Handle(CblCancelScheduledPaymentRequest request)
        {
            try
            {
                var response = await _cblService.CancelScheduledPayment(request);

                return response;
            }
            catch (Exception e)
            {
                return e.HandleException<CblCancelScheduledPaymentResponse>(e, request);
            }
        }

    }
}