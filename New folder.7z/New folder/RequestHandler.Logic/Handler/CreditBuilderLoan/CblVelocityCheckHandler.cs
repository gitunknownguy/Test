﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class CblVelocityCheckHandler : CommandHandlerBase<CblVelocityCheckRequest, CblVelocityCheckResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IEligibilityCheckService _eligibilityCheckService;

        public CblVelocityCheckHandler(IValidateIdentifier validateIdentifier, IEligibilityCheckService eligibilityCheckService)
        {
            _validateIdentifier = validateIdentifier;
            _eligibilityCheckService = eligibilityCheckService;
        }
        public override void SetDomainContext(CblVelocityCheckRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<CblVelocityCheckResponse> VerifyIdentifiers(CblVelocityCheckRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.ProgramCode);
                return Task.FromResult(new CblVelocityCheckResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CblVelocityCheckResponse>(e, request));
            }
        }

        public override async Task<CblVelocityCheckResponse> Handle(CblVelocityCheckRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.AccountIdentifier))
                    throw new AccountNotFoundException();

                var response = await _eligibilityCheckService.CblVelocityCheck(request);

                return response;
            }
            catch (Exception e)
            {
                return e.HandleException<CblVelocityCheckResponse>(e, request);
            }
        }

    }
}