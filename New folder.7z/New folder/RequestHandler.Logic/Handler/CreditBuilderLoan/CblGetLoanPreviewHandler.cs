﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;

namespace RequestHandler.Logic.Handler
{
    public class CblGetLoanPreviewHandler : CommandHandlerBase<CblGetLoanPreviewRequest, CblGetLoanPreviewResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ICreditBuilderLoanService _creditBuilderLoanService;

        public CblGetLoanPreviewHandler(IValidateIdentifier validateIdentifier,
            ICreditBuilderLoanService creditBuilderLoanService)
        {
            _validateIdentifier = validateIdentifier;
            _creditBuilderLoanService = creditBuilderLoanService;
        }

        public override void SetDomainContext(CblGetLoanPreviewRequest request)
        {
            DomainContext.Current.ProgramCode = ProgramCode.FromString(request.ProgramCode);
        }

        public override Task<CblGetLoanPreviewResponse> VerifyIdentifiers(CblGetLoanPreviewRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new CblGetLoanPreviewResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CblGetLoanPreviewResponse>(e, request));
            }
        }

        public override async Task<CblGetLoanPreviewResponse> Handle(CblGetLoanPreviewRequest request)
        {
            try
            {
                var response = await _creditBuilderLoanService.GetLoanPreview(request);

                return response;
            }
            catch (Exception e)
            {
                return e.HandleException<CblGetLoanPreviewResponse>(e, request);
            }
        }
    }
}
