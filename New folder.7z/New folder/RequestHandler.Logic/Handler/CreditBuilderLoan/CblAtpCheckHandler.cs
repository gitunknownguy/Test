﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class CblAtpCheckHandler : CommandHandlerBase<CblAtpCheckRequest, CblAtpCheckResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IEligibilityCheckService _eligibilityCheckService;

        public CblAtpCheckHandler(IValidateIdentifier validateIdentifier, IEligibilityCheckService eligibilityCheckService)
        {
            _validateIdentifier = validateIdentifier;
            _eligibilityCheckService = eligibilityCheckService;
        }
        public override void SetDomainContext(CblAtpCheckRequest request)
        {
            if (!string.IsNullOrEmpty(request.ProgramCode) && !string.IsNullOrEmpty(request.AccountIdentifier))
            {
                DomainContext.Current.ProgramCode = ProgramCode.FromString(request.ProgramCode);
                DomainContext.Current.AccountIdentifier = AccountIdentifier.FromString(request.AccountIdentifier);
            }
        }

        public override Task<CblAtpCheckResponse> VerifyIdentifiers(CblAtpCheckRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.ProgramCode);
                return Task.FromResult(new CblAtpCheckResponse { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CblAtpCheckResponse>(e, request));
            }
        }

        public override Task<CblAtpCheckResponse> Handle(CblAtpCheckRequest request)
        {
            try
            {
                var response = _eligibilityCheckService.CblAtpCheck(request);
                return response;
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CblAtpCheckResponse>(e, request));
            }
        }

    }
}