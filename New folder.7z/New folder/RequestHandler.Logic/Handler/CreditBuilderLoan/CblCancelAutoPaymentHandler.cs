﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class CblCancelAutoPaymentHandler : CommandHandlerBase<CblCancelAutoPaymentRequest, CblCancelAutoPaymentResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private ICreditBuilderLoanService _cblService;

        public CblCancelAutoPaymentHandler(IValidateIdentifier validateIdentifier, ICreditBuilderLoanService cblService)
        {
            _validateIdentifier = validateIdentifier;
            _cblService = cblService;
        }

        public override void SetDomainContext(CblCancelAutoPaymentRequest request)
        {
            if (!string.IsNullOrEmpty(request.ProgramCode))
                DomainContext.Current.ProgramCode = ProgramCode.FromString(request.ProgramCode);
        }

        public override Task<CblCancelAutoPaymentResponse> VerifyIdentifiers(CblCancelAutoPaymentRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(request.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new CblCancelAutoPaymentResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CblCancelAutoPaymentResponse>(e, request));
            }
        }

        public override async Task<CblCancelAutoPaymentResponse> Handle(CblCancelAutoPaymentRequest request)
        {
            try
            {
                var response = await _cblService.CancelAutoPayment(request);

                return response;
            }
            catch (Exception e)
            {
                return e.HandleException<CblCancelAutoPaymentResponse>(e, request);
            }
        }

    }
}