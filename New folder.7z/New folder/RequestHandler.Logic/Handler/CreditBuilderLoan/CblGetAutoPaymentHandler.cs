﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class CblGetAutoPaymentHandler : CommandHandlerBase<CblGetAutoPaymentRequest, CblGetAutoPaymentResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private ICreditBuilderLoanService _cblService;

        public CblGetAutoPaymentHandler(IValidateIdentifier validateIdentifier, ICreditBuilderLoanService cblService)
        {
            _validateIdentifier = validateIdentifier;
            _cblService = cblService;
        }

        public override void SetDomainContext(CblGetAutoPaymentRequest request)
        {
            if (!string.IsNullOrEmpty(request.ProgramCode))
                DomainContext.Current.ProgramCode = ProgramCode.FromString(request.ProgramCode);
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = AccountIdentifier.FromString(request.AccountIdentifier);
        }

        public override Task<CblGetAutoPaymentResponse> VerifyIdentifiers(CblGetAutoPaymentRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new CblGetAutoPaymentResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CblGetAutoPaymentResponse>(e, request));
            }
        }

        public override async Task<CblGetAutoPaymentResponse> Handle(CblGetAutoPaymentRequest request)
        {
            try
            {
                var response = await _cblService.GetAutoPayment(request);

                return response;
            }
            catch (Exception e)
            {
                return e.HandleException<CblGetAutoPaymentResponse>(e, request);
            }
        }

    }
}