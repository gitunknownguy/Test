﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Domain.Services.Experian;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;

namespace RequestHandler.Logic.Handler
{
    public class ExperianGetOptInHandler : CommandHandlerBase<ExperianGetOptInRequest, ExperianGetOptInResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IFinancialDataService _financialDataService;
        public ExperianGetOptInHandler(IValidateIdentifier validateIdentifier, IFinancialDataService financialDataService)
        {
            _validateIdentifier = validateIdentifier;
            _financialDataService = financialDataService;
        }

        public override void SetDomainContext(ExperianGetOptInRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<ExperianGetOptInResponse> VerifyIdentifiers(ExperianGetOptInRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new ExperianGetOptInResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<ExperianGetOptInResponse>(e, request));
            }
        }

        public override Task<ExperianGetOptInResponse> Handle(ExperianGetOptInRequest request)
        {
            var response = new ExperianGetOptInResponse()
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                }
            };

            string brandId = request.ProgramCode.Equals(Configuration.Current.GBRProgramCode, StringComparison.OrdinalIgnoreCase)
                                ? Configuration.Current.Go2BankProgramCode
                                : request.ProgramCode;

            var stored = _financialDataService.GetOptIn(request.RequestHeader.RequestId.ToString(), brandId, request.AccountIdentifier);

            if (stored != null)
            {
                response.OptIn = stored.OptIn;
                response.Boost = stored.IsBoost;
            }

            return Task.FromResult(response);
        }
    }
}
