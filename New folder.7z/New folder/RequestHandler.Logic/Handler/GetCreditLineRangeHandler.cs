﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;

namespace RequestHandler.Logic.Handler
{
    public class GetCreditLineRangeHandler : CommandHandlerBase<GetCreditLineRangeRequest, GetCreditLineRangeResponse>
    {
        private readonly IUserService _userService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IAccountService _accountService;

        public GetCreditLineRangeHandler(IAccountService accountService, IUserService userService, IValidateIdentifier validateIdentifier)
        {
            _accountService = accountService;
            _userService = userService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(GetCreditLineRangeRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetCreditLineRangeResponse> VerifyIdentifiers(GetCreditLineRangeRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetCreditLineRangeResponse() { ResponseHeader = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetCreditLineRangeResponse>(e, request));
            }
        }

        public override Task<GetCreditLineRangeResponse> Handle(GetCreditLineRangeRequest request)
        {
            GetCreditLineRangeResponse response = new GetCreditLineRangeResponse()
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                }
            };
            try
            {
                //no matter account is dda or scc, we just need to retrieve the user
                var account = _accountService.GetAccountByAccountIdentifier(request.AccountIdentifier);
                if (account == null)
                {
                    throw new ValidationException(10, 0, "Account Not Found");
                }
                var primaryUser = account.AccountHolders.FirstOrDefault(a => a.IsPrimary && a.ConsumerProfileTypeKey == 1);
                if (primaryUser == null)
                {
                    throw new ValidationException(10, 0, "User Not Found");
                }
                var primaryUserInfo = _userService.GetUser(account.AccountIdentifier, primaryUser.UserIdentifier).
                        FirstOrDefault(u => u.ConsumerProfileKey == primaryUser.ConsumerProfileKey);
                if (primaryUserInfo == null)
                {
                    throw new ValidationException(10, 0, "User Not Found");
                }
                //GBOS-32219 Validate whether acccount is SCC or not
                var linkedAccounts = _accountService.GetLinkedAccount(request.AccountIdentifier);
                if (!linkedAccounts.Any(a => a.LinkAccountIdentifier.ToLower() == request.AccountIdentifier.ToLower()
                                            && a.AccountLinkType == AccountLinkType.SecureCreditCard))
                {
                    throw new ValidationException(101, 0, "SCC AccountIdentifier Required");
                }

                var result = default(CreditLineRange);
                //GBOS-35091 Add income and expense in request
                if (request.Income.HasValue && request.Expense.HasValue)
                {
                    result = _userService.GetCreditLineRangeWithIncomeExpenseInRequest(request.ProgramCode, (decimal)request.Income,
                        request.IncomeFrequency, (decimal)request.Expense, request.ExpenseFrequency);
                }
                else
                {
                    result = _userService.GetCreditLineRange(primaryUserInfo.ConsumerProfileKey, request.ProgramCode);
                }

                if (result == null)
                {
                    throw new ValidationException(10, 0, "Income or Expense Not Found");
                }

                response.MinCreditLine = result.MinCreditLine;
                response.MaxCreditLine = result.MaxCreditLine;
                response.Income = result.Income;
                response.IncomeFrequency = result.IncomeFrequency;
                response.Expense = result.Expense;
                response.ExpenseFrequency = result.ExpenseFrequency;

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetCreditLineRangeResponse>(e, request));
            }
        }
    }
}
