﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Amazon.SecretsManager.Model;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Enums;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;
using RequestHandler.Core.Domain.Model.Business;

namespace RequestHandler.Logic.Handler
{
    public class GetBusinessMetaDataHandler : CommandHandlerBase<GetBusinessEnrollmentRequest, GetBusinessEnrollmentResponse>
    {
        private readonly IGetBusinessMetaDataService _getBusinessMetadataService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IUserService _userService;

        public GetBusinessMetaDataHandler(IGetBusinessMetaDataService getBusinessMetadataService
        , IUserService userService, IValidateIdentifier validateIdentifier)
        {
            _getBusinessMetadataService = getBusinessMetadataService;
            _validateIdentifier = validateIdentifier;
            _userService = userService;
        }

        public override void SetDomainContext(GetBusinessEnrollmentRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
            {
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            }
        }

        public override Task<GetBusinessEnrollmentResponse> VerifyIdentifiers(GetBusinessEnrollmentRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidatePartner_AccountIdProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetBusinessEnrollmentResponse()
                {
                    ResponseHeader = new ResponseHeader()
                });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetBusinessEnrollmentResponse>(e, request));
            }
        }

        public override Task<GetBusinessEnrollmentResponse> Handle(GetBusinessEnrollmentRequest request)
        {
            var response = new GetBusinessEnrollmentResponse();

            try
            {
                if (request == null)
                    throw new InvalidRequestException("Invalid Request.");

                if (string.IsNullOrEmpty(request.AccountIdentifier))
                    throw new AccountNotFoundException();

                if (string.IsNullOrEmpty(request.ProgramCode))
                    throw new ArgumentNullException($"ProgramCode: Program Code cannot be null or empty.");

                //Get business user data from GBOS DB
                var businessUserData = _userService.GetBusinessUser(request.AccountIdentifier);

                var getBusinessEnrollmentRequest = new GetBusinessEnrollmentRequest
                {
                    AccountIdentifier = request.AccountIdentifier,
                    ProgramCode = request.ProgramCode,
                    RequestHeader = request.RequestHeader
                };
                //Get business information and owners from cassandra DB
                var info = _getBusinessMetadataService.GetBusinessMetaData(getBusinessEnrollmentRequest);

                if (info != null)
                    response = MapBusinessMetaData(response, info, businessUserData, getBusinessEnrollmentRequest);
                else
                {
                    return Task.FromResult(new GetBusinessEnrollmentResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 503,
                            SubStatusCode = 4123,
                        }
                    });
                }
                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetBusinessEnrollmentResponse>(e, request));
            }
        }

        private GetBusinessEnrollmentResponse MapBusinessMetaData(GetBusinessEnrollmentResponse response, BusinessEnrollment info, Tuple<Gd.Bos.RequestHandler.Core.Domain.Model.User.UserProfile, long> businessUserData, GetBusinessEnrollmentRequest request)
        {
            response = new GetBusinessEnrollmentResponse
            {
                ownerInfo = new List<OwnerProfileData>(),
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                }
            };

            if (info.BusinessInfo != null)
            {
                response.BusinessInfo = new EnrollBusinessInfoData
                {
                    BusinessIndustryCode = info.BusinessInfo?.BusinessIndustryCode,
                    BusinessName = info.BusinessInfo?.BusinessName,
                    IncorporatedState = info.BusinessInfo?.IncorporatedState,
                    CompanyProfileTypeCode = info.BusinessInfo?.CompanyProfileTypeCode,
                    CompanyProfileRoleCode = info.BusinessInfo?.CompanyProfileRoleCode,
                    StartDate = info.BusinessInfo.StartDate,
                    TaxId = info.BusinessInfo?.TaxId,
                    Last4TaxId = info.BusinessInfo?.Last4TaxId
                };
            }
            if (info.BusinessContactInfo != null)
            {
                response.BusinessContactInfo = new EnrollBusinessContactInfoData
                {
                    AddressLineOne = info.BusinessContactInfo?.AddressLineOne,
                    AddressLineTwo = info.BusinessContactInfo?.AddressLineTwo,
                    State = info.BusinessContactInfo?.State,
                    City = info.BusinessContactInfo?.City,
                    Zip = info.BusinessContactInfo?.Zip,
                    PhoneNumber = info.BusinessContactInfo?.PhoneNumber
                };
            }

            if (businessUserData.Item2 == ((long)ConsumerProfileType.BeneficialOwner))
            {
                var userData = new OwnerProfileData
                {
                    FirstName = businessUserData.Item1?.FirstName,
                    MiddleName = businessUserData.Item1?.MiddleName,
                    LastName = businessUserData.Item1.LastName,
                    AddressLineOne = businessUserData.Item1.Addresses.Where(X => X.IsVerified).FirstOrDefault()?.AddressLine1,
                    AddressLineTwo = businessUserData.Item1.Addresses?.Where(X => X.IsVerified).FirstOrDefault()?.AddressLine2,
                    State = businessUserData.Item1.Addresses?.Where(X => X.IsVerified).FirstOrDefault()?.State,
                    City = businessUserData.Item1.Addresses?.Where(X => X.IsVerified).FirstOrDefault().City,
                    Zip = businessUserData.Item1.Addresses?.Where(X => X.IsVerified).FirstOrDefault().ZipCode
                };
                response.ownerInfo.Add(userData);
            }
            if (info.OwnersInfo != null)
            {
                foreach (var ownerInfo in info?.OwnersInfo)
                {
                    response.ownerInfo.Add(ownerInfo);
                }
            }
            return response;
        }

    }
}
