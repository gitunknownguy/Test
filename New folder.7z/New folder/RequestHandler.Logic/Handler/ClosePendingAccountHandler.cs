﻿using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System;
using System.Threading.Tasks;

namespace RequestHandler.Logic.Handler
{
    public class ClosePendingAccountHandler : CommandHandlerBase<ClosePendingAccountRequest, ClosePendingAccountResponse>
    {
        private readonly IAccountService _accountService;
        private readonly IValidateIdentifier _validateIdentifier;

        public ClosePendingAccountHandler(IAccountService accountService, IValidateIdentifier validateIdentifier)
        {
            _accountService = accountService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(ClosePendingAccountRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<ClosePendingAccountResponse> VerifyIdentifiers(ClosePendingAccountRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 3, 105);
                return Task.FromResult(new ClosePendingAccountResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<ClosePendingAccountResponse>(e, request));
            }
        }

        public override Task<ClosePendingAccountResponse> Handle(ClosePendingAccountRequest request)
        {
            ClosePendingAccountResponse response;
            try
            {
                response = _accountService.ClosePendingAccount(request);
            }
            catch (Exception e)
            {
                response = e.HandleException<ClosePendingAccountResponse>(e, request);
            }

            return Task.FromResult(response);
        }
    }
}