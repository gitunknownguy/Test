﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using NLog;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class AdjustmentHandler : CommandHandlerBase<AdjustAccountBalanceRequest, AdjustAccountBalanceResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IAccountTransactionService _accountTransactionService;
        private readonly ITransClassService _transClassService;
        private readonly IBaasConfiguration _baasConfiguration;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();


        public AdjustmentHandler(IValidateIdentifier validateIdentifier,
            IAccountTransactionService accountTransactionService,
            IBaasConfiguration baasConfiguration,
            ITransClassService transClassService)
        {
            _validateIdentifier = validateIdentifier;
            _accountTransactionService = accountTransactionService;
            _baasConfiguration = baasConfiguration;
            _transClassService = transClassService;
        }

        public override Task<AdjustAccountBalanceResponse> Handle(AdjustAccountBalanceRequest request)
        {
            try
            {
                var response = _accountTransactionService.Adjustment(request);

                return Task.FromResult(response);
            }
            catch (AccountTransactionException<AdjustAccountBalanceBaseResponse> ae)
            {
                var response = new AdjustAccountBalanceResponse
                {
                    ResponseHeader = ae.ResponseData.ResponseHeader,
                    Status = ae.ResponseData.Status,
                    StatusReason = ae.ResponseData.StatusReason,
                    AdjustmentIdentifier = request.AdjustmentIdentifier
                };
                return Task.FromResult(response);
            }
            catch (AccountValidationException ave)
            {
                var response = new AdjustAccountBalanceResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader?.RequestId ?? new Guid(),
                        StatusCode = ave.Code,
                        SubStatusCode = ave.SubCode,
                        Message = ave.Message,
                        Details = ave.ToString()
                    },
                    AdjustmentIdentifier = request.AdjustmentIdentifier
                };
                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AdjustAccountBalanceResponse>(e, request));
            }
        }

        public override void SetDomainContext(AdjustAccountBalanceRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<AdjustAccountBalanceResponse> VerifyIdentifiers(AdjustAccountBalanceRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);

                return Task.FromResult(new AdjustAccountBalanceResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AdjustAccountBalanceResponse>(e, request));
            }
        }
    }
}
