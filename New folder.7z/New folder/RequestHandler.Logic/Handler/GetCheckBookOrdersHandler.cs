﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using RequestHandler.Core.Domain.Services.PaperCheck;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using CheckBookOrder = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.CheckBookOrder;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetCheckBookOrdersHandler : CommandHandlerBase<GetCheckBookOrdersRequest, GetCheckBookOrdersResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IPaperCheckService _paperCheckService;

        public GetCheckBookOrdersHandler(IPaperCheckService paperCheckService, IValidateIdentifier validateIdentifier)
        {
            _validateIdentifier = validateIdentifier;
            _paperCheckService = paperCheckService;
        }

        
        public override void SetDomainContext(GetCheckBookOrdersRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        
        public override Task<GetCheckBookOrdersResponse> VerifyIdentifiers(GetCheckBookOrdersRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);

                return Task.FromResult(new GetCheckBookOrdersResponse { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetCheckBookOrdersResponse>(e, request));
            }
        }

        public override Task<GetCheckBookOrdersResponse> Handle(GetCheckBookOrdersRequest request)
        {
            try
            {
                var result = new GetCheckBookOrdersResponse();

                var serviceResponse = _paperCheckService.GetCheckBookOrders(request);

                if (serviceResponse.ErrorCode == "0")
                {
                    result.ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    };
                    result.CheckBookOrders = GetCheckBookOrdersFromModel(serviceResponse.CheckBookOrders);
                }
                else
                {
                    HandlePartnerErrorResponse(serviceResponse);
                }

                return Task.FromResult(result);
            }
            catch (Exception ex)
            {
                return Task.FromResult(ex.HandleException<GetCheckBookOrdersResponse>(ex, request));
            }
        }

        
        private IEnumerable<CheckBookOrder> GetCheckBookOrdersFromModel(List<global::RequestHandler.Core.Domain.Services.PaperCheck.CheckBookOrder> orders)
        {
            var result = new List<CheckBookOrder>();

            foreach (var order in orders)
            {
                result.Add(new CheckBookOrder
                {
                    CheckBookOrderDate = order.CheckBookOrderDate,
                    CheckBookOrderStatus = order.CheckBookOrderStatus.ToString(),
                    FirstCheckNumber = order.FirstCheckNumber,
                    LastCheckNumber = order.LastCheckNumber,
                    OrderConfirmationToken = order.OrderConfirmationToken
                });
            }

            return result;
        }


        /// <summary>
        /// map known GSS error response codes here
        /// </summary>
        /// <param name="response"></param>
        private void HandlePartnerErrorResponse(GetCheckBookOrdersResponseModel response)
        {
            switch (response.ErrorCode)
            {

                case "03001": // order not found
                    throw new RequestHandlerException(10, 1, "Check book order is not found.");

                case "0": // success
                    return;

                default:
                    {
                        throw new RequestHandlerException(400, 0,
                            $"Unhandled error code from downstream service. ErrorCode:{response.ErrorCode} ErrorMessage:{response.ErrorMessage}");
                    }
            }

        }
    }
}
