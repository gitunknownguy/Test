﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.Contract;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using NLog;
using Gd.Bos.RequestHandler.Core.Domain;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class AtmLocationsHandler : CommandHandlerBase<AtmLocationsRequest, AtmLocationsResponse>
    {
        private readonly IBaasConfiguration _configuration;
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();
        public AtmLocationsHandler(IAtmLocationService atmLocationService, IValidateIdentifier validateIdentifier, IBaasConfiguration configuration)
        {
            _atmLocationService = atmLocationService;
            _validateIdentifier = validateIdentifier;
            _configuration = configuration;
        }

        public override void SetDomainContext(AtmLocationsRequest request)
        {

        }

        public override Task<AtmLocationsResponse> VerifyIdentifiers(AtmLocationsRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.ProgramCode);
                return Task.FromResult(new AtmLocationsResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AtmLocationsResponse>(e, request));
            }
        }

        public override async Task<AtmLocationsResponse> Handle(AtmLocationsRequest request)
        {
            if (request.RequestHeader.RequestId == Guid.Empty)
            {
                throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId, $"{nameof(request)}.RequestHeader.RequestId must be specified");
            }

            try
            {
                List<AtmLocation> response;

                if (_configuration.NeedSpeedUp(request.ProgramCode))
                {
                    response = await GetAtmLocations(request);
                }
                else
                {
                    response = await _atmLocationService.GetAtmLocations(request.AddressLine,
                        request.City,
                        request.State,
                        request.PostalCode,
                        request.Country,
                        request.Latitude,
                        request.Longitude,
                        request.Radius);
                }

                return new AtmLocationsResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                    Locations = response
                };
            }
            catch (Exception ex)
            {
                return ex.HandleException<AtmLocationsResponse>(ex, request);
            }
        }

        private async Task<List<AtmLocation>> GetAtmLocations(AtmLocationsRequest request)
        {
            var firstStopWatch = Stopwatch.StartNew();
            var firstCts = new CancellationTokenSource();
            var fistToken = firstCts.Token;
            var firstTask = Task.Run(() => _atmLocationService.GetAtmLocations
            (
                request.AddressLine,
                request.City,
                request.State,
                request.PostalCode,
                request.Country,
                request.Latitude,
                request.Longitude,
                request.Radius
            ), fistToken);

            var timespanCts = new CancellationTokenSource();
            var timespanToken = timespanCts.Token;
            var timespanTask = Task.Delay(_configuration.AtmLocationDelayTime(request.ProgramCode), timespanToken);
            var completeTask = await Task.WhenAny(firstTask, timespanTask);

            if (completeTask == firstTask)
            {
                CancelTask(timespanCts);
                return await firstTask;
            }

            var secondStopWatch = Stopwatch.StartNew();
            var secondCts = new CancellationTokenSource();
            var secondToken = secondCts.Token;
            var secondTask = Task.Run(() => _atmLocationService.GetAtmLocations
            (
                request.AddressLine,
                request.City,
                request.State,
                request.PostalCode,
                request.Country,
                request.Latitude,
                request.Longitude,
                request.Radius
            ), secondToken);

            var raceTask = await Task.WhenAny(firstTask, secondTask);
            firstStopWatch.Stop();
            secondStopWatch.Stop();
            if (raceTask == secondTask)
            {
                CancelTask(firstCts);
                Logger.Warn($"Get atm location is slow and the 2nd thread return the result, 2nd thread used {secondStopWatch.ElapsedMilliseconds}ms, 1st thread already used {firstStopWatch.ElapsedMilliseconds}ms.");
                return await secondTask;
            }

            CancelTask(secondCts);
            Logger.Warn($"Get atm location is slow and the 1st thread return the result, 1st thread used {firstStopWatch.ElapsedMilliseconds}ms, 2nd thread already used {secondStopWatch.ElapsedMilliseconds}ms.");
            return await firstTask;
        }

        private static void CancelTask(CancellationTokenSource timespanCts)
        {
            try
            {
                timespanCts.Cancel();
                timespanCts.Dispose();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private readonly IAtmLocationService _atmLocationService;
        private readonly IValidateIdentifier _validateIdentifier;
    }
}
