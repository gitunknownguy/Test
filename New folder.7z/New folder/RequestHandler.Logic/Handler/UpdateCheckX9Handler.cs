﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;

namespace Gd.Bos.RequestHandler.Logic.Handler
{

    public class UpdateCheckX9Handler : CommandHandlerBase<UpdateMrdcX9CheckRequest, UpdateMrdcX9CheckResponse>
    {
        private static string unspecifiedGuid = Guid.Empty.ToString();
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ITransferService _transferService;
        private readonly ILockService _lockService;

        public UpdateCheckX9Handler(ITransferService transferService, IValidateIdentifier validateIdentifier, ILockService lockService)
        {
            _transferService = transferService;
            _validateIdentifier = validateIdentifier;
            _lockService = lockService;
        }

        public override void SetDomainContext(UpdateMrdcX9CheckRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<UpdateMrdcX9CheckResponse> VerifyIdentifiers(UpdateMrdcX9CheckRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new UpdateMrdcX9CheckResponse { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpdateMrdcX9CheckResponse>(e, request));
            }
        }

        public override Task<UpdateMrdcX9CheckResponse> Handle(UpdateMrdcX9CheckRequest request)
        {
            try
            {
                if (request.RequestHeader.RequestId == Guid.Empty)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId,
                        $"{nameof(request)}.RequestHeader.RequestId must be specified");
                }

                if (string.IsNullOrEmpty(request.TransferIdentifier) || request.TransferIdentifier == unspecifiedGuid)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier,
                        $"{nameof(request)}.TransferIdentifier must be specified");
                }

                UpdateMrdcX9CheckResponse response = _transferService.UpdateCheckX9(request);

                return Task.FromResult(new UpdateMrdcX9CheckResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "success"
                    },
                    Transfer = new MrdcTransfer
                    {
                        CheckDeposit = new CheckDeposit
                        {
                            CheckDepositStatus = response.Transfer?.CheckDeposit.CheckDepositStatus,
                            CheckDepositSubStatus = response.Transfer?.CheckDeposit.CheckDepositSubStatus,
                            CheckDeclinedDate = response.Transfer.CheckDeposit.CheckDeclinedDate,
                            CheckReturnedDate = response.Transfer.CheckDeposit.CheckReturnedDate,
                            TransactionAmount = response.Transfer?.CheckDeposit.TransactionAmount != null ? Math.Round(Math.Floor(response.Transfer.CheckDeposit.TransactionAmount * 100) / 100 * 1.00M, 2) : 0.00M,
                        },
                        TransferStatus = response.Transfer?.TransferStatus,
                        TransferIdentifier = response.Transfer?.TransferIdentifier
                    },
                    PostingFullInfos = response.PostingFullInfos
                });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpdateMrdcX9CheckResponse>(e, request));
            }
        }

        public override async Task<UpdateMrdcX9CheckResponse> ObtainLock(UpdateMrdcX9CheckRequest request)
        {
            try
            {
                var lockId = request.TransferIdentifier;

                await _lockService.ObtainApiLock($"Transfer_Mrdc_X9_{lockId}");

                return new UpdateMrdcX9CheckResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<UpdateMrdcX9CheckResponse>(e, request);
            }
        }


        public override void ReleaseLock(UpdateMrdcX9CheckRequest request)
        {
            var lockId = request.TransferIdentifier;

            _lockService.ReleaseApiLock($"Transfer_Mrdc_X9_{lockId}");
        }
    }
}
