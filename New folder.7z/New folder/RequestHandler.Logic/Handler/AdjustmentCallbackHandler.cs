﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Application.AccountTransactions.Models;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers.Exceptions;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class AdjustmentCallbackHandler : CommandHandlerBase<AdjustmentCallbackRequest, AdjustmentCallbackResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IAccountTransactionService _accountTransactionService;
        private readonly ILockService _lockService;

        public AdjustmentCallbackHandler(
            IValidateIdentifier validateIdentifier,
            IAccountTransactionService accountTransactionService,
            ILockService lockService)
        {
            _validateIdentifier = validateIdentifier;
            _accountTransactionService = accountTransactionService;
            _lockService = lockService;
        }

        public override void SetDomainContext(AdjustmentCallbackRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<AdjustmentCallbackResponse> VerifyIdentifiers(AdjustmentCallbackRequest request)
        {
            try
            {
                if ((request?.RequestHeader?.RequestId ?? Guid.Empty) == Guid.Empty)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId,
                        $"{nameof(request)}.RequestHeader.RequestId must be specified");
                }

                if (string.IsNullOrEmpty(request.AccountTransactionIdentifier)
                    || !Guid.TryParse(request.AccountTransactionIdentifier, out _))
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier,
                        $"{nameof(request)}.AccountTransactionIdentifier must be specified and valid GUID.");
                }


                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier,
                    DomainContext.Current.ProgramCode);
                return Task.FromResult(new AdjustmentCallbackResponse() { ResponseHeader = new ResponseHeader() });
            }

            catch (AccountTransactionException<AdjustmentCallbackResponse> ea)
            {
                return Task.FromResult(ea.ResponseData);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AdjustmentCallbackResponse>(e, request));
            }
        }

        public override Task<AdjustmentCallbackResponse> Handle(AdjustmentCallbackRequest request)
        {
            try
            {
                AdjustmentCallbackResponse response;


                if (request.CallbackType?.ToUpper() == AdjustmentCallbackType.Complete.ToString().ToUpper())
                {
                    response = _accountTransactionService.RetryAdjustment(request);
                }
                else if (request.CallbackType?.ToUpper() == AdjustmentCallbackType.Cancel.ToString().ToUpper())
                {
                    response = _accountTransactionService.CancelAdjustment(request);
                }
                else if (request.CallbackType?.ToUpper() == AdjustmentCallbackType.Initiated.ToString().ToUpper())
                {
                    response = _accountTransactionService.AdjustPurseBalance(request);
                }
                else if (request.CallbackType?.ToUpper() == AdjustmentCallbackType.MMF.ToString().ToUpper())
                {
                    response = _accountTransactionService.AdjustBalance(request);
                }
                else
                {
                    throw new InvalidCallBackTypeException("Invalid callback type.");
                }

                return Task.FromResult(response);

            }
            catch (AccountTransactionException<AdjustmentCallbackResponse> ea)
            {
                return Task.FromResult(ea.ResponseData);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AdjustmentCallbackResponse>(e, request));
            }
        }

        public override async Task<AdjustmentCallbackResponse> ObtainLock(AdjustmentCallbackRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock($"{request.CallbackType.ToUpper()}_{request.AccountTransactionIdentifier}");
                return new AdjustmentCallbackResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<AdjustmentCallbackResponse>(e, request);
            }
        }

        public override void ReleaseLock(AdjustmentCallbackRequest request)
        {
            _lockService.ReleaseApiLock($"{request.CallbackType.ToUpper()}_{request.AccountTransactionIdentifier}");
        }
    }
}
