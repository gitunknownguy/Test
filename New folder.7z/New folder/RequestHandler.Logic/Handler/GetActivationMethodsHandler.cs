﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Experimental.System.Messaging;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.Common.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.DeviceProvisioning;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.DeviceProvisioning;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using NLog;
using RequestHandler.Logic.DataAccess;
using Twilio.Rest;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;

namespace RequestHandler.Logic.Handler
{
    public class GetActivationMethodsHandler : CommandHandlerBase<GetActivationMethodsRequest, GetActivationMethodsResponse>
    {
        private readonly IAccountService _accountService;
        private readonly IDeviceProvisioningMessageDataAccess _deviceProvisioningMessageDataAccess;
        private readonly ITokenizerService _tokenizerService;
        private readonly IRequestHandlerSettings _settings;

        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();

        public GetActivationMethodsHandler(IAccountService accountService,
            IDeviceProvisioningMessageDataAccess deviceProvisioningMessageDataAccess,
            ITokenizerService tokenizerService,
            IRequestHandlerSettings settings)
        {
            _accountService = accountService;
            _deviceProvisioningMessageDataAccess = deviceProvisioningMessageDataAccess;
            _tokenizerService = tokenizerService;
            _settings = settings;
        }

        public override void SetDomainContext(GetActivationMethodsRequest request)
        {
        }

        public override Task<GetActivationMethodsResponse> VerifyIdentifiers(GetActivationMethodsRequest request)
        {
            return Task.FromResult(new GetActivationMethodsResponse { ResponseHeader = new ResponseHeader() });
        }

        public override async Task<GetActivationMethodsResponse> Handle(GetActivationMethodsRequest request)
        {
            var tokenizedPan = _tokenizerService.TokenizePan(request.Pan);
            AccountPrimaryConsumerProfile consumerProfile = _accountService.GetAccountConsumerProfileByTokenizedPan(tokenizedPan);
            
            List<GetActivationMethod> getActivationMethods = new List<GetActivationMethod>();
            GetActivationMethodsResponse response = new GetActivationMethodsResponse
            {
                TraceId = request.TraceId,
                ResponseHeader = new ResponseHeader { ResponseId = request.RequestHeader.RequestId, Message = "Success" },
                GetActivationMethods = getActivationMethods
            };

            if (consumerProfile == null)
            {
                response.ResponseHeader = new ResponseHeader { ResponseId = request.RequestHeader.RequestId, Message = $"No consumer profile found {request.Pan}", StatusCode = 107 };
                _logger.Info($"No consumer profile found {request.RequestHeader.RequestId}.");
                return response;
            }

            OptionsContext.Current = OptionsContext.Current.Add("programCode", consumerProfile.ProgramCode);

            if (!consumerProfile.IsPrimaryAccountHolder)
            {
                var links = _accountService.GetLinkedAccount(consumerProfile.AccountIdentifier.ToString());
                _logger.Info($"find links for {consumerProfile.AccountIdentifier}, there are {links?.Count} records.");
                if (links != null && links.Any(l => new Guid(l.LinkAccountIdentifier) == consumerProfile.AccountIdentifier))
                {
                    var parentAccount = _accountService.GetAccount(links.FirstOrDefault().PrimaryAccountIdentifier);
                    var phoneNumber = _accountService.GetAccountPrimaryPhoneNumber(parentAccount.AccountIdentifier);
                    _logger.Info($"update the child's PhoneNumber of consumer profile {consumerProfile.PhoneNumber} to {phoneNumber}.");
                    consumerProfile.PhoneNumber = phoneNumber;
                }
            }

            if (!string.IsNullOrEmpty(consumerProfile.PhoneNumber))
            {
                getActivationMethods.Add(new GetActivationMethod()
                {
                    TokenReferenceId = request.TokenReferenceId,
                    Type = "phone",
                    Value = consumerProfile.PhoneNumber
                });

                if (_settings.EnableVoiceCallProgramCodeList.Any(x => x.Equals(consumerProfile.ProgramCode, StringComparison.OrdinalIgnoreCase))
                    && IsVoiceEligible(consumerProfile.PhoneNumber))
                {
                    getActivationMethods.Add(new GetActivationMethod()
                    {
                        TokenReferenceId = request.TokenReferenceId,
                        Type = "voice",
                        Value = consumerProfile.PhoneNumber
                    });
                }
            }

            if ("CARDHOLDER_STEPUP".Equals(request.OtpReason, StringComparison.OrdinalIgnoreCase))
            {
                if (consumerProfile.AccountStatus == AccountStatus.Closed)
                {
                    return response;
                }

                string pan = request.Pan ?? "";
                string last4Pan = pan.Length > 4 ? pan.Substring(pan.Length - 4, 4) : pan;
                var devices = _deviceProvisioningMessageDataAccess.GetPaymentIdentifierDeviceByPaymentIdentifierProxy(consumerProfile.PaymentIdentifierProxy, last4Pan);
                short[] lostStloenReasons = new short[] { 1, 11, 12, 13, 14 };
                //card still has active token but card was reported lost/stolen
                if (devices != null && devices.Any(d => d.DeviceStatusKey == 1 && d.PaymentIdentifierStatusKey == 4 && lostStloenReasons.Any(l => l.Equals(d.PaymentIdentifierStatusReasonKey ?? 0))))
                {
                    return response;
                }
            }

            // only add customer service number if we have a customer phone number
            if (("PROVISIONING".Equals(request.OtpReason, StringComparison.OrdinalIgnoreCase) && getActivationMethods.Any()) ||
                !"PROVISIONING".Equals(request.OtpReason, StringComparison.OrdinalIgnoreCase))
            {
                string callCenterPhone = GetCallCenterPhone(consumerProfile?.ProgramCode?.ToLower() ?? "");
                if (!string.IsNullOrEmpty(callCenterPhone))
                {
                    getActivationMethods.Add(new GetActivationMethod()
                    {
                        TokenReferenceId = request.TokenReferenceId,
                        Type = "CUSTOMERSERVICE",
                        Value = callCenterPhone
                    });
                }
            }
            await InsertDeviceProvisioningMessage(request, consumerProfile);

            return new GetActivationMethodsResponse
            {
                TraceId = request.TraceId,
                ResponseHeader = new ResponseHeader { ResponseId = request.RequestHeader.RequestId, Message = "Success" },
                GetActivationMethods = getActivationMethods
            };
        }

        public bool IsVoiceEligible(string phoneNumber)
        {
            var prohibitedAreaCodeList = _settings.ProhibitedAreaCodes.Split(",");
            return !prohibitedAreaCodeList.Contains(phoneNumber.Substring(0, 3));
        }

        private string GetCallCenterPhone(string programCode)
        {
            switch (programCode)
            {
                case "stash": return "1-800-205-5164";
                case "wf": return "1-844-995-8437";
                case "sep": return "1-833-337-6337";
                case "flex": return "1-855-676-0678";
                case "gbr": return "1-855-459-1334";
                case "intuitqb": return "1-888-463-4661";
                case "intuittc": return "1-888-463-4661";
                default: return "1-855-459-1334";
            }
        }

        private async Task InsertDeviceProvisioningMessage(GetActivationMethodsRequest activationMessage, AccountPrimaryConsumerProfile consumerProfile)
        {
            try
            {
                await _deviceProvisioningMessageDataAccess.InsertDeviceProvisioningMessage(activationMessage, consumerProfile.PaymentIdentifierProxy);
            }
            catch (Exception ex)
            {
                //This call should not obstruct the completion of the over all request, therefore, logging, and continuing.
                _logger.Warn($"[{nameof(GetActivationMethodsHandler)}{nameof(InsertDeviceProvisioningMessage)}] [Request ID: {activationMessage?.RequestHeader?.RequestId}] Recieved an error while attempting to create provisioning log entry. The request was not impacted. Exception: {ex}");
            }
        }
    }
}
