﻿using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.ExternalCardProfile;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ExternalCardProfile;
using RequestHandler.Core.Domain.Services.GlobalFundTransfer.Contracts;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using CardProfileInformation = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ExternalCardProfile.CardProfileInformation;

namespace Gd.Bos.RequestHandler.Logic.Handler
{

    public class GetExternalCardProfileHandler : CommandHandlerBase<GetExternalCardProfileGlobalFundTransferRequest, GetExternalCardProfileGlobalFundTransferResponse>
    {
        private readonly ITransferService _transferService;
        private static readonly string unspecifiedGuid = Guid.Empty.ToString();

        public GetExternalCardProfileHandler(ITransferService transferService, IValidateIdentifier validateIdentifier)
        {
            _transferService = transferService;
        }

        public override void SetDomainContext(GetExternalCardProfileGlobalFundTransferRequest request)
        {
        }

        public override Task<GetExternalCardProfileGlobalFundTransferResponse> VerifyIdentifiers(GetExternalCardProfileGlobalFundTransferRequest request)
        {
            return Task.FromResult(new GetExternalCardProfileGlobalFundTransferResponse() { ResponseHeader = new ResponseHeader() });

        }

        public override Task<GetExternalCardProfileGlobalFundTransferResponse> Handle(GetExternalCardProfileGlobalFundTransferRequest request)
        {
            try
            {
                if (request.RequestHeader.RequestId == Guid.Empty)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId, $"{nameof(request)}.RequestHeader.RequestId must be specified");
                }

                if (string.IsNullOrEmpty(request.ProgramCode) || request.ProgramCode == unspecifiedGuid)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier, $"{nameof(request)}.ProgramCode must be specified");
                }

                if (string.IsNullOrEmpty(request.CustomerToken) || request.CustomerToken == unspecifiedGuid)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier, $"{nameof(request)}.CustomerToken must be specified");
                }

                var gfRequest = MapGetExternalCardProfileRequest(request);
                var gfResponse = _transferService.GetExternalCardProfile(gfRequest);

                var response = new GetExternalCardProfileGlobalFundTransferResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                    CardProfileInformation = gfResponse.CardProfileInformation
                        ?.Select(x => new CardProfileInformation()
                        {
                            Bin = x.Bin,
                            CustomerToken = x.CustomerToken,
                            ExpirationMonth = x.ExpirationMonth,
                            ExpirationYear = x.ExpirationYear,
                            Last4Digits = x.Last4Digits,
                            LinkId = x.LinkId,
                            Network = x.Network
                        }).ToList()

                };
                if (gfResponse.ResponseDetails.Any())
                {
                    var firstDetail = gfResponse.ResponseDetails.First();

                    if (string.Compare(firstDetail.Description, "success", StringComparison.OrdinalIgnoreCase) != 0)
                    {
                        response.ResponseHeader.Message = firstDetail.Description;
                        response.ResponseHeader.Details = firstDetail.Description;
                        response.ResponseHeader.StatusCode = firstDetail.Code;
                        response.ResponseHeader.SubStatusCode = firstDetail.SubCode;
                    }
                }
                else
                {
                    response.ResponseHeader.Message = "Unknown Error";
                    response.ResponseHeader.Details = "Unknown Error";
                    response.ResponseHeader.StatusCode = 4214;
                    response.ResponseHeader.SubStatusCode = 1514;
                }

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetExternalCardProfileGlobalFundTransferResponse>(e, request));
            }

        }

        private GetExternalCardProfileRequest MapGetExternalCardProfileRequest(GetExternalCardProfileGlobalFundTransferRequest request)
        {
            return new GetExternalCardProfileRequest()
            {
                CustomerToken = request.CustomerToken,
                ProgramCode = request.ProgramCode,
                RequestId = request.RequestHeader.RequestId.ToString()
            };
        }
    }
}
