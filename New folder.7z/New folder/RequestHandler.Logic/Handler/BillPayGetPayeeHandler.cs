﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.BillPay;
using Gd.Bos.RequestHandler.Core.Domain.Services.BillPay.Mappers;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Service;
using System.Diagnostics.CodeAnalysis;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class BillPayGetPayeeHandler : CommandHandlerBase<BillPayGetPayeeRequest, BillPayGetPayeeResponse>
    {
        private readonly IBillPayService _billPayService;
        private readonly IValidateIdentifier _validateIdentifier;

        public BillPayGetPayeeHandler(IBillPayService billPayService, IValidateIdentifier validateIdentifier)
        {
            _billPayService = billPayService;
            _validateIdentifier = validateIdentifier;
        }

        public override Task<BillPayGetPayeeResponse> Handle(BillPayGetPayeeRequest request)
        {
            try
            {
                var response = _billPayService.GetPayee(request.ToGssModel());

                if (response == null)
                    throw new RequestHandlerException(503, 0, $"Unable to Get Payee for account {request.AccountIdentifier}");

                var coreResponse = response.ToCoreModel();
                coreResponse.ResponseHeader.ResponseId = request.RequestHeader.RequestId;

                return Task.FromResult(coreResponse);
            }
            catch (Exception ex)
            {
                return Task.FromResult(ex.HandleException<BillPayGetPayeeResponse>(ex, request));
            }
        }

        public override void SetDomainContext(BillPayGetPayeeRequest request)
        {
            if (!String.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<BillPayGetPayeeResponse> VerifyIdentifiers(BillPayGetPayeeRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new BillPayGetPayeeResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<BillPayGetPayeeResponse>(e, request));
            }
        }
    }
}
