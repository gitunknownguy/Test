﻿using Gd.Bos.RequestHandler.Logic.Queue;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.RequestHandler.Logic.Extension;
using RequestHandler.Core.Domain.Services.RetailCard;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using System.Linq;
using RequestHandler.Core.Domain.Services.Legacy;
using Account = Gd.Bos.RequestHandler.Core.Domain.Model.Account.Account;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetLegacyTransactionHandler : CommandHandlerBase<GetLegacyTransactionRequest, GetLegacyTransactionResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IRetailCardService _retailCardService;
        private readonly ILegacyTransactionService _legacyTransactionService;
        private readonly IPaymentInstrumentService _paymentInstrumentService;

        public GetLegacyTransactionHandler(IValidateIdentifier validateIdentifier,
            IRetailCardService retailCardService, IPaymentInstrumentService paymentInstrumentService, ILegacyTransactionService legacyTransactionService)
        {
            _validateIdentifier = validateIdentifier;
            _retailCardService = retailCardService;
            _paymentInstrumentService = paymentInstrumentService;
            _legacyTransactionService = legacyTransactionService;
        }

        public override Task<GetLegacyTransactionResponse> Handle(GetLegacyTransactionRequest request)
        {
            var response = new GetLegacyTransactionResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                }
            };

            try
            {
                if (!request.EndDate.HasValue)
                {
                    SetEndDate(request);
                }

                var tuple = _paymentInstrumentService.GetPaymentIdentifierInfoByAccountIdentifier(request.AccountIdentifier);
                Account account = tuple.Item1; //never be null

                //For Uber2.0, we split the flow here
                if (account != null && Configuration.Current.RetailCardProductCode.Split(',').Contains(account?.Product?.ProductCode.ToString()))
                {
                    //Only for retailcard
                    response = _retailCardService.GetLegacyTransactions(request);
                }
                else
                {
                    //for all other legacy products
                    response = _legacyTransactionService.GetLegacyTransactions(request);
                }

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetLegacyTransactionResponse>(e, request));
            }
        }

        private void SetEndDate(GetLegacyTransactionRequest request)
        {
            var tuple = _paymentInstrumentService.GetPaymentIdentifierInfoByAccountIdentifier(request.AccountIdentifier);
            var account = tuple.Item1;
            List<PaymentIdentifierInfo> paymentIdentifierInfoList = tuple.Item2;
            var paymentInstrumentInfoList = tuple.Item3;

            if (account?.Product != null && Configuration.Current.RetailCardProductCode.Split(',').Contains(account.Product.ProductCode.ToString()))
            {
                var legacyPaymentIdentifierData = paymentIdentifierInfoList.FirstOrDefault(a => a.IsTemp);
                var persoPaymentIdentifierData = paymentIdentifierInfoList.FirstOrDefault(a => a.IsTemp == false);

                var legacyPaymentInstrumentInfo = paymentInstrumentInfoList.FirstOrDefault(
                        a => a.PaymentIdentifierKey == legacyPaymentIdentifierData?.PaymentIdentifierKey
                        && a.PaymentInstrumentType == PaymentInstrumentType.MagStripe
                        && a.PaymentInstrumentStatus == PaymentInstrumentStatus.Activated);


                var persoPaymentInstrumentInfo = paymentInstrumentInfoList.FirstOrDefault(
                       a => a.PaymentIdentifierKey == persoPaymentIdentifierData?.PaymentIdentifierKey
                       && a.PaymentInstrumentType == PaymentInstrumentType.Emv
                       && a.PaymentInstrumentStatus == PaymentInstrumentStatus.Activated);


                if (persoPaymentInstrumentInfo != null && persoPaymentInstrumentInfo.ActivatedDateTime.HasValue)
                {
                    request.EndDate = persoPaymentInstrumentInfo.ActivatedDateTime.Value.AddDays(Configuration.Current.NecTransactionLookBackDays);
                }
                else if (legacyPaymentInstrumentInfo != null)
                {
                    //if NPNR
                    request.EndDate = DateTime.Now;
                }
            }

            if (!request.EndDate.HasValue)
            {
                //default if not set above
                request.EndDate = DateTime.Now;
            }
        }

        public override void SetDomainContext(GetLegacyTransactionRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetLegacyTransactionResponse> VerifyIdentifiers(GetLegacyTransactionRequest request)
        {
            _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
            return Task.FromResult(new GetLegacyTransactionResponse { ResponseHeader = new ResponseHeader() });
        }
    }
}
