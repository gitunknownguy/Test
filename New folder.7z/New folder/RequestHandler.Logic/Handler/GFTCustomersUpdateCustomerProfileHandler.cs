﻿using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System;
using System.Threading.Tasks;
using NLog;
using RequestHandler.Core.Domain.Services.GlobalFundTransfer;
using RequestHandler.Core.Domain.Services.GlobalFundTransfer.Contracts;
using Address = RequestHandler.Core.Domain.Services.GlobalFundTransfer.Contracts.Address;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.GFTCustomers;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.GFTCustomers;
using System.Linq;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Common;

namespace RequestHandler.Logic.Handler
{
    public class GFTCustomersUpdateCustomerProfileHandler : CommandHandlerBase<GFTCustomersUpdateCustomerProfileRequest, GFTCustomersUpdateCustomerProfileResponse>
    {
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        private readonly IGlobalFundTransferService _globalFundTransferService;
        private readonly IBaasConfiguration _baasConfiguration;

        public GFTCustomersUpdateCustomerProfileHandler(IGlobalFundTransferService globalFundTransferService, IBaasConfiguration baasConfiguration)
        {
            _globalFundTransferService = globalFundTransferService;
            _baasConfiguration = baasConfiguration;
        }

        public override void SetDomainContext(GFTCustomersUpdateCustomerProfileRequest request)
        {
        }

        public override Task<GFTCustomersUpdateCustomerProfileResponse> VerifyIdentifiers(GFTCustomersUpdateCustomerProfileRequest request)
        {
            try
            {
                return Task.FromResult(new GFTCustomersUpdateCustomerProfileResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GFTCustomersUpdateCustomerProfileResponse>(e, request));
            }
        }

        public override Task<GFTCustomersUpdateCustomerProfileResponse> Handle(GFTCustomersUpdateCustomerProfileRequest request)
        {
            try
            {
                if (!GFTCustomerTokenMapping.IsValidCustomerType(request.CustomerType))
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier, $"{nameof(request)}.Customer type is invalid");
                }

                var newAddress = request.Address ?? new GFTCustomersUpdateCustomerProfileRequest._.Address();

                UpdateCustomerProfileRequest updateCustomerProfileRequest = new UpdateCustomerProfileRequest
                {
                    FirstName = request.FirstName,
                    LastName = request.LastName,
                    MiddleName = request.MiddleName,
                    Email = request.Email,
                    PhoneNumber = request.PhoneNumber,
                    DateOfBirth = request.DateOfBirth,
                    ProgramCode = request.ProgramCode,
                    Address = new Address
                    {
                        AddressLine1 = newAddress.AddressLine1,
                        AddressLine2 = newAddress.AddressLine2,
                        City = newAddress.City,
                        State = newAddress.State,
                        ZipCode = newAddress.ZipCode
                    },
                    RequestId = request.RequestHeader.RequestId.ToString()
                };

                var updateCustomerProfileResponse = _globalFundTransferService.UpdateCustomerProfile(updateCustomerProfileRequest, request.CustomerToken);

                if (updateCustomerProfileResponse == null || updateCustomerProfileResponse.ResponseDetails == null)
                    throw new RequestHandlerException(0, 404, "updateCustomerProfileResponse is null");

                GFTCustomersUpdateCustomerProfileResponse response = new GFTCustomersUpdateCustomerProfileResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                    Status = updateCustomerProfileResponse.Customer?.Status,
                    CustomerToken = request.CustomerToken,
                    CustomerType = request.CustomerType
                };

                if (updateCustomerProfileResponse.ResponseDetails.Any())
                {
                    var firstDetail = updateCustomerProfileResponse.ResponseDetails.First();

                    if (string.Compare(firstDetail.Description, "success", StringComparison.OrdinalIgnoreCase) != 0)
                    {
                        response.ResponseHeader.Message = firstDetail.Description;
                        response.ResponseHeader.Details = firstDetail.Description;
                        response.ResponseHeader.StatusCode = firstDetail.Code;
                        response.ResponseHeader.SubStatusCode = firstDetail.SubCode;
                    }
                }
                else
                {
                    response.ResponseHeader.Message = "Unknown Error";
                    response.ResponseHeader.Details = "Unknown Error";
                    response.ResponseHeader.StatusCode = 4214;
                    response.ResponseHeader.SubStatusCode = 1514;
                }

                return Task.FromResult(response);
            }

            catch (InvalidProductMaterialException e)
            {
                var response = new GFTCustomersUpdateCustomerProfileResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 4,
                        SubStatusCode = 312,
                        Message = e.Message
                    },
                };
                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                var eResult = e.HandleException<GFTCustomersUpdateCustomerProfileResponse>(e, request);

                Logger.Info($"post UpdateCustomerProfile failure, prospectId:{DomainContext.Current.ProspectIdentifier},prospectType:{DomainContext.Current.ProspectType},statusCode:{eResult.ResponseHeader.StatusCode},subStatusCode:{eResult.ResponseHeader.SubStatusCode},statusMessage:{eResult.ResponseHeader.Message},statusDetails:{eResult.ResponseHeader.Details}");
                return Task.FromResult(eResult);
            }
        }
    }
}
