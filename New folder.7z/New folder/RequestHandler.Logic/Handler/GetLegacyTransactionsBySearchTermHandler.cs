﻿using Gd.Bos.RequestHandler.Logic.Queue;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.RequestHandler.Logic.Extension;
using RequestHandler.Core.Domain.Services.RetailCard;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using System.Linq;
using RequestHandler.Core.Domain.Services.Legacy;
using Account = Gd.Bos.RequestHandler.Core.Domain.Model.Account.Account;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetLegacyTransactionsBySearchTermHandler : CommandHandlerBase<GetLegacyTransactionBySearchTermRequest, GetLegacyTransactionResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IRetailCardService _retailCardService;
        private readonly ILegacyTransactionService _legacyTransactionService;
        private readonly IPaymentInstrumentService _paymentInstrumentService;

        public GetLegacyTransactionsBySearchTermHandler(IValidateIdentifier validateIdentifier,
            IRetailCardService retailCardService, IPaymentInstrumentService paymentInstrumentService, ILegacyTransactionService legacyTransactionService)
        {
            _validateIdentifier = validateIdentifier;
            _retailCardService = retailCardService;
            _paymentInstrumentService = paymentInstrumentService;
            _legacyTransactionService = legacyTransactionService;
        }

        public override Task<GetLegacyTransactionResponse> Handle(GetLegacyTransactionBySearchTermRequest request)
        {
            var response = new GetLegacyTransactionResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                }
            };

            try
            {
                var tuple = _paymentInstrumentService.GetPaymentIdentifierInfoByAccountIdentifier(request.AccountIdentifier);
                Account account = tuple.Item1; //never be null

                //For Uber2.0, we split the flow here
                if (account != null && Configuration.Current.RetailCardProductCode.Split(',').Contains(account.Product.ProductCode.ToString()))
                {
                    //Only for retailcard
                    response = _retailCardService.GetLegacyTransactionsBySearchTerm(request);
                }
                else
                {
                    //for all other legacy products
                    response = _legacyTransactionService.GetLegacyTransactionsBySearchTerm(request);
                }

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetLegacyTransactionResponse>(e, request));
            }
        }

        public override void SetDomainContext(GetLegacyTransactionBySearchTermRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetLegacyTransactionResponse> VerifyIdentifiers(GetLegacyTransactionBySearchTermRequest request)
        {
            _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
            return Task.FromResult(new GetLegacyTransactionResponse { ResponseHeader = new ResponseHeader() });
        }
    }
}
