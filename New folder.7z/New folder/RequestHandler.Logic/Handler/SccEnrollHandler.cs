﻿using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.DataAccesses;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using RequestHandler.Core.Application;
using RequestHandler.Core.Domain.Model;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using AccountHolder = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.AccountHolder;
using AccountStatus = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountStatus;
using AccountStatusReason = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountStatusReason;
using CardExpirationDate = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.CardExpirationDate;
using FrequencyType = Gd.Bos.RequestHandler.Core.Application.FrequencyType;
using KycStateData = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using User = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.User;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class SccEnrollHandler : CommandHandlerBase<SccEnrollRequest, SccEnrollResponse>
    {
        private readonly IRequestDataAccess _requestDataAccess;
        private readonly IEnrollmentDataAccess _enrollmentDataAccess;
        private readonly ISccEnrollmentService _enrollmentService;
        private readonly ILazyCache _lazyCache;
        private readonly IAgreementDataAccess _agreementRepository;
        private readonly INotificationService _notificationPublisher;
        private readonly IWelcomeNotificationService _welcomeNotificationService;
        private readonly ILockService _lockService;
        private readonly IProductService _productService;
        private readonly IProgramRepository _programRepository;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IEligibilityCheckService _eligibilitiesService;
        private readonly IAccountService _accountService;
        private readonly IUserService _userService;
        private readonly ICustomerNotificationService _customerNotificationService;
        private string _sccReferencedAccountIdentifierLocker = $"scc{DomainContext.Current.ReferencedAccountIdentifier}";

        private readonly short _expiredMonth = 6;

        public SccEnrollHandler(IRequestDataAccess requestDataAccess, IEnrollmentDataAccess enrollmentDataAccess,
            ISccEnrollmentService enrollmentService,
            ILazyCache lazyCache, IAgreementDataAccess agreementRepository,
            INotificationService notificationPublisher, IEligibilityCheckService eligibilitiesService,
            IWelcomeNotificationService welcomeNotificationService, ILockService lockService,
            IProductService productService, IProgramRepository programRepository,
            IValidateIdentifier validateIdentifier,
            IAccountService accountService,
            IUserService userService,
            ICustomerNotificationService customerNotificationService
        )
        {
            _requestDataAccess = requestDataAccess;
            _enrollmentDataAccess = enrollmentDataAccess;
            _enrollmentService = enrollmentService;
            _lazyCache = lazyCache;
            _agreementRepository = agreementRepository;
            _notificationPublisher = notificationPublisher;
            _welcomeNotificationService = welcomeNotificationService;
            _lockService = lockService;
            _productService = productService;
            _programRepository = programRepository;
            _validateIdentifier = validateIdentifier;
            _eligibilitiesService = eligibilitiesService;
            _accountService = accountService;
            _userService = userService;

            _customerNotificationService = customerNotificationService;
        }

        public override void SetDomainContext(SccEnrollRequest request)
        {
            DomainContext.Current.ReferencedAccountIdentifier = request.SccCreationData?.DdaAccountIdentifier;
            _sccReferencedAccountIdentifierLocker = $"scc{request.SccCreationData?.DdaAccountIdentifier}";
            DomainContext.Current.ProgramCode = ProgramCode.FromString(request.ProgramCode);
        }

        public override Task<SccEnrollResponse> VerifyIdentifiers(SccEnrollRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.ReferencedAccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new SccEnrollResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<SccEnrollResponse>(e, request));
            }
        }

        public override async Task<SccEnrollResponse> ObtainLock(SccEnrollRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock(OptionsContext.Current.GetString("requestId"));
                await _lockService.ObtainApiLock(_sccReferencedAccountIdentifierLocker);

                return new SccEnrollResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<SccEnrollResponse>(e, request);
            }
        }

        public override Task<SccEnrollResponse> Handle(SccEnrollRequest request)
        {
            try
            {
                if (request.AccountCreationData == null)
                {
                    throw new ArgumentNullException(nameof(request.AccountCreationData));
                }

                if (request.SccCreationData == null)
                {
                    throw new ArgumentNullException(nameof(request.SccCreationData));
                }

                EnrollResult enrollResult = null;
                var response = new SccEnrollResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success",
                        ResponseId = request.RequestHeader.RequestId
                    }
                };

                var newAccountIdentifier = Guid.NewGuid();
                var existingRequestAccountIdentifier = _requestDataAccess.InsertRequestId(RequestType.Enroll,
                    request.RequestHeader.RequestId, newAccountIdentifier);

                if (existingRequestAccountIdentifier.HasValue)
                {
                    newAccountIdentifier = existingRequestAccountIdentifier.Value;
                    enrollResult = GetSccEnrollIdempotentEnrollResult(newAccountIdentifier, request);
                    if (enrollResult == null)
                    {
                        GetSccEnrollIdempotentResponse(newAccountIdentifier, request.ProgramCode, response);
                        if (!string.IsNullOrEmpty(response.AccountIdentifier))
                        {
                            return Task.FromResult(response);
                        }
                    }
                }

                if (enrollResult == null)
                {
                    var eligibilityCheckResponse = _eligibilitiesService.SccEligibilities(null, request.ProgramCode, request.SccCreationData.DdaAccountIdentifier.ToString());
                    if (eligibilityCheckResponse.ResponseHeader.StatusCode != 0)
                    {
                        response.ResponseHeader = eligibilityCheckResponse.ResponseHeader;
                        response.ResponseHeader.ResponseId = request.RequestHeader.RequestId;

                        if (eligibilityCheckResponse.ResponseHeader.StatusCode == 1201 && eligibilityCheckResponse.ResponseHeader.SubStatusCode == 1600)
                        {
                            SendAdverseNotification(request, ExceedFraudLimitReason);
                        }

                        return Task.FromResult(response);
                    }
                }

                if (enrollResult == null)
                {
                    SetProductMaterialType(request);
                    var agreement =
                        _agreementRepository.GetAgreementsByProductCode(request.AccountCreationData.ProductCode);
                    var terms = request.AccountCreationData.TermsAcceptances?.ToDomain(agreement);

                    enrollResult = _enrollmentService.SccEnroll(newAccountIdentifier.ToString(),
                        request.ProgramCode,
                        request.AccountCreationData.ProductCode,
                        request.AccountCreationData.ProductMaterialType,
                        terms,
                        request.AccountCreationData.Language,
                        request.SccCreationData.DdaAccountIdentifier,
                        request.SccCreationData.Expense,
                        (FrequencyType)Enum.Parse(typeof(FrequencyType), request.SccCreationData.ExpenseFrequency, true),
                        request.SccCreationData.Income,
                        (FrequencyType)Enum.Parse(typeof(FrequencyType), request.SccCreationData.IncomeFrequency, true),
                        request.RequestHeader.RequestId);
                }

                var newUser = enrollResult.User;
                var newAccount = enrollResult.Account;
                var newPaymentIdentifier = enrollResult.PaymentIdentifier;
                var newAccountBalance = enrollResult.AccountBalance;
                var privateCardData = enrollResult.PrivateCardData;
                var creditLineRange = enrollResult.CreditLineRange;

                var errorCode = _lazyCache?.Value?.Get<string>(request.RequestHeader?.RequestId.ToString());
                if (!string.IsNullOrEmpty(errorCode) && errorCode != "0")
                {
                    response.ResponseHeader = response.ResponseHeader.GetResponseHeader(errorCode, request.RequestHeader.RequestId);
                }
                else
                {
                    response.ResponseHeader = response.ResponseHeader.GetResponseHeader(newAccount.ErrorCode.ToString(), request.RequestHeader.RequestId);
                    _lazyCache?.Value?.Set(request.RequestHeader?.RequestId.ToString(), newAccount.ErrorCode.ToString(), new TimeSpan(1, 0, 0, 0));
                }

                response.AccountIdentifier = newAccount.AccountIdentifier.ToString();
                response.AccountReferenceNumber = newAccount.CustomerAccountNumber;
                response.Status = newAccount.AccountStatus.ToString().ToLower();

                DateTime accountStatusDateChange = newAccount.AccountStatusChangedDateTime;
                accountStatusDateChange = accountStatusDateChange.ToUniversalTime();
                response.AccountStatusChangedDateTime =
                    accountStatusDateChange.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");

                if (newAccount.AccountStatusReasons?.Count > 0)
                {
                    response.StatusReasons = new List<string>();

                    foreach (AccountStatusReason statusReason in newAccount
                        .AccountStatusReasons)
                    {
                        response.StatusReasons.Add(statusReason.ToString());
                    }
                }

                response.DirectDepositInformation = new DirectDepositInformation
                {
                    AccountNumber = newAccount.AccountNumber,
                    RoutingNumber = newAccount.RoutingNumber
                };

                if (creditLineRange != null)
                {
                    response.CreditLineRange = new CreditLineRange
                    {
                        Expense = creditLineRange.Expense,
                        ExpenseFrequency = creditLineRange.ExpenseFrequency,
                        Income = creditLineRange.Income,
                        IncomeFrequency = creditLineRange.IncomeFrequency,
                        MinCreditLine = creditLineRange.MinCreditLine,
                        MaxCreditLine = creditLineRange.MaxCreditLine
                    };
                }

                if (newAccountBalance != null)
                {
                    response.Purses = new List<Purse>();
                    var purse = new Purse
                    {
                        PurseIdentifier = newAccountBalance.AccountBalanceIdentifier.ToString(),
                        PurseType = PurseType.Primary,
                        AvailableBalance = newAccountBalance.AvailableBalance,
                        LedgerBalance = newAccountBalance.CurrentBalance,
                        AvailableBalanceAsOfDateTime = newAccountBalance.AvailableBalanceAsOfDate,
                        LedgerBalanceAsOfDateTime = newAccountBalance.CurrentBalanceAsOfDate,
                        Status = newAccountBalance.Status
                    };
                    response.Purses.Add(purse);
                }

                response.AccountHolders = new List<AccountHolder>();
                var accountHolder = new AccountHolder();

                foreach (var ah in newAccount.AccountHolders)
                {
                    accountHolder.User = new User
                    {
                        UserIdentifier = newUser.UserIdentifier.ToString(),
                        Status = UserStatus.Active,
                        IsPrimaryAccountHolder = true,
                        KycStateData = new KycStateData
                        {
                            OfacStatus = ah.kycStateData.OfacStatus.ToString().ToLower(),
                            KycStatus = ah.kycStateData.KycStatus.ToString().ToLower(),
                            PendingKycGate = ah.kycStateData.KycPendingGate.ToLower()
                        }
                    };


                    if (newPaymentIdentifier != null)
                    {
                        accountHolder.PaymentInstruments = new List<PaymentInstrument>();
                        var paymentInstrument = new PaymentInstrument();
                        Enum.TryParse(newPaymentIdentifier.PaymentInstrument.Status, out PaymentInstrumentStatus paymentInstrumentStatus);

                        paymentInstrument.PaymentIdentifier = newPaymentIdentifier.PaymentIdentifierIdentifier.ToString();
                        paymentInstrument.PaymentInstrumentIdentifier = newPaymentIdentifier.PaymentInstrument
                            .PaymentInstrumentIdentifier.ToString();
                        paymentInstrument.PaymentInstrumentType =
                            newPaymentIdentifier.PaymentInstrument.PaymentInstrumentType;
                        paymentInstrument.Status = paymentInstrumentStatus;
                        paymentInstrument.IsPinSet = newPaymentIdentifier.PaymentInstrument.PinSetDate.HasValue;
                        paymentInstrument.Last4Pan = newPaymentIdentifier.PaymentInstrument.Last4Pan;
                        paymentInstrument.ActivatedDateTime = newPaymentIdentifier.PaymentInstrument.ActivatedDateTime;
                        paymentInstrument.IssuedDateTime = newPaymentIdentifier.PaymentInstrument.IssuedDateTime;

                        if (privateCardData != null)
                        {
                            paymentInstrument.PrivateCardData =
                                new Bos.Shared.Common.Core.CoreApi.Contract.Data.PrivateCardData
                                {
                                    Pan = privateCardData.Pan,
                                    Cvv = privateCardData.Cvv,
                                    ExpirationDate = new CardExpirationDate
                                    {
                                        CardExpirationMonth = privateCardData.CardExpirationDate.CardExpirationMonth,
                                        CardExpirationyear = privateCardData.CardExpirationDate.CardExpirationYear
                                    }
                                };

                            if (paymentInstrument.PaymentInstrumentType == PaymentInstrumentType.Virtual)
                                paymentInstrument.IsPrivateDataViewable = "true";
                        }

                        accountHolder.PaymentInstruments.Add(paymentInstrument);
                    }

                    response.AccountHolders.Add(accountHolder);
                }

                var accountResp = _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(newAccount.AccountIdentifier.ToString(), request.ProgramCode, false);

                _notificationPublisher.PublishNotification(request.ProgramCode, accountResp.Account, EventType.AccountUpdated, request.RequestHeader.RequestId.ToString());
                if (accountResp.Account.Status == "normal")
                {
                    _welcomeNotificationService.RaiseWelcomeNotification(request.ProgramCode, accountResp.Account.AccountIdentifier, request.RequestHeader.RequestId);
                    var customerInfo =
                        _userService.GetUser(AccountIdentifier.FromGuid(request.SccCreationData.DdaAccountIdentifier), null)
                            ?.FirstOrDefault(x => x.IsPrimaryAccountHolder);
                    var phone = customerInfo.PhoneNumbers.FirstOrDefault(p => p.IsDefault);
                    _customerNotificationService.EnrollNotificationsWhenKycApprovedAsync(accountResp.Account.AccountIdentifier, request.ProgramCode, accountResp.Account.ProductCode, phone?.Number, customerInfo.Email?.EmailAddress, request.RequestHeader.RequestId);
                }
                else if (_accountService.IsDeclinedAccount(accountResp.Account))
                    _welcomeNotificationService.RaiseUnwelcomeNotification(request.ProgramCode, accountResp.Account.AccountIdentifier, request.RequestHeader.RequestId);

                return Task.FromResult(response);
            }
            catch (InvalidProductMaterialException e)
            {
                var exceptionResponse = new SccEnrollResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 4,
                        SubStatusCode = 312,
                        Message = e.Message
                    },
                };
                return Task.FromResult(exceptionResponse);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<SccEnrollResponse>(e, request));
            }
        }

        public override void ReleaseLock(SccEnrollRequest request)
        {
            _lockService.ReleaseApiLock(OptionsContext.Current.GetString("requestId"));
            _lockService.ReleaseApiLock(_sccReferencedAccountIdentifierLocker);
        }

        private void SetProductMaterialType(SccEnrollRequest request)
        {
            var productMaterialType = request.AccountCreationData.ProductMaterialType;

            if (!string.IsNullOrEmpty(productMaterialType))
            {
                if (!_productService.IsValidProductMaterialTypeForProductTier(request.ProgramCode, productMaterialType))
                    throw new InvalidProductMaterialException("Invalid Product Material type");
            }
            else if (string.IsNullOrEmpty(productMaterialType))
            {
                request.AccountCreationData.ProductMaterialType = GetDefaultProductMaterialType(request.ProgramCode, request.AccountCreationData.ProductCode);
            }
        }

        private string GetDefaultProductMaterialType(string programCode, string productCode)
        {
            var productMaterialType = string.Empty;
            var prg = _programRepository.GetByProgramIdentifier(ProgramCode.FromString(programCode));
            var prgInfo = _programRepository.GetProgramTierInfo(prg.ProgramKey);
            var valueList = prgInfo.ProductTiers.Where(p => p.ProductCode.Equals(productCode, StringComparison.InvariantCultureIgnoreCase) && p.ProductTierAttribute == "CardStock" && p.IsDefault).ToList();

            var processor = _enrollmentDataAccess.GetProcessorByProductCode(productCode);
            var defaultProductMaterialTypeList = prgInfo.ProductmaterialTypes
                ?.Where(pt => pt.ProcessorKey == (int)processor).OrderByDescending(pt => pt.IsDefault);


            if (defaultProductMaterialTypeList != null)
            {
                foreach (var defaultProductMaterialType in defaultProductMaterialTypeList)
                {
                    if (valueList.Exists(v => v.Value.Equals(defaultProductMaterialType.ProcessorValue, StringComparison.InvariantCultureIgnoreCase)))
                    {
                        productMaterialType = defaultProductMaterialType.ProductMaterialType;
                        break;
                    }
                }
            }

            if (string.IsNullOrEmpty(productMaterialType))
            {
                throw new InvalidProductMaterialException($"Can not find proper Product Material type for programCode {programCode}, productCode {productCode}");
            }

            return productMaterialType;
        }

        private EnrollResult GetSccEnrollIdempotentEnrollResult(Guid existingAccountIdentifier, SccEnrollRequest request)
        {
            EnrollResult result = null;
            var getEnrollmentResponse = _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(existingAccountIdentifier.ToString(), request.ProgramCode, true);
            if (getEnrollmentResponse.Account != null)
            {
                if (Enum.TryParse(getEnrollmentResponse.Account.Status, true, out AccountStatus accountStatus) && accountStatus == AccountStatus.Pending)
                {
                    SetProductMaterialType(request);
                    result = _enrollmentService.SccIdempotentEnroll(getEnrollmentResponse, request.ProgramCode, request.AccountCreationData.ProductCode, request.AccountCreationData.ProductMaterialType, request.SccCreationData.DdaAccountIdentifier);
                }
            }

            return result;
        }

        private void GetSccEnrollIdempotentResponse(Guid existingAccountIdentifier, string programCode, SccEnrollResponse response)
        {
            var getEnrollmentResponse = _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(existingAccountIdentifier.ToString(), programCode, true);
            if (getEnrollmentResponse.Account != null)
            {
                Enum.TryParse(getEnrollmentResponse.Account.Status, true, out AccountStatus accountStatus);
                if (accountStatus == AccountStatus.Locked && getEnrollmentResponse.Account.StatusReasons.Any(a => Enum.TryParse(a, true, out AccountStatusReason accountStatusReason) && accountStatusReason == AccountStatusReason.abilityToPayCheckFailed))
                {
                    throw new ValidationException(1201, 1608, AbilityToPayCheckFailedMessage);
                }

                if (accountStatus == AccountStatus.Locked && getEnrollmentResponse.Account.StatusReasons.Any(a => Enum.TryParse(a, true, out AccountStatusReason accountStatusReason) && accountStatusReason == AccountStatusReason.registrationNotComplete))
                {
                    response.ResponseHeader.StatusCode = 2;
                    response.ResponseHeader.SubStatusCode = 31;
                    response.ResponseHeader.Message = OfacDeclinedMessage;
                }

                if (accountStatus == AccountStatus.Normal || response.ResponseHeader.StatusCode == 2 && response.ResponseHeader.SubStatusCode == 31)
                {
                    response.AccountIdentifier = getEnrollmentResponse.Account.AccountIdentifier;
                    response.AccountHolders = getEnrollmentResponse.Account.AccountHolders;
                    foreach (var accountHolder in response.AccountHolders)
                    {
                        accountHolder.User.FirstName = string.Empty;
                        accountHolder.User.LastName = null;
                        accountHolder.User.DobStatus = null;
                        accountHolder.User.Last4Identity = null;
                        accountHolder.User.IdentityType = null;
                        accountHolder.User.PeerTransferAcceptPreference = null;
                        accountHolder.AccountHolderIdentifier = null;
                    }
                    response.AccountReferenceNumber = getEnrollmentResponse.Account.CustomerReferenceNumber;
                    response.AccountStatusChangedDateTime = getEnrollmentResponse.Account.AccountStatusChangedDateTime;
                    response.DirectDepositInformation = getEnrollmentResponse.Account.DirectDepositInformation;
                    response.Purses = getEnrollmentResponse.Account.Purses;
                    response.Status = getEnrollmentResponse.Account.Status;
                    response.StatusCure = getEnrollmentResponse.Account.StatusCure;
                    response.StatusReasons = getEnrollmentResponse.Account.StatusReasons;

                    var primaryUserInfo = response.AccountHolders.FirstOrDefault(a => a.User.IsPrimaryAccountHolder)?.User;
                    if (primaryUserInfo != null)
                    {
                        var creditLineRange = _userService.GetCreditLineRange(primaryUserInfo.ConsumerProfileKey, programCode);
                        if (creditLineRange != null)
                        {
                            response.CreditLineRange = new CreditLineRange
                            {
                                Expense = creditLineRange.Expense,
                                ExpenseFrequency = creditLineRange.ExpenseFrequency,
                                Income = creditLineRange.Income,
                                IncomeFrequency = creditLineRange.IncomeFrequency,
                                MinCreditLine = creditLineRange.MinCreditLine,
                                MaxCreditLine = creditLineRange.MaxCreditLine
                            };
                        }
                    }
                }

            }
        }

        private void SendAdverseNotification(SccEnrollRequest request, string reason)
        {
            var ddaAccountIdentifier = request.SccCreationData.DdaAccountIdentifier.ToString();
            var ddaAccount = _accountService.GetAccountByAccountIdentifier(ddaAccountIdentifier);
            var primaryUser = ddaAccount.AccountHolders.FirstOrDefault(a => a.IsPrimary && a.ConsumerProfileTypeKey == 1);
            if (primaryUser == null)
            {
                throw new ValidationException(10, 0, UserNotFoundMessage);
            }

            var primaryUserInfo = _userService.GetUser(AccountIdentifier.FromString(ddaAccountIdentifier), primaryUser.UserIdentifier).FirstOrDefault();
            if (primaryUserInfo == null)
            {
                throw new ValidationException(10, 0, UserNotFoundMessage);
            }

            _enrollmentService.SendAdverseCustomerNotification(request.RequestHeader.RequestId, request.ProgramCode, request.AccountCreationData.ProductCode, ddaAccountIdentifier, primaryUserInfo, reason);
        }

        private const string OfacDeclinedMessage = "OFAC Match.";
        private const string UserNotFoundMessage = "User Not Found";
        private const string AbilityToPayCheckFailedMessage = "Ability To Pay Check Failed";
        private const string ExceedFraudLimitReason = "Customers may not open more than one GO2bank Secured Credit Card account at any given time.";
    }
}
