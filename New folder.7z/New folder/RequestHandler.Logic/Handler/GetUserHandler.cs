﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Address = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Address;
using Email = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Email;
using PhoneNumber = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PhoneNumber;
using UserProfile = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.UserProfile;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetUserHandler : CommandHandlerBase<GetUserRequest, GetUserResponse>
    {
        private readonly IUserService _userService;
        private readonly IValidateIdentifier _validateIdentifier;

        public GetUserHandler(IUserService userService, IValidateIdentifier validateIdentifier)
        {
            _userService = userService;
            _validateIdentifier = validateIdentifier;
        }
        public override void SetDomainContext(GetUserRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            if (!string.IsNullOrEmpty(request.UserIdentifier))
                DomainContext.Current.UserIdentifier = request.UserIdentifier;
        }

        public override Task<GetUserResponse> VerifyIdentifiers(GetUserRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidateConsumerProfileIdentifier(DomainContext.Current.AccountIdentifier, DomainContext.Current.UserIdentifier);
                return Task.FromResult(new GetUserResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetUserResponse>(e, request));
            }
        }

        public override Task<GetUserResponse> Handle(GetUserRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.AccountIdentifier) && string.IsNullOrEmpty(request.UserIdentifier))
                    throw new AccountNotFoundException();

                AccountIdentifier accountIdentifier = null;
                UserIdentifier userIdentifier = null;

                if (!string.IsNullOrEmpty(request.AccountIdentifier))
                    accountIdentifier = AccountIdentifier.FromString(request.AccountIdentifier);

                if (!string.IsNullOrEmpty(request.UserIdentifier))
                    userIdentifier = UserIdentifier.FromString(request.UserIdentifier);

                List<UserProfile> users = ConvertToOutput(_userService.GetUser(accountIdentifier, userIdentifier), request.AccountIdentifier);
                var response = new GetUserResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                    Users = users
                };
                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetUserResponse>(e, request));
            }
        }

        private List<UserProfile> ConvertToOutput(List<Gd.Bos.RequestHandler.Core.Domain.Model.User.UserProfile> domainUsers, string accountIdentifier)
        {
            List<UserProfile> users = new List<UserProfile>();
            foreach (Gd.Bos.RequestHandler.Core.Domain.Model.User.UserProfile domainUser in domainUsers)
            {
                List<Address> addresses = new List<Address>();
                foreach (Gd.Bos.RequestHandler.Core.Domain.Model.User.Address domainAddress in domainUser.Addresses)
                {
                    Address address = new Address();
                    if (!string.IsNullOrEmpty(domainAddress.AddressLine1)) address.AddressLine1 = domainAddress.AddressLine1;
                    if (!string.IsNullOrEmpty(domainAddress.AddressLine2)) address.AddressLine2 = domainAddress.AddressLine2;
                    if (!string.IsNullOrEmpty(domainAddress.City)) address.City = domainAddress.City;
                    if (!string.IsNullOrEmpty(domainAddress.Country)) address.CountryCode = domainAddress.Country;
                    if (!string.IsNullOrEmpty(domainAddress.State)) address.State = domainAddress.State;
                    if (!string.IsNullOrEmpty(domainAddress.ZipCode)) address.ZipCode = domainAddress.ZipCode;
                    if (!string.IsNullOrEmpty(domainAddress.Type)) address.Type = domainAddress.Type;
                    address.IsDefault = domainAddress.IsDefault;
                    address.IsReturned = domainAddress.IsVerified;
                    if (domainAddress.LastModified != DateTimeOffset.MinValue)
                        address.LastUpdatedDateTime = domainAddress.LastModified.DateTime;
                    if (domainAddress.Created != DateTimeOffset.MinValue)
                        address.CreatedDateTime = domainAddress.Created.DateTime;
                    addresses.Add(address);
                }

                List<PhoneNumber> phoneNumbers = new List<PhoneNumber>();
                foreach (Gd.Bos.RequestHandler.Core.Domain.Model.User.PhoneNumber domainPhone in domainUser.PhoneNumbers)
                {
                    PhoneNumber phone = new PhoneNumber();
                    if (!string.IsNullOrEmpty(domainPhone.Number)) phone.Number = domainPhone.Number;
                    phone.Type = domainPhone.Type;
                    phone.IsDefault = domainPhone.IsDefault;
                    phone.IsVerified = domainPhone.IsVerified;
                    if (domainPhone.LastModified != DateTimeOffset.MinValue)
                        phone.LastUpdatedDateTime = domainPhone.LastModified.DateTime;
                    phoneNumbers.Add(phone);
                }

                List<Identity> identities = new List<Identity>();
                foreach (Identity domainIdentity in domainUser.Identities)
                {
                    var identity = new Identity()
                    {
                        Last4Identity = domainIdentity.Last4Identity,
                        IdentityType = domainIdentity.IdentityType,
                        CountryCode = domainIdentity.CountryCode
                    };
                    identities.Add(identity);
                }

                UserProfile user = new UserProfile
                {
                    AccountIdentifier = accountIdentifier,
                    UserIdentifier = domainUser.UserIdentifier.ToString(),
                    PeerTransferAcceptPreference = domainUser.IsTransferAutoAccept == false ? "manual" : "automatic",
                    ProfileData = new ProfileData
                    {
                        FirstName = string.IsNullOrEmpty(domainUser.FirstName) ? null : domainUser.FirstName,
                        MiddleName = string.IsNullOrEmpty(domainUser.MiddleName) ? null : domainUser.MiddleName,
                        LastName = string.IsNullOrEmpty(domainUser.LastName) ? null : domainUser.LastName,
                        Addresses = addresses,
                        DateOfBirth = domainUser.DateOfBirth
                    },
                    PhoneNumbers = phoneNumbers,
                    Identities = identities,
                    TermsAcceptances = domainUser.TermsAcceptances
                };
                if (domainUser.LastModified != DateTimeOffset.MinValue)
                    user.ProfileData.LastUpdatedDateTime = domainUser.LastModified.DateTime;

                if (domainUser.Email != null)
                {
                    user.Email = new Email
                    {
                        EmailAddress = domainUser.Email.EmailAddress,
                        IsDefault = domainUser.Email.IsPrimary,
                        IsVerified = domainUser.Email.IsVerified,
                        LastUpdatedDateTime = domainUser.Email.LastModified.DateTime
                    };
                }

                // add the Email history
                user.EmailHistory = domainUser.EmailHistory?.ConvertAll(email => new Email
                {
                    EmailAddress = email.EmailAddress,
                    IsDefault = email.IsPrimary,
                    IsVerified = email.IsVerified,
                    LastUpdatedDateTime = email.LastModified.DateTime
                }) ?? [];

                // add the PhoneNumber history
                user.PhoneNumbersHistory = domainUser.PhoneNumbersHistory?.ConvertAll(phone => new PhoneNumber
                {
                    Number = phone.Number,
                    Type = phone.Type,
                    IsDefault = phone.IsDefault,
                    IsVerified = phone.IsVerified,
                    LastUpdatedDateTime = phone.LastModified.DateTime
                }) ?? [];
                
                users.Add(user);
            }

            return users;
        }
    }
}
