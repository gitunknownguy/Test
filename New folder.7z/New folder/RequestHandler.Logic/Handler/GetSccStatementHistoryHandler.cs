﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.LoanManagement;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.LoanManagement;
using Gd.Bos.RequestHandler.Core.Domain.Services.LoanManagement;
using Gd.Bos.RequestHandler.Logic.Service;
using NLog;
using Gd.Bos.RequestHandler.Logic.Extension;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;

namespace RequestHandler.Logic.Handler
{
    public class GetSccStatementHistoryHandler : CommandHandlerBase<GetStatementHistoryRequest, GetStatementHistoryResponse>
    {
        private readonly ILoanManagementService _loanManagementService;

        private readonly IValidateIdentifier _validateIdentifier;
        // private readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        public GetSccStatementHistoryHandler(IValidateIdentifier validateIdentifier, ILoanManagementService loanManagementService)
        {
            _loanManagementService = loanManagementService;
            _validateIdentifier = validateIdentifier;
        }
        public override void SetDomainContext(GetStatementHistoryRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;

        }

        public override Task<GetStatementHistoryResponse> VerifyIdentifiers(GetStatementHistoryRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetStatementHistoryResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetStatementHistoryResponse>(e, request));
            }
        }

        public override Task<GetStatementHistoryResponse> Handle(GetStatementHistoryRequest request)
        {
            try
            {
                GetStatementHistoryResponse response;
                if (!DateTime.TryParseExact(
                        request.StartMonth + "/01" + "/" + request.StartYear,
                        "M/dd/yyyy",
                        CultureInfo.InvariantCulture,
                        DateTimeStyles.None,
                        out var startDate)
                    || !DateTime.TryParseExact(
                        request.EndMonth + "/01" + "/" + request.EndYear,
                        "M/dd/yyyy",
                        CultureInfo.InvariantCulture,
                        DateTimeStyles.None,
                        out var endDate)
                   || endDate < startDate
                   || endDate.AddMonths(-12) >= startDate)
                {
                    response = new GetStatementHistoryResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 400,
                            SubStatusCode = 0,
                            Message = "Date format or range is invalid."
                        }
                    };
                    return Task.FromResult(response);
                }

                response = _loanManagementService.GetStatementHistory(request.AccountIdentifier.ToString(), request.ProgramCode, request);
                return Task.FromResult(response);
            }
            catch (Exception ex)
            {
                return Task.FromResult(ex.HandleException<GetStatementHistoryResponse>(ex, request));
            }

        }
    }
}
