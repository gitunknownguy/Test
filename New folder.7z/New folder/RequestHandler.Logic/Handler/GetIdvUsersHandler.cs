﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using RequestHandler.Core.Application;

namespace RequestHandler.Logic.Handler
{
    public class GetIdvUsersHandler : CommandHandlerBase<GetIdvUsersRequest, GetIdvUsersResponse>
    {
        private readonly ISaveBusinessOwnerInfoService _businessOwnerInfoService;
        private readonly IValidateIdentifier _validateIdentifier;

        public GetIdvUsersHandler(ISaveBusinessOwnerInfoService businessOwnerInfoService
            , IValidateIdentifier validateIdentifier)
        {
            _businessOwnerInfoService = businessOwnerInfoService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(GetIdvUsersRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
            {
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            }
        }

        public override Task<GetIdvUsersResponse> VerifyIdentifiers(GetIdvUsersRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier,
                    DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetIdvUsersResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetIdvUsersResponse>(e, request));
            }
        }

        public override Task<GetIdvUsersResponse> Handle(GetIdvUsersRequest request)
        {
            var response = new GetIdvUsersResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                }
            };

            try
            {
                var info = _businessOwnerInfoService.GetIdvUsers(request);
                response.Users = info.Users;
                if (info == null)
                {
                    response.ResponseHeader.StatusCode = 10;
                    response.ResponseHeader.SubStatusCode = 0;
                    response.ResponseHeader.Message = "Account not found.";

                    return Task.FromResult(response);
                }

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetIdvUsersResponse>(e, request));
            }
        }
    }
}
