﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Enums;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Model.User.PreInterventions;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Logic.Exceptions;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;
using RequestHandler.Core.Domain.Services.CNAPI;
using RequestHandler.Core.Domain.Services.CNAPI.Messages.Request;
using RequestHandler.Core.Domain.Services.Risk.Messages.Request;
using RequestHandler.Core.Domain.Services.TokenManagementService;
using RequestHandler.Core.Domain.Services.TokenManagementService.EventMessage;
using Address = Gd.Bos.RequestHandler.Core.Domain.Model.User.Address;
using Email = Gd.Bos.RequestHandler.Core.Domain.Model.User.Email;
using IServiceBusNotificationPublisher = RequestHandler.Core.Domain.Services.AzureServiceBus.IServiceBusNotificationPublisher;
using PhoneNumber = Gd.Bos.RequestHandler.Core.Domain.Model.User.PhoneNumber;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class UpdateUserProfileHandler : CommandHandlerBase<UpdateUserProfileRequest, UpdateUserProfileResponse>
    {

        private readonly IUserService _userService;
        private readonly INotificationService _notificationPublisher;
        private readonly IContactService _contactService;
        private readonly IBaasConfiguration _baasConfiguration;
        private readonly IAddressIntervention _addressIntervention;
        private readonly IPhoneIntervention _phoneIntervention;
        private readonly IAccountService _accountService;
        private readonly ITermsAcceptanceService _termsAcceptanceService;
        private readonly IRiskService _riskService;
        private readonly IContactChangeEligibilityService _contactChangeEligibilityService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IGssFraudEventService _gssFraudEventService;
        private readonly ICNAPIService _cNAPIService;
        private readonly IAccountRepository _accountRepository;
        private readonly ITokenManagementService _tokenManagementService;

        private readonly IEnumerable<string> _peerTransferType = new List<string> { "manual", "automatic" };

        public UpdateUserProfileHandler(IUserService userService,
            INotificationService notificationPublisher,
            IContactService contactService,
            IValidateIdentifier validateIdentifier,
            IBaasConfiguration baasConfiguration,
            IAddressIntervention addressIntervention,
            IPhoneIntervention phoneIntervention,
            IAccountService accountService,
            ITermsAcceptanceService termsAcceptanceService,
            IRiskService riskService,
            IContactChangeEligibilityService contactChangeEligibilityService,
            IGssFraudEventService gssFraudEventService,
            ICNAPIService cNAPIService,
            IAccountRepository accountRepository,
            ITokenManagementService tokenManagementService)
        {
            _userService = userService;
            _notificationPublisher = notificationPublisher;
            _validateIdentifier = validateIdentifier;
            _contactService = contactService;
            _baasConfiguration = baasConfiguration;
            _addressIntervention = addressIntervention;
            _phoneIntervention = phoneIntervention;
            _accountService = accountService;
            _termsAcceptanceService = termsAcceptanceService;
            _riskService = riskService;
            _contactChangeEligibilityService = contactChangeEligibilityService;
            _gssFraudEventService = gssFraudEventService;
            _cNAPIService = cNAPIService;
            _accountRepository = accountRepository;
            _tokenManagementService = tokenManagementService;
        }


        public override void SetDomainContext(UpdateUserProfileRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            if (!string.IsNullOrEmpty(request.UserIdentifier))
                DomainContext.Current.UserIdentifier = request.UserIdentifier;
        }


        public override Task<UpdateUserProfileResponse> VerifyIdentifiers(UpdateUserProfileRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidateConsumerProfileIdentifier(DomainContext.Current.AccountIdentifier, DomainContext.Current.UserIdentifier);
                _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 4, 105);

                return Task.FromResult(new UpdateUserProfileResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpdateUserProfileResponse>(e, request));
            }
        }


        public override async Task<UpdateUserProfileResponse> Handle(UpdateUserProfileRequest request)
        {
            if (request.PeerTransferAcceptPreference != null && !_peerTransferType.Contains(request.PeerTransferAcceptPreference.ToLower()))
                throw new UpdateUserProfileException("Invalid PeerTransferAcceptPreference.");

            var newAddresses = request.ProfileData?.Addresses != null
                ? ConvertToDomainAddresses(request.ProfileData.Addresses)
                : new List<Address>();

            var newPhoneNumbers = request.PhoneNumbers != null
                ? ConvertToDomainPhoneNumbers(request.PhoneNumbers)
                : new List<PhoneNumber>();

            var newConsumerProfileExtensions = request.ConsumerProfileExtensionAttributes != null
                ? request.ConsumerProfileExtensionAttributes.Select(c => new ConsumerProfileExtensionV2()
                {
                    ConsumerProfileExtensionAttribute = c.ConsumerProfileExtensionAttribute,
                    ConsumerProfileExtensionAttributeValue = c.ConsumerProfileExtensionAttributeValue
                }).ToList()
                : new List<ConsumerProfileExtensionV2>();

            Email newEmail = null;
            if (request.Email != null && !string.IsNullOrEmpty(request.Email.EmailAddress))
            {
                newEmail = new Email(request.Email.EmailAddress, false, true);
            }

            _addressIntervention.ValidAddresses(newAddresses, false);
            _phoneIntervention.ValidPhoneNumbers(newPhoneNumbers);
            VerifyBirthday(request?.ProfileData?.DateOfBirth);

            try
            {
                var accountInfo = _accountService.GetAccountByAccountIdentifier(request.AccountIdentifier);
                var userInfo = _userService.GetUser(request.AccountIdentifier, request.UserIdentifier).FirstOrDefault();

                // GBOS-101374 [SP][RH] Prevent updating parent's user profile from child account
                if (accountInfo != null && accountInfo.AccountKey > 0 && userInfo != null)
                {
                    NotAllowChildAccountUpdateParentProfile(userInfo.IsPrimaryAccountHolder, request.AccountIdentifier);
                }

                var consumerProfileTypeKey = accountInfo?.AccountHolders?.FirstOrDefault(x => x.ConsumerProfileKey == userInfo?.ConsumerProfileKey)?.ConsumerProfileTypeKey;

                var currentPrimaryPhone = userInfo?.PhoneNumbers?.FirstOrDefault(p => p.IsDefault);
                var phone = newPhoneNumbers.Find(f => f.IsDefault);
                if (phone == null)
                {
                    phone = newPhoneNumbers.Find(p => p.Type == currentPrimaryPhone?.Type);
                }
                if (phone != null && IsPhoneLimitCheckRequired(request.ProgramCode, consumerProfileTypeKey))
                {

                    try
                    {
                        _accountService.PhoneLimitVerification(phone.Number, "PhoneNumber",
                            accountInfo.Product.ProductCode.ToString(), request.ProgramCode);
                    }
                    catch (RequestHandlerException e)
                    {
                        throw new RequestHandlerException(5, e.SubCode, e.Message);
                    }

                }
                if (newEmail != null && !string.IsNullOrEmpty(newEmail?.EmailAddress))
                {

                    try
                    {
                        _accountService.EmailLimitVerification(newEmail.EmailAddress, 
                            accountInfo.Product.ProductCode.ToString(), request.ProgramCode);
                    }
                    catch (RequestHandlerException e)
                    {
                        throw new RequestHandlerException(5, e.SubCode, e.Message);
                    }
                }

                CheckContactVerificationStatus(newPhoneNumbers, newEmail, request);
                VerifyEligibility(request, accountInfo.Product.ProductCode.ToString(), newPhoneNumbers, accountInfo.ProductTierKey);
                VerifyDataShareEligibility(request, newAddresses, userInfo);

                await _termsAcceptanceService.UpdateTermAcceptances(request.AccountIdentifier, request.UserIdentifier,
                    request.TermsAcceptances?.ToArray(), request.RequestHeader?.RequestId ?? Guid.NewGuid());

                var userIdCreateDate = string.IsNullOrEmpty(request.UserIdCreateDate)
                    ? (DateTime?)null
                    : Convert.ToDateTime(request.UserIdCreateDate);
                var passwordChangeDate = string.IsNullOrEmpty(request.PasswordChangeDate)
                    ? (DateTime?)null
                    : Convert.ToDateTime(request.PasswordChangeDate);

                var canUpdateUser = true;
                if (!_baasConfiguration.NoNeedCheckNUM(request.ProgramCode, accountInfo.Product.ProductCode.ToString()))
                {
                    canUpdateUser = UpdateUserRiskCheck(request, newAddresses, newPhoneNumbers, newEmail);
                }
                if (!canUpdateUser)
                {
                    return new UpdateUserProfileResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 5,
                            SubStatusCode = 110,
                            Message = "Negative Decline"
                        },
                    };
                }

                if (newEmail != null)
                {
                    _accountService.EmailLimitVerification(request.ProgramCode, newEmail?.EmailAddress, 5, accountInfo.AccountKey);
                }

                _userService.UpdateUser(AccountIdentifier.FromString(request.AccountIdentifier),
                    UserIdentifier.FromString(request.UserIdentifier),
                    newAddresses,
                    newPhoneNumbers,
                    newEmail,
                    request.PeerTransferAcceptPreference,
                    request.ProgramCode,
                    request.RequestHeader.RequestId,
                    /*https://pd/browse/GBOS-6925 - Scenario 1 request.OverrideAddressStandardization*/ true,
                    false,
                    request?.ProfileData?.DateOfBirth,
                    request?.ProfileData?.IsDobVerified,
                    userIdCreateDate,
                    passwordChangeDate,
                    newConsumerProfileExtensions);

                
                await _tokenManagementService.PublishUserProfileUpdatedMessageAsync(request.RequestHeader.RequestId,
                    request.ProgramCode,
                    new UserProfileUpdatedMessage()
                    {
                        PhoneNumber =
                            request.PhoneNumbers is { Count: > 0 }
                                ? request.PhoneNumbers[0].Number
                                : null,
                        Email = request.Email?.EmailAddress,
                        AccountIdentifier = request.AccountIdentifier,
                        ProgramCode = request.ProgramCode
                    });

                if (phone != null || newEmail != null)
                {
                    var cnapirequest = new CNApiContactUpdateRequest
                    {
                        Header = new CNAPIRequestHeader()
                        {
                            RequestId = request.RequestHeader?.RequestId.ToString(),
                            RequestOptions = request.RequestHeader?.Options
                        },
                        AccountIdentifer = request.AccountIdentifier,
                        ProgramCode = request.ProgramCode,
                        ProductCode = accountInfo.Product.ProductCode.ToString(),
                        Contacts = new List<Contact>()
                    };
                    if (phone != null)
                    {
                        cnapirequest.Contacts.Add(new Contact
                        {
                            ChannelType = 1,
                            ContactValue = phone.Number
                        });
                    }
                    if (newEmail != null)
                    {
                        cnapirequest.Contacts.Add(new Contact
                        {
                            ChannelType = 2,
                            ContactValue = newEmail.EmailAddress
                        });
                    }
                    var cnapiResponse = _cNAPIService.UpdateContact(cnapirequest);
                    if (cnapiResponse.Header.StatusCode != "200")
                    {
                        return new UpdateUserProfileResponse
                        {
                            ResponseHeader = new ResponseHeader
                            {
                                ResponseId = request.RequestHeader.RequestId,
                                StatusCode = 503,
                                Message = "Failed to call NotifyAPI.UpdateCustomerContract."
                            },
                        };
                    }
                }

                var phoneUpdatedByCrm = request.Source == Source.Crm && newPhoneNumbers.Any();
                var emailUpdatedByCrm =
                    request.Source == Source.Crm && !string.IsNullOrEmpty(request.Email?.EmailAddress);
                var dateOfBirthByCrm =
                    request.Source == Source.Crm && !string.IsNullOrEmpty(request?.ProfileData?.DateOfBirth);

                if (!_baasConfiguration.DoesProgramRequireCrmToPushPn(request.ProgramCode) || phoneUpdatedByCrm || emailUpdatedByCrm || dateOfBirthByCrm)
                {
                    PublishUserUpdateNotification(request.ProfileData?.Addresses, request.PhoneNumbers, request.Email, request.AccountIdentifier, request.UserIdentifier, request.ProgramCode, request?.ProfileData?.DateOfBirth);
                }

            }
            catch (Exception e)
            {
                return e.HandleException<UpdateUserProfileResponse>(e, request);
            }

            var response = new UpdateUserProfileResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                },
            };

            return response;
        }

        private void NotAllowChildAccountUpdateParentProfile(bool isPrimaryAccountHolder, string accountIdentifier)
        {
            var linkedAccounts = _accountRepository.GetLinkedAccounts(accountIdentifier);
            var isUpdatedByChildAccount = linkedAccounts.Exists(
                x => x.AccountLinkType == AccountLinkType.Custodian &&
                     string.Equals(accountIdentifier.Trim(), x.LinkAccountIdentifier, StringComparison.OrdinalIgnoreCase));
            if (isUpdatedByChildAccount && isPrimaryAccountHolder)
            {
                throw new RequestHandlerException(5, 1903, "The child account is not allowed to update parent's profile.");
            }
        }

        private bool IsPhoneLimitCheckRequired(string programCode, int? consumerProfileTypeKey)
        {
            // GBOS-88326 - Credibly needs to skip phone limit check for individual profile type
            if (!string.Equals(programCode, "credibly", StringComparison.InvariantCultureIgnoreCase))
                return true;

            if (consumerProfileTypeKey.HasValue
                && consumerProfileTypeKey.Value != (int)ConsumerProfileType.Individual)
                return true;

            return false;
        }

        protected void VerifyDataShareEligibility(UpdateUserProfileRequest request, List<Address> newAddress, Core.Domain.Model.User.UserProfile userInfo)
        {
            // Need to force Opt out if user is changing address from outside of CA to CA
            if (newAddress.FirstOrDefault(x => x.AddressTypeKey == (short)AddressType.Home)?.State == "CA"
                && userInfo?.Addresses?.FirstOrDefault(x => x.AddressTypeKey == (short)AddressType.Home)?.State != "CA")
            {
                if (request.TermsAcceptances == null)
                {
                    request.TermsAcceptances = new List<TermsAcceptance>();
                }

                request.TermsAcceptances?.Add(new TermsAcceptance()
                {
                    TermsIdentifier = "dataShare",
                    TermsAcceptanceFlag = false
                });
            }
        }

        private bool UpdateUserRiskCheck(UpdateUserProfileRequest request, IEnumerable<Address> addresses, IEnumerable<PhoneNumber> phoneNumbers, Email email)
        {
            var userData = new Dictionary<string, object>();

            var address = addresses.FirstOrDefault();
            if (address != null)
            {
                userData.Add("Address", address);
            }

            var phone = phoneNumbers.FirstOrDefault();
            if (phone != null)
            {
                userData.Add("Phone", phone.Number);
            }

            if (email != null)
            {
                userData.Add("Email", email.EmailAddress);
            }

            if (userData.Count == 0)
            {
                // We are returning true here because user is not updating any of these three. User can update other information like Date of birth etc
                return true;
            }

            var verifyUserDataRequest = new VerifyUpdateProfileRequest
            {
                RequestHeader = request.RequestHeader,
                ProgramCode = request.ProgramCode,
                AccountIdentifier = request.AccountIdentifier,
                UserData = userData
            };

            var verifyUserDataResponse = _riskService.VerifyUpdateProfile(verifyUserDataRequest);
            return verifyUserDataResponse.IsValidData;
        }

        private void CheckContactVerificationStatus(IEnumerable<PhoneNumber> phoneNumbers, Email newEmail, UpdateUserProfileRequest request)
        {

            if (request?.ContactVerificationIdentifiers == null
                || request.ContactVerificationIdentifiers.Count == 0)
            {
                if (request?.PhoneNumbers == null) return;

                foreach (var number in request.PhoneNumbers)
                {
                    var phone = phoneNumbers.FirstOrDefault(p => p.Number == number.Number);
                    phone.IsVerified = number.IsVerified;
                }
                return;
            }

            var getContactVerificationStatusRequest = new GetContactVerificationStatusRequest
            {
                RequestHeader = new RequestHeader
                {
                    RequestId = (request?.RequestHeader?.RequestId) ?? Guid.NewGuid()
                }
            };

            foreach (var verifyIdentifier in request.ContactVerificationIdentifiers)
            {
                getContactVerificationStatusRequest.ContactVerificationIdentifier = verifyIdentifier.ToString();
                var getContactVerificationStatusResponse = _contactService.GetContactVerificationStatus(getContactVerificationStatusRequest);

                if (string.IsNullOrEmpty(getContactVerificationStatusResponse.Status))
                {
                    throw new ValidationException(5, 336, "Contact handle was not approved");
                }

                if (getContactVerificationStatusResponse.Status.Equals("expired",
                        StringComparison.InvariantCultureIgnoreCase))
                {
                    throw new ValidationException(5, 340, "Verification Code Expired");
                }

                if (!getContactVerificationStatusResponse.Status.Equals("success",
                    StringComparison.InvariantCultureIgnoreCase))
                {
                    throw new ValidationException(5, 336, "Contact handle was not approved");
                }

                if (getContactVerificationStatusResponse.ContactType == ContactType.Phone)
                {
                    VerifyPhone(getContactVerificationStatusResponse.Contact, phoneNumbers, request);
                }
                else if (getContactVerificationStatusResponse.ContactType == ContactType.Email)
                {
                    VerifyEmail(getContactVerificationStatusResponse.Contact, newEmail, request);
                }
            }
        }


        private static void VerifyPhone(string contact, IEnumerable<PhoneNumber> phoneNumbers, UpdateUserProfileRequest request)
        {
            var phoneNumber = phoneNumbers?.FirstOrDefault(p =>
                p.Number.Equals(contact, StringComparison.InvariantCultureIgnoreCase));

            if (phoneNumber == null)
            {
                throw new ValidationException(5, 345, "Phone number not matched");
            }

            //already verified
            if (phoneNumber.IsVerified)
            {
                throw new ValidationException(5, 346, "Conflicting Contact Verification Identifiers");
            }
            phoneNumber.IsVerified = true;

            var originalPhone = request.PhoneNumbers.FirstOrDefault(p => p.Number == phoneNumber.Number);
            if (originalPhone != null)
            {
                originalPhone.IsVerified = true;
            }
        }

        private static void VerifyEmail(string contact, Email newEmail, UpdateUserProfileRequest request)
        {
            if (string.IsNullOrEmpty(newEmail?.EmailAddress)
                || !contact.Equals(newEmail?.EmailAddress, StringComparison.InvariantCultureIgnoreCase))
            {
                throw new ValidationException(5, 345, "Email address not matched");
            }

            //already verified
            if (request.Email.IsVerified)
            {
                throw new ValidationException(5, 346, "Conflicting Contact Verification Identifiers");
            }

            newEmail.IsVerified = true;
            request.Email.IsVerified = true;
        }

        private static void VerifyBirthday(string birthday)
        {
            if (!string.IsNullOrEmpty(birthday))
            {
                if (DateTime.TryParseExact(birthday, "yyyy-mm-dd", null, DateTimeStyles.None, out DateTime date) == false)
                {
                    throw new ValidationException(700, 0, "dateOfBirth must be in the form of YYYY-MM-DD.");
                }
            }
        }

        private void VerifyEligibility(UpdateUserProfileRequest request,
            string productCode,
            IEnumerable<PhoneNumber> phoneNumbers,
            int productTierKey)
        {
            // GBOS-54809 Only GBR or FLEX must go through additional verification unless source is CRM
            if (!_contactChangeEligibilityService.ProgramCodeEligibleForContactChangeRestrictions(request.ProgramCode)
                || (request.Source.HasValue && request.Source.Value == Source.Crm))
                return;

            if (!_contactChangeEligibilityService.MailedCardActivated(request.AccountIdentifier, productCode, true, productTierKey))
            {
                if (_baasConfiguration.AllowPhoneUpdateBeforeCardActivation(request.ProgramCode) &&
                    string.IsNullOrEmpty(request.Email?.EmailAddress) &&
                    request.ProfileData == null &&
                    request.ConsumerProfileExtensionAttributes == null &&
                    request.PasswordChangeDate == null &&
                    phoneNumbers.All(it => it.IsVerified))
                {
                    //* This is only for PLS edge case, allow update phone number before first card activation/*
                    //* for more information about this change, please refer to GBOS-92504 */
                    return;
                }

                throw new ValidationException(520, 630, "Mailed card must be activated");
            }
        }

        private static List<Address> ConvertToDomainAddresses(IEnumerable<Shared.Common.Core.CoreApi.Contract.Data.Address> addresses)
        {
            return addresses.Select(address => new Address
            {
                Country = "USA",
                State = address.State,
                AddressLine1 = address.AddressLine1,
                AddressLine2 = address.AddressLine2,
                City = address.City,
                Type = address.Type,
                ZipCode = address.ZipCode,
                IsDefault = address.IsDefault,
                IsVerified = false
            })
                .ToList();
        }

        private static List<PhoneNumber> ConvertToDomainPhoneNumbers(IEnumerable<Shared.Common.Core.CoreApi.Contract.Data.PhoneNumber> phoneNumbers)
        {
            return phoneNumbers.Select(number => new PhoneNumber
            {
                Number = number.Number,
                Type = number.Type,
                IsDefault = number.IsDefault,
                IsVerified = false
            }).ToList();
        }

        private void PublishUserUpdateNotification(List<Shared.Common.Core.CoreApi.Contract.Data.Address> addresses,
            List<Shared.Common.Core.CoreApi.Contract.Data.PhoneNumber> numbers,
            Shared.Common.Core.CoreApi.Contract.Data.Email email, string accountIdentifier, string userIdentifier, string programCode, string dateOfBirth)
        {
            var profile = new Shared.Common.Core.CoreApi.Contract.Data.UserProfile
            {
                AccountIdentifier = accountIdentifier,
                UserIdentifier = userIdentifier
            };

            if (addresses != null && addresses.Count != 0)
            {
                addresses.ForEach(a =>
                {
                    a.IsReturned = false;
                    a.IsVerified = false;
                    a.LastUpdatedDateTime = DateTime.Parse(DateTime.UtcNow.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'")).ToUniversalTime();
                    a.CountryCode = "USA";
                });

                var profileData = new ProfileData
                {
                    Addresses = addresses,
                    LastUpdatedDateTime = null
                };

                profile.ProfileData = profileData;
            }

            if (numbers?.Count != 0)
            {
                numbers?.ForEach(n =>
                {
                    n.LastUpdatedDateTime = DateTime.Parse(DateTime.UtcNow.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'")).ToUniversalTime();
                });
                profile.PhoneNumbers = numbers;
            }

            if (email != null)
            {
                email.LastUpdatedDateTime = DateTime.Parse(DateTime.UtcNow.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'")).ToUniversalTime();
                profile.Email = email;
            }

            if (!string.IsNullOrEmpty(dateOfBirth))
            {
                if (profile.ProfileData == null) profile.ProfileData = new ProfileData();
                profile.ProfileData.DateOfBirth = dateOfBirth;
            }

            _notificationPublisher.PublishNotification(programCode, profile, EventType.UserUpdate);
        }
    }
}
