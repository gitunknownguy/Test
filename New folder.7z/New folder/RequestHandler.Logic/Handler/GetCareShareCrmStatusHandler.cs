﻿using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Utils;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Logic;
using Gd.Bos.Shared.Common.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RequestHandler.Logic.Handler
{
    public class GetCareShareCrmStatusHandler : CommandHandlerBase<CareShareCrmRequest, CareShareCrmResponse>
    {
        private readonly ILockService _lockService;
        private readonly IAccountService _accountService;
        private readonly IValidateIdentifier _validateIdentifier;


        public GetCareShareCrmStatusHandler(ILockService lockService, IAccountService accountService,
            IValidateIdentifier validateIdentifier)
        {
            _lockService = lockService;
            _accountService = accountService;
            _validateIdentifier = validateIdentifier;
        }

        public override Task<CareShareCrmResponse> Handle(CareShareCrmRequest request)
        {
            try
            {
                string msg = "Success";
                CareShareCrmResponse response = new CareShareCrmResponse();
                response.MappingList = new List<CareShareCrmOutput>();

                if (request.MappingList == null || !request.MappingList.Any())
                {
                    throw new RequestHandlerException(0, 0, $"Input Request MappingList is null/empty, {request.RequestHeader.RequestId}.");
                }

                Dictionary<Guid, string> accountIdentifiersHT = new Dictionary<Guid, string>();

                foreach (var req in request.MappingList)
                {
                    if (!CheckForValidGuid(req))
                    {
                        response.MappingList.Add(new CareShareCrmOutput
                        {
                            AccountIdentifier = Guid.Empty,
                            ProgramCode = !string.IsNullOrEmpty(req.ProgramCode) ? req.ProgramCode : null,
                        });
                        continue;
                    }

                    if (string.IsNullOrEmpty(req.ProgramCode))
                    {
                        response.MappingList.Add(new CareShareCrmOutput
                        {
                            AccountIdentifier = Guid.Parse(req.AccountIdentifier),
                            ProgramCode = null,
                        });
                        continue;
                    }

                    accountIdentifiersHT.Add(Guid.Parse(req.AccountIdentifier), req.ProgramCode);
                }

                if (!accountIdentifiersHT.Any())
                {
                    response.ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        Message = "No valid Guids/Progamcode found in the input list"
                    };

                    return Task.FromResult(response);
                }

                var ids = accountIdentifiersHT.Select(id => id.Key).ToList();

                var accountCardStatuses = _accountService.GetAccountCardStatuses(ids);

                if (accountCardStatuses != null && !accountCardStatuses.Any())
                {
                    foreach (var ac in accountIdentifiersHT)
                    {
                        response.MappingList.Add(new CareShareCrmOutput
                        {
                            AccountIdentifier = ac.Key,
                            ProgramCode = ac.Value,
                        });
                    }

                    response.ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        Message = "No mapping accounts found in the system for the input list"
                    };

                    return Task.FromResult(response);
                }

                var acGrps = accountCardStatuses.GroupBy(ac => ac.AccountIdentifier);


                foreach (var acGrp in acGrps)
                {
                    accountIdentifiersHT.Remove(Guid.Parse(acGrp.Key));
                    // PaymentIdentifierStatus or PaymentInstrumentStatus as CardStatus????
                    //filter by latest PaymentInstrument_CreateDate
                    var crdStatusItem = acGrp.Select(cs => cs).OrderByDescending(d => d.PaymentInstrumentCreateDate).First();


                    //= crdStatusItem.PaymentIdentifierStatusKey;
                    PaymentIdentifierStatus pIdentStatus = (PaymentIdentifierStatus)crdStatusItem.PaymentIdentifierStatusKey;
                    PaymentInstrumentStatus pInstrStatus = (PaymentInstrumentStatus)crdStatusItem.PaymentInstrumentStatusKey;

                    var crdStatus = StatusMapper.GetPaymentInstrumentStatus(pIdentStatus, pInstrStatus);

                    response.MappingList.Add(new CareShareCrmOutput
                    {
                        AccountIdentifier = Guid.Parse(acGrp.Key),
                        ProgramCode = acGrp.First().ProgramCode != null ? acGrp.First().ProgramCode : null,
                        AccountStatus = acGrp.First().AccountStatusKey > 0 ? acGrp.First().AccountStatusKey.ToString() : null,
                        AccountStatusReason = acGrp.First().AccountStatusReasonKey > 0 ? acGrp.First().AccountStatusReasonKey.ToEnumMemberAttrValue() : null,
                        CardStatus = crdStatus > 0 ? crdStatus.ToString() : null,
                    });
                }

                if (accountIdentifiersHT.Any())
                {
                    foreach (var account in accountIdentifiersHT)
                    {
                        response.MappingList.Add(new CareShareCrmOutput
                        {
                            AccountIdentifier = account.Key,
                            ProgramCode = account.Value,
                        });
                    }

                    msg = "Partial success";
                }

                response.ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    Message = msg
                };

                return Task.FromResult(response);
            }
            catch (Exception ex)
            {
                return Task.FromResult(ex.HandleException<CareShareCrmResponse>(ex, request));
            }
        }

        private bool CheckForValidGuid(CareShareCrmInput req)
        {


            if (string.IsNullOrEmpty(req.AccountIdentifier) || !Guid.TryParse(req.AccountIdentifier, out Guid guid))
            {
                return false;
            }

            return true;
        }

        public override void SetDomainContext(CareShareCrmRequest request)
        {

        }

        public override Task<CareShareCrmResponse> VerifyIdentifiers(CareShareCrmRequest request)
        {

            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.ProgramCode);

                return Task.FromResult(
                           new CareShareCrmResponse { ResponseHeader = new ResponseHeader() }
                           );
            }
            catch (Exception ex)
            {
                return Task.FromResult(ex.HandleException<CareShareCrmResponse>(ex, request));
            }
        }

        public override async Task<CareShareCrmResponse> ObtainLock(CareShareCrmRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock("Account_" + request.RequestHeader.RequestId + request.ProgramCode);
                return new CareShareCrmResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<CareShareCrmResponse>(e, request);
            }
        }

        public override void ReleaseLock(CareShareCrmRequest request)
        {
            _lockService.ReleaseApiLock("Account_" + request.RequestHeader.RequestId + request.ProgramCode);
        }
    }
}
