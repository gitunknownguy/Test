﻿using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using RequestHandler.Core.Application;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Response;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using System.ComponentModel;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using RequestHandler.Core.Application.Exception;
using RequestHandler.Core.Domain.Enums;
using AccountHolderCure = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolderCure;
using VerificationActivityType = Gd.Bos.RequestHandler.Core.Domain.Model.Account.VerificationActivityType;
using VerificationStatus = Gd.Bos.RequestHandler.Core.Domain.Model.Account.VerificationStatus;
using Gd.Bos.RequestHandler.Core.Domain.Model;

namespace RequestHandler.Logic.Handler
{
    public class IdvPresignupBySocureHandler : CommandHandlerBase<IdvPresignupRequestSocure, IdvPresignupResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ILockService _lockService;
        private readonly ITempCardEnrollmentService _tempCardEnrollmentService;
        private readonly IRiskService _riskService;
        private readonly ITokenizerService _tokenizerService;
        private readonly IVerificationRepository _verificationRepository;

        public IdvPresignupBySocureHandler(IValidateIdentifier validateIdentifier,
            ILockService lockService,
            ITempCardEnrollmentService tempCardEnrollmentService,
            IRiskService riskService,
            ITokenizerService tokenizerService,
            IVerificationRepository verificationRepository)
        {
            _validateIdentifier = validateIdentifier;
            _lockService = lockService;
            _tempCardEnrollmentService = tempCardEnrollmentService;
            _riskService = riskService;
            _tokenizerService = tokenizerService;
            _verificationRepository = verificationRepository;
            
        }

        public override Task<IdvPresignupResponse> Handle(IdvPresignupRequestSocure request)
        {
            #region Validations
            if (string.IsNullOrWhiteSpace(request.DocVTransactionToken))
            {
                return Task.FromResult(new IdvPresignupResponse()
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 400,
                        SubStatusCode = 340,
                        Message = "DocVTransactionToken is required"
                    }
                });
            }

            if (!Guid.TryParse(request.RegistrationToken, out var registrationToken))
            {
                return Task.FromResult(new IdvPresignupResponse()
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 400,
                        SubStatusCode = 341,
                        Message = "Invalid RegistrationToken format"
                    }
                });
            }
            var verificationRequest = _tempCardEnrollmentService.GetVerificationRequestByIdentifier(registrationToken);
            
            if (verificationRequest.VerificationRequestKey == 0)
            {
                return Task.FromResult(new IdvPresignupResponse()
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 400,
                        SubStatusCode = 340,
                        Message = "Verification request not found"
                    }
                });
            }

            AccountHolderCure verificationRequestStatus = (AccountHolderCure)verificationRequest.StatusKey;

            if (verificationRequestStatus != AccountHolderCure.IDV)
            {
                return Task.FromResult(new IdvPresignupResponse()
                {
                    KycGate = new KycGate
                    {
                        KycStateData = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData
                        {
                            PendingKycGate = verificationRequestStatus.ToString()
                        }
                    },
                    ResponseHeader = new ResponseHeader()
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 400,
                        SubStatusCode = 343,
                        Message = "KYC Gate does not match kycPendingGate.",
                        Details = $"KYC Gate: {verificationRequestStatus}"
                    }
                });
            }

            #endregion


            #region Get_Request_Data_From_Cassandra
            PreSignupEnrollmentRequest requestTempCard = new PreSignupEnrollmentRequest()
            {
                Card = new Card()
                {
                    RegistrationToken = registrationToken.ToString()
                }
            };

            //Get PII data stored in Cassandra
            var enrollmentData = _tempCardEnrollmentService.MapRequestFromCassandra(requestTempCard);
            if (enrollmentData == null)
            {
                throw new Exception("Unable to get PII from Cassandra");
            }
            //Map PII Data to Verify Request
            var verifyRequest = _tempCardEnrollmentService.MapPIIDataToVerifyRequest(enrollmentData);
            if (verifyRequest == null)
            {
                throw new Exception("An error has occurred while mapping PII data");
            }
            #endregion
            verifyRequest.TriggerType = (TriggerType)verificationRequest.TriggerTypeKey;
            verifyRequest.CustomData = new Dictionary<string, object>();
            if (request.FraudData != null && request.FraudData.Keys.Count > 0)
            {
                foreach (var fraudData in request.FraudData)
                {
                    verifyRequest.CustomData.Add(fraudData.Key, fraudData.Value);
                }
            }
            verifyRequest.Document = new CreateDocumentInfo()
            {
               DocVTransactionToken=request.DocVTransactionToken,
            };
            verifyRequest.CustomData.Add("ProductCode", enrollmentData.AccountCreationData.ProductCode);
           CreateRiskResponse response;
            try
            {
                response = _riskService.IdvUploadRequest(verifyRequest);
            }
            catch (IdvUploadException e)
            {
                return Task.FromResult(new IdvPresignupResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = e.Status,
                        SubStatusCode = e.SubStatus,
                        Message = e.ErrorDescription,
                        Details = e.Message
                    }
                });
            }

            if (response == null)
            {
                throw new Exception("An error has occurred while calling Risk Service");
            }
            
            if (response.UserDetail.KycGate != AccountHolderCure.Healthy.ToString().ToLower())
            {
                var idvResponse = SetIdvResponse(request.RequestHeader.RequestId, response);

                try
                {
                    verificationRequestStatus = (AccountHolderCure)Enum.Parse(typeof(AccountHolderCure), response.UserDetail.KycGate, true);
                    _verificationRepository.UpdateVerificationRequestStatusPreEnroll(verificationRequest.VerificationRequestKey, verificationRequestStatus);
                }
                catch (Exception)
                {
                    throw new Exception("An error has occurred while updating status");
                }

                return Task.FromResult(idvResponse ?? new IdvPresignupResponse()
                {
                    KycGate = new KycGate
                    {
                        KycStateData = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData
                        {
                            KycStatus = String.Join(", ", response.UserDetail.StatusReasonCode),
                            PendingKycGate = response.UserDetail.KycGate
                        }
                    },
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 200,
                        SubStatusCode = 4000,
                        Message = $"KycGate: {response.UserDetail.KycGate}",
                        Details = $"Status reason: {String.Join(", ", response.UserDetail.StatusReasonCode)}"
                    }
                });
            }

            try
            {
                _verificationRepository.UpdateVerificationRequestStatusPreEnroll(verificationRequest.VerificationRequestKey, AccountHolderCure.Healthy);
                var verificationActivities =
                   new Dictionary<VerificationActivityType, VerificationStatus>
                   {
                    { VerificationActivityType.IDV, VerificationStatus.Passed }
                   };
                _verificationRepository.CreateVerificationActivity(verificationRequest.VerificationRequestKey, verificationActivities);
            }
            catch (Exception)
            {
                throw new Exception("An error has occurred while updating status");
            }

            return Task.FromResult(new IdvPresignupResponse()
            {
                KycGate = new KycGate
                {
                    KycStateData = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData
                    {
                        KycStatus = String.Join(", ", response.UserDetail.StatusReasonCode),
                        PendingKycGate = response.UserDetail.KycGate
                    }
                },
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 200,
                    SubStatusCode = 0,
                    Message = response.UserDetail.StatusReasonCode.Contains("IDV-A", StringComparer.OrdinalIgnoreCase) ? "IDV Approved." : $"KycGate: {response.UserDetail.KycGate}",
                    Details = $"Status reason: {String.Join(", ", response.UserDetail.StatusReasonCode)}"
                }
            });
        }

        private IdvPresignupResponse SetIdvResponse(Guid requestId, CreateRiskResponse response)
        {
            if (response.UserDetail?.KycGate?.ToLower() == "idv")
            {
                if (response.UserDetail.StatusReasonCode.Contains("IDV-INV", StringComparer.OrdinalIgnoreCase))
                {
                    return new IdvPresignupResponse
                    {
                        ResponseHeader = SetResponseHeader(requestId, 2, 21, "IDV Scan Upload Failure."),
                        KycGate = SetKycGate(response)
                    };
                }
                else if (response.UserDetail.StatusReasonCode.Contains("IDV-NR", StringComparer.OrdinalIgnoreCase))
                {
                    return new IdvPresignupResponse
                    {
                        ResponseHeader = SetResponseHeader(requestId, 2, 22, "IDV Not Readable."),
                        KycGate = SetKycGate(response)
                    };
                }
                else
                {
                    return new IdvPresignupResponse
                    {
                        ResponseHeader = SetResponseHeader(requestId, 2, 20, "IDV Scan Upload Failure."),
                        KycGate = SetKycGate(response)
                    };
                }
            }
            else 
            {
                if (response.UserDetail != null && response.UserDetail.StatusReasonCode.Contains("MAX-R", StringComparer.OrdinalIgnoreCase))
                {
                    return new IdvPresignupResponse
                    {
                        ResponseHeader = SetResponseHeader(requestId, 2, 31, "IDV scan Max Attempt Reached."),
                        KycGate = SetKycGate(response)
                    };
                }
                else if (response.UserDetail != null && response.UserDetail.StatusReasonCode.Contains("IDV-F", StringComparer.OrdinalIgnoreCase))
                {
                    return new IdvPresignupResponse
                    {
                        ResponseHeader = SetResponseHeader(requestId, 2, 32, "IDV Scan Upload Success - Verification Failed."),
                        KycGate = SetKycGate(response)
                    };
                }
                else
                {
                    return new IdvPresignupResponse
                    {
                        ResponseHeader = SetResponseHeader(requestId, 2, 30, "IDV Scan Upload Success - Verification Failed."),
                        KycGate = SetKycGate(response)
                    };
                }
            }
        }

        private ResponseHeader SetResponseHeader(Guid requestId, int statusCode, int subStatusCode, string message)
        {
            return new ResponseHeader
            {
                ResponseId = requestId, 
                StatusCode = statusCode, 
                SubStatusCode = subStatusCode, 
                Message = message
            };
        }

        private KycGate SetKycGate(CreateRiskResponse response)
        {
            return new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.KycGate()
            {
                KycStateData = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData()
                {
                    KycStatus = VerificationStatus.Failed.ToString(),
                    OfacStatus =
                        !response.UserDetail.StatusReasonCode.Contains("OFAC-PM", StringComparer.OrdinalIgnoreCase)
                            ? VerificationStatus.Passed.ToString()
                            : VerificationStatus.Failed.ToString(),
                    PendingKycGate = response.UserDetail?.KycGate?.ToLower()
                }
            };
        }

        public override void SetDomainContext(IdvPresignupRequestSocure request)
        {
        }
        public override Task<IdvPresignupResponse> VerifyIdentifiers(IdvPresignupRequestSocure request)
        {
            return Task.FromResult(new IdvPresignupResponse() { ResponseHeader = new ResponseHeader() });
        }

    }
}
