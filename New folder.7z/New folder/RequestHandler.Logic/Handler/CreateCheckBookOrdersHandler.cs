﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using Gd.Bos.Shared.Common.Locking.ApiLock;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using RabbitMQ.Client.Impl;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using RequestHandler.Core.Domain.Services.PaperCheck;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.FraudApi.Model.FraudRuleUI;
using Gd.Bos.Shared.Common.Logic.FeatureLimitsFees.Repository;
using StackExchange.Redis;
using RequestHandler.Core.Domain.Model.Interest;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class CreateCheckBookOrdersHandler : CommandHandlerBase<CreateCheckBookOrdersRequest, CreateCheckBookOrdersResponse>
    {
        private readonly IPaperCheckService _paperCheckService;
        private readonly ILockService _lockService;
        private readonly IAccountRepository _accountRepository;
        private readonly IProductRepository _productRepository;

        public CreateCheckBookOrdersHandler(IPaperCheckService paperCheckService, ILockService lockService, IAccountRepository accountRepository, IProductRepository productRepository)
        {
            _paperCheckService = paperCheckService;
            _lockService = lockService;
            _accountRepository = accountRepository;
            _productRepository = productRepository;
        }

        
        public override void SetDomainContext(CreateCheckBookOrdersRequest request)
        {
            
        }

        
        public override Task<CreateCheckBookOrdersResponse> VerifyIdentifiers(CreateCheckBookOrdersRequest request)
        {
            try
            {
                return Task.FromResult(new CreateCheckBookOrdersResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CreateCheckBookOrdersResponse>(e, request));
            }
        }

        
        public override async Task<CreateCheckBookOrdersResponse> ObtainLock(CreateCheckBookOrdersRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock(OptionsContext.Current.GetString("requestId"));

                return new CreateCheckBookOrdersResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<CreateCheckBookOrdersResponse>(e, request);
            }
        }

        
        public override void ReleaseLock(CreateCheckBookOrdersRequest request)
        {
            _lockService.ReleaseApiLock(OptionsContext.Current.GetString("requestId"));
        }


        public override Task<CreateCheckBookOrdersResponse> Handle(CreateCheckBookOrdersRequest request)
        {
            try
            {
                var result = new CreateCheckBookOrdersResponse();
                var checkBookOrdersDoRequest = new CreateCheckBookOrderDoRequest()
                {
                    Order = request.Order,
                    ProgramCode = request.ProgramCode,
                    CheckBookOrders = new List<CheckBookOrderData> ()
                };

                foreach (CheckBookOrderInfo item in request.CheckBookOrders)
                {
                    var orderData = new CheckBookOrderData(item);

                    var account = _accountRepository.GetAccountByAccountNumber(orderData.AccountNumber);

                    if(account != null) 
                    {
                        if (string.IsNullOrEmpty(orderData.AccountIdentifier) || orderData.AccountIdentifier.ToLower() == account.AccountIdentifier.ToString().ToLower())
                        {
                            orderData.AccountIdentifier = account.AccountIdentifier.ToString().ToUpper();
                        }
                        else
                        {
                            orderData.Invalid = true;
                            orderData.InvalidReason = "invalid account";
                            orderData.AccountIdentifier = Guid.Empty.ToString();
                            checkBookOrdersDoRequest.CheckBookOrders.Add(orderData);
                            continue;
                        }
                    }
                    else
                    {
                        orderData.Invalid = true;
                        orderData.InvalidReason = "account not found";
                        orderData.AccountIdentifier = Guid.Empty.ToString();
                        checkBookOrdersDoRequest.CheckBookOrders.Add(orderData);
                        continue;
                    }
                    var product = _productRepository.GetProductByKey(account.Product.ProductKey);
                    if (!orderData.RoutingNumber.Equals(product.RoutingNumber)
                        || product.ProgramCode.ToString().ToLower() != request.ProgramCode.ToLower())
                    {
                        orderData.Invalid = true;
                        orderData.InvalidReason = "invalid routingNumber";
                        checkBookOrdersDoRequest.CheckBookOrders.Add(orderData);
                        continue;
                    }
                    if (orderData.CheckBookOrderType == 0)
                    {
                        orderData.CheckBookOrderType = (int)CheckBookOrderType.personal;
                    }
                    orderData.AccountIdentifier = account.AccountIdentifier.ToString();
                    orderData.OrderReferenceId = Guid.NewGuid();
                    if (request.Order)
                    {
                        orderData.CheckBookOrderDate = DateTime.Now;
                    }
                    checkBookOrdersDoRequest.CheckBookOrders.Add(orderData);
                }
                if(checkBookOrdersDoRequest.CheckBookOrders.Count == 0)
                {
                    result.ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 400,
                        SubStatusCode = 0,
                        Message = $"Invalid arguments. "
                    };
                    return Task.FromResult(result);
                }
                var response = _paperCheckService.CreateCheckBookOrders(checkBookOrdersDoRequest);

                // send webhook, IntuitQB don't need to send, please add your logic when your partner required.

                if (response.ErrorCode == "0")
                {
                    result.ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    };
                    result.Success = response.Success;
                    result.ExpectFailed = response.ExpectFailed;
                    result.UnExpectFailed = response.UnExpectFailed;
                }
                else
                {
                    result.ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 400,
                        SubStatusCode = 0,
                        Message = $"Invalid arguments. ErrorCode:{response.ErrorCode}, ErrorMessage:{response.ErrorMessage}"
                    };
                }

                return Task.FromResult(result);
            }
            catch (Exception ex)
            {
                return Task.FromResult(ex.HandleException<CreateCheckBookOrdersResponse>(ex, request));
            }
        }
    }
}
