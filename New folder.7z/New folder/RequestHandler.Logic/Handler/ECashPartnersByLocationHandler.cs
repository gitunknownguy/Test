﻿using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.ECash;
using ECashPartner = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.ECashPartner;
using GetECashPartnersByLocationRequest = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.GetECashPartnersByLocationRequest;
using GetECashPartnersByLocationResponse = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.GetECashPartnersByLocationResponse;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class ECashPartnersByLocationHandler : ECashHandlerBase<GetECashPartnersByLocationRequest, GetECashPartnersByLocationResponse>
    {
        public ECashPartnersByLocationHandler(IECashService eCashService) : base(eCashService)
        {

        }

        public override void SetDomainContext(GetECashPartnersByLocationRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetECashPartnersByLocationResponse> VerifyIdentifiers(GetECashPartnersByLocationRequest request)
        {
            return Task.FromResult(new GetECashPartnersByLocationResponse { ResponseHeader = new ResponseHeader() });
        }

        public override Task<GetECashPartnersByLocationResponse> Handle(GetECashPartnersByLocationRequest request)
        {
            return Task.FromResult(GetECashPartnersByLocation(request));
        }

        /// <summary>
        /// Get eCash Partners by location
        /// </summary>
        /// <param name="request">The request</param>
        /// <returns></returns>
        private GetECashPartnersByLocationResponse GetECashPartnersByLocation(GetECashPartnersByLocationRequest request)
        {
            var response = new GetECashPartnersByLocationResponse();
            var domainResponse = ECashService.GetECashPartnersByLocation(new Core.Domain.Services.ECash.GetECashPartnersByLocationRequest
            {
                AccountIdentifier = request.AccountIdentifier,
                ProgramCode = request.ProgramCode,
                Latitude = request.Latitude,
                Longitude = request.Longitude,
                Zip = request.Zip,
                City = request.City,
                State = request.State,
                Radius = request.Radius
            });

            response.ResponseHeader = MapResponse(domainResponse?.ResponseDetails?[0], request.RequestHeader.RequestId);

            if (domainResponse?.Partners != null)
            {
                response.Partners = domainResponse.Partners.Select(x => new ECashPartnerByLocation
                {
                    FaceFee = x.FaceFee,
                    PartnerId = x.PartnerId,
                    PartnerName = x.PartnerName,
                    RetailerCode = x.RetailerCode,
                    RetailerName = x.RetailerName,
                    RetailerDisplayPriority = x.RetailerDisplayPriority
                }).ToList();
            }

            return response;
        }

    }
}
