﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Model.User.PreInterventions;
using Gd.Bos.RequestHandler.Core.Domain.Services.Crypto;
using Gd.Bos.RequestHandler.Core.Domain.Services.InterestRate;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Core.Infrastructure.DataAccesses;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using NLog;
using RequestHandler.Core.Application;
using RequestHandler.Core.Domain.Enums;
using RequestHandler.Core.Domain.Services.CNAPI;
using RequestHandler.Core.Domain.Services.CNAPI.Messages.Request;
using RequestHandler.Core.Utils;
using Account = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Account;
using AccountHolder = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.AccountHolder;
using Address = Gd.Bos.RequestHandler.Core.Domain.Model.User.Address;
using CardExpirationDate = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.CardExpirationDate;
using KycStateData = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class EnrollHandler : CommandHandlerBase<EnrollRequest, EnrollResponse>
    {
        private readonly IRequestDataAccess _requestDataAccess;
        private readonly IEnrollmentDataAccess _enrollmentDataAccess;
        private readonly IEnrollmentService _enrollmentService;
        private readonly ICryptoService _cryptoService;
        private readonly IIdempotentService _idempotentService;
        private readonly IAccountService _accountService;
        private readonly ILazyCache _lazyCache;
        private readonly IAgreementDataAccess _agreementRepository;
        private readonly INotificationService _notificationPublisher;
        private readonly IWelcomeNotificationService _welcomeNotificationService;
        private readonly ILockService _lockService;
        private readonly IAddressIntervention _addressIntervention;
        private readonly IProductService _productService;
        private readonly IProgramRepository _programRepository;
        private readonly ITokenizerService _tokenizerService;
        private readonly IBaasConfiguration _baasConfiguration;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IGatewayService _gatewayService;
        private readonly ICNAPIService _cNAPIService;
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();
        private readonly IRequestHandlerSettings _configuration;
        private readonly IInterestRateService _interestRateService;

        public EnrollHandler(IRequestDataAccess requestDataAccess, IEnrollmentDataAccess enrollmentDataAccess,
            IEnrollmentService enrollmentService, ICryptoService cryptoService,
            IIdempotentService idempotentService,
            IAccountService accountService,
            ILazyCache lazyCache, IAgreementDataAccess agreementRepository,
            INotificationService notificationPublisher,
            IAddressIntervention addressIntervention,
            IWelcomeNotificationService welcomeNotificationService, ILockService lockService,
            IProductService productService, IProgramRepository programRepository, ITokenizerService tokenizerService,
            IBaasConfiguration baasConfiguration,
            IValidateIdentifier validateIdentifier,
            IGatewayService gatewayService,
            ICNAPIService cNAPIService,
            IRequestHandlerSettings requestHandlerSettings,
            IInterestRateService interestRateService
            )
        {
            _requestDataAccess = requestDataAccess;
            _enrollmentDataAccess = enrollmentDataAccess;
            _enrollmentService = enrollmentService;
            _cryptoService = cryptoService;
            _idempotentService = idempotentService;
            _accountService = accountService;
            _lazyCache = lazyCache;
            _agreementRepository = agreementRepository;
            _notificationPublisher = notificationPublisher;
            _welcomeNotificationService = welcomeNotificationService;
            _lockService = lockService;
            _addressIntervention = addressIntervention;
            _productService = productService;
            _programRepository = programRepository;
            _tokenizerService = tokenizerService;
            _baasConfiguration = baasConfiguration;
            _validateIdentifier = validateIdentifier;
            _gatewayService = gatewayService;
            _cNAPIService = cNAPIService;
            _configuration = requestHandlerSettings;
            _interestRateService = interestRateService;
        }

        public override void SetDomainContext(EnrollRequest request)
        {
            if (!string.IsNullOrEmpty(request.UserCreationData.IdentifyingData?.Ssn))
            {
                request.UserCreationData.IdentifyingData.IdentityValue = request.UserCreationData.IdentifyingData.Ssn;
                request.UserCreationData.IdentifyingData.IdentityType = IdentityType.SSN;
                request.UserCreationData.IdentifyingData.IdentityCountryCode = CountryCode.USA.ToString();
            }


            if (!string.IsNullOrEmpty(request.UserCreationData.IdentifyingData?.IdentityValue))
            {
                request.UserCreationData.IdentifyingData.IdentityCountryCode ??= CountryCode.USA.ToString();

                var identityType = request.UserCreationData.IdentifyingData.IdentityType == IdentityType.SSN
                    ? DomainExtensions.GetIdentityTypeBySsn(request.UserCreationData.IdentifyingData.IdentityValue)
                    : request.UserCreationData.IdentifyingData.IdentityType;
                DomainContext.Current.TokenizedIdentity = _tokenizerService.TokenizeIdentity(
                    request.UserCreationData.IdentifyingData.IdentityValue, identityType,
                    request.UserCreationData.IdentifyingData.IdentityCountryCode,
                    DomainContext.Current.ProgramCode.ToString());
            }
            DomainContext.Current.IgnoreMfa = request.RequestHeader?.IgnoreMfa;
        }

        public override Task<EnrollResponse> VerifyIdentifiers(EnrollRequest request)
        {
            _validateIdentifier.ValidateProduct(ProgramCode.FromString(request.ProgramCode),
            ProductCode.FromString(request.AccountCreationData.ProductCode));
            ValidateParentProduct(request.ProgramCode, request.AccountCreationData.ProductCode);
            return Task.FromResult(new EnrollResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override async Task<EnrollResponse> ObtainLock(EnrollRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock(OptionsContext.Current.GetString("requestId"));
                await _lockService.ObtainApiLock(DomainContext.Current.TokenizedIdentity);

                return new EnrollResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<EnrollResponse>(e, request);
            }
        }

        public override Task<EnrollResponse> Handle(EnrollRequest request)
        {

            try
            {

                string enrollmentRequestIdentifier = null;
                if (request.RequestHeader.Options != null && request.RequestHeader.Options.ContainsKey("X-GD-EnrollmentRequestIdentifier"))
                {
                    enrollmentRequestIdentifier = request.RequestHeader.Options["X-GD-EnrollmentRequestIdentifier"].ToString();
                }

                var denialResponse = DenyRestrictedRegionsEnrollment(request);
                if (denialResponse != null)
                    return denialResponse;

                var accountLimit = new AccountLimit();
                var newAccountIdentifier = Guid.NewGuid();

                var existingRequestAccountIdentifier = _requestDataAccess.InsertRequestId(RequestType.Enroll,
                    request.RequestHeader.RequestId, newAccountIdentifier);

                var isAcceptMinorEnrollment = _baasConfiguration.IsAcceptMinorEnrollment(request.ProgramCode, request.AccountCreationData.ProductCode);
                var bypassKycConfiguration = _baasConfiguration.GetBypassKYCValidationConfig(request.ProgramCode, request.AccountCreationData.ProductCode);
                var userIdentifyingData = request.UserCreationData?.IdentifyingData?.ToDomain(isAcceptMinorEnrollment);

                if (string.IsNullOrEmpty(userIdentifyingData?.OnBoardingId))
                {
                    if (bypassKycConfiguration.BypassSSN)
                    {
                        Logger.Info($"Skip AccountLimitVerification for accountIdentifier:{newAccountIdentifier},programCode:{request.ProgramCode},productCode: {request.AccountCreationData?.ProductCode}");
                    }
                    else
                    {
                        accountLimit = _accountService.AccountLimitVerification(userIdentifyingData?.IdentityValue, DomainContext.Current.TokenizedIdentity, userIdentifyingData?.GetIdentityTypeKey().ToString(), true, request.AccountCreationData?.ProductCode, request.ProgramCode);
                        accountLimit.ResponseCode = accountLimit.ResponseCode ?? "0";
                        if (accountLimit.ResponseCode != "0")
                            _lazyCache?.Value?.Set(request.RequestHeader?.RequestId.ToString(), accountLimit.ResponseCode, new TimeSpan(1, 0, 0, 0));
                    }
                }
                //If Identity limit succeeds then try phone limit
                var number = !string.IsNullOrEmpty(request.UserCreationData?.PhoneNumbers?.FirstOrDefault(p => p.IsDefault)?.Number) ? request.UserCreationData?.PhoneNumbers?.FirstOrDefault(p => p.IsDefault)?.Number : request.UserCreationData?.PhoneNumbers?.FirstOrDefault()?.Number;
                if (accountLimit.ResponseCode == "0")
                {
                    if (bypassKycConfiguration.BypassPhone)
                    {
                        Logger.Info($"Skip PhoneLimitVerification for accountIdentifier:{newAccountIdentifier},programCode:{request.ProgramCode},productCode: {request.AccountCreationData?.ProductCode}");
                    }
                    else
                    {
                        accountLimit = _accountService.PhoneLimitVerification(number, "PhoneNumber", request.AccountCreationData?.ProductCode, request.ProgramCode);
                        accountLimit.ResponseCode = accountLimit.ResponseCode ?? "0";
                        if (accountLimit.ResponseCode != "0")
                            _lazyCache?.Value?.Set(request.RequestHeader?.RequestId.ToString(), accountLimit.ResponseCode, new TimeSpan(1, 0, 0, 0));
                    }
                }

                //If phone limit succeeds then try email limit
                var verifyEmail = request.UserCreationData?.Email?.EmailAddress;
                if (accountLimit.ResponseCode == "0")
                {
                    if (bypassKycConfiguration.BypassEmail)
                    {
                        Logger.Info($"Skip EmailLimitVerification for accountIdentifier:{newAccountIdentifier},programCode:{request.ProgramCode},productCode: {request.AccountCreationData?.ProductCode}");
                    }
                    else
                    {
                        accountLimit = _accountService.EmailLimitVerification(verifyEmail, request.AccountCreationData?.ProductCode, request.ProgramCode);
                        accountLimit.ResponseCode ??= "0";
                        if (accountLimit.ResponseCode != "0")
                            _lazyCache?.Value?.Set(request.RequestHeader?.RequestId.ToString(), accountLimit.ResponseCode, new TimeSpan(1, 0, 0, 0));
                    }
                }

                if (existingRequestAccountIdentifier.HasValue || accountLimit.AccountIdentifier != null)
                {
                    newAccountIdentifier = accountLimit.AccountIdentifier == null
                        ? existingRequestAccountIdentifier.Value
                        : accountLimit.AccountIdentifier.ToGuid();

                    _enrollmentService.SaveEnrollRequest(request, newAccountIdentifier.ToString(), true);

                    var kycStateData = new Core.Domain.Model.Account.KycStateData();
                    var getEnrollmentResponse =
                        _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(newAccountIdentifier.ToString(),
                            request.ProgramCode, true);

                    if (accountLimit.ResponseCode != "0")
                    {
                        switch (accountLimit.ResponseCode)
                        {
                            case "260":
                                throw new RequestHandlerException(2, 60, "Number of Active Accounts Exceeded.");
                            case "261":
                                throw new RequestHandlerException(2, 61, "Number of Activated Accounts over Lifetime exceeded.");
                            case "264":
                                throw new RequestHandlerException(2, 64, "Account Holder limits are exceeded.");
                            case "267":
                                throw new RequestHandlerException(2, 67, "7 day opened account limit exceeded.");
                            case "268":
                                throw new RequestHandlerException(2, 68, "30 day opened account limit exceeded.");
                        }
                    }

                    if (getEnrollmentResponse?.Account != null)
                    {
                        var existingResponse = GetEnrollIdempotentResponse(
                            getEnrollmentResponse,
                            request,
                            accountLimit,
                            kycStateData,
                            newAccountIdentifier,
                            request.ContactVerificationIdentifiers,
                            enrollmentRequestIdentifier: enrollmentRequestIdentifier);
                        AccountHolder ah = existingResponse.AccountHolders.FirstOrDefault();

                        //Need to set BCD and AccountStatus here. https://pd/browse/GBOS-30134
                        if (ah.User?.KycStateData?.PendingKycGate == "healthy" &&
                            existingResponse.AccountCycleDay == 0 &&
                            ah.PaymentInstruments != null && ah.PaymentInstruments.Any())
                        {
                            var account = _accountService.GetAccount(existingResponse.AccountIdentifier);
                            //warning, if you need to use this account, it will only have the accountIdentifier and accountKey
                            string status = existingResponse.Status;
                            short? accountCycleDay = 0;
                            _idempotentService.FinishSettingBillCycle(account, request.ProgramCode, request.RequestHeader.RequestId, out accountCycleDay, out status);
                            existingResponse.Status = status;
                            existingResponse.AccountCycleDay = accountCycleDay;
                            existingResponse.StatusReasons = new List<string>
                            {
                                Core.Domain.Model.Account.AccountStatusReason.healthy.ToString()
                            };
                        }

                        return Task.FromResult(existingResponse);
                    }
                }

                if (request.AccountCreationData == null)
                {
                    throw new ArgumentNullException("Enroll: AccountCreationData");
                }

                var programCode = request.ProgramCode;
                var productCode = request.AccountCreationData.ProductCode;
                var productMaterialType = request.AccountCreationData.ProductMaterialType;

                _enrollmentService.SaveEnrollRequest(request, newAccountIdentifier.ToString(), false);

                if (!string.IsNullOrEmpty(productMaterialType))
                {
                    if (!_productService.IsValidProductMaterialTypeForProductTier(programCode, productMaterialType))
                        throw new InvalidProductMaterialException("Invalid Product Material type");
                }
                else if (string.IsNullOrEmpty(productMaterialType) && request.RequestPhysicalCardFlag)
                {
                    request.AccountCreationData.ProductMaterialType = GetDefaultProductMaterialType(programCode, productCode);
                }

                var response = new EnrollResponse();
                var userName = new UserName(request.UserCreationData?.ProfileData?.FirstName,
                    request.UserCreationData?.ProfileData?.MiddleName, request.UserCreationData?.ProfileData?.LastName);

                var email = request.UserCreationData?.Email?.ToDomain();

                var businessAccount = request.UserCreationData?.BusinessData?.ToDomain();

                if (request.UserCreationData?.BusinessData != null)
                {

                    // Use a dictionary to map field names to their values
                    Dictionary<string, string> validatingFields = new Dictionary<string, string>
                    {
                        { nameof(request.UserCreationData.BusinessData.BusinessIndustry), request.UserCreationData.BusinessData.BusinessIndustry },
                        { nameof(request.UserCreationData.BusinessData.URL), request.UserCreationData.BusinessData.URL },
                        { nameof(request.UserCreationData.BusinessData.BusinessTaxID), request.UserCreationData.BusinessData.BusinessTaxID },
                        { nameof(request.UserCreationData.BusinessData.BusinessEmailAddress), request.UserCreationData.BusinessData.BusinessEmailAddress },
                        { nameof(request.UserCreationData.BusinessData.BusinessType), request.UserCreationData.BusinessData.BusinessType.ToString() }
                    };
                    if (request.UserCreationData.BusinessData.BusinessAddress != null)
                    {
                        validatingFields.Add(nameof(request.UserCreationData.BusinessData.BusinessAddress.BusinessAddressLine1), request.UserCreationData.BusinessData.BusinessAddress.BusinessAddressLine1);
                        validatingFields.Add(nameof(request.UserCreationData.BusinessData.BusinessAddress.BusinessCity), request.UserCreationData.BusinessData.BusinessAddress.BusinessCity);
                        validatingFields.Add(nameof(request.UserCreationData.BusinessData.BusinessAddress.BusinessState), request.UserCreationData.BusinessData.BusinessAddress.BusinessState);
                        validatingFields.Add(nameof(request.UserCreationData.BusinessData.BusinessAddress.BusinessZipCode), request.UserCreationData.BusinessData.BusinessAddress.BusinessZipCode);
                        validatingFields.Add(nameof(request.UserCreationData.BusinessData.BusinessAddress.BusinessCountryCode), request.UserCreationData.BusinessData.BusinessAddress.BusinessCountryCode);
                    }
                    else
                    {
                        validatingFields.Add(nameof(request.UserCreationData.BusinessData.BusinessAddress), null);
                    }

                    var missingFields = ValidateBusinessData(validatingFields);

                    // Log warning if any fields are missing
                    if (missingFields.Any())
                    {
                        Logger.Warn($"WarnType=InvalidBusinessData;ClassName={nameof(EnrollHandler)};ProgramCode={programCode};AccountIdentifier={newAccountIdentifier}; Fields:{string.Join(",", missingFields.ToArray())} in User's BusinessData are missing or invalid");
                    }
                }

                if (businessAccount != null)
                {
                    businessAccount.AccountType = request.AccountCreationData?.AccountType;
                    if (businessAccount.BusinessType == 0)
                        throw new ValidationException(600, 0, "Invalid BusinessType");
                }


                var businessAddress = request.UserCreationData?.BusinessData?.BusinessAddress?.ToDomain();
                var addresses = new List<Address>();
                if (request.UserCreationData?.ProfileData?.Addresses != null)
                {
                    addresses = request.UserCreationData?.ProfileData?.Addresses?.ToDomain();
                }
                else
                {
                    var defaultAddress = _configuration.ToastDefaultAddress;
                    addresses.Add(defaultAddress);
                }

                var phoneNumbers =
                    request.UserCreationData?.PhoneNumbers?.ToDomain();

                var agreement =
                    _agreementRepository.GetAgreementsByProductCode(request.AccountCreationData.ProductCode);

                if (isAcceptMinorEnrollment && userIdentifyingData.IsMinor)
                {
                    if (!agreement.CheckExistAgreementForMinorEnroll())
                        throw new ValidationException(600, 0,
                            "Agreement for Additional Consent is not available for this Product Code");

                    if (request.AccountCreationData.TermsAcceptances == null || !request.AccountCreationData.TermsAcceptances.CheckExistAgreementForMinorEnroll())
                        throw new ValidationException(600, 0,
                            "Agreement for Additional Consent is not available on request or is not accepted");
                }

                var terms = request.AccountCreationData.TermsAcceptances?.ToDomain(agreement);

                var homeAddress = addresses.FirstOrDefault(add => add.AddressTypeKey == (short)AddressType.Home);

                if (businessAddress != null && homeAddress.IsDefault == false)
                {
                    businessAddress.IsBusinessAddressForPostal = true;
                }
                _addressIntervention.SetHomeAddressToDefault(addresses);
                _addressIntervention.ValidAddresses(addresses, true, bypassKycConfiguration.BypassAddress);

                var enrollResponse = _enrollmentService.Enroll(
                    newAccountIdentifier.ToString(),
                    request.ProgramCode,
                    request.AccountCreationData.ProductCode,
                    userName,
                    userIdentifyingData,
                    email,
                    addresses,
                    phoneNumbers,
                    request.ContactVerificationIdentifiers,
                    request.ExecuteKycFlag,
                    request.RequestPhysicalCardFlag,
                    terms,
                    request.AccountCreationData.ProductMaterialType,
                    request.AccountCreationData.CipLevel,
                    request.AccountCreationData.ProductClass,
                    businessAccount,
                    businessAddress,
                    request.AccountCreationData.Language,
                    /*https://pd/browse/GBOS-6925 - Scenario 1 request.OverrideAddressStandardization*/ true,
                    request.FraudData,
                    request.AccountCreationData.FraudData,
                    request.RequestHeader.Source,
                    enrollmentRequestIdentifier,
                    request.AccountCreationData.PartnerAccountId);


                var newUser = enrollResponse.Item2;
                var newAccount = enrollResponse.Item1;
                var newPaymentIdentifier = enrollResponse.Item3;
                var newAccountBalance = enrollResponse.Item4;
                var privateCardData = enrollResponse.Item5;
                var kycStateData2 = enrollResponse.Item6;

                response.KycStateData = kycStateData2 != null ? new KycStateData
                {
                    OfacStatus = kycStateData2.OfacStatus.ToString().ToLower(),
                    KycStatus = kycStateData2.KycStatus.ToString().ToLower(),
                    PendingKycGate = kycStateData2.KycPendingGate?.ToLower()
                } : null;

                string errorCode = _lazyCache?.Value?.Get<string>(request.RequestHeader?.RequestId.ToString());
                if (!string.IsNullOrEmpty(errorCode) && errorCode != "0")
                {
                    response.ResponseHeader = response.ResponseHeader.GetResponseHeader(errorCode, request.RequestHeader.RequestId);
                }
                else
                {
                    response.ResponseHeader = response.ResponseHeader.GetResponseHeader(newAccount.ErrorCode.ToString(), request.RequestHeader.RequestId);
                    _lazyCache?.Value?.Set(request.RequestHeader?.RequestId.ToString(), newAccount.ErrorCode.ToString(), new TimeSpan(1, 0, 0, 0));
                }
                Logger.Info($"errorCode:{errorCode}, newAccount ErrorCode:{newAccount?.ErrorCode}");

                response.AccountIdentifier = newAccount.AccountIdentifier.ToString();
                response.CustomerReferenceNumber = newAccount.CustomerAccountNumber;
                response.Status = newAccount.AccountStatus.ToString().ToLower();


                DateTime accountStatusDateChange = newAccount.AccountStatusChangedDateTime;
                accountStatusDateChange = accountStatusDateChange.ToUniversalTime();
                response.AccountStatusChangedDateTime =
                    accountStatusDateChange.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");


                if (newAccount.AccountStatusReasons?.Count > 0)
                {
                    response.StatusReasons = new List<string>();

                    foreach (Core.Domain.Model.Account.AccountStatusReason statusReason in newAccount
                        .AccountStatusReasons)
                    {
                        response.StatusReasons.Add(statusReason.ToString());
                    }
                }

                response.DirectDepositInformation = new DirectDepositInformation
                {
                    AccountNumber = newAccount.AccountNumber,
                    RoutingNumber = newAccount.RoutingNumber
                };


                if (newAccountBalance != null)
                {
                    response.Purses = new List<Purse>();
                    var purse = new Purse
                    {
                        PurseIdentifier = newAccountBalance.AccountBalanceIdentifier.ToString(),
                        PurseType = PurseType.Primary,
                        AvailableBalance = newAccountBalance.AvailableBalance,
                        LedgerBalance = newAccountBalance.CurrentBalance,
                        AvailableBalanceAsOfDateTime = newAccountBalance.AvailableBalanceAsOfDate,
                        LedgerBalanceAsOfDateTime = newAccountBalance.CurrentBalanceAsOfDate,
                        Status = newAccountBalance.Status
                    };
                    response.Purses.Add(purse);
                }

                response.AccountHolders = new List<AccountHolder>();
                var accountHolder = new AccountHolder();

                foreach (Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolder ah in newAccount.AccountHolders)
                {
                    accountHolder.User = new Bos.Shared.Common.Core.CoreApi.Contract.Data.User
                    {
                        UserIdentifier = newUser.UserIdentifier.ToString(),
                        Status = UserStatus.Active,
                        IsPrimaryAccountHolder = true,
                        KycStateData = new KycStateData
                        {
                            OfacStatus = ah.kycStateData.OfacStatus.ToString().ToLower(),
                            KycStatus = ah.kycStateData.KycStatus.ToString().ToLower(),
                            PendingKycGate = ah.kycStateData.KycPendingGate?.ToLower()
                        }
                    };


                    if (newPaymentIdentifier != null)
                    {
                        accountHolder.PaymentInstruments = new List<PaymentInstrument>();
                        var paymentInstrument = new PaymentInstrument();
                        //PaymentInstrumentStatus paymentInstrumentStatus;
                        Enum.TryParse(newPaymentIdentifier.PaymentInstrument.Status, out PaymentInstrumentStatus paymentInstrumentStatus);

                        paymentInstrument.PaymentIdentifier = newPaymentIdentifier.PaymentIdentifierIdentifier.ToString();
                        paymentInstrument.PaymentInstrumentIdentifier = newPaymentIdentifier?.PaymentInstrument
                            .PaymentInstrumentIdentifier.ToString();
                        paymentInstrument.PaymentInstrumentType =
                            newPaymentIdentifier.PaymentInstrument.PaymentInstrumentType;
                        paymentInstrument.Status = paymentInstrumentStatus;
                        paymentInstrument.IsPinSet = newPaymentIdentifier.PaymentInstrument.PinSetDate.HasValue;
                        paymentInstrument.Last4Pan = newPaymentIdentifier?.PaymentInstrument.Last4Pan;
                        paymentInstrument.ActivatedDateTime = newPaymentIdentifier?.PaymentInstrument.ActivatedDateTime;
                        paymentInstrument.IssuedDateTime = newPaymentIdentifier?.PaymentInstrument.IssuedDateTime;

                        if (privateCardData != null)
                        {
                            paymentInstrument.PrivateCardData =
                                new Bos.Shared.Common.Core.CoreApi.Contract.Data.PrivateCardData
                                {
                                    Pan = privateCardData?.Pan,
                                    Cvv = privateCardData?.Cvv,
                                    ExpirationDate = new CardExpirationDate
                                    {
                                        CardExpirationMonth = privateCardData?.CardExpirationDate.CardExpirationMonth,
                                        CardExpirationyear = privateCardData?.CardExpirationDate.CardExpirationYear
                                    }
                                };

                            if (paymentInstrument.PaymentInstrumentType == PaymentInstrumentType.Virtual)
                                paymentInstrument.IsPrivateDataViewable = "true";
                        }

                        accountHolder.PaymentInstruments.Add(paymentInstrument);
                    }

                    response.AccountHolders.Add(accountHolder);
                }

                if (!bypassKycConfiguration.BypassEmail)
                {
                    var cnapirequest = new CNApiContactUpdateRequest
                    {
                        Header = new CNAPIRequestHeader()
                        {
                            RequestId = request.RequestHeader?.RequestId.ToString(),
                            RequestOptions = request.RequestHeader?.Options
                        },
                        AccountIdentifer = newAccount.AccountIdentifier.ToString(),
                        ProgramCode = request.ProgramCode,
                        ProductCode = request.AccountCreationData?.ProductCode,
                        Contacts = new List<Contact>
                    {
                        new Contact
                        {
                            ChannelType = 1,
                            ContactValue = number
                        },
                        new Contact
                        {
                            ChannelType= 2,
                            ContactValue = email.EmailAddress
                        }
                    }

                    };

                    try
                    {
                        var cnapiResponse = _cNAPIService.UpdateContact(cnapirequest);
                    }
                    catch (Exception ex)
                    {
                        Logger.Warn(ex, $"Failed to call NotifyAPI.UpdateCustomerContract");
                    }
                }
                var accountResp = _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(newAccount.AccountIdentifier.ToString(), request.ProgramCode, false);
                response.AccountCycleDay = accountResp.Account.AccountCycleDay;
                response.AccountToken = accountResp.Account.AccountToken;
                //GBOS-139864 [Intuit QB] Enroll-level APY changes to the new engine EF team
                if (_baasConfiguration.InitWhenSettingBillCycleDay(programCode))
                {
                    _interestRateService.ProcessAccountInterestConfig(enrollResponse.Item1.AccountIdentifier, programCode, enrollResponse.Item1.AccountKey, (short)accountResp.Account.AccountCycleDay);
                }
                if (!request.RequestPhysicalCardFlag)
                    MassagePNMessage(accountResp.Account);
                _notificationPublisher.PublishNotification(request.ProgramCode, accountResp.Account, EventType.AccountUpdated, request.RequestHeader.RequestId.ToString());
                if (accountResp.Account.Status == "normal")
                {
                    if (string.IsNullOrEmpty(_productService.GetProductMaterialType(request.ProgramCode, request.AccountCreationData?.ProductMaterialType)))
                    {
                        _welcomeNotificationService.RaiseWelcomeNotification(request.ProgramCode, accountResp.Account.AccountIdentifier, request.RequestHeader.RequestId);
                    }

                    Task.Run(async () =>
                    {
                        await _gatewayService.SendTokenEmailInBux(request.ProgramCode, response.AccountIdentifier, response.AccountHolders?.FirstOrDefault()?.User.UserIdentifier, request.RequestHeader.RequestId);
                    });
                }
                else if (_accountService.IsDeclinedAccount(accountResp.Account))
                    _welcomeNotificationService.RaiseUnwelcomeNotification(request.ProgramCode, accountResp.Account.AccountIdentifier, request.RequestHeader.RequestId);

                // this this until we need this for multiple account holders
                response.KycStateData = null;

                return Task.FromResult(response);
            }
            catch (InvalidProductMaterialException e)
            {
                var response = new EnrollResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 4,
                        SubStatusCode = 312,
                        Message = e.Message
                    },
                };
                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<EnrollResponse>(e, request));
            }
        }

        public override void ReleaseLock(EnrollRequest request)
        {
            _lockService.ReleaseApiLock(OptionsContext.Current.GetString("requestId"));
            _lockService.ReleaseApiLock(DomainContext.Current.TokenizedIdentity);
        }

        private Task<EnrollResponse> DenyRestrictedRegionsEnrollment(EnrollRequest request)
        {
            var restrictRegionResponse = new EnrollResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 5,
                    SubStatusCode = 65,
                    Message = "This product may not be registered in the requested region"
                }
            };

            //request will be rejected if any address contain state = gu
            var existsGuState = request?.UserCreationData?.ProfileData?.Addresses?.Any(a => a.State == "GU");
            if (existsGuState.HasValue && existsGuState.Value)
            {
                return Task.FromResult(restrictRegionResponse);
            }

            var state = request?.UserCreationData?.ProfileData?.Addresses?.FirstOrDefault()?.State;


            //pr is allowed only when IsPRAddressAllowed exists
            if (!_baasConfiguration.IsPRAddressAllowed(request.ProgramCode))
            {
                if (state != null && state.Equals("PR", StringComparison.InvariantCultureIgnoreCase))
                {
                    return Task.FromResult(restrictRegionResponse);
                }
            }

            return null;
        }

        private EnrollResponse GetEnrollIdempotentResponse(GetEnrollmentResponse getEnrollmentResponse,
                                                           EnrollRequest request,
                                                           AccountLimit accountLimit,
                                                           Core.Domain.Model.Account.KycStateData kycStateData,
                                                           Guid? existingRequestAccountIdentifier,
                                                           Guid[] contactVerificationIdentifiers,
                                                           string enrollmentRequestIdentifier = null)
        {
            var phoneNumbers = request.UserCreationData?.PhoneNumbers?.ToDomain();
            var errorCode = _lazyCache?.Value?.Get<string>(request.RequestHeader?.RequestId.ToString());
            // keep only activated virtual as first enrollment does not 
            // return the magStripe payment instrument
            foreach (var ah in getEnrollmentResponse.Account.AccountHolders)
            {
                if (request.UserCreationData?.IdentifyingData != null
                    && ah?.User?.DateOfBirth != request.UserCreationData?.IdentifyingData?.DateOfBirth)
                    throw new RequestHandlerException(2, 60, "Number of Active Accounts Exceeded.");

                if (string.IsNullOrEmpty(request.UserCreationData?.IdentifyingData?.OnBoardingId)
                    && string.IsNullOrEmpty(request.UserCreationData?.IdentifyingData?.Ssn)
                    && string.IsNullOrEmpty(request.UserCreationData?.IdentifyingData?.IdentityValue))
                    _accountService.AccountLimitVerificationBySsnToken(ah?.SsnToken, request.AccountCreationData?.ProductCode, request?.ProgramCode);

                if ((ah.PaymentInstruments == null && getEnrollmentResponse?.Account?.Status?.ToLower() == "pending") ||

                    (ah.PaymentInstruments?.Count(n =>
                     n.PaymentInstrumentType == PaymentInstrumentType.MagStripe ||
                     n.PaymentInstrumentType == PaymentInstrumentType.Emv ||
                     n.PaymentInstrumentType == PaymentInstrumentType.ContactlessEmv) == 0) &&
                    getEnrollmentResponse?.Account?.Status?.ToLower() == "pending")
                {
                    _accountService.EmailLimitVerification(request?.ProgramCode, request.UserCreationData?.Email?.EmailAddress, 2);

                    Core.Domain.Model.Account.KycStateData kycData = ah.User?.KycStateData?.ToDomain();
                    var enablePhoneVerification = Configuration.Current.HighHurdleLowHurdleProgramCodes.Any(x => x.Equals(request?.ProgramCode.Trim(), StringComparison.InvariantCultureIgnoreCase));

                    kycStateData = _idempotentService?.EnrollIdempotent(
                        existingRequestAccountIdentifier.Value.ToString(),
                        ah.User?.UserIdentifier,
                        kycData,
                        request.AccountCreationData?.ProductMaterialType,
                        request?.ProgramCode,
                        request.RequestPhysicalCardFlag,
                        request.AccountCreationData?.CipLevel,
                        request.UserCreationData?.IdentifyingData?.OnBoardingId,
                        contactVerificationIdentifiers,
                        phoneNumbers,
                        ProductCode.FromString(getEnrollmentResponse.Account.ProductCode),
                        getEnrollmentResponse.Account.ProductName,
                        enablePhoneVerification,
                        enrollmentRequestIdentifier: enrollmentRequestIdentifier);

                    if (kycStateData?.KycPendingGate != null)
                        getEnrollmentResponse =
                            _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(
                                existingRequestAccountIdentifier.Value.ToString(), request.ProgramCode,
                                true);

                    if (kycStateData?.KycPendingGate == "healthy")
                        foreach (var accHolder in getEnrollmentResponse.Account?.AccountHolders)
                            accHolder.PaymentInstruments = accHolder?.PaymentInstruments
                                ?.Where(x => x.PaymentInstrumentType == PaymentInstrumentType.Virtual)
                                .ToList();
                    else
                    {
                        // if not healthy need to run the rules engine to get the error code
                        if (kycStateData.ResponseCode != 0)
                            errorCode = kycStateData.ResponseCode.ToString();
                    }
                }
                else if (!request.RequestPhysicalCardFlag)
                {
                    ah.PaymentInstruments = ah.PaymentInstruments
                        ?.Where(x => x.PaymentInstrumentType == PaymentInstrumentType.Virtual).ToList();
                }
            }

            // var paymentInst
            var existingResponse = new EnrollResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                },
                AccountIdentifier = getEnrollmentResponse.Account.AccountIdentifier,
                CustomerReferenceNumber = getEnrollmentResponse.Account.CustomerReferenceNumber,
                Status = getEnrollmentResponse.Account.Status,
                StatusReasons = getEnrollmentResponse.Account.StatusReasons,
                StatusCure = getEnrollmentResponse.Account.StatusCure,
                DirectDepositInformation = getEnrollmentResponse.Account.DirectDepositInformation,
                Purses = getEnrollmentResponse.Account.Purses,
                AccountHolders = getEnrollmentResponse.Account.AccountHolders,
                AccountStatusChangedDateTime = getEnrollmentResponse.Account?.AccountStatusChangedDateTime,
                AccountCycleDay = getEnrollmentResponse.Account.AccountCycleDay,
                KycStateData = kycStateData == null ? null : new KycStateData()
                {
                    KycStatus = kycStateData.KycStatus.ToString(),
                    PendingKycGate = kycStateData.KycPendingGate,
                    OfacStatus = kycStateData.OfacStatus.ToString()
                }
            };

            foreach (var accHolder in existingResponse.AccountHolders)
            {
                accHolder.User.PeerTransferAcceptPreference = null;
                accHolder.AccountHolderIdentifier = null;
            }

            if (!string.IsNullOrEmpty(errorCode))
                existingResponse.ResponseHeader =
                    existingResponse.ResponseHeader?.GetResponseHeader(errorCode,
                        request.RequestHeader.RequestId);

            var existingPaymentInstrument = existingResponse.AccountHolders.FirstOrDefault()
                ?.PaymentInstruments?.FirstOrDefault();
            var existingPrivateCardData = existingPaymentInstrument?.PrivateCardData;

            if (existingPrivateCardData != null
                && existingPaymentInstrument.PaymentInstrumentType == PaymentInstrumentType.Virtual)
            {
                var generateCvvResponse = _cryptoService.GenerateCvv(
                    AccountIdentifier.FromString(getEnrollmentResponse.Account.AccountIdentifier),
                    existingPrivateCardData.Pan,
                    existingPrivateCardData.ExpirationDate.CardExpirationyear.Substring(2) +
                    existingPrivateCardData.ExpirationDate.CardExpirationMonth,
                    existingPaymentInstrument.PaymentInstrumentType);

                existingPrivateCardData.Pan = existingPrivateCardData.Pan;
                existingPrivateCardData.Cvv = generateCvvResponse.Cvv;
            }


            if (existingPrivateCardData != null && _baasConfiguration.IsPinSetNeed(request.ProgramCode, existingPaymentInstrument?.IsPinSet) == false)
                existingPaymentInstrument.PrivateCardData = null;

            var accountResp = _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(getEnrollmentResponse.Account.AccountIdentifier, request.ProgramCode, false);
            _notificationPublisher.PublishNotification(request.ProgramCode, accountResp.Account, EventType.AccountUpdated);

            existingResponse.AccountToken = accountResp.Account.AccountToken;
            return existingResponse;
        }

        /// <summary>
        /// make PN message equivalent to enrollment response
        /// </summary>
        /// <param name="account"></param>
        /// <returns></returns>
        private Account MassagePNMessage(Account account)
        {
            foreach (var accHolder in account.AccountHolders)
            {
                // remove all PI which are not virtual cards
                accHolder.PaymentInstruments = accHolder.PaymentInstruments?.Where(x => x.PaymentInstrumentType == PaymentInstrumentType.Virtual).ToList();
            }
            return account;
        }

        private string GetDefaultProductMaterialType(string programCode, string productCode)
        {
            var productMaterialType = string.Empty;
            var prg = _programRepository.GetByProgramIdentifier(ProgramCode.FromString(programCode));
            var prgInfo = _programRepository.GetProgramTierInfo(prg.ProgramKey);
            var valueList = prgInfo.ProductTiers.Where(p => p.ProductCode.Equals(productCode, StringComparison.InvariantCultureIgnoreCase) && p.ProductTierAttribute == "CardStock" && p.IsDefault).ToList();

            var processor = _enrollmentDataAccess.GetProcessorByProductCode(productCode);
            var defaultProductMaterialTypeList = prgInfo.ProductmaterialTypes?.Where(pt => pt.ProcessorKey == (int)processor && pt.IsDefault);

            if (defaultProductMaterialTypeList != null)
            {
                foreach (var defaultProductMaterialType in defaultProductMaterialTypeList)
                {
                    if (valueList.Exists(v => v.Value.Equals(defaultProductMaterialType.ProcessorValue, StringComparison.InvariantCultureIgnoreCase)))
                    {
                        productMaterialType = defaultProductMaterialType.ProductMaterialType;
                        break;
                    }
                }
            }

            if (productMaterialType == null)
            {
                throw new InvalidProductMaterialException($"Can not find proper Product Material type for programCode {programCode}, productCode {productCode}");
            }

            return productMaterialType;
        }

        private void ValidateParentProduct(string programCode, string productCode)
        {
            var parentProductCodes = _baasConfiguration.GetParentProductCode(programCode);

            if (parentProductCodes?.Any() != true)
            {
                return;
            }

            var isMatch = parentProductCodes.Any(p => productCode?.Equals(p, StringComparison.OrdinalIgnoreCase) == true);
            if (!isMatch)
            {
                throw new ValidationException(600, 5010, $"The product code {productCode} is not a parent product code for program code {programCode}.");
            }
        }

        public List<string> ValidateBusinessData(Dictionary<string, string> validatingFields)
        {
            List<string> missingFields = new List<string>();

            // Check each field for null or whitespace
            foreach (var field in validatingFields)
            {
                if (string.IsNullOrWhiteSpace(field.Value))
                {
                    missingFields.Add(field.Key);
                }
            }
            return missingFields;
        }
    }
}
