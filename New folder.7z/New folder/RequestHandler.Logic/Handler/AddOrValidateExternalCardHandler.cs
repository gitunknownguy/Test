﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.ExternalCard;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Queue;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Logic.Service;
using NLog;
using Gd.Bos.RequestHandler.Core.Infrastructure;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class AddOrValidateExternalCardHandler : CommandHandlerBase<AddExternalCardRequest, AddExternalCardResponse>
    {

        public AddOrValidateExternalCardHandler(
            IExternalCardService externalCardService,
            IIftDataAccess IFTDataAccess,
            IValidateIdentifier validateIdentifier,
            IPaymentInstrumentService paymentInstrumentService)
        {
            _externalCardService = externalCardService;
            _IFTDataAccess = IFTDataAccess;
            _validateIdentifier = validateIdentifier;
            _paymentInstrumentService = paymentInstrumentService;
        }

        public override void SetDomainContext(AddExternalCardRequest request)
        {
            if (request.Action.ToLower() == "add")
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<AddExternalCardResponse> VerifyIdentifiers(AddExternalCardRequest request)
        {
            if (request.Action.ToLower() == "add")
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 4, 105);
            }
            return Task.FromResult(new AddExternalCardResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<AddExternalCardResponse> Handle(AddExternalCardRequest request)
        {
            if (request.Pan.Length <= 12)
                throw new RequestHandlerException(5, 315, "Card length is not valid");


            var bin6 = request.Pan.Substring(0, 6);
            var bin8 = request.Pan.Substring(0, 8);

            BinDetail binDetail = _IFTDataAccess.GetBinDetail(bin8) ?? _IFTDataAccess.GetBinDetail(bin6);

            AddExternalCardResponse response = new AddExternalCardResponse();
            response = _externalCardService.AddOrValidateExternalCard(request, binDetail);
            response.ResponseHeader = new ResponseHeader()
            {
                ResponseId = request.RequestHeader.RequestId,
                Message = "Success"
            };
            return Task.FromResult(response);
        }

        private readonly IExternalCardService _externalCardService;
        private readonly IIftDataAccess _IFTDataAccess;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IPaymentInstrumentService _paymentInstrumentService;
    }
}
