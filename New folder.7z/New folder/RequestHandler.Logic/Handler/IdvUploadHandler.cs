﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using System.Linq;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using MassTransit.Testing;
using NLog;
using RequestHandler.Core.Application;
using RequestHandler.Core.Domain.Services.TokenManagementService;
using RequestHandler.Core.Domain.Services.TokenManagementService.EventMessage;
using RequestHandler.Core.Infrastructure.UpgradeAccount;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class IdvUploadHandler : CommandHandlerBase<IdvUploadRequest, IdvUploadResponse>
    {

        public IdvUploadHandler(IVerificationService verificationService,
            INotificationService notificationPublisher,
            IEnrollmentDataAccess enrollmentDataAccess,
            IValidateIdentifier validateIdentifier,
            ILockService lockService,
            IAccountService accountService,
            ICustomerNotificationService customerNotificationService,
            IUserRepository userRepository,
            ITokenManagementService tokenManagementService)
        {
            _notificationPublisher = notificationPublisher;
            _verificationService = verificationService;
            _enrollmentDataAccess = enrollmentDataAccess;
            _validateIdentifier = validateIdentifier;
            _lockService = lockService;
            _accountService = accountService;
            _customerNotificationService = customerNotificationService;
            _userRepository = userRepository;
            _tokenManagementService = tokenManagementService;
        }

        public override void SetDomainContext(IdvUploadRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            DomainContext.Current.UserIdentifier = request.UserIdentifier;
        }

        public override Task<IdvUploadResponse> VerifyIdentifiers(IdvUploadRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidateConsumerProfileIdentifier(DomainContext.Current.AccountIdentifier, DomainContext.Current.UserIdentifier);
                _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 2, 105);
                return Task.FromResult(new IdvUploadResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<IdvUploadResponse>(e, request));
            }
        }

        public override async Task<IdvUploadResponse> ObtainLock(IdvUploadRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock(DomainContext.Current.AccountIdentifier.ToString());
                await _lockService.ObtainApiLock(DomainContext.Current.UserIdentifier.ToString());

                return new IdvUploadResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<IdvUploadResponse>(e, request);
            }
        }

        [ExcludeFromCodeCoverage(Justification = "Temp exclude. Remove.")]
        public override async Task<IdvUploadResponse> Handle(IdvUploadRequest request)
        {
            try
            {
                var account = _accountService.GetAdditionalHolderAccountByAccountIdentifier(request.AccountIdentifier);

                IdvUploadResponse response = null;
                var createIdvRequest = new CreateVerifyRequest
                {
                    Document = new CreateDocumentInfo(),
                    ProgramCode = request.ProgramCode
                };

                if (account.AccountStatus == Core.Domain.Model.Account.AccountStatus.Normal)
                    createIdvRequest.IsPrimaryIdvFlag = true;

                var isJoinAccount = _accountService.IsJointAccount(request.AccountIdentifier);
                _logger.Info($"IDVUpload checked isJoinAccount {isJoinAccount} with request id {request.RequestHeader?.RequestId}, account id {request.AccountIdentifier}");
                if (account.AccountHolders?.Count > 1)
                {
                    // GBOS-80672 allow credibly to continue even if restricted/locked
                    if (!string.Equals(request.ProgramCode, "Credibly", StringComparison.InvariantCultureIgnoreCase))
                    {
                        switch (account.AccountStatus)
                        {
                            case AccountStatus.Locked:
                                if (isJoinAccount) break;
                                throw new RequestHandlerException(5, 106, "IDV cannot be called to cure an additional account holder if the account is locked.");
                            case AccountStatus.Restricted:
                                throw new RequestHandlerException(5, 100, "IDV cannot be called to cure an additional account holder if the account is restricted.");

                            default:
                                break;
                        }
                    }

                    createIdvRequest.ExistingAccountHolderStatus = account.AccountStatus;
                    createIdvRequest.IsAccountHolderExists = true;
                }

                if (string.IsNullOrWhiteSpace(request.IdvDocumentInfo?.DocumentFrontImage) ||
                   (string.IsNullOrWhiteSpace(request.IdvDocumentInfo?.DocumentBackImage) &&
                    string.CompareOrdinal(request.IdvDocumentInfo?.DocumentType?.ToLower(), "passport") != 0))
                {
                    // if passport only need front image
                    // all others need front and back image
                    throw new MissingIDVImageException(string.IsNullOrWhiteSpace(request.IdvDocumentInfo?.DocumentFrontImage) ? "DocumentFrontImage must be provided" : "DocumentBackImage must be provided");
                }

                if (!VerificationService.DocumentTypes.Contains(request.IdvDocumentInfo?.DocumentType.ToLower()))
                    throw new InvalidDocumentType();

                createIdvRequest.Document.BackImage = request.IdvDocumentInfo?.DocumentBackImage;
                createIdvRequest.Document.Image = request.IdvDocumentInfo?.DocumentFrontImage;
                createIdvRequest.Document.CountryCode = request.IdvDocumentInfo?.DocumentCountryCode;
                createIdvRequest.Document.DocumentType = request.IdvDocumentInfo?.DocumentType;
                createIdvRequest.Source = request.RequestHeader?.Source;
                createIdvRequest.CustomData = new Dictionary<string, object>();

                if (request.FraudData != null && request.FraudData.Keys.Contains("IpAddress", StringComparer.CurrentCultureIgnoreCase))
                    createIdvRequest.CustomData.Add("IpAddress", request.FraudData.FirstOrDefault(a => a.Key.ToLower().Contains("ipaddress")).Value);

                createIdvRequest.RequestHeader =
                    new Core.Domain.Services.Risk.Messages.Request.RequestHeader()
                    {
                        RequestId = request.RequestHeader?.RequestId ?? new Guid()
                    };

                if (request.IdvRequestType != null &&
                    request.IdvRequestType.Equals("Prerequisite", StringComparison.OrdinalIgnoreCase))
                    createIdvRequest.TriggerType = TriggerType.Prerequisite;

                createIdvRequest.AccountIdentifier = request.AccountIdentifier;
                createIdvRequest.UserIdentifier = request.UserIdentifier;
                if (request.IdvRequestType == "AccountUpgrade")
                {
                    createIdvRequest.TriggerType = TriggerType.AccountUpgrade;
                }

                KycStateData kycData;
                if (isJoinAccount)
                {
                    kycData = _verificationService.PostEnrollmentIdvVerificationForJoinAccounts(createIdvRequest);
                }
                else
                {
                    kycData = _verificationService.PostEnrollmentIdvVerification(createIdvRequest);
                }

                if (kycData?.IsKyc == false)
                {
                    response = new IdvUploadResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader?.RequestId ?? new Guid(),
                            StatusCode = 1,
                            SubStatusCode = 12,
                            Message = "KYC Gate does not match kycPendingGate"
                        },
                        KycGate = new Bos.Shared.Common.Core.CoreApi.Contract.Data.KycGate()
                        {
                            KycStateData = new Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData()
                            {
                                PendingKycGate = kycData.KycPendingGate?.ToLower()
                            }
                        }
                    };
                }
                else
                {
                    response = new IdvUploadResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader?.RequestId ?? new Guid(),
                            StatusCode = kycData?.ResponseCode ?? 0,
                            SubStatusCode = kycData?.SubCode ?? 0,
                            Message = kycData?.Message
                        },
                        KycGate = new Shared.Common.Core.CoreApi.Contract.Data.KycGate()
                        {
                            KycStateData = new Shared.Common.Core.CoreApi.Contract.Data.KycStateData()
                            {
                                KycStatus = kycData?.KycStatus.ToString().ToLower(),
                                OfacStatus = kycData?.OfacStatus.ToString().ToLower(),
                                PendingKycGate = kycData?.KycPendingGate?.ToLower()
                            }
                        }
                    };
                }

                switch (kycData?.KycPendingGate?.ToLower())
                {
                    case "idv":
                        return response;
                    case "ddidv":
                        return response;
                }

                if (request.IdvRequestType != "AccountUpgrade")
                {
                    var accountResp =
                    _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(request.AccountIdentifier,
                        request.ProgramCode, true);
                    if (isJoinAccount)
                    {
                        accountResp.Account.AccountHolders = accountResp.Account.AccountHolders.Where(a => a.User.UserIdentifier.Equals(request.UserIdentifier, StringComparison.OrdinalIgnoreCase))?.ToList();
                    }
                    _notificationPublisher.PublishNotification(request.ProgramCode, accountResp.Account,
                    Shared.Common.Core.CoreApi.Contract.Data.EventType.AccountUpdated);

                    await EnrollNotificationWhenKycApproved(
                        kycData?.KycPendingGate,
                        accountResp.Account.AccountIdentifier,
                        accountResp.Account.Status,
                        request.ProgramCode,
                        accountResp.Account.ProductCode,
                        request.RequestHeader?.RequestId ?? new Guid());
                }

                return response;
            }
            catch (Exception e)
            {
                return e.HandleException<IdvUploadResponse>(e, request);
            }
        }

        [ExcludeFromCodeCoverage(Justification = "Exclude log statement. Remove this.")]
        private async Task EnrollNotificationWhenKycApproved(string kycPendingGate,
            string accountIdentifier,
            string accountStatus,
            string programCode,
            string productCode,
            Guid requestId)
        {
            if (kycPendingGate?.ToLower() != "healthy")
                return;

            var userInfo = _userRepository.GetUser(
                AccountIdentifier.FromString(accountIdentifier),
                null)?.FirstOrDefault(x => x.IsPrimaryAccountHolder);

            if (userInfo == null)
            {
                _logger.Info(
                    $"EnrollNotificationWhenKycApproved,UserInfo is null AccountIdentifier={accountIdentifier}");
                return;
            }

            await _customerNotificationService.EnrollNotificationsWhenKycApprovedAsync(
                userInfo.AccountIdentifier,
                programCode,
                productCode,
                userInfo.PhoneNumbers.FirstOrDefault(f => f.IsDefault)?.Number,
                userInfo.Email?.EmailAddress,
                requestId
            );

            await _tokenManagementService.PublishUserProfileUpdatedMessageAsync(
                requestId, programCode,
                new UserProfileUpdatedMessage
                {
                    AccountStatus = accountStatus,
                    AccountIdentifier = userInfo.AccountIdentifier,
                    ProgramCode = programCode,
                });
        }

        public override void ReleaseLock(IdvUploadRequest request)
        {
            _lockService.ReleaseApiLock(DomainContext.Current.AccountIdentifier.ToString());
            _lockService.ReleaseApiLock(DomainContext.Current.UserIdentifier.ToString());
        }

        private readonly INotificationService _notificationPublisher;
        private IVerificationService _verificationService;
        private readonly IEnrollmentDataAccess _enrollmentDataAccess;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ILockService _lockService;
        private readonly IAccountService _accountService;
        private readonly ICustomerNotificationService _customerNotificationService;
        private readonly IUserRepository _userRepository;
        private readonly ITokenManagementService _tokenManagementService;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();
    }
}
