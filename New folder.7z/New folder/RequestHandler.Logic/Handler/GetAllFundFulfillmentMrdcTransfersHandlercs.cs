﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetAllFundFulfillmentMrdcTransfersHandler : CommandHandlerBase<GetAllFundFulfillmentMrdcTransfersRequest, GetAllFundFulfillmentMrdcTransfersResponse>
    {
        private static string unspecifiedGuid = Guid.Empty.ToString();
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ITransferService _transferService;

        public GetAllFundFulfillmentMrdcTransfersHandler(ITransferService transferService, IValidateIdentifier validateIdentifier)
        {
            _transferService = transferService;
            _validateIdentifier = validateIdentifier;
        }
        public override void SetDomainContext(GetAllFundFulfillmentMrdcTransfersRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetAllFundFulfillmentMrdcTransfersResponse> VerifyIdentifiers(GetAllFundFulfillmentMrdcTransfersRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetAllFundFulfillmentMrdcTransfersResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetAllFundFulfillmentMrdcTransfersResponse>(e, request));
            }
        }

        public override Task<GetAllFundFulfillmentMrdcTransfersResponse> Handle(GetAllFundFulfillmentMrdcTransfersRequest request)
        {
            try
            {

                if (request.RequestHeader.RequestId == Guid.Empty)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId, $"{nameof(request)}.RequestHeader.RequestId must be specified");
                }

                if (string.IsNullOrEmpty(request.AccountIdentifier) || request.AccountIdentifier == unspecifiedGuid)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier, $"{nameof(request)}.TransferIdentifier must be specified");
                }

                DateTime endDate = request.EndDate.HasValue ? request.EndDate.Value : DateTime.MinValue;
                var response = _transferService.GetAllFundFulfillmentMrdcTransfers(request.RequestHeader.RequestId.ToString(), request.ProgramCode, request.AccountIdentifier,
                    request.StartDate, endDate, request.Offset, request.Limit);


                return Task.FromResult(new GetAllFundFulfillmentMrdcTransfersResponse()
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = response.ResponseHeader.StatusCode,
                        SubStatusCode = response.ResponseHeader.SubStatusCode,
                        Message = response.ResponseHeader.Message,
                        //Details = response.ResponseHeader.Details
                    },
                    TotalRecordCount = response.TotalRecordCount,
                    Transfers = response.Transfers
                });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetAllFundFulfillmentMrdcTransfersResponse>(e, request));
            }
        }
    }
}
