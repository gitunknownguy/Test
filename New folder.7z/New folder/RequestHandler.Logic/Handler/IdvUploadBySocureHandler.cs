﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using NLog;
using RequestHandler.Core.Application;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class IdvUploadBySocureHandler : CommandHandlerBase<IdvUploadBySocureRequest, IdvUploadBySocureResponse>
    {
        private IVerificationService _verificationService;
        private readonly INotificationService _notificationPublisher;
        private readonly IEnrollmentDataAccess _enrollmentDataAccess;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ILockService _lockService;
        private readonly IAccountService _accountService;
        private readonly ICustomerNotificationService _customerNotificationService;
        private readonly IUserRepository _userRepository;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();

        public IdvUploadBySocureHandler(IVerificationService verificationService,
            INotificationService notificationPublisher,
            IEnrollmentDataAccess enrollmentDataAccess,
            IValidateIdentifier validateIdentifier,
            ILockService lockService,
            IAccountService accountService,
            ICustomerNotificationService customerNotificationService,
            IUserRepository userRepository)
        {
            _notificationPublisher = notificationPublisher;
            _verificationService = verificationService;
            _enrollmentDataAccess = enrollmentDataAccess;
            _validateIdentifier = validateIdentifier;
            _lockService = lockService;
            _accountService = accountService;
            _customerNotificationService = customerNotificationService;
            _userRepository = userRepository;
        }

        public override void SetDomainContext(IdvUploadBySocureRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            DomainContext.Current.UserIdentifier = request.UserIdentifier;
        }

        public override Task<IdvUploadBySocureResponse> VerifyIdentifiers(IdvUploadBySocureRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidateConsumerProfileIdentifier(DomainContext.Current.AccountIdentifier, DomainContext.Current.UserIdentifier);
                _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 2, 105);
                return Task.FromResult(new IdvUploadBySocureResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<IdvUploadBySocureResponse>(e, request));
            }
        }

        public override async Task<IdvUploadBySocureResponse> ObtainLock(IdvUploadBySocureRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock(DomainContext.Current.AccountIdentifier.ToString());
                await _lockService.ObtainApiLock(DomainContext.Current.UserIdentifier.ToString());

                return new IdvUploadBySocureResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<IdvUploadBySocureResponse>(e, request);
            }
        }

        public override Task<IdvUploadBySocureResponse> Handle(IdvUploadBySocureRequest request)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(request?.DocumentUuid) && string.IsNullOrWhiteSpace(request?.DocVTransactionToken))
                {
                    throw new MissingIDVImageException("Either DocumentUuid/DocVTransactionToken must be provided");
                }

                var account = _accountService.GetAdditionalHolderAccountByAccountIdentifier(request.AccountIdentifier);

                IdvUploadBySocureResponse response = null;
                var createIdvRequest = new CreateVerifyRequest
                {
                    RequestHeader = new Core.Domain.Services.Risk.Messages.Request.RequestHeader()
                    {
                        RequestId = request.RequestHeader?.RequestId ?? new Guid()
                    },
                    Document = new CreateDocumentInfo() { DocumentUuid = request.DocumentUuid,DocVTransactionToken=request.DocVTransactionToken },
                    ProgramCode = request.ProgramCode
                };
                createIdvRequest.EventSource = request.EventSource;
                if (account.AccountStatus == AccountStatus.Normal)
                    createIdvRequest.IsPrimaryIdvFlag = true;
                createIdvRequest.AccountIdentifier = request.AccountIdentifier;
                createIdvRequest.UserIdentifier = request.UserIdentifier;
                createIdvRequest.Source = request.RequestHeader?.Source;
                createIdvRequest.CustomData = new Dictionary<string, object>();
                if (request.FraudData != null && request.FraudData.Keys.Count > 0)
                {
                    foreach (var fraudData in request.FraudData)
                    {
                        createIdvRequest.CustomData.Add(fraudData.Key, fraudData.Value);
                    }
                }

                var isJoinAccount = _accountService.IsJointAccount(request.AccountIdentifier);
                _logger.Info($"Checked isJoinAccount: {isJoinAccount} with request id {request.RequestHeader?.RequestId}");
                if (account.AccountHolders?.Count > 1)
                {
                    // GBOS-80672 allow credibly to continue even if restricted/locked
                    if (!string.Equals(request.ProgramCode, "Credibly", StringComparison.InvariantCultureIgnoreCase))
                    {
                        switch (account.AccountStatus)
                        {
                            case AccountStatus.Locked:
                                if (isJoinAccount) break;
                                throw new RequestHandlerException(5, 106, "IDV cannot be called to cure an additional account holder if the account is locked.");
                            case AccountStatus.Restricted:
                                throw new RequestHandlerException(5, 100, "IDV cannot be called to cure an additional account holder if the account is restricted.");

                            default:
                                break;
                        }
                    }

                    createIdvRequest.ExistingAccountHolderStatus = account.AccountStatus;
                    createIdvRequest.IsAccountHolderExists = true;
                }

                KycStateData kycData;
                if (isJoinAccount)
                {
                    kycData = _verificationService.PostEnrollmentIdvVerificationForJoinAccounts(createIdvRequest);
                }
                else
                {
                    kycData = _verificationService.PostEnrollmentIdvVerification(createIdvRequest);
                }

                if (kycData?.IsKyc == false)
                {
                    response = new IdvUploadBySocureResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader?.RequestId ?? new Guid(),
                            StatusCode = 1,
                            SubStatusCode = 12,
                            Message = "KYC Gate does not match kycPendingGate"
                        },
                        KycGate = new Bos.Shared.Common.Core.CoreApi.Contract.Data.KycGate()
                        {
                            KycStateData = new Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData()
                            {
                                PendingKycGate = kycData.KycPendingGate?.ToLower()
                            }
                        }
                    };
                }
                else
                {
                    response = new IdvUploadBySocureResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader?.RequestId ?? new Guid(),
                            StatusCode = kycData?.ResponseCode ?? 0,
                            SubStatusCode = kycData?.SubCode ?? 0,
                            Message = kycData?.Message
                        },
                        KycGate = new Shared.Common.Core.CoreApi.Contract.Data.KycGate()
                        {
                            KycStateData = new Shared.Common.Core.CoreApi.Contract.Data.KycStateData()
                            {
                                KycStatus = kycData?.KycStatus.ToString().ToLower(),
                                OfacStatus = kycData?.OfacStatus.ToString().ToLower(),
                                PendingKycGate = kycData?.KycPendingGate?.ToLower()
                            }
                        }
                    };
                }

                switch (kycData?.KycPendingGate?.ToLower())
                {
                    case "idv":
                        return Task.FromResult(response);
                    case "ddidv":
                        return Task.FromResult(response);
                }

                if (createIdvRequest.TriggerType != TriggerType.AccountUpgrade)
                {
                    var accountResp =_enrollmentDataAccess.GetEnrollmentByAccountIdentifier(request.AccountIdentifier, request.ProgramCode, true);
                    if (isJoinAccount)
                    {
                        accountResp.Account.AccountHolders = accountResp.Account.AccountHolders.Where(a => a.User.UserIdentifier.Equals(request.UserIdentifier, StringComparison.OrdinalIgnoreCase))?.ToList();
                    }
                    _notificationPublisher.PublishNotification(request.ProgramCode, accountResp.Account,
                    Shared.Common.Core.CoreApi.Contract.Data.EventType.AccountUpdated);

                    EnrollNotificationWhenKycApproved(
                        kycData?.KycPendingGate,
                        accountResp.Account.AccountIdentifier,
                        request.ProgramCode,
                        accountResp.Account.ProductCode,
                        request.RequestHeader?.RequestId ?? new Guid());
                }

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<IdvUploadBySocureResponse>(e, request));
            }
        }

        private void EnrollNotificationWhenKycApproved(
            string kycPendingGate,
            string accountIdentifier,
            string programCode,
            string productCode,
            Guid requestId)
        {
            if (kycPendingGate?.ToLower() == "healthy")
            {
                var userInfo = _userRepository.GetUser(AccountIdentifier.FromString(accountIdentifier), null)?.FirstOrDefault(x => x.IsPrimaryAccountHolder);

                if (userInfo != null)
                {
                    _customerNotificationService.EnrollNotificationsWhenKycApprovedAsync(
                        userInfo.AccountIdentifier,
                        programCode,
                        productCode,
                        userInfo.PhoneNumbers.FirstOrDefault(f => f.IsDefault)?.Number,
                        userInfo.Email?.EmailAddress,
                        requestId
                    );
                }
                else
                {
                    _logger.Info(
                        $"EnrollNotificationWhenKycApproved,UserInfo is null AccountIdentifier={accountIdentifier}");
                }
            }
        }

        public override void ReleaseLock(IdvUploadBySocureRequest request)
        {
            _lockService.ReleaseApiLock(DomainContext.Current.AccountIdentifier.ToString());
            _lockService.ReleaseApiLock(DomainContext.Current.UserIdentifier.ToString());
        }
    }
}
