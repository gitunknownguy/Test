﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Domain.Services.PaperCheck;
using Gd.Bos.RequestHandler.Core.Infrastructure;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class StopPaperCheckPaymentHandler : CommandHandlerBase<StopPaymentRequest, StopPaymentResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ILockService _lockService;
        private readonly IPaperCheckService _paperCheckService;

        public StopPaperCheckPaymentHandler(IValidateIdentifier validateIdentifier, IPaperCheckService paperCheckService, ILockService lockService)
        {
            _validateIdentifier = validateIdentifier;
            _lockService = lockService;
            _paperCheckService = paperCheckService;
        }

        
        public override void SetDomainContext(StopPaymentRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        
        public override Task<StopPaymentResponse> VerifyIdentifiers(StopPaymentRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 4, 105);
                return Task.FromResult(new StopPaymentResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<StopPaymentResponse>(e, request));
            }
        }

        
        public override async Task<StopPaymentResponse> ObtainLock(StopPaymentRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock(DomainContext.Current.AccountIdentifier.ToString());
                return new StopPaymentResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<StopPaymentResponse>(e, request);
            }
        }

        /// <summary>
        /// Handle
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public override Task<StopPaymentResponse> Handle(StopPaymentRequest request)
        {
            try
            {
                CheckInventoryRequest req = new CheckInventoryRequest();

                if (request.CheckInventoryStatus != null
                    && request.CheckInventoryStatus.Equals("stoppayment", StringComparison.InvariantCultureIgnoreCase))
                    req.CheckFulfillmentStatus = Convert.ToInt32(CheckInventoryStatus.StopPayment).ToString();

                req.AccountIdentifier = request.AccountIdentifier;
                req.CheckNumber = request.CheckNumber;
                req.ProgramCode = request.ProgramCode;
                req.StopReason = request.StopReason;
                req.EndCheckNumber=request.EndCheckNumber;

                var response = _paperCheckService.StopPaperCheckPayment(req);

                if (response.ErrorCode == "02001")
                    throw new RequestHandlerException(10, 1, "Check not found.");
                if (response.ErrorCode == "04001")
                    throw new RequestHandlerException(10, 0, "No CheckBookOrders were found.");
                if (response.ErrorCode == "04002")
                    throw new RequestHandlerException(101, 0, "Some check numbers in the range cannot be stopped");
                if (response.ErrorCode == "02002" || response.ErrorCode == "02010" || response.ErrorCode == "02004")
                    throw new RequestHandlerException(101, 0, "Check cannot be modified.");

                if (response.ErrorCode == "02003")
                    throw new RequestHandlerException(409, 0, "Check paid already.");

                if (response.ErrorCode == "0")
                {
                    var resp = new StopPaymentResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 0,
                            SubStatusCode = 0,
                            Message = "Success"
                        }
                    };

                    return Task.FromResult(resp);
                }

                throw new RequestHandlerException(400, 0, "Invalid arguments.");
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<StopPaymentResponse>(e, request));
            }
        }

        
        public override void ReleaseLock(StopPaymentRequest request)
        {
            _lockService.ReleaseApiLock(DomainContext.Current.AccountIdentifier.ToString());
        }

    }
}
