﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetContactVerificationStatusHandler : CommandHandlerBase<GetContactVerificationStatusRequest, GetContactVerificationStatusResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IContactService _contactVerificationService;
        public GetContactVerificationStatusHandler(IValidateIdentifier validateIdentifier, IContactService contactVerificationService)
        {
            _contactVerificationService = contactVerificationService;
            _validateIdentifier = validateIdentifier;

        }
        public override Task<GetContactVerificationStatusResponse> Handle(GetContactVerificationStatusRequest request)
        {
            try
            {
                if (request.RequestHeader.RequestId == Guid.Empty)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId,
                        $"{nameof(request)}.RequestHeader.RequestId must be specified");
                }

                GetContactVerificationStatusResponse response = _contactVerificationService.GetContactVerificationStatus(request);
                return Task.FromResult(new GetContactVerificationStatusResponse()
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = (response.ResponseHeader?.StatusCode) ?? 0,
                        SubStatusCode = (response.ResponseHeader?.SubStatusCode) ?? 0,
                        Message = response.ResponseHeader?.Message
                    },
                    Status = response.Status,
                    Contact = response.Contact,
                    ContactType = response.ContactType,
                    CommunicationType = response.CommunicationType
                });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetContactVerificationStatusResponse>(e, request));
            }
        }
        public override void SetDomainContext(GetContactVerificationStatusRequest request)
        {
            return;
        }
        public override Task<GetContactVerificationStatusResponse> VerifyIdentifiers(GetContactVerificationStatusRequest request)
        {
            try
            {
                return Task.FromResult(new GetContactVerificationStatusResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetContactVerificationStatusResponse>(e, request));
            }
        }
    }
}
