﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Domain.Services.PaperCheck;
using Gd.Bos.RequestHandler.Core.Infrastructure;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class CheckBookOrderHandler : CommandHandlerBase<CheckBookOrderRequest, CheckBookOrderResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ILockService _lockService;
        private readonly IPaperCheckService _paperCheckService;

        public CheckBookOrderHandler(IValidateIdentifier validateIdentifier, IPaperCheckService paperCheckService, ILockService lockService)
        {
            _validateIdentifier = validateIdentifier;
            _lockService = lockService;
            _paperCheckService = paperCheckService;
        }

        public override void SetDomainContext(CheckBookOrderRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<CheckBookOrderResponse> VerifyIdentifiers(CheckBookOrderRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 4, 105);
                return Task.FromResult(new CheckBookOrderResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CheckBookOrderResponse>(e, request));
            }
        }

        public override async Task<CheckBookOrderResponse> ObtainLock(CheckBookOrderRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock(DomainContext.Current.AccountIdentifier.ToString());
                return new CheckBookOrderResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<CheckBookOrderResponse>(e, request);
            }
        }

        /// <summary>
        /// Handle
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public override Task<CheckBookOrderResponse> Handle(CheckBookOrderRequest request)
        {
            try
            {
                CheckBookRequest req = new CheckBookRequest();

                if (request.CheckBookOrderStatus != null
                    && request.CheckBookOrderStatus.Equals("NotReceived", StringComparison.InvariantCultureIgnoreCase))
                    req.CheckBookOrderStatus = "notReceived";

                req.AccountIdentifier = request.AccountIdentifier;
                req.OrderConfirmationToken = request.OrderConfirmationToken;
                req.ProgramCode = request.ProgramCode;

                var response = _paperCheckService.CheckBookOrder(req);

                if (response.ErrorCode == "03001")
                    throw new RequestHandlerException(10, 1, "Check book order is not found.");

                if (response.ErrorCode == "03003")
                    throw new RequestHandlerException(409, 0, "CheckBookOrder already has checks that have been used.  It cannot be modified..");


                if (response.ErrorCode == "0")
                {
                    var resp = new CheckBookOrderResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 0,
                            SubStatusCode = 0,
                            Message = "Success"
                        }
                    };

                    return Task.FromResult(resp);
                }

                throw new RequestHandlerException(400, 0, "Invalid arguments.");
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CheckBookOrderResponse>(e, request));
            }
        }

        public override void ReleaseLock(CheckBookOrderRequest request)
        {
            _lockService.ReleaseApiLock(DomainContext.Current.AccountIdentifier.ToString());
        }

    }
}