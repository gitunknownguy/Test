﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;

namespace RequestHandler.Logic.Handler
{
    public class GetTrackMyMailHistoryHandler : CommandHandlerBase<GetTrackMyMailHistoryRequest, GetTrackMyMailHistoryResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ITrackMyMailService _trackMyMailService;

        public GetTrackMyMailHistoryHandler(IValidateIdentifier validateIdentifier, ITrackMyMailService trackMyMailService)
        {
            _validateIdentifier = validateIdentifier;
            _trackMyMailService = trackMyMailService;
        }
        public override void SetDomainContext(GetTrackMyMailHistoryRequest request)
        {
            DomainContext.Current.ProgramCode = ProgramCode.FromString(request.ProgramCode);
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetTrackMyMailHistoryResponse> VerifyIdentifiers(GetTrackMyMailHistoryRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetTrackMyMailHistoryResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetTrackMyMailHistoryResponse>(e, request));
            }
        }

        public override Task<GetTrackMyMailHistoryResponse> Handle(GetTrackMyMailHistoryRequest request)
        {
            try
            {
                var trackMyMailHistoryResponse = _trackMyMailService.GetTrackMyMailHistory(request);

                return Task.FromResult(trackMyMailHistoryResponse);

            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetTrackMyMailHistoryResponse>(e, request));
            }
        }
    }
}
