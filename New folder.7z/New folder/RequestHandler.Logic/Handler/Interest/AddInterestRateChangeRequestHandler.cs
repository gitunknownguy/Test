﻿using System;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.InterestRate;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.InterestTier;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.InterestTier;
using RequestHandler.Core.Domain.Model.Validators;


namespace RequestHandler.Logic.Handler.Interest
{
    public class AddInterestRateChangeRequestHandler : CommandHandlerBase<AddInterestRateChangeRequest,
        AddInterestRateChangeRequestResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IInterestRateService _interestRateService;

        public AddInterestRateChangeRequestHandler(IValidateIdentifier validateIdentifier,
            IInterestRateService interestRateService)
        {
            _validateIdentifier = validateIdentifier;
            _interestRateService = interestRateService;
        }

        public override void SetDomainContext(AddInterestRateChangeRequest request)
        {
        }

        public override Task<AddInterestRateChangeRequestResponse> VerifyIdentifiers(
            AddInterestRateChangeRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.ProgramCode);
                return Task.FromResult(
                    new AddInterestRateChangeRequestResponse { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AddInterestRateChangeRequestResponse>(e, request));
            }
        }

        public override Task<AddInterestRateChangeRequestResponse> Handle(AddInterestRateChangeRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.ProgramCode))
                    throw new ArgumentNullException($"ProgramCode: Program Code cannot be null or empty.");

                var response = new AddInterestRateChangeRequestResponse
                {
                    Message =
                        $"The change request for {request.ProgramCode} has been received, it will be processed shortly.",
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Error"
                    },
                };

                if (_interestRateService.AddInterestRateChangeRequest(request))
                    response.ResponseHeader.Message = "Success";

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AddInterestRateChangeRequestResponse>(e, request));
            }
        }
    }
}
