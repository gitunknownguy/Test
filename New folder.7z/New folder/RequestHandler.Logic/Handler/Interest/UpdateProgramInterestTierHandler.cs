﻿using System;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.InterestRate;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Logic;

namespace RequestHandler.Logic.Handler.Interest
{
    public class UpdateProgramInterestTierHandler : CommandHandlerBase<UpdateProgramInterestTierRequest,
        UpdateProgramInterestTierResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IInterestRateService _interestRateService;

        public UpdateProgramInterestTierHandler(IValidateIdentifier validateIdentifier,
            IInterestRateService interestRateService)
        {
            _validateIdentifier = validateIdentifier;
            _interestRateService = interestRateService;
        }

        public override void SetDomainContext(UpdateProgramInterestTierRequest request)
        {
        }

        public override Task<UpdateProgramInterestTierResponse> VerifyIdentifiers(UpdateProgramInterestTierRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.ProgramCode);
                return Task.FromResult(new UpdateProgramInterestTierResponse { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpdateProgramInterestTierResponse>(e, request));
            }
        }

        public override Task<UpdateProgramInterestTierResponse> Handle(UpdateProgramInterestTierRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.ProgramCode))
                    throw new ArgumentNullException($"ProgramCode: Program Code cannot be null or empty.");

                var response = new UpdateProgramInterestTierResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                };

                var result = _interestRateService.UpdateProgramInterestTier(request);
                switch (result.StatusCode)
                {
                    case 10:
                        response.ResponseHeader.Message = "Error";
                        response.ResponseHeader.StatusCode = result.StatusCode;
                        response.ResponseHeader.Details = result.Message;
                        break;
                    default:
                        break;
                }

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpdateProgramInterestTierResponse>(e, request));
            }
        }
    }
}
