﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.BillPay;
using Gd.Bos.RequestHandler.Core.Domain.Services.BillPay.Mappers;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Logic.Common;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class BillPayDeletePaymentHandler : CommandHandlerBase<BillPayDeletePaymentRequest, BillPayDeletePaymentResponse>
    {
        private readonly IBillPayService _billPayService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly INotificationService _notificationService;
        private readonly IBaasConfiguration _baasConfiguration;

        public BillPayDeletePaymentHandler(IBillPayService billPayService, IValidateIdentifier validateIdentifier, INotificationService notificationService, IBaasConfiguration baasConfiguration)
        {
            _billPayService = billPayService;
            _validateIdentifier = validateIdentifier;
            _notificationService = notificationService;
            _baasConfiguration = baasConfiguration;
        }

        public override void SetDomainContext(BillPayDeletePaymentRequest request)
        {
            if (!String.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<BillPayDeletePaymentResponse> VerifyIdentifiers(BillPayDeletePaymentRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 3, 105);
                return Task.FromResult(new BillPayDeletePaymentResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<BillPayDeletePaymentResponse>(e, request));
            }
        }

        public override Task<BillPayDeletePaymentResponse> Handle(BillPayDeletePaymentRequest request)
        {
            #region Request Validations
            if (request.RequestHeader.RequestId == Guid.Empty)
            {
                throw new RequestHandlerException(400, (int)ResponseSubcodes.Invalid_RequestId, $"{nameof(request)}.RequestHeader.RequestId must be specified");
            }

            if (string.IsNullOrEmpty(request.ProgramCode) || request.ProgramCode == Guid.Empty.ToString())
            {
                throw new RequestHandlerException(400, (int)ResponseSubcodes.Invalid_Transfer_Identifier, $"{nameof(request)}.ProgramCode must be specified");
            }

            if (string.IsNullOrEmpty(request.AccountIdentifier) || request.AccountIdentifier == Guid.Empty.ToString())
            {
                throw new RequestHandlerException(400, (int)ResponseSubcodes.Invalid_Account, $"{nameof(request)}.AccountIdentifier must be specified");
            }

            if (string.IsNullOrEmpty(request.PaymentIdentifier) || request.PaymentIdentifier == Guid.Empty.ToString())
            {
                throw new RequestHandlerException(400, (int)ResponseSubcodes.Invalid_Transfer_Identifier, $"{nameof(request)}.PaymentIdentifier must be specified");
            }
            #endregion

            try
            {

                var response = _billPayService.DeletePayment(request.ToGssModel());

                if (response == null) 
                { 
                    throw new RequestHandlerException(503, 0,
                        $"Unable to Delete Payment for account {request.AccountIdentifier}");
                }
                else
                {
                    //Canceled Payment webhook
                    if (_baasConfiguration.PublishPartnerNotificationForBillPay(request.ProgramCode))
                    {
                        var gssBillPayment = _billPayService.GetPayment(new GssGetPaymentRequest()
                        {
                            AccountIdentifier = request.AccountIdentifier,
                            PartnerId = request.ProgramCode,
                            PaymentIdentifier = request.PaymentIdentifier
                        });

                        //Since we are canceling the recurrence, there's no transaction/transfer attached, so we treat this as a new one
                        var billPayment = gssBillPayment.ToCoreBillPayTransfer(Guid.NewGuid().ToString(), "canceled", request.PaymentIdentifier);
                        billPayment.PaymentStatus = response.PaymentStatus;

                        _notificationService.PublishNotification(request.ProgramCode,
                        new BillPayTransferToPublish()
                        {
                            AccountIdentifier = request.AccountIdentifier,
                            BillPayTransfer = billPayment
                        },
                        EventType.BillPayTransfer);
                    }
                }

                var coreResponse = response.ToCoreModel();
                coreResponse.ResponseHeader.ResponseId = request.RequestHeader.RequestId;

                return Task.FromResult(coreResponse);
            }
            catch (Exception ex)
            {
                return Task.FromResult(ex.HandleException<BillPayDeletePaymentResponse>(ex, request));
            }
        }
    }
}
