﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Application.UpgradeAccount;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Interest;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Services.Dcpp;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.Common.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Domain.Model.Inventory;
using RequestHandler.Core.Domain.Services.RetailCard;
using PaymentInstrumentAttribute = Gd.Bos.Shared.Common.Core.Common.Enum.PaymentInstrumentAttributes;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    [ExcludeFromCodeCoverage(Justification = "Not tested previously and currently can't be easily mocked and will be taken care of on GBOS-116633")]
    public class GetEnrollmentHandlerV2 : CommandHandlerBase<GetEnrollmentRequest, GetEnrollmentResponse>
    {
        private readonly IAsyncEnrollmentDataAccess _enrollmentDataAccess;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IAsyncInterestRateRepository _interestRateRepository;
        private readonly IAsyncRetailCardService _retailCardService;
        private readonly IAsyncInstantIssueCardInventoryRepository _instantIssueCardInventoryRepository;
        private readonly IAsyncUpgradeAccountService _upgradeAccountService;
        private readonly IAsyncDcppService _dcppService;
        private readonly IAsyncAccountBalanceRepository _accountBalanceRepository;
        private readonly IBaasConfiguration _baasConfiguration;
        private readonly IAsyncPaymentIdentifierRepository _paymentIdentifierRepository;
        private readonly IAsyncProductService _productService;

        public GetEnrollmentHandlerV2(
            IAsyncEnrollmentDataAccess enrollmentDataAccess,
            IValidateIdentifier validateIdentifier,
            IAsyncInterestRateRepository interestRateRepository,
            IAsyncRetailCardService retailCardService,
            IAsyncInstantIssueCardInventoryRepository instantIssueCardInventoryRepository,
            IAsyncUpgradeAccountService upgradeAccountService,
            IAsyncDcppService dcppService,
            IAsyncAccountBalanceRepository accountBalanceRepository,
            IBaasConfiguration baasConfiguration,
            IAsyncPaymentIdentifierRepository paymentIdentifierRepository,
            IAsyncProductService productService
            )
        {
            _enrollmentDataAccess = enrollmentDataAccess;
            _validateIdentifier = validateIdentifier;
            _interestRateRepository = interestRateRepository;
            _retailCardService = retailCardService;
            _instantIssueCardInventoryRepository = instantIssueCardInventoryRepository;
            _upgradeAccountService = upgradeAccountService;
            _dcppService = dcppService;
            _accountBalanceRepository = accountBalanceRepository;
            _baasConfiguration = baasConfiguration;
            _paymentIdentifierRepository = paymentIdentifierRepository;
            _productService = productService;
        }

        public override void SetDomainContext(GetEnrollmentRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetEnrollmentResponse> VerifyIdentifiers(GetEnrollmentRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetEnrollmentResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetEnrollmentResponse>(e, request));
            }
        }

        public override async Task<GetEnrollmentResponse> Handle(GetEnrollmentRequest request)
        {
            try
            {
                var getEnrollmentResponse = await _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(request.AccountIdentifier, request.ProgramCode, request.IncludePrivatePaymentInstrumentData);

                if (getEnrollmentResponse == null)
                {
                    throw new AccountNotFoundException();
                }

                //TODO: Need to get a purse from GSS
                if (request.ProgramCode.Equals(Configuration.Current.GBRProgramCode,
                    StringComparison.OrdinalIgnoreCase) && (getEnrollmentResponse.Account.Purses == null || getEnrollmentResponse.Account.Purses.Count == 0))
                {
                    var tempPurse = await _retailCardService.GetBalance(new GetPursesRequest() { AccountIdentifier = request.AccountIdentifier, ProgramCode = request.ProgramCode, RequestHeader = request.RequestHeader });
                    getEnrollmentResponse.Account.Purses = tempPurse?.Purses?.ToList();
                }


                var accountBalanceInterests =
                    await _interestRateRepository.GetAccountBalanceInterests(request.AccountIdentifier);
                var programInterestTierMetaData =
                    await _interestRateRepository.GetProductInterestTierInfoByProgramCode(request.ProgramCode);

                if (getEnrollmentResponse.Account.Purses != null && getEnrollmentResponse.Account.Purses.Count > 0)
                {
                    foreach (var purse in getEnrollmentResponse.Account.Purses)
                    {
                        var activeTier = _interestRateRepository.GetActiveTier(
                            accountBalanceInterests.Where(a =>
                                a.AccountBalanceIdentifier == purse.PurseIdentifier));
                        purse.InterestRateTierIdentifier = activeTier?.AccountBalanceInterestIdentifier.ToString();
                        purse.APY = activeTier?.APY;
                        purse.InterestRateTier = (activeTier != null) ? programInterestTierMetaData?.Tiers?.FirstOrDefault(p => p.Key == activeTier?.InterestRateTierKey)?.Name : String.Empty;
                        purse.InterestYieldStartDate = activeTier?.InterestYieldStartDate.Value.ToString("yyyy-MM-dd");
                        purse.InterestYieldEndDate = activeTier?.InterestYieldEndDate?.ToString("yyyy-MM-dd");
                    }
                    bool getBalanceFromPartner = _baasConfiguration.GetBalanceFromPartner(request?.ProgramCode?.ToLower());
                    if (getBalanceFromPartner)
                    {
                        bool isRoutingToCPM = _dcppService.IsRoutingToCPM(request.AccountIdentifier);
                        if (isRoutingToCPM)
                        {
                            var primaryPurse = getEnrollmentResponse.Account.Purses.FirstOrDefault(p => p.PurseType == Shared.Common.Core.CoreApi.Contract.Data.Enum.PurseType.Primary);
                            if (primaryPurse != null)
                            {
                                var accountBalance = await _dcppService.GetAccountBalance(request.ProgramCode, request.AccountIdentifier);
                                DateTime now = TimeZoneInfo.ConvertTime(DateTime.Now, TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time"));

                                if (accountBalance?.AvailableBalance != null)
                                {
                                    if (primaryPurse.AvailableBalance != accountBalance.AvailableBalance.Amount &&
                                        primaryPurse.AvailableBalanceAsOfDateTime != null &&
                                        primaryPurse.AvailableBalanceAsOfDateTime < now)
                                        primaryPurse.AvailableBalanceAsOfDateTime = now;
                                    primaryPurse.AvailableBalance = accountBalance.AvailableBalance.Amount;
                                }

                                if (accountBalance?.CurrentBalance != null)
                                {
                                    if (primaryPurse.LedgerBalance != accountBalance.CurrentBalance.Amount &&
                                        primaryPurse.LedgerBalanceAsOfDateTime != null &&
                                        primaryPurse.LedgerBalanceAsOfDateTime < now)
                                        primaryPurse.LedgerBalanceAsOfDateTime = now;
                                    primaryPurse.LedgerBalance = accountBalance.CurrentBalance.Amount;
                                }

                                if (primaryPurse.AvailableBalance != 0)
                                {
                                    AccountBalance balance = new AccountBalance(AccountBalanceIdentifier.FromString(primaryPurse.PurseIdentifier), true, false);
                                    balance.SetAvailableBalance(primaryPurse.AvailableBalance);
                                    balance.SetCurrentBalance(primaryPurse.LedgerBalance);

                                    await _accountBalanceRepository.UpdateForAci(balance, now, now);
                                }
                            }
                        }
                    }
                }

                //Only for GPR products check if account is an Instant Issue
                if (getEnrollmentResponse.Account.ProductCode == "51711" && !string.IsNullOrEmpty(await _instantIssueCardInventoryRepository.GetInstantIssueCardInventoryByAccountIdentifier(new Guid(getEnrollmentResponse.Account.AccountIdentifier))))
                {
                    getEnrollmentResponse.Account.InstantIssue = true;
                }

                getEnrollmentResponse.ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                };

                getEnrollmentResponse.Account.UpgradeKycStateData = await _upgradeAccountService.GetUpgradeKycStateData(
                    request.ProgramCode,
                    getEnrollmentResponse.Account.ProductCode,
                    getEnrollmentResponse.Account.AccountIdentifier,
                    getEnrollmentResponse.Account.UpgradeKycStateData);

                var cardIssueSource = (await _productService.GetAllProductTierInfoByProgramCodeProductCode(request.ProgramCode, getEnrollmentResponse.Account.ProductCode))
                    .FirstOrDefault(p => p.ProductTierAttribute == "CardIssueSource");
                //Get PMT by PaymentInstrumentIdentifier
                if((getEnrollmentResponse.Account?.AccountHolders?.Count ?? 0) > 0)
                {
                    foreach (var accountHolder in getEnrollmentResponse.Account.AccountHolders)
                    {
                        if (accountHolder.PaymentInstruments != null)
                        {
                            foreach (var paymentInstrument in accountHolder.PaymentInstruments)
                            {
                                paymentInstrument.ProductMaterialType =
                                    await GetPmtByPaymentInstrumentIdentifier(paymentInstrument.PaymentInstrumentIdentifier);
                                this.SetPmtCardIssueSource(paymentInstrument, cardIssueSource);
                            }
                        }
                    }
                }

                return getEnrollmentResponse;
            }
            catch (Exception e)
            {
                return e.HandleException<GetEnrollmentResponse>(e, request);
            }
        }

        private async void SetPmtCardIssueSource(Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PaymentInstrument paymentInstrument, ProductTierInfo cardIssueSource)
        {
            if (paymentInstrument.PaymentInstrumentType == PaymentInstrumentType.MagStripe)
            {
                if (cardIssueSource != null)
                {
                    switch (cardIssueSource.Value)
                    {
                        case "Retail":
                            paymentInstrument.CardIssueSource = CardIssueSource.Retailer;
                            break;
                        case "FSC":
                            paymentInstrument.CardIssueSource = CardIssueSource.FSC;
                            break;
                    }
                }
                else
                {
                    paymentInstrument.CardIssueSource = CardIssueSource.Mailer;
                }
            }
            else if (paymentInstrument.PaymentInstrumentType == PaymentInstrumentType.ContactlessEmv || paymentInstrument.PaymentInstrumentType == PaymentInstrumentType.Emv)
            {
                paymentInstrument.CardIssueSource = await IsCardPrintable(paymentInstrument.PaymentInstrumentIdentifier) ? CardIssueSource.FSC : CardIssueSource.Mailer;
            }
        }

        private async Task<bool> IsCardPrintable(string paymentInstrumentIdentifier)
        {
            return (await this.GetCardPrintableByPaymentInstrumentIdentifier(paymentInstrumentIdentifier)) == "true";
        }

        private async Task<string> GetCardPrintableByPaymentInstrumentIdentifier(string paymentInstrumentIdentifier)
        {
            var paymentInstrumentDetail = (await _paymentIdentifierRepository.GetPaymentInstrumentDetails(Guid.Parse(paymentInstrumentIdentifier)))
             .FirstOrDefault(p =>
                 p.PaymentInstrumentAttribute == PaymentInstrumentAttribute.CardPrintable);
            return paymentInstrumentDetail?.PaymentInstrumentAttributeValue;
        }

        private async Task<string> GetPmtByPaymentInstrumentIdentifier(string paymentInstrumentIdentifier)
        {
            if (!Guid.TryParse(paymentInstrumentIdentifier, out var identifier))
            {
                return null;
            }

            var paymentInstrumentDetail = (await _paymentIdentifierRepository.GetPaymentInstrumentDetails(identifier))
                .FirstOrDefault(p =>
                    p.PaymentInstrumentAttribute == PaymentInstrumentAttribute.SelectedProductMaterialType);
            return paymentInstrumentDetail?.PaymentInstrumentAttributeValue;
        }
    }
}
