﻿using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Newtonsoft.Json;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;


namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetTransferByTokenHandler : CommandHandlerBase<GetTransferByTokenRequest, GetTransferByTokenResponse>
    {

        private readonly ITransferService _transferService;
        private readonly IValidateIdentifier _validateIdentifier;



        public GetTransferByTokenHandler(ITransferService transferService, IValidateIdentifier validateIdentifier)
        {
            _transferService = transferService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(GetTransferByTokenRequest request)
        {
            DomainContext.Current.ProgramCode = ProgramCode.FromString(request.ProgramCode);
        }

        public override Task<GetTransferByTokenResponse> VerifyIdentifiers(GetTransferByTokenRequest request)
        {
            _validateIdentifier.ValidateProgramCode(DomainContext.Current.ProgramCode);
            return Task.FromResult(new GetTransferByTokenResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<GetTransferByTokenResponse> Handle(GetTransferByTokenRequest request)
        {
            GetTransferByTokenResponse response = _transferService.GetTransferByToken(request);
            response.ResponseHeader = new ResponseHeader()
            {
                Message = "Success",
                ResponseId = request.RequestHeader.RequestId
            };
            var message = JsonConvert.SerializeObject(new { response }, new JsonSerializerSettings() { NullValueHandling = NullValueHandling.Ignore });
            return Task.FromResult(response);
        }
    }
}
