﻿using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;

namespace RequestHandler.Logic.Handler
{
    public class CreditBuilderPaymentHandler : CommandHandlerBase<CreditBuilderPaymentRequest, CreditBuilderPaymentResponse>
    {
        public override Task<CreditBuilderPaymentResponse> Handle(CreditBuilderPaymentRequest request)
        {
            return Task.FromResult(new CreditBuilderPaymentResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    Message = "Payment processed successfully."
                }
            });
        }

        public override void SetDomainContext(CreditBuilderPaymentRequest request)
        {
            //throw new System.NotImplementedException();
        }

        public override Task<CreditBuilderPaymentResponse> VerifyIdentifiers(CreditBuilderPaymentRequest request)
        {
            return Task.FromResult(new CreditBuilderPaymentResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    Message = "Identifiers verified successfully."
                }
            });
        }
    }
}
