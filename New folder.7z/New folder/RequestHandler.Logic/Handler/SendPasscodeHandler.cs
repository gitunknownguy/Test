﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.Common.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.DeviceProvisioning;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.DeviceProvisioning;
using Gd.Bos.Shared.Common.CoreApi.Contract.Message.Request;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using Gd.Bos.Shared.Common.Core.Common.Enum;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using System;
using Gd.Bos.RequestHandler.Core.Domain.Services.ContactVerification;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using RequestHandler.Core.Domain.Model;
using RequestHeader = Gd.Bos.Shared.Common.Contract.Message.Request.RequestHeader;
using RequestHandler.Logic.DataAccess;
using NLog;
using ContactType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.ContactType;
using EventType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.EventType;

namespace RequestHandler.Logic.Handler
{
    public class SendPasscodeHandler : CommandHandlerBase<SendPasscodeRequest, SendPasscodeResponse>
    {
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();

        private readonly IAccountService _accountService;
        private readonly IPriorityNotificationService _priorityNotificationService;
        //private readonly IValidateIdentifier _validateIdentifier;
        private readonly ILockService _lockService;
        private readonly ITokenizerService _tokenizerService;
        private readonly INotificationService _notificationService;
        private readonly IDeviceProvisioningMessageDataAccess _deviceProvisioningMessageDataAccess;
        private readonly IContactService _contactService;

        public SendPasscodeHandler(IAccountService accountService, ILockService lockService,
                                IPriorityNotificationService priorityNotificationService,
                                IDeviceProvisioningMessageDataAccess deviceProvisioningMessageDataAccess,
                                ITokenizerService tokenizerService,
                                INotificationService notificationService,
                                IContactService contactService)
        {
            _priorityNotificationService = priorityNotificationService;
            _accountService = accountService;
            _lockService = lockService;
            _tokenizerService = tokenizerService;
            _notificationService = notificationService;
            _deviceProvisioningMessageDataAccess = deviceProvisioningMessageDataAccess;
            _contactService = contactService;
        }

        /// <summary>
        /// TODO: need to write a Test case for this hanlder
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        /// <exception cref="RequestHandlerException"></exception>
        public override async Task<SendPasscodeResponse> Handle(SendPasscodeRequest request)
        {
            try
            {
                var tokenizedPan = _tokenizerService.TokenizePan(request.Pan);
                var consumerProfile = _accountService.GetAccountConsumerProfileByTokenizedPan(tokenizedPan);


                if (consumerProfile == null)
                {
                    _logger.Info($"No consumer profile found {request.RequestHeader.RequestId}.");
                    return new SendPasscodeResponse
                    {
                        TraceId = request.TraceId,
                        ResponseHeader = new ResponseHeader { ResponseId = request.RequestHeader.RequestId, Message = $"No consumer profile found {request.Pan}",StatusCode = 107 }
                        //throw new RequestHandlerException(0, 0, $"No consumer profile found {request.RequestHeader.RequestId}.");
                    };
                }
    
                string notificationChannel = null;
                OptionsContext.Current = OptionsContext.Current.Add("programCode", consumerProfile.ProgramCode);

                if (!consumerProfile.IsPrimaryAccountHolder)
                {
                    var links = _accountService.GetLinkedAccount(consumerProfile.AccountIdentifier.ToString());
                    _logger.Info($"find links for {consumerProfile.AccountIdentifier}, there are {links?.Count} records.");
                    if (links != null && links.Any(l => new Guid(l.LinkAccountIdentifier) == consumerProfile.AccountIdentifier))
                    {
                        var parentAccount = _accountService.GetAccount(links.FirstOrDefault().PrimaryAccountIdentifier);
                        var phoneNumber = _accountService.GetAccountPrimaryPhoneNumber(parentAccount.AccountIdentifier);
                        _logger.Info($"update the child's PhoneNumber of consumer profile {consumerProfile.PhoneNumber} to {phoneNumber}.");
                        consumerProfile.PhoneNumber = phoneNumber;
                    }
                }

                if (!string.IsNullOrWhiteSpace(consumerProfile?.PhoneNumber))
                {
                    notificationChannel = "1";
                    if (request.OtpMethodType == OtpMethodType.Voice)
                    {
                        SendVoiceVoice(request, consumerProfile);
                    }
                    else
                    {
                      
                        await SendCodeSms(request, consumerProfile);
                    }
                }            
                
                var provisionPnObject = new ProvisionPn()
                {
                    TransactionType = "tokenActivation",
                    Last4Pan = request.Pan?[^4..],
                    Bin = request.Pan?[..6],
                    TransactionStatus = "completed",
                    ActivationData = new ActivationData()
                    {
                        ActivationCode = request.PassCode,
                        ActivationCodeExpiry = request.ExpirationDateTime
                    },
                    PaymentInstrumentIdentifier = consumerProfile?.PaymentInstrumentIdentifier,
                    PaymentIdentifier = consumerProfile?.PaymentIdentifier?.ToString() ?? "",
                    AccountIdentifier = consumerProfile?.AccountIdentifier.ToString(),
                    TransactionIdentifier = Guid.NewGuid().ToString() 
                };
                
                provisionPnObject.UserIdentifier = consumerProfile.ConsumerProfileIdentifier;

                var pnObject = new List<ProvisionPn>()
                {
                    provisionPnObject
                };

                await _notificationService.PublishNotification(consumerProfile.ProgramCode, pnObject, EventType.Provisioning, consumerProfile.AccountIdentifier.ToString(), request.RequestHeader.RequestId.ToString());

                var response = new SendPasscodeResponse
                {
                    TraceId = request.TraceId,
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        Message = "Success"
                    }
                };

                // insert into db
                await InsertDeviceProvisioningMessage(request, consumerProfile, notificationChannel);

                return response;
            }
            catch (Exception ex)
            {
                return ex.HandleException<SendPasscodeResponse>(ex, request);
            }
        }

        private async Task InsertDeviceProvisioningMessage(SendPasscodeRequest message, AccountPrimaryConsumerProfile consumerProfile, string notificationChannel)
        {
            try
            {
                await _deviceProvisioningMessageDataAccess.InsertDeviceProvisioningMessage(message, consumerProfile.PaymentIdentifierProxy, notificationChannel);
            }
            catch (Exception ex)
            {
                //This call should not obstruct the completion of the over all request, therefore, logging, and continuing.
                _logger.Warn($"[{nameof(SendPasscodeHandler)}{nameof(InsertDeviceProvisioningMessage)}] [Request ID: {message?.RequestHeader?.RequestId}] Recieved an error while attempting to create provisioning log entry. The request was not impacted. Exception: {ex}");
            }
        }

        public override void SetDomainContext(SendPasscodeRequest request)
        {
            //throw new NotImplementedException();
        }

        public override async Task<SendPasscodeResponse> VerifyIdentifiers(SendPasscodeRequest request)
        {
            return new SendPasscodeResponse { ResponseHeader = new ResponseHeader() };
        }

        public override async Task<SendPasscodeResponse> ObtainLock(SendPasscodeRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock("Device_" + request.TokenReferenceId);
                return new SendPasscodeResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<SendPasscodeResponse>(e, request);
            }
        }

        public override void ReleaseLock(SendPasscodeRequest request)
        {
            _lockService.ReleaseApiLock("Device_" + request.TokenReferenceId);
        }

        private async Task SendCodeSms(SendPasscodeRequest request, AccountPrimaryConsumerProfile consumerProfile)
        {
            var messageContacts = new List<MessageContact>();
            var notificationType = CnNotificationType.TwoFactorAuthentication;

            // we do only text messages for passcode OTP, or webhook
            messageContacts.Add(new MessageContact
            {
                ContactValue = consumerProfile.PhoneNumber,
                ChannelType = "1"
            });

           

            var messageAttributes = new List<MessageAttribute>
            {
                new MessageAttribute {Name = "FirstName", Value = consumerProfile.FirstName},
                new MessageAttribute {Name = "LastName", Value = consumerProfile.LastName},
                new MessageAttribute {Name = "Code", Value=request.PassCode},
                new MessageAttribute {Name = "ExpireDateTime", Value=request.ExpirationDateTime.ToShortDateString() }, //update nuget package, last step
            };

            SendCnMessageRequest cnRequest = new SendCnMessageRequest
            {
                RequestHeader = new RequestHeader { RequestId = request.RequestHeader.RequestId },
                AccountIdentifier = consumerProfile.AccountIdentifier.ToString(),
                NotificationType = (int)notificationType,
                ProgramCode = consumerProfile.ProgramCode,
                ProductCode = consumerProfile.ProductCode,
                Attributes = messageAttributes.ToArray(),
                Contacts = messageContacts.ToArray()
            };

            await _priorityNotificationService.PublishPriorityNotification(consumerProfile.ProgramCode, cnRequest);
        }

        private void SendVoiceVoice(SendPasscodeRequest request, AccountPrimaryConsumerProfile consumerProfile)
        {
            var generateCodeRequest = new GenerateContactVerificationRequest
            {
                AccountIdentifier = consumerProfile.AccountIdentifier.ToString(),
                CommunicationType = CommunicationType.VoiceCall,
                ProductCode = consumerProfile.ProductCode,
                ProgramCode = consumerProfile.ProgramCode,
                ContactType = ContactType.Phone,
                ContactHandle = consumerProfile.PhoneNumber,
                DeliveryMethod = VerificationEventType.EWalletOtp,
                Code = request.PassCode,
                RequestHeader = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.RequestHeader
                {
                    RequestId = request.RequestHeader.RequestId
                }
            };

            _contactService.GenerateContactVerification(generateCodeRequest);
        }
    }
}
