﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Interest;
using Gd.Bos.RequestHandler.Core.Domain.Services.InterestRate;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class DeleteInterestRateTierHandler : CommandHandlerBase<DeleteInterestRateTierRequest, DeleteInterestRateTierResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IInterestRateService _interestRateService;

        public DeleteInterestRateTierHandler(IValidateIdentifier validateIdentifier,
            IInterestRateService interestRateService)
        {
            _validateIdentifier = validateIdentifier;
            _interestRateService = interestRateService;
        }

        public override void SetDomainContext(DeleteInterestRateTierRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<DeleteInterestRateTierResponse> VerifyIdentifiers(DeleteInterestRateTierRequest request)
        {
            _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
            _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 5, 105);
            return Task.FromResult(new DeleteInterestRateTierResponse { ResponseHeader = new ResponseHeader() });
        }

        public override Task<DeleteInterestRateTierResponse> Handle(DeleteInterestRateTierRequest request)
        {
            var tier = new AccountBalanceInterest
            {
                AccountBalanceInterestIdentifier = Guid.Parse(request.InterestRateTierIdentifier)
            };

            tier = _interestRateService.Update(
                ProgramCode.FromString(request.ProgramCode),
                AccountIdentifier.FromString(request.AccountIdentifier),
                AccountBalanceIdentifier.FromString(request.PurseIdentifier),
                tier,
                false,
                false
            );

            return Task.FromResult(new DeleteInterestRateTierResponse
            {
                InterestRateTierIdentifier = tier.AccountBalanceInterestIdentifier.ToString(),
                InterestYieldStartDate = tier.InterestYieldStartDate.Value.ToString("yyyy-MM-dd"),
                InterestYieldEndDate = tier.InterestYieldEndDate?.ToString("yyyy-MM-dd"),
                APY = tier.APY.ToString(),
                IsActive = tier.IsActive,
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                }
            });
        }
    }
}