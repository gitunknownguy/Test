﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment.Exceptions;
using Gd.Bos.RequestHandler.Core.Domain.Services.Dcpp;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Caching.Contract;
using RequestHandler.Core.Application;
using RequestHandler.Core.Domain.Services;
using RequestHandler.Core.Domain.Services.Dcpp;
using RequestHandler.Core.Domain.Services.ProspectApi;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class OptOutAccountHandler : CommandHandlerBase<OptOutAccountRequest, OptOutAccountResponse>
    {
        private ISampleCardService _sampleCardService;

        public OptOutAccountHandler(ISampleCardService sampleCardService)
        {
            _sampleCardService = sampleCardService;
        }

        public override void SetDomainContext(OptOutAccountRequest request)
        {

        }

        public override Task<OptOutAccountResponse> Handle(OptOutAccountRequest request)
        {

            if (request.RequestHeader == null)
            {
                request.RequestHeader = new RequestHeader()
                {
                    RequestId = Guid.NewGuid()
                };
            }

            var response = new OptOutAccountResponse()
            {
                ResponseHeader = new ResponseHeader()
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                }
            };
            try
            {
                response = _sampleCardService.OptOutByProspectId(request);
                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<OptOutAccountResponse>(e, request));
            }
        }

        public override Task<OptOutAccountResponse> VerifyIdentifiers(OptOutAccountRequest request)
        {

            return Task.FromResult(new OptOutAccountResponse()
            {
                ResponseHeader = new ResponseHeader()
            });
        }
    }
}
