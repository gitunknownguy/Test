﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.ExternalCard;
using Gd.Bos.RequestHandler.Logic.Queue;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;

namespace Gd.Bos.RequestHandler.Logic.Handler
{

    public class GetExternalCardsHandler : CommandHandlerBase<GetExternalCardRequest, GetAllExternalCardResponse>
    {
        private readonly IExternalCardService _externalCardService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly int _maxCardsAllowed;

        public GetExternalCardsHandler(IExternalCardService externalCardService, IValidateIdentifier validateIdentifier, IRequestHandlerSettings settings)
        {
            _externalCardService = externalCardService;
            _validateIdentifier = validateIdentifier;
            _maxCardsAllowed = settings.MaxCardsAllowedPerAccount;
        }

        public override void SetDomainContext(GetExternalCardRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetAllExternalCardResponse> VerifyIdentifiers(GetExternalCardRequest request)
        {
            _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
            return Task.FromResult(new GetAllExternalCardResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<GetAllExternalCardResponse> Handle(GetExternalCardRequest request)
        {
            var externalCards = GetExternalCards(request);
            var response = new GetAllExternalCardResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                },
                ExternalCards = externalCards,
                MaxCardsAllowed = _maxCardsAllowed
            };
            return Task.FromResult(response);
        }

        private List<GetExternalCardResponse> GetExternalCards(GetExternalCardRequest request)
        {
            return _externalCardService.GetExternalCards(request.AccountIdentifier);
        }
    }
}
