﻿using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.Shared.Common.Cassandra.Contract;
using Cassandra.Mapping;
using Cassandra;
using NLog;
using Newtonsoft.Json;
using RequestHandler.Core.Domain.Model.PublishNotification;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Cosmos.Contract;
using System.Runtime.InteropServices;
using RequestHandler.Core.Utils;

namespace RequestHandler.Logic.Handler
{
    [ExcludeFromCodeCoverage(Justification = "Due to time constraint on migration we need to revisit")]
    public class GetPnEventsHandler : CommandHandlerBase<GetPnEventsRequest, GetPnEventsResponse>
    {
        private readonly ICassandraAccess _cassandraAccess;
        private readonly ILogger _logger;
        private readonly string[] _validPnStatuses = new[] { "failed", "succeeded" };
        private readonly ICosmosAccess _cosmosAccess;
        private readonly IRequestHandlerSettings _configurationProvider;

        public GetPnEventsHandler(ICassandraAccess cassandraAccess, ILogger logger, ICosmosAccess cosmosAccess, IRequestHandlerSettings configurationProvider)
        {
            _cassandraAccess = cassandraAccess;
            _logger = logger;
            _cosmosAccess = cosmosAccess;
            _configurationProvider = configurationProvider;
        }
        public override void SetDomainContext(GetPnEventsRequest request)
        {
        }

        public override Task<GetPnEventsResponse> VerifyIdentifiers(GetPnEventsRequest request)
        {
            return Task.FromResult(new GetPnEventsResponse { ResponseHeader = new ResponseHeader() });
        }

        public override async Task<GetPnEventsResponse> Handle(GetPnEventsRequest request)
        {
            Validate(request);
            var pnEvents = GetPns(request.ProgramCode, DateTime.Parse(request.StartDate).ToUniversalTime(),
                DateTime.Parse(request.EndDate).ToUniversalTime(), request.Statuses, request.EventTypes).Result;

            return new GetPnEventsResponse
            {
                PnEvents = pnEvents,
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = OptionsContext.Current.GetGuid("requestId", Guid.Empty)
                }
            };
        }

        private async Task<Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PnEvent[]> GetPns(string programCode, DateTime startDate, DateTime endDate, string[] statuses, string[] eventTypes)
        {
            var response = new List<Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PnEvent>();
            var eventDateBuckets = GetEventDateBuckets(startDate, endDate);

            foreach (var status in statuses)
                foreach(var eventDateBucket in eventDateBuckets)
                {
                var getPns =$"select * from pn.event_delivery_status_v3 " +
                    $"where event_status = '{status}' " +
                    $"AND program_code = '{programCode}' " +
                    $"AND event_date_bucket = '{eventDateBucket}' " +
                    $"AND event_type IN ('{string.Join("','", eventTypes)}') " +
                    $"AND event_date >= '{startDate:yyyy-MM-dd HH:mm:sszzz}' " +
                    $"AND event_date < '{endDate:yyyy-MM-dd HH:mm:sszzz}'";

                var rowSet = CosmosUtils.UseCosmos(_configurationProvider) ? _cosmosAccess.ExecuteStatementAsync(getPns).Result : _cassandraAccess.ExecuteStatementAsync(getPns).Result;
                while (!rowSet.IsFullyFetched)
                {
                    await rowSet.FetchMoreResultsAsync();
                }

                if (rowSet != default(RowSet))
                {
                    foreach (var row in rowSet)
                    {
                        var eventType = row.GetValue<string>("event_type");

                        var pnEvent = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PnEvent
                        {
                            EventIdentifier = row.GetValue<Guid>("event_id").ToString(),
                            AccountIdentifier = row.GetValue<Guid>("account_id").ToString(),
                            EventType = eventType,
                            EventStatus = status
                        };
                        if (string.Equals(eventType, EventType.Transaction.ToString(), StringComparison.CurrentCultureIgnoreCase))
                        {
                            var eventJson = JsonConvert.DeserializeObject<PnFields>(row.GetValue<string>("event_json"));
                            var transactionIdentifier = eventJson.PnAccounts[0].PnEvents[0].TransactionIdentifier[0].PnTransactionIdentifier;
                            pnEvent.TransactionIdentifier = transactionIdentifier;
                        }
                        response.Add(pnEvent);
                    }
                }

            }

            return response.ToArray();
        }

        private void Validate(GetPnEventsRequest request)
        {
            if (string.IsNullOrEmpty(request?.StartDate) || string.IsNullOrEmpty(request?.EndDate))
            {
                throw new Gd.Bos.RequestHandler.Core.Infrastructure.ValidationException(555, 5,
                    "Invalid request parameters. startDate, endDate cannot be empty.");
            }

            DateTime startDate;
            DateTime endDate;
            if (!DateTime.TryParse(request?.StartDate, out startDate) ||
                !DateTime.TryParse(request?.EndDate, out endDate))
            {
                throw new ValidationException(620, 5, "Invalid request parameters. startDate, endDate is invalid.");
            }

            if (startDate >= endDate || (endDate - startDate).Days > 365)
            {
                throw new ValidationException(555, 5, "Invalid request parameters. Date range invalid.");
            }

            if (request.Statuses != null && request.Statuses.Length > 0)
            {
                var sanitizedStatuses = new List<string>();
                foreach (var status in request.Statuses)
                {
                    if (_validPnStatuses.FirstOrDefault(s => s == status.ToLowerInvariant()) == null)
                    {
                        throw new ValidationException(630, 5,
                            $"Invalid request parameters. statuses invalid. possible values: {string.Join(", ", _validPnStatuses)}");
                    }

                    sanitizedStatuses.Add(status.ToLowerInvariant());
                }

                request.Statuses = sanitizedStatuses.ToArray();
            }
            else
            {
                request.Statuses = _validPnStatuses;
            }

            //TODO: allow only transaction type for now
            if (request.EventTypes != null && request.Statuses.Length > 0)
            {
                var sanitizedEventTypes = new List<string>();
                foreach (var eventType in request.EventTypes)
                {
                    if (EventType.Transaction.ToString().ToLowerInvariant() != eventType)
                    {
                        throw new ValidationException(630, 5,
                            $"Invalid request parameters. invalid eventTypes. possible values: transaction");
                    }
                }
            }
            else
            {
                request.EventTypes = new[] { "transaction" };
            }
        }
        private static List<string> GetEventDateBuckets(DateTime startDate, DateTime endDate)
        {
            var result = new List<string>();

            DateTime currentDate = startDate.Date;
            DateTime finalDate = endDate.Date;

            while (currentDate <= finalDate)
            {
                result.Add(currentDate.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));
                currentDate = currentDate.AddDays(1);
            }

            return result;
        }
    }
}
