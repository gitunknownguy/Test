﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Application.UpgradeAccount;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.Common.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using NLog;
using RequestHandler.Core.Domain.Enums;
using RequestHandler.Core.Domain.Model.Inventory;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    [ExcludeFromCodeCoverage(Justification = "Performance improvement")]
    public class CreatePaymentInstrumentHandler : CommandHandlerBase<CreatePaymentInstrumentRequest, CreatePaymentInstrumentResponse>
    {
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();
        private readonly IUpgradeAccountService _upgradeAccountService;
        private readonly IBaasConfiguration _baasConfiguration;

        public CreatePaymentInstrumentHandler(IPaymentInstrumentService paymentInstrumentService,
            IEnrollmentDataAccess enrollmentDataAccess,
            INotificationService notificationPublisher,
            IValidateIdentifier validateIdentifier,
            IWelcomeNotificationService welcomeNotificationService,
            IProductService productService,
            ILockService lockService,
            IAccountService accountService,
            IInstantIssueCardInventoryRepository instantIssueCardInventoryRepository,
            IUpgradeAccountService upgradeAccountService,
            IBaasConfiguration baasConfiguration,
            IProductRepository productRepository)
        {
            _paymentInstrumentService = paymentInstrumentService;
            _enrollmentDataAccess = enrollmentDataAccess;
            _notificationPublisher = notificationPublisher;
            _validateIdentifier = validateIdentifier;
            _welcomeNotificationService = welcomeNotificationService;
            _productService = productService;
            _lockService = lockService;
            _accountService = accountService;
            _instantIssueCardInventoryRepository = instantIssueCardInventoryRepository;
            _upgradeAccountService = upgradeAccountService;
            _baasConfiguration = baasConfiguration;
            _productRepository = productRepository;
        }

        public override void SetDomainContext(CreatePaymentInstrumentRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            if (!string.IsNullOrEmpty(request.UserIdentifier))
                DomainContext.Current.UserIdentifier = request.UserIdentifier;
        }

        public override Task<CreatePaymentInstrumentResponse> VerifyIdentifiers(CreatePaymentInstrumentRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidateConsumerProfileIdentifier(DomainContext.Current.AccountIdentifier, DomainContext.Current.UserIdentifier);
                _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 3, 105);
                return Task.FromResult(new CreatePaymentInstrumentResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CreatePaymentInstrumentResponse>(e, request));
            }
        }

        public override async Task<CreatePaymentInstrumentResponse> ObtainLock(CreatePaymentInstrumentRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock(DomainContext.Current.AccountIdentifier.ToString());
                return new CreatePaymentInstrumentResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<CreatePaymentInstrumentResponse>(e, request);
            }
        }

        public override async Task<CreatePaymentInstrumentResponse> Handle(CreatePaymentInstrumentRequest request)
        {
            try
            {
                CreatePaymentInstrumentResponse createPaymentInstrumentResponse = new CreatePaymentInstrumentResponse();
                Tuple<Core.Domain.Model.Payment.PaymentIdentifier, Core.Application.PrivateCardData> paymentInstrumentData;

                if (request?.UpgradeFlag == true)
                {
                    paymentInstrumentData = await _upgradeAccountService.UpgradeAccount(Guid.Parse(request.AccountIdentifier), Guid.Parse(request.UserIdentifier),
                        request.ProgramCode, request.RequestHeader.RequestId, request.ProductMaterialType, request.RequestPhysicalCardFlag);
                }
                else
                {
                    paymentInstrumentData = CreatePaymentInstrument(request);
                }

                if (paymentInstrumentData == null)
                    throw new RequestHandlerException(0, 404, "Account Holder Not Found");

                var paymentInstrument = paymentInstrumentData.Item1?.PaymentInstrument;
                if (paymentInstrument != null)
                {
                    Enum.TryParse(paymentInstrument.Status, out PaymentInstrumentStatus paymentInstrumentStatus);
                    createPaymentInstrumentResponse.PaymentInstrument = new PaymentInstrument
                    {
                        PaymentInstrumentIdentifier = paymentInstrument.PaymentInstrumentIdentifier?.ToString(),
                        PaymentInstrumentType = paymentInstrument.PaymentInstrumentType,
                        Status = paymentInstrumentStatus,
                        IsPinSet = paymentInstrument.PinSetDate.HasValue,
                        Last4Pan = paymentInstrument.Last4Pan,
                        ActivatedDateTime = paymentInstrument.ActivatedDateTime,
                        IssuedDateTime = paymentInstrument.IssuedDateTime
                    };
                }
                // This will require in the future when we setPin during the enrollment

                //createPaymentInstrumentResponse.PaymentInstrument.PrivateCardData = new Bos.Shared.Common.Core.CoreApi.Contract.Data.PrivateCardData();
                //createPaymentInstrumentResponse.PaymentInstrument.PrivateCardData.Pan = paymentIntrumentData?.Item2?.Pan;
                //createPaymentInstrumentResponse.PaymentInstrument.PrivateCardData.Cvv = paymentIntrumentData?.Item2?.Cvv;

                //createPaymentInstrumentResponse.PaymentInstrument.PrivateCardData.ExpirationDate = new CardExpirationDate();
                //createPaymentInstrumentResponse.PaymentInstrument.PrivateCardData.ExpirationDate.CardExpirationMonth = paymentIntrumentData?.Item2?.CardExpirationDate.CardExpirationMonth;
                //createPaymentInstrumentResponse.PaymentInstrument.PrivateCardData.ExpirationDate.CardExpirationyear = paymentIntrumentData?.Item2?.CardExpirationDate.CardExpirationYear;

                createPaymentInstrumentResponse.ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                };

                if (request?.UpgradeFlag != true)
                {
                    if (_accountService.IsJointAccount(request.AccountIdentifier))
                    {
                        return createPaymentInstrumentResponse;
                    }
                    var accountResp = _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(request.AccountIdentifier, request.ProgramCode, false);
                    // The call below returns a Task, but it's actually sync (as of 2025-04-02), it returns a Task.CompletedTask
                    _notificationPublisher.PublishNotification(request.ProgramCode, accountResp.Account, EventType.AccountUpdated);
                    if (accountResp.Account.Status == "normal")
                        _welcomeNotificationService.RaiseWelcomeNotification(request.ProgramCode, accountResp.Account.AccountIdentifier, request.RequestHeader.RequestId);
                    else if (_accountService.IsDeclinedAccount(accountResp.Account))
                        _welcomeNotificationService.RaiseUnwelcomeNotification(request.ProgramCode, accountResp.Account.AccountIdentifier, request.RequestHeader.RequestId);
                }

                return createPaymentInstrumentResponse;
            }
            catch (InvalidProductMaterialException e)
            {
                if (request?.UpgradeFlag == true)
                {
                    _upgradeAccountService.CreateCrmNoteAsync(request.RequestHeader.RequestId, request.AccountIdentifier, request.ProgramCode, AccountUpgradeStatus.Failed);
                }
                var response = new CreatePaymentInstrumentResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 4,
                        SubStatusCode = 312,
                        Message = e.Message
                    },
                };

                return response;
            }
            catch (Exception e)
            {
                if (request?.UpgradeFlag == true)
                {
                    _upgradeAccountService.CreateCrmNoteAsync(request.RequestHeader.RequestId, request.AccountIdentifier, request.ProgramCode, AccountUpgradeStatus.Failed);
                }

                var eResult = e.HandleException<CreatePaymentInstrumentResponse>(e, request);
                Logger.Info($"post paymentInstruments failure, prospectId:{DomainContext.Current.ProspectIdentifier},prospectType:{DomainContext.Current.ProspectType},statusCode:{eResult.ResponseHeader.StatusCode},subStatusCode:{eResult.ResponseHeader.SubStatusCode},statusMessage:{eResult.ResponseHeader.Message},statusDetails:{eResult.ResponseHeader.Details}");
                return eResult;
            }
        }

        public override void ReleaseLock(CreatePaymentInstrumentRequest request)
        {
            _lockService.ReleaseApiLock(DomainContext.Current.AccountIdentifier.ToString());
        }

        private static bool IsDeclinedEnrollment(Account account)
        {
            return account.Status == "locked" && string.Equals(account.AccountHolders.First().User.KycStateData.PendingKycGate, "none", StringComparison.OrdinalIgnoreCase);
        }

        private Tuple<Core.Domain.Model.Payment.PaymentIdentifier, Core.Application.PrivateCardData> CreatePaymentInstrument(CreatePaymentInstrumentRequest request)
        {
            //Check in Instant Issue Card Inventory to know if this enrollment applies to an Instant Issue
            var mappingIdentifier = _instantIssueCardInventoryRepository.GetInstantIssueCardInventoryByAccountIdentifier(new Guid(request.AccountIdentifier));
            
            if (!string.IsNullOrEmpty(mappingIdentifier) && !IsGbosRetailNPNRCard(request.AccountIdentifier))
            {
                var paymentInstrumentData = _paymentInstrumentService.CreatePaymentInstrumentForInstantIssue(request, mappingIdentifier);
                return paymentInstrumentData;
            }
            else
            {
                if (!string.IsNullOrEmpty(request.ProductMaterialType))
                {
                    if (!_productService.IsValidProductMaterialTypeForProductTier(request.ProgramCode, request.ProductMaterialType))
                        throw new InvalidProductMaterialException("Invalid Product Material type");
                }
                var paymentInstrumentData = _paymentInstrumentService.CreatePaymentInstrument(request.AccountIdentifier,
                    request.UserIdentifier, request.ProductMaterialType, request.ProgramCode,
                    request.RequestPhysicalCardFlag, request.RequestTempCardOnly);
                return paymentInstrumentData;
            }
        }

        private bool IsGbosRetailNPNRCard(string accountIdentifier)
        {
            var accountInfoByAccountIdentifier = _accountService.GetAccount(accountIdentifier);
            
            var allCachedProductTiers = _productRepository.GetAllCachedProductTiers();
            var productTierData = allCachedProductTiers.FirstOrDefault(n =>
                n.ProductTierKey == accountInfoByAccountIdentifier.ProductTierKey);

            if (productTierData == null)
                return false;

            return productTierData.ProductClassKey == (int)ProductClass.NPNR;
        }

        private readonly IPaymentInstrumentService _paymentInstrumentService;
        private readonly IEnrollmentDataAccess _enrollmentDataAccess;
        private readonly INotificationService _notificationPublisher;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IWelcomeNotificationService _welcomeNotificationService;
        private readonly IProductService _productService;
        private readonly ILockService _lockService;
        private readonly IAccountService _accountService;
        private readonly ICBSInstantIssueEnrollmentService _cbsInstantIssueEnrollmentService;
        private readonly IInstantIssueCardInventoryRepository _instantIssueCardInventoryRepository;
        private readonly IProductRepository _productRepository;
    }
}
