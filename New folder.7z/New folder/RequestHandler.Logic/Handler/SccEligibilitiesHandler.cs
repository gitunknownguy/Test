﻿using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class SccEligibilitiesHandler : CommandHandlerBase<SccEligibilitiesRequest, SccEligibilitiesResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IEligibilityCheckService _eligibilitiesService;

        public SccEligibilitiesHandler(IValidateIdentifier validateIdentifier, IEligibilityCheckService eligibilitiesService)
        {
            _validateIdentifier = validateIdentifier;
            _eligibilitiesService = eligibilitiesService;
        }
        public override void SetDomainContext(SccEligibilitiesRequest request)
        {
            if (!string.IsNullOrEmpty(request.UserIdentifier))
                DomainContext.Current.UserIdentifier = request.UserIdentifier;
        }

        public override Task<SccEligibilitiesResponse> VerifyIdentifiers(SccEligibilitiesRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.ProgramCode);
                return Task.FromResult(new SccEligibilitiesResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<SccEligibilitiesResponse>(e, request));
            }
        }

        public override Task<SccEligibilitiesResponse> Handle(SccEligibilitiesRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.UserIdentifier))
                    throw new AccountNotFoundException();

                var response = _eligibilitiesService.SccEligibilities(request.UserIdentifier, request.ProgramCode);
                response.ResponseHeader.ResponseId = request.RequestHeader.RequestId;

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<SccEligibilitiesResponse>(e, request));
            }
        }

    }
}