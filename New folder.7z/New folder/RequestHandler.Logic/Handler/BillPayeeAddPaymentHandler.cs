﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.BillPay;
using Gd.Bos.RequestHandler.Core.Domain.Services.BillPay.Mappers;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.RequestHandler.Core.Application;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class BillPayeeAddPaymentHandler : CommandHandlerBase<BillPayAddPaymentRequest, BillPayAddPaymentResponse>
    {
        private readonly IBillPayService _billPayService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ILimitTypeService _limitTypeService;

        public BillPayeeAddPaymentHandler(IBillPayService billPayService, IValidateIdentifier validateIdentifier, ILimitTypeService limitTypeService)
        {
            _billPayService = billPayService;
            _validateIdentifier = validateIdentifier;
            _limitTypeService = limitTypeService;
        }

        public override void SetDomainContext(BillPayAddPaymentRequest request)
        {
            if (!String.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<BillPayAddPaymentResponse> VerifyIdentifiers(BillPayAddPaymentRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 3, 105);
                return Task.FromResult(new BillPayAddPaymentResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<BillPayAddPaymentResponse>(e, request));
            }
        }

        public override Task<BillPayAddPaymentResponse> Handle(BillPayAddPaymentRequest request)
        {
            try
            {
                _limitTypeService.ValidateBillpayLimit(request.AccountIdentifier, request.Amount);
                var response = _billPayService.AddPayment(request.ToGssModel());

                if (response == null)
                    throw new RequestHandlerException(503, 0,
                        $"Unable to Add Payment for account {request.AccountIdentifier}");

                var coreResponse = response.ToCoreModel();
                coreResponse.ResponseHeader.ResponseId = request.RequestHeader.RequestId;

                return Task.FromResult(coreResponse);
            }
            catch (Exception ex)
            {
                return Task.FromResult(ex.HandleException<BillPayAddPaymentResponse>(ex, request));
            }
        }
    }
}
