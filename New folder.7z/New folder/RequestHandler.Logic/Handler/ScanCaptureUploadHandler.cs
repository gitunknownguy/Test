﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Response;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class ScanCaptureUploadHandler : CommandHandlerBase<ScanCaptureUploadRequest, ScanCaptureUploadResponse>
    {
        private readonly IVerificationService _verificationService;

        public ScanCaptureUploadHandler(IVerificationService verificationService)
        {
            _verificationService = verificationService;
        }

        public override void SetDomainContext(ScanCaptureUploadRequest request)
        { }

        public override Task<ScanCaptureUploadResponse> VerifyIdentifiers(ScanCaptureUploadRequest request)
        {
            try
            {
                return Task.FromResult(new ScanCaptureUploadResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<ScanCaptureUploadResponse>(e, request));
            }
        }

        public override Task<ScanCaptureUploadResponse> Handle(ScanCaptureUploadRequest request)
        {

            VerifyOnBoardRequest verifyOnBoardRequest = new VerifyOnBoardRequest()
            {
                IdentityInfo = new Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request.IdentityInfo()
                {
                    Channel = request.IdentityInfo.Channel,
                    Program = request.IdentityInfo.Program,
                },
                Document = new DocumentInfo()
                {
                    Image = request.Document.DocumentFrontImage,
                    BackImage = request.Document.DocumentBackImage,
                    CountryCode = request.Document.DocumentCountryCode,
                    DocumentType = request.Document.DocumentType,
                },
                RequestHeader = new Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request.RequestHeader()
                {
                    RequestId = request.RequestHeader.RequestId,
                },
                CustomData = new Dictionary<string, object>()
                {
                    {"ProductCode",request.ProductCode },
                    {"ProductName",request.ProductName }
                }
            };

            var onBoard = _verificationService.PostEnrollmentScanCaptureVerification(verifyOnBoardRequest);

            var ret = ConvertToScanCaptureUploadResponse(onBoard);
            return Task.FromResult(ret);
        }

        private ScanCaptureUploadResponse ConvertToScanCaptureUploadResponse(VerifyOnBoardResponse onBoard)
        {
            ScanCaptureUploadResponse ret = new ScanCaptureUploadResponse()
            {
                TransactionId = onBoard.TransactionId,
            };

            int code = 0;
            int subCode = 0;
            string message = "successful";

            if (onBoard.ResponseCode == "5000" && onBoard.DocumentCapture != null)
            {
                ret.DocumentCapture = new DocumentCapture()
                {
                    DocumentId = onBoard.DocumentCapture.DocumentId,
                    DOB = onBoard.DocumentCapture.DOB,
                    FirstName = onBoard.DocumentCapture.FirstName,
                    LastName = onBoard.DocumentCapture.LastName,
                    Address1 = onBoard.DocumentCapture.Address1,
                    Address2 = onBoard.DocumentCapture.Address2,
                    City = onBoard.DocumentCapture.City,
                    State = onBoard.DocumentCapture.State,
                    ZipCode = onBoard.DocumentCapture.ZipCode,
                    Country = onBoard.DocumentCapture.Country,
                    IssuanceState = onBoard.DocumentCapture.IssuanceState,
                    IssuanceDate = onBoard.DocumentCapture.IssuanceDate,
                    ExpirationDate = onBoard.DocumentCapture.ExpirationDate,
                    ConfidenceScore = onBoard.DocumentCapture.ConfidenceScore,
                    DocumentType = onBoard.DocumentCapture.DocumentType,
                    TemplateType = onBoard.DocumentCapture.TemplateType,
                };
            }
            else if (onBoard.Errors != null && onBoard.Errors.Any())
            {
                var error = onBoard.Errors.First();
                code = 1;
                switch (error.ErrorCode)
                {
                    case 4015:
                        subCode = 530;
                        message = "Invalid Front Image.";
                        break;
                    case 4016:
                        subCode = 531;
                        message = "Invalid Back Image.";
                        break;
                    case 4018:
                        subCode = 532;
                        message = "Invalid Country Code.";
                        break;
                    default:
                        subCode = error.ErrorCode;
                        message = error.ErrorDescription;
                        break;
                }
            }
            else
            {
                code = 1;
                if (onBoard.ResponseDetails.Any(r => r.ResponseDetailCode == "1039"))
                {
                    subCode = 533;
                    message = "Bad Image Detected - Retry.";
                }
                else if (onBoard.ResponseDetails.Any(r => r.ResponseDetailCode == "2031"))
                {
                    subCode = 534;
                    message = "Bad Image Detected - Invalid Image.";
                }
                else if (onBoard.ResponseDetails.Any(r => r.ResponseDetailCode == "2032"))
                {
                    subCode = 535;
                    message = "Onboarding Document Declined.";
                }
                else
                {
                    int.TryParse(onBoard.ResponseCode, out subCode);
                    message = onBoard.ResponseDescription;
                }
            }

            ret.ResponseHeader = new ResponseHeader()
            {
                StatusCode = code,
                SubStatusCode = subCode,
                Message = message
            };

            return ret;
        }
    }
}
