﻿using System;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Domain.Services.CPM;

namespace RequestHandler.Logic.Handler
{
    public class AuthorizePaymentHandler : CommandHandlerBase<AuthorizePaymentRequest, AuthorizePaymentResponse>
    {
        private readonly ICpmService _cpmService;
        public AuthorizePaymentHandler(ICpmService cpmService)
        {
            _cpmService = cpmService;
        }

        public override Task<AuthorizePaymentResponse> Handle(AuthorizePaymentRequest request)
        {
            try
            {
                var domainResponse = _cpmService.AuthorizePayment(new Gd.Bos.Dcpp.Contract.Message.AuthorizePaymentRequest(request));
                var response = new AuthorizePaymentResponse
                {
                    MessageType = domainResponse.MessageType,
                    PaymentInstrumentIdentifier = domainResponse.PaymentInstrumentIdentifier,
                    TransactionIdentifier = domainResponse.TransactionIdentifier,
                    SystemTraceNumber = domainResponse.SystemTraceNumber,
                    RetrievalReferenceNumber = domainResponse.RetrievalReferenceNumber,
                    TransactionAmount = domainResponse.TransactionAmount,
                    TransactionCurrency = domainResponse.TransactionCurrency,
                    ApprovalCode = domainResponse.ApprovalCode,
                    ActionCode = domainResponse.ActionCode,
                    AdditionalAmount = domainResponse.AdditionalAmount,
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = domainResponse.ResponseDetails.Code,
                        SubStatusCode = domainResponse.ResponseDetails.SubCode,
                        Message = domainResponse.ResponseDetails.Description,
                    },
                };
                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AuthorizePaymentResponse>(e, request));
            }
        }

        public override void SetDomainContext(AuthorizePaymentRequest request)
        {
        }

        public override Task<AuthorizePaymentResponse> VerifyIdentifiers(AuthorizePaymentRequest request)
        {
            return Task.FromResult(new AuthorizePaymentResponse() { ResponseHeader = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader() });
        }
    }
}
