﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;

namespace RequestHandler.Logic.Handler
{
    public class UpdateCreditLineSourceHandler : CommandHandlerBase<UpdateCreditLineSourceRequest, UpdateCreditLineSourceResponse>
    {
        private readonly IUserService _userService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IAccountService _accountService;

        public UpdateCreditLineSourceHandler(IAccountService accountService, IUserService userService, IValidateIdentifier validateIdentifier)
        {
            _accountService = accountService;
            _userService = userService;
            _validateIdentifier = validateIdentifier;
        }
        public override void SetDomainContext(UpdateCreditLineSourceRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<UpdateCreditLineSourceResponse> VerifyIdentifiers(UpdateCreditLineSourceRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new UpdateCreditLineSourceResponse() { ResponseHeader = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpdateCreditLineSourceResponse>(e, request));
            }
        }

        public override Task<UpdateCreditLineSourceResponse> Handle(UpdateCreditLineSourceRequest request)
        {
            UpdateCreditLineSourceResponse response = new UpdateCreditLineSourceResponse()
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                }
            };
            try
            {
                //no matter account is dda or scc, we just need to retrieve the user
                var account = _accountService.GetAccountByAccountIdentifier(request.AccountIdentifier);
                if (account == null)
                {
                    throw new ValidationException(10, 0, "Account Not Found");
                }
                var primaryUser = account.AccountHolders.FirstOrDefault(a => a.IsPrimary && a.ConsumerProfileTypeKey == 1);
                if (primaryUser == null)
                {
                    throw new ValidationException(10, 0, "User Not Found");
                }
                var primaryUserInfo = _userService.GetUser(account.AccountIdentifier, primaryUser.UserIdentifier).
                        FirstOrDefault(u => u.ConsumerProfileKey == primaryUser.ConsumerProfileKey);
                if (primaryUserInfo == null)
                {
                    throw new ValidationException(10, 0, "User Not Found");
                }
                var linkedAccounts = _accountService.GetLinkedAccount(request.AccountIdentifier);
                if (!linkedAccounts.Any(a => a.LinkAccountIdentifier.ToLower() == request.AccountIdentifier.ToLower()
                                             && a.AccountLinkType == AccountLinkType.SecureCreditCard))
                {
                    throw new ValidationException(101, 0, "SCC AccountIdentifier Required");
                }

                _userService.UpdateCreditLineSource(primaryUserInfo.ConsumerProfileKey, request.Expense, request.Income, request.ExpenseFrequency, request.IncomeFrequency);

                //GBOS-32194 return min/max credit line 
                var creditLineRange = _userService.GetCreditLineRange(primaryUserInfo.ConsumerProfileKey,
                    request.ProgramCode);
                if (creditLineRange != null)
                {
                    response.MinCreditLine = creditLineRange.MinCreditLine;
                    response.MaxCreditLine = creditLineRange.MaxCreditLine;
                }

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpdateCreditLineSourceResponse>(e, request));
            }
        }
    }
}
