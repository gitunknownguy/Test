﻿using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Model.User.PreInterventions;
using Gd.Bos.RequestHandler.Core.Domain.Services.Crypto;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Core.Infrastructure.DataAccesses;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Logic.Service;
using RequestHandler.Core.Application;
using RequestHandler.Core.Utils;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
namespace RequestHandler.Logic.Handler
{
    public class DeleteOwnerProfileHandler : CommandHandlerBase<DeleteOwnerProfileRequest, DeleteOwnerProfileResponse>
    {
        private readonly ISaveBusinessOwnerInfoService _saveBusinessOwnerInfoService;
        private readonly IValidateIdentifier _validateIdentifier;

        public DeleteOwnerProfileHandler(ISaveBusinessOwnerInfoService saveBusinessOwnerInfoService
            , IValidateIdentifier validateIdentifier)
        {
            _saveBusinessOwnerInfoService = saveBusinessOwnerInfoService;
            _validateIdentifier = validateIdentifier;

        }
        public override void SetDomainContext(DeleteOwnerProfileRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
            {
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            }
        }

        public override Task<DeleteOwnerProfileResponse> VerifyIdentifiers(DeleteOwnerProfileRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidatePartner_AccountIdProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new DeleteOwnerProfileResponse()
                {
                    ResponseHeader = new ResponseHeader()
                });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<DeleteOwnerProfileResponse>(e, request));
            }
        }
        public override Task<DeleteOwnerProfileResponse> Handle(DeleteOwnerProfileRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.AccountIdentifier))
                    throw new AccountNotFoundException();
                var response = _saveBusinessOwnerInfoService.DeleteBusinessOwnerInfo(request);
                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<DeleteOwnerProfileResponse>(e, request));
            }

        }
    }
}
