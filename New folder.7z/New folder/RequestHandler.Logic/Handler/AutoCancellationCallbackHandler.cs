﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers.Exceptions;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class AutoCancellationCallbackHandler : CommandHandlerBase<AutoCancellationCallbackRequest, AutoCancellationCallbackResponse>
    {
        private readonly ITransferService _transferService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ILockService _lockService;

        public AutoCancellationCallbackHandler(ITransferService transferService, IValidateIdentifier validateIdentifier, ILockService lockService)
        {
            _transferService = transferService;
            _validateIdentifier = validateIdentifier;
            _lockService = lockService;
        }

        public override void SetDomainContext(AutoCancellationCallbackRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            DomainContext.Current.TransferIdentifier = request.TransferIdentifier;
        }

        public override Task<AutoCancellationCallbackResponse> VerifyIdentifiers(AutoCancellationCallbackRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new AutoCancellationCallbackResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AutoCancellationCallbackResponse>(e, request));
            }
        }

        public override Task<AutoCancellationCallbackResponse> Handle(AutoCancellationCallbackRequest request)
        {
            try
            {
                var callbackType = new List<string> { "complete", "return", "cancel", "reverse" };

                if (!(callbackType.Contains(request.CallbackType?.ToLower())))
                {
                    throw new InvalidCallBackTypeException("Invalid callback type.");
                }

                if (request.RequestHeader.RequestId == Guid.Empty)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId,
                        $"{nameof(request)}.RequestHeader.RequestId must be specified");
                }

                if (string.IsNullOrEmpty(request.TransferIdentifier))
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier,
                        $"{nameof(request)}.transferIdentifier must be specified");
                }


                if (request.CallbackType.ToLower() == "return")
                {
                    throw new NotImplementedException();
                }

                if (request.CallbackType.ToLower() == "complete")
                {
                    _transferService.RetryTransfer(request.TransferIdentifier, request.AccountIdentifier, request.ProgramCode);
                }

                if (request.CallbackType.ToLower() == "cancel")
                {
                    _transferService.CancelTransfer(request.TransferIdentifier, request.AccountIdentifier, request.ProgramCode);
                }

                if (request.CallbackType.ToLower() == "reverse")
                {
                    _transferService.ReverseTransfer(request.TransferIdentifier, request.AccountIdentifier, request.ProgramCode);
                }

                var response = new AutoCancellationCallbackResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                };

                return Task.FromResult(response);

            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AutoCancellationCallbackResponse>(e, request));
            }
        }

        public override async Task<AutoCancellationCallbackResponse> ObtainLock(AutoCancellationCallbackRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock(DomainContext.Current.TransferIdentifier);
                return new AutoCancellationCallbackResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<AutoCancellationCallbackResponse>(e, request);
            }
        }

        public override void ReleaseLock(AutoCancellationCallbackRequest request)
        {
            _lockService.ReleaseApiLock(DomainContext.Current.TransferIdentifier);
        }
    }
}
