﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Amazon.Runtime.Internal.Util;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using PaymentInstrument = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PaymentInstrument;
using PrivateCardData = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PrivateCardData;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetPaymentInstrumentHandlerV2 : CommandHandlerBase<GetPaymentInstrumentRequestV2, GetPaymentInstrumentResponse>
    {
        private readonly Core.Domain.Services.Crypto.ICryptoService _cryptoService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IPaymentInstrumentService _paymentInstrumentService;
        private readonly IBaasConfiguration _baasConfiguration;
        private readonly IRequestHandlerSettings _configuration;

        public GetPaymentInstrumentHandlerV2(
            IPaymentInstrumentService paymentInstrumentService,
            Core.Domain.Services.Crypto.ICryptoService cryptoService,
            IValidateIdentifier validateIdentifier,
            IBaasConfiguration baasConfiguration,
            IRequestHandlerSettings requestHandlerSettings)
        {
            _paymentInstrumentService = paymentInstrumentService;
            _cryptoService = cryptoService;
            _validateIdentifier = validateIdentifier;
            _baasConfiguration = baasConfiguration;
            _configuration = requestHandlerSettings;
        }

        public override void SetDomainContext(GetPaymentInstrumentRequestV2 request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            if (!string.IsNullOrEmpty(request.PaymentInstrumentIdentifier))
                DomainContext.Current.PaymentInstrumentIdentifier = request.PaymentInstrumentIdentifier;
        }

        public override Task<GetPaymentInstrumentResponse> VerifyIdentifiers(GetPaymentInstrumentRequestV2 request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidatePaymentInstrumentIdentifier(DomainContext.Current.AccountIdentifier, DomainContext.Current.PaymentInstrumentIdentifier);
                return Task.FromResult(new GetPaymentInstrumentResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetPaymentInstrumentResponse>(e, request));
            }
        }

        public override Task<GetPaymentInstrumentResponse> Handle(GetPaymentInstrumentRequestV2 request)
        {
            try
            {
                GetPaymentInstrumentResponse getPaymentInstrumentResponse = new GetPaymentInstrumentResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    }
                };

                var paymentIdentifier =
                    GetPaymentIdentifier(request.AccountIdentifier, request.PaymentInstrumentIdentifier);

                var pi = paymentIdentifier.PaymentInstrument;

                var paymentInstrument = new PaymentInstrument
                {
                    PaymentIdentifier = paymentIdentifier.PaymentIdentifierIdentifier.ToString(),
                    PaymentInstrumentIdentifier = pi.PaymentInstrumentIdentifier.ToString(),
                    IsPinSet = pi.PinSetDate.HasValue,
                    ActivatedDateTime = pi.ActivatedDateTime,
                    IssuedDateTime = pi.IssuedDateTime,
                    Last4Pan = pi.Last4Pan,
                    PaymentInstrumentType = pi.PaymentInstrumentType,
                    EmbossedName = pi.EmbossedName,
                    CustomCardImageIdentifier = pi.CustomCardImageIdentifier,
                    Status = StatusMapper.GetPaymentInstrumentStatus(
                    (PaymentIdentifierStatus)paymentIdentifier.PaymentIdentifierStatusKey,
                    (PaymentInstrumentStatus)Enum.Parse(typeof(PaymentInstrumentStatus), pi.Status)),
                    PaymentInstrumentStatusReasons = StatusMapper.GetPaymentInstrumentStatusReasons(
                        (PaymentIdentifierStatus)paymentIdentifier.PaymentIdentifierStatusKey,
                        (PaymentInstrumentStatus)Enum.Parse(typeof(PaymentInstrumentStatus), pi.Status), pi.PaymentInstrumentStatusReason, paymentIdentifier.PaymentIdentifierStatusReason),
                    IsPrivateDataViewable = "true"
                };
                paymentInstrument.IsOverIssuedDaysLimit = _baasConfiguration.IsOverIssuedDaysLimit(request.ProgramCode, _configuration.ValidOverIssuedDaysLimitProgramCodeList, paymentInstrument);


                if (paymentInstrument.Status == PaymentInstrumentStatus.Blocked)
                    paymentInstrument.CardPausedDateTime = pi.ChangeDataTime;

                if (request.IncludePrivatePaymentInstrumentData)
                {
                    request.PciData = request.PciData == null || request.PciData?.Length == 0
                        ? new string[] { }
                        : request.PciData;
                    var errorResponse = SetPaymentInstrumentPrivateCardData(getPaymentInstrumentResponse,
                        paymentIdentifier, paymentInstrument, request.PciData, request.ProgramCode, request.RequestHeader.Source);
                    if (errorResponse != null)
                        return Task.FromResult(errorResponse);
                }

                getPaymentInstrumentResponse.PaymentInstrument = paymentInstrument;

                return Task.FromResult(getPaymentInstrumentResponse);

            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetPaymentInstrumentResponse>(e, request));
            }
        }

        private GetPaymentInstrumentResponse SetPaymentInstrumentPrivateCardData(GetPaymentInstrumentResponse response, PaymentIdentifier paymentIdentifier,
            PaymentInstrument paymentInstrument, string[] pciDataList, string programCode, string source)
        {
            var pi = paymentIdentifier.PaymentInstrument;

            if (paymentInstrument.PaymentInstrumentType == PaymentInstrumentType.Virtual)
            {
                if (IsValidVirtualCard(paymentInstrument, pi, programCode, source))
                {
                    paymentInstrument.PrivateCardData = new PrivateCardData();
                    SetPan(pciDataList, paymentInstrument, pi.Pan);
                    SetExpirationDate(pciDataList, paymentInstrument, pi.EncryptedExpirationDate);
                    if (_baasConfiguration.IsCvvViewable(programCode, pi.IssuedDateTime))
                    {
                        SetCvv(pciDataList, paymentInstrument, paymentIdentifier, pi);
                    }
                }
            }
            else if (paymentInstrument.IsPhysicalCard())
            {
                if (paymentIdentifier.IsTemp)
                {
                    paymentInstrument.IsPrivateDataViewable = "false";
                    return null;
                }
                var errorResponse = ValidatePartnerAccessToPhysicalPciData(pciDataList, programCode, response);
                if (errorResponse != null)
                    return errorResponse;

                paymentInstrument.PrivateCardData = new PrivateCardData();
                SetPan(pciDataList, paymentInstrument, pi.Pan);
                SetExpirationDate(pciDataList, paymentInstrument, pi.EncryptedExpirationDate);
                if (_baasConfiguration.IsPhysicalCvvViewable(programCode))
                {
                    SetCvv(pciDataList, paymentInstrument, paymentIdentifier, pi);
                }
            }

            return null;
        }

        private void SetPan(string[] pciDataList, PaymentInstrument paymentInstrument, string pan)
        {
            paymentInstrument.PrivateCardData.Pan =
                pciDataList.Any(s => s.Equals("pan", StringComparison.OrdinalIgnoreCase)) ? pan : string.Empty;
        }

        private void SetExpirationDate(string[] pciDataList, PaymentInstrument paymentInstrument, CardExpirationDate exp)
        {
            paymentInstrument.PrivateCardData.ExpirationDate =
                pciDataList.Any(s => s.Equals("exp", StringComparison.OrdinalIgnoreCase))
                    ? exp
                    : new CardExpirationDate();
        }

        private void SetCvv(string[] pciDataList, PaymentInstrument paymentInstrument, PaymentIdentifier paymentIdentifier,
            Core.Domain.Model.Payment.PaymentInstrument pi)
        {
            if (pciDataList.Any(s => s.Equals("cvv", StringComparison.OrdinalIgnoreCase)))
            {
                var cvvResponse = _cryptoService.GenerateCvv(
                    paymentIdentifier.AccountIdentifier,
                    pi.Pan,
                    pi?.EncryptedExpirationDate?.CardExpirationyear.Substring(2) +
                    pi.EncryptedExpirationDate?.CardExpirationMonth, pi.PaymentInstrumentType,
                    new Guid(paymentIdentifier.PaymentIdentifierIdentifier.ToString()), new Guid(paymentInstrument.PaymentInstrumentIdentifier));

                paymentInstrument.PrivateCardData.Cvv = cvvResponse.Cvv;
            }
            else
            {
                paymentInstrument.PrivateCardData.Cvv = string.Empty;
            }
        }

        private GetPaymentInstrumentResponse ValidatePartnerAccessToPhysicalPciData(string[] pciDataList, string programCode, GetPaymentInstrumentResponse response)
        {
            if (!_baasConfiguration.IsPhysicalPanViewable(programCode)
                && pciDataList.Any(s => s.Equals("pan", StringComparison.OrdinalIgnoreCase)))
            {
                response.ResponseHeader.StatusCode = 400;
                response.ResponseHeader.SubStatusCode = 365;
                response.ResponseHeader.Message = "Partner not configured for private Pan data.";

                return response;
            }

            if (!_baasConfiguration.IsPhysicalExpViewable(programCode)
                && pciDataList.Any(s => s.Equals("exp", StringComparison.OrdinalIgnoreCase)))
            {
                response.ResponseHeader.StatusCode = 400;
                response.ResponseHeader.SubStatusCode = 365;
                response.ResponseHeader.Message = "Partner not configured for private Expiration data.";

                return response;
            }

            if (!_baasConfiguration.IsPhysicalCvvViewable(programCode)
                && pciDataList.Any(s => s.Equals("cvv", StringComparison.OrdinalIgnoreCase)))
            {
                response.ResponseHeader.StatusCode = 400;
                response.ResponseHeader.SubStatusCode = 365;
                response.ResponseHeader.Message = "Partner not configured for private CVV data.";

                return response;
            }

            return null;
        }

        /// <summary>
        /// Partners have different logic for showing private card data for virtual cards. All partners except intuit require virtual cards to be activated, PIN set, and for
        /// IsPrivateDataViewable to be true. Intuit will allow private card data for virtual cards to be shown regardless of payment instrument status and pin being set.
        /// </summary>
        /// <param name="paymentInstrument"></param>
        /// <param name="pi"></param>
        /// <param name="programCode"></param>
        /// <returns></returns>
        private bool IsValidVirtualCard(PaymentInstrument paymentInstrument, Core.Domain.Model.Payment.PaymentInstrument pi, string programCode, string source)
        {
            // bypass business rules for internal services
            if (source != null && source.Contains("LegacyAccountUtility"))
                return true;

            if (_baasConfiguration.IsPrivateDataViewable(programCode, pi.IssuedDateTime)
                && pi.IssuedDateTime != null)
            {
                if (_baasConfiguration.IsPinSetNotRequired(programCode))
                    return true;

                if (paymentInstrument.Status == PaymentInstrumentStatus.Activated &&
                    _baasConfiguration.IsPinSetNeed(programCode, pi.PinSetDate.HasValue))
                    return true;
            }

            return false;
        }

        private PaymentIdentifier GetPaymentIdentifier(string accountIdentifier, string paymentInstrumentIdentifier)
        {
            var paymentIdentifier = _paymentInstrumentService.GetPaymentIdentifier(
                accountIdentifier,
                paymentInstrumentIdentifier);

            if (paymentIdentifier?.PaymentInstrument == null)
            {
                throw new PaymentInstrumentNotFoundException();
            }

            if (paymentIdentifier.AccountIdentifier != AccountIdentifier.FromString(accountIdentifier))
            {
                throw new AccountNotFoundException();
            }

            return paymentIdentifier;
        }

    }
}
