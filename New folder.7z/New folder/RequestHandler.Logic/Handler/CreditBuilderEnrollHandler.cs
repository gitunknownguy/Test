﻿using System;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using NLog;
using RequestHandler.Core.Application;

namespace RequestHandler.Logic.Handler
{
    public class CreditBuilderEnrollHandler : CommandHandlerBase<CreditBuilderEnrollRequest, CreditBuilderEnrollResponse>
    {
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ICreditBuilderEnrollService _creditBuilderEnrollService;

        public CreditBuilderEnrollHandler(IValidateIdentifier validateIdentifier, ICreditBuilderEnrollService creditBuilderEnrollService)
        {
            _validateIdentifier = validateIdentifier;
            _creditBuilderEnrollService = creditBuilderEnrollService;
        }

        public override void SetDomainContext(CreditBuilderEnrollRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            DomainContext.Current.ProgramCode = ProgramCode.FromString(request.ProgramCode);
        }

        public override Task<CreditBuilderEnrollResponse> VerifyIdentifiers(CreditBuilderEnrollRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 4, 105);

                return Task.FromResult(new CreditBuilderEnrollResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CreditBuilderEnrollResponse>(e, request));
            }
        }

        public override async Task<CreditBuilderEnrollResponse> Handle(CreditBuilderEnrollRequest request)
        {
            try
            {
                var response = await _creditBuilderEnrollService.Enroll(request).ConfigureAwait(false);
                return response;
            }
            catch (AccountValidationException ave)
            {
                var response = new CreditBuilderEnrollResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader?.RequestId ?? Guid.NewGuid(),
                        StatusCode = ave.Code,
                        SubStatusCode = ave.SubCode,
                        Message = ave.Message,
                        Details = ave.ToString()
                    },
                    Purses = Array.Empty<Purse>()
                };
                _logger.Error(ave, $"Failed to validate the CreditBuilderEnrollRequest. RequestId:{request.RequestHeader.RequestId}");
                return response;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"CreditBuilderEnrollHandler Throws Exception. RequestId:{request.RequestHeader.RequestId}");
                return ex.HandleException<CreditBuilderEnrollResponse>(ex, request);
            }
        }
    }
}
