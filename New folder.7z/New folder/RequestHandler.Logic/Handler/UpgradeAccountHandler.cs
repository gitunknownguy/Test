﻿using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Model.User.PreInterventions;
using Gd.Bos.RequestHandler.Core.Domain.Services.Crypto;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Core.Infrastructure.DataAccesses;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Logic.Service;
using RequestHandler.Core.Application;
using RequestHandler.Core.Utils;
using Account = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Account;
using AccountHolder = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.AccountHolder;
using CardExpirationDate = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.CardExpirationDate;
using KycStateData = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using RequestHandler.Core.Domain.Services.CNAPI.Messages.Request;
using RequestHandler.Core.Domain.Services.CNAPI;
using Newtonsoft.Json;
using System.ComponentModel;
using System.Globalization;
using System.Net;
using Gd.Bos.Fraud.Api.Common.Utility;
using Gd.Bos.Shared.Common.Caching;
using Gd.Bos.Shared.Common.Core.Common.Data;
using AccountStatus = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountStatus;
using Org.BouncyCastle.Asn1.Ocsp;
using RequestHandler.Core.Domain.Model.Upgrade;
using Gd.Bos.RequestHandler.Core.Application.UpgradeAccount;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using PrivateCardData = Gd.Bos.RequestHandler.Core.Application.PrivateCardData;
using PaymentInstrument = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PaymentInstrument;
using Gd.Bos.Shared.Common.UtilityCoreApi.Contract.Data;
using Gd.Bos.RequestHandler.Core.Domain.Model.ProgramFunding;
using ProgramInfo = Gd.Bos.Shared.Common.Core.Common.Data.ProgramInfo;
using RequestHandler.Core.Domain.Enums;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Response;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk;
using RequestHandler.Core.Domain.Model.Account;
using RequestHandler.Core.Domain.Model.UpgradeAccount;
using AccountHolderCure = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolderCure;
using NLog;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class UpgradeAccountHandler : CommandHandlerBase<UpgradeAccountRequest, UpgradeAccountResponse>
    {
        private readonly IRequestDataAccess _requestDataAccess;
        private readonly IEnrollmentDataAccess _enrollmentDataAccess;
        private readonly IUpgradeAccountService _upgradeAccountService;
        private readonly IAccountService _accountService;
        private readonly IAgreementDataAccess _agreementRepository;
        private readonly ILockService _lockService;
        private readonly IAddressIntervention _addressIntervention;
        private readonly IProductService _productService;
        private readonly IProgramRepository _programRepository;
        private readonly ITokenizerService _tokenizerService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IProductRepository _productRepository;
        private readonly IUserRepository _userRepository;
        private readonly IAccountRepository _accountRepository;
        private readonly IBaasConfiguration _baasConfiguration;
        private readonly IUserService _userService;
        private Guid? _existingRequestAccountIdentifier;
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        public UpgradeAccountHandler(IRequestDataAccess requestDataAccess,
            IEnrollmentDataAccess enrollmentDataAccess,
            IUpgradeAccountService upgradeAccountService,
            IAccountService accountService,
            IAgreementDataAccess agreementRepository,
            IAddressIntervention addressIntervention,
            ILockService lockService,
            IProductService productService,
            IProgramRepository programRepository,
            ITokenizerService tokenizerService,
            IValidateIdentifier validateIdentifier,
            IProductRepository productRepository,
            IUserRepository userRepository,
            IAccountRepository accountRepository,
            IBaasConfiguration baasConfiguration,
            IUserService userService
        )
        {
            _requestDataAccess = requestDataAccess;
            _enrollmentDataAccess = enrollmentDataAccess;
            _upgradeAccountService = upgradeAccountService;
            _accountService = accountService;
            _agreementRepository = agreementRepository;
            _lockService = lockService;
            _addressIntervention = addressIntervention;
            _productService = productService;
            _programRepository = programRepository;
            _tokenizerService = tokenizerService;
            _validateIdentifier = validateIdentifier;
            _productRepository = productRepository;
            _userRepository = userRepository;
            _accountRepository = accountRepository;
            _baasConfiguration = baasConfiguration;
            _userService= userService;
        }

        public override void SetDomainContext(UpgradeAccountRequest request)
        {
            DomainContext.Current.IgnoreMfa = request.RequestHeader?.IgnoreMfa;
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<UpgradeAccountResponse> VerifyIdentifiers(UpgradeAccountRequest request)
        {
            _validateIdentifier.ValidateProgramCode(request.AccountIdentifier, DomainContext.Current.ProgramCode);  //ValidateProgramCode
            _validateIdentifier.ValidateProduct(ProgramCode.FromString(request.ProgramCode),
                ProductCode.FromString(request.AccountCreationData.ProductCode));
            return Task.FromResult(new UpgradeAccountResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override async Task<UpgradeAccountResponse> ObtainLock(UpgradeAccountRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock(OptionsContext.Current.GetString("requestId"));
                await _lockService.ObtainApiLock(DomainContext.Current.AccountIdentifier.ToString());

                return new UpgradeAccountResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<UpgradeAccountResponse>(e, request);
            }
        }
        public override async Task<UpgradeAccountResponse> Handle(UpgradeAccountRequest request)
        {
            try
            {
                _upgradeAccountService.CreateCrmNoteAsync(request.RequestHeader.RequestId, request.AccountIdentifier, request.ProgramCode, AccountUpgradeStatus.Start);
                var upgradeRequest = new UpgradeAccountParams()
                {
                    AccountIdentifier = request.AccountIdentifier,
                    UserCreationData = request.UserCreationData,
                    AccountCreationData = request.AccountCreationData,
                    ProgramCode = request.ProgramCode,
                    OverrideAddressStandardization = request.OverrideAddressStandardization,
                    UpgradeAccountFlow = true,
                    RequestHeader = request.RequestHeader,
                    FraudData = request.FraudData,
                    RequestPhysicalCardFlag = request.RequestPhysicalCardFlag
                };
                var checkResponse = InfoCheck(request, upgradeRequest);
                if (checkResponse != null)
                {
                    _upgradeAccountService.CreateCrmNoteAsync(request.RequestHeader.RequestId, request.AccountIdentifier, request.ProgramCode, AccountUpgradeStatus.Failed);
                    return checkResponse;
                }

                var upgradeResponse = await _upgradeAccountService.Upgrade(upgradeRequest);
                var account = upgradeResponse.Item1;
                var paymentIdentifier = upgradeResponse.Item2;
                var accountBalance = upgradeResponse.Item3;
                var privateCardData = upgradeResponse.Item4;
                var responseData = GetResponseData(account, paymentIdentifier, accountBalance, privateCardData,
                    upgradeRequest.AccountInfo);
                responseData.ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                };
                return responseData;
            }
            catch (InvalidProductMaterialException e)
            {
                _upgradeAccountService.CreateCrmNoteAsync(request.RequestHeader.RequestId, request.AccountIdentifier, request.ProgramCode, AccountUpgradeStatus.Failed);
                var response = new UpgradeAccountResponse()
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 4,
                        SubStatusCode = 312,
                        Message = e.Message
                    },
                };
                return response;
            }
            catch (Exception e)
            {
                _upgradeAccountService.CreateCrmNoteAsync(request.RequestHeader.RequestId, request.AccountIdentifier, request.ProgramCode, AccountUpgradeStatus.Failed);
                return e.HandleException<UpgradeAccountResponse>(e, request);
            }
        }

        public override void ReleaseLock(UpgradeAccountRequest request)
        {
            _lockService.ReleaseApiLock(OptionsContext.Current.GetString("requestId"));
            _lockService.ReleaseApiLock(request.AccountIdentifier);
        }

        public UpgradeAccountResponse InfoCheck(UpgradeAccountRequest request, UpgradeAccountParams upgradeRequest)
        {
            if (request.AccountCreationData == null)
            {
                throw new ArgumentNullException("Upgrade: AccountCreationData");
            }
            if (request.UserCreationData?.IdentifyingData == null)
            {
                throw new ArgumentNullException("Upgrade: UserCreationData");
            }

            var accountIdentifier = request.AccountIdentifier;
            var accountInfo = _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(request.AccountIdentifier, request.ProgramCode, false);//get account

            //check region
            var denialResponse = DenyRestrictedRegionsEnrollment(request, accountInfo?.Account?.ProductTierKey);
            if (denialResponse != null)
                return denialResponse;

            //set & verify address
            var addresses = request.UserCreationData.ProfileData?.Addresses?.ToDomain();
            _addressIntervention.SetHomeAddressToDefault(addresses);
            _addressIntervention.ValidAddresses(addresses, false);

            //get accountInfo
            if (accountInfo?.Account?.AccountHolders?.FirstOrDefault() == null)
            {
                var response = _upgradeAccountService.GenerateResponse(request.RequestHeader.RequestId, 10, 0, "Account Not Found.");
                return response;
            }

            //check account health
            if (!accountInfo.Account.Status.Equals(AccountStatus.Normal.ToString(), StringComparison.InvariantCultureIgnoreCase))
            {
                var response = _upgradeAccountService.GenerateResponse(request.RequestHeader.RequestId, 4503, 0, "Account status is not healthy");
                return response;
            }

            //check productcode mapping
            if (request.AccountCreationData.ProductCode.Equals(accountInfo.Account.ProductCode, StringComparison.InvariantCultureIgnoreCase))
            {
                var response = _upgradeAccountService.GenerateResponse(request.RequestHeader.RequestId, 4506, 0, "Account already upgrade success");
                return response;
            }
            var isUpgradeProductMapping = _upgradeAccountService.IsUpgradeProductMatching(request.ProgramCode, accountInfo.Account.ProductCode, request.AccountCreationData.ProductCode);
            if (!isUpgradeProductMapping)
            {
                var response = _upgradeAccountService.GenerateResponse(request.RequestHeader.RequestId, 4504, 0, "Target productCode not matched");
                return response;
            }

            //check card created within 10 days
            var latestCardInfo = accountInfo.Account.AccountHolders.FirstOrDefault().PaymentInstruments?.OrderByDescending(x => x.IssuedDateTime)?.FirstOrDefault();
            if (latestCardInfo?.Status == PaymentInstrumentStatus.NotActivated && latestCardInfo.IssuedDateTime.Value.AddDays(10) > DateTime.Now)
            {
                throw new ValidationException(4, 308, "Existing not activated card within 10 days.");
            }

            //check agreement
            var agreement = _agreementRepository.GetAgreementsByProductCode(request.AccountCreationData.ProductCode);   //GetAllProductAgreements
            var termsResponse = IsTermAgreementAcceptedAsync(agreement, request.AccountCreationData.TermsAcceptances,
                request.AccountCreationData.ProductCode, request.RequestHeader.RequestId, request.ProgramCode);
            if (!termsResponse.Item1)
                return new UpgradeAccountResponse() { ResponseHeader = termsResponse.Item2 };

            var terms = request.AccountCreationData.TermsAcceptances?.ToDomain(agreement);

            var programCode = request.ProgramCode;
            var productCode = request.AccountCreationData.ProductCode;
            var productMaterialType = request.AccountCreationData.ProductMaterialType;

            //check productMaterialType
            var prgInfo = _upgradeAccountService.GetProductTierByProgramCode(programCode);
            if (!string.IsNullOrEmpty(productMaterialType))
            {
                if (!prgInfo.ProductmaterialTypes.Exists(a => a.ProductMaterialType == productMaterialType))
                {
                    var response = _upgradeAccountService.GenerateResponse(request.RequestHeader.RequestId, 4, 312, "Invalid Product Material type");
                    return response;
                }
            }
            else if (string.IsNullOrEmpty(productMaterialType))
            {
                request.AccountCreationData.ProductMaterialType = GetDefaultProductMaterialType(prgInfo, programCode, productCode);
            }

            var account = _accountService.GetAccountByAccountIdentifier(request.AccountIdentifier);

            //User profile check
            UserProfileCheck(request, account);

            //initial upgradeRequest
            upgradeRequest.UserIdentifyingData = request.UserCreationData?.IdentifyingData?.ToDomain(false);   //check age 
            upgradeRequest.Account = account;
            upgradeRequest.AccountInfo = accountInfo;  //with source productcode info
            upgradeRequest.SourceProductCode = accountInfo.Account.ProductCode;
            upgradeRequest.TargetProductCode = request.AccountCreationData.ProductCode;
            upgradeRequest.TargetProductName = _productRepository.GetNameByProductCode(ProductCode.FromString(upgradeRequest.TargetProductCode), ProgramCode.FromString(programCode));
            upgradeRequest.TargetProductTierKey = GetProductTierKeyByProductCode(request.AccountCreationData.ProductMaterialType, upgradeRequest.TargetProductCode, programCode, request.RequestPhysicalCardFlag);
            upgradeRequest.SourceProductTierKey = GetProductTierKeyByAccountIdentifier(request.AccountIdentifier);

            //get history table data
            var accountUpgradeHistory = _upgradeAccountService.GetLatestAccountUpgradeHistory(request.AccountIdentifier);

            //insert/get request
            _existingRequestAccountIdentifier = _requestDataAccess.InsertRequestId(RequestType.Upgrade,
                request.RequestHeader.RequestId, Guid.Parse(accountIdentifier));
            if (!string.IsNullOrEmpty(_existingRequestAccountIdentifier.ToString())
                && !accountIdentifier.Equals(_existingRequestAccountIdentifier.ToString(), StringComparison.InvariantCultureIgnoreCase))
            {
                var response = _upgradeAccountService.GenerateResponse(request.RequestHeader.RequestId, 4505, 0, "Account not matched");
                return response;
            }

            if (accountUpgradeHistory == null)
            {
                //insert start history (AccountLimit, OfacHardDecline, NegMatch, KycFailed)
                var newHistory = new AccountUpgradeHistory()
                {
                    SourceProductCode = upgradeRequest.SourceProductCode,
                    TargetProductCode = upgradeRequest.TargetProductCode,
                    SourceProductTierKey = upgradeRequest.SourceProductTierKey,
                    TargetProductTierKey = upgradeRequest.TargetProductTierKey,
                    AccountUpgradeStatus = AccountUpgradeStatus.Start,
                    AccountUpgradeHistoryMsg = AccountUpgradeStatus.Start.ToString(),
                    CureKey = (int)AccountHolderCure.Unknown,
                    IsActive = true
                };

                var accountUpgradeHistoryKey = _upgradeAccountService.InsertAccountUpgradeHistory(newHistory, request.AccountIdentifier);
                upgradeRequest.AccountKey = upgradeRequest.Account.AccountKey;
                upgradeRequest.AccountUpgradeHistoryKey = accountUpgradeHistoryKey;
            }
            else
            {
                upgradeRequest.AccountKey = accountUpgradeHistory.AccountKey;
                upgradeRequest.AccountUpgradeHistoryKey = accountUpgradeHistory.AccountUpgradeHistoryKey;
                if (accountUpgradeHistory.AccountUpgradeStatus == AccountUpgradeStatus.Pending
                    && accountUpgradeHistory.CureKey != (int)AccountHolderCure.Healthy)
                {
                    upgradeRequest.UpgradeAccountFlow = false;
                }

                upgradeRequest.Account.UpgradeKycStateData = new Core.Domain.Model.Account.KycStateData()
                {
                    KycPendingGate = ((AccountHolderCure)accountUpgradeHistory.CureKey).ToString()
                };
            }
            upgradeRequest.RequestJson = _upgradeAccountService.ConvertUpgradeRequestToJson(request);
            return null;
        }

        private void UserProfileCheck(UpgradeAccountRequest request, Core.Domain.Model.Account.Account account)
        {
            var domainAddresses = ConvertToDomainAddresses(request.UserCreationData.ProfileData.Addresses);
            var domainPhoneNumbers = ConvertToDomainPhoneNumbers(request.UserCreationData.PhoneNumbers);
            if (request.OverrideAddressStandardization)
            {
                domainAddresses = _upgradeAccountService.GetStandardizedAddresses(domainAddresses, AccountIdentifier.FromString(request.AccountIdentifier));
            }
            var userProfiles = _userRepository.GetUser(AccountIdentifier.FromString(request.AccountIdentifier), null);
            var userProfile = userProfiles?.FirstOrDefault();
            if (userProfile == null)
            {
                throw new RequestHandlerException(10, 0, "User Not Found.");
            }
            var isDobVerified = (request.UserCreationData.ProfileData.IsDobVerified ?? false) || (userProfile.IsDobVerified ?? false);
            var userIdentifier = userProfile.UserIdentifier?.ToString();
            var isTransferAutoAccept = userProfile.IsTransferAutoAccept;

            var customerProfileKey = account.AccountHolders?.FirstOrDefault(c => c.UserIdentifier == userIdentifier)?.ConsumerProfileKey;
            if (account.AccountHolders?.Count == 0 || null == customerProfileKey)
                throw new ValidationException(10, 0, "AccountHolder Not Found");

            var updatedUserProfile = new Gd.Bos.RequestHandler.Core.Domain.Model.User.UserProfile
            {
                IsTransferAutoAccept = isTransferAutoAccept,
                Addresses = domainAddresses,
                PhoneNumbers = domainPhoneNumbers,
                Email =
                    new Gd.Bos.RequestHandler.Core.Domain.Model.User.Email(
                        request.UserCreationData.Email.EmailAddress, false, true),
                DateOfBirth = request.UserCreationData.ProfileData.DateOfBirth,
                IsDobVerified = isDobVerified,
                ConsumerProfileExtensions = new List<ConsumerProfileExtensionV2>()
            };

            bool allowUpdateUserProfile = _baasConfiguration.AllowUpdateUserProfile(request.ProgramCode);
            if (allowUpdateUserProfile)
            {
                _userService.UpdateUserProfile(updatedUserProfile,
                    AccountIdentifier.FromString(request.AccountIdentifier), UserIdentifier.FromString(userIdentifier),
                    request.RequestHeader.RequestId);
            }
            else
            {
                var updateResult =
                    _userRepository.CheckChanged(updatedUserProfile, userIdentifier, request.AccountIdentifier);
                if (updateResult.Item1 || updateResult.Item2 || updateResult.Item3)
                {
                    Logger.Info(string.Format("User profile changed, address:{0}, phone:{1}, email:{2}",
                        updateResult.Item1, updateResult.Item2, updateResult.Item3));
                    throw new RequestHandlerException(4502, 0, "User profile can‘t changed");
                }
            }
        }

        private static List<Gd.Bos.RequestHandler.Core.Domain.Model.User.Address> ConvertToDomainAddresses(IEnumerable<Shared.Common.Core.CoreApi.Contract.Data.Address> addresses)
        {
            return addresses.Select(address => new Gd.Bos.RequestHandler.Core.Domain.Model.User.Address
            {
                Country = "USA",
                State = address.State,
                AddressLine1 = address.AddressLine1,
                AddressLine2 = address.AddressLine2,
                City = address.City,
                Type = address.Type,
                ZipCode = address.ZipCode,
                IsDefault = address.IsDefault,
                IsVerified = false
            })
            .ToList();
        }

        private static List<Gd.Bos.RequestHandler.Core.Domain.Model.User.PhoneNumber> ConvertToDomainPhoneNumbers(IEnumerable<Shared.Common.Core.CoreApi.Contract.Data.PhoneNumber> phoneNumbers)
        {
            return phoneNumbers.Select(number => new Gd.Bos.RequestHandler.Core.Domain.Model.User.PhoneNumber
            {
                Number = number.Number,
                Type = number.Type,
                IsDefault = number.IsDefault,
                IsVerified = false
            }).ToList();
        }

        private int GetProductTierKeyByProductCode(string productMaterialType, string targetProductCode, string programCode, bool requestPhysicalCardFlag)
        {
            requestPhysicalCardFlag = requestPhysicalCardFlag || _baasConfiguration.IsPhysicalCardRequiredInUpgrade(programCode);
            var productTierInfo = _productService.GetProductTierByProductCodeMaterialType(targetProductCode, requestPhysicalCardFlag, productMaterialType);   //GetAllProductTiers
            if (productTierInfo == null)
            {
                throw new RequestHandlerException(602, 0, $"Current context: the product code is {targetProductCode}; the requestPhysicalCard flag is {requestPhysicalCardFlag}; the productMaterialType is {productMaterialType}. But cannot get a ProductTier by the product code and productMaterialType.");
            }
            return productTierInfo.ProductTierKey;
        }

        private int GetProductTierKeyByAccountIdentifier(string accountIdentifier)
        {
            var programFundingSource = _upgradeAccountService.GetProgramFundingSource(AccountIdentifier.FromString(accountIdentifier));   //GetProductInfoByAccountIdentifier
            return programFundingSource.ProductTierKey;
        }

        private UpgradeAccountResponse DenyRestrictedRegionsEnrollment(UpgradeAccountRequest request, int? productTierKey)
        {
            var (isGbosRetail, npnrProduct, emvProduct) = productTierKey == null ? (false, null, null) : _productRepository.IsGbosRetailProductTier(productTierKey.Value);

            var state = request?.UserCreationData?.ProfileData?.Addresses?.FirstOrDefault()?.State;
            if (isGbosRetail && _baasConfiguration.IsRetailPRAddressAllowed(request.ProgramCode))
            {
                if (state != null && state.Equals("GU", StringComparison.InvariantCultureIgnoreCase))
                {
                    return new UpgradeAccountResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 5,
                            SubStatusCode = 65,
                            Message = "This product may not be registered in the requested region"
                        }
                    };
                }
            }
            else
            {
                if (state != null && (state.Equals("PR", StringComparison.InvariantCultureIgnoreCase) ||
                                  state.Equals("GU", StringComparison.InvariantCultureIgnoreCase)))
                {
                    return new UpgradeAccountResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 5,
                            SubStatusCode = 65,
                            Message = "This product may not be registered in the requested region"
                        }
                    };
                }
            }

            return null;
        }

        private string GetDefaultProductMaterialType(ProgramInfo prgInfo, string programCode, string productCode)
        {
            var productMaterialType = string.Empty;
            var valueList = prgInfo.ProductTiers.Where(p => p.ProductCode.Equals(productCode, StringComparison.InvariantCultureIgnoreCase) && p.ProductTierAttribute == "CardStock" && p.IsDefault).ToList();

            var processor = _enrollmentDataAccess.GetProcessorByProductCode(productCode);
            var defaultProductMaterialTypeList = prgInfo.ProductmaterialTypes?.Where(pt => pt.ProcessorKey == (int)processor && pt.IsDefault);

            if (defaultProductMaterialTypeList != null)
            {
                foreach (var defaultProductMaterialType in defaultProductMaterialTypeList)
                {
                    if (valueList.Exists(v => v.Value.Equals(defaultProductMaterialType.ProcessorValue, StringComparison.InvariantCultureIgnoreCase)))
                    {
                        productMaterialType = defaultProductMaterialType.ProductMaterialType;
                        break;
                    }
                }
            }

            if (productMaterialType == null)
            {
                throw new InvalidProductMaterialException($"Can not find proper Product Material type for programCode {programCode}, productCode {productCode}");
            }

            return productMaterialType;
        }

        private Tuple<bool, ResponseHeader> IsTermAgreementAcceptedAsync(List<Agreement> agreementsDb, List<TermsAcceptance> termsAcceptances,
            string productCode, Guid requestId, string programCode, bool isSamplesEnroll = false)
        {
            if (termsAcceptances == null)
                termsAcceptances = new List<TermsAcceptance>();

            bool globalAcceptorPresent = false;
            string globalAcceptorDate = string.Empty;
            var gT = termsAcceptances.FirstOrDefault(x =>
                !string.IsNullOrEmpty(x.TermsIdentifier) && x.TermsIdentifier.Equals("termsAndConditions", StringComparison.CurrentCultureIgnoreCase));
            if (gT != null)
            {
                globalAcceptorPresent = true;
                globalAcceptorDate = string.IsNullOrEmpty(gT.TermsAcceptanceDateTime) ? DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffK") : gT.TermsAcceptanceDateTime;

                if (gT.TermsAcceptanceFlag == false)
                {
                    return new Tuple<bool, ResponseHeader>(false, new ResponseHeader
                    {
                        ResponseId = requestId,
                        Details = $"Required terms were not accepted. TermsIdentifier: {gT.TermsIdentifier} ",
                        Message = $"Required terms were not accepted.",
                        StatusCode = 2,
                        SubStatusCode = 55
                    });
                }
            }

            //Ignore extra terms which are not matching to terms in db. NOTE: remove this code when we will be doing true validations.
            var extraTerms = termsAcceptances.Where(ta => !agreementsDb.Any(a2 => a2.BrandAgreementTypeIdentifier.Equals(ta.TermsIdentifier, StringComparison.CurrentCultureIgnoreCase))
                                                          || string.IsNullOrEmpty(ta.TermsIdentifier)).ToList();
            foreach (var eta in extraTerms)
            {
                if (termsAcceptances.Contains(eta))
                    termsAcceptances.Remove(eta);
            }


            foreach (var a in agreementsDb)
            {
                if (a.IsRequired)
                {
                    var ta = termsAcceptances.FirstOrDefault(x => x.TermsIdentifier.Trim().Equals(a.BrandAgreementTypeIdentifier, StringComparison.CurrentCultureIgnoreCase));
                    if (ta == null)
                    {
                        if (globalAcceptorPresent) //if term not found in request but "globalAcceptor" is there then add term to request
                        {
                            ta = new TermsAcceptance
                            {
                                TermsIdentifier = a.BrandAgreementTypeIdentifier,
                                TermsAcceptanceFlag = true
                            };
                            termsAcceptances.Add(ta);
                        }
                        else if (!isSamplesEnroll) // if required term is not passed in request
                        {
                            return new Tuple<bool, ResponseHeader>(false, new ResponseHeader
                            {
                                ResponseId = requestId,
                                Details =
                                    $"Required terms were not accepted. BrandAgreementTypeIdentifier: {a.BrandAgreementTypeIdentifier} , " +
                                    $"BrandAgreementTypeName: {a.BrandAgreementTypeName}",
                                Message = $"Required terms were not accepted.",
                                StatusCode = 2,
                                SubStatusCode = 55
                            });
                        }
                        else
                            return new Tuple<bool, ResponseHeader>(true, null);
                    }

                    if (globalAcceptorPresent)//if globalAcceptorPresent then use its value for any required term
                        ta.TermsAcceptanceFlag = true;

                    if (ta.TermsAcceptanceFlag == false)
                    {
                        return new Tuple<bool, ResponseHeader>(false, new ResponseHeader
                        {
                            ResponseId = requestId,
                            Details = $"Required terms were not accepted. BrandAgreementTypeIdentifier: {a.BrandAgreementTypeIdentifier} , " +
                                        $"BrandAgreementTypeName: {a.BrandAgreementTypeName}",
                            Message = $"Required terms were not accepted.",
                            StatusCode = 2,
                            SubStatusCode = 55
                        });
                    }
                }
            }


            foreach (var ta in termsAcceptances)
            {
                if (string.IsNullOrEmpty(ta.TermsIdentifier))
                { continue; }
                ta.TermsIdentifier = ta.TermsIdentifier.Trim();

                if (globalAcceptorPresent && !string.IsNullOrEmpty(globalAcceptorDate))  // use globalAcceptorPresent date time for all terms
                    ta.TermsAcceptanceDateTime = globalAcceptorDate;

                var termsAcceptanceBuffer = _upgradeAccountService.GetTermsAcceptanceHoursBuffer(programCode);
                if (!string.IsNullOrEmpty(ta.TermsAcceptanceDateTime))
                {
                    // date string doesn't ends with Z or is not a valid format then throw error
                    if (!(ta.TermsAcceptanceDateTime.Trim().EndsWith("Z")) ||
                        !(DateTime.TryParseExact(ta.TermsAcceptanceDateTime.Trim(), "yyyy-MM-ddTHH:mm:ssK", CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal, out var taDate) ||
                        DateTime.TryParseExact(ta.TermsAcceptanceDateTime.Trim(), "yyyy-MM-ddTHH:mm:ss.fK", CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal, out taDate) ||
                        DateTime.TryParseExact(ta.TermsAcceptanceDateTime.Trim(), "yyyy-MM-ddTHH:mm:ss.ffK", CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal, out taDate) ||
                        DateTime.TryParseExact(ta.TermsAcceptanceDateTime.Trim(), "yyyy-MM-ddTHH:mm:ss.fffK", CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal, out taDate))
                        )
                    {
                        //_logger.Warn($"TermsAcceptanceDateTime: {ta.TermsAcceptanceDateTime} for TermsIdentifier: {ta.TermsIdentifier} is not a valid UTC date/time.");
                        return new Tuple<bool, ResponseHeader>(false, new ResponseHeader
                        {
                            ResponseId = requestId,
                            Details = $"TermsAcceptanceDateTime: {ta.TermsAcceptanceDateTime} for TermsIdentifier: {ta.TermsIdentifier} is not a valid UTC date/time.",
                            Message = $"TermsAcceptanceDateTime is not a valid UTC date/time.",
                            StatusCode = 720,
                        });
                    }

                    if (taDate > DateTime.UtcNow.AddHours(termsAcceptanceBuffer) || taDate < DateTime.UtcNow.AddHours(-termsAcceptanceBuffer))
                    {
                        return new Tuple<bool, ResponseHeader>(false, new ResponseHeader
                        {
                            ResponseId = requestId,
                            Details = $"TermsAcceptanceDateTime: {ta.TermsAcceptanceDateTime} for TermsIdentifier: {ta.TermsIdentifier} is either in the future or not a recent date.",
                            Message = $"The termsAcceptanceDateTime is either in the future or not a recent date.",
                            StatusCode = 620,
                        });
                    }
                }
            }

            return new Tuple<bool, ResponseHeader>(true, null);
        }
        private UpgradeAccountResponse GetResponseData(Gd.Bos.RequestHandler.Core.Domain.Model.Account.Account account, PaymentIdentifier paymentIdentifier,
            List<AccountBalance> accountBalances, PrivateCardData privateCardData, GetEnrollmentResponse accountResp)
        {

            var response = new UpgradeAccountResponse();
            response.AccountIdentifier = account.AccountIdentifier.ToString();
            response.CustomerReferenceNumber = account.CustomerAccountNumber;
            response.Status = account.AccountStatus.ToString().ToLower();


            DateTime accountStatusDateChange = account.AccountStatusChangedDateTime;
            accountStatusDateChange = accountStatusDateChange.ToUniversalTime();
            response.AccountStatusChangedDateTime =
                accountStatusDateChange.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");


            if (account.AccountStatusReasons?.Count > 0)
            {
                response.StatusReasons = new List<string>();

                foreach (Core.Domain.Model.Account.AccountStatusReason statusReason in account
                    .AccountStatusReasons)
                {
                    response.StatusReasons.Add(statusReason.ToString());
                }
            }

            response.DirectDepositInformation = new DirectDepositInformation
            {
                AccountNumber = account.AccountNumber,
                RoutingNumber = account.RoutingNumber
            };

            if (accountBalances != null)
            {
                response.Purses = new List<Purse>();
                foreach (var item in accountBalances)
                {
                    var purse = new Purse
                    {
                        PurseIdentifier = item.AccountBalanceIdentifier.ToString(),
                        PurseType = PurseType.Primary,
                        AvailableBalance = item.AvailableBalance,
                        LedgerBalance = item.CurrentBalance,
                        AvailableBalanceAsOfDateTime = item.AvailableBalanceAsOfDate,
                        LedgerBalanceAsOfDateTime = item.CurrentBalanceAsOfDate,
                        Status = item.Status
                    };
                    response.Purses.Add(purse);
                }
            }


            response.AccountHolders = new List<AccountHolder>();

            foreach (Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolder ah in account.AccountHolders)
            {
                var accountHolder = new AccountHolder();
                accountHolder.User = new Bos.Shared.Common.Core.CoreApi.Contract.Data.User
                {
                    UserIdentifier = accountResp?.Account?.AccountHolders[0]?.User?.UserIdentifier,
                    Status = UserStatus.Active,
                    IsPrimaryAccountHolder = true,
                    KycStateData = new KycStateData
                    {
                        OfacStatus = ah.kycStateData?.OfacStatus.ToString().ToLower(),
                        KycStatus = ah.kycStateData?.KycStatus.ToString().ToLower(),
                        PendingKycGate = ah.kycStateData?.KycPendingGate.ToLower()
                    }
                };


                if (paymentIdentifier != null)
                {
                    accountHolder.PaymentInstruments = new List<PaymentInstrument>();
                    var paymentInstrument = new PaymentInstrument();
                    //PaymentInstrumentStatus paymentInstrumentStatus;
                    Enum.TryParse(paymentIdentifier.PaymentInstrument.Status, out PaymentInstrumentStatus paymentInstrumentStatus);

                    paymentInstrument.PaymentIdentifier = paymentIdentifier.PaymentIdentifierIdentifier.ToString();
                    paymentInstrument.PaymentInstrumentIdentifier = paymentIdentifier?.PaymentInstrument
                        .PaymentInstrumentIdentifier.ToString();
                    paymentInstrument.PaymentInstrumentType =
                        paymentIdentifier.PaymentInstrument.PaymentInstrumentType;
                    paymentInstrument.Status = paymentInstrumentStatus;
                    paymentInstrument.IsPinSet = paymentIdentifier.PaymentInstrument.PinSetDate.HasValue;
                    paymentInstrument.Last4Pan = paymentIdentifier?.PaymentInstrument.Last4Pan;
                    paymentInstrument.ActivatedDateTime = paymentIdentifier?.PaymentInstrument.ActivatedDateTime;
                    paymentInstrument.IssuedDateTime = paymentIdentifier?.PaymentInstrument.IssuedDateTime;

                    if (privateCardData != null)
                    {
                        paymentInstrument.PrivateCardData =
                            new Bos.Shared.Common.Core.CoreApi.Contract.Data.PrivateCardData
                            {
                                Pan = privateCardData?.Pan,
                                Cvv = privateCardData?.Cvv,
                                ExpirationDate = new CardExpirationDate
                                {
                                    CardExpirationMonth = privateCardData?.CardExpirationDate.CardExpirationMonth,
                                    CardExpirationyear = privateCardData?.CardExpirationDate.CardExpirationYear
                                }
                            };

                        if (paymentInstrument.PaymentInstrumentType == PaymentInstrumentType.Virtual)
                            paymentInstrument.IsPrivateDataViewable = "true";
                    }

                    accountHolder.PaymentInstruments.Add(paymentInstrument);
                }

                response.AccountHolders.Add(accountHolder);
            }
            response.UpgradeKycStateData = new KycStateData()
            {
                OfacStatus = account?.UpgradeKycStateData?.OfacStatus.ToString().ToLower(),
                KycStatus = account?.UpgradeKycStateData?.KycStatus.ToString().ToLower(),
                PendingKycGate = account?.UpgradeKycStateData?.KycPendingGate.ToLower()
            };
            response.AccountCycleDay = accountResp.Account.AccountCycleDay;
            return response;
        }
    }
}
