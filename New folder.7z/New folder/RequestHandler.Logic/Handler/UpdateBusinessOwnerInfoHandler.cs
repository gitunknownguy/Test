﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;

namespace RequestHandler.Logic.Handler
{
    public class UpdateBusinessOwnerInfoHandler : CommandHandlerBase<UpdateOwnerProfileRequest, UpdateOwnerProfileResponse>
    {
        private readonly ISaveBusinessOwnerInfoService _saveBusinessOwnerInfoService;
        private readonly IValidateIdentifier _validateIdentifier;

        public UpdateBusinessOwnerInfoHandler(ISaveBusinessOwnerInfoService saveBusinessOwnerInfoService
       , IValidateIdentifier validateIdentifier)
        {
            _saveBusinessOwnerInfoService = saveBusinessOwnerInfoService;
            _validateIdentifier = validateIdentifier;

        }
        public override void SetDomainContext(UpdateOwnerProfileRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
            {
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            }
        }

        public override Task<UpdateOwnerProfileResponse> VerifyIdentifiers(UpdateOwnerProfileRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidatePartner_AccountIdProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new UpdateOwnerProfileResponse()
                {
                    ResponseHeader = new ResponseHeader()
                });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpdateOwnerProfileResponse>(e, request));
            }
        }
        public override Task<UpdateOwnerProfileResponse> Handle(UpdateOwnerProfileRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.AccountIdentifier))
                    throw new AccountNotFoundException();
                var updateOwnerProfileRequest = new UpdateOwnerProfileRequest()
                {
                    AccountIdentifier = request.AccountIdentifier,
                    ProgramCode = request.ProgramCode,
                    RequestHeader = request.RequestHeader,
                    OwnerProfileData = new OwnerProfileData()
                    {
                        OwnerIdentifier = request.OwnerProfileData.OwnerIdentifier,
                        IsVerified = request.OwnerProfileData.IsVerified,
                        IsConfirmedIndividual = request.OwnerProfileData.IsConfirmedIndividual,
                        FirstName = request.OwnerProfileData.FirstName,
                        MiddleName = request.OwnerProfileData.MiddleName,
                        LastName = request.OwnerProfileData.LastName,
                        AddressLineOne = request.OwnerProfileData.AddressLineOne,
                        AddressLineTwo = request.OwnerProfileData.AddressLineTwo,
                        State = request.OwnerProfileData.State,
                        City = request.OwnerProfileData.City,
                        SSN = request.OwnerProfileData.SSN,
                        DOB = request.OwnerProfileData.DOB,
                        Zip = request.OwnerProfileData.Zip
                    }
                };

                var response = _saveBusinessOwnerInfoService.UpdateBusinessOwnerInfo(updateOwnerProfileRequest);
                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpdateOwnerProfileResponse>(e, request));
            }

        }
    }
}
