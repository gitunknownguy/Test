﻿//using System;
//using Gd.Bos.Shared.Common.Core.Contract.Interface;
//using Gd.Bos.Shared.Common.Core.Contract.Request;
//using Gd.Bos.Shared.Common.Core.Contract.Response;
//using Gd.Bos.RequestHandler.Logic.Extension;

//namespace Gd.Bos.RequestHandler.Logic.Handler
//{
//    public class PingEchoHandler : IHandler<PingEchoResponse, PingEchoRequest>
//    {
//        PingEchoResponse IHandler<PingEchoResponse>.Handle(BaseRequest request)
//        {
//            if (!(request is PingEchoRequest))
//                throw new InvalidOperationException();
//            return Handle((PingEchoRequest)request);
//        }

//        PingEchoResponse IHandler<PingEchoResponse, PingEchoRequest>.Handle(PingEchoRequest request)
//        {
//            return Handle(request);
//        }

//        public PingEchoResponse Handle(PingEchoRequest request)
//        {
//            var response = "200".GetResponse<PingEchoResponse>();
//            return response;
//        }
//    }
//}
