﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.InterestRate;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RequestHandler.Logic.Handler
{
    public class GetProductInterestTierMetaDataHandler : CommandHandlerBase<GetProductInterestTierMetaDataRequest, GetProductInterestTierMetaDataResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IInterestRateService _interestRateService;

        public GetProductInterestTierMetaDataHandler(IValidateIdentifier validateIdentifier,
             IInterestRateService interestRateService)
        {
            _validateIdentifier = validateIdentifier;
            _interestRateService = interestRateService;
        }

        public override void SetDomainContext(GetProductInterestTierMetaDataRequest request)
        {
        }

        public override Task<GetProductInterestTierMetaDataResponse> VerifyIdentifiers(GetProductInterestTierMetaDataRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetProductInterestTierMetaDataResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetProductInterestTierMetaDataResponse>(e, request));
            }

        }

        public override Task<GetProductInterestTierMetaDataResponse> Handle(GetProductInterestTierMetaDataRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.ProgramCode))
                    throw new ArgumentNullException($"ProgramCode: Program Code cannot be null or empty.");

                var response =
                    _interestRateService.GetProductInterestTierMetaData(request.ProgramCode, request.RequestHeader.RequestId);

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetProductInterestTierMetaDataResponse>(e, request));
            }
        }
    }
}
