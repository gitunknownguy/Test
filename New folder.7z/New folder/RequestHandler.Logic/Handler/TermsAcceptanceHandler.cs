﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CareCoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class TermsAcceptanceHandler : CommandHandlerBase<TermAcceptanceRequest, TermAcceptanceResponse>
    {
        private readonly IAccountService _accountService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ITermsAcceptanceService _termAcceptanceService;
        private readonly IBaasConfiguration _baasConfiguration;

        public TermsAcceptanceHandler(ITermsAcceptanceService termAcceptanceService,
            IAccountService accountService,
            IValidateIdentifier validateIdentifier,
            IBaasConfiguration baasConfiguration)
        {
            _termAcceptanceService = termAcceptanceService;
            _accountService = accountService;
            _validateIdentifier = validateIdentifier;
            _baasConfiguration = baasConfiguration;
        }

        public override void SetDomainContext(TermAcceptanceRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<TermAcceptanceResponse> VerifyIdentifiers(TermAcceptanceRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new TermAcceptanceResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<TermAcceptanceResponse>(e, request));
            }
        }

        public override async Task<TermAcceptanceResponse> Handle(TermAcceptanceRequest request)
        {
            try
            {
                await _termAcceptanceService.UpdateTermAcceptances(request.AccountIdentifier, null, request.TermsAcceptances,
                    request.RequestHeader?.RequestId ?? Guid.NewGuid());
                if (request.PartnerAccountIdentifier != null)
                {
                    if (!_baasConfiguration.IsAccountTokenMaintenanceEnabled(request.ProgramCode))
                    {
                        throw new ValidationException(2, 5200, $"The Account token cannot be modified by policies.");
                    }
                    _accountService.UpdateAccountToken(request.AccountIdentifier, request.PartnerAccountIdentifier);
                }

                _termAcceptanceService.UpdateWinBackAccount(request.AccountIdentifier, request.ProgramCode,
                    request.RequestHeader?.RequestId ?? Guid.NewGuid(), request.Email, request.RequestHeader?.Source);

                if (request.ProgramCode?.ToUpper() == "GBR" && !string.IsNullOrEmpty(request.Email?.EmailAddress))
                    _termAcceptanceService.UpdateEmail(request.AccountIdentifier, request.Email);

                return new TermAcceptanceResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader?.RequestId ?? Guid.NewGuid(),
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    }
                };
            }
            catch (ValidationException e)
            {
                return new TermAcceptanceResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader?.RequestId ?? Guid.NewGuid(),
                        StatusCode = e.Code,
                        SubStatusCode = e.SubCode,
                        Message = e.Message
                    }
                };
            }
            catch (Exception e)
            {
                return e.HandleException<TermAcceptanceResponse>(e, request);
            }
        }
    }
}
