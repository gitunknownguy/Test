﻿using System;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using NLog;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class RestoreAccountHandler : CommandHandlerBase<RestoreAccountRequest, RestoreAccountResponse>
    {
        private readonly IRestoreAccountService _restoreAccountService;
        private ILogger _logger = LogManager.GetCurrentClassLogger();

        public RestoreAccountHandler(IRestoreAccountService restoreAccountService)
        {
            _restoreAccountService = restoreAccountService;
        }
        public override void SetDomainContext(RestoreAccountRequest request)
        {
            if (!string.IsNullOrEmpty(request?.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<RestoreAccountResponse> VerifyIdentifiers(RestoreAccountRequest request)
        {
            return Task.FromResult(new RestoreAccountResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<RestoreAccountResponse> Handle(RestoreAccountRequest request)
        {
            RestoreAccountResponse response;

            try
            {
                response = _restoreAccountService.RestoreAccount(request);
            }
            catch (Exception e)
            {
                response = e.HandleException<RestoreAccountResponse>(e, request);
            }

            return Task.FromResult(response);
        }
    }
}
