﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;

namespace RequestHandler.Logic.Handler
{
    public class GetPanByAccountIdentifiersHandler : CommandHandlerBase<GetPanByAccountIdentifiersRequest, GetPanByAccountIdentifiersResponse>
    {

        private readonly IPaymentIdentifierRepository _paymentIdentifierRepository;
        private readonly ITokenizerService _tokenizerService;
        public GetPanByAccountIdentifiersHandler(IPaymentIdentifierRepository paymentIdentifierRepository, ITokenizerService tokenizerService)
        {
            _paymentIdentifierRepository = paymentIdentifierRepository;
            _tokenizerService = tokenizerService;
        }
        public override void SetDomainContext(GetPanByAccountIdentifiersRequest request)
        {
            DomainContext.Current.ProgramCode = ProgramCode.FromString(request.ProgramCode);
        }
        public override Task<GetPanByAccountIdentifiersResponse> VerifyIdentifiers(GetPanByAccountIdentifiersRequest request)
        {
            return Task.FromResult(new GetPanByAccountIdentifiersResponse { ResponseHeader = new ResponseHeader() });
        }

        public override Task<GetPanByAccountIdentifiersResponse> Handle(GetPanByAccountIdentifiersRequest request)
        {

            var dbResult = _paymentIdentifierRepository.GetTokenizedPanExpirationDateByAccountIdentifiers(request.AccountIdentifiers);
            if (dbResult == null || dbResult.Count == 0)
            {
                return Task.FromResult(new GetPanByAccountIdentifiersResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId
                    },
                    AccountCardData = new List<AccountCardInfoLite>()
                });
            }


            var result = new List<AccountCardInfoLite>();

            foreach (PaymentInstrumentLite card in dbResult)
            {

                var item = new AccountCardInfoLite
                {
                    AccountIdentifier = card.AccountIdentifier,
                    ExpDate = card.ExpirationDate,
                    Pan = _tokenizerService.DeTokenizePan(card.TokenizedPan)
                };

                result.Add(item);
            }


            return Task.FromResult(new GetPanByAccountIdentifiersResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId
                },
                AccountCardData = result
            });
        }



    }

    public class GetPanByAccountIdentifiersRequest : BaseRequest
    {
        public List<string> AccountIdentifiers { get; set; }
    }

    public class GetPanByAccountIdentifiersResponse : BaseResponse
    {
        public List<AccountCardInfoLite> AccountCardData { get; set; }
    }

    public class AccountCardInfoLite
    {
        public string AccountIdentifier { get; set; }
        public string Pan { get; set; }
        public string ExpDate { get; set; }
    }
}