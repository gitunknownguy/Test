﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using RequestHandler.Core.Domain.Services.Overdraft;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetTermAcceptanceHistoryHandler : CommandHandlerBase<GetTermAcceptanceHistoryRequest, GetTermAcceptanceHistoryResponse>
    {
        private readonly IAccountDataAccess _accountDataAccess;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IOverdraftService _overdraftService;

        public GetTermAcceptanceHistoryHandler(IAccountDataAccess accountDataAccess, IValidateIdentifier validateIdentifier, IOverdraftService overdraftService)
        {
            _accountDataAccess = accountDataAccess;
            _validateIdentifier = validateIdentifier;
            _overdraftService = overdraftService;
        }

        public override void SetDomainContext(GetTermAcceptanceHistoryRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetTermAcceptanceHistoryResponse> VerifyIdentifiers(GetTermAcceptanceHistoryRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetTermAcceptanceHistoryResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetTermAcceptanceHistoryResponse>(e, request));
            }
        }

        public override async Task<GetTermAcceptanceHistoryResponse> Handle(GetTermAcceptanceHistoryRequest request)
        {
            GetTermAcceptanceHistoryResponse response = new GetTermAcceptanceHistoryResponse()
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                }
            };
            try
            {
                var accountResponse = _accountDataAccess.GetAccountByAccountIdentifier(request.AccountIdentifier, request.ProgramCode, false);

                if (accountResponse?.Account?.AccountHolders == null)
                {
                    throw new AccountNotFoundException();
                }

                if (request.IsOverdraftTerm)
                {
                    var historyItems = await _overdraftService.GetOverdraftTermAcceptanceHistoryList(
                        accountResponse.Account.AccountHolders?.Select(p => p.AccountHolderIdentifier), request.ProgramCode);
                    response.Data = historyItems;
                }
                else
                {
                    throw new NotImplementedException("Non-od TermAcceptanceHistory query is not implemented.");
                }

                return response;
            }
            catch (Exception e)
            {
                return e.HandleException<GetTermAcceptanceHistoryResponse>(e, request);
            }
        }
    }
}