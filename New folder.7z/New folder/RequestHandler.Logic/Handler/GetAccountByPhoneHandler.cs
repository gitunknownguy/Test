﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using System.Collections.Generic;
using Account = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Account;

namespace RequestHandler.Logic.Handler
{
    public class GetAccountByPhoneHandler : CommandHandlerBase<GetAccountByPhoneRequest, GetAccountByPhoneResponse>
    {
        private readonly IAccountRepository _accountRepository;

        public GetAccountByPhoneHandler(IAccountRepository accountRepository)
        {
            _accountRepository = accountRepository;
        }

        public override void SetDomainContext(GetAccountByPhoneRequest request)
        {
            DomainContext.Current.ProgramCode = ProgramCode.FromString(request.ProgramCode);
        }

        public override Task<GetAccountByPhoneResponse> VerifyIdentifiers(GetAccountByPhoneRequest request)
        {
            return Task.FromResult(new GetAccountByPhoneResponse { ResponseHeader = new ResponseHeader() });
        }

        public override Task<GetAccountByPhoneResponse> Handle(GetAccountByPhoneRequest request)
        {
            try
            {
                var lst = _accountRepository.GetAccountInfoByPhoneNumber(request.PhoneNumber);

                var accounts = lst.Where(x =>
                        x.Item1.Product.ProgramCode.Equals(ProgramCode.FromString(request.ProgramCode))
                        && x.Item1.AccountHolders.Any(a => a.IsPrimary)
                        && x.Item2.PhoneNumbers.Any(p => p.IsDefault)).Select(x => x.Item1)
                    .GroupBy(x => x.AccountIdentifier).Select(x => x.First()).ToList();

                if (!String.IsNullOrEmpty(request.ProductCode))
                {
                    accounts = accounts.Where(x =>
                        x.Product.ProductCode.Equals(ProductCode.FromString(request.ProductCode))).ToList();
                }

                var response = new GetAccountByPhoneResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                    Accounts = new List<Account>()
                };

                if (!accounts.Any())
                {
                    response.ResponseHeader.StatusCode = 10;
                    response.ResponseHeader.Message = "No accounts found.";
                    response.ResponseHeader.Details = "No accounts associated with phone number found.";
                    return Task.FromResult(response);
                }

                foreach (var account in accounts)
                    response.Accounts.Add(new Account
                    {
                        AccountIdentifier = account.AccountIdentifier.ToString()
                    });

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetAccountByPhoneResponse>(e, request));
            }
        }
    }
}
