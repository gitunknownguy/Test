﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment.Exceptions;
using Gd.Bos.RequestHandler.Core.Domain.Services.Dcpp;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using RequestHandler.Logic;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Logic.Exceptions;
using System.Linq;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request;
using NLog;
using System.Collections.Generic;
using Gd.Bos.Shared.Common.Core.CareCoreApi.Contract.Data.Enum;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using RequestHandler.Core.Domain.Services.CNAPI;
using RequestHandler.Core.Domain.Services.CNAPI.Messages.Request;
using Attribute = RequestHandler.Core.Domain.Services.CNAPI.Messages.Request.Attribute;

namespace RequestHandler.Logic.Handler
{
    public class CNAPITransferHandler : CommandHandlerBase<Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.CNAPITransferRequest, Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.CNAPITransferResponse>
    {
        private readonly ICNAPIService _cNAPIService;
        public CNAPITransferHandler(ICNAPIService cNAPIService)
        {
            _cNAPIService = cNAPIService;
        }
        public override void SetDomainContext(Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.CNAPITransferRequest request)
        {
        }

        public override Task<Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.CNAPITransferResponse> VerifyIdentifiers(Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.CNAPITransferRequest request)
        {
            try
            {
                return Task.FromResult(new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.CNAPITransferResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.CNAPITransferResponse>(e, request));
            }
        }

        public override Task<Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.CNAPITransferResponse> Handle(Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.CNAPITransferRequest request)
        {

            Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.CNAPITransferResponse response;
            try
            {
                var cnapiattributes = new List<Attribute>();
                if (request.Attributes != null)
                {
                    foreach (var attribute in request.Attributes)
                    {
                        cnapiattributes.Add(new Attribute()
                        {
                            Name = attribute.Name,
                            Value = attribute.Value
                        });
                    }
                }
                var cnapirequest = new RequestHandler.Core.Domain.Services.CNAPI.Messages.Request.CNAPITransferRequest()
                {
                    ProductCode = request.ProductCode,
                    ProgramCode = request.ProgramCode,
                    Attributes = cnapiattributes,
                    Header = new CNAPIRequestHeader() { RequestId = request.RequestHeader?.RequestId.ToString(), RequestOptions = request.RequestHeader?.Options }
                };

                var cnapiresponse = _cNAPIService.Transfer(cnapirequest);

                response = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.CNAPITransferResponse()
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                    Header = new CNAPIResponseHeader()
                    {
                        ResponseId = cnapiresponse.Header.ResponseId,
                        SubStatusCode = cnapiresponse.Header.SubStatusCode,
                        StatusCode = cnapiresponse.Header.StatusCode,
                        StatusMessage = cnapiresponse.Header.StatusMessage
                    }
                };
            }
            catch (Exception ex)
            {
                response = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.CNAPITransferResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = -1,
                        SubStatusCode = -1,
                        Message = "CNAPI transfer system error.",
                        Details = ex.Message
                    }
                };
            }

            return Task.FromResult(response);

        }

    }
}
