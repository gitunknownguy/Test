﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Service;
using ExternalAccountStatusDomainRequest = Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request.ExternalAccountStatusRequest;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class ExternalAccountStatusHandler : CommandHandlerBase<ExternalAccountStatusRequest, ExternalAccountStatusResponse>
    {
        private readonly IAccountDataAccess _accountDataAccess;
        private readonly IAccountStatusService _accountStatusService;
        private readonly IValidateIdentifier _validateIdentifier;
        public ExternalAccountStatusHandler(IAccountDataAccess accountDataAccess, IValidateIdentifier validateIdentifier, IAccountStatusService accountStatusService)
        {
            _validateIdentifier = validateIdentifier;
            _accountDataAccess = accountDataAccess;
            _accountStatusService = accountStatusService;
        }

        public override void SetDomainContext(ExternalAccountStatusRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<ExternalAccountStatusResponse> VerifyIdentifiers(ExternalAccountStatusRequest request)
        {
            _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
            _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 4, 105);

            return Task.FromResult(new ExternalAccountStatusResponse() { ResponseHeader = new ResponseHeader() });
        }

        private static string ReturnFraudReasonCode(string statusOrStatusReason)
        {
            return statusOrStatusReason switch
            {
                "locked/potentialfirstpartyfraud" => "PTR-PFP-L",
                "locked/confirmedfirstpartyfraud" => "PTR-CFP-L",
                "locked/potentialthirdpartyfraud" => "PTR-PTP-L",
                "locked/confirmedthirdpartyfraud" => "PTR-CTP-L",
                "locked/potentialaccounttakeover" => "PTR-PAT-L",
                "locked/confirmedaccounttakeover" => "PTR-CAT-L",
                "locked/potentialidentitytheft" => "PTR-PIT-L",
                "locked/confirmedidentitytheft" => "PTR-CIT-L",
                "locked/potentialotherfraud" => "PTR-POF-L",
                "locked/confirmedotherfraud" => "PTR-COF-L",
                //TODO: remove this temp old combinations
                "normal/healthy" => "PTR-HH",
                "restricted/potentialfraud" => "PTR-RP",
                "restricted/spenddown" => "PTR-RN",
                "locked/potentialfraud" => "PTR-LP",
                "locked/confirmedfraud" => "PTR-LN",
                _ => ""
            };
        }


        /// <summary>
        /// Handle
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public override Task<ExternalAccountStatusResponse> Handle(ExternalAccountStatusRequest request)
        {
            try
            {

                string statusAndReason = request.AccountStatus?.ToLower() + "/" + request?.AccountStatusReasons[0]?.ToLower();
                string returnReasonCode = ReturnFraudReasonCode(statusAndReason);

                if (string.IsNullOrEmpty(returnReasonCode))
                    throw new ArgumentException("Invalid status/statusReason combination, please review.", nameof(request));

                ExternalAccountStatusDomainRequest externalAccountStatusRequest = new ExternalAccountStatusDomainRequest();
                ExternalAccountStatusResponse responseData = new ExternalAccountStatusResponse();
                List<string> accountReason = new List<string>();

                externalAccountStatusRequest.DecisionCode = returnReasonCode;
                externalAccountStatusRequest.Source = request.Source;
                externalAccountStatusRequest.Cure = request.Cure;

                var response = _accountStatusService.SetPartnerAccountStatus(externalAccountStatusRequest, request?.AccountIdentifier, request.Notes, request.ProgramCode);

                var actualResponse = response?.Item1;
                var partnerStatusInfo = response.Item2;

                foreach (var reason in partnerStatusInfo.AccountStatusReasons)
                {
                    accountReason.Add(reason.ToString());
                }

                if (partnerStatusInfo.StatusCode != 0)
                {
                    responseData = new ExternalAccountStatusResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 5,
                            SubStatusCode = 420,
                            Message = "The status update was declined by RequestHandler."
                        },
                        AccountStatus = partnerStatusInfo.AccountStatus.ToString(),
                        AccountStatusReasons = accountReason,
                        KycPendingGate = partnerStatusInfo.KycPendingGate
                    };
                }
                else if (actualResponse.Result.ResponseCode == "0")
                {
                    responseData = new ExternalAccountStatusResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 0,
                            SubStatusCode = 0,
                            Message = "success"
                        },
                        AccountStatus = partnerStatusInfo.AccountStatus.ToString(),
                        AccountStatusReasons = accountReason,
                        KycPendingGate = partnerStatusInfo.KycPendingGate

                    };
                }
                else
                {
                    responseData = new ExternalAccountStatusResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 5,
                            SubStatusCode = 420,
                            Message = "The status update was declined by fraud."
                        },
                        AccountStatus = partnerStatusInfo.AccountStatus.ToString(),
                        AccountStatusReasons = accountReason,
                        KycPendingGate = partnerStatusInfo.KycPendingGate
                    };
                }

                return Task.FromResult(responseData);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<ExternalAccountStatusResponse>(e, request));
            }

        }

    }
}
