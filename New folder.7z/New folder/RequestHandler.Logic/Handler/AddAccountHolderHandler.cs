﻿using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Model.User.PreInterventions;
using Gd.Bos.RequestHandler.Core.Domain.Services.Crypto;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Account = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Account;
using AccountHolder = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.AccountHolder;
using CardExpirationDate = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.CardExpirationDate;
using KycStateData = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using PaymentInstrumentStatus = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.PaymentInstrumentStatus;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure.DataAccesses;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using PrivateCardData = Gd.Bos.RequestHandler.Core.Application.PrivateCardData;
using Gd.Bos.RequestHandler.Core.Infrastructure.Enrollment;
using RequestHandler.Core.Infrastructure.Enrollment;
using AccountHolderCure = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolderCure;
using RequestHandler.Core.Domain.Enums;
using RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Domain.Enums;
using RequestHandler.Core.Application;
using Gd.Bos.Shared.Common.Contract.Exceptions;
using NLog;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class AddAccountHolderHandler(
        IEnrollmentDataAccess enrollmentDataAccess,
        ICryptoService cryptoService,
        IIdempotentService idempotentService,
        IAccountService accountService,
        ILazyCache lazyCache,
        INotificationService notificationPublisher,
        IValidateIdentifier validateIdentifier,
        IAgreementDataAccess agreementDataAccess,
        IEnrollRepository baasEnrollCassandraRepository,
        IAccountRepository accountRepository,
        ILockService lockService,
        IUserRepository userRepository,
        IAccountHolderService accountHolderService,
        ITokenizerService tokenizerService,
        IRequestDataAccess requestDataAccess,
        ICreateLinkedAccountRepository createLinkedAccountRepository,
        IBaasConfiguration baasConfiguration,
        IVerificationService verificationService,
        IAsyncAccountService asyncAccountService)
        : CommandHandlerBase<AddAccountHolderRequest, AddAccountHolderResponse>
    {

        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();

        public override void SetDomainContext(AddAccountHolderRequest request)
        {
            if (!String.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;

            if (!string.IsNullOrEmpty(request.UserProfile.Ssn))
                DomainContext.Current.TokenizedIdentity = tokenizerService.TokenizeSsn(request.UserProfile.Ssn, DomainContext.Current.ProgramCode.ToString());
        }

        public override Task<AddAccountHolderResponse> VerifyIdentifiers(AddAccountHolderRequest request)
        {
            try
            {
                validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 3, 105);
                return Task.FromResult(new AddAccountHolderResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AddAccountHolderResponse>(e, request));
            }
        }
        public override async Task<AddAccountHolderResponse> ObtainLock(AddAccountHolderRequest request)
        {
            try
            {
                await lockService.ObtainApiLock(OptionsContext.Current.GetString("requestId"));
                await lockService.ObtainApiLock(DomainContext.Current.TokenizedIdentity);
                await lockService.ObtainApiLock(DomainContext.Current.AccountIdentifier.ToString());

                return new AddAccountHolderResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<AddAccountHolderResponse>(e, request);
            }
        }

        public override void ReleaseLock(AddAccountHolderRequest request)
        {
            lockService.ReleaseApiLock(OptionsContext.Current.GetString("requestId"));
            lockService.ReleaseApiLock(DomainContext.Current.TokenizedIdentity);
            lockService.ReleaseApiLock(DomainContext.Current.AccountIdentifier.ToString());
        }

        public override Task<AddAccountHolderResponse> Handle(AddAccountHolderRequest request)
        {
            try
            {
                var validateResult = ValidateRequestAndGetInfo(request);
                
                _logger.Info($"RequestId:{request.RequestHeader.RequestId}, ValidateRequestAndGetInfo Success. Begin CreateLinkedAccount");
                
                var userIdentifierGuid = validateResult.userIdentifierGuid;
                var status = validateResult.status;
                if (status >= CreateLinkedAccountStatus.FraudPass)
                {
                    var acc = accountService.GetEnrollmentByAccountIdentifier(request.AccountIdentifier.ToString(), request.ProgramCode, false)?.Account;
                    return Task.FromResult(BuildResponse(acc));
                }
                
                var account = validateResult.account;
                var primaryUser = validateResult.user;
                var primaryAccountHolder = validateResult.accountHolder;
                var userIdentifier = UserIdentifier.FromGuid(userIdentifierGuid);
                //var isFraudVerificationPassed = false;
                Core.Domain.Model.User.User secondaryUser = null;
                long secondaryAccountHolderKey = 0;
                var userIdentifyingData = new UserIdentifyingData(request.UserProfile!.DateOfBirth, "", request.UserProfile.Ssn, "");

                SsnAndPhoneLimitCheck(request, primaryUser);
                
                _logger.Info($"RequestId:{request.RequestHeader.RequestId}, SsnAndPhoneLimitCheck Success");
                
                if (status == CreateLinkedAccountStatus.Started)
                {
                    createLinkedAccountRepository.SaveRequest(request, userIdentifierGuid);
                    var newUserInfo = BuildNewUser(request, primaryUser);
                    var addAccountHolderResult = accountHolderService.AddAditionAccountHolder(account, request.ProgramCode, request.ProductCode,
                        DomainContext.Current.TokenizedIdentity, newUserInfo.userName, newUserInfo.email, newUserInfo.addresses,
                        newUserInfo.phones, request.TermsAcceptances?.ToDomain(newUserInfo.agreements),
                        userIdentifyingData, userIdentifier);
                    secondaryUser = addAccountHolderResult.Item1;
                    secondaryAccountHolderKey = addAccountHolderResult.Item2;
                    status = CreateLinkedAccountStatus.AccountCreated;
                    createLinkedAccountRepository.UpdateStatusByKey(userIdentifierGuid, status);
                    _logger.Info($"RequestId:{request.RequestHeader.RequestId}, AccountCreated Success,UserIdentifier:{userIdentifierGuid}");
                }
                
                if (status == CreateLinkedAccountStatus.AccountCreated)
                {
                    if (secondaryUser == null)
                    {
                        var currentAccountHolder = account.AccountHolders.FirstOrDefault(m => m.UserIdentifier == userIdentifier);
                        var existingUser = userRepository.GetUser(account.AccountIdentifier, userIdentifier).FirstOrDefault(m => m.UserIdentifier == userIdentifier);
                        secondaryUser = BuildSecondaryUser(request.ProgramCode, existingUser, userIdentifyingData);
                        secondaryAccountHolderKey = currentAccountHolder!.AccountHolderKey;
                    }
                    
                    var isFraudVerificationPassed = FraudVerification(account, secondaryAccountHolderKey, secondaryUser, request.ProgramCode, DomainContext.Current.TokenizedIdentity);
                    status = isFraudVerificationPassed ? CreateLinkedAccountStatus.FraudPass : CreateLinkedAccountStatus.FraudFail;
                    createLinkedAccountRepository.UpdateStatusByKey(userIdentifierGuid, status);
                    _logger.Info($"RequestId:{request.RequestHeader.RequestId}, FraudVerification, UserIdentifier:{userIdentifierGuid},status:{status}");
                }

                var enrollmentAccount = accountService.GetEnrollmentByAccountIdentifier(request.AccountIdentifier.ToString(), request.ProgramCode, false)?.Account;
                var response = BuildResponse(enrollmentAccount);
                if (status == CreateLinkedAccountStatus.FraudFail)
                {
                    enrollmentAccount!.AccountHolders = enrollmentAccount.AccountHolders.Where(a => a.User.UserIdentifier.Equals(userIdentifierGuid.ToString(), StringComparison.OrdinalIgnoreCase))?.ToList();
                    notificationPublisher.PublishNotification(request.ProgramCode, enrollmentAccount, EventType.AccountUpdated, request.RequestHeader.RequestId.ToString());
                }
                else
                {
                    var primaryPaymentInstrument = enrollmentAccount?.AccountHolders.FirstOrDefault(m => m.User.IsPrimaryAccountHolder)?.PaymentInstruments;
                    var primaryStatus = createLinkedAccountRepository.GetStatusByKeyWithoutException(Guid.Parse(primaryAccountHolder.UserIdentifier.ToString()));
                    if (primaryPaymentInstrument?.Any() != true && primaryStatus is null or < CreateLinkedAccountStatus.FraudCompleted)
                    {
                        var currentAccountHolderIdentifier = enrollmentAccount?.AccountHolders.FirstOrDefault(m => m.User.UserIdentifier.Equals(userIdentifier.ToString(), StringComparison.OrdinalIgnoreCase))?.AccountHolderIdentifier;
                        accountRepository.UpdateIsPrimaryAccountHolder(currentAccountHolderIdentifier);
                        asyncAccountService.CreateExternalLinkedAccount(account, request.RequestPhysicalCard, request.ProductMaterialType, userIdentifier.ToString(), true);
                        createLinkedAccountRepository.UpdateStatusByKey(userIdentifierGuid, CreateLinkedAccountStatus.FraudCompleted);
                        _logger.Info($"RequestId:{request.RequestHeader.RequestId},CreateExternalLinkedAccount Success ,UserIdentifier:{userIdentifierGuid},status:{status}");
                    }
                    else
                    {
                        createLinkedAccountRepository.SaveRequest(request, CreateLinkedAccountStatus.JointAccountStarted, userIdentifierGuid);
                        asyncAccountService.CreateJointAccount(request.AccountIdentifier, userIdentifier, account.Product, request.RequestPhysicalCard, request.ProductMaterialType, true);
                        _logger.Info($"RequestId:{request.RequestHeader.RequestId},CreateJointAccount Success ,UserIdentifier:{userIdentifierGuid}");
                    }
                }

                return Task.FromResult(response);
            }
            catch (Exception ex)
            {
                return Task.FromResult(ex.HandleException<AddAccountHolderResponse>(ex, request));
            }
        }
        private Core.Domain.Model.User.User BuildSecondaryUser(
            string programCode,
            Core.Domain.Model.User.UserProfile exsitingUser,
            UserIdentifyingData userIdentifierData)
        {
            Core.Domain.Model.User.User secondaryUser = new Core.Domain.Model.User.User
                          (
                          exsitingUser.UserIdentifier,
                          ProgramCode.FromString(programCode),
                          new UserName(exsitingUser.FirstName, exsitingUser.MiddleName, exsitingUser.LastName),
                          exsitingUser.Email,
                          userIdentifierData,
                          null
                          );
            exsitingUser.Addresses.ForEach(m => secondaryUser.AddAddress(m));
            exsitingUser.PhoneNumbers.ForEach(m => secondaryUser.AddPhoneNumber(m));
            return secondaryUser;
        }

        private (
            Core.Domain.Model.Account.Account account,
            Core.Domain.Model.User.UserProfile user,
            Core.Domain.Model.Account.AccountHolder accountHolder,
            Guid userIdentifierGuid,
            CreateLinkedAccountStatus status
            ) ValidateRequestAndGetInfo(AddAccountHolderRequest request)
        {
            var isDuplicatedGroup = request.UserProfile.Addresses?.GroupBy(ad => ad.Type).Any(ag => ag.Count() > 1);
            if (isDuplicatedGroup == true)
            {
                throw new RequestHandlerException(1020, 0, "Duplicated type is not allowed.");
            }
            var account = accountService.GetKeysAccountIdentifier(request.AccountIdentifier);
            if (accountService.IsJointAccount(request.AccountIdentifier) && account!.AccountHolders!.Any(m => m.ConsumerProfileTypeKey != (int)ConsumerProfileType.Individual))
            {
                throw new RequestHandlerException(10, 0, "business account not supported for joint account.");
            }
            var primaryAccountHolder = account!.AccountHolders!.FirstOrDefault(x => x.IsPrimary);
            if (primaryAccountHolder?.AccountHolderCure == AccountHolderCure.None)
            {
                throw new RequestHandlerException(5, 100, "An account must not be in a locked status to add an additional cardholder.");
            }
            var primaryUser = userRepository.GetUser(request.AccountIdentifier, primaryAccountHolder?.UserIdentifier)?.FirstOrDefault();
            if (primaryUser == null)
            {
                throw new RequestHandlerException(10, 0, "User Not Found.");
            }
            var userIdentifierGuid = Guid.NewGuid();
            var status = CreateLinkedAccountStatus.Started;
            var existingUserIdentifier = requestDataAccess.InsertRequestId(RequestType.CreateLinkedAccount, request.RequestHeader.RequestId, userIdentifierGuid);
            if (existingUserIdentifier.HasValue && existingUserIdentifier.Equals(Guid.Parse(request.AccountIdentifier)))
            {
                throw new RequestHandlerException(5, 100, "Request id had been used, please use another request id.");
            }
            if (existingUserIdentifier.HasValue)
            {
                userIdentifierGuid = existingUserIdentifier.Value;
                var secondaryAccountHolder = account!.AccountHolders!.FirstOrDefault(m=> string.Equals(m.UserIdentifier.ToString(), userIdentifierGuid.ToString(), StringComparison.OrdinalIgnoreCase));
                if (secondaryAccountHolder?.AccountHolderCure == AccountHolderCure.None)
                {
                    throw new RequestHandlerException(5, 100, "Account holder cure can not be none.");
                }
                status = createLinkedAccountRepository.GetStatusByKeyWithoutException(userIdentifierGuid) ?? CreateLinkedAccountStatus.Started;
            }
            var maxAccountHolder = baasConfiguration.GetMaxAccountHolderConfig(request.ProgramCode);
            if (account.AccountHolders.Count(m => !string.Equals(m.UserIdentifier.ToString(), userIdentifierGuid.ToString(), StringComparison.OrdinalIgnoreCase)) >= maxAccountHolder)
            {
                throw new RequestHandlerException(5, 102, @$"This account already has {maxAccountHolder} account holders.");
            }

            var enrollmentTimeLimit = baasConfiguration.GetAddAccountHolderTimeLimit(request.ProgramCode);
            var shouldValidateTimeLimit = ShouldValidateTimeLimit(request.ProgramCode, account);
            if (shouldValidateTimeLimit && enrollmentTimeLimit != 0)
            {
                DateTimeOffset now = DateTimeOffset.UtcNow;
                DateTimeOffset accountCreateDate = account.AccountCreateDate;
                var hourDifference = now - accountCreateDate;
                if (hourDifference.TotalSeconds >= enrollmentTimeLimit)
                {
                    throw new RequestHandlerException(5, 10, $"Join Account can not be created, time limit exceeded.");
                }
            }

            return new(account, primaryUser, primaryAccountHolder, userIdentifierGuid, status);
        }

        private bool ShouldValidateTimeLimit(string programCode, Core.Domain.Model.Account.Account account)
        {
            var skipTimeLimitConfig = baasConfiguration.GetAddAccountHolderSkipTimeLimitConfig(programCode);
            if (!skipTimeLimitConfig)
            {
                return true;
            }
            var exsitingTrasacationHistory = accountService.ExsitingTrasacationHistory(account.AccountIdentifier, account.AccountCreateDate);
            return exsitingTrasacationHistory;
        }

        private (UserName userName,
            List<Core.Domain.Model.User.PhoneNumber> phones,
            Core.Domain.Model.User.Email email,
            List<Core.Domain.Model.User.Address> addresses,
            List<Shared.Common.Core.Common.Data.Agreement> agreements) BuildNewUser(AddAccountHolderRequest request, Core.Domain.Model.User.UserProfile user)
        {
            if (request.UserProfile.Addresses?.Any() != true)
            {
                var address = user.Addresses.FirstOrDefault(m => m.IsDefault) ?? user.Addresses.FirstOrDefault(m => m.Type?.ToLower() == "home") ?? user.Addresses.FirstOrDefault();
                request.UserProfile.Addresses = new List<Shared.Common.Core.CoreApi.Contract.Data.Address>()
                        {
                           new Shared.Common.Core.CoreApi.Contract.Data.Address()
                           {
                                AddressLine1 = address.AddressLine1,
                                AddressLine2 = address.AddressLine2,
                                City = address.City,
                                CountryCode = address.Country,
                                IsDefault = true,
                                State = address.State,
                                IsVerified = address.IsVerified,
                                ZipCode = address.ZipCode,
                                Type = address.Type
                           }
                        };
            }
            else if (!request.UserProfile.Addresses.Any(m => m.IsDefault))
            {
                var address = request.UserProfile.Addresses.FirstOrDefault(m => m.Type?.ToLower() == "home") ?? request.UserProfile.Addresses.FirstOrDefault();
                address.IsDefault = true;
            }
            if (request.UserProfile.PhoneNumbers?.Any() != true)
            {
                var phone = user.PhoneNumbers.FirstOrDefault(m => m.IsDefault) ?? user.PhoneNumbers.FirstOrDefault(m => m.Type == PhoneType.Home) ?? user.PhoneNumbers.FirstOrDefault();
                request.UserProfile.PhoneNumbers = new List<Shared.Common.Core.CoreApi.Contract.Data.PhoneNumber>()
                        {
                            new Shared.Common.Core.CoreApi.Contract.Data.PhoneNumber()
                            {
                                Number = phone.Number,
                                IsDefault = true,
                                IsVerified = phone.IsVerified,
                                Type = phone.Type
                            }
                        };
            }
            else if (!request.UserProfile.PhoneNumbers.Any(m => m.IsDefault))
            {
                var phone = request.UserProfile.PhoneNumbers.FirstOrDefault(m => m.Type == PhoneType.Home) ?? request.UserProfile.PhoneNumbers.FirstOrDefault();
                phone.IsDefault = true;
            }
            if (request.UserProfile.Email?.IsDefault == false)
            {
                request.UserProfile.Email.IsDefault = true;
            }
            var userName = new UserName(request.UserProfile.FirstName, request.UserProfile.MiddleName, request.UserProfile.LastName);
            var email = string.IsNullOrWhiteSpace(request.UserProfile?.Email?.EmailAddress) ? user.Email : request.UserProfile.Email.ToDomain();
            var agreement = agreementDataAccess.GetAgreementsByProductCode(request.ProductCode);
            return (userName, request.UserProfile.PhoneNumbers.ToDomain(), email, request.UserProfile.Addresses.ToDomain(), agreement);
        }

        private bool FraudVerification(Core.Domain.Model.Account.Account account,
            long accountHolderKey,
            Core.Domain.Model.User.User user, string programCode,
            string ssnToken)
        {
            Core.Domain.Model.Account.AccountHolder accountHolder =
                account.AccountHolders.First(ah => ah.AccountHolderKey == accountHolderKey);
            if (accountHolder.VerificationRequestIdentifier == null)
            {
                accountHolder.VerificationRequestIdentifier = VerificationRequestIdentifier.FromString(Guid.NewGuid().ToString());
            }
            return verificationService.EnrollmentVerificationForSecondaryAccountHolder(account, accountHolder, user,
                programCode, ssnToken).Item1;
        }

        private AccountLimit SsnAndPhoneLimitCheck(AddAccountHolderRequest request, Gd.Bos.RequestHandler.Core.Domain.Model.User.UserProfile user)
        {
            var accountLimit = accountService.AccountLimitVerification(request.UserProfile.Ssn, string.Empty,
                IdentityType.SSN.ToString(), false, request.ProductCode, request.ProgramCode);
            if (!string.IsNullOrWhiteSpace(accountLimit.ResponseCode) && accountLimit.ResponseCode != "0")
            {
                throw new RequestHandlerException(Convert.ToInt32(accountLimit.ResponseCode), 0,
                    "SSN limit check is failed");
            }
            var phoneNumber = string.Empty;
            if (request.UserProfile.PhoneNumbers?.Any() != true)
            {
                var phone = user.PhoneNumbers.FirstOrDefault(m => m.IsDefault) ?? user.PhoneNumbers.FirstOrDefault(m => m.Type == PhoneType.Home) ?? user.PhoneNumbers.FirstOrDefault();
                phoneNumber = phone.Number;
            }
            else
            {
                var phone = request.UserProfile.PhoneNumbers.FirstOrDefault(m => m.IsDefault) ?? request.UserProfile.PhoneNumbers.FirstOrDefault(m => m.Type == PhoneType.Home) ?? request.UserProfile.PhoneNumbers.FirstOrDefault();
                phoneNumber = phone.Number;
            }
            accountLimit = accountService.PhoneLimitVerification(phoneNumber, "PhoneNumber", request.ProductCode,
                request.ProgramCode);
            return accountLimit;
        }

        private AddAccountHolderResponse BuildResponse(Account account)
        {
            var response = new AddAccountHolderResponse()
            {
                ResponseHeader = new ResponseHeader()
                {
                    StatusCode = 0,
                    ResponseId = new Guid(OptionsContext.Current.GetString("requestId"))
                },
                AccountIdentifier = account.AccountIdentifier,
                AccountHolders = new List<LinkedAccountHolder>(),
                Status = account?.Status,
                AccountStatusReasons = account.StatusReasons
            };
            foreach (var item in account?.AccountHolders)
            {
                var lah = new LinkedAccountHolder()
                {
                    FirstName = item.User?.FirstName,
                    LastName = item.User?.LastName,
                    UserIdentifier = item.User?.UserIdentifier?.ToString(),
                    KycStateData = new KycStateData()
                    {
                        PendingKycGate = item?.User?.KycStateData?.PendingKycGate,
                        KycStatus = item?.User?.KycStateData?.KycStatus,
                        OfacStatus = item?.User?.KycStateData?.OfacStatus
                    }
                };
                response.AccountHolders.Add(lah);
            }
            return response;
        }
    }
}
