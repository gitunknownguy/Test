﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Logic.Exceptions;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Model.User.PreInterventions;
using KycStateData = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;


namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class RetailAccountVerificationHandler : CommandHandlerBase<RetailAccountVerificationRequest, RetailAccountVerificationResponse>
    {
        private readonly IUserService _userService;
        private readonly ITokenizerService _tokenizerService;
        private readonly IVerificationService _verificationService;
        private readonly IAccountService _accountService;
        private readonly IProductRepository _productRepository;
        private readonly IAddressIntervention _addressIntervention;
        private readonly IPhoneIntervention _phoneIntervention;

        public RetailAccountVerificationHandler(
            IUserService userService,
            ITokenizerService tokenizerService,
            IVerificationService verificationService,
            IAccountService accountService,
            IProductRepository productRepository,
            IAddressIntervention addressIntervention,
            IPhoneIntervention phoneIntervention
        )
        {
            _userService = userService;
            _tokenizerService = tokenizerService;
            _verificationService = verificationService;
            _accountService = accountService;
            _productRepository = productRepository;
            _addressIntervention = addressIntervention;
            _phoneIntervention = phoneIntervention;
        }

        public override void SetDomainContext(RetailAccountVerificationRequest request)
        {
        }

        public override Task<RetailAccountVerificationResponse> VerifyIdentifiers(RetailAccountVerificationRequest request)
        {
            return Task.FromResult(new RetailAccountVerificationResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<RetailAccountVerificationResponse> Handle(RetailAccountVerificationRequest request)
        {

            var accountRefID = request?.AccountIdentifier;
            var response = new RetailAccountVerificationResponse();
            response.AccountIdentifier = accountRefID;
            response.KycStateData = new KycStateData();
            var addresses = request.ProfileData?.Addresses?.ToDomain();
            _addressIntervention.SetHomeAddressToDefault(addresses);

            List<Address> newAddresses = addresses != null
               ? ConvertToDomainAddresses(addresses)
               : new List<Address>();

            List<PhoneNumber> newPhoneNumbers = request?.PhoneNumbers != null
                ? ConvertToDomainPhoneNumbers(request?.PhoneNumbers)
                : new List<PhoneNumber>();

            _addressIntervention.ValidAddresses(newAddresses, false);
            _phoneIntervention.ValidPhoneNumbers(newPhoneNumbers);

            if (request.IdentifyingData != null)
            {
                request.IdentifyingData.SsnSuffix = "";
                request.IdentifyingData.OnBoardingId = "";
            }

            try
            {
                #region Update Consumer profile
                UserName name = new UserName(request?.ProfileData?.FirstName, request?.ProfileData?.MiddleName, request?.ProfileData?.LastName);

                if (name.FirstName == null && name.LastName == null)
                    name = null;

                // get customer information
                var customerInfo =
                    _userService.GetUser(AccountIdentifier.FromGuid(Guid.Parse(accountRefID)), null)
                        ?.FirstOrDefault(x => x.IsPrimaryAccountHolder);

                if (customerInfo == null)
                {
                    throw new UpdateUserProfileException("No primary account holder info identified.");
                }

                var userIdentifyingData = request?.IdentifyingData?.ToDomain();

                //update user name
                _userService.UpdateUserName(name, AccountIdentifier.FromString(accountRefID), customerInfo?.UserIdentifier);

                //update email, phone and address
                Email newEmail = null;
                if (request.Email != null)
                {
                    newEmail = new Email(request.Email.EmailAddress, request.Email.IsVerified, true);
                }
                _userService.UpdateUser(AccountIdentifier.FromString(accountRefID),
                    customerInfo?.UserIdentifier,
                    newAddresses,
                    newPhoneNumbers,
                    newEmail,
                    string.Empty,
                    request.ProgramCode,
                    request.RequestHeader.RequestId,
                    false, true);

                //Tokenize ssn
                string tokenizedSSn = _tokenizerService.TokenizeSsn(userIdentifyingData?.Ssn, request.ProgramCode);

                //Update Identity
                _userService.UpdateConsumerIdentity(customerInfo.UserIdentifier, userIdentifyingData?.Ssn, tokenizedSSn);

                //update encrypted dob
                _userService.UpdateEncryptedDOB(customerInfo.UserIdentifier, userIdentifyingData?.DateOfBirth);

                #endregion Update Consumer profile

                #region KYC Check
                string fraudSsnToken = string.Empty;

                User user = new User(customerInfo.UserIdentifier, ProgramCode.FromString(request.ProgramCode), name, newEmail, userIdentifyingData, tokenizedSSn);
                Account account = _accountService.GetAccountByAccountIdentifier(accountRefID);

                var accountholder = account.AccountHolders?.First();
                accountholder.VerificationRequestIdentifier = VerificationRequestIdentifier.FromString(Guid.NewGuid().ToString());
                accountholder.kycStateData = new Core.Domain.Model.Account.KycStateData();

                if (account.AccountHolders.Count > 1)
                {
                    account.AccountHolders?.Remove(account?.AccountHolders?.FirstOrDefault());
                    account.AccountHolders.Add(accountholder);
                }

                Product product = _productRepository.GetByProductCode(ProductCode.FromString(request.ProductCode),
                ProgramCode.FromString(request.ProgramCode));
                account.Product = product;

                var kycflag = _verificationService.EnrollmentFraudVerification(account, user, addresses, newEmail, newPhoneNumbers, null, request.ProgramCode, tokenizedSSn, "kyc", true, null, null, new PhoneVerificationOptions { PhoneProfileVerificationEnabled = false }, ref fraudSsnToken);

                var kycData = account.AccountHolders.FirstOrDefault().kycStateData;

                if (kycData != null)
                {
                    response.KycStateData.KycStatus = kycData.KycStatus.ToString().ToLower();
                    response.KycStateData.PendingKycGate = kycData.KycPendingGate.ToLower();
                    if (kycData.KycPendingGate.ToLower() == "none")
                    {
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 2,
                            SubStatusCode = 11,
                            Message = "KYC Failed.  No Cure."
                        };
                    }
                    else if (kycData.KycPendingGate.ToLower() != "healthy")
                    {
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 1,
                            SubStatusCode = 10,
                            Message = "KYC Required.  Curable."
                        };
                    }
                    else
                    {
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 0,
                            SubStatusCode = 0,
                            Message = "Success"
                        };
                    }
                }
                else
                {
                    response.ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 2,
                        SubStatusCode = 11,
                        Message = "KYC Failed.  No Cure."
                    };
                }
                #endregion

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<RetailAccountVerificationResponse>(e, request));

            }

        }

        private List<Address> ConvertToDomainAddresses(List<Address> addresses)
        {
            List<Address> domainAddresses = new List<Address>();
            foreach (var address in addresses)
            {
                Address domainAddress = new Address
                {
                    Country = "USA",
                    State = address.State,
                    AddressLine1 = address.AddressLine1,
                    AddressLine2 = address.AddressLine2,
                    City = address.City,
                    Type = address.Type,
                    ZipCode = address.ZipCode,
                    IsDefault = address.IsDefault,
                    IsVerified = false
                };

                domainAddresses.Add(domainAddress);
            }

            return domainAddresses;
        }

        private List<PhoneNumber> ConvertToDomainPhoneNumbers(List<Bos.Shared.Common.Core.CoreApi.Contract.Data.PhoneNumber> phoneNumbers)
        {
            List<PhoneNumber> domainPhoneNumbers = new List<PhoneNumber>();
            foreach (var number in phoneNumbers)
            {
                PhoneNumber newNumber = new PhoneNumber
                {
                    Number = number.Number,
                    Type = number.Type,
                    IsDefault = number.IsDefault,
                    IsVerified = false
                };

                domainPhoneNumbers.Add(newNumber);
                number.IsVerified = false;
            }

            return domainPhoneNumbers;
        }
    }
}
