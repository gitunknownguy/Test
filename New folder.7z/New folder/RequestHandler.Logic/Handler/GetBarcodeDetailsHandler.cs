﻿using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.ECash;
using GetBarcodeDetailsRequest = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.GetBarcodeDetailsRequest;
using GetBarcodeDetailsResponse = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.GetBarcodeDetailsResponse;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetBarcodeDetailsHandler : ECashHandlerBase<GetBarcodeDetailsRequest, GetBarcodeDetailsResponse>
    {
        public GetBarcodeDetailsHandler(IECashService eCashService) : base(eCashService)
        {

        }

        public override void SetDomainContext(GetBarcodeDetailsRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetBarcodeDetailsResponse> VerifyIdentifiers(GetBarcodeDetailsRequest request)
        {
            return Task.FromResult(new GetBarcodeDetailsResponse { ResponseHeader = new ResponseHeader() });
        }

        public override Task<GetBarcodeDetailsResponse> Handle(GetBarcodeDetailsRequest request)
        {
            return Task.FromResult(GetBarcodeDetails(request));
        }

        private GetBarcodeDetailsResponse GetBarcodeDetails(GetBarcodeDetailsRequest request)
        {
            var response = new GetBarcodeDetailsResponse();
            var domainResponse = ECashService.GetBarcodeDetails(new Core.Domain.Services.ECash.GetBarcodeDetailsRequest
            {
                AccountIdentifier = request.AccountIdentifier,
                ProgramCode = request.ProgramCode,
                BarcodeHumanReadable = request.BarcodeHumanReadable
            });

            response.ResponseHeader = MapResponse(domainResponse?.ResponseDetails?[0], request.RequestHeader.RequestId);

            if (domainResponse?.ECashTransaction != null)
            {
                response.ECashTransactionDetails = new ECashTransactionDetails
                {
                    PartnerId = domainResponse.ECashTransaction.PartnerId,
                    PartnerName = domainResponse.ECashTransaction.PartnerName,
                    ProgramCode = domainResponse.ECashTransaction.ProgramCode,
                    ProductCode = domainResponse.ECashTransaction.ProductCode,
                    AccountIdentifier = domainResponse.ECashTransaction.AccountIdentifier,
                    Amount = domainResponse.ECashTransaction.Amount,
                    Recipient = domainResponse.ECashTransaction.Recipient,
                    Memo = domainResponse.ECashTransaction.Memo,
                    TransactionType = domainResponse.ECashTransaction.TransactionType,
                    BarcodeHumanReadable = domainResponse.ECashTransaction.BarcodeHumanReadable,
                    BarcodeNumber = domainResponse.ECashTransaction.BarcodeNumber,
                    BarcodeStatus = domainResponse.ECashTransaction.BarcodeStatus,
                    BarcodeExpirationDateTime = domainResponse.ECashTransaction.BarcodeExpirationDateTime,
                    FaceFee = domainResponse.ECashTransaction.FaceFee,
                    ZipCode = domainResponse.ECashTransaction.ZipCode
                };
            }

            return response;
        }
    }
}
