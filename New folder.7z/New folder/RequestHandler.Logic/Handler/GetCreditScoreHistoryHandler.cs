﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Core.Infrastructure.DataAccesses;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Logic.Options;

namespace RequestHandler.Logic.Handler
{
    public class GetCreditScoreHistoryHandler : CommandHandlerBase<GetCreditScoreHistoryRequest, GetCreditScoreHistoryResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IRiskService _riskService;
        private readonly IAccountRepository _accountRepository;
        private readonly IAgreementDataAccess _agreementDataAccess;
        private readonly IBaasConfiguration _bassBaasConfiguration;

        public GetCreditScoreHistoryHandler(IValidateIdentifier validateIdentifier,
            IRiskService riskService,
            IAccountRepository accountRepository,
            IAgreementDataAccess agreementDataAccess,
            IBaasConfiguration baasConfiguration)
        {
            _validateIdentifier = validateIdentifier;
            _riskService = riskService;
            _accountRepository = accountRepository;
            _agreementDataAccess = agreementDataAccess;
            _bassBaasConfiguration = baasConfiguration;
        }

        public override void SetDomainContext(GetCreditScoreHistoryRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            DomainContext.Current.UserIdentifier = request.UserIdentifier;
        }

        public override Task<GetCreditScoreHistoryResponse> VerifyIdentifiers(GetCreditScoreHistoryRequest request)
        {
            _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
            _validateIdentifier.ValidateConsumerProfileIdentifier(DomainContext.Current.AccountIdentifier,
                DomainContext.Current.UserIdentifier);
            return Task.FromResult(new GetCreditScoreHistoryResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<GetCreditScoreHistoryResponse> Handle(GetCreditScoreHistoryRequest request)
        {

            var consumerProfile = _accountRepository.GetAccountPrimaryConsumerProfile(Guid.Parse(request.AccountIdentifier),
                Guid.Parse(request.UserIdentifier));

            var userTermAcceptances = _agreementDataAccess.GetTermsAcceptancesByAccountIdentifier(request.AccountIdentifier, null)
             .Where(te => te.AccountHolderKey == consumerProfile.AccountHolderKey)
             .ToList();

            var agreement = userTermAcceptances.FirstOrDefault(
                x => x.OptoutDate == null &&
                     (x.BrandAgreementTypeIdentifier.Equals("EqCSA", StringComparison.CurrentCultureIgnoreCase)
                      || x.BrandAgreementTypeIdentifier.Equals("EqCSACbl", StringComparison.CurrentCultureIgnoreCase)));

            if (agreement == null)
            {
                return Task.FromResult(new GetCreditScoreHistoryResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        Message = "User has not opted-in to receive score.",
                        StatusCode = 1,
                        SubStatusCode = 55

                    }
                });
            }

            if (!_bassBaasConfiguration.GetCreditScoreHistoryEnabled(request.ProgramCode))
            {
                return Task.FromResult(new GetCreditScoreHistoryResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        Message = "Partner not valid to call this API - Operation not allowed.",
                        StatusCode = 0,
                        SubStatusCode = 963

                    }
                });
            }

            if (consumerProfile.AccountStatus != AccountStatus.Normal
                && consumerProfile.AccountStatus != AccountStatus.Restricted
                && consumerProfile.AccountStatus != AccountStatus.Locked
                || (consumerProfile.AccountStatus == AccountStatus.Restricted ||
                    consumerProfile.AccountStatus == AccountStatus.Locked)
                && (consumerProfile.AccountHolderCure == AccountHolderCure.Unknown
                    || consumerProfile.AccountHolderCure == AccountHolderCure.None))
            {
                return Task.FromResult(new GetCreditScoreHistoryResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        Message = "Operation not allowed for this account status.",
                        StatusCode = 3,
                        SubStatusCode = 100

                    }
                });
            }
            var riskRequest = new GetCreditScoresRequest
            {
                RequestHeader = new Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request.RequestHeader
                {
                    RequestId = OptionsContext.Current.GetGuid("requestId", Guid.NewGuid())
                },
                ExternalIdentifiers = new Dictionary<string, object>
                {
                    { "ConsumerProfileIdentifier", request.UserIdentifier},
                },
                StartDate = string.IsNullOrEmpty(request.StartDate) ? (DateTime?)null : DateTime.Parse(request.StartDate),
                EndDate = string.IsNullOrEmpty(request.EndDate) ? (DateTime?)null : DateTime.Parse(request.EndDate).AddDays(1)
            };
            var riskResponse = _riskService.GetCreditScores(riskRequest);

            riskResponse.CreditScoreDetail.MaxScore = riskResponse.CreditScoreDetail.MaxScore ?? 0;
            riskResponse.CreditScoreDetail.MinScore = riskResponse.CreditScoreDetail.MinScore ?? 0;

            return Task.FromResult(new GetCreditScoreHistoryResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId
                },
                CreditScores = riskResponse.CreditScores,
                CreditScoreDetail = riskResponse.CreditScoreDetail
            });
        }
    }
}