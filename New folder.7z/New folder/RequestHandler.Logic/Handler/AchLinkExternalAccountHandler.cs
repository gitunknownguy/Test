﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Services.Core;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using Gd.Bos.Shared.Common.UtilityCoreApi.Contract.Data;
using Gd.Bos.Shared.Common.UtilityCoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.UtilityCoreApi.Contract.Message.Response;
using IAchService = Gd.Bos.RequestHandler.Core.Domain.Services.Ach.IAchService;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class AchLinkExternalAccountHandler : CommandHandlerBase<AchLinkExternalAccountRequest, AchLinkExternalAccountResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IAchService _achService;
        private readonly IBaasConfiguration _baasConfiguration;
        private readonly ITransferService _transferService;
        private readonly ILockService _lockService;
        private readonly IUtilityCoreWebApiClient _utilityCoreWebApiClient;

        public AchLinkExternalAccountHandler(IValidateIdentifier validateIdentifier, IAchService achService, IBaasConfiguration baasConfiguration, ITransferService transferService, ILockService lockService, IUtilityCoreWebApiClient utilityCoreWebApiClient)
        {
            _validateIdentifier = validateIdentifier;
            _achService = achService;
            _baasConfiguration = baasConfiguration;
            _transferService = transferService;
            _lockService = lockService;
            _utilityCoreWebApiClient = utilityCoreWebApiClient;
        }

        public override Task<AchLinkExternalAccountResponse> Handle(AchLinkExternalAccountRequest request)
        {
            try
            {
                var getExternalBankAccountsRequest = new GetExternalBankAccountsRequest()
                {
                    AccountReferenceId = request.AccountReferenceId,
                    AccountIdentifier = request.AccountReferenceId,
                    ProgramCode = request.ProgramCode,
                    ExternalAccountProvider = request.ExternalAccountProvider,
                    RequestHeader = new Gd.Bos.Shared.Common.Contract.Message.Request.RequestHeader()
                    {
                        RequestId = request.RequestHeader.RequestId,
                        Options = request.RequestHeader.Options
                    }
                };

                GetExternalBankAccountsResponse externalBankAccountsResponse = _utilityCoreWebApiClient.GetExternalBankAccounts(getExternalBankAccountsRequest);
                if (externalBankAccountsResponse != null && !string.IsNullOrWhiteSpace(externalBankAccountsResponse.MaxExternalBankAccountsAllowed))
                {
                    if (int.TryParse(externalBankAccountsResponse.MaxExternalBankAccountsAllowed, out int maxExternalBankAccountsAllowed))
                    {
                        if (externalBankAccountsResponse.BankAccounts != null)
                        {
                            int bankAccountCount = externalBankAccountsResponse.BankAccounts.Count(o => o.BankAccountStatus != BankAccountStatus.Deleted);

                            if (bankAccountCount >= maxExternalBankAccountsAllowed)
                            {
                                throw new ValidationException(630, 0, "Can not link external account due to allowable linked account limit hit.");
                            }
                        }
                    }
                }

                Core.Domain.Services.Ach.AchLinkExternalAccountRequest achLinkExternalAccountRequest = new Core.Domain.Services.Ach.AchLinkExternalAccountRequest();

                achLinkExternalAccountRequest.ProgramCode = request.ProgramCode;
                achLinkExternalAccountRequest.PublicToken = request.PublicToken;
                achLinkExternalAccountRequest.AccountReferenceId = request.AccountReferenceId;
                achLinkExternalAccountRequest.SelectedBankAccounts = request.SelectedBankAccounts;
                achLinkExternalAccountRequest.ExternalAccountProvider = Enum.GetName(typeof(TokenType), request.ExternalAccountProvider);

                var domainResponse = _achService.AchLinkExternalAccount(achLinkExternalAccountRequest);
                var response = new AchLinkExternalAccountResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                    ResponseCode = domainResponse.ResponseCode,
                    ExternalAccountProfileReferenceId = domainResponse.ExternalAccountProfileReferenceId,
                    ExternalBankAccountReferenceIds = domainResponse.ExternalBankAccountReferenceIds
                };

                SetResponseCode(response, domainResponse);

                if (response.ResponseCode == 0 && _baasConfiguration.PublishCustomerNotification(request.ProgramCode, "Ach"))
                {
                    string bankName = request?.SelectedBankAccounts?.FirstOrDefault()?.InstitutionName;
                    _transferService.RaisePriorityMessageToLinkBankAccount(request.AccountReferenceId, request.ProgramCode, null, null, bankName);
                }

                return Task.FromResult(response);

            }
            catch (Exception ex)
            {
                return Task.FromResult(ex.HandleException<AchLinkExternalAccountResponse>(ex, request));
            }
        }

        private void SetResponseCode(AchLinkExternalAccountResponse response,
            Core.Domain.Services.Ach.AchLinkExternalAccountResponse domainResponse)
        {

            switch (domainResponse.ResponseCode)
            {
                case 0:
                    break;

                case 1:
                    response.ResponseHeader.StatusCode = 5;
                    response.ResponseHeader.SubStatusCode = 236;
                    response.ResponseHeader.Message = "Cannot get accessToken from publicToken";
                    break;
                case 2:
                    response.ResponseHeader.StatusCode = 5;
                    response.ResponseHeader.SubStatusCode = 237;
                    response.ResponseHeader.Message = "Identity call failed to Plaid";
                    break;
                case 3:
                    response.ResponseHeader.StatusCode = 5;
                    response.ResponseHeader.SubStatusCode = 550;
                    response.ResponseHeader.Message = "Identity declined by risk due to name mismatch.";
                    break;
                case 4:
                    response.ResponseHeader.StatusCode = 5;
                    response.ResponseHeader.SubStatusCode = 238;
                    response.ResponseHeader.Message = "Auth call failed to Plaid.";
                    break;
                case 5:
                    response.ResponseHeader.StatusCode = 5;
                    response.ResponseHeader.SubStatusCode = 239;
                    response.ResponseHeader.Message = "Auth declined by risk.";
                    break;
                case 20:
                    response.ResponseHeader.StatusCode = 5;
                    response.ResponseHeader.SubStatusCode = 240;
                    response.ResponseHeader.Message = "Phone and Address Validation Failed.";
                    break;
                case 27:
                    response.ResponseHeader.StatusCode = 5;
                    response.ResponseHeader.SubStatusCode = 241;
                    response.ResponseHeader.Message = "Retrieve Account Owner info failed";
                    break;
                default:
                    response.ResponseHeader.StatusCode = 5;
                    response.ResponseHeader.SubStatusCode = 242;
                    response.ResponseHeader.Message = "AchLinkExternalAccount error";
                    break;
            }
        }

        public override void SetDomainContext(AchLinkExternalAccountRequest request)
        {
        }

        public override Task<AchLinkExternalAccountResponse> VerifyIdentifiers(AchLinkExternalAccountRequest request)
        {
            return Task.FromResult(new AchLinkExternalAccountResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override async Task<AchLinkExternalAccountResponse> ObtainLock(AchLinkExternalAccountRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock(GenerateLockKey(request.AccountReferenceId));
                return new AchLinkExternalAccountResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<AchLinkExternalAccountResponse>(e, request);
            }
        }

        public override void ReleaseLock(AchLinkExternalAccountRequest request)
        {
            _lockService.ReleaseApiLock(GenerateLockKey(request.AccountReferenceId));
        }

        private static string GenerateLockKey(string accountId)
        {
            return "AchLinkExternalAccount_" + accountId;
        }
    }
}
