﻿using System;
using System.Threading.Tasks;
using FluentValidation;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using ValidationException = Gd.Bos.RequestHandler.Core.Infrastructure.ValidationException;

namespace RequestHandler.Logic.Handler
{
    public class GetAccountByTokenizedPanHandler : CommandHandlerBase<GetAccountByTokenizedPanRequest, GetAccountByTokenizedPanResponse>
    {

        private readonly IAccountRepository _accountRepository;
        public GetAccountByTokenizedPanHandler(IAccountRepository accountRepository)
        {
            _accountRepository = accountRepository;
        }
        public override void SetDomainContext(GetAccountByTokenizedPanRequest request)
        {
            DomainContext.Current.ProgramCode = ProgramCode.FromString(request.ProgramCode);
        }
        public override Task<GetAccountByTokenizedPanResponse> VerifyIdentifiers(GetAccountByTokenizedPanRequest request)
        {
            if (string.IsNullOrEmpty(request.TokenizedPan))
            {
                throw new ValidationException(400, 0, "TokenizedPan null or empty");
            }
            return Task.FromResult(new GetAccountByTokenizedPanResponse { ResponseHeader = new ResponseHeader() });
        }

        public override Task<GetAccountByTokenizedPanResponse> Handle(GetAccountByTokenizedPanRequest request)
        {

            var (accountIdentifier, programCode) = _accountRepository.GetAccountIdentifierByTokenizedPan(request.TokenizedPan);
            if (accountIdentifier == Guid.Empty)
            {
                throw new ValidationException(10, 0, "Account Not Found.");
            }

            return Task.FromResult(new GetAccountByTokenizedPanResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId
                },
                AccountIdentifier = accountIdentifier,
                ProgramCode = programCode
            });
        }

    }
}