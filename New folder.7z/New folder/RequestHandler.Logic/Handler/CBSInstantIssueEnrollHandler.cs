﻿using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Model.User.PreInterventions;
using Gd.Bos.RequestHandler.Core.Domain.Services.Crypto;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Core.Infrastructure.DataAccesses;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Logic.Service;
using RequestHandler.Core.Application;
using AccountHolder = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.AccountHolder;
using Address = Gd.Bos.RequestHandler.Core.Domain.Model.User.Address;
using CardExpirationDate = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.CardExpirationDate;
using Email = Gd.Bos.RequestHandler.Core.Domain.Model.User.Email;
using GetAciPackageRequest = RequestHandler.Core.Domain.Services.AciRetailApi.GetAciPackageRequest;
using GetAciPackageResponse = RequestHandler.Core.Domain.Services.AciRetailApi.GetAciPackageResponse;
using KycStateData = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData;
using PaymentInstrument = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PaymentInstrument;
using PhoneNumber = Gd.Bos.RequestHandler.Core.Domain.Model.User.PhoneNumber;
using RequestHeader = Gd.Bos.Shared.Common.Contract.Message.Request.RequestHeader;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using DomainAddress = Gd.Bos.RequestHandler.Core.Domain.Model.User.Address;
using DomainPhoneNumber = Gd.Bos.RequestHandler.Core.Domain.Model.User.PhoneNumber;
using Gd.Bos.Logging.Common.Managers;
using Newtonsoft.Json;
using RequestHandler.Core.Domain.Enums;
using RequestHandler.Core.Domain.Model.User;
using System.Text.RegularExpressions;
using Gd.Bos.Shared.Common.Core.Common.Enum;
using NLog;
using LogManager = NLog.LogManager;
using PaymentInstrumentType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PaymentInstrumentType;
using User = Gd.Bos.RequestHandler.Core.Domain.Model.User.User;

namespace RequestHandler.Logic.Handler
{
    public class CBSInstantIssueEnrollHandler : CommandHandlerBase<CBSInstantIssueEnrollmentRequest, CBSInstantIssueEnrollmentResponse>
    {
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();
        private readonly IRequestDataAccess _requestDataAccess;
        private readonly IEnrollmentDataAccess _enrollmentDataAccess;
        private readonly IEnrollmentService _enrollmentService;
        private readonly ICBSInstantIssueEnrollmentService _cbsInstantIssueEnrollmentService;
        private readonly IPaymentIdentifierRepository _paymentIdentifierRepository;
        private readonly IInstantIssueService _instantIssueService;
        private readonly ICryptoService _cryptoService;
        private readonly IIdempotentService _idempotentService;
        private readonly IAccountService _accountService;
        private readonly ILazyCache _lazyCache;
        private readonly IAgreementDataAccess _agreementRepository;
        private readonly INotificationService _notificationPublisher;
        private readonly IWelcomeNotificationService _welcomeNotificationService;
        private readonly ILockService _lockService;
        private readonly IAddressIntervention _addressIntervention;
        private readonly IProductService _productService;
        private readonly IProgramRepository _programRepository;
        private readonly ITokenizerService _tokenizerService;
        private readonly IBaasConfiguration _baasConfiguration;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IGatewayService _gatewayService;
        private readonly IAciRetailService _aciRetailService;
        private readonly IProspectService _prospectService;
        private readonly ISamplesEnrollService _samplesEnrollService;
        private readonly IUserRepository _userRepository;
        private readonly IProductRepository _productRepository;

        public CBSInstantIssueEnrollHandler(IRequestDataAccess requestDataAccess, IEnrollmentDataAccess enrollmentDataAccess,
            IEnrollmentService enrollmentService, ICryptoService cryptoService,
            IIdempotentService idempotentService,
            IAccountService accountService,
            ILazyCache lazyCache, IAgreementDataAccess agreementRepository,
            INotificationService notificationPublisher,
            IAddressIntervention addressIntervention,
            IWelcomeNotificationService welcomeNotificationService, ILockService lockService,
            IProductService productService, IProgramRepository programRepository, ITokenizerService tokenizerService,
            IBaasConfiguration baasConfiguration,
            IValidateIdentifier validateIdentifier,
            IGatewayService gatewayService, IAciRetailService aciRetailService, ICBSInstantIssueEnrollmentService cbsInstantIssueEnrollmentService,
            IPaymentIdentifierRepository paymentIdentifierRepository, IInstantIssueService instantIssueService,
            IProspectService prospectService, ISamplesEnrollService samplesEnrollService, IUserRepository userRepository,
            IProductRepository productRepository
        )
        {
            _requestDataAccess = requestDataAccess;
            _enrollmentDataAccess = enrollmentDataAccess;
            _enrollmentService = enrollmentService;
            _cryptoService = cryptoService;
            _idempotentService = idempotentService;
            _accountService = accountService;
            _lazyCache = lazyCache;
            _agreementRepository = agreementRepository;
            _notificationPublisher = notificationPublisher;
            _welcomeNotificationService = welcomeNotificationService;
            _lockService = lockService;
            _addressIntervention = addressIntervention;
            _productService = productService;
            _programRepository = programRepository;
            _tokenizerService = tokenizerService;
            _baasConfiguration = baasConfiguration;
            _validateIdentifier = validateIdentifier;
            _gatewayService = gatewayService;
            _aciRetailService = aciRetailService;
            _cbsInstantIssueEnrollmentService = cbsInstantIssueEnrollmentService;
            _paymentIdentifierRepository = paymentIdentifierRepository;
            _instantIssueService = instantIssueService;
            _prospectService = prospectService;
            _samplesEnrollService = samplesEnrollService;
            _userRepository = userRepository;
            _productRepository = productRepository;
        }

        public override Task<CBSInstantIssueEnrollmentResponse> Handle(CBSInstantIssueEnrollmentRequest request)
        {
            try
            {
                string enrollmentRequestIdentifier = null;
                bool? enablePhoneVerification = GetEnablePhoneVerification(request.ProgramCode);
                if (request.RequestHeader.Options != null && request.RequestHeader.Options.ContainsKey("X-GD-EnrollmentRequestIdentifier"))
                {
                    enrollmentRequestIdentifier = request.RequestHeader.Options["X-GD-EnrollmentRequestIdentifier"];
                }

                var denialResponse = DenyRestrictedRegionsEnrollment(request);
                if (denialResponse != null)
                    return denialResponse;

                #region "Request Id"

                var accountLimit = new AccountLimit();
                var newAccountIdentifier = Guid.NewGuid();

                var existingRequestAccountIdentifier = _requestDataAccess.InsertRequestId(RequestType.Enroll,
                    request.RequestHeader.RequestId, newAccountIdentifier);
                #endregion

                #region "Get_Aci_Package_Info"

                if (string.IsNullOrEmpty(request.InstantIssue.MappingIdentifier))
                {
                    return Task.FromResult(new CBSInstantIssueEnrollmentResponse()
                    {
                        ResponseHeader = new ResponseHeader()
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 400,
                            SubStatusCode = 5022,
                            Message = "Mapping Identifier can not be empty"
                        }
                    });
                }

                if (string.IsNullOrEmpty(request.InstantIssue.Type))
                {
                    return Task.FromResult(new CBSInstantIssueEnrollmentResponse()
                    {
                        ResponseHeader = new ResponseHeader()
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 400,
                            SubStatusCode = 6181,
                            Message = "Instant Issue Type can not be empty"
                        }
                    });
                }

                if (request.InstantIssue.Type != EnrollmentType.CBS.ToString() && request.InstantIssue.Type != EnrollmentType.CBSDM.ToString())
                {
                    return Task.FromResult(new CBSInstantIssueEnrollmentResponse()
                    {
                        ResponseHeader = new ResponseHeader()
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 400,
                            SubStatusCode = 6182,
                            Message = "Instant Issue Type Invalid"
                        }
                    });
                }

                //Verify ProductId
                var packageDetails = _aciRetailService.GetPackageDetailsById(new GetAciPackageRequest()
                {
                    ExternalId = request.InstantIssue.MappingIdentifier,
                    RequestHeader = new RequestHeader()
                    {
                        RequestId = request.RequestHeader.RequestId
                    }
                }).Result;

                if (packageDetails.ResponseHeader.StatusCode != 0)
                {
                    return Task.FromResult(new CBSInstantIssueEnrollmentResponse()
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = packageDetails.ResponseHeader.ResponseId,
                            StatusCode = packageDetails.ResponseHeader.StatusCode,
                            SubStatusCode = packageDetails.ResponseHeader.SubStatusCode,
                            Message = packageDetails.ResponseHeader.Message
                        },
                    });
                }

                if (string.IsNullOrEmpty(packageDetails.AlternativePan))
                {
                    return Task.FromResult(new CBSInstantIssueEnrollmentResponse()
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = packageDetails.ResponseHeader.ResponseId,
                            StatusCode = 400,
                            SubStatusCode = 5025,
                            Message = "Alternative Pan is missing from Mapping Identifier info"
                        },
                    });
                }

                //Get Enrollment Type
                var enrollTypeFromRequest = (EnrollmentType)Enum.Parse(typeof(EnrollmentType), request.InstantIssue.Type);
                var enrollType = GetEnrollmentTypeByCardProxy(request.RequestHeader.RequestId, request.ProgramCode, packageDetails.AlternativePan, enrollTypeFromRequest);

                //Instant Issue Type should match with Enrollment Type
                if (request.InstantIssue.Type != enrollType.ToString())
                {
                    return Task.FromResult(new CBSInstantIssueEnrollmentResponse()
                    {
                        ResponseHeader = new ResponseHeader()
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 400,
                            SubStatusCode = 6185,
                            Message = "Mapping Identifier is a different type"
                        }
                    });
                }

                #endregion

                #region "AcceptMinors"
                var isAcceptMinorEnrollment = _baasConfiguration.IsAcceptMinorEnrollment(request.ProgramCode, request.AccountCreationData.ProductCode);
                #endregion

                var userIdentifyingData = request.UserCreationData?.IdentifyingData?.ToDomain(isAcceptMinorEnrollment);

                #region "Limit_Verifications"

                if (string.IsNullOrEmpty(userIdentifyingData?.OnBoardingId))
                {
                    accountLimit = _accountService.AccountLimitVerification(userIdentifyingData?.Ssn, string.Empty, userIdentifyingData?.GetIdentityTypeKey().ToString(), false, request.AccountCreationData?.ProductCode, request.ProgramCode);
                    accountLimit.ResponseCode = accountLimit.ResponseCode ?? "0";
                    if (accountLimit.ResponseCode != "0")
                        _lazyCache?.Value?.Set(request.RequestHeader?.RequestId.ToString(), accountLimit.ResponseCode, new TimeSpan(1, 0, 0, 0));
                }
                //If SSN limit succeeds then try phone limit
                if (accountLimit.ResponseCode == "0")
                {
                    var number = !string.IsNullOrEmpty(request.UserCreationData?.PhoneNumbers.FirstOrDefault(p => p.IsDefault)?.Number) ? request.UserCreationData?.PhoneNumbers.FirstOrDefault(p => p.IsDefault)?.Number : request.UserCreationData?.PhoneNumbers.FirstOrDefault()?.Number;
                    accountLimit = _accountService.PhoneLimitVerification(number, "PhoneNumber", request.AccountCreationData?.ProductCode, request.ProgramCode);
                    accountLimit.ResponseCode = accountLimit.ResponseCode ?? "0";
                    if (accountLimit.ResponseCode != "0")
                        _lazyCache?.Value?.Set(request.RequestHeader?.RequestId.ToString(), accountLimit.ResponseCode, new TimeSpan(1, 0, 0, 0));
                }
                var mappedEnrollment = MapCBSInstantIssueEnrollment(request);
                #endregion

                if (request.InstantIssue.Type == EnrollmentType.CBSDM.ToString())
                {
                    return HandleProspectEnroll(mappedEnrollment, enrollmentRequestIdentifier, newAccountIdentifier, packageDetails, existingRequestAccountIdentifier, accountLimit, enablePhoneVerification, isAcceptMinorEnrollment);
                }

                #region "InstantIssue Enroll"

                #region "AccountIdentifier_exists_Update"

                if (existingRequestAccountIdentifier.HasValue || accountLimit.AccountIdentifier != null)
                {
                    newAccountIdentifier = accountLimit.AccountIdentifier == null
                        ? existingRequestAccountIdentifier.Value
                        : accountLimit.AccountIdentifier.ToGuid();

                    _enrollmentService.SaveEnrollRequest(mappedEnrollment, newAccountIdentifier.ToString(), true);

                    var kycStateData = new Gd.Bos.RequestHandler.Core.Domain.Model.Account.KycStateData();
                    var getEnrollmentResponse =
                        _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(newAccountIdentifier.ToString(),
                            request.ProgramCode, true);

                    if (getEnrollmentResponse?.Account != null)
                    {

                        var existingResponse = GetEnrollIdempotentResponse(
                            getEnrollmentResponse,
                            request,
                            packageDetails,
                            newAccountIdentifier);
                        AccountHolder ah = existingResponse.AccountHolders.FirstOrDefault();

                        //Need to set BCD and AccountStatus here. https://pd/browse/GBOS-30134
                        if (ah.User.KycStateData.PendingKycGate == "healthy" &&
                            existingResponse.AccountCycleDay == 0 &&
                            ah.PaymentInstruments != null && ah.PaymentInstruments.Any())
                        {
                            var account = _accountService.GetAccount(existingResponse.AccountIdentifier);
                            //warning, if you need to use this account, it will only have the accountIdentifier and accountKey
                            string status = existingResponse.Status;
                            short? accountCycleDay = 0;
                            _idempotentService.FinishSettingBillCycle(account, request.ProgramCode, request.RequestHeader.RequestId, out accountCycleDay, out status);
                            existingResponse.Status = status;
                            existingResponse.AccountCycleDay = accountCycleDay;
                            existingResponse.StatusReasons = new List<string>
                            {
                                Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountStatusReason.healthy.ToString()
                            };
                        }

                        return Task.FromResult(existingResponse);
                    }
                }
                #endregion

                var responseHeaderForMappingIdentifier = CheckMappingIdentifierInUse(packageDetails);

                if (responseHeaderForMappingIdentifier != null)
                {
                    return Task.FromResult(new CBSInstantIssueEnrollmentResponse()
                    { ResponseHeader = responseHeaderForMappingIdentifier });
                }

                if (request.AccountCreationData == null)
                {
                    throw new ArgumentNullException("Enroll: AccountCreationData");
                }

                var programCode = request.ProgramCode;
                var productCode = request.AccountCreationData.ProductCode;
                var productMaterialType = request.AccountCreationData.ProductMaterialType;

                _enrollmentService.SaveEnrollRequest(mappedEnrollment, newAccountIdentifier.ToString(), false);

                //For now is retrieved from Core as defaultSetting into Cassandra InstantIssue
                if (!string.IsNullOrEmpty(productMaterialType))
                {
                    if (!_productService.IsValidProductMaterialTypeForProductTier(programCode, productMaterialType))
                        throw new InvalidProductMaterialException("Invalid Product Material type");
                }
                else if (string.IsNullOrEmpty(productMaterialType) && request.RequestPhysicalCardFlag == false)
                {
                    request.AccountCreationData.ProductMaterialType = GetDefaultProductMaterialType(programCode, productCode);
                }

                #region "Fill_Data_from_Payload"

                var response = new CBSInstantIssueEnrollmentResponse();
                var userName = new UserName(request.UserCreationData?.ProfileData?.FirstName,
                    request.UserCreationData?.ProfileData?.MiddleName, request.UserCreationData?.ProfileData?.LastName);

                var email = request.UserCreationData?.Email?.ToDomain();

                var businessAccount = request.UserCreationData?.BusinessData?.ToDomain();
                if (businessAccount != null)
                {
                    businessAccount.AccountType = request.AccountCreationData?.AccountType;
                    if (businessAccount.BusinessType == 0)
                        throw new ValidationException(600, 0, "Invalid BusinessType");
                }

                var businessAddress = request.UserCreationData?.BusinessData?.BusinessAddress?.ToDomain();

                var addresses =
                    request.UserCreationData?.ProfileData?.Addresses?.ToDomain();

                var phoneNumbers =
                    request.UserCreationData?.PhoneNumbers?.ToDomain();

                var agreement =
                    _agreementRepository.GetAgreementsByProductCode(request.AccountCreationData.ProductCode);

                var terms = request.AccountCreationData.TermsAcceptances?.ToDomain(agreement);

                #region "Verify_MinorEnrollment_agreemet"

                if (isAcceptMinorEnrollment && userIdentifyingData.IsMinor)
                {
                    if (!agreement.CheckExistAgreementForMinorEnroll())
                        throw new ValidationException(600, 0,
                            "Agreement for Additional Consent is not available for this Product Code");

                    if (request.AccountCreationData.TermsAcceptances == null || !request.AccountCreationData.TermsAcceptances.CheckExistAgreementForMinorEnroll())
                        throw new ValidationException(600, 0,
                            "Agreement for Additional Consent is not available on request or is not accepted");
                }
                #endregion

                var homeAddress = addresses.FirstOrDefault(add => add.AddressTypeKey == (short)AddressType.Home);

                if (businessAddress != null && homeAddress.IsDefault == false)
                {
                    businessAddress.IsBusinessAddressForPostal = true;
                }
                _addressIntervention.SetHomeAddressToDefault(addresses);

                _addressIntervention.ValidAddresses(addresses, true);

                #endregion

                #region "enroll"
                var enrollResponse = _cbsInstantIssueEnrollmentService.CBSInstantIssueEnroll(
                                    request.RequestHeader.RequestId,
                                    packageDetails,
                                    newAccountIdentifier.ToString(),
                                    request.ProgramCode,
                                    request.AccountCreationData.ProductCode,
                                    userName,
                                    userIdentifyingData,
                                    email,
                                    addresses,
                                    phoneNumbers,
                                    request.ContactVerificationIdentifiers,
                                    request.ExecuteKycFlag,
                                    request.RequestPhysicalCardFlag,
                                    terms,
                                    productMaterialType,
                                    request.AccountCreationData.CipLevel,
                                    request.AccountCreationData.ProductClass,
                                    businessAccount,
                                    businessAddress,
                                    request.AccountCreationData.Language,
                                    enablePhoneVerification: enablePhoneVerification ?? false,
                                    overrideAddressStandardization: true, // ceridian should not be calling QAS, setting override flag to true for now until there is a product level configuration
                                    request.FraudData,
                                    request.AccountCreationData.FraudData,
                                    request.RequestHeader.Source,
                                    enrollmentRequestIdentifier
                                    );

                #endregion

                #region "Retrieve_From_Enroll"

                var newUser = enrollResponse.Item2;
                var newAccount = enrollResponse.Item1;
                var newPaymentIdentifier = enrollResponse.Item3;
                var newAccountBalance = enrollResponse.Item4;
                var privateCardData = enrollResponse.Item5;

                string errorCode = _lazyCache?.Value?.Get<string>(request.RequestHeader?.RequestId.ToString());
                if (!string.IsNullOrEmpty(errorCode) && errorCode != "0")
                {
                    response.ResponseHeader = response.ResponseHeader.GetResponseHeader(errorCode, request.RequestHeader.RequestId);
                }
                else
                {
                    response.ResponseHeader = response.ResponseHeader.GetResponseHeader(newAccount.ErrorCode.ToString(), request.RequestHeader.RequestId);
                    _lazyCache?.Value?.Set(request.RequestHeader?.RequestId.ToString(), newAccount.ErrorCode.ToString(), new TimeSpan(1, 0, 0, 0));
                }

                response.AccountIdentifier = newAccount.AccountIdentifier.ToString();
                response.CustomerReferenceNumber = newAccount.CustomerAccountNumber;
                response.Status = newAccount.AccountStatus.ToString().ToLower();


                DateTime accountStatusDateChange = newAccount.AccountStatusChangedDateTime;
                accountStatusDateChange = accountStatusDateChange.ToUniversalTime();
                response.AccountStatusChangedDateTime =
                    accountStatusDateChange.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");


                if (newAccount.AccountStatusReasons?.Count > 0)
                {
                    response.StatusReasons = new List<string>();

                    foreach (Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountStatusReason statusReason in newAccount
                        .AccountStatusReasons)
                    {
                        response.StatusReasons.Add(statusReason.ToString());
                    }
                }

                response.DirectDepositInformation = new DirectDepositInformation
                {
                    AccountNumber = newAccount.AccountNumber,
                    RoutingNumber = newAccount.RoutingNumber
                };


                if (newAccountBalance != null)
                {
                    response.Purses = new List<Purse>();
                    var purse = new Purse
                    {
                        PurseIdentifier = newAccountBalance.AccountBalanceIdentifier.ToString(),
                        PurseType = PurseType.Primary,
                        AvailableBalance = newAccountBalance.AvailableBalance,
                        LedgerBalance = newAccountBalance.CurrentBalance,
                        AvailableBalanceAsOfDateTime = newAccountBalance.AvailableBalanceAsOfDate,
                        LedgerBalanceAsOfDateTime = newAccountBalance.CurrentBalanceAsOfDate,
                        Status = newAccountBalance.Status
                    };
                    response.Purses.Add(purse);
                }

                response.AccountHolders = new List<AccountHolder>();
                var accountHolder = new AccountHolder();

                foreach (Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolder ah in newAccount.AccountHolders)
                {
                    accountHolder.User = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.User
                    {
                        UserIdentifier = newUser.UserIdentifier.ToString(),
                        Status = UserStatus.Active,
                        IsPrimaryAccountHolder = true,
                        KycStateData = new KycStateData
                        {
                            OfacStatus = ah.kycStateData.OfacStatus.ToString().ToLower(),
                            KycStatus = ah.kycStateData.KycStatus.ToString().ToLower(),
                            PendingKycGate = ah.kycStateData.KycPendingGate.ToLower()
                        }
                    };


                    if (newPaymentIdentifier != null)
                    {
                        accountHolder.PaymentInstruments = new List<PaymentInstrument>();
                        var paymentInstrument = new PaymentInstrument();
                        //PaymentInstrumentStatus paymentInstrumentStatus;
                        Enum.TryParse(newPaymentIdentifier.PaymentInstrument.Status, out PaymentInstrumentStatus paymentInstrumentStatus);

                        paymentInstrument.PaymentIdentifier = newPaymentIdentifier.PaymentIdentifierIdentifier.ToString();
                        paymentInstrument.PaymentInstrumentIdentifier = newPaymentIdentifier?.PaymentInstrument
                            .PaymentInstrumentIdentifier.ToString();
                        paymentInstrument.PaymentInstrumentType =
                            newPaymentIdentifier.PaymentInstrument.PaymentInstrumentType;
                        paymentInstrument.Status = paymentInstrumentStatus;
                        paymentInstrument.IsPinSet = newPaymentIdentifier.PaymentInstrument.PinSetDate.HasValue;
                        paymentInstrument.Last4Pan = newPaymentIdentifier?.PaymentInstrument.Last4Pan;
                        paymentInstrument.ActivatedDateTime = newPaymentIdentifier?.PaymentInstrument.ActivatedDateTime;
                        paymentInstrument.IssuedDateTime = newPaymentIdentifier?.PaymentInstrument.IssuedDateTime;

                        if (privateCardData != null)
                        {
                            paymentInstrument.PrivateCardData =
                                new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PrivateCardData
                                {
                                    Pan = privateCardData?.Pan,
                                    Cvv = privateCardData?.Cvv,
                                    ExpirationDate = new CardExpirationDate
                                    {
                                        CardExpirationMonth = privateCardData?.CardExpirationDate.CardExpirationMonth,
                                        CardExpirationyear = privateCardData?.CardExpirationDate.CardExpirationYear
                                    }
                                };

                            if (paymentInstrument.PaymentInstrumentType == PaymentInstrumentType.Virtual)
                                paymentInstrument.IsPrivateDataViewable = "true";
                        }

                        accountHolder.PaymentInstruments.Add(paymentInstrument);
                    }

                    response.AccountHolders.Add(accountHolder);
                }

                var accountResp = _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(newAccount.AccountIdentifier.ToString(), request.ProgramCode, false);
                response.AccountCycleDay = accountResp.Account.AccountCycleDay;

                _notificationPublisher.PublishNotification(request.ProgramCode, accountResp.Account, EventType.AccountUpdated, request.RequestHeader.RequestId.ToString());
                if (accountResp.Account.Status == "normal")
                {
                    _welcomeNotificationService.RaiseWelcomeNotification(request.ProgramCode, accountResp.Account.AccountIdentifier, request.RequestHeader.RequestId);
                    Task.Run(async () =>
                    {
                        await _gatewayService.SendTokenEmailInBux(request.ProgramCode, response.AccountIdentifier, response.AccountHolders?.FirstOrDefault()?.User.UserIdentifier, request.RequestHeader.RequestId);
                    });
                }
                else if (_accountService.IsDeclinedAccount(accountResp.Account))
                    _welcomeNotificationService.RaiseUnwelcomeNotification(request.ProgramCode, accountResp.Account.AccountIdentifier, request.RequestHeader.RequestId);

                return Task.FromResult(response);
                #endregion

                #endregion
            }
            catch (InvalidProductMaterialException e)
            {
                var response = new CBSInstantIssueEnrollmentResponse()
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 4,
                        SubStatusCode = 312,
                        Message = e.Message
                    },
                };
                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CBSInstantIssueEnrollmentResponse>(e, request));
            }
        }

        private bool? GetEnablePhoneVerification(string programCode)
        {
            if (string.IsNullOrWhiteSpace(programCode))
                return null;

            // Skip PhoneVerification for Ceridian per https://pd.nextestate.com/browse/GBOS-85419
            if (programCode.ToLowerInvariant() == "dayforce")
                return false;

            return null;
        }

        public override void ReleaseLock(CBSInstantIssueEnrollmentRequest request)
        {
            _lockService.ReleaseApiLock(OptionsContext.Current.GetString("requestId"));
            _lockService.ReleaseApiLock(DomainContext.Current.TokenizedIdentity);
        }

        private Task<CBSInstantIssueEnrollmentResponse> DenyRestrictedRegionsEnrollment(CBSInstantIssueEnrollmentRequest request)
        {
            var state = request?.UserCreationData?.ProfileData?.Addresses?.FirstOrDefault()?.State;
            if (_baasConfiguration.IsPRAddressAllowed(request.ProgramCode))
            {
                if (state != null && state.Equals("GU", StringComparison.InvariantCultureIgnoreCase))
                {
                    return Task.FromResult(new CBSInstantIssueEnrollmentResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 5,
                            SubStatusCode = 65,
                            Message = "This product may not be registered in the requested region"
                        }
                    });
                }
            }
            else if (state != null && (state.Equals("PR", StringComparison.InvariantCultureIgnoreCase) ||
                state.Equals("GU", StringComparison.InvariantCultureIgnoreCase)))
            {
                return Task.FromResult(new CBSInstantIssueEnrollmentResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 5,
                        SubStatusCode = 65,
                        Message = "This product may not be registered in the requested region"
                    }
                });
            }

            return null;
        }

        private CBSInstantIssueEnrollmentResponse GetEnrollIdempotentResponse(
                                                           GetEnrollmentResponse getEnrollmentResponse,
                                                           CBSInstantIssueEnrollmentRequest request,
                                                           GetAciPackageResponse aciPackageDetails,
                                                           Guid? existingRequestAccountIdentifier)
        {
            var errorCode = _lazyCache?.Value?.Get<string>(request.RequestHeader?.RequestId.ToString());
            // keep only activated virtual as first enrollment does not 
            // return the magStripe payment instrument
            foreach (var ah in getEnrollmentResponse.Account.AccountHolders)
            {
                if (request.UserCreationData?.IdentifyingData != null
                    && ah?.User?.DateOfBirth != request.UserCreationData?.IdentifyingData?.DateOfBirth)
                    throw new RequestHandlerException(2, 60, "Number of Active Accounts Exceeded.");

                if (string.IsNullOrEmpty(request.UserCreationData?.IdentifyingData?.OnBoardingId) && string.IsNullOrEmpty(request.UserCreationData?.IdentifyingData?.Ssn))
                    _accountService.AccountLimitVerificationBySsnToken(ah?.SsnToken, request.AccountCreationData?.ProductCode, request?.ProgramCode);

                if (ah.PaymentInstruments == null && getEnrollmentResponse?.Account?.Status?.ToLower() == "pending")
                {

                    Tuple<UserName, List<Address>, List<PhoneNumber>,
                        PaymentInstrumentUpdateInfo, Gd.Bos.RequestHandler.Core.Domain.Model.Account.Account, AccountPrimaryConsumerProfile, Email> userData =
                        _paymentIdentifierRepository.GetByAccountIdentifierUserIdentifier(
                            AccountIdentifier.FromString(getEnrollmentResponse.Account.AccountIdentifier), UserIdentifier.FromString(ah.User?.UserIdentifier));
                    var user = new User(ah.User?.UserIdentifier
                        , ProgramCode.FromString(request.ProgramCode)
                        , new UserName(ah.User?.FirstName, string.Empty, ah.User?.LastName)
                        , userData.Item7
                        , new UserIdentifyingData(ah.User?.DateOfBirth, null, null, null)
                        , ah.SsnToken);
                    userData.Item2.ForEach(user.AddAddress);
                    userData.Item3.ForEach(user.AddPhoneNumber);
                    if (CheckMappingIdentifierInUse(aciPackageDetails) != null)
                    {
                        throw new RequestHandlerException(400, 5012, "Mapping Identifier is already in use");
                    }

                    _instantIssueService.RegisterInstantIssueCard(
                       request.RequestHeader.RequestId,
                       request.ProgramCode,
                       getEnrollmentResponse.Account.ProductCode,
                       getEnrollmentResponse.Account.AccountIdentifier,
                       aciPackageDetails.ExternalId,
                       aciPackageDetails.AlternativePan,
                       userData?.Item5, user);

                    getEnrollmentResponse = _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(
                        existingRequestAccountIdentifier.Value.ToString(), request.ProgramCode, true);
                }
            }

            // var paymentInst
            var existingResponse = new CBSInstantIssueEnrollmentResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                },
                AccountIdentifier = getEnrollmentResponse.Account.AccountIdentifier,
                CustomerReferenceNumber = getEnrollmentResponse.Account.CustomerReferenceNumber,
                Status = getEnrollmentResponse.Account.Status,
                StatusReasons = getEnrollmentResponse.Account.StatusReasons,
                StatusCure = getEnrollmentResponse.Account.StatusCure,
                DirectDepositInformation = getEnrollmentResponse.Account.DirectDepositInformation,
                Purses = getEnrollmentResponse.Account.Purses,
                AccountHolders = getEnrollmentResponse.Account.AccountHolders,
                AccountStatusChangedDateTime = getEnrollmentResponse.Account?.AccountStatusChangedDateTime,
                AccountCycleDay = getEnrollmentResponse.Account.AccountCycleDay
            };

            foreach (var accHolder in existingResponse.AccountHolders)
            {
                accHolder.User.PeerTransferAcceptPreference = null;
                accHolder.AccountHolderIdentifier = null;
            }

            if (!string.IsNullOrEmpty(errorCode))
                existingResponse.ResponseHeader =
                    existingResponse.ResponseHeader?.GetResponseHeader(errorCode,
                        request.RequestHeader.RequestId);

            var existingPaymentInstrument = existingResponse.AccountHolders.FirstOrDefault()
                ?.PaymentInstruments?.FirstOrDefault();
            var existingPrivateCardData = existingPaymentInstrument?.PrivateCardData;

            if (existingPrivateCardData != null
                && existingPaymentInstrument.PaymentInstrumentType == PaymentInstrumentType.Virtual)
            {
                var generateCvvResponse = _cryptoService.GenerateCvv(
                    AccountIdentifier.FromString(getEnrollmentResponse.Account.AccountIdentifier),
                    existingPrivateCardData.Pan,
                    existingPrivateCardData.ExpirationDate.CardExpirationyear.Substring(2) +
                    existingPrivateCardData.ExpirationDate.CardExpirationMonth,
                    existingPaymentInstrument.PaymentInstrumentType);

                existingPrivateCardData.Pan = existingPrivateCardData.Pan;
                existingPrivateCardData.Cvv = generateCvvResponse.Cvv;
            }


            if (existingPrivateCardData != null && _baasConfiguration.IsPinSetNeed(request.ProgramCode, existingPaymentInstrument?.IsPinSet) == false)
                existingPaymentInstrument.PrivateCardData = null;

            var accountResp = _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(getEnrollmentResponse.Account.AccountIdentifier, request.ProgramCode, false);
            _notificationPublisher.PublishNotification(request.ProgramCode, accountResp.Account, EventType.AccountUpdated);

            return existingResponse;
        }

        private string GetDefaultProductMaterialType(string programCode, string productCode)
        {
            var productMaterialType = string.Empty;
            var prg = _programRepository.GetByProgramIdentifier(ProgramCode.FromString(programCode));
            var prgInfo = _programRepository.GetProgramTierInfo(prg.ProgramKey);
            var valueList = prgInfo.ProductTiers.Where(p => p.ProductCode.Equals(productCode, StringComparison.InvariantCultureIgnoreCase) && p.ProductTierAttribute == "CardStock" && p.IsDefault).ToList();

            var processor = _enrollmentDataAccess.GetProcessorByProductCode(productCode);
            var defaultProductMaterialTypeList = prgInfo.ProductmaterialTypes?.Where(pt => pt.ProcessorKey == (int)processor && pt.IsDefault);

            if (defaultProductMaterialTypeList != null)
            {
                foreach (var defaultProductMaterialType in defaultProductMaterialTypeList)
                {
                    if (valueList.Exists(v => v.Value.Equals(defaultProductMaterialType.ProcessorValue, StringComparison.InvariantCultureIgnoreCase)))
                    {
                        productMaterialType = defaultProductMaterialType.ProductMaterialType;
                        break;
                    }
                }
            }

            if (productMaterialType == null)
            {
                throw new InvalidProductMaterialException($"Can not find proper Product Material type for programCode {programCode}, productCode {productCode}");
            }

            return productMaterialType;
        }

        public override void SetDomainContext(CBSInstantIssueEnrollmentRequest request)
        {
            if (!string.IsNullOrEmpty(request.UserCreationData.IdentifyingData?.Ssn))
                DomainContext.Current.TokenizedIdentity = _tokenizerService.TokenizeSsn(request.UserCreationData.IdentifyingData.Ssn, DomainContext.Current.ProgramCode.ToString());

            DomainContext.Current.IgnoreMfa = request.RequestHeader?.IgnoreMfa;

        }

        public override Task<CBSInstantIssueEnrollmentResponse> VerifyIdentifiers(CBSInstantIssueEnrollmentRequest request)
        {
            _validateIdentifier.ValidateProduct(ProgramCode.FromString(request.ProgramCode),
                ProductCode.FromString(request.AccountCreationData.ProductCode));
            return Task.FromResult(new CBSInstantIssueEnrollmentResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override async Task<CBSInstantIssueEnrollmentResponse> ObtainLock(CBSInstantIssueEnrollmentRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock(OptionsContext.Current.GetString("requestId"));
                await _lockService.ObtainApiLock(DomainContext.Current.TokenizedIdentity);

                return new CBSInstantIssueEnrollmentResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<CBSInstantIssueEnrollmentResponse>(e, request);
            }
        }

        private ResponseHeader CheckMappingIdentifierInUse(GetAciPackageResponse packageDetails)
        {
            ResponseHeader responseHeader = null;
            if (!string.IsNullOrEmpty(packageDetails.Status) || !string.IsNullOrEmpty(_instantIssueService
                    .GetInstantIssueCardInventoryByMappingIdentifier(packageDetails.ExternalId).ToString()))
            {
                responseHeader = new ResponseHeader
                {
                    ResponseId = packageDetails.ResponseHeader.ResponseId,
                    StatusCode = 400,
                    SubStatusCode = 5012,
                    Message = "Mapping Identifier is already in use"
                };
            }

            return responseHeader;
        }

        private EnrollRequest MapCBSInstantIssueEnrollment(CBSInstantIssueEnrollmentRequest cbsInstantIssueEnrollmentRequest)
        {
            return new EnrollRequest()
            {
                RequestHeader = cbsInstantIssueEnrollmentRequest.RequestHeader,
                ProgramCode = cbsInstantIssueEnrollmentRequest.ProgramCode,
                ContactVerificationIdentifiers = cbsInstantIssueEnrollmentRequest.ContactVerificationIdentifiers,
                UserCreationData = cbsInstantIssueEnrollmentRequest.UserCreationData,
                AccountCreationData = cbsInstantIssueEnrollmentRequest.AccountCreationData,
                ExecuteKycFlag = cbsInstantIssueEnrollmentRequest.ExecuteKycFlag,
                RequestPhysicalCardFlag = cbsInstantIssueEnrollmentRequest.RequestPhysicalCardFlag,
                OverrideAddressStandardization = cbsInstantIssueEnrollmentRequest.OverrideAddressStandardization,
                FraudData = cbsInstantIssueEnrollmentRequest.FraudData
            };
        }

        private Task<CBSInstantIssueEnrollmentResponse> HandleProspectEnroll(EnrollRequest request, string enrollmentRequestIdentifier, Guid newAccountIdentifier,
            GetAciPackageResponse cardDetails, Guid? existingRequestAccountIdentifier, AccountLimit accountLimit, bool? enablePhoneVerification = null, bool acceptMinors = false)
        {
            Logger.Info($"RequestId:{request.RequestHeader.RequestId}: Start to HandleProspectEnroll");
            UserName userName;
            var addresses = new List<DomainAddress>();
            var phoneNumbers = new List<DomainPhoneNumber>();
            List<DomainTermsAcceptance> terms = new List<DomainTermsAcceptance>();
            Email email;
            string cardProxy = cardDetails.AlternativePan;
            string dateOfBirth = null;
            string ssn = null;
            string ssnToken = null;
            SourceSystem? sourceSystem = null;
            if (!string.IsNullOrWhiteSpace(request.RequestHeader?.Source))
            {
                if (Enum.TryParse(request.RequestHeader.Source, true, out SourceSystem ss))
                {
                    sourceSystem = ss;
                }
            }

            //1.GetProspectDetailsByCardProxy
            var prospectDetail = _prospectService.GetProspectDetails(new Core.Domain.Services.GetProspectDetailsRequest()
            {
                Header = new Gd.Bos.Shared.Common.Dcpp.Contract.Message.RequestHeader
                {
                    RequestId = request.RequestHeader.RequestId
                },
                ProgramCode = request.ProgramCode,
                CardProxy = cardProxy
            });

            if (prospectDetail.ResponseHeader?.StatusCode != 0)
            {
                return Task.FromResult(new CBSInstantIssueEnrollmentResponse()
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 400,
                        SubStatusCode = prospectDetail.ResponseHeader.StatusCode,
                        Message = prospectDetail.ResponseHeader.StatusMessage
                    }
                });
            }

            #region validation & init UserData
            if (request.UserCreationData?.PhoneNumbers.FirstOrDefault() == null || request.UserCreationData?.IdentifyingData.Ssn == null)
                throw new ValidationException(101, 0, "UserData:Ssn,Phone is required in DM flow");

            if (request.UserCreationData?.ProfileData.Addresses.FirstOrDefault() != null)
                request.UserCreationData?.ProfileData?.Addresses?.ForEach(address =>
                {
                    addresses.Add(new DomainAddress
                    {
                        State = address.State,
                        AddressLine1 = address.AddressLine1,
                        AddressLine2 = address.AddressLine2,
                        City = address.City,
                        Type = address.Type,
                        ZipCode = address.ZipCode,
                        IsDefault = address.IsDefault,
                        IsVerified = address.IsVerified
                    });
                });
            else
            {
                addresses.Add(new DomainAddress
                {
                    State = prospectDetail.Address.State,
                    AddressLine1 = prospectDetail.Address.AddressLine,
                    AddressLine2 = prospectDetail.Address.AddressLine2,
                    City = prospectDetail.Address.City,
                    Type = AddressType.Home.ToString(),
                    ZipCode = prospectDetail.Address.ZipCode,
                    IsDefault = true,
                    IsVerified = true
                });
            }

            if (!string.IsNullOrWhiteSpace(request.UserCreationData?.ProfileData?.FirstName))
            {
                var userProfile = request.UserCreationData?.ProfileData;

                if (!string.Equals(userProfile.FirstName, prospectDetail.FirstName, StringComparison.OrdinalIgnoreCase) ||
                    !string.Equals(userProfile.LastName, prospectDetail.LastName, StringComparison.OrdinalIgnoreCase))
                {
                    throw new ValidationException(600, 6184, "Mapping Identifier Error: DM UserName not match");
                }

                userName = new UserName(userProfile.FirstName, userProfile.MiddleName, userProfile.LastName);
            }
            else
            {
                userName = new UserName(prospectDetail.FirstName, null, prospectDetail.LastName);
            }

            request.UserCreationData.PhoneNumbers?.ForEach(phone =>
                phoneNumbers.Add(new PhoneNumber()
                {
                    Type = phone.Type,
                    IsDefault = phone.IsDefault,
                    IsVerified = phone.IsVerified,
                    Number = phone.Number
                }));

            email = request.UserCreationData.Email.ToDomain();
            email.IsPrimary = true;
            dateOfBirth = string.IsNullOrEmpty(request.UserCreationData.ProfileData.DateOfBirth) ?
                request.UserCreationData.IdentifyingData.DateOfBirth :
                request.UserCreationData.ProfileData.DateOfBirth;
            ssnToken = _tokenizerService.TokenizeSsn(request.UserCreationData.IdentifyingData.Ssn, request.ProgramCode);
            ssn = request.UserCreationData.IdentifyingData.Ssn;

            DomainContext.Current.ProspectType = (SampleType)prospectDetail.SampleType;

            if (!string.IsNullOrEmpty(ssnToken))
                DomainContext.Current.TokenizedIdentity = ssnToken;

            #endregion

            //filter symbol for phonenumber and format it
            if (!OptionsContext.Current.ContainsKey("X-Gd-Bos-IgnorePhoneLimits"))
                FilterPhoneNumber(phoneNumbers);

            //2.verifProductCode & Terms Verification
            _programRepository.GetByProgramIdentifier(ProgramCode.FromString(request.ProgramCode));

            _productRepository.GetByProductCode(
                ProductCode.FromString(prospectDetail.ProductCode),
                ProgramCode.FromString(request.ProgramCode));

            Logger.Info($"RequestId:{request.RequestHeader.RequestId}:ProductCode and Program validate Success");

            if (request.AccountCreationData?.TermsAcceptances != null &&
                request.AccountCreationData.TermsAcceptances.Any())
            {
                var brandAgreementTypeResult = _agreementRepository.ValidateBrandAgreementType(
                    request.AccountCreationData.TermsAcceptances,
                    prospectDetail.ProductCode, request.ProgramCode);

                if (brandAgreementTypeResult.ResponseHeader.StatusCode != 0)
                    return Task.FromResult(new CBSInstantIssueEnrollmentResponse()
                    {
                        ResponseHeader = new ResponseHeader()
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = brandAgreementTypeResult.ResponseHeader.StatusCode,
                            SubStatusCode = 0,
                            Details = brandAgreementTypeResult.ResponseHeader.Details
                        }
                    });

                var agreement =
                    _agreementRepository.GetAgreementsByProductCode(prospectDetail.ProductCode);

                var termsResponse = _agreementRepository.IsTermAgreementAccepted(agreement,
                    request.AccountCreationData.TermsAcceptances,
                    prospectDetail.ProductCode,
                    request.RequestHeader.RequestId);

                if (!termsResponse.Item1)
                    return Task.FromResult(new CBSInstantIssueEnrollmentResponse { ResponseHeader = termsResponse.Item2 });

                terms = request.AccountCreationData.TermsAcceptances?.ToDomain(agreement);
                Logger.Info($"RequestId:{request.RequestHeader.RequestId}:Terms Validate Success");
            }

            //3.Copa Verification age>=18
            var userIdentifyingData = new UserIdentifyingData(
                dateOfBirth,
                string.Empty,
                ssn,
                string.Empty,
                acceptMinors);

            //return account information if the prospectId already associated to an existing account
            string prospectInfo = _userRepository.GetAccountIdentifierByProspectId(prospectDetail.ProspectIdentifier);
            string existingAccountIdentifier = null;
            if (!string.IsNullOrWhiteSpace(prospectInfo))
            {
                existingAccountIdentifier = JsonConvert
                    .DeserializeObject<ProspectProfile>(prospectInfo)
                    .AccountIdentifier;

            }

            //Compare AccountIdentifier related to Prospect Data with AccountIdentifier in Request data and AccountIdentifier in Account Limit
            if ((existingRequestAccountIdentifier.HasValue && CompareAccountIdentifiers(existingRequestAccountIdentifier, existingAccountIdentifier)) ||
                (accountLimit.AccountIdentifier != null && CompareAccountIdentifiers(accountLimit?.AccountIdentifier, existingAccountIdentifier)))
            {
                newAccountIdentifier = !string.IsNullOrWhiteSpace(existingAccountIdentifier) ?
                    new Guid(existingAccountIdentifier) : (
                    accountLimit.AccountIdentifier == null
                    ? existingRequestAccountIdentifier.Value
                    : accountLimit.AccountIdentifier.ToGuid());

                var kycStateData = new Gd.Bos.RequestHandler.Core.Domain.Model.Account.KycStateData();

                var getEnrollmentResponse = _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(newAccountIdentifier.ToString(), request.ProgramCode, true);

                if (getEnrollmentResponse?.Account != null)
                {
                    var existingResponse = GetProspectEnrollIdempotentResponse(
                        getEnrollmentResponse,
                        userIdentifyingData,
                        phoneNumbers,
                        kycStateData,
                        existingRequestAccountIdentifier,
                        request.RequestHeader.RequestId,
                        request.ProgramCode,
                        enrollmentRequestIdentifier: enrollmentRequestIdentifier,
                        enablePhoneVerification: enablePhoneVerification);

                    var ah = existingResponse.AccountHolders.FirstOrDefault();

                    //Need to set BCD and AccountStatus here. https://pd/browse/GBOS-30134
                    if (ah?.User?.KycStateData?.PendingKycGate == "healthy" &&
                        existingResponse.AccountCycleDay == 0 && ah.PaymentInstruments != null && ah.PaymentInstruments.Any())
                    {
                        var account = _accountService.GetAccount(existingResponse.AccountIdentifier);
                        //warning, if you need to use this account, it will only have the accountIdentifier and accountKey
                        string status = existingResponse.Status;
                        short? accountCycleDay = 0;

                        accountCycleDay = (short)_accountService.SetBillCycle(
                        request.RequestHeader.RequestId,
                        account.AccountIdentifier.ToString(),
                        request.ProgramCode);

                        existingResponse.Status = status;
                        existingResponse.AccountCycleDay = accountCycleDay;
                        existingResponse.StatusReasons = new List<string>
                        {
                            Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountStatusReason.healthy.ToString()
                        };
                    }

                    return Task.FromResult(existingResponse);
                }
            }

            var responseHeaderForMappingIdentifier = CheckMappingIdentifierInUse(cardDetails);

            if (responseHeaderForMappingIdentifier != null)
            {
                return Task.FromResult(new CBSInstantIssueEnrollmentResponse()
                { ResponseHeader = responseHeaderForMappingIdentifier });
            }

            _accountService.EmailLimitVerification(request.ProgramCode, email?.EmailAddress, 5);

            var sampleType = Enum.IsDefined(typeof(SampleType), prospectDetail.SampleType) ?
                (SampleType)prospectDetail.SampleType : SampleType.Default;

            var enrollResponse = _samplesEnrollService.Enroll(
                newAccountIdentifier.ToString(),
                request.ProgramCode,
                userName,
                userIdentifyingData,
                email,
                addresses,
                phoneNumbers,
                kycFlag: true,
                terms,
                prospectDetail,
                upgradeToEmv: true,
                request.AccountCreationData.FraudData,
                sourceSystem,
                sampleType,
                request.RequestHeader.Source,
                enrollmentRequestIdentifier: enrollmentRequestIdentifier,
                mappingIdentifier: cardDetails.ExternalId,
                phoneProfileVerificationEnabled: enablePhoneVerification ?? false);

            return GenerateResponse(enrollResponse, request);
        }

        private static void FilterPhoneNumber(List<DomainPhoneNumber> phoneNumbers)
        {
            foreach (var entity in phoneNumbers)
            {
                if (string.IsNullOrEmpty(entity.Number))
                    throw new ValidationException(101, 0, "Phone is required");

                var replacedPhone = Regex.Replace(entity.Number, @"[(\)\-]", string.Empty, RegexOptions.Compiled);

                if (!Regex.IsMatch(replacedPhone, @"^[1]?([0-9]{3})([0-9]{3})([0-9]{4})$"))
                    throw new ValidationException(350, 0, "The format of the phonenumber was invalid.");

                entity.Number = replacedPhone;
            }
        }

        private CBSInstantIssueEnrollmentResponse GetProspectEnrollIdempotentResponse(
            GetEnrollmentResponse getEnrollmentResponse,
            UserIdentifyingData userData,
            List<DomainPhoneNumber> phoneNumbers,
            Gd.Bos.RequestHandler.Core.Domain.Model.Account.KycStateData kycStateData,
            Guid? existingRequestAccountIdentifier,
            Guid requestId,
            string programCode,
            string enrollmentRequestIdentifier = null,
            bool? enablePhoneVerification = null)
        {
            Logger.Info($"start GetSamplesEnrollIdempotentResponse requestid:{requestId},programcode:{programCode}, enrollmentRequestIdentifier:{enrollmentRequestIdentifier ?? string.Empty}");

            var errorCode = _lazyCache?.Value?.Get<string>(requestId.ToString());
            Logger.Info($"GetSamplesEnrollIdempotentResponse,requestid:{requestId},errorcode from lazycahce:{errorCode}");

            var errorCodeForProspectIdentifier = GetErrorCodeForProspectidentifier(getEnrollmentResponse?.Account?.Status?.ToLower(),
                getEnrollmentResponse?.Account?.AccountHolders?.FirstOrDefault().User?.KycStateData?.PendingKycGate?.ToLower());
            // keep only activated virtual as first enrollment does not 
            // return the magStripe payment instrument
            foreach (var ah in getEnrollmentResponse.Account.AccountHolders)
            {
                if (ah?.User?.DateOfBirth != userData.DateOfBirth)
                    throw new RequestHandlerException(2, 60, "Number of Active Accounts Exceeded.");


                if ((ah.PaymentInstruments == null && getEnrollmentResponse?.Account?.Status.ToLower() == "pending") ||

                    (ah.PaymentInstruments?.Count(n =>
                     n.PaymentInstrumentType == PaymentInstrumentType.MagStripe ||
                     n.PaymentInstrumentType == PaymentInstrumentType.Emv) == 0)
                     && getEnrollmentResponse?.Account?.Status?.ToLower() == "pending")
                {
                    Gd.Bos.RequestHandler.Core.Domain.Model.Account.KycStateData kycData = ah.User?.KycStateData?.ToDomain();

                    kycStateData = _idempotentService?.EnrollIdempotent(
                        existingRequestAccountIdentifier.Value.ToString(),
                        ah.User?.UserIdentifier,
                        kycData, "pvc",
                        programCode,
                        requestPhysicalCard: true,
                        cipLevel: "kyc",
                        onboardId: null,
                        contactVerificationIdentifiers: null,
                        phoneNumbers,
                        ProductCode.FromString(getEnrollmentResponse.Account.ProductCode),
                        getEnrollmentResponse.Account.ProductName,
                        enablePhoneVerification: enablePhoneVerification ?? false,
                        enrollmentRequestIdentifier: enrollmentRequestIdentifier);

                    if (kycStateData?.KycPendingGate != null)
                        getEnrollmentResponse =
                            _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(
                                existingRequestAccountIdentifier.Value.ToString(), programCode,
                                true);

                    if (kycStateData?.KycPendingGate == "healthy")
                        foreach (var accHolder in getEnrollmentResponse.Account?.AccountHolders)
                            accHolder.PaymentInstruments = accHolder?.PaymentInstruments
                                ?.Where(x => x.PaymentInstrumentType == PaymentInstrumentType.Virtual)
                                .ToList();
                }
            }

            // var paymentInst
            var existingResponse = new CBSInstantIssueEnrollmentResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = requestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                },
                AccountIdentifier = getEnrollmentResponse.Account.AccountIdentifier,
                CustomerReferenceNumber = getEnrollmentResponse.Account.CustomerReferenceNumber,
                Status = getEnrollmentResponse.Account.Status,
                StatusReasons = getEnrollmentResponse.Account.StatusReasons,
                StatusCure = getEnrollmentResponse.Account.StatusCure,
                DirectDepositInformation = getEnrollmentResponse.Account.DirectDepositInformation,
                Purses = getEnrollmentResponse.Account.Purses,
                AccountHolders = getEnrollmentResponse.Account.AccountHolders,
                AccountStatusChangedDateTime = getEnrollmentResponse.Account?.AccountStatusChangedDateTime,
                AccountCycleDay = getEnrollmentResponse.Account.AccountCycleDay
            };

            foreach (var accHolder in existingResponse.AccountHolders)
            {
                accHolder.User.PeerTransferAcceptPreference = null;
                accHolder.AccountHolderIdentifier = null;
            }

            if (!string.IsNullOrEmpty(errorCode))
                existingResponse.ResponseHeader =
                    existingResponse.ResponseHeader?.GetResponseHeader(errorCode,
                        requestId);

            if (!string.IsNullOrWhiteSpace(errorCodeForProspectIdentifier))
                existingResponse.ResponseHeader =
                    existingResponse.ResponseHeader?.GetResponseHeader(errorCodeForProspectIdentifier,
                        requestId);

            var existingPaymentInstrument = existingResponse.AccountHolders.FirstOrDefault()?.PaymentInstruments?.FirstOrDefault();
            var existingPrivateCardData = existingPaymentInstrument?.PrivateCardData;

            if (existingPrivateCardData != null &&
                _baasConfiguration.IsPinSetNeed(programCode, existingPaymentInstrument?.IsPinSet) == false)
                existingPaymentInstrument.PrivateCardData = null;

            _notificationPublisher.PublishNotification(programCode, getEnrollmentResponse.Account, EventType.AccountUpdated);

            return existingResponse;
        }

        private string GetErrorCodeForProspectidentifier(string accountStatus, string kycPendingGate)
        {
            if (accountStatus == "pending" && kycPendingGate == "idv")
                return "110";
            else if (accountStatus == "locked" && kycPendingGate == "manual")
                return "231";
            else if (accountStatus == "locked" && (kycPendingGate == null || kycPendingGate == "none"))
                return "211";
            else
                return null;
        }

        private Task<CBSInstantIssueEnrollmentResponse> GenerateResponse(Tuple<Gd.Bos.RequestHandler.Core.Domain.Model.Account.Account,
            Gd.Bos.RequestHandler.Core.Domain.Model.User.User, PaymentIdentifier, AccountBalance, Gd.Bos.RequestHandler.Core.Application.PrivateCardData, string, Gd.Bos.RequestHandler.Core.Domain.Model.Account.KycStateData> enrollResponse, EnrollRequest request)
        {
            var response = new CBSInstantIssueEnrollmentResponse();
            var newAccount = enrollResponse.Item1;
            var newUser = enrollResponse.Item2;
            var newPaymentIdentifier = enrollResponse.Item3;
            var newAccountBalance = enrollResponse.Item4;
            var privateCardData = enrollResponse.Item5;
            var activationStatus = enrollResponse.Item6;

            Logger.Info(
                $"RequestId:{request.RequestHeader.RequestId}:accountIdentifier:{newAccount.AccountIdentifier} call enroll service returned,{MaskEngine.MaskMessage(JsonConvert.SerializeObject(enrollResponse))}");

            string errorCode = _lazyCache?.Value?.Get<string>(request.RequestHeader?.RequestId.ToString());

            Logger.Info($"GenerateResponse from lazy cache errorcode:{errorCode}");
            if (!string.IsNullOrEmpty(errorCode) && errorCode != "0")
            {
                response.ResponseHeader =
                    response.ResponseHeader.GetResponseHeader(errorCode, request.RequestHeader.RequestId);
            }
            else
            {
                response.ResponseHeader = response.ResponseHeader.GetResponseHeader(newAccount.ErrorCode.ToString(),
                    request.RequestHeader.RequestId);
                _lazyCache?.Value?.Set(request.RequestHeader?.RequestId.ToString(), newAccount.ErrorCode.ToString(),
                    new TimeSpan(1, 0, 0, 0));
            }

            var accountResp =
                _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(newAccount.AccountIdentifier.ToString(),
                    request.ProgramCode, false);
            response.AccountCycleDay = accountResp.Account.AccountCycleDay;
            Logger.Info($"RequestId:{request?.RequestHeader?.RequestId} accountResp from GetEnrollmentByAccountIdentifier，Detail:{JsonConvert.SerializeObject(accountResp)}");

            // Logger.Info($"start response requestid:request.RequestHeader.RequestId,{JsonConvert.SerializeObject(enrollResponse)}");
            response.AccountIdentifier = newAccount.AccountIdentifier.ToString();
            response.CustomerReferenceNumber = accountResp.Account.CustomerReferenceNumber;
            response.Status = newAccount.AccountStatus.ToString().ToLower();

            DateTime accountStatusDateChange = newAccount.AccountStatusChangedDateTime;
            accountStatusDateChange = accountStatusDateChange.ToUniversalTime();
            response.AccountStatusChangedDateTime =
                accountStatusDateChange.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");

            response.StatusReasons = MapStatusReasons(newAccount);
            response.DirectDepositInformation = MapDirectDepositInformation(newAccount);

            if (newAccountBalance != null)
            {
                response.Purses = new List<Purse>();
                var purse = new Purse
                {
                    PurseIdentifier = newAccountBalance.AccountBalanceIdentifier.ToString(),
                    PurseType = PurseType.Primary,
                    AvailableBalance = newAccountBalance.AvailableBalance,
                    LedgerBalance = newAccountBalance.CurrentBalance,
                    AvailableBalanceAsOfDateTime = newAccountBalance.AvailableBalanceAsOfDate,
                    LedgerBalanceAsOfDateTime = newAccountBalance.CurrentBalanceAsOfDate,
                    Status = newAccountBalance.Status
                };
                response.Purses.Add(purse);
            }

            response.AccountHolders = new List<Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.AccountHolder>();
            var accountHolder = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.AccountHolder();

            foreach (Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolder ah in newAccount.AccountHolders)
            {
                accountHolder.User = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.User
                {
                    UserIdentifier = newUser.UserIdentifier.ToString(),
                    Status = UserStatus.Active,
                    IsPrimaryAccountHolder = true,
                    KycStateData = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData
                    {
                        OfacStatus = ah.kycStateData.OfacStatus.ToString().ToLower(),
                        KycStatus = ah.kycStateData.KycStatus.ToString().ToLower(),
                        PendingKycGate = ah.kycStateData.KycPendingGate.ToLower()
                    }
                };

                if (newPaymentIdentifier != null)
                {
                    accountHolder.PaymentInstruments = new List<PaymentInstrument>();
                    var paymentInstrument = new PaymentInstrument();
                    //PaymentInstrumentStatus paymentInstrumentStatus;
                    Enum.TryParse(newPaymentIdentifier.PaymentInstrument.Status,
                        out PaymentInstrumentStatus paymentInstrumentStatus);

                    paymentInstrument.PaymentIdentifier = newPaymentIdentifier.PaymentIdentifierIdentifier.ToString();
                    paymentInstrument.PaymentInstrumentIdentifier = newPaymentIdentifier?.PaymentInstrument
                        .PaymentInstrumentIdentifier.ToString();
                    paymentInstrument.PaymentInstrumentType =
                        newPaymentIdentifier.PaymentInstrument.PaymentInstrumentType;
                    paymentInstrument.Status = paymentInstrumentStatus;
                    paymentInstrument.IsPinSet = newPaymentIdentifier.PaymentInstrument.PinSetDate.HasValue;
                    paymentInstrument.Last4Pan = newPaymentIdentifier?.PaymentInstrument.Last4Pan;
                    paymentInstrument.ActivatedDateTime = newPaymentIdentifier?.PaymentInstrument.ActivatedDateTime;
                    paymentInstrument.IssuedDateTime = newPaymentIdentifier?.PaymentInstrument.IssuedDateTime;

                    if (privateCardData != null)
                    {
                        paymentInstrument.PrivateCardData =
                            new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PrivateCardData
                            {
                                Pan = privateCardData?.Pan,
                                Cvv = privateCardData?.Cvv,
                                ExpirationDate = new CardExpirationDate
                                {
                                    CardExpirationMonth = privateCardData?.CardExpirationDate.CardExpirationMonth,
                                    CardExpirationyear = privateCardData?.CardExpirationDate.CardExpirationYear
                                }
                            };
                    }
                    accountHolder.PaymentInstruments.Add(paymentInstrument);
                }

                response.AccountHolders.Add(accountHolder);
            }

            response.AccountCycleDay = accountResp.Account.AccountCycleDay;

            _notificationPublisher.PublishNotification(request.ProgramCode, accountResp.Account,
                EventType.AccountUpdated, request.RequestHeader.RequestId.ToString());
            if (accountResp.Account.Status.Equals("normal", StringComparison.OrdinalIgnoreCase))
                _welcomeNotificationService.RaiseWelcomeNotification(request.ProgramCode,
                    accountResp.Account.AccountIdentifier, request.RequestHeader.RequestId);

            Logger.Info($"RequestId:{request.RequestHeader.RequestId}:notification send out");

            Logger.Info($"Samples enrollment success, prospectId:{DomainContext.Current.ProspectIdentifier},prospectType:{DomainContext.Current.ProspectType},accountStatus:{accountResp.Account?.Status}");
            return Task.FromResult(response);
        }

        private EnrollmentType GetEnrollmentTypeByCardProxy(Guid requestId, string programCode, string cardProxy, EnrollmentType enrollTypeFromRequest)
        {
            var prospectDetailsRequest = new Core.Domain.Services.GetProspectDetailsRequest()
            {
                Header = new Gd.Bos.Shared.Common.Dcpp.Contract.Message.RequestHeader { RequestId = requestId },
                ProgramCode = programCode,
                CardProxy = cardProxy
            };
            try
            {
                _prospectService.GetProspectDetails(prospectDetailsRequest);
                return EnrollmentType.CBSDM;
            }
            catch (Exception ex)
            {
                if (ex.GetType() != typeof(ValidationException) && enrollTypeFromRequest == EnrollmentType.CBSDM)
                {
                    throw new Exception($"GetProspectDetails did not return a recognizable response.");
                }
                return EnrollmentType.CBS;
            }
        }

        private static bool CompareAccountIdentifiers(Guid? requestAccountIdentifier, string prospectAccountIdentifier)
        {
            return !string.IsNullOrEmpty(prospectAccountIdentifier) && requestAccountIdentifier == new Guid(prospectAccountIdentifier);
        }

        private static List<string> MapStatusReasons(Gd.Bos.RequestHandler.Core.Domain.Model.Account.Account account)
        {
            var result = new List<string>();

            var reasons = account?.AccountStatusReasons;

            if (reasons != null && reasons.Count > 0)
            {
                foreach (var statusReason in reasons)
                {
                    result.Add(statusReason.ToString());
                }
            }
            return result;
        }

        private static DirectDepositInformation MapDirectDepositInformation(Gd.Bos.RequestHandler.Core.Domain.Model.Account.Account account)
        {
            if (account == null) return null;
            return new DirectDepositInformation
            {
                AccountNumber = account.AccountNumber,
                RoutingNumber = account.RoutingNumber
            };
        }
    }
}
