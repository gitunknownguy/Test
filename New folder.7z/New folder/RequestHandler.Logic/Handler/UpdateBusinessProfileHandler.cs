﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Business;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;


namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class UpdateBusinessProfileHandler : CommandHandlerBase<UpdateBusinessProfileRequest, UpdateBusinessProfileResponse>
    {
        private readonly IBusinessProfileService _businessProfileService;
        private readonly IValidateIdentifier _validateIdentifier;

        public UpdateBusinessProfileHandler(IBusinessProfileService businessProfileService
        , IValidateIdentifier validateIdentifier)
        {
            _businessProfileService = businessProfileService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(UpdateBusinessProfileRequest request)
        {
            if (!string.IsNullOrEmpty(request.BusinessProfile.AccountIdentifier))
            {
                DomainContext.Current.AccountIdentifier = request.BusinessProfile.AccountIdentifier;
            }
        }

        public override Task<UpdateBusinessProfileResponse> VerifyIdentifiers(UpdateBusinessProfileRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new UpdateBusinessProfileResponse()
                {
                    ResponseHeader = new ResponseHeader()
                });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpdateBusinessProfileResponse>(e, request));
            }
        }

        public override Task<UpdateBusinessProfileResponse> Handle(UpdateBusinessProfileRequest request)
        {
            var response = new UpdateBusinessProfileResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "success"
                }
            };

            try
            {
                var info = new BusinessProfileInfo
                {
                    AccountIdentifier = new Guid(request.BusinessProfile.AccountIdentifier),
                    Address1 = request.BusinessProfile.Address1,
                    Address2 = request.BusinessProfile.Address2,
                    City = request.BusinessProfile.City,
                    ConsumerProfileType = request.BusinessProfile.ConsumerProfileType,
                    Country = request.BusinessProfile.Country,
                    Email = request.BusinessProfile.Email,
                    Name = request.BusinessProfile.Name,
                    LegalName = request.BusinessProfile.LegalName,
                    EmbossedName = request.BusinessProfile.EmbossedName,
                    State = request.BusinessProfile.State,
                    ZipCode = request.BusinessProfile.ZipCode,
                    PhoneNumber = request.BusinessProfile.PhoneNumber,
                    TaxId = request.BusinessProfile.TaxId,
                    Url = request.BusinessProfile.Url,
                    AvgMonthlyProcessingVolume = request.BusinessProfile.AvgMonthlyProcessingVolume,
                    BusinessIndustry = request.BusinessProfile.BusinessIndustry

                };

                bool isSuccess = _businessProfileService.UpdateBusinessProfile(info, request.ProgramCode, request.RequestHeader.RequestId);

                if (!isSuccess)
                {
                    response.ResponseHeader.StatusCode = 10;
                    response.ResponseHeader.SubStatusCode = 0;
                    response.ResponseHeader.Message = "Business profile not found.";

                    return Task.FromResult(response);
                }

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpdateBusinessProfileResponse>(e, request));
            }
        }
    }
}
