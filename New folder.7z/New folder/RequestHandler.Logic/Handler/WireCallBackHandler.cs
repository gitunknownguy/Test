﻿using System;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using ValidationException = Gd.Bos.RequestHandler.Core.Infrastructure.ValidationException;

namespace RequestHandler.Logic.Handler
{
    public class WireCallBackHandler : CommandHandlerBase<WireCallBackRequest, WireCallBackResponse>
    {
        private readonly ITransferService _transferService;

        public WireCallBackHandler(ITransferService transferService)
        {
            _transferService = transferService;
        }
        public override void SetDomainContext(WireCallBackRequest request)
        {

        }

        public override Task<WireCallBackResponse> VerifyIdentifiers(WireCallBackRequest request)
        {
            return Task.FromResult(new WireCallBackResponse { ResponseHeader = new ResponseHeader() });
        }

        public override Task<WireCallBackResponse> Handle(WireCallBackRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.WireIdentifier) || request.WireIdentifier == Guid.Empty.ToString())
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier, $"{nameof(request)}.WireIdentifier must be specified");
                }

                if (request.CallBackType != WireCallBackType.Completed)
                {
                    throw new ValidationException("callBackType Only support Completed currently.");
                }
                var response = _transferService.WireCallBack(request);
                return Task.FromResult(response);

            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<WireCallBackResponse>(e, request));
            }

        }
    }
}
