﻿using System;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class UpdateFundsAvailableDateHandler : CommandHandlerBase<UpdateFundsAvailableDateRequest, UpdateFundsAvailableDateResponse>
    {
        private static string unspecifiedGuid = Guid.Empty.ToString();
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ITransferService _transferService;
        public UpdateFundsAvailableDateHandler(ITransferService transferService, IValidateIdentifier validateIdentifier)
        {
            _transferService = transferService;

            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(UpdateFundsAvailableDateRequest request)
        {
            //DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<UpdateFundsAvailableDateResponse> VerifyIdentifiers(UpdateFundsAvailableDateRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.ProgramCode);
                return Task.FromResult(new UpdateFundsAvailableDateResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpdateFundsAvailableDateResponse>(e, request));
            }
        }

        public override Task<UpdateFundsAvailableDateResponse> Handle(UpdateFundsAvailableDateRequest request)
        {
            try
            {
                if (request.RequestHeader.RequestId == Guid.Empty)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId,
                        $"{nameof(request)}.RequestHeader.RequestId must be specified");
                }

                if (string.IsNullOrEmpty(request.TransferIdentifier) || request.TransferIdentifier == unspecifiedGuid)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier,
                        $"{nameof(request)}.TransferIdentifier must be specified");
                }

                UpdateFundsAvailableDateResponse response = _transferService.UpdateFundsAvailableDate(request);
                return Task.FromResult(new UpdateFundsAvailableDateResponse()
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "success"
                    },

                });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpdateFundsAvailableDateResponse>(e, request));
            }
        }
    }
}

