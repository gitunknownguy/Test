﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers.Exceptions;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class AchCallbackHandler : CommandHandlerBase<AchCallbackRequest, AchCallbackResponse>
    {
        public AchCallbackHandler(ITransferService transferService, IValidateIdentifier validateIdentifier, ILockService lockService)
        {
            _transferService = transferService;
            _validateIdentifier = validateIdentifier;
            _lockService = lockService;
        }

        public override void SetDomainContext(AchCallbackRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<AchCallbackResponse> VerifyIdentifiers(AchCallbackRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new AchCallbackResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AchCallbackResponse>(e, request));
            }
        }

        public override async Task<AchCallbackResponse> ObtainLock(AchCallbackRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock(DomainContext.Current.AccountIdentifier.ToString());
                return new AchCallbackResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<AchCallbackResponse>(e, request);
            }
        }

        public override void ReleaseLock(AchCallbackRequest request)
        {
            _lockService.ReleaseApiLock(DomainContext.Current.AccountIdentifier.ToString());
        }

        public override Task<AchCallbackResponse> Handle(AchCallbackRequest request)
        {
            try
            {
                var returnType = new List<string> { "achpull", "achout" };
                var callbackType = new List<string> { "complete", "return" };

                if (!(returnType.Contains(request.ReturnType?.ToLower())))
                    throw new InvalidReturnTypeException("Invalid return type.");

                if (!(callbackType.Contains(request.AchCallbackType?.ToLower())))
                    throw new InvalidCallBackTypeException("Invalid callback type.");

                if (request.RequestHeader.RequestId == Guid.Empty)
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId, $"{nameof(request)}.RequestHeader.RequestId must be specified");

                if (request.AchCallbackType != null && request.AchCallbackType.Equals("return", StringComparison.InvariantCultureIgnoreCase))
                {
                    _transferService.ReverseAchTransfer(request.AccountIdentifier,
                        request.TransactionReferenceId,
                        request.AchCallbackType,
                        request.ReturnReasonCode,
                        request.ReturnType,
                        request.ProgramCode);
                }
                if (request.AchCallbackType != null && request.AchCallbackType.Equals("complete", StringComparison.InvariantCultureIgnoreCase))
                {
                    _transferService.CompleteAchTransfer(request.AccountIdentifier,
                        request.TransactionReferenceId,
                        request.AchCallbackType,
                        request.ReturnReasonCode,
                        request.ReturnType,
                        request.ProgramCode);
                }

                var response = new AchCallbackResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                };

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AchCallbackResponse>(e, request));
            }
        }


        private readonly ITransferService _transferService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ILockService _lockService;

        private enum CallBackType
        {

            Return = 1,
            Complete = 2
        }
    }
}
