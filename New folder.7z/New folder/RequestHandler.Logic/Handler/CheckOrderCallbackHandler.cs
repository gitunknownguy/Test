﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers.Exceptions;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class CheckOrderCallbackHandler : CommandHandlerBase<CheckOrderCallbackRequest, CheckOrderCallbackResponse>
    {
        private readonly INotificationService _notificationService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly HashSet<string> _validStatuses = new HashSet<string> { "initiated", "ordered", "declined", "notreceived" };

        public CheckOrderCallbackHandler(INotificationService notificationService, IValidateIdentifier validateIdentifier)
        {
            _notificationService = notificationService;
            _validateIdentifier = validateIdentifier;
        }

        
        public override void SetDomainContext(CheckOrderCallbackRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountID;
        }

        
        public override Task<CheckOrderCallbackResponse> VerifyIdentifiers(CheckOrderCallbackRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new CheckOrderCallbackResponse { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CheckOrderCallbackResponse>(e, request));
            }
        }


        public override Task<CheckOrderCallbackResponse> Handle(CheckOrderCallbackRequest request)
        {
            try
            {
                if (!_validStatuses.Contains(request.CheckBookOrderStatus?.ToLower()))
                    throw new InvalidCallBackTypeException("Invalid status.");

                if (request.RequestHeader.RequestId == Guid.Empty)
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId, $"{nameof(request)}.RequestHeader.RequestId must be specified");

                _notificationService.PublishNotification(request.ProgramCode, new CheckOrderEvent(request), EventType.PaperCheckOrder);

                var response = new CheckOrderCallbackResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                };

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CheckOrderCallbackResponse>(e, request));
            }
        }

        private enum CallBackType
        {

            Return = 1,
            Complete = 2
        }
    }
}
