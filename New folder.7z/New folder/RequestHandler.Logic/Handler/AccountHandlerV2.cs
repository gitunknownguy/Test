﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application.UpgradeAccount;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.UtilityCoreApi.Contract.Enum;
using Newtonsoft.Json;
using NLog;
using RequestHandler.Core.Application;
using RequestHandler.Core.Domain.Model.Inventory;
using RequestHandler.Core.Domain.Model.User;
using RequestHandler.Logic.DataAccess;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    [ExcludeFromCodeCoverage(Justification = "async v2 handler; not used in prod; needs more tests")]
    public class AccountHandlerV2 : CommandHandlerBase<GetAccountRequest, GetAccountResponse>
    {
        private readonly IAsyncAccountDataAccess _accountDataAccess;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IAsyncUserRepository _userRepository;
        private readonly IAsyncInstantIssueCardInventoryRepository _instantIssueCardInventoryRepository;
        private readonly IAsyncContactChangeEligibilityService _contactChangeEligibilityService;
        private readonly IAsyncUpgradeAccountService _upgradeAccountService;
        private readonly IAsyncProductRepository _productRepository;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        public AccountHandlerV2(IAsyncAccountDataAccess accountDataAccess, IValidateIdentifier validateIdentifier, IAsyncUserRepository userRepository,
            IAsyncContactChangeEligibilityService contactChangeEligibilityService, IAsyncInstantIssueCardInventoryRepository instantIssueCardInventoryRepository,
            IAsyncUpgradeAccountService upgradeAccountService, IAsyncProductRepository productRepository)
        {
            _accountDataAccess = accountDataAccess;
            _validateIdentifier = validateIdentifier;
            _userRepository = userRepository;
            _contactChangeEligibilityService = contactChangeEligibilityService;
            _instantIssueCardInventoryRepository = instantIssueCardInventoryRepository;
            _upgradeAccountService = upgradeAccountService;
            _productRepository = productRepository;
        }

        public override void SetDomainContext(GetAccountRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetAccountResponse> VerifyIdentifiers(GetAccountRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetAccountResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetAccountResponse>(e, request));
            }
        }

        public override async Task<GetAccountResponse> Handle(GetAccountRequest request)
        {
            var stopwatch = Stopwatch.StartNew();
            try
            {
                var getAccountResponse = await _accountDataAccess.GetAccountByAccountIdentifier(request.AccountIdentifier,
                    request.ProgramCode, request.IncludePrivatePaymentInstrumentData);

                if (getAccountResponse == null)
                {
                    throw new AccountNotFoundException();
                }

                var accountHolders = getAccountResponse.Account?.AccountHolders;
                Task<string> prospectIdTask = null;
                if (accountHolders != null && accountHolders.Count > 0)
                {
                    var userIdentifier = accountHolders[0].User?.UserIdentifier;
                    if (!string.IsNullOrEmpty(userIdentifier))
                    {
                        var consumerProfileExtensionsTask = _userRepository.GetConsumerProfileExtension(userIdentifier);
                        prospectIdTask = consumerProfileExtensionsTask.ContinueWith(task =>
                        {
                            var consumerProfileExtensions = task.Result;
                            var prospectInfo = consumerProfileExtensions.FirstOrDefault(c => c.ConsumerProfileExtensionAttributeKey == (int)ConsumerProfileExtensionAttribute.ProspectProfile);
                            if (prospectInfo != null)
                            {
                                return JsonConvert
                                    .DeserializeObject<ProspectProfile>(prospectInfo.ConsumerProfileExtensionAttributeValue)
                                    .ProspectIdentifier;
                            }
                            return null;
                        }, TaskContinuationOptions.OnlyOnRanToCompletion);

                    }
                }

                // Initialize tasks to execute concurrently to improve performance
                var productTask = _productRepository.GetByProductCode(ProductCode.FromString(getAccountResponse.Account.ProductCode));
                var productTierInfoTask = _upgradeAccountService.GetProductTierByProgramCode(request.ProgramCode);
                var productTierKeyTask = _accountDataAccess.GetAccountProductTierKey(request.AccountIdentifier, request.ProgramCode);

                // Wait for tasks to complete
                await Task.WhenAll(productTask, productTierInfoTask, productTierKeyTask);

                // Get the results of the tasks
                var productTierInfo = productTierInfoTask.Result;
                var productTierKey = productTierKeyTask.Result;
                var targetUserType = productTierInfo.ProductTiers.FirstOrDefault(x =>
                    x.ProductTierKey == productTierKey && x.ProductTierAttributeKey == 33 &&
                    x.ProductTierAttribute == "TargetUserType")?.Value;

                var product = productTask.Result;
                getAccountResponse.Account.BankName = product?.BankName;
                getAccountResponse.Account.TargetUserType = targetUserType;

                if (prospectIdTask != null)
                {
                    getAccountResponse.ProspectIdentifier = await prospectIdTask;
                }

                if (request.ProgramCode.Equals("credibly", StringComparison.OrdinalIgnoreCase))
                {
                    var individualAccountHolderCure = getAccountResponse.Account?.AccountHolders?
                        .Where(item => item.User.IsPrimaryAccountHolder)?.FirstOrDefault()?.User.KycStateData.PendingKycGate;

                    if (individualAccountHolderCure != null)
                    {
                        if ((individualAccountHolderCure.Equals("Healthy", StringComparison.OrdinalIgnoreCase) || individualAccountHolderCure.Equals("Manual", StringComparison.OrdinalIgnoreCase))
                            && getAccountResponse.Account.AccountHolders.Any(item => item.User.KycStateData.PendingKycGate == Core.Domain.Model.Account.AccountHolderCure.IDV.ToString().ToLower()))
                        {
                            getAccountResponse.Account.AccountHolders.FirstOrDefault(d => d.User.IsPrimaryAccountHolder).User.KycStateData.PendingKycGate = "idv";
                            getAccountResponse.Account.AccountHolders.FirstOrDefault(d => d.User.IsPrimaryAccountHolder).User.KycStateData.KycStatus = "failed";
                        }

                        if (getAccountResponse.Account.AccountHolders.Any(item => item.User.KycStateData.PendingKycGate == Core.Domain.Model.Account.AccountHolderCure.None.ToString().ToLower()))
                        {
                            getAccountResponse.Account.AccountHolders.FirstOrDefault(d => d.User.IsPrimaryAccountHolder).User.KycStateData.PendingKycGate = "none";
                            getAccountResponse.Account.AccountHolders.FirstOrDefault(d => d.User.IsPrimaryAccountHolder).User.KycStateData.KycStatus = "failed";
                        }
                    }

                    getAccountResponse.Account?.AccountHolders?.RemoveAll(item => item.User.IsPrimaryAccountHolder == false);
                }

                getAccountResponse.ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                };

                if (_contactChangeEligibilityService.ProgramCodeEligibleForContactChangeRestrictions(request.ProgramCode))
                {
                    getAccountResponse.Account.AccountEligibility = new AccountEligibility()
                    {
                        //By default, the partner can change Address, Email and phone. Care can only update Address
                        ContactChangeEligibility = new ContactChangeEligibility()
                        {
                            Address = new List<string>() { "partner", "care" },
                            Email = new List<string>() { "partner" },
                            Phone = new List<string>() { "partner" }
                        }
                    };

                    if (await _contactChangeEligibilityService.MailedCardActivated(request.AccountIdentifier, getAccountResponse.Account.ProductCode))
                    {
                        //Only once there is an activated perso card, should the customer be allowed to update PII
                        getAccountResponse.Account.AccountEligibility.ContactChangeEligibility.Address.Add("customer");
                        getAccountResponse.Account.AccountEligibility.ContactChangeEligibility.Email.Add("customer");
                        getAccountResponse.Account.AccountEligibility.ContactChangeEligibility.Phone.Add("customer");
                    }
                }
                //Only for GPR products check if account is an Instant Issue
                if (getAccountResponse.Account.ProductCode == "51711" && !string.IsNullOrEmpty(await _instantIssueCardInventoryRepository.GetInstantIssueCardInventoryByAccountIdentifier(new Guid(getAccountResponse.Account.AccountIdentifier))))
                {
                    getAccountResponse.Account.InstantIssue = true;
                }

                getAccountResponse.Account.UpgradeKycStateData = await _upgradeAccountService.GetUpgradeKycStateData(
                    request.ProgramCode,
                    getAccountResponse.Account.ProductCode,
                    getAccountResponse.Account.AccountIdentifier,
                    getAccountResponse.Account.UpgradeKycStateData);

                return getAccountResponse;
            }
            catch (Exception e)
            {
                return e.HandleException<GetAccountResponse>(e, request);
            }
            finally
            {
                stopwatch.Stop();
                _logger.Info($"AccountHandlerV2.Handle method executed in {stopwatch.ElapsedMilliseconds} ms.");
            }
        }
    }
}
