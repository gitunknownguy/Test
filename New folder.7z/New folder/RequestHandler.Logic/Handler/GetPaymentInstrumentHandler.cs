﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using PaymentInstrument = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PaymentInstrument;
using PrivateCardData = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PrivateCardData;
using Gd.Bos.RequestHandler.Core.Domain;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetPaymentInstrumentHandler : CommandHandlerBase<GetPaymentInstrumentRequest, GetPaymentInstrumentResponse>
    {
        private readonly Core.Domain.Services.Crypto.ICryptoService _cryptoService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IPaymentInstrumentService _paymentInstrumentService;
        private readonly IBaasConfiguration _baasConfiguration;
        private readonly IRequestHandlerSettings _configuration;

        public GetPaymentInstrumentHandler(
            IPaymentInstrumentService paymentInstrumentService,
            Core.Domain.Services.Crypto.ICryptoService cryptoService,
            IValidateIdentifier validateIdentifier,
            IBaasConfiguration baasConfiguration,
            IRequestHandlerSettings requestHandlerSettings
            )
        {
            _paymentInstrumentService = paymentInstrumentService;
            _cryptoService = cryptoService;
            _validateIdentifier = validateIdentifier;
            _baasConfiguration = baasConfiguration;
            _configuration = requestHandlerSettings;
        }

        public override void SetDomainContext(GetPaymentInstrumentRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            if (!string.IsNullOrEmpty(request.PaymentInstrumentIdentifier))
                DomainContext.Current.PaymentInstrumentIdentifier = request.PaymentInstrumentIdentifier;
        }

        public override Task<GetPaymentInstrumentResponse> VerifyIdentifiers(GetPaymentInstrumentRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidatePaymentInstrumentIdentifier(DomainContext.Current.AccountIdentifier, DomainContext.Current.PaymentInstrumentIdentifier);
                return Task.FromResult(new GetPaymentInstrumentResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetPaymentInstrumentResponse>(e, request));
            }
        }

        public override Task<GetPaymentInstrumentResponse> Handle(GetPaymentInstrumentRequest request)
        {
            try
            {
                GetPaymentInstrumentResponse getPursesResponse;
                var paymentIdentifier =
                    GetPaymentIdentifier(request.AccountIdentifier, request.PaymentInstrumentIdentifier);

                var pi = paymentIdentifier.PaymentInstrument;

                var paymentInstrument = new PaymentInstrument();


                paymentInstrument.PaymentIdentifier = paymentIdentifier.PaymentIdentifierIdentifier.ToString();
                paymentInstrument.PaymentInstrumentIdentifier = pi.PaymentInstrumentIdentifier.ToString();
                paymentInstrument.IsPinSet = pi.PinSetDate.HasValue;
                paymentInstrument.ActivatedDateTime = pi.ActivatedDateTime;
                paymentInstrument.IssuedDateTime = pi.IssuedDateTime;
                paymentInstrument.Last4Pan = pi.Last4Pan;
                paymentInstrument.PaymentInstrumentType = pi.PaymentInstrumentType;
                paymentInstrument.EmbossedName = pi.EmbossedName;
                paymentInstrument.CustomCardImageIdentifier = pi.CustomCardImageIdentifier;

                paymentInstrument.Status = StatusMapper.GetPaymentInstrumentStatus(
                    (PaymentIdentifierStatus)paymentIdentifier.PaymentIdentifierStatusKey,
                    (PaymentInstrumentStatus)Enum.Parse(typeof(PaymentInstrumentStatus), pi.Status));

                if (paymentInstrument.Status == PaymentInstrumentStatus.Blocked)
                    paymentInstrument.CardPausedDateTime = pi.ChangeDataTime;

                paymentInstrument.PaymentInstrumentStatusReasons = StatusMapper.GetPaymentInstrumentStatusReasons(
                    (PaymentIdentifierStatus)paymentIdentifier.PaymentIdentifierStatusKey,
                    (PaymentInstrumentStatus)Enum.Parse(typeof(PaymentInstrumentStatus), pi.Status), pi.PaymentInstrumentStatusReason, paymentIdentifier.PaymentIdentifierStatusReason);

                paymentInstrument.IsOverIssuedDaysLimit = _baasConfiguration.IsOverIssuedDaysLimit(request.ProgramCode, _configuration.ValidOverIssuedDaysLimitProgramCodeList, paymentInstrument);
                if (request.IncludePrivatePaymentInstrumentData)
                {
                    SetPaymentInstrumentPrivateCardData(paymentIdentifier, paymentInstrument, request.ProgramCode);
                }


                if (!_baasConfiguration.IsPinSetNeed(request.ProgramCode, pi.PinSetDate.HasValue) && pi.PaymentInstrumentType == PaymentInstrumentType.Virtual)
                {
                    getPursesResponse = new GetPaymentInstrumentResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 1,
                            SubStatusCode = 321,
                            Message = "encryptedPrivatePaymentInstrumentData was not returned because the ATM Pin is not set."
                        },
                        PaymentInstrument = paymentInstrument
                    };
                }
                else
                {
                    getPursesResponse = new GetPaymentInstrumentResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 0,
                            SubStatusCode = 0,
                            Message = "Success"
                        },
                        PaymentInstrument = paymentInstrument
                    };
                }

                return Task.FromResult(getPursesResponse);

            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetPaymentInstrumentResponse>(e, request));
            }
        }

        private void SetPaymentInstrumentPrivateCardData(PaymentIdentifier paymentIdentifier, PaymentInstrument paymentInstrument, string programCode)
        {
            var pi = paymentIdentifier.PaymentInstrument;
            if (paymentInstrument.PaymentInstrumentType == PaymentInstrumentType.Emv &&
                paymentInstrument.Status == PaymentInstrumentStatus.NotActivated &&
                _baasConfiguration.GetWfCardDetails(programCode))
            {
                //GBOS-77364
                paymentInstrument.PrivateCardData = new PrivateCardData();

                var cvvResponse = _cryptoService.GenerateCvv(
                    paymentIdentifier.AccountIdentifier,
                    pi.Pan,
                    pi?.EncryptedExpirationDate?.CardExpirationyear.Substring(2) +
                    pi.EncryptedExpirationDate?.CardExpirationMonth, pi.PaymentInstrumentType,
                    new Guid(paymentIdentifier.PaymentIdentifierIdentifier.ToString()), new Guid(paymentInstrument.PaymentInstrumentIdentifier));

                paymentInstrument.PrivateCardData.ExpirationDate = pi.EncryptedExpirationDate;
                paymentInstrument.PrivateCardData.Pan = pi.Pan;
                paymentInstrument.PrivateCardData.Cvv = cvvResponse.Cvv;
                paymentInstrument.IsPrivateDataViewable = "true";

            }
            if (paymentInstrument.PaymentInstrumentType == PaymentInstrumentType.Virtual &&
                paymentInstrument.Status == PaymentInstrumentStatus.Activated)
            {
                if (_baasConfiguration.IsPinSetNeed(programCode, pi.PinSetDate.HasValue))
                {
                    if (pi.IssuedDateTime != null && _baasConfiguration.IsPrivateDataViewable(programCode, pi.IssuedDateTime))
                    {
                        paymentInstrument.PrivateCardData = new PrivateCardData();

                        var cvvResponse = _cryptoService.GenerateCvv(
                            paymentIdentifier.AccountIdentifier,
                            pi.Pan,
                            pi?.EncryptedExpirationDate?.CardExpirationyear.Substring(2) +
                            pi.EncryptedExpirationDate?.CardExpirationMonth, pi.PaymentInstrumentType,
                            new Guid(paymentIdentifier.PaymentIdentifierIdentifier.ToString()), new Guid(paymentInstrument.PaymentInstrumentIdentifier));

                        paymentInstrument.PrivateCardData.ExpirationDate = pi.EncryptedExpirationDate;
                        paymentInstrument.PrivateCardData.Pan = pi.Pan;

                        if (_baasConfiguration.IsCvvViewable(programCode, pi.IssuedDateTime))
                        {
                            paymentInstrument.PrivateCardData.Cvv = cvvResponse.Cvv;
                            paymentInstrument.IsPrivateDataViewable = "true";
                        }
                        else
                        {
                            paymentInstrument.PrivateCardData.Cvv = null;
                            paymentInstrument.IsPrivateDataViewable = "false";
                        }
                    }
                }
            }
            else if (paymentInstrument.PaymentInstrumentType == PaymentInstrumentType.MagStripe || paymentInstrument.PaymentInstrumentType == PaymentInstrumentType.Emv ||
                     paymentInstrument.PaymentInstrumentType == PaymentInstrumentType.ContactlessEmv)
            {
                if (paymentIdentifier.IsTemp) return;
                paymentInstrument.PrivateCardData = new PrivateCardData();

                paymentInstrument.PrivateCardData.ExpirationDate = pi.EncryptedExpirationDate;
                paymentInstrument.PrivateCardData.Pan = pi.Pan;

                if (!_baasConfiguration.IsPhysicalCvvViewable(programCode)) return;

                var cvvResponse = _cryptoService.GenerateCvv(
                    paymentIdentifier.AccountIdentifier,
                    pi.Pan,
                    pi?.EncryptedExpirationDate?.CardExpirationyear.Substring(2) +
                    pi.EncryptedExpirationDate?.CardExpirationMonth, pi.PaymentInstrumentType,
                    new Guid(paymentIdentifier.PaymentIdentifierIdentifier.ToString()), new Guid(paymentInstrument.PaymentInstrumentIdentifier));

                paymentInstrument.PrivateCardData.Cvv = cvvResponse.Cvv;
                if (_baasConfiguration.IsPinSetNeed(programCode, pi.PinSetDate.HasValue))
                {
                    paymentInstrument.IsPrivateDataViewable = "true";
                }
                else
                {
                    paymentInstrument.IsPrivateDataViewable = "false";
                }

            }
        }

        private PaymentIdentifier GetPaymentIdentifier(string accountIdentifier, string paymentInstrumentIdentifier)
        {
            var paymentIdentifier = _paymentInstrumentService.GetPaymentIdentifier(
                accountIdentifier,
                paymentInstrumentIdentifier);

            if (paymentIdentifier?.PaymentInstrument == null)
            {
                throw new PaymentInstrumentNotFoundException();
            }

            if (paymentIdentifier.AccountIdentifier != AccountIdentifier.FromString(accountIdentifier))
            {
                throw new AccountNotFoundException();
            }

            return paymentIdentifier;
        }

    }
}
