﻿using System;
using System.Diagnostics.CodeAnalysis;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Amazon.SecretsManager.Model;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class BusinessContactInfoHandler : CommandHandlerBase<BusinessContactInfoRequest, BusinessContactInfoResponse>
    {
        private readonly IBusinessContactInfoService _businessContactInfoService;
        private readonly IValidateIdentifier _validateIdentifier;

        public BusinessContactInfoHandler(IBusinessContactInfoService businessContactInfoService
        , IValidateIdentifier validateIdentifier)
        {
            _businessContactInfoService = businessContactInfoService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(BusinessContactInfoRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
            {
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            }
        }

        public override Task<BusinessContactInfoResponse> VerifyIdentifiers(BusinessContactInfoRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidatePartner_AccountIdProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new BusinessContactInfoResponse()
                {
                    ResponseHeader = new ResponseHeader()
                });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<BusinessContactInfoResponse>(e, request));
            }
        }
        public override Task<BusinessContactInfoResponse> Handle(BusinessContactInfoRequest request)
        {
            var response = new BusinessContactInfoResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0
                }
            };

            try
            {
                if (request == null || request.BusinessContactInfo == null)
                    throw new InvalidRequestException("Invalid Request.");

                if (string.IsNullOrEmpty(request.AccountIdentifier))
                    throw new AccountNotFoundException();

                if (string.IsNullOrEmpty(request.ProgramCode))
                    throw new ArgumentNullException($"ProgramCode: Program Code cannot be null or empty.");

                var businessContactInfo = new BusinessContactInfoRequest
                {
                    AccountIdentifier = request.AccountIdentifier,
                    ProgramCode = request.ProgramCode,
                    RequestHeader = request.RequestHeader,
                    BusinessContactInfo = new BusinessContactInfoData
                    {
                        AddressLineOne = request.BusinessContactInfo.AddressLineOne,
                        AddressLineTwo = request.BusinessContactInfo.AddressLineTwo,
                        City = request.BusinessContactInfo.City,
                        State = request.BusinessContactInfo.State,
                        Zip = request.BusinessContactInfo.Zip,
                        PhoneNumber = request.BusinessContactInfo.PhoneNumber
                    }
                };

                var _response = _businessContactInfoService.SaveBusinessContactInfo(businessContactInfo);

                response.ResponseHeader.StatusCode = _response.ResponseHeader.StatusCode;
                response.ResponseHeader.SubStatusCode = _response.ResponseHeader.SubStatusCode;
                response.ResponseHeader.Message = _response.ResponseHeader.Message;
                response.ResponseHeader.ResponseId = _response.ResponseHeader.ResponseId;
                response.ResponseHeader.Details = _response.ResponseHeader.Details;

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<BusinessContactInfoResponse>(e, request));
            }
        }
    }
}
