﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.FinancialDataApi.Enums;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Domain.Services.Experian;
using RequestHandler.Core.Domain.Services.Experian.Contracts;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using RequestHandler.Core.Domain.Services.Experian.Enum;

namespace RequestHandler.Logic.Handler
{
    public class ExperianRedirectUrlHandler : CommandHandlerBase<ExperianRedirectUrlRequest, ExperianRedirectUrlResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IExperianService _experianService;
        private readonly IFinancialDataService _financialDataService;
        private readonly IExperianServiceHelper _experianServiceHelper;

        public ExperianRedirectUrlHandler(IValidateIdentifier validateIdentifier, IExperianService experianService,
                                            IFinancialDataService financialDataService, IExperianServiceHelper experianServiceHelper)
        {
            _validateIdentifier = validateIdentifier;
            _experianService = experianService;
            _financialDataService = financialDataService;
            _experianServiceHelper = experianServiceHelper;
        }

        public override void SetDomainContext(ExperianRedirectUrlRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<ExperianRedirectUrlResponse> VerifyIdentifiers(ExperianRedirectUrlRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new ExperianRedirectUrlResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<ExperianRedirectUrlResponse>(e, request));
            }
        }

        public override Task<ExperianRedirectUrlResponse> Handle(ExperianRedirectUrlRequest request)
        {
            string brandId = request.ProgramCode.Equals(Configuration.Current.GBRProgramCode, StringComparison.OrdinalIgnoreCase)
                                ? Configuration.Current.Go2BankProgramCode
                                : request.ProgramCode;

            var storedAccount = _financialDataService.GetOptIn(request.RequestHeader.RequestId.ToString(), brandId, request.AccountIdentifier);

            var response = new ExperianRedirectUrlResponse()
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                }
            };

            if (storedAccount.OptIn)
            {
                var experianCustomer = _financialDataService.GetPartnerCustomerId(request.RequestHeader.RequestId.ToString(), brandId, request.AccountIdentifier);

                try
                {
                    var token = _experianService.GetPartnerLinkToken(experianCustomer.PartnerCustomerId);
                    var featureName = string.Empty;
                    string fdAccountId = string.Empty;

                    var fdAccount = _financialDataService.GetFdAccount(request.RequestHeader.RequestId.ToString(), brandId, request.AccountIdentifier);
                    fdAccountId = fdAccount?.Account?.AccountId.ToString();

                    switch (request.Feature)
                    {
                        case ExperianFeatureType.Boost:
                            featureName = "boost";
                            break;

                        case ExperianFeatureType.Fico:
                            featureName = "reportScore";
                            break;

                        case ExperianFeatureType.Lock:
                            featureName = "creditLock";
                            break;

                        case ExperianFeatureType.IdentityProtection:
                            featureName = "protection";
                            break;
                    }

                    var getPartnerLinkRequest = new GetPartnerLinkRequest()
                    {
                        TokenResponse = token,
                        FeatureName = featureName,
                        NewAccountAdded = request.NewAccountAdded,
                        Brand = brandId,
                        AccountId = fdAccountId
                    };

                    var getPartnerLinkResponse = _experianService.GetPartnerLink(getPartnerLinkRequest);
                    Enum.TryParse(getPartnerLinkResponse.Status, out ExperianResponseCode responseCode);
                    switch (responseCode)
                    {
                        case ExperianResponseCode.success:
                            response.RedirectUrl = getPartnerLinkResponse.RedirectUrl;
                            break;
                        case ExperianResponseCode.e007:
                            {
                                var createCustomerRequest = new CreateCustomerHelperRequest()
                                {
                                    RequestId = request.RequestHeader.RequestId,
                                    ProgramCode = request.ProgramCode,
                                    AccountIdentifier = request.AccountIdentifier,
                                    OptIn = true,
                                    Source = CreateCustomerSource.RedirectUrl
                                };

                                var createCustomerResponse = _experianServiceHelper.CreateCustomer(createCustomerRequest);
                                if (createCustomerResponse != null)
                                {
                                    var tokenRetry = _experianService.GetPartnerLinkToken(createCustomerResponse.NewPartnerCustomerId);
                                    getPartnerLinkRequest.TokenResponse = tokenRetry;

                                    var getPartnerLinkResponseRetry = _experianService.GetPartnerLink(getPartnerLinkRequest);

                                    response.RedirectUrl = getPartnerLinkResponseRetry.RedirectUrl;
                                }

                                break;
                            }
                        default:
                            throw new ArgumentOutOfRangeException();
                    }
                }
                catch (Exception e)
                {
                    response.ResponseHeader.StatusCode = 0;
                    response.ResponseHeader.SubStatusCode = (int)RequestHandler.Core.Domain.Services.Experian.Enum.SubStatusCode.ClientSideError;
                    response.ResponseHeader.Message = e.Message;
                }
            }
            else
            {
                response.ResponseHeader.SubStatusCode = 20;
                response.ResponseHeader.Message = "User is not Opted-In for this feature.";
            }

            return Task.FromResult(response);
        }
    }
}
