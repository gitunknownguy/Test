﻿using Gd.Bos.RequestHandler.Logic.Queue;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Core.Infrastructure.DataAccesses;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using NLog;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class WireOutHandler : CommandHandlerBase<WireOutRequest, WireOutResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        private readonly ITransferService _transferService;
        private readonly IAgreementDataAccess _agreementDataAccess;
        private readonly ILockService _lockService;

        public WireOutHandler(ITransferService transferService,
            IAgreementDataAccess agreementDataAccess,
            IValidateIdentifier validateIdentifier,
            ILockService lockService)
        {
            _validateIdentifier = validateIdentifier;
            _transferService = transferService;
            _agreementDataAccess = agreementDataAccess;
            _lockService = lockService;
        }
        public override Task<WireOutResponse> Handle(WireOutRequest request)
        {
            try
            {
                var hasAgreement = CheckAgreement(request.AccountIdentifier, "daa");
                var wireOutData = new WireOutData
                {
                    Amount = request.Amount,
                    BeneficiaryData = request.BeneficiaryData,
                    Currency = request.Currency,
                    IntermediaryBank = request.IntermediaryBank,
                    Obi = request.Obi,
                    Memo = request.Memo,
                    WireIdentifier = request.WireIdentifier
                };
                var response = _transferService.WireOut(wireOutData, request.ProgramCode, request.AccountIdentifier, request.RequestHeader.RequestId, hasAgreement);
                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<WireOutResponse>(e, request));
            }

        }

        private bool CheckAgreement(string accountIdentifier, string brandAgreementTypeIdentifier)
        {
            var agreements =
                _agreementDataAccess.GetTermsAcceptancesByAccountIdentifier(accountIdentifier,
                    brandAgreementTypeIdentifier);

            var currentDate = DateTime.Now;
            var agreement = agreements.FirstOrDefault(a =>
                a.AcceptanceDate <= currentDate && (a.OptoutDate ?? currentDate) >= currentDate);

            return agreement != null;



        }

        public override void SetDomainContext(WireOutRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            if (!string.IsNullOrEmpty(request.WireIdentifier))
                DomainContext.Current.TransferIdentifier = request.WireIdentifier;
        }

        public override Task<WireOutResponse> VerifyIdentifiers(WireOutRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);

                return Task.FromResult(new WireOutResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<WireOutResponse>(e, request));
            }
        }

        public override async Task<WireOutResponse> ObtainLock(WireOutRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock(DomainContext.Current.TransferIdentifier);
                return new WireOutResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<WireOutResponse>(e, request);
            }
        }

        public override void ReleaseLock(WireOutRequest request)
        {
            _lockService.ReleaseApiLock(DomainContext.Current.TransferIdentifier);
        }
    }
}
