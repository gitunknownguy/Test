﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class VerifyAddressHandler : CommandHandlerBase<AddressVerificationRequest, AddressVerificationResponse>
    {
        public VerifyAddressHandler(IRiskService riskService, IValidateIdentifier validateIdentifier)
        {
            _riskService = riskService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(AddressVerificationRequest request)
        {
            DomainContext.Current.AccountIdentifier = null;
        }

        public override Task<AddressVerificationResponse> VerifyIdentifiers(AddressVerificationRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new AddressVerificationResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AddressVerificationResponse>(e, request));
            }
        }

        public override Task<AddressVerificationResponse> Handle(AddressVerificationRequest request)
        {
            try
            {
                var riskResponse = _riskService.VerifyAddress(request);
                return Task.FromResult(riskResponse);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AddressVerificationResponse>(e, request));
            }
        }

        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IRiskService _riskService;
    }
}
