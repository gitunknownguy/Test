﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Core.Infrastructure.DataAccesses;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Account = Gd.Bos.RequestHandler.Core.Domain.Model.Account.Account;
using Address = Gd.Bos.RequestHandler.Core.Domain.Model.User.Address;
using PaymentInstrument = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PaymentInstrument;
using PhoneNumber = Gd.Bos.RequestHandler.Core.Domain.Model.User.PhoneNumber;
using PrivateCardData = Gd.Bos.RequestHandler.Core.Application.PrivateCardData;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using User = Gd.Bos.RequestHandler.Core.Domain.Model.User.User;
using Gd.Bos.Shared.Common.Core.Common.Enum;
using GetAciPackageRequest = RequestHandler.Core.Domain.Services.AciRetailApi.GetAciPackageRequest;
using GetAciPackageResponse = RequestHandler.Core.Domain.Services.AciRetailApi.GetAciPackageResponse;
using RequestHandler.Core.Application;
using RequestHeader = Gd.Bos.Shared.Common.Contract.Message.Request.RequestHeader;
using Microsoft.IdentityModel.Tokens;
using Gd.Bos.Shared.Common.Configuration;

namespace RequestHandler.Logic.Handler
{
    public class RetailCardEnrollHandler : CommandHandlerBase<RetailCardEnrollmentRequest, RetailCardEnrollmentResponse>
    {
        private readonly ITokenizerService _tokenizerService;
        private readonly IRequestDataAccess _requestDataAccess;
        private readonly IAccountService _accountService;
        private readonly ILazyCache _lazyCache;
        private readonly IAciRetailService _aciRetailService;
        private readonly IRetailCardEnrollService _retailCardEnrollService;
        private readonly IRetailCardBosEnrollService _retailCardBosEnrollService;
        private readonly IAgreementDataAccess _agreementRepository;
        private readonly IEnrollmentDataAccess _enrollmentDataAccess;
        private readonly IPaymentIdentifierRepository _paymentIdentifierRepository;
        private readonly IBaasConfiguration _baasConfiguration;

        public RetailCardEnrollHandler(
            ITokenizerService tokenizerService,
            IAccountService accountService,
            ILazyCache lazyCache,
            IAgreementDataAccess agreementRepository,
            IRequestDataAccess requestDataAccess,
            IAciRetailService aciRetailService,
            IRetailCardEnrollService retailCardEnrollService,
            IRetailCardBosEnrollService retailCardBosEnrollService,
            IEnrollmentDataAccess enrollmentDataAccess,
            IPaymentIdentifierRepository paymentIdentifierRepository,
            IBaasConfiguration baasConfiguration
        )
        {
            _tokenizerService = tokenizerService;
            _requestDataAccess = requestDataAccess;
            _accountService = accountService;
            _lazyCache = lazyCache;
            _agreementRepository = agreementRepository;
            _aciRetailService = aciRetailService;
            _retailCardEnrollService = retailCardEnrollService;
            _retailCardBosEnrollService = retailCardBosEnrollService;
            _enrollmentDataAccess = enrollmentDataAccess;
            _paymentIdentifierRepository = paymentIdentifierRepository;
            _baasConfiguration = baasConfiguration;
        }

        public override void SetDomainContext(RetailCardEnrollmentRequest request)
        {
            if (!string.IsNullOrEmpty(request.UserData?.Ssn))
                DomainContext.Current.TokenizedIdentity = _tokenizerService.TokenizeSsn(request.UserData.Ssn, DomainContext.Current.ProgramCode.ToString());
        }

        public override Task<RetailCardEnrollmentResponse> VerifyIdentifiers(RetailCardEnrollmentRequest request)
        {
            return Task.FromResult(new RetailCardEnrollmentResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<RetailCardEnrollmentResponse> Handle(RetailCardEnrollmentRequest request)
        {
            try
            {
                var isLegacyRetailCard = Guid.TryParse(request.RetailCardIdentifier, out Guid retailCardIdentifier);

                GetAciPackageResponse packageDetails = null;

                #region "Get_Aci_Package_Info" for BaasRetail
                if (!isLegacyRetailCard)
                {
                    if (string.IsNullOrEmpty(request.RetailCardIdentifier))
                    {
                        return Task.FromResult(new RetailCardEnrollmentResponse()
                        {
                            ResponseHeader = new ResponseHeader()
                            {
                                ResponseId = request.RequestHeader.RequestId,
                                StatusCode = 400,
                                SubStatusCode = 5022,
                                Message = "Retail card externalId can not be empty"
                            }
                        });
                    }

                    //Verify ProductId
                    packageDetails = _aciRetailService.GetPackageDetailsById(new GetAciPackageRequest()
                    {
                        ExternalId = request.RetailCardIdentifier,
                        RequestHeader = new RequestHeader()
                        {
                            RequestId = request.RequestHeader.RequestId
                        }
                    }).Result;

                    if (packageDetails.ResponseHeader.StatusCode != 0)
                    {
                        return Task.FromResult(new RetailCardEnrollmentResponse()
                        {
                            ResponseHeader = new ResponseHeader
                            {
                                ResponseId = packageDetails.ResponseHeader.ResponseId,
                                StatusCode = packageDetails.ResponseHeader.StatusCode,
                                SubStatusCode = packageDetails.ResponseHeader.SubStatusCode,
                                Message = packageDetails.ResponseHeader.Message
                            },
                        });
                    }

                    if (string.IsNullOrEmpty(packageDetails.AlternativePan))
                    {
                        return Task.FromResult(new RetailCardEnrollmentResponse()
                        {
                            ResponseHeader = new ResponseHeader
                            {
                                ResponseId = packageDetails.ResponseHeader.ResponseId,
                                StatusCode = 400,
                                SubStatusCode = 5025,
                                Message = "Alternative Pan is missing from Mapping Identifier info"
                            },
                        });
                    }
                }
                #endregion

                var denialResponse = DenyRestrictedRegionsEnrollment(request);
                if (denialResponse != null)
                    return denialResponse;

                if (Configuration.Current.RetailCardContactVerification && !OptionsContext.Current.IsDefined("X-GD-Bos-IgnoreMFA"))
                {
                    if (request.UserData?.Phone.Type != PhoneType.Mobile)
                        throw new RequestHandlerException(603, 0, "Only one mobile phone type is allowed for gbr RetailCard enrollment.");
                    if (request.ContactVerificationIdentifiers == null || !request.ContactVerificationIdentifiers.Any())
                        throw new RequestHandlerException(101, 0, "ContactVerificationIdentifier should be supplied in MFA.");
                }

                var newAccountIdentifier = Guid.NewGuid();

                var existingRequestAccountIdentifier = _requestDataAccess.InsertRequestId(RequestType.Enroll,
                    request.RequestHeader.RequestId, newAccountIdentifier);

                if (existingRequestAccountIdentifier.HasValue)
                {
                    var kycStateData = new Gd.Bos.RequestHandler.Core.Domain.Model.Account.KycStateData();
                    var getEnrollmentResponse = _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(
                                                existingRequestAccountIdentifier.Value.ToString(), request.ProgramCode, true);

                    if (getEnrollmentResponse.Account == null)
                    {
                        newAccountIdentifier = existingRequestAccountIdentifier.Value;
                    }
                    else
                    {
                        //If we have AccountStatus pending, and no paymentInstruments, we should just rerun enrollment
                        if (getEnrollmentResponse?.Account?.Status?.ToLower() == "pending" && getEnrollmentResponse.Account.AccountHolders.First()?.PaymentInstruments?.Count == 0)
                        {
                            newAccountIdentifier = existingRequestAccountIdentifier.Value;
                        }
                        else
                        {
                            return Task.FromResult(GetEnrollIdempotentResponse(getEnrollmentResponse, request, kycStateData, existingRequestAccountIdentifier.Value, isLegacyRetailCard, packageDetails, request.RequestTempCardOnly));
                        }
                    }
                }

                var userIdentifyingData = new UserIdentifyingData(
                    request.UserData.DateOfBirth,
                    string.Empty,
                    request.UserData.Ssn,
                    string.Empty);

                var phoneNumbers = new List<PhoneNumber>
                {
                    new PhoneNumber
                    {
                        Type = request.UserData.Phone.Type,
                        IsDefault = true,
                        IsVerified = request.UserData.Phone.IsVerified,
                        Number = request.UserData.Phone.Number
                    }
                };

                NpNrReason npnrReason = NpNrReason.GoodStanding;

                var agreement = _agreementRepository.GetAgreementsByProductCode(request.AccountCreationData.ProductCode);

                Tuple<bool, ResponseHeader> termsResponse
                    = _agreementRepository.IsTermAgreementAccepted(agreement,
                    request.AccountCreationData.TermsAcceptances,
                    request.AccountCreationData.ProductCode,
                    request.RequestHeader.RequestId);

                if (!termsResponse.Item1)
                    npnrReason = NpNrReason.TermNotAccepted;

                AccountLimit accountLimit = new AccountLimit();
                try
                {
                    accountLimit = _accountService.AccountLimitVerification(userIdentifyingData.Ssn,
                        string.Empty,
                        userIdentifyingData.GetIdentityTypeKey().ToString(),
                        false,
                        request.AccountCreationData.ProductCode,
                        request.ProgramCode);

                    if (string.IsNullOrEmpty(accountLimit.ResponseCode)) accountLimit.ResponseCode = "0";
                    string phoneNumber = phoneNumbers.FirstOrDefault()?.Number;
                    if (accountLimit.ResponseCode == "0" && !string.IsNullOrEmpty(phoneNumber))
                    {
                        accountLimit = _accountService.PhoneLimitVerification(
                            phoneNumber,
                            "PhoneNumber",
                            request.AccountCreationData.ProductCode,
                            request.ProgramCode);
                    }

                    accountLimit.ResponseCode ??= "0";
                    var verifyEmail = request.UserData?.Email.EmailAddress;
                    if (accountLimit.ResponseCode == "0" && !string.IsNullOrEmpty(verifyEmail))
                    {
                        accountLimit = _accountService.EmailLimitVerification(
                            verifyEmail,
                            request.AccountCreationData.ProductCode,
                            request.ProgramCode);
                    }
                }
                catch (RequestHandlerException e)
                {
                    accountLimit.ResponseCode = e.ResponseCode;
                }

                accountLimit.ResponseCode = accountLimit.ResponseCode ?? "0";
                if (accountLimit.ResponseCode != "0")
                {
                    _lazyCache?.Value?.Set(request.RequestHeader?.RequestId.ToString(), accountLimit.ResponseCode, new TimeSpan(1, 0, 0, 0));
                    npnrReason = NpNrReason.AccountLimit;
                }

                var userName = new UserName(request.UserData.Name.FirstName,
                    request.UserData.Name.MiddleName, request.UserData.Name.LastName);

                var addresses = new List<Address>()
                {
                    new Address()
                    {
                        AddressLine1 = request.UserData.Address.AddressLine1,
                        AddressLine2 = request.UserData.Address.AddressLine2,
                        City = request.UserData.Address.City,
                        Country = request.UserData.Address.CountryCode,
                        IsDefault = true,
                        IsVerified = false,
                        State = request.UserData.Address.State,
                        ZipCode = request.UserData.Address.ZipCode,
                        Type = request.UserData.Address.Type,
                    }
                };

                var terms = request.AccountCreationData.TermsAcceptances?.ToDomain(agreement);

                var email = request.UserData?.Email?.ToDomain();
                var enrollResponse = isLegacyRetailCard ?
                    _retailCardEnrollService.Enroll(newAccountIdentifier.ToString(), request.ProgramCode,
                        request.AccountCreationData.ProductCode, userName, userIdentifyingData, email, addresses,
                        phoneNumbers,
                        request.ContactVerificationIdentifiers,
                        true,
                        terms,
                        true,
                        request.RequestHeader.RequestId,
                        request.RetailCardIdentifier,
                        request.AccountCreationData.FraudData,
                        isNpnr: npnrReason)
                    :
                    _retailCardBosEnrollService.Enroll(newAccountIdentifier.ToString(), request.ProgramCode,
                        request.AccountCreationData.ProductCode, userName, userIdentifyingData, email, addresses,
                        phoneNumbers,
                        request.ContactVerificationIdentifiers,
                        true,
                        terms,
                        true,
                        request.RequestHeader.RequestId,
                        packageDetails,
                        request.AccountCreationData.FraudData,
                        isNpnr: npnrReason,
                        requestTempCardOnly: request.RequestTempCardOnly);

                var rtlExtn = new RetailEnrollmentExtensions(_lazyCache, _enrollmentDataAccess);
                var response = rtlExtn.GenerateRetailCardEnrollmentResponse(request, enrollResponse, npnrReason, termsResponse);

                return Task.FromResult(response);
            }
            catch (Exception ex)
            {
                return Task.FromResult(ex.HandleException<RetailCardEnrollmentResponse>(ex, request));
            }
        }

        private RetailCardEnrollmentResponse GetEnrollIdempotentResponse(GetEnrollmentResponse getEnrollmentResponse,
            RetailCardEnrollmentRequest request,
            Gd.Bos.RequestHandler.Core.Domain.Model.Account.KycStateData kycStateData,
            Guid? existingRequestAccountIdentifier, bool isLegacyRetailCard, GetAciPackageResponse packageDetails,
            bool requestTempCardOnly, string source = null)
        {
            var errorCode = _lazyCache?.Value?.Get<string>(request.RequestHeader?.RequestId.ToString());

            foreach (var ah in getEnrollmentResponse.Account.AccountHolders)
            {
                //If the DOBs don't match return an error. This is what is being returned on the other enrollment call. 
                if (request?.UserData?.DateOfBirth != null
                    && ah?.User?.DateOfBirth != request.UserData?.DateOfBirth)
                    throw new RequestHandlerException(2, 60, "Number of Active Accounts Exceeded.");
            }
            
            var userName = new UserName(request.UserData.Name.FirstName,
                    request.UserData.Name.MiddleName, request.UserData.Name.LastName);

            var email = request.UserData?.Email?.ToDomain();

            var addresses = new List<Address>()
            {
                new Address()
                {
                    AddressLine1 = request.UserData.Address.AddressLine1,
                    AddressLine2 = request.UserData.Address.AddressLine2,
                    City = request.UserData.Address.City,
                    Country = request.UserData.Address.CountryCode,
                    IsDefault = true,
                    IsVerified = false,
                    State = request.UserData.Address.State,
                    ZipCode = request.UserData.Address.ZipCode,
                    Type = request.UserData.Address.Type,
                }
            };

            var userIdentifyingData = new UserIdentifyingData(
                request.UserData.DateOfBirth,
                string.Empty,
                request.UserData.Ssn,
                string.Empty);

            var phoneNumbers = new List<PhoneNumber>
            {
                new PhoneNumber
                {
                    Type = request.UserData.Phone.Type,
                    IsDefault = true,
                    IsVerified = request.UserData.Phone.IsVerified,
                    Number = request.UserData.Phone.Number
                }
            };
            var agreement = _agreementRepository.GetAgreementsByProductCode(request.AccountCreationData.ProductCode);

            var terms = request.AccountCreationData.TermsAcceptances?.ToDomain(agreement);


            Tuple<bool, ResponseHeader> termsResponse = _agreementRepository.IsTermAgreementAccepted(agreement,
            request.AccountCreationData.TermsAcceptances,
            request.AccountCreationData.ProductCode,
            request.RequestHeader.RequestId);


            NpNrReason npnrReason = NpNrReason.GoodStanding;
            if (!termsResponse.Item1)
                npnrReason = NpNrReason.TermNotAccepted;

            if (isLegacyRetailCard)
            {
                var paymentIdentifierLegacyTemp =
                    _paymentIdentifierRepository.GetPaymentIdentifierByPaymentIdentifierIdentifier(
                        PaymentIdentifierIdentifier.FromString(request.RetailCardIdentifier));
                
                //PaymentIdentifierStatusKey 2 - Not Activated
                if (paymentIdentifierLegacyTemp.PaymentIdentifierStatus == PaymentIdentifierStatus.NotActivated)
                {
                    var enrollResponse = 
                        _retailCardEnrollService.EnrollIdempotent(getEnrollmentResponse,
                            getEnrollmentResponse.Account.ProductCode, userName, userIdentifyingData, email,
                            addresses, phoneNumbers, request.ContactVerificationIdentifiers, terms, request.ProgramCode, request.RequestHeader.RequestId,
                            request.RetailCardIdentifier, null, isNpnr: npnrReason);

                    var rtlExtn = new RetailEnrollmentExtensions(_lazyCache, _enrollmentDataAccess);
                    return rtlExtn.GenerateRetailCardEnrollmentResponse(request, enrollResponse, npnrReason, termsResponse);
                }
            }
            else
            {
                var enrollResponse = _retailCardBosEnrollService.EnrollIdempotent(getEnrollmentResponse,
                        getEnrollmentResponse.Account.ProductCode, userName, userIdentifyingData, email,
                        addresses, phoneNumbers, request.ContactVerificationIdentifiers, terms, request.ProgramCode, request.RequestHeader.RequestId,
                        packageDetails, source, null, isNpnr: npnrReason, requestTempCardOnly: requestTempCardOnly);

                var rtlExtn = new RetailEnrollmentExtensions(_lazyCache, _enrollmentDataAccess);
                return rtlExtn.GenerateRetailCardEnrollmentResponse(request, enrollResponse, npnrReason, termsResponse);
            }
            
            // var paymentInst
            var existingResponse = new RetailCardEnrollmentResponse()
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                },
                AccountIdentifier = getEnrollmentResponse.Account.AccountIdentifier,
                AccountReferenceNumber = getEnrollmentResponse.Account.CustomerReferenceNumber,
                Status = getEnrollmentResponse.Account.Status,
                StatusReasons = getEnrollmentResponse.Account.StatusReasons,
                StatusCure = getEnrollmentResponse.Account.StatusCure,
                DirectDepositInformation = getEnrollmentResponse.Account.DirectDepositInformation,
                Purses = getEnrollmentResponse.Account.Purses,
                AccountHolders = getEnrollmentResponse.Account.AccountHolders,
                AccountStatusChangedDateTime = getEnrollmentResponse.Account?.AccountStatusChangedDateTime,
                AccountCycleDay = getEnrollmentResponse.Account.AccountCycleDay
            };

            if (!string.IsNullOrEmpty(errorCode))
                existingResponse.ResponseHeader =
                    existingResponse.ResponseHeader?.GetResponseHeader(errorCode,
                        request.RequestHeader.RequestId);

            return existingResponse;
        }

        private Task<RetailCardEnrollmentResponse> DenyRestrictedRegionsEnrollment(RetailCardEnrollmentRequest request)
        {
            var state = request?.UserData?.Address?.State;

            if (_baasConfiguration.IsRetailPRAddressAllowed(request.ProgramCode))
            {
                if (state != null && state.Equals("GU", StringComparison.InvariantCultureIgnoreCase))
                {
                    return Task.FromResult(new RetailCardEnrollmentResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 5,
                            SubStatusCode = 65,
                            Message = "This product may not be registered in the requested region"
                        }
                    });
                }
            }
            else
            {
                if (state != null && (state.Equals("PR", StringComparison.InvariantCultureIgnoreCase) ||
                                      state.Equals("GU", StringComparison.InvariantCultureIgnoreCase)))
                {
                    return Task.FromResult(new RetailCardEnrollmentResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 5,
                            SubStatusCode = 65,
                            Message = "This product may not be registered in the requested region"
                        }
                    });
                } 
            }

            return null;
        }
    }
}
