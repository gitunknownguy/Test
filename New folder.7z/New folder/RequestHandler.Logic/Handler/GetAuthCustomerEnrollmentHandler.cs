﻿using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;

namespace RequestHandler.Logic.Handler
{
    public class GetAuthCustomerEnrollmentHandler : CommandHandlerBase<GetCustomerEnrollmentRequest, GetCustomerEnrollmentResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IAccountService _accountService;

        public GetAuthCustomerEnrollmentHandler(IAccountService accountService, IValidateIdentifier validateIdentifier)
        {
            _accountService = accountService;
            _validateIdentifier = validateIdentifier;
        }

        public override Task<GetCustomerEnrollmentResponse> Handle(GetCustomerEnrollmentRequest request)
        {
            try
            {
                if (request.RequestHeader.RequestId == Guid.Empty)
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId, $"{nameof(request)}.RequestHeader.RequestId must be specified");

                if (string.IsNullOrEmpty(request.AccountIdentifier) || request.AccountIdentifier == Guid.Empty.ToString())
                    throw new RequestHandlerException(350, 0, $"The format of accountIdentifier is invalid.");

                var result = _accountService.GetAuthCustomerEnrollment(request.RequestHeader.RequestId.ToString(),
                    request.AccountIdentifier, request.UserIdentifier, request.ProgramCode);

                return Task.FromResult(new GetCustomerEnrollmentResponse()
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                    CustomerId = result.CustomerId,
                    EnrollmentStatusCode = result.EnrollmentStatusCode,
                    EnrollmentStatus = result.EnrollmentStatus
                });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetCustomerEnrollmentResponse>(e, request));
            }
        }

        public override void SetDomainContext(GetCustomerEnrollmentRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetCustomerEnrollmentResponse> VerifyIdentifiers(GetCustomerEnrollmentRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetCustomerEnrollmentResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetCustomerEnrollmentResponse>(e, request));
            }
        }
    }
}
