﻿using System;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.ContactVerification.Contract.Data.Enum;
using Gd.Bos.Shared.Common.ContactVerification.Contract.Data;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using NLog;
using System.Collections.Generic;
using RequestHandler.Core.Utils;
using Gd.Bos.RequestHandler.Core.Domain.Services.ContactVerification;

namespace RequestHandler.Logic.Handler
{
    public class UnlockContactVerificationHandler : CommandHandlerBase<UnlockContactVerificationRequest, UnlockContactVerificationResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IServiceInvokeProvider _serviceInvokerProvider;
        private readonly IContactVerificationService _contactVerificationService;
        private static readonly Logger _logger = LogManager.GetCurrentClassLogger();
        public UnlockContactVerificationHandler(IValidateIdentifier validateIdentifier, IServiceInvokeProvider serviceInvokeProvider, IContactVerificationService contactVerificationService)
        {
            _validateIdentifier = validateIdentifier;
            _serviceInvokerProvider = serviceInvokeProvider;
            _contactVerificationService = contactVerificationService;
        }
        public override Task<UnlockContactVerificationResponse> Handle(UnlockContactVerificationRequest request)
        {
            try
            {
                var serviceRequest = new Gd.Bos.Shared.Common.ContactVerification.Contract.Message.Request.UnlockContactVerificationRequest()
                {
                    AccountIdentifier = request.AccountIdentifier,
                    FirstName = request.FirstName,
                    LastName = request.LastName,
                    ProductCode = request.ProductCode,
                    ProgramCode = request.ProgramCode,
                    RetailCardIdentifier = request.RetailCardIdentifier,
                    EventType = request.EventType,
                    Contact = new List<InnerContactValue>(),
                    RequestHeader = new Gd.Bos.Shared.Common.Contract.Message.Request.RequestHeader()
                };

                this.MapRequestHeader(serviceRequest, request.RequestHeader);
                this.MapContact(serviceRequest, request.Contact);

                _logger.Info($"request is ready to send to ContactVerification RequestId:{request.RequestHeader.RequestId}");
                var response = _contactVerificationService.UnlockContactVerification(serviceRequest);
                _logger.Info($"Received the response from ContactVerification RequestId:{request.RequestHeader.RequestId} Message:{response.ResponseHeader.Message} StatusCode:{response.ResponseHeader.StatusCode} Details:{response.ResponseHeader.Details}");

                return Task.FromResult(new UnlockContactVerificationResponse()
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        Details = response.ResponseHeader.Details,
                        Message = response.ResponseHeader.Message,
                        ResponseId = response.ResponseHeader.ResponseId,
                        StatusCode = response.ResponseHeader.StatusCode,
                        SubStatusCode = response.ResponseHeader.SubStatusCode
                    }
                });
            }
            catch (Exception ex)
            {
                return Task.FromResult(ex.HandleException<UnlockContactVerificationResponse>(ex, request));
            }
        }
        private void MapRequestHeader(Gd.Bos.Shared.Common.ContactVerification.Contract.Message.Request.UnlockContactVerificationRequest request, RequestHeader header)
        {
            if (header != null)
            {
                request.RequestHeader.RequestId = header.RequestId;
                request.RequestHeader.Options = header.Options;
            }
        }
        private void MapContact(Gd.Bos.Shared.Common.ContactVerification.Contract.Message.Request.UnlockContactVerificationRequest request, List<InnerContactValue> contacts)
        {
            if (contacts != null)
            {
                contacts.ForEach(contact =>
                {
                    var data = new Gd.Bos.Shared.Common.ContactVerification.Contract.Data.InnerContactValue()
                    {
                        ContactValue = contact.ContactValue,
                        ContactType = contact.ContactType
                    };
                    request.Contact.Add(data);
                });
            }
        }
        public override void SetDomainContext(UnlockContactVerificationRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<UnlockContactVerificationResponse> VerifyIdentifiers(UnlockContactVerificationRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new UnlockContactVerificationResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UnlockContactVerificationResponse>(e, request));
            }
        }
    }
}
