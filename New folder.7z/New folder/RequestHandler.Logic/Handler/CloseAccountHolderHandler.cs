﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using NLog;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class CloseAccountHolderHandler : CommandHandlerBase<CloseAccountHolderRequest, CloseAccountHolderResponse>
    {
        private readonly IAccountService _accountService;
        private readonly IValidateIdentifier _validateIdentifier;
        private ILogger _logger = LogManager.GetCurrentClassLogger();

        public CloseAccountHolderHandler(IAccountService accountService, IValidateIdentifier validateIdentifier)
        {
            _accountService = accountService;
            _validateIdentifier = validateIdentifier;
        }
        public override void SetDomainContext(CloseAccountHolderRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<CloseAccountHolderResponse> VerifyIdentifiers(CloseAccountHolderRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 3, 105);
                return Task.FromResult(new CloseAccountHolderResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CloseAccountHolderResponse>(e, request));
            }
        }

        public override Task<CloseAccountHolderResponse> Handle(CloseAccountHolderRequest request)
        {
            CloseAccountHolderResponse response;

            try
            {
                response = _accountService.CloseAccountHolder(request);

            }
            catch (Exception e)
            {

                response = e.HandleException<CloseAccountHolderResponse>(e, request);
            }

            return Task.FromResult(response);
        }
    }
}
