﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;


namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class AchReturnHandler : CommandHandlerBase<AchReturnRequest, AchReturnResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;

        public AchReturnHandler(IValidateIdentifier validateIdentifier)
        {
            _validateIdentifier = validateIdentifier;
        }
        public override void SetDomainContext(AchReturnRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<AchReturnResponse> VerifyIdentifiers(AchReturnRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new AchReturnResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AchReturnResponse>(e, request));
            }
        }

        public override Task<AchReturnResponse> Handle(AchReturnRequest request)
        {
            try
            {
                var response = new AchReturnResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                };

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AchReturnResponse>(e, request));
            }
        }
    }
}
