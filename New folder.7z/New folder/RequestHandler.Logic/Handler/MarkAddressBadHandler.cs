﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Newtonsoft.Json;
using NLog;
using Address = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Address;
using UserProfile = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.UserProfile;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class MarkAddressBadHandler : CommandHandlerBase<MarkAddressBadRequest, MarkAddressBadResponse>
    {
        private readonly IAccountService _accountService;
        private readonly INotificationService _notificationPublisher;

        public MarkAddressBadHandler(IAccountService accountService, INotificationService notificationPublisher)
        {
            _accountService = accountService;
            _notificationPublisher = notificationPublisher;
        }

        public override void SetDomainContext(MarkAddressBadRequest request)
        {
        }

        public override Task<MarkAddressBadResponse> VerifyIdentifiers(MarkAddressBadRequest request)
        {
            return Task.FromResult(new MarkAddressBadResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<MarkAddressBadResponse> Handle(MarkAddressBadRequest request)
        {
            try
            {
                var result = _accountService.MarkAddressAsBad(request);

                PublishReturnMailNotification(result.Item1, result.Item2, result.Item3.IsDefault, request.ProgramCode);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<MarkAddressBadResponse>(e, request));
            }

            return Task.FromResult(new MarkAddressBadResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success."
                }
            });
        }

        private void PublishReturnMailNotification(AccountIdentifier accountIdentifier, UserIdentifier userIdentifier, bool isDefaultAddress, string programCode)
        {
            UserProfile profile = new UserProfile
            {
                AccountIdentifier = accountIdentifier.ToString(),
                UserIdentifier = userIdentifier.ToString(),
                ProfileData = new ProfileData
                {
                    Addresses = new List<Address>
                    {
                        new Address
                        {
                            Type = "home",
                            IsReturned = true,
                            IsDefault = isDefaultAddress,
                            LastUpdatedDateTime = DateTime.Parse(DateTime.UtcNow.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'")).ToUniversalTime()
                        }
                    }
                }
            };

            _notificationPublisher.PublishNotification(programCode, profile, EventType.UserUpdate);
        }
    }
}
