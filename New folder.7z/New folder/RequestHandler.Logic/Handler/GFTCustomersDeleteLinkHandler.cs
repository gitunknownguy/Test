﻿using System;
using System.Linq;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Domain.Services.GlobalFundTransfer.Contracts;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.GFTCustomers;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.GFTCustomers;
using RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;

namespace RequestHandler.Logic.Handler
{

    public class GFTCustomersDeleteCardLinkHandler : CommandHandlerBase<GFTCustomersDeleteCardLinkRequest, GFTCustomersDeleteLinkResponse>
    {
        private readonly ITransferService _transferService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IBaasConfiguration _baasConfiguration;
        private static string unspecifiedGuid = Guid.Empty.ToString();

        public GFTCustomersDeleteCardLinkHandler(ITransferService transferService, IValidateIdentifier validateIdentifier, IBaasConfiguration baasConfiguration)
        {
            _transferService = transferService;
            _validateIdentifier = validateIdentifier;
            _baasConfiguration = baasConfiguration;
        }

        public override void SetDomainContext(GFTCustomersDeleteCardLinkRequest request)
        {
        }

        public override Task<GFTCustomersDeleteLinkResponse> VerifyIdentifiers(GFTCustomersDeleteCardLinkRequest request)
        {
            return Task.FromResult(new GFTCustomersDeleteLinkResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<GFTCustomersDeleteLinkResponse> Handle(GFTCustomersDeleteCardLinkRequest request)
        {
            if (request.RequestHeader.RequestId == Guid.Empty)
            {
                throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId, $"{nameof(request)}.RequestHeader.RequestId must be specified");
            }

            if (string.IsNullOrEmpty(request.ProgramCode) || request.ProgramCode == unspecifiedGuid)
            {
                throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier, $"{nameof(request)}.ProgramCode must be specified");
            }

            if (string.IsNullOrEmpty(request.CustomerToken) || request.CustomerToken == unspecifiedGuid)
            {
                throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier, $"{nameof(request)}.CustomerToken must be specified");
            }

            if (string.IsNullOrEmpty(request.LinkId) || request.CustomerToken == unspecifiedGuid)
            {
                throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier, $"{nameof(request)}.LinkId must be specified");
            }

            if (!GFTCustomerTokenMapping.IsValidCustomerType(request.CustomerType))
            {
                throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier, $"{nameof(request)}.Customer type is invalid");
            }

            var gftRequest = new DeleteLinkRequest()
            {
                CustomerToken = request.CustomerToken,
                LinkId = request.LinkId,
                ProgramCode = request.ProgramCode,
                RequestId = request.RequestHeader.RequestId.ToString(),
            };

            var gftResponse = _transferService.DeleteCardLink(gftRequest);

            var response = new GFTCustomersDeleteLinkResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                },
                LinkId = gftResponse.LinkId,
                Status = gftResponse.Status
            };

            if (gftResponse.ResponseDetails.Any())
            {
                var firstDetail = gftResponse.ResponseDetails.First();

                if (string.Compare(firstDetail.Description, "success", StringComparison.OrdinalIgnoreCase) != 0)
                {
                    response.ResponseHeader.Message = firstDetail.Description;
                    response.ResponseHeader.Details = firstDetail.Description;
                    response.ResponseHeader.StatusCode = firstDetail.Code;
                    response.ResponseHeader.SubStatusCode = firstDetail.SubCode;
                }
            }
            else
            {
                response.ResponseHeader.Message = "Unknown Error";
                response.ResponseHeader.Details = "Unknown Error";
                response.ResponseHeader.StatusCode = 4214;
                response.ResponseHeader.SubStatusCode = 1514;
            }
            return Task.FromResult(response);
        }
    }
}
