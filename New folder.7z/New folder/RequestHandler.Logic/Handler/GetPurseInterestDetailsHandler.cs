﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Interest;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;

namespace RequestHandler.Logic.Handler
{
    public class GetPurseInterestDetailsHandler : CommandHandlerBase<GetPurseInterestDetailsRequest, GetPurseInterestDetailsResponse>
    {
        private readonly IAccountDataAccess _accountDataAccess;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IInterestRateRepository _interestRateRepository;
        private readonly IAccountBalanceRepository _accountBalanceRepository;

        public GetPurseInterestDetailsHandler(IAccountDataAccess accountDataAccess, IValidateIdentifier validateIdentifier, IInterestRateRepository interestRateRepository, IAccountBalanceRepository accountBalanceRepository)
        {
            _accountDataAccess = accountDataAccess;
            _validateIdentifier = validateIdentifier;
            _interestRateRepository = interestRateRepository;
            _accountBalanceRepository = accountBalanceRepository;
        }

        public override void SetDomainContext(GetPurseInterestDetailsRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetPurseInterestDetailsResponse> VerifyIdentifiers(GetPurseInterestDetailsRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetPurseInterestDetailsResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetPurseInterestDetailsResponse>(e, request));
            }
        }

        public override Task<GetPurseInterestDetailsResponse> Handle(GetPurseInterestDetailsRequest request)
        {
            try
            {
                var accountBalances = _accountBalanceRepository.GetAccountBalanceByAccountIdentifier(request.AccountIdentifier);
                var purse = accountBalances.FirstOrDefault(x => x.AccountBalanceIdentifier == AccountBalanceIdentifier.FromString(request.PurseIdentifier));
                if (purse == null)
                {
                    throw new ValidationException(10, 0, "The purse does not exist.");
                }

                if (!ValidatePeriodTime(request.PeriodStartDate, request.PeriodEndDate))
                {
                    throw new ValidationException(10, 0, "Invalid request period time.");
                }

                var accountKey = _accountDataAccess.GetAccountKey(request.AccountIdentifier, request.ProgramCode).GetValueOrDefault();
                var currentAccountBalanceInterestSnapshots = _interestRateRepository.GetAccountBalanceInterestSnapshots(accountKey, request.PeriodStartDate, request.PeriodEndDate)?
                    .FindAll(a => a.AccountBalanceKey == purse.AccountBalanceKey);

                if (currentAccountBalanceInterestSnapshots == null || currentAccountBalanceInterestSnapshots.Count == 0)
                {
                    throw new ValidationException(10, 0, "The purseInterestDetails not found.");
                }

                var currentAccountBalanceInterests = _interestRateRepository.GetAccountBalanceInterests(request.AccountIdentifier)?
                    .Where(a => a.AccountBalanceIdentifier.Equals(request.PurseIdentifier, StringComparison.InvariantCultureIgnoreCase)).ToList();

                var productTiers = _interestRateRepository.GetProductInterestTierByProductKey(purse.ProductKey);
                FormatProductTierEndDate(productTiers);
                var programInterestTierMetaData =
                    _interestRateRepository.GetProductInterestTierInfoByProgramCode(request.ProgramCode);

                var purseInterestDetails = new List<PurseInterestDetail>();
                foreach (var accountBalanceInterestSnapshot in currentAccountBalanceInterestSnapshots)
                {
                    var accountBalanceInterest = currentAccountBalanceInterests?.FirstOrDefault(c => c.AccountBalanceInterestKey == accountBalanceInterestSnapshot.AccountBalanceInterestKey);
                    var tiers = productTiers.Where(p => p.ProductInterestTierKey == accountBalanceInterest?.ProductInterestTierKey).OrderBy(p => p.CreateDate).ToList();

                    var transactionDate = _accountDataAccess.GetAccountTransaction(accountBalanceInterestSnapshot.TransactionReferenceId);
                    var interestRate = tiers.FirstOrDefault(p => p.StartDate <= accountBalanceInterestSnapshot.PeriodStartDate && p.EndDate >= accountBalanceInterestSnapshot.PeriodEndDate)?.InterestRate;
                    purseInterestDetails.Add(new PurseInterestDetail
                    {
                        APY = accountBalanceInterestSnapshot.APY,
                        InterestRateTier = (null != accountBalanceInterest) ? programInterestTierMetaData.Tiers.FirstOrDefault(p => p.Key == accountBalanceInterest?.InterestRateTierKey)!.Name : String.Empty,
                        InterestRate = interestRate,
                        InterestCreditAmount = accountBalanceInterestSnapshot.InterestCreditAmount,
                        AverageDailyBalance = accountBalanceInterestSnapshot.AverageDailyBalance,
                        PeriodStartDate = accountBalanceInterestSnapshot.PeriodStartDate.ToString("yyyy-MM-dd"),
                        PeriodEndDate = accountBalanceInterestSnapshot.PeriodEndDate.ToString("yyyy-MM-dd"),
                        InterestCreditTransactionPostingDate = transactionDate?.ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
                    });
                }

                var getPurseInterestRateResponse = new GetPurseInterestDetailsResponse()
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                    PurseInterestDetails = purseInterestDetails.ToArray()
                };

                return Task.FromResult(getPurseInterestRateResponse);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetPurseInterestDetailsResponse>(e, request));
            }
        }

        private bool ValidatePeriodTime(DateTime? startDate, DateTime? endDate)
        {
            bool result = true;
            if (startDate != null && endDate != null)
            {
                if ((startDate >= endDate))
                {
                    result = false;
                }
            }

            return result;
        }

        private void FormatProductTierEndDate(List<ProductInterestTier> productTiers)
        {
            if (productTiers != null && productTiers.Count != 0)
            {
                foreach (var productTier in productTiers)
                {
                    if (productTier.EndDate == null)
                    {
                        productTier.EndDate = DateTime.MaxValue;
                    }
                }
            }
        }

    }
}