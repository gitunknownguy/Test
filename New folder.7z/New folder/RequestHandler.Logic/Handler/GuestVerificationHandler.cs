﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GuestVerificationHandler : CommandHandlerBase<GuestVerificationRequest, GuestVerificationResponse>
    {

        public GuestVerificationHandler(IVerificationService verificationService,
            INotificationService notificationPublisher)
        {
            _notificationPublisher = notificationPublisher;
            _verificationService = verificationService;

        }

        public override void SetDomainContext(GuestVerificationRequest request)
        {
        }

        public override Task<GuestVerificationResponse> VerifyIdentifiers(GuestVerificationRequest request)
        {

            return Task.FromResult(new GuestVerificationResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<GuestVerificationResponse> Handle(GuestVerificationRequest request)
        {
            try
            {

                var userName = new UserName(request.UserCreationData?.ProfileData?.FirstName,
                   request.UserCreationData?.ProfileData?.MiddleName, request.UserCreationData?.ProfileData?.LastName);

                var email = request.UserCreationData?.Email?.ToDomain();

                var addresses =
                    request.UserCreationData?.ProfileData?.Addresses?.ToDomain();

                var phoneNumbers =
                    request.UserCreationData?.PhoneNumbers?.ToDomain();

                var response = _verificationService.GuestVerification(userName, email, addresses, phoneNumbers, request.Device, request.ProgramCode, request.UserCreationData?.IdentifyingData?.DateOfBirth, request.TransferIdentifier);
                response.ResponseHeader.ResponseId = request.RequestHeader.RequestId;

                return Task.FromResult(response);
            }
            catch (Exception e)
            {

                return Task.FromResult(e.HandleException<GuestVerificationResponse>(e, request));
            }
        }


        private readonly INotificationService _notificationPublisher;
        private IVerificationService _verificationService;
        private readonly IValidateIdentifier _validateIdentifier;
    }
}
