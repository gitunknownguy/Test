﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Interest;
using Gd.Bos.RequestHandler.Core.Domain.Services.InterestRate;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using Gd.Bos.RequestHandler.Logic.Extension;
using System.Collections.Generic;
using Gd.Bos.RequestHandler.Core.Application;
using System.Linq;
using RequestHandler.Core.Domain.Model.Interest;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class AddInterestRateTierHandler : CommandHandlerBase<AddInterestRateTierRequest, AddInterestRateTierResponse>
    {
        public AddInterestRateTierHandler(IValidateIdentifier validateIdentifier, IInterestRateService interestRateService,
            ILockService lockService, IAccountService accountService, IInterestRateRepository interestRateRepository)
        {
            _validateIdentifier = validateIdentifier;
            _interestRateService = interestRateService;
            _lockService = lockService;
            _accountService = accountService;
            _interestRateRepository = interestRateRepository;
        }

        public override void SetDomainContext(AddInterestRateTierRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }
        public override Task<AddInterestRateTierResponse> VerifyIdentifiers(AddInterestRateTierRequest request)
        {
            _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
            _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 5, 105);
            return Task.FromResult(new AddInterestRateTierResponse { ResponseHeader = new ResponseHeader() });
        }

        public override async Task<AddInterestRateTierResponse> ObtainLock(AddInterestRateTierRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock(request.PurseIdentifier);
                return new AddInterestRateTierResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<AddInterestRateTierResponse>(e, request);
            }
        }

        public override Task<AddInterestRateTierResponse> Handle(AddInterestRateTierRequest request)
        {
            short interestRateTierKey = 0;
            if (!string.IsNullOrEmpty(request.InterestRateTier))
            {
                var programInterestTierMetaData =
                    _interestRateRepository.GetProductInterestTierInfoByProgramCode(request.ProgramCode);
                if (programInterestTierMetaData.Tiers.FirstOrDefault(p => p.Name == request.InterestRateTier) == null)
                    throw new ValidationException(600, 0, "Invalid InterestRateTier.");
                interestRateTierKey =
                    programInterestTierMetaData.Tiers.FirstOrDefault(p => p.Name == request.InterestRateTier)!.Key;
            }

            var account = _accountService.GetAccount(request.AccountIdentifier);
            var productInterestTier = _interestRateService.GetProductInterestTierByProductKey(account.Product.ProductKey, null).FirstOrDefault(p => p.InterestTierKey == interestRateTierKey);
            if (productInterestTier == null)
            {
                throw new ValidationException(5, 355, "Invalid InterestRateTier. ");
            }

            var newAccountBalanceInterest = new AccountBalanceInterest
            {
                InterestYieldStartDate = string.IsNullOrEmpty(request.InterestYieldStartDate) ? DateTime.Now.Date : DateTime.Parse(request.InterestYieldStartDate),
                InterestRateTierKey = interestRateTierKey
            };

            bool autoAlign;
            if (request.AutoAlignStartDate.HasValue)
                autoAlign = (bool)request.AutoAlignStartDate;
            else
                autoAlign = true;

            var addInterestRateTierResponse = _interestRateService.Add(
                ProgramCode.FromString(request.ProgramCode),
                AccountIdentifier.FromString(request.AccountIdentifier),
                account.AccountKey,
                AccountBalanceIdentifier.FromString(request.PurseIdentifier),
                newAccountBalanceInterest,
                autoAlign);

            addInterestRateTierResponse.ResponseHeader = new ResponseHeader
            {
                ResponseId = request.RequestHeader.RequestId,
                StatusCode = 0,
                SubStatusCode = 0,
                Message = "Success"
            };

            return Task.FromResult(addInterestRateTierResponse);
        }

        public override void ReleaseLock(AddInterestRateTierRequest request)
        {
            _lockService.ReleaseApiLock(request.PurseIdentifier);
        }

        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IInterestRateService _interestRateService;
        private readonly ILockService _lockService;
        private readonly IAccountService _accountService;
        private readonly IInterestRateRepository _interestRateRepository;
    }
}
