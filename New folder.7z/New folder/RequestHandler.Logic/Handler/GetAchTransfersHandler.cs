﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.RequestHandler.Core.Domain.Services.Ach;
using RequestHandler.Core.Domain.Services.Ach;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetAchTransfersHandler : CommandHandlerBase<AchTransfersRequest, AchTransfersResponse>
    {
        private readonly ITransferService _transferService;
        private readonly IValidateIdentifier _validateIdentifier;
        private static string unspecifiedGuid = Guid.Empty.ToString();
        private readonly IAchService _achService;
        public GetAchTransfersHandler(ITransferService transferService, IValidateIdentifier validateIdentifier, IAchService achService)
        {
            _transferService = transferService;
            _validateIdentifier = validateIdentifier;
            _achService = achService;
        }

        public override void SetDomainContext(AchTransfersRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<AchTransfersResponse> VerifyIdentifiers(AchTransfersRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new AchTransfersResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AchTransfersResponse>(e, request));
            }
        }

        public override Task<AchTransfersResponse> Handle(AchTransfersRequest request)
        {
            try
            {
                List<Transfer> response = null;

                if (request.RequestHeader.RequestId == Guid.Empty)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId, $"{nameof(request)}.RequestHeader.RequestId must be specified");
                }

                if (string.IsNullOrEmpty(request.AccountIdentifier) || request.AccountIdentifier == unspecifiedGuid)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier, $"{nameof(request)}.TransferIdentifier must be specified");
                }

                DateTime endDate = request.EndDate.HasValue ? request.EndDate.Value : DateTime.MinValue;
                request.Status = request.Status != null && request.Status?.Length != 0 ? request.Status : new AchTransferStatus[] { };
                response = _transferService.GetAchTransfers(request.ProgramCode, request.AccountIdentifier,
                    request.StartDate, endDate, request.Status);

                return Task.FromResult(new AchTransfersResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                    TotalRecordCount = response.Count,
                    Transfers = response
                });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AchTransfersResponse>(e, request));
            }

        }
    }
}
