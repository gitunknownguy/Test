﻿using System;
using System.Linq;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Domain.Services.GlobalFundTransfer.Contracts;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;

namespace Gd.Bos.RequestHandler.Logic.Handler
{

    public class DeleteLinkHandler : CommandHandlerBase<DeleteLinkGlobalFoundTransferRequest, DeleteLinkGlobalFoundTransferResponse>
    {
        private readonly ITransferService _transferService;
        private readonly IValidateIdentifier _validateIdentifier;
        private static string unspecifiedGuid = Guid.Empty.ToString();

        public DeleteLinkHandler(ITransferService transferService, IValidateIdentifier validateIdentifier)
        {
            _transferService = transferService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(DeleteLinkGlobalFoundTransferRequest request)
        {
        }

        public override Task<DeleteLinkGlobalFoundTransferResponse> VerifyIdentifiers(DeleteLinkGlobalFoundTransferRequest request)
        {
            return Task.FromResult(new DeleteLinkGlobalFoundTransferResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<DeleteLinkGlobalFoundTransferResponse> Handle(DeleteLinkGlobalFoundTransferRequest request)
        {
            if (request.RequestHeader.RequestId == Guid.Empty)
            {
                throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId, $"{nameof(request)}.RequestHeader.RequestId must be specified");
            }

            if (string.IsNullOrEmpty(request.ProgramCode) || request.ProgramCode == unspecifiedGuid)
            {
                throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier, $"{nameof(request)}.ProgramCode must be specified");
            }

            if (string.IsNullOrEmpty(request.CustomerToken) || request.CustomerToken == unspecifiedGuid)
            {
                throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier, $"{nameof(request)}.CustomerToken must be specified");
            }

            if (string.IsNullOrEmpty(request.LinkId) || request.CustomerToken == unspecifiedGuid)
            {
                throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier, $"{nameof(request)}.LinkId must be specified");
            }

            var gfRequest = MapDeleteLinkRequest(request);

            var gftResponse = _transferService.DeleteCardLink(gfRequest);

            var response = new DeleteLinkGlobalFoundTransferResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                },
                LinkId = gftResponse.LinkId,
                Status = gftResponse.Status
            };

            if (gftResponse.ResponseDetails.Any())
            {
                var firstDetail = gftResponse.ResponseDetails.First();

                if (string.Compare(firstDetail.Description, "success", StringComparison.OrdinalIgnoreCase) != 0)
                {
                    response.ResponseHeader.Message = firstDetail.Description;
                    response.ResponseHeader.Details = firstDetail.Description;
                    response.ResponseHeader.StatusCode = firstDetail.Code;
                    response.ResponseHeader.SubStatusCode = firstDetail.SubCode;
                }
            }
            else
            {
                response.ResponseHeader.Message = "Unknown Error";
                response.ResponseHeader.Details = "Unknown Error";
                response.ResponseHeader.StatusCode = 4214;
                response.ResponseHeader.SubStatusCode = 1514;
            }
            return Task.FromResult(response);
        }

        private DeleteLinkRequest MapDeleteLinkRequest(DeleteLinkGlobalFoundTransferRequest request)
        {
            return new DeleteLinkRequest()
            {
                CustomerToken = request.CustomerToken,
                LinkId = request.LinkId,
                ProgramCode = request.ProgramCode,
                RequestId = request.RequestHeader.RequestId.ToString(),
            };
        }

    }
}
