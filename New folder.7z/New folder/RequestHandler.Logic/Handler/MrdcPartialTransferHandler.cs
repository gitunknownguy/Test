﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Services.MrdcPartial;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.MRDC;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using RequestHandler.Core.Utils;
using TransferType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class MrdcPartialTransferHandler : CommandHandlerBase<MrdcPartialTransferRequest, MrdcPartialTransferResponse>
    {
        public MrdcPartialTransferHandler(ITransferService transferService,
            IValidateIdentifier validateIdentifier,
            ILockService lockService)
        {
            _transferService = transferService;
            _validateIdentifier = validateIdentifier;
            _lockService = lockService;
        }

        public override void SetDomainContext(MrdcPartialTransferRequest request)
        {
            DomainContext.Current.Initiator = request.TransferRoute.TargetTransferEndpoint.AccountIdentifier;

        }

        public override Task<MrdcPartialTransferResponse> VerifyIdentifiers(MrdcPartialTransferRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramFunding(DomainContext.Current.ProgramFundingIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.Initiator, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidatePartner_AccountIdProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidatePartner_AccountIdProgramCode(DomainContext.Current.ReferencedAccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidatePartner_PartialFunding(request, DomainContext.Current.ProgramCode);

                return Task.FromResult(new MrdcPartialTransferResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<MrdcPartialTransferResponse>(e, request));
            }
        }

        public override async Task<MrdcPartialTransferResponse> ObtainLock(MrdcPartialTransferRequest request)
        {
            try
            {
                var lockId = DomainContext.Current.Initiator.ToString();

                await _lockService.ObtainApiLock($"Transfer_{lockId}");

                return new MrdcPartialTransferResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<MrdcPartialTransferResponse>(e, request);
            }
        }

        public override Task<MrdcPartialTransferResponse> Handle(MrdcPartialTransferRequest request)
        {
            try
            {
                if (request.RequestHeader.RequestId == Guid.Empty)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId, $"{nameof(request)}.RequestHeader.RequestId must be specified");
                }

                if (string.IsNullOrEmpty(request.TransferIdentifier) || request.TransferIdentifier == UnspecifiedGuid)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier, $"{nameof(request)}.TransferIdentifier must be specified");
                }

                if (DomainContext.Current.ProgramCode == null)
                {
                    DomainContext.Current.ProgramCode = ProgramCode.FromString(request.ProgramCode);
                }

                request.TransferIdentifier = request.TransferIdentifier.ToLower();

                var responseMrdcX9Transfer = HandleMrdcX9Transfer(request);

                return Task.FromResult(new MrdcPartialTransferResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = responseMrdcX9Transfer.Item3.StatusCode,
                        SubStatusCode = responseMrdcX9Transfer.Item3.SubStatusCode,
                        Message = responseMrdcX9Transfer.Item3.Message
                    },
                    Transfer = new MrdcPartialMainTransfer
                    {
                        AccountIdentifier = request.TransferRoute.TargetTransferEndpoint.AccountIdentifier,
                        CheckAmount = Math.Round(Math.Floor(request.TransferRoute.TransactionAmount * 100) / 100 * 1.00M, 2),
                        CheckCanceledDate = string.Empty,
                        TransferIdentifier = request.TransferIdentifier,
                        TransferStatus = responseMrdcX9Transfer.Item1.ToString().FirstCharToLowerCase(),
                        CheckReturnedDate = string.Empty,
                        CheckDeclinedDate = responseMrdcX9Transfer.Item2.CheckDeclinedDate?.ToString(),
                        RejectReason = responseMrdcX9Transfer.Item2.RejectReason,
                        CheckSubmitDate = responseMrdcX9Transfer.Item2.CheckSubmitDate,
                        PostingInfos = responseMrdcX9Transfer.Item2.PostingInfos
                    },

                });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<MrdcPartialTransferResponse>(e, request));
            }

        }

        private Tuple<MrdcX9TransferStatus, MrdcPartialDepositCheckResponse, ResponseHeader> HandleMrdcX9Transfer(MrdcPartialTransferRequest request)
        {
            TransferRequestValidation.HandleMrdcX9TransferValidation(request);

            var response = _transferService.TransferMrdcX9(
                request.TransferIdentifier,
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.TargetTransferEndpoint.AccountIdentifier,
                request.RequestHeader,
                request.ProgramCode,
                request.TransferRoute.SourceTransferEndpoint.Check,
                request.TransferRoute.SourceTransferEndpoint.CheckX9,
                request.TransferRoute.SourceTransferEndpoint.PostingInfos,
                false);

            Tuple<MrdcX9TransferStatus, MrdcPartialDepositCheckResponse, ResponseHeader> result = new Tuple<MrdcX9TransferStatus, MrdcPartialDepositCheckResponse, ResponseHeader>(response.Item1, response.Item2, response.Item3);

            return result;
        }

        public override void ReleaseLock(MrdcPartialTransferRequest request)
        {
            var lockId = DomainContext.Current.Initiator.ToString();

            if (request.TransferType == TransferType.DisbursementIn)
                lockId = DomainContext.Current.ReferencedAccountIdentifier.ToString();
            _lockService.ReleaseApiLock("Transfer_" + lockId);
        }

        private readonly ITransferService _transferService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ILockService _lockService;
        private static readonly string UnspecifiedGuid = Guid.Empty.ToString();
    }
}
