﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Newtonsoft.Json;
using static Dapper.SqlMapper;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class FraudKycCureHandler : CommandHandlerBase<FraudKycCureRequest, FraudKycCureResponse>
    {
        private readonly Core.Domain.Services.Tokenizer.ITokenizerService _tokenizerService;
        private readonly IAccountService _accountService;
        public FraudKycCureHandler(IVerificationService verificationService,
            INotificationService notificationPublisher,
            IEnrollmentDataAccess enrollmentDataAccess,
            IValidateIdentifier validateIdentifier,
            Core.Domain.Services.Tokenizer.ITokenizerService tokenizerService,
            IAccountService accountService)
        {
            _notificationPublisher = notificationPublisher;
            _verificationService = verificationService;
            _enrollmentDataAccess = enrollmentDataAccess;
            _validateIdentifier = validateIdentifier;
            _tokenizerService = tokenizerService;
            _accountService = accountService;


        }

        public override void SetDomainContext(FraudKycCureRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            DomainContext.Current.UserIdentifier = request.UserIdentifier;
        }

        public override Task<FraudKycCureResponse> VerifyIdentifiers(FraudKycCureRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidateConsumerProfileIdentifier(DomainContext.Current.AccountIdentifier, DomainContext.Current.UserIdentifier);
                if (!string.IsNullOrEmpty(request.DateOfBirth))
                    _validateIdentifier.ValidateDOB(request.DateOfBirth);
                return Task.FromResult(new FraudKycCureResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<FraudKycCureResponse>(e, request));
            }
        }

        private void AccountLimitValidateExceptionMapping(AccountLimit accountLimit)
        {
            if (accountLimit.ResponseCode == "260")
                throw new RequestHandlerException(2, 60, "Number of Active Accounts Exceeded.");
            else if (accountLimit.ResponseCode == "267")
                throw new RequestHandlerException(2, 67, "7 day opened account limit exceeded.");
            else if (accountLimit.ResponseCode == "268")
                throw new RequestHandlerException(2, 68, "30 day opened account limit exceeded.");
        }

        public override Task<FraudKycCureResponse> Handle(FraudKycCureRequest request)
        {
            try
            {
                string enrollmentRequestIdentifier = null;
                if (request.RequestHeader.Options != null && request.RequestHeader.Options.ContainsKey("X-GD-EnrollmentRequestIdentifier"))
                {
                    enrollmentRequestIdentifier = request.RequestHeader.Options["X-GD-EnrollmentRequestIdentifier"].ToString();
                }

                var account = _accountService.GetAccount(request.AccountIdentifier);
                var accountLimit = _accountService.AccountLimitVerification(request.Ssn, string.Empty, "SSN", false, account.Product.ProductCode.ToString(), request.ProgramCode);
                accountLimit.ResponseCode = accountLimit.ResponseCode ?? "0";
                AccountLimitValidateExceptionMapping(accountLimit);

                var token = _tokenizerService.TokenizeSsn(request.Ssn, request.ProgramCode);

                CreateVerifyRequest createVerifyRequest = new CreateVerifyRequest();
                FraudKycCureResponse response = null;

                createVerifyRequest.AccountIdentifier = request.AccountIdentifier;
                createVerifyRequest.UserIdentifier = request.UserIdentifier;
                createVerifyRequest.IsPostEnrollmentKyc = true;
                createVerifyRequest.IdentityRequest = new CreateRiskRequest
                {
                    SSNToken = token,
                    DateOfBirth = request.DateOfBirth,
                    FirstName = request.Name?.FirstName,
                    MiddleName = request.Name?.MiddleName,
                    LastName = request.Name?.LastName,
                    Last4SSN = request.Ssn == null || request.Ssn.Length < 4 ? null : request.Ssn.Substring(request.Ssn.Length - 4, 4)
                };
                createVerifyRequest.ContactVerificationIdentifiers = request.ContactVerificationIdentifiers;
                createVerifyRequest.ProspectType = request.ProspectType;
                createVerifyRequest.EnrollmentRequestIdentifier = enrollmentRequestIdentifier;
                createVerifyRequest.FraudData = request.FraudData;
                createVerifyRequest.ProductCode = account.Product?.ProductCode?.ToString();
                createVerifyRequest.ProductName = account.Product?.ProductName;
                createVerifyRequest.ProgramCode = request.ProgramCode;

                var kycData = _verificationService.PostEnrollmentFraudVerification(createVerifyRequest, true);

                if (kycData?.IsKyc == false)
                {
                    response = new FraudKycCureResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 1,
                            SubStatusCode = 12,
                            Message = "KYC Gate does not match kycPendingGate"
                        },
                        KycGate = new Bos.Shared.Common.Core.CoreApi.Contract.Data.KycGate()
                        {
                            KycStateData = new Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData()
                            {
                                PendingKycGate = kycData.KycPendingGate?.ToLower()
                            }
                        }
                    };
                }
                else
                {
                    response = new FraudKycCureResponse();

                    response.ResponseHeader = response.ResponseHeader.GetResponseHeader(kycData?.ResponseCode.ToString(), request.RequestHeader.RequestId);

                    response.KycGate = new Bos.Shared.Common.Core.CoreApi.Contract.Data.KycGate()
                    {
                        KycStateData = new Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData()
                        {
                            KycStatus = kycData?.KycStatus.ToString().ToLower(),
                            OfacStatus = kycData?.OfacStatus.ToString().ToLower(),
                            PendingKycGate = kycData?.KycPendingGate?.ToLower()
                        }
                    };
                }

                if (kycData?.KycPendingGate?.ToLower() != "kyc2")
                {
                    var accountResp =
                        _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(request.AccountIdentifier,
                            request.ProgramCode, true);
                    _notificationPublisher.PublishNotification(request.ProgramCode, accountResp.Account,
                        Bos.Shared.Common.Core.CoreApi.Contract.Data.EventType.AccountUpdated);
                }

                return Task.FromResult(response);
            }
            catch (Exception e)
            {

                return Task.FromResult(e.HandleException<FraudKycCureResponse>(e, request));
            }
        }


        private readonly INotificationService _notificationPublisher;
        private IVerificationService _verificationService;
        private readonly IEnrollmentDataAccess _enrollmentDataAccess;
        private readonly IValidateIdentifier _validateIdentifier;

    }
}
