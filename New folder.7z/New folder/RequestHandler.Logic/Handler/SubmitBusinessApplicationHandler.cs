﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using AccountStatusReason = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.AccountStatusReason;

namespace RequestHandler.Logic.Handler
{
    public class SubmitBusinessApplicationHandler : CommandHandlerBase<SubmitBusinessApplicationRequest, SubmitBusinessApplicationResponse>
    {
        private readonly ISubmitBusinessApplicationService _submitBusinessApplicationService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IEnrollmentDataAccess _enrollmentDataAccess;

        public SubmitBusinessApplicationHandler(ISubmitBusinessApplicationService submitBusinessApplicationService
        , IValidateIdentifier validateIdentifier, IEnrollmentDataAccess enrollmentDataAccess)
        {
            _submitBusinessApplicationService = submitBusinessApplicationService;
            _validateIdentifier = validateIdentifier;
            _enrollmentDataAccess = enrollmentDataAccess;
        }

        public override void SetDomainContext(SubmitBusinessApplicationRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
            {
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            }
        }

        public override Task<SubmitBusinessApplicationResponse> VerifyIdentifiers(SubmitBusinessApplicationRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidatePartner_AccountIdProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new SubmitBusinessApplicationResponse()
                {
                    ResponseHeader = new ResponseHeader()
                });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<SubmitBusinessApplicationResponse>(e, request));
            }
        }

        public override Task<SubmitBusinessApplicationResponse> Handle(SubmitBusinessApplicationRequest request)
        {
            var response = new SubmitBusinessApplicationResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0
                }
            };

            try
            {
                if (string.IsNullOrEmpty(request.AccountIdentifier))
                    throw new AccountNotFoundException();

                if (string.IsNullOrEmpty(request.ProgramCode))
                    throw new ArgumentNullException($"ProgramCode: Program Code cannot be null or empty.");


                var submitBusinessApplication = new SubmitBusinessApplicationRequest
                {
                    AccountIdentifier = request.AccountIdentifier,
                    ProgramCode = request.ProgramCode,
                    RequestHeader = request.RequestHeader
                };


                var accountResp = _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(request.AccountIdentifier, request.ProgramCode, false);

                // GBOS-91075 Reject enrollments that have already completed/not in pending status
                if (accountResp != null)
                {
                    if (accountResp.Account?.AccountHolders?.Count > 0
                        && accountResp.Account?.AccountHolders[0].PaymentInstruments?.Count > 0)
                    {
                        response.ResponseHeader.StatusCode = 400;
                        response.ResponseHeader.SubStatusCode = 4127;
                        response.ResponseHeader.Message = "Enrollment already completed. / Account has payment instruments created.";
                        return Task.FromResult(response);
                    }

                }


                response = _submitBusinessApplicationService.SubmitBusinessApplication(submitBusinessApplication, accountResp);

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<SubmitBusinessApplicationResponse>(e, request));
            };

        }
    }
}