﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using NLog;
using RequestHandler.Core.Domain.Services.RetailCard;
using Account = Gd.Bos.RequestHandler.Core.Domain.Model.Account.Account;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using SetPinRequest = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.SetPinRequest;
using SetPinResponse = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.SetPinResponse;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class SetPinHandler : CommandHandlerBase<SetPinRequest, SetPinResponse>
    {
        private readonly IPaymentInstrumentService _paymentInstrumentService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly INotificationService _notificationService;
        private readonly ILockService _lockService;
        private readonly IRetailCardService _retailCardService;
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        public SetPinHandler(IPaymentInstrumentService paymentInstrumentService, IValidateIdentifier validateIdentifier, INotificationService notificationService, ILockService lockService, IRetailCardService retailCardService)
        {
            _paymentInstrumentService = paymentInstrumentService;
            _validateIdentifier = validateIdentifier;
            _notificationService = notificationService;
            _lockService = lockService;
            _retailCardService = retailCardService;
        }

        public override void SetDomainContext(SetPinRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            if (!string.IsNullOrEmpty(request.PaymentInstrumentIdentifier))
                DomainContext.Current.PaymentInstrumentIdentifier = request.PaymentInstrumentIdentifier;
        }

        public override Task<SetPinResponse> VerifyIdentifiers(SetPinRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidatePaymentInstrumentIdentifier(DomainContext.Current.AccountIdentifier, DomainContext.Current.PaymentInstrumentIdentifier);
                _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 4, 105);
                return Task.FromResult(new SetPinResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<SetPinResponse>(e, request));
            }
        }

        public override async Task<SetPinResponse> ObtainLock(SetPinRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock("Card_" + DomainContext.Current.AccountIdentifier.ToString());
                return new SetPinResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<SetPinResponse>(e, request);
            }
        }

        public override Task<SetPinResponse> Handle(SetPinRequest request)
        {
            try
            {
                if (IsRetailTempCard(request)) // check if we need to set atm pin for a legacy temp card as well
                {
                    // run same pin validations as perso card
                    _paymentInstrumentService.ValidatePin(request.AccountIdentifier, request.PaymentInstrumentIdentifier, request.Pin);

                    var gssResponse = _retailCardService.SetAtmPin(new SetAtmPinRequest
                    {
                        AccountIdentifier = request.AccountIdentifier,
                        AtmPin = request.Pin,
                        ProgramCode = request.ProgramCode,
                        RequestHeader = request.RequestHeader
                    });

                    if (gssResponse.ResponseHeader.StatusCode != 0)
                    {
                        return Task.FromResult(new SetPinResponse
                        {
                            PinSet = false,
                            ResponseHeader = new ResponseHeader
                            {
                                ResponseId = request.RequestHeader.RequestId,
                                StatusCode = gssResponse.ResponseHeader.StatusCode,
                                SubStatusCode = gssResponse.ResponseHeader.SubStatusCode,
                                Message = gssResponse.ResponseHeader.Message
                            }
                        });
                    }

                    var paymentIdentifier = _paymentInstrumentService.GetPaymentIdentifier(request.AccountIdentifier, request.PaymentInstrumentIdentifier);
                    _paymentInstrumentService.UpdatePinChangeDate(paymentIdentifier.PaymentIdentifierKey, request.Channel, DateTime.Now);
                }
                else
                {
                    _paymentInstrumentService.SetPin(request.AccountIdentifier, request.PaymentInstrumentIdentifier,
                        request.Pin);

                    var paymentIdentifier = _paymentInstrumentService.GetPaymentIdentifier(request.AccountIdentifier,
                        request.PaymentInstrumentIdentifier);

                    _paymentInstrumentService.UpdatePinChangeDate(paymentIdentifier.PaymentIdentifierKey,request.Channel, DateTime.Now);

                    var atmPinResetRequest = new AtmPinResetTransferToPublish
                    {
                        AccountIdentifier = request.AccountIdentifier,
                        AtmPinSetDetail = new AtmPinSetDetail
                        {
                            PaymentInstrumentIdentifier = request.PaymentInstrumentIdentifier,
                            PaymentIdentifier = paymentIdentifier.PaymentIdentifierIdentifier.ToString(),
                            Bin = _paymentInstrumentService.GetBinByPan(paymentIdentifier.PaymentInstrument.Pan),//paymentIdentifier.PaymentInstrument.Pan.Substring(0, 6),
                            Last4Pan = paymentIdentifier.PaymentInstrument.Last4Pan,
                            AtmPinSetDateTime = paymentIdentifier.PaymentInstrument.PinSetDate?.ToUniversalTime()
                                .ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
                        }
                    };

                    _notificationService.PublishNotification(request.RequestHeader.RequestId, request.ProgramCode,
                        atmPinResetRequest, EventType.AtmPinReset);
                }

                var response = new SetPinResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                    PinSet = true
                };

                return Task.FromResult(response);

            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<SetPinResponse>(e, request));
            }
        }

        // method to determine if we are trying to set a retail temp card (need to call gss set atm pin)
        private bool IsRetailTempCard(SetPinRequest request)
        {
            Logger.Debug($"SetAtmPin - Starting IsRetailTempCard logic. AccountId:{request.AccountIdentifier}, RequestId:{request.RequestHeader.RequestId}");

            var tuple = _paymentInstrumentService.GetPaymentIdentifierInfoByAccountIdentifier(request.AccountIdentifier);

            var account = tuple.Item1;
            // PaymentIdentifierInfo paymentIdentifierInfo = tuple.Item2;
            var paymentInstrumentInfoList = tuple.Item3;

            var paymentInstrumentInfo = paymentInstrumentInfoList.FirstOrDefault(a => a.PaymentInstrumentIdentifier == Guid.Parse(request.PaymentInstrumentIdentifier));

            if (account != null && !Configuration.Current.RetailCardProductCode.Split(',').Contains(account.Product.ProductCode.ToString()))
            {
                //if its not a 40007 product then its not a retail temp 
                Logger.Debug($"IsRetailTempCard - not {Configuration.Current.RetailCardProductCode}, not retail temp. AccountId:{request.AccountIdentifier}, RequestId:{request.RequestHeader.RequestId}");
                return false;
            }

            if (paymentInstrumentInfo == null)
            {
                Logger.Info($"IsRetailTempCard - NPNR Scenario - need to call Legacy. AccountId:{request.AccountIdentifier}, RequestId:{request.RequestHeader.RequestId}");
                //NPNR scenario: temp card activated and perso card Not activate. Goto Legacy GetBalance
                return true;
            }

            if (paymentInstrumentInfo.PaymentInstrumentType == PaymentInstrumentType.MagStripe)
            {
                Logger.Info($"IsRetailTempCard - PaymentInstrumentType=MagStripe - Temp card, need to call legacy. AccountId:{request.AccountIdentifier}, RequestId:{request.RequestHeader.RequestId}, PaymentInstrumentIdentifier:{paymentInstrumentInfo.PaymentInstrumentIdentifier}");
                return true;
            }

            Logger.Debug($"IsRetailTempCard - default scenario (false). AccountId:{request.AccountIdentifier}, RequestId:{request.RequestHeader.RequestId}");
            return false;
        }

        public override void ReleaseLock(SetPinRequest request)
        {
            _lockService.ReleaseApiLock("Card_" + DomainContext.Current.AccountIdentifier.ToString());
        }

    }
}
