﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Application.UpgradeAccount;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Interest;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Services.Dcpp;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.Common.Data;
using Gd.Bos.Shared.Common.Core.Common.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.UtilityCoreApi.Contract.Enum;
using RequestHandler.Core.Domain.Model.Inventory;
using RequestHandler.Core.Domain.Services.RetailCard;
using PaymentInstrumentAttribute = Gd.Bos.Shared.Common.Core.Common.Enum.PaymentInstrumentAttributes;
using PaymentInstrumentType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PaymentInstrumentType;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetEnrollmentHandler : CommandHandlerBase<GetEnrollmentRequest, GetEnrollmentResponse>
    {
        private readonly IEnrollmentDataAccess _enrollmentDataAccess;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IInterestRateRepository _interestRateRepository;
        private readonly IRetailCardService _retailCardService;
        private readonly IInstantIssueCardInventoryRepository _instantIssueCardInventoryRepository;
        private readonly IUpgradeAccountService _upgradeAccountService;
        private readonly IDcppService _dcppService;
        private readonly IAccountBalanceRepository _accountBalanceRepository;
        private readonly IBaasConfiguration _baasConfiguration;
        private readonly IPaymentIdentifierRepository _paymentIdentifierRepository;
        private readonly IProductService _productService;
        private readonly IUserRepository _userRepository;

        public GetEnrollmentHandler(
            IEnrollmentDataAccess enrollmentDataAccess,
            IValidateIdentifier validateIdentifier,
            IInterestRateRepository interestRateRepository,
            IRetailCardService retailCardService,
            IInstantIssueCardInventoryRepository instantIssueCardInventoryRepository,
            IUpgradeAccountService upgradeAccountService,
            IDcppService dcppService,
            IAccountBalanceRepository accountBalanceRepository,
            IBaasConfiguration baasConfiguration,
            IPaymentIdentifierRepository paymentIdentifierRepository,
            IProductService productService,
            IUserRepository userRepository
            )
        {
            _enrollmentDataAccess = enrollmentDataAccess;
            _validateIdentifier = validateIdentifier;
            _interestRateRepository = interestRateRepository;
            _retailCardService = retailCardService;
            _instantIssueCardInventoryRepository = instantIssueCardInventoryRepository;
            _upgradeAccountService = upgradeAccountService;
            _dcppService = dcppService;
            _accountBalanceRepository = accountBalanceRepository;
            _baasConfiguration = baasConfiguration;
            _paymentIdentifierRepository = paymentIdentifierRepository;
            _productService = productService;
            _userRepository = userRepository;
        }

        public override void SetDomainContext(GetEnrollmentRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetEnrollmentResponse> VerifyIdentifiers(GetEnrollmentRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetEnrollmentResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetEnrollmentResponse>(e, request));
            }
        }

        public override Task<GetEnrollmentResponse> Handle(GetEnrollmentRequest request)
        {
            try
            {
                var token = new CancellationToken();
                var getEnrollmentResponse = _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(request.AccountIdentifier, request.ProgramCode, request.IncludePrivatePaymentInstrumentData);

                if (getEnrollmentResponse == null)
                {
                    throw new AccountNotFoundException();
                }

                //TODO: Need to get a purse from GSS
                if (request.ProgramCode.Equals(Configuration.Current.GBRProgramCode,
                    StringComparison.OrdinalIgnoreCase) && (getEnrollmentResponse.Account.Purses == null || getEnrollmentResponse.Account.Purses.Count == 0))
                {
                    var tempPurse = _retailCardService.GetBalance(new GetPursesRequest() { AccountIdentifier = request.AccountIdentifier, ProgramCode = request.ProgramCode, RequestHeader = request.RequestHeader });
                    getEnrollmentResponse.Account.Purses = tempPurse?.Purses?.ToList();
                }


                var accountBalanceInterests =
                    _interestRateRepository.GetAccountBalanceInterests(request.AccountIdentifier);
                var programInterestTierMetaData =
                    _interestRateRepository.GetProductInterestTierInfoByProgramCode(request.ProgramCode);

                if (getEnrollmentResponse.Account.Purses != null && getEnrollmentResponse.Account.Purses.Count > 0)
                {
                    foreach (var purse in getEnrollmentResponse.Account.Purses)
                    {
                        var activeTier = _interestRateRepository.GetActiveTier(
                            accountBalanceInterests.Where(a =>
                                a.AccountBalanceIdentifier == purse.PurseIdentifier));
                        purse.InterestRateTierIdentifier = activeTier?.AccountBalanceInterestIdentifier.ToString();
                        purse.APY = activeTier?.APY;
                        purse.InterestRateTier = (activeTier != null) ? programInterestTierMetaData?.Tiers?.FirstOrDefault(p => p.Key == activeTier?.InterestRateTierKey)?.Name : String.Empty;
                        purse.InterestYieldStartDate = activeTier?.InterestYieldStartDate.Value.ToString("yyyy-MM-dd");
                        purse.InterestYieldEndDate = activeTier?.InterestYieldEndDate?.ToString("yyyy-MM-dd");
                    }
                    bool getBalanceFromPartner = _baasConfiguration.GetBalanceFromPartner(request?.ProgramCode?.ToLower());
                    if (getBalanceFromPartner)
                    {
                        bool isRoutingToCPM = _dcppService.IsRoutingToCPM(request.AccountIdentifier);
                        if (isRoutingToCPM)
                        {
                            var primaryPurse = getEnrollmentResponse.Account.Purses.FirstOrDefault(p => p.PurseType == Shared.Common.Core.CoreApi.Contract.Data.Enum.PurseType.Primary);
                            if (primaryPurse != null)
                            {
                                var accountBalance = _dcppService.GetAccountBalance(request.ProgramCode, request.AccountIdentifier);
                                DateTime now = TimeZoneInfo.ConvertTime(DateTime.Now, TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time"));

                                if (accountBalance?.AvailableBalance != null)
                                {
                                    if (primaryPurse.AvailableBalance != accountBalance.AvailableBalance.Amount &&
                                        primaryPurse.AvailableBalanceAsOfDateTime != null &&
                                        primaryPurse.AvailableBalanceAsOfDateTime < now)
                                        primaryPurse.AvailableBalanceAsOfDateTime = now;
                                    primaryPurse.AvailableBalance = accountBalance.AvailableBalance.Amount;
                                }

                                if (accountBalance?.CurrentBalance != null)
                                {
                                    if (primaryPurse.LedgerBalance != accountBalance.CurrentBalance.Amount &&
                                        primaryPurse.LedgerBalanceAsOfDateTime != null &&
                                        primaryPurse.LedgerBalanceAsOfDateTime < now)
                                        primaryPurse.LedgerBalanceAsOfDateTime = now;
                                    primaryPurse.LedgerBalance = accountBalance.CurrentBalance.Amount;
                                }

                                if (primaryPurse.AvailableBalance != 0)
                                {
                                    AccountBalance balance = new AccountBalance(AccountBalanceIdentifier.FromString(primaryPurse.PurseIdentifier), true, false);
                                    balance.SetAvailableBalance(primaryPurse.AvailableBalance);
                                    balance.SetCurrentBalance(primaryPurse.LedgerBalance);

                                    _accountBalanceRepository.UpdateForAci(balance, now, now);
                                }

                            }
                        }
                    }
                }

                //Only for GPR products check if account is an Instant Issue
                if (getEnrollmentResponse.Account.ProductCode == "51711" && !string.IsNullOrEmpty(_instantIssueCardInventoryRepository.GetInstantIssueCardInventoryByAccountIdentifier(new Guid(getEnrollmentResponse.Account.AccountIdentifier))))
                {
                    getEnrollmentResponse.Account.InstantIssue = true;
                }

                getEnrollmentResponse.Account.ProductClass = _productService.GetProductClassByProductTierKey(getEnrollmentResponse.Account.ProductTierKey);
                getEnrollmentResponse.Account.EnrollmentSource = GetEnrollmentSource(getEnrollmentResponse.Account);

                getEnrollmentResponse.ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                };

                getEnrollmentResponse.Account.UpgradeKycStateData = _upgradeAccountService.GetUpgradeKycStateData(
                    request.ProgramCode,
                    getEnrollmentResponse.Account.ProductCode,
                    getEnrollmentResponse.Account.AccountIdentifier,
                    getEnrollmentResponse.Account.UpgradeKycStateData);

                var cardIssueSource = _productService.GetAllProductTierInfoByProgramCodeProductCode(request.ProgramCode, getEnrollmentResponse.Account.ProductCode).FirstOrDefault(p => p.ProductTierAttribute == "CardIssueSource");
                //Get PMT by PaymentInstrumentIdentifier
                getEnrollmentResponse.Account?.AccountHolders?.ForEach(
                    accountHolder =>
                    {
                        if (accountHolder.PaymentInstruments != null)
                        {
                            foreach (var paymentInstrument in accountHolder.PaymentInstruments)
                            {
                                paymentInstrument.ProductMaterialType =
                                    GetPmtByPaymentInstrumentIdentifier(paymentInstrument.PaymentInstrumentIdentifier);
                                this.SetPmtCardIssueSource(paymentInstrument, cardIssueSource);
                            }
                        }
                    }
                );

                return Task.FromResult(getEnrollmentResponse);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetEnrollmentResponse>(e, request));
            }
        }
        private void SetPmtCardIssueSource(Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PaymentInstrument paymentInstrument, ProductTierInfo cardIssueSource)
        {
            if (paymentInstrument.PaymentInstrumentType == PaymentInstrumentType.MagStripe)
            {
                if (cardIssueSource != null)
                {
                    switch (cardIssueSource.Value)
                    {
                        case "Retail":
                            paymentInstrument.CardIssueSource = CardIssueSource.Retailer;
                            break;
                        case "FSC":
                            paymentInstrument.CardIssueSource = CardIssueSource.FSC;
                            break;
                    }
                }
                else
                {
                    paymentInstrument.CardIssueSource = CardIssueSource.Mailer;
                }
            }
            else if (paymentInstrument.PaymentInstrumentType == PaymentInstrumentType.ContactlessEmv || paymentInstrument.PaymentInstrumentType == PaymentInstrumentType.Emv)
            {
                paymentInstrument.CardIssueSource = IsCardPrintable(paymentInstrument.PaymentInstrumentIdentifier) ? CardIssueSource.FSC : CardIssueSource.Mailer;
            }
        }
        private bool IsCardPrintable(string paymentInstrumentIdentifier)
        {
            return this.GetCardPrintableByPaymentInstrumentIdentifier(paymentInstrumentIdentifier) == "true" ? true : false;
        }
        private string GetCardPrintableByPaymentInstrumentIdentifier(string paymentInstrumentIdentifier)
        {
            var paymentInstrumentDetail = _paymentIdentifierRepository.GetPaymentInstrumentDetails(Guid.Parse(paymentInstrumentIdentifier))
             .FirstOrDefault(p =>
                 p.PaymentInstrumentAttribute == PaymentInstrumentAttribute.CardPrintable);
            return paymentInstrumentDetail?.PaymentInstrumentAttributeValue;
        }
        private string GetPmtByPaymentInstrumentIdentifier(string paymentInstrumentIdentifier)
        {
            if (!Guid.TryParse(paymentInstrumentIdentifier, out var identifier))
            {
                return null;
            }

            var paymentInstrumentDetail = _paymentIdentifierRepository.GetPaymentInstrumentDetails(identifier)
                .FirstOrDefault(p =>
                    p.PaymentInstrumentAttribute == PaymentInstrumentAttribute.SelectedProductMaterialType);
            return paymentInstrumentDetail?.PaymentInstrumentAttributeValue;
        }

        private EnrollmentSource GetEnrollmentSource(Shared.Common.Core.CoreApi.Contract.Data.Account account)
        {
            var user = account.AccountHolders?.Select(x => x.User)
                .FirstOrDefault( y => y?.IsPrimaryAccountHolder == true);

            if(!string.IsNullOrEmpty(user?.UserIdentifier))
            {
                var prospectInfo = _userRepository.GetConsumerProfileExtension(user.UserIdentifier)
                    .Find(x => x.ConsumerProfileExtensionAttributeKey == (int)ConsumerProfileExtensionAttribute.ProspectProfile);
                
                if(prospectInfo != null)
                {
                    return EnrollmentSource.Prospect;
                }
            }

            return _productService.GetEnrollmentSourceByProductTierKey(account.ProductTierKey);
        }
    }
}
