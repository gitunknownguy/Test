﻿using System;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CareCoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;

namespace RequestHandler.Logic.Handler
{
    public class GetAccountForShowcaseHandler(
        IAccountService accountService, 
        IValidateIdentifier validateIdentifier
        )
        : CommandHandlerBase<GetAccountForShowcaseRequest, GetAccountForShowcaseResponse>
    {
        public override void SetDomainContext(GetAccountForShowcaseRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetAccountForShowcaseResponse> VerifyIdentifiers(GetAccountForShowcaseRequest request)
        {
            try
            {
                validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetAccountForShowcaseResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetAccountForShowcaseResponse>(e, request));
            }
        }

        public override Task<GetAccountForShowcaseResponse> Handle(GetAccountForShowcaseRequest request)
        {
            try
            {
                var result = accountService.GetAccountByAccountIdentifierForShowcase(request.AccountIdentifier);

                GetAccountForShowcaseResponse response = new()
                {
                    AccountIdentifier = result.AccountIdentifier, AccountBillCycleDay = result.AccountBillCycleDay,
                    AccountCreateDate = result.AccountCreateDate,
                    AccountStatus = (AccountStatus)result.AccountStatus,
                    AccountStatusChangeDate = result.AccountStatusChangeDate,
                    ProductCode = result.ProductCode,
                    IsOptIn = result.IsOptIn,
                    CurrentFeature = result.CurrentFeature,
                    TermsAcceptances = result.TermsAcceptances,
                    ResponseHeader = new ResponseHeader()
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    }
                };

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetAccountForShowcaseResponse>(e, request));
            }
        }
    }
}
