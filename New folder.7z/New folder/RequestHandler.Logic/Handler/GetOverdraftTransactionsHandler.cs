﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Domain.Services.Overdraft;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetOverdraftTransactionsHandler : CommandHandlerBase<GetOverdraftTransactionsRequest, GetOverdraftTransactionsResponse>
    {
        private readonly IOverdraftService _overdraftService;
        private readonly IAccountBalanceRepository _accountBalanceRepository;
        private readonly IValidateIdentifier _validateIdentifier;

        public GetOverdraftTransactionsHandler(
            IOverdraftService overdraftService,
            IAccountBalanceRepository accountBalanceRepository,
            IValidateIdentifier validateIdentifier
            )
        {
            _overdraftService = overdraftService;
            _accountBalanceRepository = accountBalanceRepository;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(GetOverdraftTransactionsRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetOverdraftTransactionsResponse> VerifyIdentifiers(GetOverdraftTransactionsRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetOverdraftTransactionsResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetOverdraftTransactionsResponse>(e, request));
            }
        }

        public override async Task<GetOverdraftTransactionsResponse> Handle(GetOverdraftTransactionsRequest request)
        {
            try
            {
                bool startDateSuccess = DateTime.TryParse(request.StartDate, out var startDate);
                bool endDateSuccess = DateTime.TryParse(request.EndDate, out var endDate);

                if (!startDateSuccess)
                {
                    startDate = DateTime.MinValue;
                }

                if (!endDateSuccess)
                {
                    startDate = DateTime.Today;
                }

                var reinstatementKeyResult =
                    await _overdraftService.GetAccountSubscriptionReinstatementInfo(request.AccountKey,
                       startDate, endDate, 1);

                var result = await _overdraftService.GetOverdraftTransactions(request.AccountIdentifier, request.StartDate,
                    request.EndDate);

                result.ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                };

                // GET MOST RECENT REINSTATEMENT KEY
                var reinstatementKey =
                    reinstatementKeyResult?.MaxBy(x => x.ReinstatementDate);

                result.AccountSubscriptionReinstatementReasonKey =
                    reinstatementKey?.AccountSubscriptionReinstatementReasonKey.ToString() ?? "";

                return result;
            }
            catch (Exception e)
            {
                return e.HandleException<GetOverdraftTransactionsResponse>(e, request);
            }
        }
    }
}
