﻿using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Services.Crypto;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Services.Dcpp;
using System.Linq;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.PInstantIssue;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using RequestHandler.Core.Domain.Model.Payment;
using Microsoft.Data.SqlClient;
using Gd.Bos.Shared.Common.Core.Data;
using PaymentInstrumentAttribute = Gd.Bos.Shared.Common.Core.Common.Enum.PaymentInstrumentAttributes;
using PaymentInstrumentType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PaymentInstrumentType;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class InstantIssueGetPaymentInstrumentListHandler : CommandHandlerBase<GetPaymentInstrumentListRequest, InstantIssueEnrollmentResponse>
    {
        private readonly IDcppService _processorRoutingService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IPaymentInstrumentService _paymentInstrumentService;
        private readonly ICryptoService _cryptoService;
        private readonly IAccountService _accountService;
        private readonly IDataAccess _dataAccess;
        public readonly ITokenizerService _tokenizerService;
        private readonly IPaymentIdentifierRepository _paymentIdentifierRepository;

        public InstantIssueGetPaymentInstrumentListHandler(
            IDcppService processorRoutingService,
            IPaymentInstrumentService paymentInstrumentService,
            IValidateIdentifier validateIdentifier,
            ICryptoService cryptoService,
            IAccountService accountService,
            ITokenizerService tokenizerService,
            IDataAccess DataAccess,
            IPaymentIdentifierRepository paymentIdentifierRepository)
        {
            _dataAccess = DataAccess;
            _paymentInstrumentService = paymentInstrumentService;
            _validateIdentifier = validateIdentifier;
            _cryptoService = cryptoService;
            _accountService = accountService;
            _tokenizerService = tokenizerService;
            _processorRoutingService = processorRoutingService;
            _paymentIdentifierRepository = paymentIdentifierRepository;
        }

        public override void SetDomainContext(GetPaymentInstrumentListRequest request)
        {
            // Check if the request has AccountNumber or accountIdentifier
            if (!Guid.TryParse(request.AccountIdentifier, out var newGuid))
            {
                SqlParameter[] parameters = new[]
                {
                        new SqlParameter() {ParameterName = "AccountReferenceNumber", Value = request.AccountIdentifier},
                };

                using var reader = _dataAccess.ExecuteReader("[CRM].[GetAccountInfoByAccountReferenceNumber]", _dataAccess.CreateConnection(), parameters);
                if (reader.Read())
                {

                    request.AccountIdentifier = reader.GetGuid(reader.GetOrdinal("AccountIdentifier")).ToString();
                }
                else
                {
                    throw new ValidationException(10, 0, "Account Not Found.");
                }
            }
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<InstantIssueEnrollmentResponse> VerifyIdentifiers(GetPaymentInstrumentListRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidatePaymentInstrumentIdentifier(DomainContext.Current.AccountIdentifier, DomainContext.Current.PaymentInstrumentIdentifier);
                return Task.FromResult(new InstantIssueEnrollmentResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<InstantIssueEnrollmentResponse>(e, request));
            }
        }

        public override Task<InstantIssueEnrollmentResponse> Handle(GetPaymentInstrumentListRequest request)
        {
            try
            {
                string message = "Success";
                var accountResponse = _accountService.GetAccount(request.AccountIdentifier);
                InstantIssueEnrollmentResponse getPaymentInstrumentsResponse = new InstantIssueEnrollmentResponse
                {
                    AccountIdentifier = accountResponse?.AccountIdentifier?.ToString(),
                    AccountReferenceNumber = accountResponse?.AccountReferenceNumber
                };
               
                List<InstantIssuePaymentInstrument> PLSPaymentInstrumentsResult = new List<InstantIssuePaymentInstrument>();

                if (accountResponse.AccountStatus.Equals(Core.Domain.Model.Account.AccountStatus.Normal))
                {
                    List<PaymentIdentifierData> paymentIdentifiersData = _accountService.GetPaymentIdentifierByAccountIdentifier(request.AccountIdentifier);

                    if (paymentIdentifiersData != null && paymentIdentifiersData.Count > 0)
                    {
                        foreach (var pi in paymentIdentifiersData)
                        {
                            if(request.ExcludeTempCards.HasValue && request.ExcludeTempCards == true && pi.PaymentInstrumentTypeKey == (int)PaymentInstrumentType.MagStripe)
                                continue;

                            PaymentIdentifier paymentIdentifierResponse = _paymentInstrumentService.GetPaymentIdentifier(request.AccountIdentifier, pi.PaymentInstrumentIdentifier.ToString());

                            var paymentInstrumentIdentifier = new Guid(paymentIdentifierResponse.PaymentInstrument.PaymentInstrumentIdentifierString);

                            var paymentInstrumentDetail = GetPaymentInstrumentDetails(paymentInstrumentIdentifier);
                            var printStatus = GetPaymentInstrumentAttributeValue(paymentInstrumentDetail, PaymentInstrumentAttribute.Printed);
                            var eligibleStatus = GetPaymentInstrumentAttributeValue(paymentInstrumentDetail, PaymentInstrumentAttribute.CardPrintable);
                            //var issueDateTime = GetPaymentInstrumentAttributeValue(paymentInstrumentDetail, PaymentInstrumentAttribute.PrintedDateTime);

                            InstantIssuePaymentInstrument plsPaymentInstrument = new InstantIssuePaymentInstrument();
                            plsPaymentInstrument.PaymentInstrumentIdentifier = paymentInstrumentIdentifier;
                            plsPaymentInstrument.ProductCode = paymentIdentifierResponse.ProductCode;
                            plsPaymentInstrument.TokenizedPAN = paymentIdentifierResponse.TokenizedPAN;
                            plsPaymentInstrument.ProductMaterialType = GetProductMaterialTypeByPaymentInstrumentIdentifier(paymentInstrumentIdentifier);
                            plsPaymentInstrument.CardStatus = (PaymentInstrumentStatus)Enum.Parse(typeof(PaymentInstrumentStatus), paymentIdentifierResponse.PaymentInstrument.Status);
                            plsPaymentInstrument.Last4PAN = paymentIdentifierResponse.PaymentInstrument.Last4Pan;
                            plsPaymentInstrument.EmbossedLine1 = paymentIdentifierResponse.PaymentInstrument.EmbossedName;
                            plsPaymentInstrument.EmbossedLine2 = string.Empty; // For now is empty
                            plsPaymentInstrument.Pan = _tokenizerService.DeTokenizePan(paymentIdentifierResponse.TokenizedPAN);
                            plsPaymentInstrument.Expiration = paymentIdentifierResponse.PaymentInstrument.EncryptedExpirationDate;
                            plsPaymentInstrument.createdDateTime = pi.CreateDate;
                            plsPaymentInstrument.EligibleInstruments = eligibleStatus != null && bool.Parse(GetPaymentInstrumentAttributeValue(paymentInstrumentDetail, PaymentInstrumentAttribute.CardPrintable));
                            plsPaymentInstrument.IssuedStatus = printStatus == "true" ? "PrintSuccess" : printStatus == "false" ? "PrintFailure" : "";
                            plsPaymentInstrument.IssuedDateTime = GetPaymentInstrumentAttributeValue(paymentInstrumentDetail, PaymentInstrumentAttribute.PrintedDateTime);
                            plsPaymentInstrument.PaymentInstrumentType = (PaymentInstrumentType)pi.PaymentInstrumentTypeKey;

                            var cardExpDateTemp = new Core.Domain.Services.Dcpp.CardExpirationDate()
                            {
                                CardExpirationMonth = plsPaymentInstrument.Expiration.CardExpirationMonth,
                                CardExpirationYear = plsPaymentInstrument.Expiration.CardExpirationyear,
                            };

                            
                            if (IsCardNotActivated(plsPaymentInstrument.CardStatus))
                            {
                                CardDetails cardResponse = _processorRoutingService.GetCardDetails(request.AccountIdentifier, cardExpDateTemp,
                                paymentIdentifierResponse.PaymentIdentifierIdentifier.ToGuid(), plsPaymentInstrument.PaymentInstrumentIdentifier);
                                plsPaymentInstrument.Cvv = string.IsNullOrEmpty(cardResponse.Cvv) ? string.Empty : cardResponse.Cvv;

                                PLSPaymentInstrumentsResult.Add(plsPaymentInstrument);
                            }
                        }

                        getPaymentInstrumentsResponse.ResponseHeader = new ResponseHeader()
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 0,
                            SubStatusCode = 0,
                            Message = message
                        };
                        getPaymentInstrumentsResponse.PaymentInstruments = PLSPaymentInstrumentsResult;
                    }
                    else
                    {
                        getPaymentInstrumentsResponse.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 205,
                            SubStatusCode = 1001,
                            Message = "The user doesn't have any payment Identifier"
                        };
                    }
                }
                else
                {
                    message = $"Account Status is {accountResponse.AccountStatus}";
                    getPaymentInstrumentsResponse.ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 205,
                        SubStatusCode = 1002,
                        Message = message
                    };
                }

                return Task.FromResult(getPaymentInstrumentsResponse);

            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<InstantIssueEnrollmentResponse>(e, request));
            }
        }
        private static bool IsCardNotActivated(PaymentInstrumentStatus status)
        {
            return status == PaymentInstrumentStatus.NotActivated || status == PaymentInstrumentStatus.Activated;
        }

        private List<PaymentInstrumentDetail> GetPaymentInstrumentDetails(Guid paymentInstrumentIdentifier)
        {
            return _paymentIdentifierRepository.GetPaymentInstrumentDetails(paymentInstrumentIdentifier);
        }

        private string GetPaymentInstrumentAttributeValue(List<PaymentInstrumentDetail> paymentInstrumentDetail, PaymentInstrumentAttribute paymentInstrumentAttributeKey)
        {
            var attributeRecord = paymentInstrumentDetail.FirstOrDefault(p => p.PaymentInstrumentAttribute == paymentInstrumentAttributeKey);

            attributeRecord = attributeRecord ?? new PaymentInstrumentDetail();

            return attributeRecord.PaymentInstrumentAttributeValue;
        }


        private string GetProductMaterialTypeByPaymentInstrumentIdentifier(Guid paymentInstrumentIdentifier)
        {
            var paymentInstrumentDetail = GetPaymentInstrumentDetails(paymentInstrumentIdentifier).FirstOrDefault(p =>
                    p.PaymentInstrumentAttribute == PaymentInstrumentAttribute.SelectedProductMaterialType);
            return paymentInstrumentDetail?.PaymentInstrumentAttributeValue;
        }
    }
}
