﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.Shared.Common.Core.CareCoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers.Exceptions;
using Gd.Bos.RequestHandler.Core.Domain.Services.Core;
using Gd.Bos.RequestHandler.Core.Domain.Services.ECash;
using Gd.Bos.RequestHandler.Core.Domain.Services.Retail;
using Gd.Bos.RequestHandler.Core.Domain.Services.Retail.Enum;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using GenerateBarcodeRequest = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.GenerateBarcodeRequest;
using GenerateBarcodeResponse = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.GenerateBarcodeResponse;
using Geolocation = Gd.Bos.RequestHandler.Core.Domain.Services.ECash.Geolocation;
using TransferType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType;


namespace Gd.Bos.RequestHandler.Logic.Handler
{

    /// <summary>
    /// GenerateBarcodeHandler
    /// </summary>
    public class GenerateBarcodeHandler : ECashHandlerBase<GenerateBarcodeRequest, GenerateBarcodeResponse>
    {
        private readonly ICoreWebApiClient _coreWebApiClient;
        private readonly IRetailService _retailService;
        private readonly ITransferService _transferService;
        private readonly ILimitTypeService _limitTypeService;
        private const string ECashTransaction = "ECASH";
        private readonly IValidateIdentifier _validateIdentifier;

        public GenerateBarcodeHandler(IECashService eCashService, IRetailService retailService,
            ITransferService transferService, ILimitTypeService limitTypeService, IValidateIdentifier validateIdentifier, ICoreWebApiClient coreWebApiClient) : base(eCashService)
        {
            _coreWebApiClient = coreWebApiClient;
            _retailService = retailService;
            _transferService = transferService;
            _limitTypeService = limitTypeService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(GenerateBarcodeRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GenerateBarcodeResponse> VerifyIdentifiers(GenerateBarcodeRequest request)
        {
            return Task.FromResult(new GenerateBarcodeResponse { ResponseHeader = new ResponseHeader() });
        }

        public override Task<GenerateBarcodeResponse> Handle(GenerateBarcodeRequest request)
        {
            return Task.FromResult(GenerateBarcode(request));
        }

        private GenerateBarcodeResponse GenerateBarcode(GenerateBarcodeRequest request)
        {
            var response = new GenerateBarcodeResponse();
            try
            {
                if (request.TransactionType == ECashTransactionType.Send)
                {
                    #region RetailPartner Limit Check

                    var retailResponse = _retailService.GetRetailPartners(ECashTransaction,
                        request.RequestHeader.RequestId.ToString());

                    // Filter retailer object with RetailPartner_Identifier
                    var retailer = retailResponse?.Retailers.FirstOrDefault(r =>
                        string.Equals(r.RetailPartnerIdentifier, request.PartnerId,
                            StringComparison.CurrentCultureIgnoreCase));
                    if (retailer == null)
                    {
                        throw new RequestHandlerException(200, (int)ResponseSubcodes.Operation_Not_Supported,
                            $"{nameof(request)}. RetailPartnerId '{request.PartnerId}' is not found or not supported by RetailAPI.");
                    }

                    // Searching by ProgramCode or use default ProgramCode: null, TransactionType should be ECASH
                    var retailPartnerLimit = retailer?.Limits.FirstOrDefault(c =>
                                                 (c.TransactionType == TransactionTypeEnum.ECASHEnum &&
                                                  string.Equals(c.ProgramCode, request.ProgramCode,
                                                      StringComparison.CurrentCultureIgnoreCase))) ??
                                             retailer?.Limits.FirstOrDefault(c =>
                                                 (c.TransactionType == TransactionTypeEnum.ECASHEnum &&
                                                  string.IsNullOrEmpty(c.ProgramCode)));

                    if (retailPartnerLimit == null)
                    {
                        throw new RequestHandlerException(200, (int)ResponseSubcodes.Operation_Not_Supported,
                            $"{nameof(request)}. RetailPartner Limit for TransactionType 'eCash' not found. RetailPartnerId: {request.PartnerId}.");
                    }

                    // Find limit with TenderType 'CASH' and State: null
                    var limit = retailPartnerLimit?.Limits.FirstOrDefault(l =>
                        (l.TenderType == LoadLimit.TenderTypeEnum.CASHEnum && string.IsNullOrEmpty(l.State)));
                    if (limit == null)
                    {
                        throw new RequestHandlerException(200, (int)ResponseSubcodes.Operation_Not_Supported,
                            $"{nameof(request)}. Cash Limit for TransactionType 'eCash' not found. RetailPartnerId: {request.PartnerId}.");
                    }

                    // Retail Limit Verification
                    if (request.Amount * 100 < limit?.MinAmount.Value)
                    {
                        response.ResponseHeader = new ResponseHeader()
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 952,
                            SubStatusCode = 608,
                            Message = "Barcode Amount is Below the Minimum Required Amount."
                        };
                        return response;
                    }

                    if (request.Amount * 100 > limit?.MaxAmount.Value)
                    {
                        response.ResponseHeader = new ResponseHeader()
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 952,
                            SubStatusCode = 609,
                            Message = "Barcode Amount is Above the Maximum Amount Allowed."
                        };
                        return response;
                    }

                    #endregion RetailPartner Limit Check

                    //Validate Phone Number
                    if (!IsValidPhoneNumber(request.Recipient.PhoneNumber))
                    {
                        response.ResponseHeader = new ResponseHeader()
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 951,
                            SubStatusCode = 602,
                            Message = "Missing or Invalid Parameter: phonenumber: Should not be null or empty."
                        };
                        return response;
                    }

                    #region Comment the service call

                    //var assessRequest = new AssessTransferRequest
                    //{
                    //    ProgramCode = request.ProgramCode,
                    //    RequestHeader = new RequestHeader
                    //    {
                    //        RequestId = request.RequestHeader.RequestId
                    //    },
                    //    TransferIdentifier = Guid.NewGuid().ToString("D"),
                    //    TransferType = TransferType.ECashSend,
                    //    AuthorizationType = AuthorizationType.Hold,
                    //    Initiator = request.AccountIdentifier,
                    //    Memo = "",

                    //    TransferRoute = new TransferRoute
                    //    {
                    //        TransactionAmount = request.Amount ?? 0m,
                    //        SourceTransferEndPoint = new TransferEndPoint
                    //        {
                    //            TransferEndPointType = EndpointType.RetailSale,
                    //            Currency = "USD",
                    //            RetailSaleData = new RetailSaleData
                    //            {
                    //                //No Retailer information need to pass currently
                    //            }
                    //        },
                    //        TargetTransferEndPoint = new TransferEndPoint
                    //        {
                    //            TransferEndPointType = EndpointType.Handle,
                    //            Currency = "USD",
                    //            HandleData = new HandleData
                    //            {
                    //                FirstName = request.Recipient.FirstName,
                    //                Handle = request.Recipient.PhoneNumber,
                    //                LastName = request.Recipient.LastName,
                    //            }
                    //        }
                    //    }
                    //};
                    //var assessResponse = _coreWebApiClient.AssessTransfer(assessRequest);

                    #endregion

                    var assessResponse = AssessTransferForECashSend(request);

                    if (assessResponse.Limits?.Count > 0)
                    {
                        if (assessResponse.ResponseHeader.StatusCode != (int)StatusCode.SUCCESS)
                        {
                            var responseHeader = new ResponseHeader();
                            var limits = assessResponse.Limits;
                            switch (assessResponse.ResponseHeader.SubStatusCode)
                            {
                                case 113:
                                    var weeklyLimit = (from l in limits
                                                       where l.Type.ToLower() == "peertransfersendvelocitylimit"
                                                       select l).FirstOrDefault();
                                    responseHeader.ResponseId = request.RequestHeader.RequestId;
                                    responseHeader.StatusCode = 952;
                                    responseHeader.SubStatusCode = 610;
                                    responseHeader.Message = "Barcode Amount Exceeds Limits. ";
                                    if (weeklyLimit != null)
                                        responseHeader.Message +=
                                            $"TimePeriod: {weeklyLimit.Frequency}, AmountRemaining: {weeklyLimit.AmountRemaining}";
                                    break;
                                case 114:
                                    var maximumLimit = (from l in limits
                                                        where l.Type.ToLower() == "peertransfersendperuselimit"
                                                        select l).FirstOrDefault();
                                    responseHeader.ResponseId = request.RequestHeader.RequestId;
                                    responseHeader.StatusCode = 952;
                                    responseHeader.SubStatusCode = 612;
                                    responseHeader.Message = "Barcode Amount is Above the Maximum Amount Allowed. ";
                                    if (maximumLimit != null)
                                        responseHeader.Message += $"MaximumAmount: {maximumLimit.MaximumAmount}";
                                    break;
                                case 115:
                                    var minimumLimit = (from l in limits
                                                        where l.Type.ToLower() == "peertransfersendperuselimit"
                                                        select l).FirstOrDefault();
                                    responseHeader.ResponseId = request.RequestHeader.RequestId;
                                    responseHeader.StatusCode = 952;
                                    responseHeader.SubStatusCode = 611;
                                    responseHeader.Message = "Barcode Amount is Below the Minimum Amount Required. ";
                                    if (minimumLimit != null)
                                        responseHeader.Message += $"MinimumAmount: {minimumLimit.MinimumAmount}";
                                    break;
                                case 205:
                                    responseHeader.ResponseId = request.RequestHeader.RequestId;
                                    responseHeader.StatusCode = 951;
                                    responseHeader.SubStatusCode = 602;
                                    responseHeader.Message =
                                        "Missing or Invalid Parameter: amount: Should not be null or empty.";
                                    break;

                                default:
                                    var responseDetail = assessResponse.ResponseHeader?.Details != null
                                        ? new ResponseDetail
                                        {
                                            Code = assessResponse.ResponseHeader.StatusCode,
                                            SubCode = assessResponse.ResponseHeader.SubStatusCode,
                                            Description = assessResponse.ResponseHeader.Message,
                                            Url = null
                                        }
                                        : null;

                                    responseHeader = MapResponse(responseDetail, request.RequestHeader.RequestId);
                                    break;
                            }

                            response.ResponseHeader = responseHeader;
                            return response;
                        }
                    }
                    else
                    {
                        var responseDetail = assessResponse?.ResponseHeader != null
                            ? new ResponseDetail
                            {
                                Code = assessResponse.ResponseHeader.StatusCode,
                                SubCode = assessResponse.ResponseHeader.SubStatusCode,
                                Description = assessResponse.ResponseHeader.Message,
                                Url = null
                            }
                            : null;
                        response.ResponseHeader = MapResponse(responseDetail, request.RequestHeader.RequestId);
                        return response;
                    }
                }

                var domainResponse = ECashService.GenerateBarcode(new Core.Domain.Services.ECash.GenerateBarcodeRequest
                {
                    AccountIdentifier = request.AccountIdentifier,
                    ProgramCode = request.ProgramCode,
                    PartnerId = request.PartnerId,
                    Amount = request.Amount,
                    Memo = request.Memo,
                    TransactionType = request.TransactionType,
                    Geolocation = request.Geolocation == null
                        ? null
                        : new Geolocation
                        {
                            Latitude = request.Geolocation.Latitude,
                            Longitude = request.Geolocation.Longitude
                        },
                    ZipCode = request.ZipCode,
                    Recipient = request.Recipient == null
                        ? null
                        : new ECashRecipient
                        {
                            FirstName = request.Recipient.FirstName,
                            LastName = request.Recipient.LastName,
                            PhoneNumber = request.Recipient.PhoneNumber
                        }
                });

                response.ResponseHeader =
                    MapResponse(domainResponse?.ResponseDetails?[0], request.RequestHeader.RequestId);

                if (domainResponse?.ECashTransaction?.BarcodeNumber != null)
                {
                    response.ECashTransaction = new Bos.Shared.Common.Core.CoreApi.Contract.Data.ECashTransaction
                    {
                        FaceFee = domainResponse.ECashTransaction.FaceFee,
                        ZipCode = domainResponse.ECashTransaction.ZipCode,
                        BarcodeNumber = domainResponse.ECashTransaction.BarcodeNumber,
                        BarcodeExpirationDateTime = domainResponse.ECashTransaction.BarcodeExpirationDateTime,
                        BarcodeHumanReadable = domainResponse.ECashTransaction.BarcodeHumanReadable,
                        BarcodeStatus = domainResponse.ECashTransaction.BarcodeStatus
                    };

                }
            }
            catch (Exception ex)
            {
                var detail = new ResponseDetail
                {
                    Code = ECashStatusCode.OperationFailed,
                    SubCode = ECashSubStatusCode.SystemError,
                    Description = !string.IsNullOrEmpty(ex.Message) ? ex.Message : "Internal exception when GenerateBarcode()."
                };
                response.ResponseHeader = MapResponse(detail, request.RequestHeader.RequestId);
            }
            return response;
        }

        /// <summary>
        /// AssessTransferForECashSend
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        private AssessTransferResponse AssessTransferForECashSend(GenerateBarcodeRequest request)
        {
            var retailSaleData = new RetailSaleData();
            var handleData = new HandleData
            {
                FirstName = request.Recipient.FirstName,
                Handle = request.Recipient.PhoneNumber,
                LastName = request.Recipient.LastName
            };

            List<Limits> filteredLimits = null;

            try
            {
                filteredLimits = _limitTypeService.GetApplicableLimits(request.AccountIdentifier,
                    request.ProgramCode, TransferType.ECashSend);
            }
            catch
            {
                //Nothing needs by following AssessTransferHandler
            }

            Tuple<TransferStatus, List<Account>>
                transferECashSendResponse;
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.Initiator,
                    DomainContext.Current.ProgramCode);

                transferECashSendResponse = _transferService.TransferECashSend(
                    Guid.NewGuid().ToString("D"),
                    request.AccountIdentifier,
                    AuthorizationType.Hold,
                    request.Amount ?? 0m,
                    retailSaleData.MerchantName,
                    retailSaleData.StoreNumber,
                    retailSaleData.City,
                    retailSaleData.State,
                    null,
                    EndpointType.Handle,
                    handleData.Handle,
                    handleData.FirstName,
                    handleData.LastName,
                    handleData.UserName,
                    request.ProgramCode,
                    string.Empty, true
                );
            }
            catch (TransferAccountStateException ex)
            {
                var rs = ex.HandleException<AssessTransferResponse>(ex, request);
                rs.Limits = filteredLimits;
                return rs;
            }
            catch (RequestHandlerException ex)
            {
                var rs = ex.HandleException<AssessTransferResponse>(ex, request);
                rs.Limits = filteredLimits;
                return rs;
            }
            catch (Core.Infrastructure.AccountNotFoundException ex)
            {
                var e = new Core.Domain.Model.Transfers.Exceptions.AccountNotFoundException(10, 0, ex.Message);
                var rs = ex.HandleException<AssessTransferResponse>(e, request);
                rs.Limits = filteredLimits;
                return rs;
            }
            catch (Exception ex)
            {
                var rs = ex.HandleException<AssessTransferResponse>(ex, request);
                rs.Limits = filteredLimits;
                return rs;
            }

            var transferStatus = transferECashSendResponse?.Item1;
            return new AssessTransferResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = transferStatus == TransferStatus.Completed ? "Success" : transferStatus.ToString()
                },
                Limits = filteredLimits
            };
        }

        private bool IsValidPhoneNumber(string phoneNumber)
        {
            if (string.IsNullOrWhiteSpace(phoneNumber))
            {
                return false;
            }
            return true;
        }
    }
}
