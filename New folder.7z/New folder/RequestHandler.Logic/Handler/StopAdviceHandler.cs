﻿using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;

namespace RequestHandler.Logic.Handler
{
    public class StopAdviceHandler (IVauService vauService) : CommandHandlerBase<StopAdviceRequest, StopAdviceResponse>
    {
        public override void SetDomainContext(StopAdviceRequest request)
        {
            
        }

        public override Task<StopAdviceResponse> VerifyIdentifiers(StopAdviceRequest request)
        {
            return Task.FromResult(new StopAdviceResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<StopAdviceResponse> Handle(StopAdviceRequest request)
        {
            return vauService.SendStopAdvice(request);
        }
    }
}
