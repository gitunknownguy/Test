using System;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;

namespace RequestHandler.Logic.Handler
{
    public class GetConsumerProfileAddressHistoryHandler : CommandHandlerBase<GetConsumerProfileAddressHistoryRequest, GetConsumerProfileAddressHistoryResponse>
    {
        private readonly IUserService _userService;

        public GetConsumerProfileAddressHistoryHandler(IUserService userService)
        {
            _userService = userService;
        }

        public override void SetDomainContext(GetConsumerProfileAddressHistoryRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetConsumerProfileAddressHistoryResponse> VerifyIdentifiers(GetConsumerProfileAddressHistoryRequest request)
        {
            return Task.FromResult(new GetConsumerProfileAddressHistoryResponse { ResponseHeader = new ResponseHeader() });
        }

        public override Task<GetConsumerProfileAddressHistoryResponse> Handle(
            GetConsumerProfileAddressHistoryRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.AccountIdentifier))
                    throw new AccountNotFoundException();

                AccountIdentifier accountIdentifier = null;

                if (!string.IsNullOrEmpty(request.AccountIdentifier))
                    accountIdentifier = AccountIdentifier.FromString(request.AccountIdentifier);

                var addresses = _userService.GetConsumerProfileAddressHistoryByAccountIdentifier((accountIdentifier));
                var response = new GetConsumerProfileAddressHistoryResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                    Addresses = addresses
                };
                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetConsumerProfileAddressHistoryResponse>(e, request));
            }
        }
    }
}