﻿using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Core.Domain.Services.EGift;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class EGiftGetLifeTimeRewardsHandler : CommandHandlerBase<EGiftGetLifeTimeRewardsRequest, EGiftGetLifeTimeRewardsResponse>
    {
        private readonly IEGiftService _egiftService;

        public EGiftGetLifeTimeRewardsHandler(IEGiftService egiftService)
        {
            _egiftService = egiftService;
        }

        public override void SetDomainContext(EGiftGetLifeTimeRewardsRequest request)
        {
            var req = request;
            if (req != null)
                DomainContext.Current.AccountIdentifier = req.AccountIdentifier;
        }

        public override Task<EGiftGetLifeTimeRewardsResponse> VerifyIdentifiers(EGiftGetLifeTimeRewardsRequest request)
        {
            return Task.FromResult(new EGiftGetLifeTimeRewardsResponse { ResponseHeader = new ResponseHeader() });
        }

        public override Task<EGiftGetLifeTimeRewardsResponse> Handle(EGiftGetLifeTimeRewardsRequest request)
        {
            var req = request;
            return req != null
                ? Task.FromResult(GetEGiftBalance(req))
                : null;
        }

        private EGiftGetLifeTimeRewardsResponse GetEGiftBalance(EGiftGetLifeTimeRewardsRequest request)
        {
            var req = request;
            if (request != null)
                DomainContext.Current.AccountIdentifier = req.AccountIdentifier;

            var response = _egiftService.GetLifeTimeRewards(request);

            return response;
        }
    }
}
