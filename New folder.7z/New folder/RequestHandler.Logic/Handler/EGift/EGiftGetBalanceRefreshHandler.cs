﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Core.Domain.Services.EGift;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Logic.DataAccess;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class EGiftGetBalanceRefreshHandler : CommandHandlerBase<EGiftBalanceRefreshRequest, EGiftBalanceRefreshResponse>
    {
        private readonly IEGiftService _egiftService;
        private readonly IAccountDataAccess _accountDataAccess;

        public EGiftGetBalanceRefreshHandler(IEGiftService egiftService, IAccountDataAccess accountDataAccess)
        {
            _egiftService = egiftService;
            _accountDataAccess = accountDataAccess;
        }

        public override void SetDomainContext(EGiftBalanceRefreshRequest request)
        {
            var req = request;
            if (req != null)
                DomainContext.Current.AccountIdentifier = req.AccountIdentifier;
        }

        public override Task<EGiftBalanceRefreshResponse> VerifyIdentifiers(EGiftBalanceRefreshRequest request)
        {
            return Task.FromResult(new EGiftBalanceRefreshResponse { ResponseHeader = new ResponseHeader() });
        }

        public override Task<EGiftBalanceRefreshResponse> Handle(EGiftBalanceRefreshRequest request)
        {
            var req = request;
            if (req != null)
            {
                return Task.FromResult(GetEGiftBalanceRefresh(req));
            }

            return null;
        }

        private EGiftBalanceRefreshResponse GetEGiftBalanceRefresh(EGiftBalanceRefreshRequest request)
        {
            var req = request;
            if (req != null)
                DomainContext.Current.AccountIdentifier = req.AccountIdentifier;

            var getAccountResponse = _accountDataAccess.GetAccountKey(request.AccountIdentifier, request.ProgramCode);

            if (getAccountResponse == null)
            {
                var errorResponse = new EGiftBalanceRefreshResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 10,
                        SubStatusCode = 1536,
                        Message = "Account Not Found."
                    }
                };
                return errorResponse;
            }

            var response = _egiftService.GetEGiftBalanceRefresh(new EGiftGetBalanceRefreshRequest
            {
                RequestHeader = request.RequestHeader,
                AccountIdentifier = Guid.Parse(request.AccountIdentifier),
                EGiftId = Guid.Parse(request.EGiftId),
                IncludeDeleted = request.IncludeDeleted,
                ProgramCode = request.ProgramCode
            });
            var res = new EGiftBalanceRefreshResponse
            {
                ResponseHeader = response.ResponseHeader,
                EGift = EGift.Convert(response.EGift)
            };

            return res;
        }
    }
}
