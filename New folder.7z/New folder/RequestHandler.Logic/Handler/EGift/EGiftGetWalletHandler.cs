﻿using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.EGift;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Queue;
using EGiftGetWalletRequest = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.EGiftGetWalletRequest;
using EGiftGetWalletResponse = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.EGiftGetWalletResponse;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class EGiftGetWalletHandler : CommandHandlerBase<EGiftGetWalletRequest, EGiftGetWalletResponse>
    {
        private readonly IEGiftService _egiftService;
        private readonly IAccountDataAccess _accountDataAccess;
        public EGiftGetWalletHandler(IEGiftService egiftService, IAccountDataAccess accountDataAccess)
        {
            _egiftService = egiftService;
            _accountDataAccess = accountDataAccess;
        }

        public override void SetDomainContext(EGiftGetWalletRequest request)
        {
            var req = request;
            if (req != null)
                DomainContext.Current.AccountIdentifier = req.AccountIdentifier;
        }

        public override Task<EGiftGetWalletResponse> VerifyIdentifiers(EGiftGetWalletRequest request)
        {
            return Task.FromResult(new EGiftGetWalletResponse { ResponseHeader = new ResponseHeader() });
        }

        public override Task<EGiftGetWalletResponse> Handle(EGiftGetWalletRequest request)
        {
            var req = request;
            if (req != null)
            {
                return Task.FromResult(GetWallet(req));
            }

            return null;
        }

        private EGiftGetWalletResponse GetWallet(EGiftGetWalletRequest request)
        {
            var req = request;
            if (req != null)
                DomainContext.Current.AccountIdentifier = req.AccountIdentifier;

            var getAccountResponse = _accountDataAccess.GetAccountKey(request.AccountIdentifier, request.ProgramCode);

            if (getAccountResponse == null)
            {
                var errorResponse = new EGiftGetWalletResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 10,
                        SubStatusCode = 1536,
                        Message = "Account Not Found."
                    }
                };
                return errorResponse;
            }


            var response = _egiftService.GetWallet(new Core.Domain.Services.EGift.EGiftGetWalletRequest
            {
                RequestHeader = request.RequestHeader,
                AccountIdentifier = request.AccountIdentifier,
                IncludeDeleted = request.IncludeDeleted,
                ProgramCode = request.ProgramCode
            });
            var res = new EGiftGetWalletResponse
            {
                ResponseHeader = response.ResponseHeader,
                EGifts = Gd.Bos.RequestHandler.Core.Domain.Services.EGift.EgiftWallet.Convert(response.EGifts)
            };

            return res;
        }
    }
}
