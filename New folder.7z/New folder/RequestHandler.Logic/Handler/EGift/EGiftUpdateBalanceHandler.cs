﻿using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Core.Domain.Services.EGift;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class EGiftUpdateBalanceHandler : CommandHandlerBase<EGiftUpdateBalanceRequest, EGiftUpdateBalanceResponse>
    {
        private readonly IEGiftService _egiftService;

        public EGiftUpdateBalanceHandler(IEGiftService egiftService)
        {
            _egiftService = egiftService;
        }

        public override void SetDomainContext(EGiftUpdateBalanceRequest request)
        {
            var req = request;
            if (req != null)
                DomainContext.Current.AccountIdentifier = req.AccountIdentifier;
        }

        public override Task<EGiftUpdateBalanceResponse> VerifyIdentifiers(EGiftUpdateBalanceRequest request)
        {
            return Task.FromResult(new EGiftUpdateBalanceResponse { ResponseHeader = new ResponseHeader() });
        }

        public override Task<EGiftUpdateBalanceResponse> Handle(EGiftUpdateBalanceRequest request)
        {
            var req = request;
            if (req != null)
            {
                return Task.FromResult(UpdateEGiftBalance(req));
            }

            return null;
        }

        private EGiftUpdateBalanceResponse UpdateEGiftBalance(EGiftUpdateBalanceRequest request)
        {
            var req = request;
            if (req != null)
                DomainContext.Current.AccountIdentifier = req.AccountIdentifier;

            var response = _egiftService.UpdateEGiftBalance(new EGiftUpdateGiftCardBalanceRequest
            {
                RequestHeader = request.RequestHeader,
                AccountIdentifier = request.AccountIdentifier,
                EGiftId = request.EGiftId,
                ProgramCode = request.ProgramCode,
                Balance = request.Balance
            });
            var res = new EGiftUpdateBalanceResponse
            {
                ResponseHeader = response.ResponseHeader,
                EGift = Core.Domain.Services.EGift.EGift.Convert(response.EGift)
            };

            return res;
        }
    }
}
