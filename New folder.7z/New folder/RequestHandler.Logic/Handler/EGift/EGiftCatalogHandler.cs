﻿using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Core.Domain.Services.EGift;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using ActivationCharacteristics = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.ActivationCharacteristics;
using Gd.Bos.RequestHandler.Core.Infrastructure;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class EGiftCatalogHandler : CommandHandlerBase<EGiftCatalogRequest, EGiftCatalogResponse>
    {
        private readonly IEGiftService _egiftService;

        public EGiftCatalogHandler(IEGiftService egiftService)
        {
            _egiftService = egiftService;
        }

        public override void SetDomainContext(EGiftCatalogRequest request)
        {
            var req = request;
            if (req != null)
                DomainContext.Current.AccountIdentifier = req.AccountIdentifier;
        }

        public override Task<EGiftCatalogResponse> VerifyIdentifiers(EGiftCatalogRequest request)
        {
            return Task.FromResult(new EGiftCatalogResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<EGiftCatalogResponse> Handle(EGiftCatalogRequest request)
        {
            var req = request;
            if (req != null)
            {
                return Task.FromResult((EGiftCatalogResponse)GetEGiftCatalog(req));
            }
            return null;
        }

        private EGiftCatalogResponse GetEGiftCatalog(EGiftCatalogRequest request)
        {
            var req = request;
            if (req != null)
                DomainContext.Current.AccountIdentifier = req.AccountIdentifier;
            var response = _egiftService.GetEGiftCatalog(new EGiftProductRequest()
            {
                RequestHeader = request.RequestHeader,
                AccountIdentifier = request.AccountIdentifier,
                ProgramCode = request.ProgramCode
            });
            EGiftCatalogResponse res = new EGiftCatalogResponse();
            res.ResponseHeader = response.ResponseHeader;
            res.CatalogItems = response.CatalogItems.Select(x =>
            {
                return new EGiftCatalogItem()
                {
                    ActivationCharacteristics = new ActivationCharacteristics()
                    {
                        BaseValueAmount = x.ActivationCharacteristics.BaseValueAmount,
                        MaxValueAmount = x.ActivationCharacteristics.MaxValueAmount,
                        IsVariable = x.ActivationCharacteristics.IsVariableValue,
                    },
                    Category = x.Category,
                    FrontImage = x.FrontImage,
                    ImageSize = x.ImageSize,
                    ProductId = x.ProductId,
                    ProductConfigurationId = x.ProductConfigurationId,
                    ProductDescription = x.ProductDescription,
                    BrandName = x.BrandName,
                    ProductName = x.ProductName,
                    RewardPercentage = EGiftService.GetPercentage(x.RewardPercentages, x.RewardPercentage),
                    TermsAndConditions = x.TermsAndConditions?.Select(y => new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.TermsAndConditionsItem()
                    {
                        Id = y.Id,
                        Text = y.Text,
                        TermsAndConditionsType = y.TermsAndConditionsType
                    }).ToArray(),
                    Tier = x.Tier,
                    IsActive = x.IsActive,
                    ProductType = x.ProductType,
                    ProductPairingKey = x.ProductPairingKey,
                    ProductPairOrderingKey = x.ProductPairOrderingKey,
                    ProductMiscDetails = x.ProductMiscDetails,
                    UniversalProductCode = x.UniversalProductCode,
                    NetGreendotCommision = EGiftService.GetPercentage(x.Netgreendotcommissions, x.NetGreendotCommision),
                    CreateDate = x.CreateDate,
                    ChangeDate = x.ChangeDate,
                    DoubleCBPoints = x.DoubleCBPoints
                };
            }).ToArray();

            res.Sections = response.Sections.Select(x => new Section()
            {
                Description = x.Description,
                TemplateId = x.TemplateId,
                Tier = x.Tier,
                Title = x.Title,
                IsActive = x.IsActive
            }).ToArray();

            return res;
        }
    }
}
