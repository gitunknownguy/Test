﻿using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Core.Domain.Services.EGift;
using EGiftDeleteRequest = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.EGiftDeleteRequest;
using EGiftDeleteResponse = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.EGiftDeleteResponse;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class EGiftDeleteHandler : CommandHandlerBase<EGiftDeleteRequest, EGiftDeleteResponse>
    {
        private readonly IEGiftService _egiftService;

        public EGiftDeleteHandler(IEGiftService egiftService)
        {
            _egiftService = egiftService;
        }

        public override void SetDomainContext(EGiftDeleteRequest request)
        {
            var req = request;
            if (req != null)
                DomainContext.Current.AccountIdentifier = req.AccountIdentifier;
        }

        public override async Task<EGiftDeleteResponse> VerifyIdentifiers(EGiftDeleteRequest request)
        {
            return await Task.FromResult(new EGiftDeleteResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<EGiftDeleteResponse> Handle(EGiftDeleteRequest request)
        {
            var req = request;
            if (req != null)
            {
                return Task.FromResult(DeleteEGift(req));
            }

            return null;
        }

        private EGiftDeleteResponse DeleteEGift(EGiftDeleteRequest request)
        {
            var req = request;
            if (req != null)
                DomainContext.Current.AccountIdentifier = req.AccountIdentifier;

            var response = _egiftService.DeleteEGift(new Core.Domain.Services.EGift.EGiftDeleteRequest
            {
                RequestHeader = request.RequestHeader,
                AccountIdentifier = request.AccountIdentifier,
                EGiftId = request.EGiftId,
                ProgramCode = request.ProgramCode
            });
            var res = new EGiftDeleteResponse
            {
                ResponseHeader = response.ResponseHeader,
                EGift = EGift.Convert(response.EGift)
            };

            return res;
        }
    }
}
