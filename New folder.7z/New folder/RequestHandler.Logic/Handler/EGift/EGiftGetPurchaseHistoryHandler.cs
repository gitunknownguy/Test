﻿using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.EGift;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using EGiftGetPurchaseHistoryRequest = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.EGiftGetPurchaseHistoryRequest;
using EGiftGetPurchaseHistoryResponse = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.EGiftGetPurchaseHistoryResponse;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class EGiftGetPurchaseHistoryHandler : CommandHandlerBase<EGiftGetPurchaseHistoryRequest, EGiftGetPurchaseHistoryResponse>
    {
        private readonly IEGiftService _egiftService;
        private readonly IAccountDataAccess _accountDataAccess;
        public EGiftGetPurchaseHistoryHandler(IEGiftService egiftService, IAccountDataAccess accountDataAccess)
        {
            _egiftService = egiftService;
            _accountDataAccess = accountDataAccess;
        }

        public override void SetDomainContext(EGiftGetPurchaseHistoryRequest request)
        {
            var req = request;
            if (req != null)
                DomainContext.Current.AccountIdentifier = req.AccountIdentifier;
        }

        public override Task<EGiftGetPurchaseHistoryResponse> VerifyIdentifiers(EGiftGetPurchaseHistoryRequest request)
        {
            return Task.FromResult(new EGiftGetPurchaseHistoryResponse { ResponseHeader = new ResponseHeader() });
        }

        public override Task<EGiftGetPurchaseHistoryResponse> Handle(EGiftGetPurchaseHistoryRequest request)
        {
            var req = request;
            if (req != null)
            {
                return Task.FromResult(GetEGiftPurchaseHistory(req));
            }

            return null;
        }

        private EGiftGetPurchaseHistoryResponse GetEGiftPurchaseHistory(EGiftGetPurchaseHistoryRequest request)
        {
            var req = request;
            if (req != null)
                DomainContext.Current.AccountIdentifier = req.AccountIdentifier;

            var getAccountResponse = _accountDataAccess.GetAccountKey(request.AccountIdentifier, request.ProgramCode);

            if (getAccountResponse == null)
            {
                var errorResponse = new EGiftGetPurchaseHistoryResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 10,
                        SubStatusCode = 1536,
                        Message = "Account Not Found."
                    }
                };
                return errorResponse;
            }


            var response = _egiftService.GetEGiftPurchaseHistory(new Core.Domain.Services.EGift.EGiftGetPurchaseHistoryRequest
            {
                RequestHeader = request.RequestHeader,
                AccountIdentifier = request.AccountIdentifier,
                ProgramCode = request.ProgramCode
            });

            if (response == null || response.Purchases == null || response.Purchases.Count == 0)
            {
                var errorResponse = new EGiftGetPurchaseHistoryResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 1564,
                        Message = "No gift cards are successfully purchased"
                    }
                };
                return errorResponse;
            }


            var cashBackRewardAmountsByGiftCard = _accountDataAccess.GetEGiftCashBackTransactionAmounts(request.AccountIdentifier);
            var resultPurchases = Gd.Bos.RequestHandler.Core.Domain.Services.EGift.GiftCardPurchaseRecord.Convert(response.Purchases);


            // set the CBR if we found one in DB
            foreach (var purchase in resultPurchases)
            {
                if (cashBackRewardAmountsByGiftCard.ContainsKey(purchase.GiftCardId))
                {
                    purchase.CashBackRewardAmount = cashBackRewardAmountsByGiftCard[purchase.GiftCardId];
                }
            }


            var res = new EGiftGetPurchaseHistoryResponse
            {
                ResponseHeader = response.ResponseHeader,
                Purchases = resultPurchases
            };

            return res;
        }
    }
}
