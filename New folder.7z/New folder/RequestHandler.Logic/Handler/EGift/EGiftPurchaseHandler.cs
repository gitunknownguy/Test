﻿using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Queue;
using EGiftPurchaseRequest = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.EGiftPurchaseRequest;
using EGiftPurchaseResponse = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.EGiftPurchaseResponse;
using Gd.Bos.RequestHandler.Core.Domain.Services.EGift;
using Gd.Bos.RequestHandler.Core.Application;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class EGiftPurchaseHandler : CommandHandlerBase<EGiftPurchaseRequest, EGiftPurchaseResponse>
    {
        private readonly IEGiftService _egiftService;
        private readonly ITransferService _transferService;

        public EGiftPurchaseHandler(
            IEGiftService egiftService,
            ITransferService transferService)
        {
            _egiftService = egiftService;
            _transferService = transferService;
        }

        public override void SetDomainContext(EGiftPurchaseRequest request)
        {
            request.SourceAccountIdentifier = request.RequestHeader.Options["SourceAccountIdentifier"];
            DomainContext.Current.AccountIdentifier = request.SourceAccountIdentifier;
        }

        public override async Task<EGiftPurchaseResponse> VerifyIdentifiers(EGiftPurchaseRequest request)
        {
            return await Task.FromResult(new EGiftPurchaseResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<EGiftPurchaseResponse> Handle(EGiftPurchaseRequest request)
        {
            return Task.FromResult((EGiftPurchaseResponse)PurchaseEGift(request));
        }

        private EGiftPurchaseResponse PurchaseEGift(EGiftPurchaseRequest request)
        {
            request.SourceAccountIdentifier = request.RequestHeader.Options["SourceAccountIdentifier"];
            DomainContext.Current.AccountIdentifier = request.SourceAccountIdentifier;

            string transferId = request.RequestHeader.RequestId.ToString();
            string initiator = request.SourceAccountIdentifier;
            string description = $"EGift Purchase RequestID: {request.RequestHeader.RequestId}";

            var targetAccountId = request.PurchaseType == PurchaseType.ToGift
                ? request.EGiftEndpoint?.EndpointValue?.ToString()
                : initiator;

            EGiftPurchaseResponse response = null;
            var res = _transferService.TransferEGiftPurchase(
                transferId,
                initiator,
                targetAccountId,
                request.AuthorizationType.ToString(),
                request.Amount,
                request.ProductId,
                //request.ProductConfigurationId,
                description,
                request.ProgramCode,
                request.ContactName,
                request.Memo,
                false,
                request.PurchaseFeature);

            response = res.Item2;

            // trim sensitive data for egifts purchased for someone else
            if (targetAccountId != initiator)
            {
                response.EGift.AccountNumber = null;
                response.EGift.Barcode3rdLineData = null;
                response.EGift.BarcodeCharacteristics = null;
                response.EGift.BarcodeType = null;
                response.EGift.Pin = null;
            }
            return response;
        }
    }
}
