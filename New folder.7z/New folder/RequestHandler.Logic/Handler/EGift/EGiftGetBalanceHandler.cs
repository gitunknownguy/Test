﻿using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Core.Domain.Services.EGift;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class EGiftGetBalanceHandler : CommandHandlerBase<EGiftBalanceRequest, EGiftBalanceResponse>
    {
        private readonly IEGiftService _egiftService;

        public EGiftGetBalanceHandler(IEGiftService egiftService)
        {
            _egiftService = egiftService;
        }

        public override void SetDomainContext(EGiftBalanceRequest request)
        {
            var req = request;
            if (req != null)
                DomainContext.Current.AccountIdentifier = req.AccountIdentifier;
        }

        public override Task<EGiftBalanceResponse> VerifyIdentifiers(EGiftBalanceRequest request)
        {
            return Task.FromResult(new EGiftBalanceResponse { ResponseHeader = new ResponseHeader() });
        }

        public override Task<EGiftBalanceResponse> Handle(EGiftBalanceRequest request)
        {
            var req = request;
            if (req != null)
            {
                return Task.FromResult(GetEGiftBalance(req));
            }

            return null;
        }

        private EGiftBalanceResponse GetEGiftBalance(EGiftBalanceRequest request)
        {
            var req = request;
            if (req != null)
                DomainContext.Current.AccountIdentifier = req.AccountIdentifier;

            var response = _egiftService.GetEGiftBalance(new EGiftGetBalanceRequest
            {
                RequestHeader = request.RequestHeader,
                AccountIdentifier = request.AccountIdentifier,
                EGiftId = request.EGiftId,
                IncludeDeleted = request.IncludeDeleted,
                ProgramCode = request.ProgramCode
            });
            var res = new EGiftBalanceResponse
            {
                ResponseHeader = response.ResponseHeader,
                EGift = Core.Domain.Services.EGift.EGift.Convert(response.EGift)
            };

            return res;
        }
    }
}
