﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using System.Threading.Tasks;
using FluentValidation;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.Contract.Request;
using Gd.Bos.Shared.Common.Core.Contract.Response;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;

namespace RequestHandler.Logic.Handler
{
    public class InventoryHandler : CommandHandlerBase<InventoryRequest, InventoryResponse>
    {

        private readonly IInventoryService _inventoryService;
        private readonly IProgramRepository _programRepository;
        private readonly IRequestDataAccess _requestDataAccess;

        public InventoryHandler(IInventoryService inventoryService,
                IProgramRepository programRepository,
                IRequestDataAccess requestDataAccess
        )
        {
            _inventoryService = inventoryService;
            _programRepository = programRepository;
            _requestDataAccess = requestDataAccess;
        }

        public override void SetDomainContext(InventoryRequest request)
        {
            if (!string.IsNullOrEmpty(request.ProgramCode))
                DomainContext.Current.ProgramCode = ProgramCode.FromString(request.ProgramCode);
        }

        public override Task<InventoryResponse> VerifyIdentifiers(InventoryRequest request)
        {
            return Task.FromResult(new InventoryResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<InventoryResponse> Handle(InventoryRequest request)
        {
            var newInventoryOrderIdentifier = Guid.NewGuid();
            var existingRequestInventoryOrderIdentifier = _requestDataAccess.InsertRequestId(RequestType.InventoryOrder,
                request.RequestHeader.RequestId, newInventoryOrderIdentifier);

            if (existingRequestInventoryOrderIdentifier != null)
            {

                var orderStatus = _inventoryService.GetInventoryOrderStatus(existingRequestInventoryOrderIdentifier.ToString());

                return Task.FromResult(new InventoryResponse()
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        StatusCode = 200,
                        SubStatusCode = 0,
                        Message = "Success",
                        Details = "",
                        ResponseId = request.RequestHeader.RequestId
                    },
                    ClientReferenceNumber = orderStatus.ClientReferenceNumber,
                    OrderIdentifier = orderStatus.OrderIdentifier,
                    Status = orderStatus.Status,
                    OrderCreated = orderStatus.OrderCreated
                });
            }

            Program program =
                _programRepository.GetByProgramIdentifier(ProgramCode.FromString(request.ProgramCode));

            InventoryResponse inventoryResponse = _inventoryService.saveInventoryRequest(request, newInventoryOrderIdentifier.ToString());
            inventoryResponse.ResponseHeader = new ResponseHeader()
            {
                StatusCode = 200,
                SubStatusCode = 0,
                Message = "Success",
                Details = "",
                ResponseId = request.RequestHeader.RequestId
            };
            return Task.FromResult(inventoryResponse);
        }
    }
}
