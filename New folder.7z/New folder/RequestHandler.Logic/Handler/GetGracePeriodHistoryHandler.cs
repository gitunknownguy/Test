﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Logic;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using Gd.Bos.Shared.Common.Overdraft;
using RequestHandler.Core.Application;

namespace RequestHandler.Logic.Handler
{
    public class GetGracePeriodHistoryHandler : CommandHandlerBase<GetGracePeriodHistoryRequest, GetGracePeriodHistoryResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ISCCTransactionService _sccTransactionService;

        public GetGracePeriodHistoryHandler(IValidateIdentifier validateIdentifier,
            ILockService lockService,
            IOverDraftFeeHelper overDraftFeeHelper,
            ISCCTransactionService sccTransactionService)
        {
            _validateIdentifier = validateIdentifier;
            _sccTransactionService = sccTransactionService;
        }

        public override void SetDomainContext(GetGracePeriodHistoryRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetGracePeriodHistoryResponse> VerifyIdentifiers(GetGracePeriodHistoryRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetGracePeriodHistoryResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetGracePeriodHistoryResponse>(e, request));
            }
        }

        public override Task<GetGracePeriodHistoryResponse> Handle(GetGracePeriodHistoryRequest request)
        {
            try
            {
                var trans = _sccTransactionService.GetAuthGracePeriodHistory(request);

                var response = new GetGracePeriodHistoryResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                };
                response.ODAuthGracePeriods = trans;

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetGracePeriodHistoryResponse>(e, request));
            }
        }
    }
}
