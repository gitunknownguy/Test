﻿using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using System.Threading.Tasks;

namespace RequestHandler.Logic.Handler
{
    public class GetAccountMigrationItemConfirmationHandler : CommandHandlerBase<GetAccountMigrationItemConfirmationRequestDTO, GetAccountMigrationItemConfirmationResponseDTO>
    {
        private ISampleCardService _sampleCardService;

        public GetAccountMigrationItemConfirmationHandler(ISampleCardService sampleCardService)
        {
            _sampleCardService = sampleCardService;
        }

        public override void SetDomainContext(GetAccountMigrationItemConfirmationRequestDTO request)
        {

        }

        public override Task<GetAccountMigrationItemConfirmationResponseDTO> Handle(GetAccountMigrationItemConfirmationRequestDTO request)
        {
            if (request.RequestHeader == null)
            {
                request.RequestHeader = new RequestHeader()
                {
                    RequestId = Guid.NewGuid()
                };
            }

            var response = new GetAccountMigrationItemConfirmationResponseDTO()
            {
                ResponseHeader = new ResponseHeader()
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                }
            };
            try
            {
                response = _sampleCardService.GetAccountMigrationItemConfirmation(request);
                return Task.FromResult(response);

            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetAccountMigrationItemConfirmationResponseDTO>(e, request));
            }
        }

        public override Task<GetAccountMigrationItemConfirmationResponseDTO> VerifyIdentifiers(GetAccountMigrationItemConfirmationRequestDTO request)
        {
            if (string.IsNullOrEmpty(request?.ProspectId))
            {
                return Task.FromResult(new GetAccountMigrationItemConfirmationResponseDTO()
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        StatusCode = 601,
                        SubStatusCode = 0,
                        Message = $"Prospect record is not found for {request?.ProspectId}"
                    }
                });
            }

            return Task.FromResult(new GetAccountMigrationItemConfirmationResponseDTO()
            {
                ResponseHeader = new ResponseHeader()
            });
        }
    }
}

