﻿using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;

namespace RequestHandler.Logic.Handler
{
    public class CheckCreditLineDecreaseEligibilityHandler : CommandHandlerBase<CheckCreditLineDecreaseEligibilityRequest, CheckCreditLineDecreaseEligibilityResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IEligibilityCheckService _eligibilityService;

        public CheckCreditLineDecreaseEligibilityHandler(IValidateIdentifier validateIdentifier, IEligibilityCheckService eligibilityService)
        {
            _validateIdentifier = validateIdentifier;
            _eligibilityService = eligibilityService;
        }

        public override Task<CheckCreditLineDecreaseEligibilityResponse> Handle(CheckCreditLineDecreaseEligibilityRequest request)
        {
            try
            {
                var response = _eligibilityService.CheckCreditLineDecreaseEligibility(request.ProgramCode, request.AccountIdentifier, request.RequestHeader?.RequestId.ToString());
                response.ResponseHeader.ResponseId = request.RequestHeader.RequestId;

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CheckCreditLineDecreaseEligibilityResponse>(e, request));
            }
        }

        public override void SetDomainContext(CheckCreditLineDecreaseEligibilityRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<CheckCreditLineDecreaseEligibilityResponse> VerifyIdentifiers(CheckCreditLineDecreaseEligibilityRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(request.AccountIdentifier, DomainContext.Current.ProgramCode);

                return Task.FromResult(new CheckCreditLineDecreaseEligibilityResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CheckCreditLineDecreaseEligibilityResponse>(e, request));
            }
        }
    }
}