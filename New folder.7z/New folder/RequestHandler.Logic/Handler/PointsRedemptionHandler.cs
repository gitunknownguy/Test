﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.PointsSystem;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;


namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class PointsRedemptionHandler : CommandHandlerBase<PointsRedemptionRequest, PointsRedemptionResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IPointsSystemService _pointsSystemService;

        public PointsRedemptionHandler(IPointsSystemService pointsSystemService, IValidateIdentifier validateIdentifier)
        {
            _pointsSystemService = pointsSystemService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(PointsRedemptionRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<PointsRedemptionResponse> VerifyIdentifiers(PointsRedemptionRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new PointsRedemptionResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<PointsRedemptionResponse>(e, request));
            }
        }

        public override Task<PointsRedemptionResponse> Handle(PointsRedemptionRequest request)
        {
            try
            {
                var response = _pointsSystemService.PointsRedemption(request);

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<PointsRedemptionResponse>(e, request));
            }
        }
    }
}
