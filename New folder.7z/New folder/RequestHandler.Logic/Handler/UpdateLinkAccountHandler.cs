﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Interest;
using Gd.Bos.RequestHandler.Core.Domain.Services.InterestRate;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class UpdateLinkAccountHandler : CommandHandlerBase<UpdateLinkAccountRequest, UpdateLinkAccountResponse>
    {
        public UpdateLinkAccountHandler(IValidateIdentifier validateIdentifier, IAccountService accountService)
        {
            _validateIdentifier = validateIdentifier;
            _accountService = accountService;

        }

        public override void SetDomainContext(UpdateLinkAccountRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.PrimaryAccountIdentifier;
        }
        public override Task<UpdateLinkAccountResponse> VerifyIdentifiers(UpdateLinkAccountRequest request)
        {
            _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
            _validateIdentifier.ValidateProgramCode(request.LinkAccountIdentifier, DomainContext.Current.ProgramCode);
            return Task.FromResult(new UpdateLinkAccountResponse { ResponseHeader = new ResponseHeader() });
        }

        public override Task<UpdateLinkAccountResponse> Handle(UpdateLinkAccountRequest request)
        {
            _accountService.UpdateLinkAccount(request.PrimaryAccountIdentifier, request.LinkAccountIdentifier);

            var result = new UpdateLinkAccountResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                }
            };

            return Task.FromResult(result);
        }

        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IAccountService _accountService;
    }
}
