﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Services.BillPay;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Queue;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    class BillPayEnrollHandler : CommandHandlerBase<BillPayEnrollRequest, BillPayEnrollResponse>
    {
        private readonly IBillPayService _billPayService;

        public BillPayEnrollHandler(IBillPayService billPayService)
        {
            _billPayService = billPayService;
            //https://gssmmssvc/billpay/v1
        }
        public override void SetDomainContext(BillPayEnrollRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<BillPayEnrollResponse> VerifyIdentifiers(BillPayEnrollRequest request)
        {
            return Task.FromResult(new BillPayEnrollResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<BillPayEnrollResponse> Handle(BillPayEnrollRequest request)
        {
            if (request.RequestHeader.RequestId == Guid.Empty)
            {
                throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId,
                    $"{nameof(request)}.RequestHeader.RequestId must be specified");
            }
            _billPayService.EnrollCustomer(request);
            return Task.FromResult(new BillPayEnrollResponse()
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                },
            });

        }
    }
}
