﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Interest;
using Gd.Bos.RequestHandler.Core.Domain.Services.InterestRate;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Logic;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetProductInterestRateTierHandler : CommandHandlerBase<ProductInterestRateTierRequest, ProductInterestRateTierResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IProductService _productService;
        private readonly IInterestRateService _interestRateService;
        private readonly IInterestRateRepository _interestRateRepository;

        public GetProductInterestRateTierHandler(IValidateIdentifier validateIdentifier, IProductService productService, IInterestRateService interestRateService,
        IInterestRateRepository interestRateRepository)
        {
            _validateIdentifier = validateIdentifier;
            _productService = productService;
            _interestRateService = interestRateService;
            _interestRateRepository = interestRateRepository;
        }

        public override void SetDomainContext(ProductInterestRateTierRequest request)
        {
        }

        public override Task<ProductInterestRateTierResponse> VerifyIdentifiers(ProductInterestRateTierRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.ProgramCode);
                return Task.FromResult(new ProductInterestRateTierResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<ProductInterestRateTierResponse>(e, request));
            }

        }

        public override Task<ProductInterestRateTierResponse> Handle(ProductInterestRateTierRequest request)
        {
            try
            {
                var product = _productService.GetByProductCode(request.ProductCode, DomainContext.Current.ProgramCode);
                var productInterestTiers = _interestRateService.GetProductInterestTierByProductKey(product.ProductKey, request.EffectiveDate);
                var sortedProductInterestTiers = SortProductInterestRateTier(productInterestTiers);
                var productInterestRateTiers = ToContracts(sortedProductInterestTiers, request.ProgramCode);
                var response = new ProductInterestRateTierResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                    ProductInterestRateTiers = productInterestRateTiers
                };
                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<ProductInterestRateTierResponse>(e, request));
            }
        }

        private List<ProductInterestTier> SortProductInterestRateTier(List<ProductInterestTier> productInterestTiers)
        {
            var returnProductInterestTiers = new List<ProductInterestTier>();

            var groupList = productInterestTiers
                .GroupBy(a => new { a.PurseType, a.InterestTierKey })
                .Select(a => new { a.Key }).ToList();
            foreach (var groupKey in groupList)
            {
                var orderedProductInterestTiers = productInterestTiers
                    .Where(a =>
                        a.PurseType == groupKey.Key.PurseType
                        && a.InterestTierKey == groupKey.Key.InterestTierKey)
                    .OrderBy(a => a.StartDate)
                    .ToList();
                returnProductInterestTiers.AddRange(orderedProductInterestTiers);
            }

            return returnProductInterestTiers;
        }

        private ProductInterestRateTier[] ToContracts(List<ProductInterestTier> productInterestTiers, string programCode)
        {
            var programInterestTierMetaData =
                _interestRateRepository.GetProductInterestTierInfoByProgramCode(programCode);

            return productInterestTiers.Select(a => new ProductInterestRateTier()
            {
                PurseType = a.PurseType.ToEnumMemberAttrValue(),
                APY = a.APY,
                InterestRate = a.InterestRate,
                StartDate = a.StartDate,
                EndDate = a.EndDate,
                InterestRateTier = programInterestTierMetaData.Tiers.FirstOrDefault(p => p.Key == a.InterestTierKey)!.Name,
                MinimumBalance = a.MinimumBalance,
                MaximumBalance = a.MaximumBalance,
                MaxInterestBalance = a.MaxInterestBalance
            }).ToArray();
        }
    }
}
