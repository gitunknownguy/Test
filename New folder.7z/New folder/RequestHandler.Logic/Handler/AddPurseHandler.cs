﻿using System;
using System.Collections.Specialized;
using System.Configuration;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using Gd.Bos.RequestHandler.Core.Domain.Model.Interest;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class AddPurseHandler : CommandHandlerBase<AddPurseRequest, AddPurseResponse>
    {
        private readonly IAccountService _accountService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ILockService _lockService;
        private readonly IInterestRateRepository _interestRateRepository;

        public AddPurseHandler(IAccountService accountService, IValidateIdentifier validateIdentifier, ILockService lockService, IInterestRateRepository interestRateRepository)
        {
            _accountService = accountService;
            _validateIdentifier = validateIdentifier;
            _lockService = lockService;
            _interestRateRepository = interestRateRepository;
        }

        public override void SetDomainContext(AddPurseRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<AddPurseResponse> VerifyIdentifiers(AddPurseRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new AddPurseResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AddPurseResponse>(e, request));
            }
        }

        public override async Task<AddPurseResponse> ObtainLock(AddPurseRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock(DomainContext.Current.AccountIdentifier.ToString());
                return new AddPurseResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<AddPurseResponse>(e, request);
            }
        }

        public override Task<AddPurseResponse> Handle(AddPurseRequest request)
        {
            try
            {
                PurseType purseType;
                if (!Enum.TryParse(request.PurseType, true, out purseType))
                    throw new ValidationException(600, 0,
                        $"Invalid purseType. Valid types: {Enum.GetNames(typeof(PurseType)).Aggregate((sa, s) => sa + ", " + s)}.");

                short interestRateTierKey = 0;
                if (!string.IsNullOrEmpty(request.InterestRateTier))
                {
                    var programInterestTierMetaData =
                        _interestRateRepository.GetProductInterestTierInfoByProgramCode(request.ProgramCode);
                    if (programInterestTierMetaData.Tiers.FirstOrDefault(p => p.Name == request.InterestRateTier) ==
                        null)
                        throw new ValidationException(600, 0, "Invalid InterestRateTier.");
                    interestRateTierKey =
                        programInterestTierMetaData.Tiers.FirstOrDefault(p => p.Name == request.InterestRateTier)!.Key;
                }

                var accountBalanceInterest = new AccountBalanceInterest
                {
                    InterestRateTierKey = interestRateTierKey,
                    InterestYieldStartDate = string.IsNullOrEmpty(request.InterestYieldStartDate) ? DateTime.Now.Date : DateTime.Parse(request.InterestYieldStartDate)
                };

                var newPurse = _accountService.AddPurseToAccount(request.ProgramCode, request.AccountIdentifier, purseType, request.PurseDescription, request.GoalAmount, request.GoalDate, request.IconName, accountBalanceInterest, request.AutoAlignStartDate, request.PurseSubType);

                var response = new AddPurseResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                    Purse = newPurse,
                };
                return Task.FromResult(response);
            }
            catch (DcppException e)
            {
                return Task.FromResult(e.HandleException<AddPurseResponse>(e, request));
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AddPurseResponse>(e, request));
            }
        }

        public override void ReleaseLock(AddPurseRequest request)
        {
            _lockService.ReleaseApiLock(DomainContext.Current.AccountIdentifier.ToString());
        }
    }
}
