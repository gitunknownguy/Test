﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Core.Infrastructure.DataAccesses;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.Common.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using RequestHandler.Core.Application.LinkedAccount;
using Account = Gd.Bos.RequestHandler.Core.Domain.Model.Account.Account;
using AccountStatus = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountStatus;
using Tokenizer = Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;

namespace RequestHandler.Logic.Handler
{
    public class CreateLinkedAccountHandler : CommandHandlerBase<LinkedAccountRequest, LinkedAccountResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ILockService _lockService;
        private readonly IAccountService _accountService;
        private readonly IProductService _productService;
        private readonly IBaasConfiguration _baasConfiguration;
        private readonly IRequestDataAccess _requestDataAccess;
        private readonly IUserRepository _userRepository;
        private readonly IAgreementDataAccess _agreementRepository;
        private readonly Tokenizer.ITokenizerService _tokenizerService;

        private readonly ILinkedAccountEnrollmentService _linkedAccountEnrollmentService;
        public CreateLinkedAccountHandler(
            IValidateIdentifier validateIdentifier,
            ILockService lockService,
            IAccountService accountService,
            IProductService productService,
            IBaasConfiguration baasConfiguration,
            IRequestDataAccess requestDataAccess,
            IUserRepository userRepository,
            IAgreementDataAccess agreementRepository,
            Tokenizer.ITokenizerService tokenizerService,
            ILinkedAccountEnrollmentService linkedAccountEnrollmentService
        )
        {
            _validateIdentifier = validateIdentifier;
            _lockService = lockService;
            _accountService = accountService;
            _productService = productService;
            _baasConfiguration = baasConfiguration;
         
            _requestDataAccess = requestDataAccess;
            _userRepository = userRepository;
            _agreementRepository = agreementRepository;
            _tokenizerService = tokenizerService;
            _linkedAccountEnrollmentService = linkedAccountEnrollmentService;
        }

        public override void SetDomainContext(LinkedAccountRequest request)
        {
            DomainContext.Current.IgnoreMfa = request.RequestHeader?.IgnoreMfa;
        }

        public override Task<LinkedAccountResponse> VerifyIdentifiers(LinkedAccountRequest request)
        {
            _validateIdentifier.ValidateProgramCode(request.AccountIdentifier, DomainContext.Current.ProgramCode);  //ValidateProgramCode
            _validateIdentifier.ValidateProduct(ProgramCode.FromString(request.ProgramCode), ProductCode.FromString(request.LinkedProductCode));
            ValidateChildProduct(request.ProgramCode, request.LinkedProductCode);
            return Task.FromResult(new LinkedAccountResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override async Task<LinkedAccountResponse> ObtainLock(LinkedAccountRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock(OptionsContext.Current.GetString("requestId"));

                return new LinkedAccountResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<LinkedAccountResponse>(e, request);
            }
        }

        public override void ReleaseLock(LinkedAccountRequest request)
        {
            _lockService.ReleaseApiLock(OptionsContext.Current.GetString("requestId"));
        }

        public override Task<LinkedAccountResponse> Handle(LinkedAccountRequest request)
        {
            try
            {
                ValidateRequest(request);

                var linkedProduct = GetLinkedProduct(request.ProgramCode, request.LinkedProductCode, request.RequestPhysicalCard, request.ProductMaterialType);

                var denialResponse = DenyRestrictedRegionsCreateLinkedAccount(request);
                if (denialResponse != null) return denialResponse;

                var parentAccount = GetAndValidateParentAccount(request.AccountIdentifier);
                var parentUser = GetAndValidateParentUser(parentAccount);
                var parentIdentity = parentUser.Identities.First();

                AccountLimitCheck(parentUser, request);


                var linkedAccountIdentifier = Guid.NewGuid();
                var existingAccountIdentifier = _requestDataAccess.InsertRequestId(RequestType.CreateLinkedAccount,
                    request.RequestHeader.RequestId, linkedAccountIdentifier);
                if (existingAccountIdentifier.HasValue && !existingAccountIdentifier.Value.Equals(linkedAccountIdentifier))
                {
                    linkedAccountIdentifier = existingAccountIdentifier.Value;
                }

                var userName = new UserName(request.UserProfile.FirstName, request.UserProfile.MiddleName, request.UserProfile.LastName);
                var email = string.IsNullOrWhiteSpace(request.UserProfile?.Email?.EmailAddress) ? parentUser.Email : request.UserProfile.Email.ToDomain();
                var addresses = request.UserProfile?.Addresses?.Count() > 0 ? request.UserProfile.Addresses.ToDomain() : parentUser.Addresses;
                var phoneNumbers = request.UserProfile?.PhoneNumbers?.Count > 0 ? request.UserProfile.PhoneNumbers.ToDomain() : parentUser.PhoneNumbers;
                var agreement = _agreementRepository.GetAgreementsByProductCode(request.LinkedProductCode);
                var terms = request.TermsAcceptances?.ToDomain(agreement);

                var ssn = _tokenizerService.DeTokenizeSsn(parentIdentity.IdentityToken, request.ProgramCode);
                var userIdentifyingData = new UserIdentifyingData(request.UserProfile!.DateOfBirth, "", ssn, "",
                    (int)RequestType.CreateLinkedAccount);

                return _linkedAccountEnrollmentService.LinkedAccountEnrollment(request, existingAccountIdentifier, linkedAccountIdentifier,
                    userName, email, addresses, phoneNumbers, terms, parentAccount, parentUser, userIdentifyingData,
                    linkedProduct);
            }
            catch (InvalidProductMaterialException e)
            {
                var response = new LinkedAccountResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 4,
                        SubStatusCode = 312,
                        Message = e.Message
                    },
                };
                return Task.FromResult(response);
            }
            catch (AccountNotFoundException e)
            {
                return Task.FromResult(e.HandleException<LinkedAccountResponse>(e, request));
            }
            catch (RequestHandlerException e)
            {
                var response = new LinkedAccountResponse();
                response.ResponseHeader = response.ResponseHeader.GetResponseHeader(e.Code.ToString(), request.RequestHeader.RequestId);
                if (response.ResponseHeader.StatusCode == 0)
                {
                    return Task.FromResult(e.HandleException<LinkedAccountResponse>(e, request));
                }

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<LinkedAccountResponse>(e, request));
            }
        }

        private static void ValidateRequest(LinkedAccountRequest request)
        {
            if (request.UserProfile == null)
            {
                throw new ValidationException(600, 5006, $"Missing user profile data.");
            }
            if (string.IsNullOrWhiteSpace(request.LinkedProductCode))
            {
                throw new ValidationException(600, 5001, $"linked product code is not valid.");
            }
            if (string.IsNullOrWhiteSpace(request.UserProfile?.FirstName) || request.UserProfile.FirstName.Length > 35)
            {
                throw new ValidationException(600, 5003, $"First name is not valid.");
            }

            if (string.IsNullOrWhiteSpace(request.UserProfile?.LastName) || request.UserProfile.LastName.Length is > 35 or 1)
            {
                throw new ValidationException(600, 5004, $"Last name is not valid.");
            }

            if (!string.IsNullOrWhiteSpace(request.UserProfile?.MiddleName) && request.UserProfile.MiddleName.Length is > 35 or 1)
            {
                throw new ValidationException(600, 5005, $"Middle name is not valid.");
            }

            if (!DateTime.TryParse(request.UserProfile?.DateOfBirth, out var dob) || dob > DateTime.Today)
            {
                throw new ValidationException(600, 5007, $"DateOfBirth is not valid.");
            }
        }

        private ProductTierInfo GetLinkedProduct(string programCode, string productCode, bool requestPhysicalCard, string productMaterialType)
        {
            if (!string.IsNullOrEmpty(productMaterialType))
            {
                if (!_productService.IsValidProductMaterialTypeForProductTier(programCode, productMaterialType))
                    throw new InvalidProductMaterialException("Invalid Product Material type");
            }

            ProductTierInfo result = null;
            
            if (requestPhysicalCard)
            {
                if (_baasConfiguration.IsGetProductTierByProductMaterialType(programCode))
                {
                    result = _productService.GetProductTierByProductCodeMaterialType(productCode, requestPhysicalCard, productMaterialType);

                    if (result == null)
                    {
                        throw new ValidationException(600, 5008, $"Can not get a ProductTier by the product code and productMaterialType {productMaterialType}.");
                    }
                }
                else
                {
                    var productTierInfos = _productService.GetAllProductTierInfoByProgramCodeProductCode(programCode, productCode);
                    result = productTierInfos?.FirstOrDefault(p => p.ProductMaterialType == productMaterialType);
                    if (result == null)
                    {
                        throw new ValidationException(600, 5008, $"Can not get a ProductTier by the product code and productMaterialType {productMaterialType}.");
                    }
                }
            }
            else
            {
                result = _productService.GetVirtualProductTierByProgramCodeProductCode(programCode, productCode);
                if (result == null)
                    throw new RequestHandlerException(600, 5009, "A virtual card only account is not allowed for this product.");
            }

            return result;
        }

        private Account GetAndValidateParentAccount(string parentAccountIdentifier)
        {
            var parentAccount = _accountService.GetAccount(parentAccountIdentifier);
            if (parentAccount?.AccountHolders?.FirstOrDefault() == null)
            {
                throw new RequestHandlerException(10, 0, "User Not Found.");
            }
            if (parentAccount.AccountStatus != AccountStatus.Normal)
            {
                throw new RequestHandlerException(600, 5000, "Account status must be healthy.");
            }

            return parentAccount;
        }

        private UserProfile GetAndValidateParentUser(Account parentAccount)
        {
            var primaryAccountHolder = parentAccount!.AccountHolders!.FirstOrDefault(x => x.IsPrimary);
            var parentUser = _userRepository
                .GetUser(parentAccount.AccountIdentifier, primaryAccountHolder?.UserIdentifier)?.FirstOrDefault();
            if (parentUser == null)
            {
                throw new RequestHandlerException(10, 0, "User Not Found.");
            }

            var userProfileIdentify = parentUser.Identities.FirstOrDefault();
            if (string.IsNullOrEmpty(userProfileIdentify?.IdentityToken))
            {
                throw new RequestHandlerException(10, 0, "User Not Found.");
            }

            return parentUser;
        }

        private void AccountLimitCheck(UserProfile parentUser, LinkedAccountRequest request)
        {
            var identity = parentUser.Identities.First();
            var accountLimit = _accountService.AccountLimitVerification(string.Empty, identity.IdentityToken,
                identity.IdentityType.ToString(), true, request.LinkedProductCode, request.ProgramCode);

            if (!string.IsNullOrWhiteSpace(accountLimit.ResponseCode) && accountLimit.ResponseCode != "0")
            {
                throw new RequestHandlerException(Convert.ToInt32(accountLimit.ResponseCode), 0, "SSN limit check is failed");
            }

            if (string.IsNullOrWhiteSpace(accountLimit.ResponseCode) || accountLimit.ResponseCode == "0")
            {
                var number = parentUser.PhoneNumbers?.FirstOrDefault(p => p.IsDefault)?.Number;
                if (string.IsNullOrEmpty(number))
                {
                    number = parentUser.PhoneNumbers?.FirstOrDefault()?.Number;
                }
                _accountService.PhoneLimitVerification(number, "PhoneNumber", request.LinkedProductCode, request.ProgramCode);
            }
        }

        private Task<LinkedAccountResponse> DenyRestrictedRegionsCreateLinkedAccount(LinkedAccountRequest request)
        {
            var state = request?.UserProfile?.Addresses?.FirstOrDefault()?.State;
            if (_baasConfiguration.IsPRAddressAllowed(request.ProgramCode))
            {
                if (state != null && state.Equals("GU", StringComparison.InvariantCultureIgnoreCase))
                {
                    return Task.FromResult(new LinkedAccountResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 5,
                            SubStatusCode = 65,
                            Message = "This product may not be registered in the requested region"
                        }
                    });
                }
            }
            else if (state != null && (state.Equals("PR", StringComparison.InvariantCultureIgnoreCase) ||
                state.Equals("GU", StringComparison.InvariantCultureIgnoreCase)))
            {
                return Task.FromResult(new LinkedAccountResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 5,
                        SubStatusCode = 65,
                        Message = "This product may not be registered in the requested region"
                    }
                });
            }

            return null;
        }

        private void ValidateChildProduct(string programCode, string productCode)
        {
            var childProductCodes = _baasConfiguration.GetChildProductCode(programCode);

            if (childProductCodes?.Any() != true)
            {
                return;
            }

            var isMatch = childProductCodes.Any(p => productCode?.Equals(p, StringComparison.OrdinalIgnoreCase) == true);
            if (!isMatch)
            {
                throw new ValidationException(600, 5010, $"The product code {productCode} is not a child product code for program code {programCode}.");
            }
        }

    }
}
