﻿using System;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using NLog;
using RequestHandler.Core.Application;

namespace RequestHandler.Logic.Handler
{
    public class CheckGiftA2AInLimitationHandler : CommandHandlerBase<CheckGiftA2AInLimitationRequest, CheckGiftA2AInLimitationResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IGiftA2AInService _giftA2AInService;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();

        public CheckGiftA2AInLimitationHandler(IValidateIdentifier validateIdentifier, IGiftA2AInService giftA2AInService)
        {
            _validateIdentifier = validateIdentifier;
            _giftA2AInService = giftA2AInService;
        }

        public override Task<CheckGiftA2AInLimitationResponse> Handle(CheckGiftA2AInLimitationRequest request)
        {
            try
            {
                var response = _giftA2AInService.CheckLimitation(request);

                return Task.FromResult(response);
            }
            catch(AccountValidationException ave)
            {
                var response = new CheckGiftA2AInLimitationResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader?.RequestId ?? new Guid(),
                        StatusCode = ave.Code,
                        SubStatusCode = ave.SubCode,
                        Message = ave.Message,
                        Details = ave.ToString()
                    },
                    AccountIdentifier = request.AccountIdentifier,
                    Amount = request.Amount
                };
                _logger.Error(ave, $"Failed to validate the CheckGiftA2AInLimitationRequest. RequestId:{request.RequestHeader.RequestId}");
                return Task.FromResult(response);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"CheckGiftA2AInLimitationHandler Throws Exception. RequestId:{request.RequestHeader.RequestId}");
                return Task.FromResult(ex.HandleException<CheckGiftA2AInLimitationResponse>(ex, request));
            }
        }

        public override void SetDomainContext(CheckGiftA2AInLimitationRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<CheckGiftA2AInLimitationResponse> VerifyIdentifiers(CheckGiftA2AInLimitationRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 4, 105);

                return Task.FromResult(new CheckGiftA2AInLimitationResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CheckGiftA2AInLimitationResponse>(e, request));
            }
        }
    }
}
