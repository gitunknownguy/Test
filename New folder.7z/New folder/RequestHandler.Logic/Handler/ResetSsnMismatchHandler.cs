﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using NLog;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class ResetSsnMismatchHandler : CommandHandlerBase<ResetSsnMismatchRequest, ResetSsnMismatchResponse>
    {
        private readonly IResetSsnMismatchService _resetSsnMismatchService;
        private readonly IValidateIdentifier _validateIdentifier;

        public ResetSsnMismatchHandler(IResetSsnMismatchService resetSsnMismatchService
        , IValidateIdentifier validateIdentifier)
        {
            _resetSsnMismatchService = resetSsnMismatchService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(ResetSsnMismatchRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            if (!string.IsNullOrEmpty(request.UserIdentifier))
                DomainContext.Current.UserIdentifier = request.UserIdentifier;
        }

        public override Task<ResetSsnMismatchResponse> VerifyIdentifiers(ResetSsnMismatchRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidateConsumerProfileIdentifier(DomainContext.Current.AccountIdentifier, DomainContext.Current.UserIdentifier);
                return Task.FromResult(new ResetSsnMismatchResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<ResetSsnMismatchResponse>(e, request));
            }
        }

        public override Task<ResetSsnMismatchResponse> Handle(ResetSsnMismatchRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.UserIdentifier))
                {
                    throw new ArgumentNullException(nameof(request.UserIdentifier));
                }

                _resetSsnMismatchService.ResetSsnMismatch(request.AccountIdentifier, request.UserIdentifier);

                var response = new ResetSsnMismatchResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    }
                };

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<ResetSsnMismatchResponse>(e, request));
            }
        }
    }
}
