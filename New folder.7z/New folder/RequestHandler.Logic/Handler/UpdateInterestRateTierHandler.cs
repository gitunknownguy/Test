﻿using System;
using System.Globalization;
using System.Linq;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Interest;
using Gd.Bos.RequestHandler.Core.Domain.Services.InterestRate;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using System.Diagnostics.CodeAnalysis;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class UpdateInterestRateTierHandler : CommandHandlerBase<UpdateInterestRateTierRequest, UpdateInterestRateTierResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IInterestRateService _interestRateService;
        private readonly IInterestRateRepository _interestRateRepository;

        public UpdateInterestRateTierHandler(IValidateIdentifier validateIdentifier, IInterestRateService interestRateService, IInterestRateRepository interestRateRepository)
        {
            _validateIdentifier = validateIdentifier;
            _interestRateService = interestRateService;
            _interestRateRepository = interestRateRepository;
        }
        public override void SetDomainContext(UpdateInterestRateTierRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<UpdateInterestRateTierResponse> VerifyIdentifiers(UpdateInterestRateTierRequest request)
        {
            _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
            _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 5, 105);
            return Task.FromResult(new UpdateInterestRateTierResponse { ResponseHeader = new ResponseHeader() });
        }

        public override Task<UpdateInterestRateTierResponse> Handle(UpdateInterestRateTierRequest request)
        {
            short interestRateTierKey = 0;
            if (!string.IsNullOrEmpty(request.InterestRateTier))
            {
                var programInterestTierMetaData =
                    _interestRateRepository.GetProductInterestTierInfoByProgramCode(request.ProgramCode);
                if (programInterestTierMetaData.Tiers.FirstOrDefault(p => p.Name == request.InterestRateTier) == null)
                    throw new ValidationException(600, 0, "Invalid InterestRateTier.");
                interestRateTierKey =
                    programInterestTierMetaData.Tiers.FirstOrDefault(p => p.Name == request.InterestRateTier)!.Key;
            }

            var endDate = new DateTime?();
            if (!string.IsNullOrEmpty(request.InterestYieldEndDate) &&
                DateTime.TryParse(request.InterestYieldEndDate, out var parsedEndDate))
                endDate = parsedEndDate.ToUniversalTime().Date;

            var newAccountBalanceInterest = new AccountBalanceInterest
            {
                AccountBalanceInterestIdentifier = Guid.Parse(request.InterestRateTierIdentifier),
                InterestYieldEndDate = endDate,

                InterestRateTierKey = interestRateTierKey
            };

            DateTime? startDate = null;
            if (!string.IsNullOrEmpty(request.InterestYieldStartDate) &&
                DateTime.TryParse(request.InterestYieldStartDate, out var parsedStartDate))
                startDate = parsedStartDate.ToUniversalTime().Date;

            if (startDate != null)
                newAccountBalanceInterest.InterestYieldStartDate = startDate.Value;

            bool autoAlignStartDate = false;
            if (request.AutoAlignStartDate != null)
            {
                autoAlignStartDate = request.AutoAlignStartDate.Value;
            }

            var tier = _interestRateService.Update(
                ProgramCode.FromString(request.ProgramCode),
                AccountIdentifier.FromString(request.AccountIdentifier),
                AccountBalanceIdentifier.FromString(request.PurseIdentifier),
                newAccountBalanceInterest,
                request.RemoveInterestYieldEndDate,
                autoAlignStartDate: autoAlignStartDate
            );

            return Task.FromResult(new UpdateInterestRateTierResponse
            {
                InterestRateTierIdentifier = tier.AccountBalanceInterestIdentifier.ToString(),
                InterestYieldStartDate = tier.InterestYieldStartDate.Value.ToString("yyyy-MM-dd"),
                InterestYieldEndDate = tier.InterestYieldEndDate?.ToString("yyyy-MM-dd"),
                APY = tier.APY.ToString(),
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                }
            });
        }


    }
}