﻿using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.ECash;
using ECashPartner = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.ECashPartner;
using GetECashPartnersRequest = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.GetECashPartnersRequest;
using GetECashPartnersResponse = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.GetECashPartnersResponse;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class ECashPartnersHandler : ECashHandlerBase<GetECashPartnersRequest, GetECashPartnersResponse>
    {
        public ECashPartnersHandler(IECashService eCashService) : base(eCashService)
        {

        }

        public override void SetDomainContext(GetECashPartnersRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetECashPartnersResponse> VerifyIdentifiers(GetECashPartnersRequest request)
        {
            return Task.FromResult(new GetECashPartnersResponse { ResponseHeader = new ResponseHeader() });
        }

        public override Task<GetECashPartnersResponse> Handle(GetECashPartnersRequest request)
        {
            return Task.FromResult(GetECashPartners(request));
        }

        private GetECashPartnersResponse GetECashPartners(GetECashPartnersRequest request)
        {
            var response = new GetECashPartnersResponse();
            var domainResponse = ECashService.GetECashPartners(new Core.Domain.Services.ECash.GetECashPartnersRequest
            {
                AccountIdentifier = request.AccountIdentifier,
                ProgramCode = request.ProgramCode
            });

            response.ResponseHeader = MapResponse(domainResponse?.ResponseDetails?[0], request.RequestHeader.RequestId);

            if (domainResponse?.Partners != null)
            {
                response.Partners = domainResponse.Partners.Select(x => new ECashPartner
                {
                    FaceFee = x.FaceFee,
                    PartnerId = x.PartnerId,
                    PartnerName = x.PartnerName
                }).ToList();
            }

            return response;
        }

    }
}
