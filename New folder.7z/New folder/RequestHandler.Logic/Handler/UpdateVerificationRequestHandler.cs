﻿using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Enums;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using NLog;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class UpdateVerificationRequestHandler : CommandHandlerBase<UpdateVerificationRequest, UpdateVerificationResponse>
    {
        private readonly VerificationRequestService _service;
        private readonly IEnrollmentDataAccess _enrollmentDataAccess;
        private readonly INotificationService _notificationPublisher;
        private readonly IWelcomeNotificationService _welcomeNotificationService;
        private readonly IAccountService _accountService;
        private readonly IAccountRepository _accountRepository;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IVerificationRepository _verificationRepository;
        private readonly IBaasConfiguration _baasConfiguration;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();


        public UpdateVerificationRequestHandler(VerificationRequestService service,
            IEnrollmentDataAccess enrollmentDataAccess,
            INotificationService notificationPublisher,
            IWelcomeNotificationService welcomeNotificationService,
            IAccountRepository accountRepository,
            IAccountService accountService,
            IValidateIdentifier validateIdentifier,
            IVerificationRepository verificationRepository,
            IBaasConfiguration baasConfiguration
            )
        {
            _service = service;
            _enrollmentDataAccess = enrollmentDataAccess;
            _notificationPublisher = notificationPublisher;
            _welcomeNotificationService = welcomeNotificationService;
            _accountService = accountService;
            _accountRepository = accountRepository;
            _validateIdentifier = validateIdentifier;
            _verificationRepository = verificationRepository;
            _baasConfiguration = baasConfiguration;
        }

        public override void SetDomainContext(UpdateVerificationRequest request)
        {
        }

        public override Task<UpdateVerificationResponse> VerifyIdentifiers(UpdateVerificationRequest request)
        {
            return Task.FromResult(new UpdateVerificationResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override async Task<UpdateVerificationResponse> Handle(UpdateVerificationRequest request)
        {
            try
            {
                //the reasons in the request will be changed in some scenarios, but ofacH notification need to use the original reasons to check.
                //ToList() will create a new list to keep the original value.
                var reasons = request.Reasons == null ? new List<string>() : request.Reasons.ToList();

                var accountIdentifier = _service.GetAccountIdentifier(VerificationRequestIdentifier.FromString(request.VerificationRequestIdentifier));
                //Validate program code and account identifier
                _validateIdentifier.ValidateProgramCode(accountIdentifier, DomainContext.Current.ProgramCode);
                string productCode = null;

                if (accountIdentifier != null)
                {
                    var accountRespForProductCode =
                        _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(accountIdentifier.ToString(),
                            request.ProgramCode, false);
                    productCode = accountRespForProductCode.Account.ProductCode;
                }
                var vri = Guid.Parse(request.VerificationRequestIdentifier);
                // existing verification request
                var verificationRequest = _verificationRepository.GetByVerificationRequestIdentifier(vri);
                var isJoinAccount = _accountService.IsJointAccount(accountIdentifier?.ToString());
                _logger.Info($"UpdateVerification checked isJoinAccount {isJoinAccount} with request id {request.RequestHeader?.RequestId}, account id {accountIdentifier}");
                if (isJoinAccount)
                {
                    _service.UpdateVerificationRequestForJoinAccounts(request, accountIdentifier, verificationRequest);
                }
                else
                {
                    await _service.UpdateVerificationRequest(request, accountIdentifier, productCode, verificationRequest);
                }

                if (accountIdentifier != null)
                {
                    if (verificationRequest.TriggerTypeKey != (short)TriggerType.AccountUpgrade)
                    {
                        var accountResp = _accountService.GetEnrollmentByAccountIdentifier(accountIdentifier.ToString(), request.ProgramCode, false);
                        var childProductCode = _baasConfiguration.GetChildProductCode(request.ProgramCode);
                        if(childProductCode!= null && childProductCode.Exists(x => x.Equals(productCode)))
                        { 
                            accountResp.Account.AccountHolders.Remove(accountResp.Account.AccountHolders.Where(x => x.User.IsPrimaryAccountHolder).FirstOrDefault());
                        }
                        if (isJoinAccount)
                        {
                            accountResp.Account.AccountHolders = accountResp.Account.AccountHolders.Where(a => a.User.ConsumerProfileKey == verificationRequest.ConsumerProfileKey)?.ToList();
                        }

                        var requestId = request.RequestHeader?.RequestId == null ? Guid.NewGuid().ToString() : request.RequestHeader.RequestId.ToString();
                        await _notificationPublisher.PublishNotification(request.ProgramCode, accountResp.Account,
                            Bos.Shared.Common.Core.CoreApi.Contract.Data.EventType.AccountUpdated, requestId);

                        if (accountResp.Account.Status == "normal")
                            _welcomeNotificationService.RaiseWelcomeNotification(request.ProgramCode, accountResp.Account.AccountIdentifier, request.RequestHeader.RequestId);
                        else if (_accountService.IsDeclinedAccount(accountResp.Account))
                        {
                            UpdateLinkedSccAccountEndDate(accountResp.Account.AccountIdentifier);

                            //if it is a SCC account and with status reason ofach then should have a new type unwelcome email
                            var binType = _accountService.GetAccountBinType(accountIdentifier);
                            reasons = reasons.ConvertAll(d => d.ToLower());
                            if (binType == BinType.Credit && reasons.Contains("OFAC-H".ToLower()))
                            {
                                _welcomeNotificationService.RaiseUnwelcomeNotificationForSccOFACH(request.ProgramCode, accountResp.Account.AccountIdentifier, request.RequestHeader.RequestId);
                            }
                            else
                            {
                                _welcomeNotificationService.RaiseUnwelcomeNotification(request.ProgramCode, accountResp.Account.AccountIdentifier, request.RequestHeader.RequestId);
                            }
                        }

                    }
                }
                else
                {
                    throw new AccountNotFoundException();
                }

                return new UpdateVerificationResponse()
                {
                    ResponseHeader = ResponseHeader.SuccessForRequest(request.RequestHeader),
                };

            }
            catch (Exception e)
            {
                return e.HandleException<UpdateVerificationResponse>(e, request);
            }

        }

        private void UpdateLinkedSccAccountEndDate(string linkAccountIdentifier)
        {
            var linkAccountDetail =
                _accountRepository.GetLinkedAccounts(AccountIdentifier.FromString(linkAccountIdentifier));

            var result = linkAccountDetail.Find(l => l.LinkAccountIdentifier.Equals(linkAccountIdentifier, StringComparison.InvariantCultureIgnoreCase) && (l.EndDate > DateTime.Now || l.EndDate == null));
            if (result != null)
            {
                _accountRepository.UpdateLinkAccount(result.AccountLinkKey);
            }
        }

    }
}
