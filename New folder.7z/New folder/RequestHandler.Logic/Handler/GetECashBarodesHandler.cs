﻿using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.ECash;
using GetBarcodeListResponse = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.GetBarcodeListResponse;
using GetBarcodeListRequest = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.GetBarcodeListRequest;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetECashBarcodesHandler : ECashHandlerBase<GetBarcodeListRequest, GetBarcodeListResponse>
    {
        public GetECashBarcodesHandler(IECashService eCashService) : base(eCashService)
        {

        }

        public override void SetDomainContext(GetBarcodeListRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetBarcodeListResponse> VerifyIdentifiers(GetBarcodeListRequest request)
        {
            return Task.FromResult(new GetBarcodeListResponse { ResponseHeader = new ResponseHeader() });
        }

        public override Task<GetBarcodeListResponse> Handle(GetBarcodeListRequest request)
        {
            return Task.FromResult(GetECashBarcodes(request));
        }

        private GetBarcodeListResponse GetECashBarcodes(GetBarcodeListRequest request)
        {
            var response = new GetBarcodeListResponse();
            var domainResponse = ECashService.GetECashBarcodes(new Core.Domain.Services.ECash.GetBarcodeListRequest
            {
                AccountIdentifier = request.AccountIdentifier,
                ProgramCode = request.ProgramCode
            });

            response.ResponseHeader = MapResponse(domainResponse?.ResponseDetails?[0], request.RequestHeader.RequestId);


            if (domainResponse?.ECashTransactions != null)
            {
                response.ECashTransactions = domainResponse.ECashTransactions.Select(eCash => new ECashTransactionDetails
                {
                    PartnerId = eCash.PartnerId,
                    PartnerName = eCash.PartnerName,
                    ProgramCode = eCash.ProgramCode,
                    ProductCode = eCash.ProductCode,
                    AccountIdentifier = eCash.AccountIdentifier,
                    Amount = eCash.Amount,
                    Recipient = eCash.Recipient,
                    Memo = eCash.Memo,
                    TransactionType = eCash.TransactionType,
                    BarcodeHumanReadable = eCash.BarcodeHumanReadable,
                    BarcodeNumber = eCash.BarcodeNumber,
                    BarcodeStatus = eCash.BarcodeStatus,
                    BarcodeExpirationDateTime = eCash.BarcodeExpirationDateTime,
                    FaceFee = eCash.FaceFee,
                    ZipCode = eCash.ZipCode
                }).ToList();
            }

            return response;
        }

    }
}
