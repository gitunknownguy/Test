﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.ProgramFunding;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers.Exceptions;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Exceptions;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Account = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Account;
using AssessTransferRequest = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.AssessTransferRequest;
using Limits = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Limits;
using RequestHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.RequestHeader;
using TransferType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class AssessTransferHandler : CommandHandlerBase<AssessTransferRequest, AssessTransferResponse>
    {
        private readonly string _customTransactionDescriptionSuffix = "#";

        public AssessTransferHandler(ITransferService transferService, IValidateIdentifier validateIdentifier, IRiskService riskService, ILimitTypeService limitTypeService, IBaasConfiguration baasConfiguration)
        {
            _transferService = transferService;
            _validateIdentifier = validateIdentifier;
            _riskService = riskService;
            _limitTypeService = limitTypeService;
            _baasConfiguration = baasConfiguration;
        }

        public override void SetDomainContext(AssessTransferRequest request)
        {
            DomainContext.Current.Initiator = request.Initiator;
            if (!string.IsNullOrEmpty(request.TransferRoute.SourceTransferEndPoint.Identifier)
                && request.TransferRoute.SourceTransferEndPoint.TransferEndPointType != EndpointType.Card)
                DomainContext.Current.AccountIdentifier = request.TransferRoute.SourceTransferEndPoint.Identifier;
            if (!string.IsNullOrEmpty(request.TransferRoute.TargetTransferEndPoint.Identifier)
                && request.TransferRoute.TargetTransferEndPoint.TransferEndPointType != EndpointType.Card)
                DomainContext.Current.ReferencedAccountIdentifier = request.TransferRoute.TargetTransferEndPoint.Identifier;
            if (request.TransferType == TransferType.Purse)
            {
                DomainContext.Current.AccountIdentifier = request.Initiator;
                DomainContext.Current.ReferencedAccountIdentifier = request.Initiator;
            }

            if (request.TransferRoute.SourceTransferEndPoint.TransferEndPointType == EndpointType.ProgramFundingSource)
                DomainContext.Current.ProgramFundingIdentifier = ProgramFundingIdentifier.FromString(request.TransferRoute.SourceTransferEndPoint.Identifier);
            if (request.TransferRoute.TargetTransferEndPoint.TransferEndPointType == EndpointType.ProgramFundingSource)
                DomainContext.Current.ProgramFundingIdentifier = ProgramFundingIdentifier.FromString(request.TransferRoute.TargetTransferEndPoint.Identifier);
        }

        public override Task<AssessTransferResponse> VerifyIdentifiers(AssessTransferRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramFunding(DomainContext.Current.ProgramFundingIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.Initiator, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidatePartner_AccountIdProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidatePartner_AccountIdProgramCode(DomainContext.Current.ReferencedAccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new AssessTransferResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AssessTransferResponse>(e, request));
            }
        }

        public override Task<AssessTransferResponse> Handle(AssessTransferRequest request)
        {
            Tuple<TransferStatus, List<Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Account>> response = null;
            List<Limits> filteredlimits = null;
            List<string> preReqResponse = null;
            try
            {
                if (request.RequestHeader.RequestId == Guid.Empty)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId,
                        $"{nameof(request)}.RequestHeader.RequestId must be specified");
                }

                if (string.IsNullOrEmpty(request.TransferIdentifier) || request.TransferIdentifier == Guid.Empty.ToString())
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier,
                        $"{nameof(request)}.TransferIdentifier must be specified");
                }

                var accountIdForLimits = (request.TransferType == TransferType.DisbursementIn)
                    ? request.TransferRoute.TargetTransferEndPoint.Identifier
                    : request.Initiator;


                try
                {
                    filteredlimits = _limitTypeService.GetApplicableLimits(accountIdForLimits, request.ProgramCode, request.TransferType);
                }
                catch (Exception e) { }

                decimal? availableBalance = 0;
                switch (request.TransferType)
                {
                    case TransferType.DisbursementIn:
                        availableBalance = null;
                        response = HandleDisbursementIn(request);
                        break;
                    case TransferType.DisbursementOut:
                        response = HandleDisbursementOut(request);
                        break;
                    case TransferType.AchOut:
                        response = HandleAchOut(request);
                        break;
                    case TransferType.AchPull:
                        availableBalance = null;
                        response = HandleAchPull(request);
                        break;
                    case TransferType.SwipeReload:
                        response = HandleSwipeReload(request);
                        break;
                    case TransferType.MrdcTransfer:
                        availableBalance = null;
                        preReqResponse = GetPrerequisites(request.TransferType, request?.TransferRoute?.TargetTransferEndPoint?.Identifier, request.RequestHeader);
                        response = HandleMrdc(request);
                        break;
                    case TransferType.ECashLoad:
                        response = HandleECashLoad(request);
                        break;
                    case TransferType.BillPay:
                        //response = HandleBillpay(request);
                        break;
                    case TransferType.PeerPayment:
                        response = HandlePeerPayments(request);
                        break;
                    case TransferType.ECashSend:
                        availableBalance = null;
                        response = HandleECashSend(request);
                        break;
                    case TransferType.IFTLoad:
                        availableBalance = null;
                        response = HandleIFTLoad(request);
                        break;
                    case TransferType.IFTSend:
                        availableBalance = null;
                        response = HandleIFTSend(request);
                        break;
                    case TransferType.IFTOut:
                        //availableBalance = null;
                        response = HandleIFTOut(request);
                        break;
                    case TransferType.UnLoad:
                        response = HandleUnLoad(request);
                        break;
                    case TransferType.InitialLoad:
                        response = HandleInitialLoad(request);
                        break;
                    default:
                        throw new InvalidTransferTypeException($"Invalid Transfer Type.");
                }

                if (request.TransferType != TransferType.Purse
                    && request.TransferType != TransferType.ECashSend
                    && request.TransferType != TransferType.IFTSend
                    && request.Initiator != request.TransferRoute.SourceTransferEndPoint.Identifier
                    && request.Initiator != request.TransferRoute.TargetTransferEndPoint.Identifier)
                    throw new InvalidInitiatorException("Initiator does not match the source or target account.");

                var transferStatus = response?.Item1;
                var accountList = response?.Item2;

                if (availableBalance.HasValue)
                {
                    var account = accountList?.FirstOrDefault(a => a.AccountIdentifier == accountIdForLimits.ToLower());
                    var primaryPurse = account?.Purses.FirstOrDefault(p => p.PurseType == PurseType.Primary);
                    if (primaryPurse != null)
                        availableBalance = System.Math.Round(primaryPurse.AvailableBalance, 2);

                    decimal accountbalance = 0;
                    if (account != null && account.Purses != null)
                    {
                        accountbalance = account.Purses.Sum(p => p.AvailableBalance);
                    }
                    UpdateSwipeReloadLimitRemainingAmount(request.TransferType, filteredlimits, accountbalance);
                }

                var fees = _transferService.GetTransferFees(request.TransferType, request.Initiator,
                    request.TransferRoute.TransactionAmount);
                var netAmount = _transferService.CalculateNetAmount(request.TransferType, request.TransferRoute.TransactionAmount, fees);

                return Task.FromResult(new AssessTransferResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = transferStatus == TransferStatus.Completed ? "Success" : transferStatus.ToString()
                    },
                    AccountHolders = GetAccountHolder(null),
                    AvailableBalance = availableBalance,
                    Fees = fees,
                    Limits = filteredlimits,
                    Prerequisites = preReqResponse,
                    NetAmount = netAmount
                });
            }
            catch (TransferAccountStateException ex)
            {
                var fees = _transferService.GetTransferFees(request.TransferType, request.Initiator,
                    request.TransferRoute.TransactionAmount);
                var netAmount = _transferService.CalculateNetAmount(request.TransferType, request.TransferRoute.TransactionAmount, fees);

                var rs = ex.HandleException<AssessTransferResponse>(ex, request);
                rs.AccountHolders = GetAccountHolder(ex.AccountHolder);
                rs.Fees = fees;
                rs.Limits = filteredlimits;
                rs.Prerequisites = preReqResponse;
                rs.NetAmount = netAmount;
                return Task.FromResult(rs);
            }
            catch (TransferValidationException ex)
            {
                var fees = _transferService.GetTransferFees(request.TransferType, request.Initiator,
                    request.TransferRoute.TransactionAmount);
                var netAmount = _transferService.CalculateNetAmount(request.TransferType, request.TransferRoute.TransactionAmount, fees);

                var rs = ex.HandleException<AssessTransferResponse>(ex, request);
                rs.AccountHolders = GetAccountHolder(null);
                rs.Fees = fees;
                rs.Limits = filteredlimits;
                rs.Prerequisites = preReqResponse;
                rs.NetAmount = netAmount;

                Tuple<decimal, decimal> avalilbalanceTuple = null;
                switch (request.TransferType)
                {
                    case TransferType.InitialLoad:
                        avalilbalanceTuple = GetAvailableBalanceForAmountBalanceDeclind(request.IsReversal == false ? request.TransferRoute.TargetTransferEndPoint.Identifier : request.TransferRoute.SourceTransferEndPoint.Identifier);
                        rs.AvailableBalance = avalilbalanceTuple.Item1;
                        break;
                    case TransferType.SwipeReload:
                        avalilbalanceTuple = GetAvailableBalanceForAmountBalanceDeclind(request.IsReversal == false ? request.TransferRoute.TargetTransferEndPoint.Identifier : request.TransferRoute.SourceTransferEndPoint.Identifier);
                        rs.AvailableBalance = avalilbalanceTuple.Item1;
                        break;
                    case TransferType.UnLoad:
                        avalilbalanceTuple = GetAvailableBalanceForAmountBalanceDeclind(request.IsReversal == false ? request.TransferRoute.SourceTransferEndPoint.Identifier : request.TransferRoute.TargetTransferEndPoint.Identifier);
                        rs.AvailableBalance = avalilbalanceTuple.Item1;
                        break;
                }

                if (avalilbalanceTuple != null)
                {
                    UpdateSwipeReloadLimitRemainingAmount(request.TransferType, rs.Limits, avalilbalanceTuple.Item2);
                }
                return Task.FromResult(rs);
            }
            catch (RequestHandlerException e)
            {
                var fees = _transferService.GetTransferFees(request.TransferType, request.Initiator,
                    request.TransferRoute.TransactionAmount);
                var netAmount = _transferService.CalculateNetAmount(request.TransferType, request.TransferRoute.TransactionAmount, fees);

                var rs = e.HandleException<AssessTransferResponse>(e, request);
                rs.AccountHolders = GetAccountHolder(null);
                rs.Fees = fees;
                rs.Limits = filteredlimits;
                rs.Prerequisites = preReqResponse;
                rs.NetAmount = netAmount;
                return Task.FromResult(rs);
            }
            //catch (Core.Domain.Model.Transfers.Exceptions.AccountNotFoundException e)
            //{
            //    throw;
            //}
            catch (Exception e)
            {
                var rs = e.HandleException<AssessTransferResponse>(e, request);
                if (!(rs?.ResponseHeader?.StatusCode == 3 && rs?.ResponseHeader?.SubStatusCode == 105)) //account is not closed
                {
                    var fees = _transferService.GetTransferFees(request.TransferType, request.Initiator,
                        request.TransferRoute.TransactionAmount);
                    var netAmount = _transferService.CalculateNetAmount(request.TransferType, request.TransferRoute.TransactionAmount, fees);

                    rs.AccountHolders = GetAccountHolder(null);
                    rs.Fees = fees;
                    rs.Limits = filteredlimits;
                    rs.Prerequisites = preReqResponse;
                    rs.NetAmount = netAmount;
                }
                return Task.FromResult(rs);
            }

        }
        private void UpdateSwipeReloadLimitRemainingAmount(TransferType transferType, List<Limits> limits, decimal availableBalance)
        {
            if (transferType == TransferType.SwipeReload)
            {
                var balanceLimit = limits.Where(l => l.Type.Equals("balanceLimit")).FirstOrDefault();
                if (balanceLimit != null)
                {
                    balanceLimit.AmountRemaining = balanceLimit.MaximumAmount - availableBalance;
                    balanceLimit.AmountRemaining = balanceLimit.AmountRemaining >= 0 ? balanceLimit.AmountRemaining : 0;
                }
            }
        }
        private Tuple<decimal, decimal> GetAvailableBalanceForAmountBalanceDeclind(AccountIdentifier accountIdentifier)
        {
            var response = _transferService.GetTransferResponse(TransferStatus.Declined, accountIdentifier);
            var account = response.Item2?.FirstOrDefault(a => a.AccountIdentifier == accountIdentifier);

            if (account != null && account.Purses != null)
            {
                decimal primaryBalance = 0;
                decimal sumBalance = 0;

                var primaryPurse = account.Purses.FirstOrDefault(p => p.PurseType == PurseType.Primary);
                if (primaryPurse != null)
                {
                    primaryBalance = System.Math.Round(primaryPurse.AvailableBalance, 2);
                }
                sumBalance = account.Purses.Sum(p => p.AvailableBalance);
                return new Tuple<decimal, decimal>(primaryBalance, sumBalance);
            }
            return new Tuple<decimal, decimal>(0, 0);
        }
        private List<string> GetPrerequisites(TransferType requestTransferType, string identifier, RequestHeader requestHeaders)
        {
            if (requestTransferType != TransferType.MrdcTransfer)
                return null;

            List<string> prereqs = new List<string>();
            var riskResponse = _transferService.ValidateMrdcPrerequisites(identifier, requestHeaders);
            if (riskResponse.EligibilityReasonCodes?.Length > 0)
                foreach (var code in riskResponse.EligibilityReasonCodes)
                {
                    var prereq = code.ToLower().Replace("mrdc-", "");
                    prereqs.Add(prereq);
                }

            return prereqs;
        }

        private Tuple<TransferStatus, List<Account>> HandleDisbursementIn(AssessTransferRequest request)
        {
            TransferRequestValidation.HandleDisbursementInValidation(request);

            if (!string.IsNullOrWhiteSpace(request.TransferDescription))
            {
                request.TransferDescription = request.TransferDescription + _customTransactionDescriptionSuffix;
            }

            return _transferService.TransferDisbursementIn(
                request.TransferIdentifier,
                request.Initiator,
                request.AuthorizationType.ToString(),
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.SourceTransferEndPoint.Identifier,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.ProgramCode,
                request.PartnerReferenceData,
                true,
                request.TransferDescription);
        }

        private Tuple<TransferStatus, List<Account>> HandleDisbursementOut(AssessTransferRequest request)
        {
            TransferRequestValidation.HandleDisbursementOutValidation(request);

            if (!string.IsNullOrWhiteSpace(request.TransferDescription))
            {
                request.TransferDescription = request.TransferDescription + _customTransactionDescriptionSuffix;
            }

            return _transferService.TransferDisbursementOut(
                request.TransferIdentifier,
                request.Initiator,
                request.AuthorizationType.ToString(),
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.SourceTransferEndPoint.Identifier,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.ProgramCode,
                request.PartnerReferenceData,
                true,
                request.TransferDescription);
        }

        private Tuple<TransferStatus, List<Account>> HandleMrdc(AssessTransferRequest request)
        {
            TransferRequestValidation.HandleMrdcTransferValidation(request, true);

            Check check = request.TransferRoute.SourceTransferEndPoint.Check;

            var result = _transferService.TransferMrdc(
                request.TransferIdentifier,
                request.Initiator,
                request.AuthorizationType.ToString(),
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.RequestHeader,
                request.ProgramCode,
                check,
                true,
                request.TransferRoute.DeliveryType);

            return new Tuple<TransferStatus, List<Account>>(result.Item1, result.Item2);
        }

        private Tuple<TransferStatus, List<Account>> HandleAchOut(AssessTransferRequest request)
        {
            TransferRequestValidation.HandleAchOutValidation(request);

            if (!string.IsNullOrWhiteSpace(request.TransferDescription))
            {
                request.TransferDescription = request.TransferDescription + _customTransactionDescriptionSuffix;
            }

            Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.BankAccount bankAccount = request.TransferRoute.TargetTransferEndPoint.BankAccount;

            return _transferService.TransferAchOut(
                request.TransferIdentifier,
                request.Initiator,
                request.AuthorizationType.ToString(),
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.SourceTransferEndPoint.Identifier,
                request.TransferRoute.RecurringType,
                request.TransferRoute.BankAccountVerificationMethod,
                request.TransferRoute.BankAccountVerificationDate,
                request.TransferRoute.BankAccountAuthorizationDate,
                bankAccount.AccountNumber,
                bankAccount.RoutingNumber,
                bankAccount.BankName,
                bankAccount.FirstName,
                bankAccount.LastName,
                bankAccount.BusinessName,
                bankAccount.AccountType,
                request.ProgramCode,
                true,
                request.UserIdentifier,
                request.TransferRoute.TargetTransferEndPoint.BankAccountReferenceId,
                request.TransferDescription,
                request.DeviceType);
        }

        private Tuple<TransferStatus, List<Account>> HandleAchPull(AssessTransferRequest request)
        {
            TransferRequestValidation.HandleAchPullValidation(request);

            if (!string.IsNullOrWhiteSpace(request.TransferDescription))
            {
                request.TransferDescription = request.TransferDescription + _customTransactionDescriptionSuffix;
            }

            Core.Domain.Model.Account.BankAccount bankAccount;
            if (String.IsNullOrEmpty(request.TransferRoute.SourceTransferEndPoint.BankAccountReferenceId))
            {
                bankAccount = new Core.Domain.Model.Account.BankAccount()
                {
                    AccountNumber = request.TransferRoute.SourceTransferEndPoint.BankAccount.AccountNumber,
                    RoutingNumber = request.TransferRoute.SourceTransferEndPoint.BankAccount.RoutingNumber,
                    AccountType = request.TransferRoute.SourceTransferEndPoint.BankAccount.AccountType,
                    BankName = request.TransferRoute.SourceTransferEndPoint.BankAccount.BankName,
                    BusinessName = request.TransferRoute.SourceTransferEndPoint.BankAccount.BusinessName,
                    FirstName = request.TransferRoute.SourceTransferEndPoint.BankAccount.FirstName,
                    LastName = request.TransferRoute.SourceTransferEndPoint.BankAccount.LastName
                };
            }
            else
            {
                bankAccount = new Core.Domain.Model.Account.BankAccount()
                {
                    BankAccountReferenceId = request.TransferRoute.SourceTransferEndPoint.BankAccountReferenceId
                };
            }

            return _transferService.TransferAchPull(
                request.TransferIdentifier,
                request.Initiator,
                request.AuthorizationType.ToString(),
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.TransferRoute.RecurringType,
                request.TransferRoute.BankAccountVerificationMethod,
                request.TransferRoute.BankAccountVerificationDate,
                request.TransferRoute.BankAccountAuthorizationDate,
                bankAccount,
                request.VerificationIdentifier,
                request.ProgramCode,
                true,
                request.TransferDescription,
                request.TransferRoute.DeliveryType,
                request.DeviceType,
                request.UserIdentifier);
        }
        private Tuple<TransferStatus, List<Account>> HandleSwipeReload(TransferRequest request)
        {
            TransferRequestValidation.HandleSwipeReloadValidation(request);

            if (request.IsReversal)
            {
                if (_baasConfiguration.IsAllowNegativeBalanceInReversal(request.ProgramCode))
                {
                    return _transferService.TransferSwipeReloadReversalForPLS(
                       request.TransferIdentifier,
                       request.Initiator,
                       request.TransferRoute.TransactionAmount,
                       request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.MerchantName,
                       request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.StoreNumber,
                       request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.City,
                       request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.State,
                       request.TransferRoute.SourceTransferEndPoint.Identifier,
                       request.ProgramCode,
                       true,
                       request.TransferDescription);
                }
                else
                {
                    return _transferService.TransferSwipeReloadReversal(
                        request.TransferIdentifier,
                        request.Initiator,
                        request.TransferRoute.TransactionAmount,
                        request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.MerchantName,
                        request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.StoreNumber,
                        request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.City,
                        request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.State,
                        request.TransferRoute.SourceTransferEndPoint.Identifier,
                        request.ProgramCode,
                        true,
                        request.TransferDescription);
                }
            }

            return _transferService.TransferSwipeReload(
                request.TransferIdentifier,
                request.Initiator,
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.MerchantName,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.StoreNumber,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.City,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.State,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.ProgramCode,
                true,
                request.TransferDescription);
        }

        private Tuple<TransferStatus, List<Account>> HandleECashLoad(TransferRequest request)
        {
            TransferRequestValidation.HandleSwipeReloadValidation(request);

            return _transferService.TransferECashLoad(
                request.TransferIdentifier,
                request.Initiator,
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.MerchantName,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.StoreNumber,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.City,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.State,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.ProgramCode,
                true);
        }

        private Tuple<TransferStatus, List<Account>> HandleECashSend(TransferRequest request)
        {
            TransferRequestValidation.HandleECashSendValidation(request);

            return _transferService.TransferECashSend(
                request.TransferIdentifier,
                request.Initiator,
                request.AuthorizationType,
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.MerchantName,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.StoreNumber,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.City,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.State,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.TransferRoute.TargetTransferEndPoint.TransferEndPointType,
                request.TransferRoute.TargetTransferEndPoint.HandleData?.Handle,
                request.TransferRoute.TargetTransferEndPoint.HandleData?.FirstName,
                request.TransferRoute.TargetTransferEndPoint.HandleData?.LastName,
                request.TransferRoute.TargetTransferEndPoint.HandleData?.UserName,
                request.ProgramCode,
                request.Memo,
                true);
        }

        private Tuple<TransferStatus, List<Account>> HandlePeerPayments(TransferRequest request)
        {
            TransferRequestValidation.HandlePeerPaymentValidation(request);

            return _transferService.PeerPayments(
                request.Initiator,
                request.TransferIdentifier,
                request.AuthorizationType,
                request.Memo,
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.SourceTransferEndPoint.Identifier,
                request.TransferRoute.SourceTransferEndPoint.HandleData?.Handle,
                request.TransferRoute.SourceTransferEndPoint.HandleData?.FirstName,
                request.TransferRoute.SourceTransferEndPoint.HandleData?.LastName,
                request.TransferRoute.SourceTransferEndPoint.HandleData?.UserName,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.TransferRoute.TargetTransferEndPoint.TransferEndPointType,
                request.TransferRoute.TargetTransferEndPoint.HandleData?.Handle,
                request.TransferRoute.TargetTransferEndPoint.HandleData?.FirstName,
                request.TransferRoute.TargetTransferEndPoint.HandleData?.LastName,
                request.TransferRoute.TargetTransferEndPoint.HandleData?.UserName,
                request.ProgramCode,
                true);
        }

        private Tuple<TransferStatus, List<Account>> HandleIFTLoad(TransferRequest request)
        {
            TransferRequestValidation.HandleIFTLoadValidation(request);

            return _transferService.TransferIFTLoad(
                request.Initiator,
                request.TransferIdentifier,
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.SourceTransferEndPoint.Identifier,
                request.TransferRoute?.SourceTransferEndPoint?.CardData?.Cvv,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.ProgramCode,
                true);
        }

        private Tuple<TransferStatus, List<Account>> HandleIFTSend(TransferRequest request)
        {
            TransferRequestValidation.HandleIFTSendValidation(request);

            return _transferService.TransferIFTSend(
                request.Initiator,
                request.TransferIdentifier,
                request.TransferRoute.TransactionAmount,
                request.AuthorizationType,
                request.TransferRoute.SourceTransferEndPoint.Identifier,
                request.TransferRoute?.SourceTransferEndPoint?.CardData?.Cvv,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.TransferRoute.TargetTransferEndPoint.TransferEndPointType,
                request.TransferRoute.TargetTransferEndPoint.HandleData?.Handle,
                request.TransferRoute.TargetTransferEndPoint.HandleData?.FirstName,
                request.TransferRoute.TargetTransferEndPoint.HandleData?.LastName,
                request.TransferRoute.TargetTransferEndPoint.HandleData?.UserName,
                request.ProgramCode,
                request.Memo,
                true,
                request.FraudData);
        }
        private Tuple<TransferStatus, List<Account>> HandleUnLoad(TransferRequest request)
        {
            TransferRequestValidation.HandleUnLoadValidation(request);

            if (request.IsReversal)
                return _transferService.TransferUnLoadReversal(
                    request.TransferIdentifier,
                    request.Initiator,
                    request.TransferRoute.TransactionAmount,
                    request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.MerchantName,
                    request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.StoreNumber,
                    request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.City,
                    request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.State,
                    request.TransferRoute.TargetTransferEndPoint.Identifier,
                    request.ProgramCode,
                    true,
                    request.TransferDescription);

            return _transferService.TransferUnLoad(
                request.TransferIdentifier,
                request.Initiator,
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.MerchantName,
                request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.StoreNumber,
                request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.City,
                request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.State,
                request.TransferRoute.SourceTransferEndPoint.Identifier,
                request.ProgramCode,
                true,
                request.TransferDescription);
        }
        private Tuple<TransferStatus, List<Account>> HandleInitialLoad(TransferRequest request)
        {
            TransferRequestValidation.HandleInitialLoadValidation(request);

            if (request.IsReversal)
                return _transferService.TransferInitialLoadReversal(
                    request.TransferIdentifier,
                    request.Initiator,
                    request.TransferRoute.TransactionAmount,
                    request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.MerchantName,
                    request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.StoreNumber,
                    request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.City,
                    request.TransferRoute.TargetTransferEndPoint.RetailSaleData?.State,
                    request.TransferRoute.SourceTransferEndPoint.Identifier,
                    request.ProgramCode,
                    true,
                    request.TransferDescription);

            return _transferService.TransferInitialLoad(
                request.TransferIdentifier,
                request.Initiator,
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.MerchantName,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.StoreNumber,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.City,
                request.TransferRoute.SourceTransferEndPoint.RetailSaleData?.State,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.ProgramCode,
                true,
                request.TransferDescription);
        }
        private Tuple<TransferStatus, List<Account>> HandleIFTOut(TransferRequest request)
        {
            TransferRequestValidation.HandleIFTOutValidation(request);

            return _transferService.TransferIFTOut(
                request.Initiator,
                request.TransferIdentifier,
                request.TransferRoute.TransactionAmount,
                request.TransferRoute.SourceTransferEndPoint.Identifier,
                request.TransferRoute.TargetTransferEndPoint.Identifier,
                request.TransferRoute?.TargetTransferEndPoint?.CardData?.Cvv,
                request.ProgramCode,
                true);
        }

        //private List<Fee> GetFee(TransferType transferType)
        //{
        //    List<Gd.Bos.Shared.Common.Logic.FeatureLimitsFees.Contract.Limit> limits = _productRepository.GetAllLimitsForProduct(programFundingSource.ProductKey, programFundingSource.ProductTierKey, Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType.AchOut);

        //    return new List<Fee>() { };
        //}


        private List<AccountHolderAssess> GetAccountHolder(IEnumerable<Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolder> accountHolders)
        {
            if (accountHolders == null) return new List<AccountHolderAssess>();

            var result = new List<AccountHolderAssess>();
            foreach (var ah in accountHolders)
            {
                var item = new AccountHolderAssess();
                item.PendingkycGate = ah.AccountHolderCure.ToString();
                item.UserIdentifier = ah.UserIdentifier.ToString();
                item.AccountIdentifier = ah.AccountIdentifier.ToString();
                result.Add(item);
            }

            return result;
        }

        private readonly ITransferService _transferService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IRiskService _riskService;
        private readonly ILimitTypeService _limitTypeService;
        private readonly IBaasConfiguration _baasConfiguration;
    }
}
