﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.Common.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;
using RequestHandler.Core.Domain.Services;
using RequestHandler.Core.Domain.Services.ProspectApi;
using GetAciPackageRequest = RequestHandler.Core.Domain.Services.AciRetailApi.GetAciPackageRequest;
using GetAciPackageResponse = RequestHandler.Core.Domain.Services.AciRetailApi.GetAciPackageResponse;
using RequestHeader = Gd.Bos.Shared.Common.Contract.Message.Request.RequestHeader;

namespace RequestHandler.Logic.Handler
{
    public class EnrollmentTypeByMappingIdentifierHandler : CommandHandlerBase<EnrollmentTypeByMappingIdentifierRequest, EnrollmentTypeByMappingIdentifierResponse>
    {
        private readonly IAciRetailService _aciRetailService;
        private readonly IProspectService _prospectService;

        public EnrollmentTypeByMappingIdentifierHandler(IAciRetailService aciRetailService, IProspectService prospectService)
        {
            _aciRetailService = aciRetailService;
            _prospectService = prospectService;
        }
        public override Task<EnrollmentTypeByMappingIdentifierResponse> Handle(EnrollmentTypeByMappingIdentifierRequest request)
        {
            var mappingIdentifier = request.MappingIdentifier;
            var requestId = request.RequestHeader.RequestId;
            var response = InstanceNewEnrollmentTypeResponse(mappingIdentifier, requestId);

            if (string.IsNullOrEmpty(request.MappingIdentifier))
            {
                response.ResponseHeader = new ResponseHeader()
                {
                    ResponseId = requestId,
                    StatusCode = 400,
                    SubStatusCode = 0,
                    Message = "Mapping Identifier can not be empty"
                };
                return Task.FromResult(response);
            }

            var aciPackageDetails = GetMappingIdentifierDetails(mappingIdentifier, requestId).Result;

            if (aciPackageDetails.ResponseHeader.StatusCode != 0)
            {
                response.ResponseHeader = new ResponseHeader()
                {
                    ResponseId = requestId,
                    StatusCode = 400,
                    SubStatusCode = 5020,
                    Message = "Mapping Identifier is not found"
                };
                return Task.FromResult(response);
            }

            if (string.IsNullOrEmpty(aciPackageDetails.AlternativePan))
            {
                response.ResponseHeader = new ResponseHeader()
                {
                    ResponseId = requestId,
                    StatusCode = 400,
                    SubStatusCode = 5025,
                    Message = "Alternative Pan is missing from Mapping Identifier info"
                };
                return Task.FromResult(response);
            }
            var prospectDetails = GetProspectDetailsByCardProxy(aciPackageDetails.AlternativePan, requestId);

            response.EnrollmentType = prospectDetails.ResponseHeader.StatusCode != 0 ?
                EnrollmentType.CBS : EnrollmentType.CBSDM;
            response.ResponseHeader.Message = "Success";

            return Task.FromResult(response);
        }

        public override void SetDomainContext(EnrollmentTypeByMappingIdentifierRequest request)
        {
            if (!string.IsNullOrEmpty(request.ProgramCode))
                DomainContext.Current.ProgramCode = ProgramCode.FromString(request.ProgramCode);
        }

        public override Task<EnrollmentTypeByMappingIdentifierResponse> VerifyIdentifiers(EnrollmentTypeByMappingIdentifierRequest request)
        {
            return Task.FromResult(new EnrollmentTypeByMappingIdentifierResponse() { ResponseHeader = new ResponseHeader() });
        }

        private async Task<GetAciPackageResponse> GetMappingIdentifierDetails(string mappingIdentifier, Guid requestId)
        {
            var aciPackageResponse = await _aciRetailService.GetPackageDetailsById(new GetAciPackageRequest()
            {
                ExternalId = mappingIdentifier,
                RequestHeader = new RequestHeader()
                {
                    RequestId = requestId
                }
            });


            return aciPackageResponse;
        }

        private GetProspectDetailsResponse GetProspectDetailsByCardProxy(string cardProxy, Guid requestId)
        {
            var prospectDetailsResponse = new GetProspectDetailsResponse();

            var request = new GetProspectDetailsRequest()
            {
                CardProxy = cardProxy,
                Header = new Gd.Bos.Shared.Common.Dcpp.Contract.Message.RequestHeader { RequestId = requestId }
            };
            try
            {
                prospectDetailsResponse = _prospectService.GetProspectDetails(request);
            }
            catch
            {
                prospectDetailsResponse.ResponseHeader = new ProspectApiResponseHeader()
                {
                    ResponseId = requestId.ToString(),
                    StatusCode = 400,
                    StatusMessage = "Card Proxy not found"
                };
            }

            return prospectDetailsResponse;

        }

        private EnrollmentTypeByMappingIdentifierResponse InstanceNewEnrollmentTypeResponse(string mappingIdentifier, Guid requestId)
        {
            return new EnrollmentTypeByMappingIdentifierResponse()
            {
                MappingIdentifier = mappingIdentifier,
                EnrollmentType = EnrollmentType.Invalid,
                ResponseHeader = new ResponseHeader()
                {
                    ResponseId = requestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Details = "",
                    Message = ""
                }
            };
        }
    }
}