﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Interest;
using Gd.Bos.RequestHandler.Core.Domain.Model.ProgramFunding;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetPurseInterestRateTiersHandler : CommandHandlerBase<GetPurseInterestRateTiersRequest, GetPurseInterestRateTiersResponse>
    {
        private readonly IAccountDataAccess _accountDataAccess;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IInterestRateRepository _interestRateRepository;
        private readonly IProgramFundingRepository _programFundingRepository;

        public GetPurseInterestRateTiersHandler(IAccountDataAccess accountDataAccess, IValidateIdentifier validateIdentifier, IInterestRateRepository interestRateRepository, IProgramFundingRepository programFundingRepository)
        {
            _accountDataAccess = accountDataAccess;
            _validateIdentifier = validateIdentifier;
            _interestRateRepository = interestRateRepository;
            _programFundingRepository = programFundingRepository;
        }

        public override void SetDomainContext(GetPurseInterestRateTiersRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetPurseInterestRateTiersResponse> VerifyIdentifiers(GetPurseInterestRateTiersRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetPurseInterestRateTiersResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetPurseInterestRateTiersResponse>(e, request));
            }
        }

        public override Task<GetPurseInterestRateTiersResponse> Handle(GetPurseInterestRateTiersRequest request)
        {
            try
            {
                var purse = _accountDataAccess.GetPurses(request.AccountIdentifier, request.ProgramCode)?.Purses?.FirstOrDefault(a => a.PurseIdentifier.Equals(request.PurseIdentifier, StringComparison.InvariantCultureIgnoreCase));
                if (purse == null)
                {
                    throw new ValidationException(10, 0, "The purse does not exist.");
                }

                var currentPurseInterests = _interestRateRepository.GetAccountBalanceInterests(request.AccountIdentifier)
                    .Where(a => a.AccountBalanceIdentifier.Equals(request.PurseIdentifier, StringComparison.InvariantCultureIgnoreCase) && a.IsActive)
                    .ToList();

                if (!currentPurseInterests.Any())
                {
                    throw new ValidationException(10, 0, "The purseInterestRateTier not found.");
                }

                var productInfo = _programFundingRepository.GetProgramInfoByAccountIdentifier(AccountIdentifier.FromString(request.AccountIdentifier));
                var productTiers = _interestRateRepository.GetProductInterestTierByProductKey(productInfo.ProductKey);
                var programInterestTierMetaData =
                    _interestRateRepository.GetProductInterestTierInfoByProgramCode(request.ProgramCode);

                var purseInterestRates = new List<PurseInterestRateTier>();
                foreach (var accountBalanceInterest in currentPurseInterests)
                {
                    var tiers = productTiers.Where(p => p.ProductInterestTierKey == accountBalanceInterest.ProductInterestTierKey)
                        .OrderBy(p => p.CreateDate)
                        .ToList();

                    if (!tiers.Any())
                    {
                        continue;
                    }

                    foreach (var tier in tiers)
                    {
                        purseInterestRates.Add(new PurseInterestRateTier()
                        {
                            PurseIdentifier = purse.PurseIdentifier,
                            PurseType = purse.PurseType,
                            AccountBalanceInterestIdentifier = accountBalanceInterest.AccountBalanceInterestIdentifier.ToString(),
                            InterestRateTier = programInterestTierMetaData.Tiers.FirstOrDefault(p => p.Key == accountBalanceInterest.InterestRateTierKey)!.Name,
                            InterestYieldStartDate = accountBalanceInterest.InterestYieldStartDate.Value.ToString("yyyy-MM-dd"),
                            InterestYieldEndDate = accountBalanceInterest.InterestYieldEndDate?.ToString("yyyy-MM-dd"),
                            APY = tier.APY,
                            InterestRate = tier.InterestRate
                        });
                    }
                }

                var getPurseInterestRateResponse = new GetPurseInterestRateTiersResponse()
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                    PurseInterestRateTiers = purseInterestRates.ToArray()
                };

                return Task.FromResult(getPurseInterestRateResponse);

            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetPurseInterestRateTiersResponse>(e, request));
            }
        }
    }
}