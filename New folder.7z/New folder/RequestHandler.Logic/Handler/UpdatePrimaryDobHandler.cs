﻿using System.Threading.Tasks;
using System;
using System.Linq;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Logic.Service;
using System.Runtime.CompilerServices;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Logic.Exceptions;

[assembly: InternalsVisibleTo("Tests")]
namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class UpdatePrimaryDobHandler : CommandHandlerBase<UpdatePrimaryDobRequest, UpdatePrimaryDobResponse>
    {
        private readonly IUserService _userService;
        private readonly IValidateIdentifier _validateIdentifier;

        public UpdatePrimaryDobHandler(IUserService userService,
            IValidateIdentifier validateIdentifier)
        {
            _userService = userService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(UpdatePrimaryDobRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
            {
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            }
        }

        public override Task<UpdatePrimaryDobResponse> VerifyIdentifiers(UpdatePrimaryDobRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier,
                    DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidateConsumerProfileIdentifier(DomainContext.Current.AccountIdentifier,
                    DomainContext.Current.UserIdentifier);
                return Task.FromResult(new UpdatePrimaryDobResponse()
                {
                    ResponseHeader = new ResponseHeader()
                });
            }
            catch (Exception ex)
            {
                return Task.FromResult(ex.HandleException<UpdatePrimaryDobResponse>(ex, request));
            }
        }

        public override Task<UpdatePrimaryDobResponse> Handle(UpdatePrimaryDobRequest request)
        {
            var userProfile = _userService
                .GetUser(AccountIdentifier.FromGuid(Guid.Parse(request.AccountIdentifier)), null)
                ?.OrderBy(x => x.ConsumerProfileTypeKey).FirstOrDefault(x => x.IsPrimaryAccountHolder);

            if (userProfile == null)
            {
                throw new UpdateUserProfileException("No primary account holder info identified.");
            }

            _validateIdentifier.ValidateDOB(request.DateOfBirth);

            _userService.UpdateEncryptedDOB(userProfile.UserIdentifier, request.DateOfBirth);

            var response = new UpdatePrimaryDobResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                }
            };

            return Task.FromResult(response);
        }
    }
}
