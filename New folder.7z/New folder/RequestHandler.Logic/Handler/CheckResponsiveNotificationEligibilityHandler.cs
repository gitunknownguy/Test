﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Enums;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Services.CareSharedApi;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using Gd.Bos.Shared.Common.Messaging.Logic;
using NLog;
using RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Services.Core;
using Gd.Bos.Shared.Common.Core.Common.Enum;
using AccountStatus = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountStatus;
using AccountHolderCure = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolderCure;
using GetAMMRuleRequest = Gd.Bos.Shared.Common.UtilityCoreApi.Contract.Message.Request.GetAMMRuleRequest;
using AMMRuleStatus = Gd.Bos.Shared.Common.UtilityCoreApi.Contract.Enum.AMMRuleStatus;
using AMMTransferType = Gd.Bos.Shared.Common.UtilityCoreApi.Contract.Enum.AMMTransferType;
using ProgramCode = Gd.Bos.RequestHandler.Core.Domain.Model.ProgramCode;
using RequestHandlerException = Gd.Bos.RequestHandler.Core.Infrastructure.RequestHandlerException;

namespace RequestHandler.Logic.Handler
{
    public class CheckResponsiveNotificationEligibilityHandler : CommandHandlerBase<CheckResponsiveNotificationEligibilityRequest, CheckResponsiveNotificationEligibilityResponse>
    {

        private readonly IUserMessageService _userMessageService;

        public CheckResponsiveNotificationEligibilityHandler(IUserMessageService userMessageService)
        {
            _userMessageService = userMessageService;
        }

        public override void SetDomainContext(CheckResponsiveNotificationEligibilityRequest request)
        {
            DomainContext.Current.AccountIdentifier = request?.AccountIdentifier;
        }

        public override Task<CheckResponsiveNotificationEligibilityResponse> VerifyIdentifiers(CheckResponsiveNotificationEligibilityRequest request)
        {
            return Task.FromResult(new CheckResponsiveNotificationEligibilityResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override async Task<CheckResponsiveNotificationEligibilityResponse> Handle(CheckResponsiveNotificationEligibilityRequest request)
        {

            try
            {
                switch (request.NotificationTypeKey)
                {
                    case (int)CnNotificationType.PaymentPastDue:
                        return _userMessageService.CheckQuickPaymentEligibility(request.ProgramCode,
                            request.AccountIdentifier, request.RequestHeader?.RequestId ?? Guid.NewGuid(), false).Item1;
                    default:
                        throw new Exception($"Notification type {request.NotificationTypeKey} is not supported.");
                }

            }
            catch (Exception e)
            {
                var result = e.HandleException<CheckResponsiveNotificationEligibilityResponse>(e, request);
                if (result != null)
                {
                    result.IsEligibile = false;
                }
                return result;
            }
        }


    }
}
