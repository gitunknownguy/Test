﻿using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using NLog;
using VaultSharp.V1.SystemBackend.Enterprise;
using Gd.Bos.RequestHandler.Logic.Extension;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class UpdateAccountBalanceHandler : CommandHandlerBase<UpdateAccountBalanceRequest, UpdateAccountBalanceResponse>
    {
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        private readonly IAccountBalanceService _accountBalanceService;

        public UpdateAccountBalanceHandler(IAccountBalanceService accountBalanceService)
        {
            _accountBalanceService = accountBalanceService;
        }

        public override void SetDomainContext(UpdateAccountBalanceRequest request)
        {
        }

        public override Task<UpdateAccountBalanceResponse> VerifyIdentifiers(UpdateAccountBalanceRequest request)
        {
            return Task.FromResult(new UpdateAccountBalanceResponse { ResponseHeader = new ResponseHeader() });
        }

        public override async Task<UpdateAccountBalanceResponse> Handle(UpdateAccountBalanceRequest request)
        {
            try
            {
                if (request == null)
                {
                    var e = new ArgumentNullException(nameof(request));
                    return e.HandleException<UpdateAccountBalanceResponse>(e, new UpdateAccountBalanceRequest { RequestHeader = new RequestHeader() });
                }

                if (string.IsNullOrWhiteSpace(request.AccountExternalId))
                {
                    _logger.Warn("UpdateAccountBalanceHandler: No AccountExternalId specified. UpdateAccountBalance not executed.");

                    return new UpdateAccountBalanceResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            StatusCode = 400,
                            SubStatusCode = 0,
                            Message = "Fail"
                        }
                    };
                }

                return HandleUpdateAccountBalance(request);
            }
            catch (Exception e)
            {
                return e.HandleException<UpdateAccountBalanceResponse>(e, request);
            }
        }

        private UpdateAccountBalanceResponse HandleUpdateAccountBalance(UpdateAccountBalanceRequest request)
        {
            var result = new UpdateAccountBalanceResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                }
            };

            var balances =
                _accountBalanceService.GetAccountBalancesByAciExternalAccountIdentifier(request.AccountExternalId);

            if (!balances.Any())
            {
                var message = $"No balances found for AccountExternalId ${request.AccountExternalId}.";

                _logger.Warn(message);

                result.ResponseHeader.StatusCode = 400;
                result.ResponseHeader.SubStatusCode = 0;
                result.ResponseHeader.Message = message;

                return result;
            }

            var balance = balances.First();

            if (!Configuration.Current.EnableUpdateAccountBalance)
            {
                var wouldUpdate = request.AvailableBalance != balance.AvailableBalance &&
                                  request.AvailableBalanceAsOfDate > balance.AvailableBalanceAsOfDate &&
                                  request.LedgerBalance != balance.CurrentBalance &&
                                  request.LedgerBalanceAsOfDate > balance.CurrentBalanceAsOfDate;
                _logger.Info($"UpdateAccountBalanceHandler - Update: {wouldUpdate}\r\nRequest: {request.AvailableBalance} available as of {request.AvailableBalanceAsOfDate} and {request.LedgerBalance} ledger as of {request.LedgerBalanceAsOfDate}\r\nDatabase: {balance.AvailableBalance} available as of {balance.AvailableBalanceAsOfDate} and {balance.CurrentBalance} ledger as of {balance.CurrentBalanceAsOfDate}");

                return result;
            }

            _accountBalanceService.UpdateAccountBalanceForAci(
                balance.AccountBalanceIdentifier.ToGuid(),
                request.AvailableBalance,
                request.AvailableBalanceAsOfDate,
                request.LedgerBalance,
                request.LedgerBalanceAsOfDate);

            return result;
        }
    }
}
