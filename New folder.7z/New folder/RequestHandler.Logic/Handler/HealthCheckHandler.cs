﻿using System.Diagnostics;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Logic.Queue;
using RequestHandler.Core.Domain.Services.AzureServiceBus;

namespace Gd.Bos.RequestHandler.Logic.Handler;

public class HealthCheckHandler(IServiceBusNotificationPublisher serviceBusNotificationPublisher)
    : CommandHandlerBase<HealthCheckRequest, HealthCheckResponse>
{
    public override void SetDomainContext(HealthCheckRequest request)
    {
    }

    public override Task<HealthCheckResponse> VerifyIdentifiers(HealthCheckRequest request) =>
        Task.FromResult(new HealthCheckResponse { ResponseHeader = new ResponseHeader() });


    public override async Task<HealthCheckResponse> Handle(HealthCheckRequest request)
    {
        Stopwatch sw = Stopwatch.StartNew();

        await serviceBusNotificationPublisher.PublishHealthCheckMessage("q.tokenmanagementservicehandler");

        return
            new HealthCheckResponse
            {
                ResponseHeader = new ResponseHeader { StatusCode = 0, SubStatusCode = 0, Message = "Success" },
                HealthCheck = new Shared.Common.Core.CoreApi.Contract.Data.HealthCheck
                {
                    ServiceName = "RequestHandler",
                    Status = "OK",
                    TotalTime = sw.Elapsed.TotalMilliseconds.ToString()
                }
            };
    }
}

//namespace Gd.Bos.RequestHandler.Logic.Handler
//{
//    public class HealthCheckHandler : IHandler<HealthCheckResponse, HealthCheckRequest>
//    {
//        private readonly IDcppApiAdapter _dcppApiAdapter;
//        private readonly IRiskApiAdapter _riskApiAdapter;

//        public HealthCheckHandler(IDcppApiAdapter dcppApiAdapter, IRiskApiAdapter riskApiAdapter)
//        {
//            _dcppApiAdapter = dcppApiAdapter;
//            _riskApiAdapter = riskApiAdapter;
//        }

//        HealthCheckResponse IHandler<HealthCheckResponse>.Handle(BaseRequest request)
//        {
//            if (!(request is HealthCheckRequest))
//                throw new InvalidOperationException();
//            return Handle((HealthCheckRequest)request);
//        }

//        HealthCheckResponse IHandler<HealthCheckResponse, HealthCheckRequest>.Handle(HealthCheckRequest request)
//        {
//            return Handle(request);
//        }

//        public HealthCheckResponse Handle(HealthCheckRequest request)
//        {
//            Stopwatch totalTime = Stopwatch.StartNew();
//            Stopwatch externalTime = Stopwatch.StartNew();

//            var dcppHealthCheck = GetDcppHealthCheck();

//            double dcppTime = externalTime.Elapsed.TotalMilliseconds;

//            externalTime.Restart();

//            var riskHealthCheck = GetRiskHealthCheck();

//            double riskTime = externalTime.Elapsed.TotalMilliseconds;

//            externalTime.Stop();

//            var response = new HealthCheckResponse
//            {
//                ResponseHeader = new ResponseHeader
//                {
//                    StatusCode = "200"
//                },
//                HealthCheck = new HealthCheck
//                {
//                    ServiceName = "RequestHandler",
//                    Status = "OK",
//                    TotalTime = totalTime.Elapsed.TotalMilliseconds.ToString(),
//                    WaitTime = new Dictionary<string, string>()
//                    {
//                        { "Dcpp", dcppTime.ToString() },
//                        { "Risk", riskTime.ToString() }
//                    },
//                    Dependencies = new List<HealthCheck>()
//                    {
//                        dcppHealthCheck,
//                        riskHealthCheck
//                    }
//                }
//            };
//            return response;
//        }

//        private HealthCheck GetDcppHealthCheck()
//        {
//            Gd.Bos.Dcpp.Contract.Message.HealthCheckRequest request = new Gd.Bos.Dcpp.Contract.Message.HealthCheckRequest
//            {
//                Header = new Gd.Bos.Dcpp.Contract.Message.RequestHeader
//                {
//                    RequestId = OptionsContext.Current.GetGuid("RequestId", Guid.NewGuid())
//                }
//            };

//            Gd.Bos.Dcpp.Contract.Message.HealthCheckResponse response = null;
//            string exceptionMessage = null;

//            try
//            {
//                response = _dcppApiAdapter.HealthCheck(request);
//            }
//            catch(Exception e)
//            {
//                exceptionMessage = e.Message;
//            }

//            HealthCheck returnValue = new HealthCheck { ServiceName = "Dcpp" };

//            if (response != null && response.Header.StatusCode == "200")
//            {
//                returnValue = Convert(response.HealthCheck);
//            }
//            else if(response == null)
//            {
//                if (exceptionMessage != null)
//                    returnValue.Status = "Exception: " + exceptionMessage;
//                else
//                    returnValue.Status = "Null";
//            }
//            else if (response.Header.StatusCode == "503")
//            {
//                returnValue.Status = "No Response/Timeout";
//            }
//            else
//            {
//                returnValue.Status = "Error Response: " + response.Header.StatusCode + ", " + response.Header.ErrorInfo?.Message;
//            }

//            return returnValue;
//        }

//        private HealthCheck Convert(Gd.Bos.Dcpp.Contract.Data.HealthCheck dcppHealthCheck)
//        {
//            HealthCheck returnValue = new HealthCheck
//            {
//                ServiceName = dcppHealthCheck.ServiceName,
//                Status = dcppHealthCheck.Status,
//                TotalTime = dcppHealthCheck.TotalTime,
//                WaitTime = dcppHealthCheck.WaitTime
//            };

//            if(dcppHealthCheck.Dependencies != null)
//            {
//                var dependencies = new List<HealthCheck>();

//                foreach (var currDcppDependency in dcppHealthCheck.Dependencies)
//                    dependencies.Add(Convert(currDcppDependency));

//                returnValue.Dependencies = dependencies;
//            }

//            return returnValue;
//        }

//        private HealthCheck GetRiskHealthCheck()
//        {
//            string pingResponse = null;
//            string exceptionMessage = null;

//            try
//            {
//                pingResponse = _riskApiAdapter.Ping();
//            }
//            catch (Exception e)
//            {
//                exceptionMessage = e.Message;
//            }

//            HealthCheck returnValue = new HealthCheck { ServiceName = "Risk" };

//            if (pingResponse == null)
//            {
//                if (exceptionMessage != null)
//                    returnValue.Status = "Exception: " + exceptionMessage;
//                else
//                    returnValue.Status = "Null";
//            }
//            else if (pingResponse == "Ping Successful")
//                returnValue.Status = "OK";
//            else
//                returnValue.Status = "Unexpected Response: " + pingResponse;

//            return returnValue;
//        }
//    }
//}
