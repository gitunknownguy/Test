﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Application;
using System.Collections.Generic;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetAllFeaturesHandler : CommandHandlerBase<GetAllFeaturesRequest, GetAllFeaturesResponse>
    {

        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IFeatureService _featureService;
        public GetAllFeaturesHandler(IValidateIdentifier validateIdentifier, IFeatureService featureService)
        {
            _validateIdentifier = validateIdentifier;
            _featureService = featureService;
        }

        public override void SetDomainContext(GetAllFeaturesRequest request)
        {
            DomainContext.Current.ProgramCode = ProgramCode.FromString(request.ProgramCode);
        }

        public override Task<GetAllFeaturesResponse> VerifyIdentifiers(GetAllFeaturesRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProduct(DomainContext.Current.ProgramCode, ProductCode.FromString(request.ProductCode));
                return Task.FromResult(new GetAllFeaturesResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetAllFeaturesResponse>(e, request));
            }
        }

        public override Task<GetAllFeaturesResponse> Handle(GetAllFeaturesRequest request)
        {
            try
            {
                var allFeatureData = new List<FeatureInfo>(150);
                var productInfo = _featureService.GetProductInfo(request.ProductCode, request.ProgramCode);
                var vipProductFeatureGroups = _featureService.GetVipProductFeatureGroupsByProduct(productInfo.ProductKey);
                var standardProductFeatureGroups = productInfo.ProductTiers.SelectMany(it => it.Features).ToList();
                var allFeatures = _featureService.GetAllFeatures();

                foreach (var feature in allFeatures)
                {
                    var isValidFeature =
                        standardProductFeatureGroups.Exists(it => (short)it.FeatureType == feature.FeatureTypeKey)
                        || vipProductFeatureGroups.Exists(it => it.FeatureKey == feature.FeatureTypeKey);
                    var featureData = new FeatureInfo()
                    {
                        Feature = feature.FeatureType,
                        Category = feature.Category,
                        IsValid = isValidFeature,
                        IsFeeType = false,
                    };
                    allFeatureData.Add(featureData);
                }

                var feeInfos = productInfo.ProductTiers.SelectMany(it => it.Fees).Select(it => it.FeeType)
                    .Distinct().Select(it => new FeatureInfo
                    {
                        Feature = it.ToString(),
                        IsValid = true,
                        IsFeeType = true
                    });

                allFeatureData.AddRange(feeInfos);

                var response = new GetAllFeaturesResponse
                {
                    Features = allFeatureData,
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    }
                };

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetAllFeaturesResponse>(e, request));
            }
        }
    }
}