﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;

namespace RequestHandler.Logic.Handler
{
    public class GetCheckDetailByTransactionHandler : CommandHandlerBase<GetCheckDetailByTransactionRequest, GetCheckDetailByTransactionResponse>
    {
        private readonly ITransactionService _transactionService;
        private readonly IValidateIdentifier _validateIdentifier;

        public GetCheckDetailByTransactionHandler(IValidateIdentifier validateIdentifier, ITransactionService transactionService)
        {
            _validateIdentifier = validateIdentifier;
            _transactionService = transactionService;

        }

        
        public override void SetDomainContext(GetCheckDetailByTransactionRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        
        public override Task<GetCheckDetailByTransactionResponse> VerifyIdentifiers(GetCheckDetailByTransactionRequest request)
        {
            _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
            _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 4, 105);

            return Task.FromResult(new GetCheckDetailByTransactionResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<GetCheckDetailByTransactionResponse> Handle(GetCheckDetailByTransactionRequest request)
        {

            try
            {
                var result = _transactionService.GetCheckDetailByTransactionIdentifier(request);

                return Task.FromResult(result);
            }
            catch (Exception ex)
            {
                return Task.FromResult(ex.HandleException<GetCheckDetailByTransactionResponse>(ex, request));
            }
        }
    }
}
