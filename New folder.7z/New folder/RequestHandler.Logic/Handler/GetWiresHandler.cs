﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using NLog;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetWiresHandler : CommandHandlerBase<GetWiresRequest, GetWiresResponse>
    {
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        private readonly ITransferService _transferService;


        public GetWiresHandler(ITransferService transferService)
        {
            _transferService = transferService;
        }
        public override void SetDomainContext(GetWiresRequest request)
        {
            //
        }

        public override Task<GetWiresResponse> VerifyIdentifiers(GetWiresRequest request)
        {
            return Task.FromResult(new GetWiresResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<GetWiresResponse> Handle(GetWiresRequest request)
        {
            GetWiresResponse response;

            try
            {
                _logger.Info($"Start to get Wires for request {request.RequestHeader?.RequestId}");
                response = _transferService.GetWires(request);
            }
            catch (Exception e)
            {
                _logger.Error(e, $"Error occured for request {request.RequestHeader?.RequestId}: Error : {e.Message}");
                response = e.HandleException<GetWiresResponse>(e, request);
            }

            return Task.FromResult(response);
        }
    }
}
