﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.InterestRate;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RequestHandler.Logic.Handler
{
    public class UpdateProductInterestTierHandler : CommandHandlerBase<UpdateProductInterestTierRequest, UpdateProductInterestTierResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IInterestRateService _interestRateService;

        public UpdateProductInterestTierHandler(IValidateIdentifier validateIdentifier,
             IInterestRateService interestRateService)
        {
            _validateIdentifier = validateIdentifier;
            _interestRateService = interestRateService;
        }

        public override void SetDomainContext(UpdateProductInterestTierRequest request)
        {
        }

        public override Task<UpdateProductInterestTierResponse> VerifyIdentifiers(UpdateProductInterestTierRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.ProgramCode);
                return Task.FromResult(new UpdateProductInterestTierResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpdateProductInterestTierResponse>(e, request));
            }

        }

        public override Task<UpdateProductInterestTierResponse> Handle(UpdateProductInterestTierRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.ProgramCode))
                    throw new ArgumentNullException($"ProgramCode: Program Code cannot be null or empty.");

                var response = new UpdateProductInterestTierResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Error"
                    },
                };

                var dbUpdated =
                    _interestRateService.UpdateProductInterestTier(request);

                if (!dbUpdated)
                {
                    return Task.FromResult(response);
                }

                response.ResponseHeader.Message = "Success";

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpdateProductInterestTierResponse>(e, request));
            }
        }
    }
}
