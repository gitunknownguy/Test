﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers.Exceptions;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class AchNocCallbackHandler : CommandHandlerBase<AchNocCallbackRequest, AchNocCallbackResponse>
    {
        public AchNocCallbackHandler(ITransferService transferService, IValidateIdentifier validateIdentifier)
        {
            _transferService = transferService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(AchNocCallbackRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<AchNocCallbackResponse> VerifyIdentifiers(AchNocCallbackRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new AchNocCallbackResponse() { ResponseHeader = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AchNocCallbackResponse>(e, request));
            }
        }

        public override Task<AchNocCallbackResponse> Handle(AchNocCallbackRequest request)
        {
            try
            {
                var achTransferType = new List<string> { "achpull", "achout" };
                if (!(achTransferType.Contains(request.AchTransferType?.ToLower())))
                {
                    throw new AchNocCallbackException("Invalid Ach Transfer type.");
                }

                var validNocCodes = new List<string>() { "C01", "C02", "C03", "C06", "C07" };
                if (!validNocCodes.Contains(request.NocCode.Trim().ToUpper()))
                    throw new AchNocCallbackException("Invalid NOC Code.");

                if (request.RequestHeader.RequestId == Guid.Empty)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId, $"{nameof(request)}.RequestHeader.RequestId must be specified");
                }

                _transferService.SendAchNOCPn(request);

                var response = new AchNocCallbackResponse
                {
                    ResponseHeader = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                };

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AchNocCallbackResponse>(e, request));
            }
        }

        private readonly ITransferService _transferService;
        private readonly IValidateIdentifier _validateIdentifier;

    }
}
