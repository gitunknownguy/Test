﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.BillPay;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Logic.Extension;
using System.Diagnostics.CodeAnalysis;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Domain.Services.BillPay.Mappers;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class BillPayUpdatePaymentHandler : CommandHandlerBase<BillPayUpdatePaymentRequest, BillPayUpdatePaymentResponse>
    {
        private readonly IBillPayService _billPayService;
        private readonly IValidateIdentifier _validateIdentifier;

        public BillPayUpdatePaymentHandler(IBillPayService billPayService, IValidateIdentifier validateIdentifier)
        {
            _billPayService = billPayService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(BillPayUpdatePaymentRequest request)
        {
            if (!String.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<BillPayUpdatePaymentResponse> VerifyIdentifiers(BillPayUpdatePaymentRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 3, 105);
                return Task.FromResult(new BillPayUpdatePaymentResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<BillPayUpdatePaymentResponse>(e, request));
            }
        }

        public override Task<BillPayUpdatePaymentResponse> Handle(BillPayUpdatePaymentRequest request)
        {
            try
            {
                var response = _billPayService.UpdatePayment(request.ToGssModel());

                if (response == null)
                    throw new RequestHandlerException(503, 0,
                        $"Unable to Update Payment for account {request.AccountIdentifier}");

                var coreResponse = response.ToCoreModel();
                coreResponse.ResponseHeader.ResponseId = request.RequestHeader.RequestId;

                return Task.FromResult(coreResponse);
            }
            catch (Exception ex)
            {
                return Task.FromResult(ex.HandleException<BillPayUpdatePaymentResponse>(ex, request));
            }
        }
    }
}
