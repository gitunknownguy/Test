﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application.UpgradeAccount;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.UtilityCoreApi.Contract.Enum;
using Newtonsoft.Json;
using NLog;
using RequestHandler.Core.Application;
using RequestHandler.Core.Domain.Model.Inventory;
using RequestHandler.Core.Domain.Model.User;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class AccountHandler : CommandHandlerBase<GetAccountRequest, GetAccountResponse>
    {
        private readonly IAccountDataAccess _accountDataAccess;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IUserRepository _userRepository;
        private readonly IInstantIssueCardInventoryRepository _instantIssueCardInventoryRepository;
        private readonly IContactChangeEligibilityService _contactChangeEligibilityService;
        private readonly IUpgradeAccountService _upgradeAccountService;
        private readonly IProductRepository _productRepository;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        public AccountHandler(IAccountDataAccess accountDataAccess, IValidateIdentifier validateIdentifier, IUserRepository userRepository,
            IContactChangeEligibilityService contactChangeEligibilityService, IInstantIssueCardInventoryRepository instantIssueCardInventoryRepository,
            IUpgradeAccountService upgradeAccountService, IProductRepository productRepository)
        {
            _accountDataAccess = accountDataAccess;
            _validateIdentifier = validateIdentifier;
            _userRepository = userRepository;
            _contactChangeEligibilityService = contactChangeEligibilityService;
            _instantIssueCardInventoryRepository = instantIssueCardInventoryRepository;
            _upgradeAccountService = upgradeAccountService;
            _productRepository = productRepository;
        }

        public override void SetDomainContext(GetAccountRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetAccountResponse> VerifyIdentifiers(GetAccountRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetAccountResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetAccountResponse>(e, request));
            }
        }

        public override Task<GetAccountResponse> Handle(GetAccountRequest request)
        {
            var stopwatch = Stopwatch.StartNew();
            try
            {
                var getAccountResponse = new GetAccountResponse();

                getAccountResponse = _accountDataAccess.GetAccountByAccountIdentifier(request.AccountIdentifier,
                    request.ProgramCode, request.IncludePrivatePaymentInstrumentData);


                if (getAccountResponse == null)
                {
                    throw new AccountNotFoundException();
                }
                var product = _productRepository.GetByProductCode(ProductCode.FromString(getAccountResponse.Account.ProductCode));
                getAccountResponse.Account.BankName = product?.BankName;

                var productTierKey =
                    _accountDataAccess.GetAccountProductTierKey(request.AccountIdentifier, request.ProgramCode);
                var productTierInfo = _upgradeAccountService.GetProductTierByProgramCode(request.ProgramCode);
                var targetUserType = productTierInfo.ProductTiers.FirstOrDefault(x =>
                    x.ProductTierKey == productTierKey && x.ProductTierAttributeKey == 33 &&
                    x.ProductTierAttribute == "TargetUserType")?.Value;
                getAccountResponse.Account.TargetUserType = targetUserType;

                var accountHolders = getAccountResponse.Account?.AccountHolders;
                if (accountHolders != null && accountHolders.Count > 0)
                {
                    var userIdentifier = accountHolders[0].User?.UserIdentifier;
                    if (!string.IsNullOrEmpty(userIdentifier))
                    {
                        var prospectInfo = _userRepository.GetConsumerProfileExtension(userIdentifier)
                        .FirstOrDefault(c =>
                        c.ConsumerProfileExtensionAttributeKey ==
                        (int)ConsumerProfileExtensionAttribute.ProspectProfile);
                        if (prospectInfo != null)
                        {
                            var prospectId = JsonConvert
                            .DeserializeObject<ProspectProfile>(prospectInfo.ConsumerProfileExtensionAttributeValue)
                            .ProspectIdentifier;
                            getAccountResponse.ProspectIdentifier = prospectId;
                        }
                    }
                }

                if (request.ProgramCode.Equals("credibly", StringComparison.OrdinalIgnoreCase))
                {
                    var individualAccountHolderCure = getAccountResponse.Account?.AccountHolders?
                        .Where(item => item.User.IsPrimaryAccountHolder)?.FirstOrDefault()?.User.KycStateData.PendingKycGate;

                    if (individualAccountHolderCure != null)
                    {
                        if ((individualAccountHolderCure.Equals("Healthy", StringComparison.OrdinalIgnoreCase) || individualAccountHolderCure.Equals("Manual", StringComparison.OrdinalIgnoreCase))
                            && getAccountResponse.Account.AccountHolders.Any(item => item.User.KycStateData.PendingKycGate == Core.Domain.Model.Account.AccountHolderCure.IDV.ToString().ToLower()))
                        {
                            getAccountResponse.Account.AccountHolders.FirstOrDefault(d => d.User.IsPrimaryAccountHolder).User.KycStateData.PendingKycGate = "idv";
                            getAccountResponse.Account.AccountHolders.FirstOrDefault(d => d.User.IsPrimaryAccountHolder).User.KycStateData.KycStatus = "failed";
                        }

                        if (getAccountResponse.Account.AccountHolders.Any(item => item.User.KycStateData.PendingKycGate == Core.Domain.Model.Account.AccountHolderCure.None.ToString().ToLower()))
                        {
                            getAccountResponse.Account.AccountHolders.FirstOrDefault(d => d.User.IsPrimaryAccountHolder).User.KycStateData.PendingKycGate = "none";
                            getAccountResponse.Account.AccountHolders.FirstOrDefault(d => d.User.IsPrimaryAccountHolder).User.KycStateData.KycStatus = "failed";
                        }
                    }

                    getAccountResponse.Account?.AccountHolders?.RemoveAll(item => item.User.IsPrimaryAccountHolder == false);
                }

                getAccountResponse.ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                };

                if (_contactChangeEligibilityService.ProgramCodeEligibleForContactChangeRestrictions(request.ProgramCode))
                {
                    getAccountResponse.Account.AccountEligibility = new AccountEligibility()
                    {
                        //By default, the partner can change Address, Email and phone. Care can only update Address
                        ContactChangeEligibility = new ContactChangeEligibility()
                        {
                            Address = new List<string>() { "partner", "care" },
                            Email = new List<string>() { "partner" },
                            Phone = new List<string>() { "partner" }
                        }
                    };

                    if (_contactChangeEligibilityService.MailedCardActivated(request.AccountIdentifier, getAccountResponse.Account.ProductCode, true, getAccountResponse.Account.ProductTierKey))
                    {
                        //Only once there is an activated perso card, should the customer be allowed to update PII
                        getAccountResponse.Account.AccountEligibility.ContactChangeEligibility.Address.Add("customer");
                        getAccountResponse.Account.AccountEligibility.ContactChangeEligibility.Email.Add("customer");
                        getAccountResponse.Account.AccountEligibility.ContactChangeEligibility.Phone.Add("customer");
                    }
                }
                //Only for GPR products check if account is an Instant Issue
                if (getAccountResponse.Account.ProductCode == "51711" && !string.IsNullOrEmpty(_instantIssueCardInventoryRepository.GetInstantIssueCardInventoryByAccountIdentifier(new Guid(getAccountResponse.Account.AccountIdentifier))))
                {
                    getAccountResponse.Account.InstantIssue = true;
                }

                getAccountResponse.Account.UpgradeKycStateData = _upgradeAccountService.GetUpgradeKycStateData(
                    request.ProgramCode,
                    getAccountResponse.Account.ProductCode,
                    getAccountResponse.Account.AccountIdentifier,
                    getAccountResponse.Account.UpgradeKycStateData);

                return Task.FromResult(getAccountResponse);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetAccountResponse>(e, request));
            }
            finally
            {
                stopwatch.Stop();
                _logger.Info($"AccountHandler.Handle method executed in {stopwatch.ElapsedMilliseconds} ms.");
            }
        }
    }
}
