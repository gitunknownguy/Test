﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Cassandra.Data.Linq;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Interest;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Domain.Services.InterestCalculation;
using LogManager = NLog.LogManager;
using NLog;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class CalculateInterestHandler : CommandHandlerBase<CalculateInterestRequest, CalculateInterestResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IAccountBalanceService _accountBalanceService;
        private readonly IInterestCalculationProcessorService _interestCalculationService;
        private readonly IInterestRateRepository _interestRateRepository;
        private readonly static Logger _logger = LogManager.GetCurrentClassLogger();

        public CalculateInterestHandler(
            IValidateIdentifier validateIdentifier, 
            IAccountBalanceService accountBalanceService,
            IInterestCalculationProcessorService interestCalculationService,
            IInterestRateRepository interestRateRepository)
        {
            _validateIdentifier = validateIdentifier;
            _accountBalanceService = accountBalanceService;
            _interestCalculationService = interestCalculationService;
            _interestRateRepository = interestRateRepository;
        }

        public override void SetDomainContext(CalculateInterestRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<CalculateInterestResponse> VerifyIdentifiers(CalculateInterestRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new CalculateInterestResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CalculateInterestResponse>(e, request));
            }
        }

        public override async Task<CalculateInterestResponse> Handle(CalculateInterestRequest request)
        {
            try
            {
                ValidateDates(request);

                var accountBalanceList = _accountBalanceService.GetAccountBalancesByAccountIdentifier(request.AccountIdentifier);
                var target = accountBalanceList?.FirstOrDefault(b => b.AccountBalanceIdentifier.ToString().Equals(request.PurseIdentifier, StringComparison.OrdinalIgnoreCase));

                if (target == null || target.Status != PurseStatus.Active)
                {
                    throw new ValidationException(3, 117, "The purse is invalid.");
                }

                var accountBalanceInterests = _interestRateRepository.GetAccountBalanceInterests(request.AccountIdentifier);

                var currentPurseWithEmptyAccountBalanceInterests = accountBalanceInterests == null || 
                    !accountBalanceInterests.Any(_=>_.AccountBalanceIdentifier.Equals(request.PurseIdentifier, StringComparison.OrdinalIgnoreCase));

                if(currentPurseWithEmptyAccountBalanceInterests)
                {
                    throw new ValidationException(3, 117, "The purse has no account balance interest.");
                }

                var response = await _interestCalculationService.CalculateInterestOnlineAsync(request);

                if (response?.Success == true)
                {
                    return new CalculateInterestResponse()
                    {
                        Interest = response.Interest,
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 0,
                            SubStatusCode = 0,
                            Message = "Success"
                        }
                    };
                }

                if(response is {Success: false, Code: 400})
                {
                    throw new ValidationException(3, 117, response.Message);
                }

                return new CalculateInterestResponse()
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 500,
                        SubStatusCode = 0,
                        Message = response?.Message ?? "An error occurred while calculating interest."
                    }
                };
            }
            catch (Exception e)
            {
                _logger.Error(e, "Unexpected error happened in CalculateInterestHandler. Request: {Request} Error message: {ErrorMessage}", request, e.Message);
                return e.HandleException<CalculateInterestResponse>(e, request);
            }
        }

        private static void ValidateDates(CalculateInterestRequest request)
        {
            var dateFormat = "yyyy-MM-dd";
            var culture = System.Globalization.CultureInfo.InvariantCulture;

            var isStartDateValid = DateTime.TryParseExact(request.StartDate, dateFormat, culture, System.Globalization.DateTimeStyles.None, out var startDate);

            if (!isStartDateValid)
            {
                throw new ValidationException(3, 117, "The start date is invalid.");
            }

            var isEndDateValid = DateTime.TryParseExact(request.EndDate, dateFormat, culture, System.Globalization.DateTimeStyles.None, out var endDate);

            if (!isEndDateValid)
            {
                throw new ValidationException(3, 117, "The end date is invalid.");
            }

            if (startDate > endDate)
            {
                throw new ValidationException(3, 117, "The start date must be less than the end date.");
            }
        }
    }
}
