﻿using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Core.Application.Exception;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetAdjustBalanceStatusHandler : CommandHandlerBase<GetAdjustAccountBalanceStatusRequest,
        GetAdjustAccountBalanceStatusResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IAccountTransactionService _accountTransactionService;


        public GetAdjustBalanceStatusHandler(IValidateIdentifier validateIdentifier,
            IAccountTransactionService accountTransactionService)
        {
            _validateIdentifier = validateIdentifier;
            _accountTransactionService = accountTransactionService;

        }

        public override Task<GetAdjustAccountBalanceStatusResponse> Handle(GetAdjustAccountBalanceStatusRequest request)
        {
            try
            {
                var response = _accountTransactionService.GetAdjustmentStatus(request);
                return Task.FromResult(response);
            }

            catch (AccountTransactionException<AdjustAccountBalanceBaseResponse> ae)
            {
                var response = ae.ResponseData as GetAdjustAccountBalanceStatusResponse;
                if (response != null)
                {
                    response.ResponseHeader.StatusCode = 0;
                    response.ResponseHeader.SubStatusCode = 0;
                    response.ResponseHeader.Message = "Success";
                }
                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetAdjustAccountBalanceStatusResponse>(e, request));
            }
        }

        public override void SetDomainContext(GetAdjustAccountBalanceStatusRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetAdjustAccountBalanceStatusResponse> VerifyIdentifiers(
            GetAdjustAccountBalanceStatusRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier,
                    DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetAdjustAccountBalanceStatusResponse()
                { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetAdjustAccountBalanceStatusResponse>(e, request));
            }
        }
    }
}
