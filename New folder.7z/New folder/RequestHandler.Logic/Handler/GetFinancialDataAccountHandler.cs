﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using System.Linq;
using System.Collections.Generic;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using NLog;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetFinancialDataAccountHandler : CommandHandlerBase<GetFinancialDataAccountRequest, GetFinancialDataAccountResponse>
    {
        private readonly IAccountRepository _accountRepository;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IAccountBalanceRepository _accountBalanceRepository;
        ILogger _logger = LogManager.GetCurrentClassLogger();

        public GetFinancialDataAccountHandler(IAccountRepository accountRepository, IValidateIdentifier validateIdentifier, IAccountBalanceRepository accountBalanceRepository)
        {
            _accountRepository = accountRepository;
            _validateIdentifier = validateIdentifier;
            _accountBalanceRepository = accountBalanceRepository;
        }

        public override void SetDomainContext(GetFinancialDataAccountRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetFinancialDataAccountResponse> VerifyIdentifiers(GetFinancialDataAccountRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetFinancialDataAccountResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetFinancialDataAccountResponse>(e, request));
            }
        }

        public override Task<GetFinancialDataAccountResponse> Handle(GetFinancialDataAccountRequest request)
        {
            try
            {
                var accountProfile = _accountRepository.GetAccountPrimaryConsumerProfile(request.AccountIdentifier);

                if (accountProfile == null)
                    throw new AccountNotFoundException();

                Shared.Common.Core.CoreApi.Contract.Data.Enum.AccountStatus status = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.AccountStatus.Normal;

                Enum.TryParse<Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.AccountStatus>(accountProfile.AccountStatus.ToString(), true, out status);
               
                AccountBalance activePurse = null;
                List<AccountBalance> existingPurses = null;

                try
                {
                    // get the currency
                    existingPurses = _accountBalanceRepository.GetAccountBalanceByAccountIdentifier(accountProfile.AccountIdentifier);
                    activePurse = existingPurses.FirstOrDefault(p => p.Status == PurseStatus.Active && p.PurseType == PurseType.Primary);

                    if (activePurse == null)
                        activePurse = existingPurses.FirstOrDefault(p => p.Status == PurseStatus.Active);

                    if (activePurse == null)
                        activePurse = existingPurses.FirstOrDefault();
                }
                catch (Exception ex)
                {
                    _logger.Error(ex, $"AccountIdentifier:{request.AccountIdentifier} - {ex.Message} - existingPurses:{existingPurses?.Count} activePurse:{activePurse}");
                }

                var response = new GetFinancialDataAccountResponse();

                response.User = new Shared.Common.Core.CoreApi.Contract.Data.UserLight
                {
                    FirstName = accountProfile.FirstName,
                    LastName = accountProfile.LastName,
                };

                response.Addresses = new List<Shared.Common.Core.CoreApi.Contract.Data.AddressLight>
                    {
                        {
                            new Shared.Common.Core.CoreApi.Contract.Data.AddressLight()
                            {
                                Type = accountProfile.AddressType.ToString(),
                                AddressLine1 = accountProfile.Address1,
                                AddressLine2 = accountProfile.Address2,
                                City = accountProfile.City,
                                State = accountProfile.State,
                                ZipCode = accountProfile.ZipCode,
                                CountryCode = accountProfile.Country
                            }
                        }
                    };

                response.PhoneNumbers = new List<Shared.Common.Core.CoreApi.Contract.Data.PhoneNumberLight>
                    {
                        new Shared.Common.Core.CoreApi.Contract.Data.PhoneNumberLight
                        {
                            Type = accountProfile.PhoneType,
                            Number = accountProfile.PhoneNumber
                        }
                    };

                try
                {
                    response.DepositAccount = new DepositAccount
                    {
                        AccountId = accountProfile.AccountIdentifier.ToString(),
                        AccountNumber = accountProfile.AccountNumber,
                        AccountNumberDisplay = accountProfile?.AccountNumber.Substring(accountProfile.AccountNumber.Length - 4),
                        RoutingTransitNumber = accountProfile.RoutingNumber,
                        Status = status,
                        PurseType = activePurse?.PurseType != null ? activePurse.PurseType.Value : PurseType.Primary,
                        AvailableBalance = (decimal)(activePurse?.AvailableBalance),
                        CurrentBalance = (decimal)(activePurse?.CurrentBalance),
                        BalanceAsOf = (activePurse != null) ? activePurse.AvailableBalanceAsOfDate : DateTime.MinValue,
                        Currency = activePurse?.Currency
                    };
                }
                catch (Exception ex)
                {
                    _logger.Error(ex, $"AccountIdentifier:{request.AccountIdentifier} - {ex.Message} - DepositAccount");
                }

                response.ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                };

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetFinancialDataAccountResponse>(e, request));
            }
        }
    }
}
