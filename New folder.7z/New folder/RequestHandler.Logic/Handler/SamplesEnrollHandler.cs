﻿using Gd.Bos.Logging.Common.Managers;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Services.Crypto;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Core.Infrastructure.DataAccesses;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Configuration;
using Gd.Bos.Shared.Common.Configuration.Repository;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.Disbursements;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using RequestHandler.Core.Domain.Enums;
using Newtonsoft.Json;
using NLog;
using RequestHandler.Core.Application;
using RequestHandler.Core.Domain.Services.Disbursement;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Account = Gd.Bos.RequestHandler.Core.Domain.Model.Account.Account;
using DomainAddress = Gd.Bos.RequestHandler.Core.Domain.Model.User.Address;
using DomainPhoneNumber = Gd.Bos.RequestHandler.Core.Domain.Model.User.PhoneNumber;
using Email = Gd.Bos.RequestHandler.Core.Domain.Model.User.Email;
using LogManager = NLog.LogManager;
using PaymentInstrument = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PaymentInstrument;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using AccountStatus = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.AccountStatus;
using AccountHolderCure = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolderCure;
using RequestHandler.Core.Domain.Model.User;
using Microsoft.IdentityModel.Tokens;
using System.Runtime.Intrinsics.X86;

namespace RequestHandler.Logic.Handler
{
    public class SamplesEnrollHandler : CommandHandlerBase<SamplesEnrollmentRequest, SamplesEnrollmentResponse>
    {
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();
        private readonly object _repoLock = new object();
        private readonly ITokenizerService _tokenizerService;
        private readonly ILockService _lockService;
        private readonly IRequestDataAccess _requestDataAccess;
        private readonly IAccountService _accountService;
        private readonly ILazyCache _lazyCache;
        private readonly IAgreementDataAccess _agreementRepository;

        private readonly ISamplesEnrollService _samplesEnrollService;
        private readonly IEnrollmentDataAccess _enrollmentDataAccess;
        private readonly IIdempotentService _idempotentService;

        private readonly IBaasConfiguration _baasConfiguration;
        private readonly INotificationService _notificationPublisher;

        private readonly IWelcomeNotificationService _welcomeNotificationService;

        private readonly IProductRepository _productRepository;
        private readonly IProspectService _prospectService;
        private readonly IProgramRepository _programRepository;
        private readonly IBaasConfigRepository _baasConfigRepository;
        private readonly IDisbursementGatewayClient _disbursementGatewayClient;
        private readonly IUserRepository _userRepository;

        private static BaasConfigDictionary _baasConfig;
        public SamplesEnrollHandler(
            IEnrollmentDataAccess enrollmentDataAccess,
            ILazyCache lazyCache,
            IIdempotentService idempotentService,
            IAgreementDataAccess agreementRepository,
            IAccountService accountService,
            IRequestDataAccess requestDataAccess,
            ISamplesEnrollService samplesEnrollService,
            ILockService lockService,

            ITokenizerService tokenizerService,
            IBaasConfiguration baasConfiguration,
            INotificationService notificationPublisher,
            IWelcomeNotificationService welcomeNotificationService,
            IProspectService prospectService,
            IProductRepository productRepository,

            IProgramRepository programRepository,
            IBaasConfigRepository baasConfigRepository,
            IDisbursementGatewayClient disbursementGatewayClient,
            IUserRepository userRepository)
        {
            _idempotentService = idempotentService;
            _enrollmentDataAccess = enrollmentDataAccess;
            _samplesEnrollService = samplesEnrollService;
            _agreementRepository = agreementRepository;
            _accountService = accountService;
            _requestDataAccess = requestDataAccess;
            _lockService = lockService;
            _tokenizerService = tokenizerService;
            _lazyCache = lazyCache;

            _baasConfiguration = baasConfiguration;
            _notificationPublisher = notificationPublisher;
            _welcomeNotificationService = welcomeNotificationService;
            _prospectService = prospectService;
            _productRepository = productRepository;

            _programRepository = programRepository;
            _baasConfigRepository = baasConfigRepository;
            _disbursementGatewayClient = disbursementGatewayClient;
            _userRepository = userRepository;
        }

        public override void SetDomainContext(SamplesEnrollmentRequest request)
        {
            if (!string.IsNullOrEmpty(request.ProspectIdentifier))
                DomainContext.Current.ProspectIdentifier = request.ProspectIdentifier;

            if (!string.IsNullOrEmpty(request.ProgramCode))
                DomainContext.Current.ProgramCode = ProgramCode.FromString(request.ProgramCode);
        }

        public override Task<SamplesEnrollmentResponse> VerifyIdentifiers(SamplesEnrollmentRequest request)
        {
            return Task.FromResult(new SamplesEnrollmentResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override async Task<SamplesEnrollmentResponse> ObtainLock(SamplesEnrollmentRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock(OptionsContext.Current.GetString("requestId"));
                await _lockService.ObtainApiLock(DomainContext.Current.ProspectIdentifier);

                return new SamplesEnrollmentResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<SamplesEnrollmentResponse>(e, request);
            }
        }

        public override void ReleaseLock(SamplesEnrollmentRequest request)
        {
            _lockService.ReleaseApiLock(OptionsContext.Current.GetString("requestId"));
            _lockService.ReleaseApiLock(DomainContext.Current.ProspectIdentifier);
        }

        private SamplesEnrollmentResponse GetSamplesEnrollIdempotentResponse(
            GetEnrollmentResponse getEnrollmentResponse,
            UserIdentifyingData userData,
            List<DomainPhoneNumber> phoneNumbers,
            Gd.Bos.RequestHandler.Core.Domain.Model.Account.KycStateData kycStateData,
            Guid? existingRequestAccountIdentifier,
            Guid requestId,
            string programCode,
            string enrollmentRequestIdentifier = null)
        {

            Logger.Info($"start GetSamplesEnrollIdempotentResponse requestid:{requestId},programcode:{programCode}, enrollmentRequestIdentifier:{enrollmentRequestIdentifier ?? string.Empty}");

            var errorCode = _lazyCache?.Value?.Get<string>(requestId.ToString());
            Logger.Info($"GetSamplesEnrollIdempotentResponse,requestid:{requestId},errorcode from lazycahce:{errorCode}");

            var errorCodeForProspectIdentifier = GetErrorCodeForProspectidentifier(getEnrollmentResponse?.Account?.Status?.ToLower(),
                getEnrollmentResponse?.Account?.AccountHolders?.FirstOrDefault().User?.KycStateData?.PendingKycGate?.ToLower());
            // keep only activated virtual as first enrollment does not 
            // return the magStripe payment instrument
            foreach (var ah in getEnrollmentResponse.Account.AccountHolders)
            {
                if (ah?.User?.DateOfBirth != userData.DateOfBirth)
                    throw new RequestHandlerException(2, 60, "Number of Active Accounts Exceeded.");


                if ((ah.PaymentInstruments == null && getEnrollmentResponse?.Account?.Status.ToLower() == "pending") ||

                    (ah.PaymentInstruments?.Count(n =>
                     n.PaymentInstrumentType == PaymentInstrumentType.MagStripe ||
                     n.PaymentInstrumentType == PaymentInstrumentType.Emv) == 0)
                     && getEnrollmentResponse?.Account?.Status?.ToLower() == "pending")
                {
                    Gd.Bos.RequestHandler.Core.Domain.Model.Account.KycStateData kycData = ah.User?.KycStateData?.ToDomain();

                    kycStateData = _idempotentService?.EnrollIdempotent(
                        existingRequestAccountIdentifier.Value.ToString(),
                        ah.User?.UserIdentifier,
                        kycData, "pvc",
                        programCode,
                        true,
                        "kyc",
                       null,
                        null,
                        phoneNumbers,
                        ProductCode.FromString(getEnrollmentResponse.Account.ProductCode),
                        getEnrollmentResponse.Account.ProductName,
                        true,
                        enrollmentRequestIdentifier: enrollmentRequestIdentifier);

                    if (kycStateData?.KycPendingGate != null)
                        getEnrollmentResponse =
                            _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(
                                existingRequestAccountIdentifier.Value.ToString(), programCode,
                                true);

                    if (kycStateData?.KycPendingGate == "healthy")
                        foreach (var accHolder in getEnrollmentResponse.Account?.AccountHolders)
                            accHolder.PaymentInstruments = accHolder?.PaymentInstruments
                                ?.Where(x => x.PaymentInstrumentType == PaymentInstrumentType.Virtual)
                                .ToList();
                }
            }

            // var paymentInst
            var existingResponse = new SamplesEnrollmentResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = requestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                },
                AccountIdentifier = getEnrollmentResponse.Account.AccountIdentifier,
                AccountReferenceNumber = getEnrollmentResponse.Account.CustomerReferenceNumber,
                Status = getEnrollmentResponse.Account.Status,
                StatusReasons = getEnrollmentResponse.Account.StatusReasons,
                StatusCure = getEnrollmentResponse.Account.StatusCure,
                DirectDepositInformation = getEnrollmentResponse.Account.DirectDepositInformation,
                Purses = getEnrollmentResponse.Account.Purses,
                AccountHolders = getEnrollmentResponse.Account.AccountHolders,
                AccountStatusChangedDateTime = getEnrollmentResponse.Account?.AccountStatusChangedDateTime,
                AccountCycleDay = getEnrollmentResponse.Account.AccountCycleDay,
                KycStateData = kycStateData == null ? null : new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData
                {
                    KycStatus = kycStateData.KycStatus.ToString(),
                    PendingKycGate = kycStateData.KycPendingGate,
                    OfacStatus = kycStateData.OfacStatus.ToString()
                }
            };

            foreach (var accHolder in existingResponse.AccountHolders)
            {
                accHolder.User.PeerTransferAcceptPreference = null;
                accHolder.AccountHolderIdentifier = null;
            }

            if (!string.IsNullOrEmpty(errorCode))
                existingResponse.ResponseHeader =
                    existingResponse.ResponseHeader?.GetResponseHeader(errorCode,
                        requestId);

            if (!string.IsNullOrWhiteSpace(errorCodeForProspectIdentifier))
                existingResponse.ResponseHeader =
                    existingResponse.ResponseHeader?.GetResponseHeader(errorCodeForProspectIdentifier,
                        requestId);

            var existingPaymentInstrument = existingResponse.AccountHolders.FirstOrDefault()?.PaymentInstruments?.FirstOrDefault();
            var existingPrivateCardData = existingPaymentInstrument?.PrivateCardData;

            //if (existingPrivateCardData != null
            //    && existingPaymentInstrument.PaymentInstrumentType == PaymentInstrumentType.Virtual)
            //{
            //    var generateCvvResponse = _cryptoService.GenerateCvv(
            //        AccountIdentifier.FromString(getEnrollmentResponse.Account.AccountIdentifier),
            //        existingPrivateCardData.Pan,
            //        existingPrivateCardData.ExpirationDate.CardExpirationyear.Substring(2) +
            //        existingPrivateCardData.ExpirationDate.CardExpirationMonth,
            //        existingPaymentInstrument.PaymentInstrumentType);

            //    existingPrivateCardData.Pan = existingPrivateCardData.Pan;
            //    existingPrivateCardData.Cvv = generateCvvResponse.Cvv;
            //}


            if (existingPrivateCardData != null &&
                _baasConfiguration.IsPinSetNeed(programCode, existingPaymentInstrument?.IsPinSet) == false)
                existingPaymentInstrument.PrivateCardData = null;

            if (kycStateData?.KycPendingGate != null && kycStateData.KycPendingGate.Equals("healthy",
                                                         StringComparison.OrdinalIgnoreCase)
                                                     && !programCode.Equals("credibly",
                                                         StringComparison.OrdinalIgnoreCase))
                //using same logic used to update account info to see if we need to send notification 
            {
                _notificationPublisher.PublishNotification(programCode, getEnrollmentResponse.Account, EventType.AccountUpdated);
            }

            return existingResponse;
        }
        private string GetErrorCodeForProspectidentifier(string accountStatus, string kycPendingGate)
        {
            if (accountStatus == "pending" && (kycPendingGate == "idv" || kycPendingGate == "kyc2"))
                return "110";
            else if (accountStatus == "locked" && kycPendingGate == "manual")
                return "231";
            else if (accountStatus == "locked" && (kycPendingGate == null || kycPendingGate == "none"))
                return "211";
            else
                return null;
        }
        private Task<SamplesEnrollmentResponse> DenyRestrictedRegionsEnrollment(SamplesEnrollmentRequest request)
        {
            string state = request.UserData?.Address?.State;
            if (state != null && (state.Equals("PR", StringComparison.InvariantCultureIgnoreCase) ||
                                  state.Equals("GU", StringComparison.InvariantCultureIgnoreCase)))
            {
                return Task.FromResult(new SamplesEnrollmentResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 5,
                        SubStatusCode = 65,
                        Message = "This product may not be registered in the requested region"
                    }
                });
            }

            return null;
        }

        public override Task<SamplesEnrollmentResponse> Handle(SamplesEnrollmentRequest request)
        {
            try
            {
                return HandleByProspectId(request);
            }
            catch (InvalidProductMaterialException e)
            {
                var response = new SamplesEnrollmentResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 4,
                        SubStatusCode = 312,
                        Message = e.Message
                    },
                };
                return Task.FromResult(response);
            }
            catch (PhoneValidationException e)
            {
                var accountIdentifier = DomainContext.Current.AccountIdentifier?.ToString();

                var response = new SamplesEnrollmentResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = e.Code,
                        SubStatusCode = e.SubCode,
                        Message = e.Message
                    },
                    AccountIdentifier = accountIdentifier
                };

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                var eResult = e.HandleException<SamplesEnrollmentResponse>(e, request);
                Logger.Info($"Samples enrollment failure, prospectId:{DomainContext.Current.ProspectIdentifier}, prospectType:{DomainContext.Current.ProspectType},statusCode:{eResult.ResponseHeader.StatusCode},subStatusCode:{eResult.ResponseHeader.SubStatusCode},statusMessage:{eResult.ResponseHeader.Message},statusDetails:{eResult.ResponseHeader.Details}");
                return Task.FromResult(eResult);
            }
        }

        private bool IsDisbursementEnrollmentRequired(string programCode)
        {
            try
            {
                LoadData(); //load SQL config
                if (_baasConfig != null)
                    return _baasConfig.GetBoolean(String.Format("/programs/{0}/disbursement/enrollment/require", programCode));
            }
            catch (System.Exception exp)
            {
                Logger.Error("Error loading config data from SQL Exception: {0}", exp.ToString());

                if (programCode.Equals("spark", StringComparison.InvariantCultureIgnoreCase))
                    throw new Exception($"Error loading config data from SQL Exception: {exp.ToString()}");
            }
            return false;
        }
        private void LoadData()
        {
            if (_baasConfig == null)
            {
                lock (_repoLock)
                {
                    if (_baasConfig == null)
                    {
                        Logger.Info("Getting configuration data from baasConfigRepository.");
                        try
                        {
                            _baasConfig = _baasConfigRepository.LoadConfigDataCommon();
                            Logger.Info("Data loaded from baasConfigRepository.");
                        }
                        catch (Exception e)
                        {
                            Logger.Info($"Could not connect to SQL {e}");
                            _baasConfig = null;
                            throw;
                        }
                    }
                }
            }
        }

        private static void FilterPhoneNumber(List<DomainPhoneNumber> phoneNumbers)
        {
            foreach (var entity in phoneNumbers)
            {
                if (string.IsNullOrEmpty(entity.Number))
                    throw new ValidationException(101, 0, "Phone is required");

                var replacedPhone = Regex.Replace(entity.Number, @"[(\)\-]", string.Empty, RegexOptions.Compiled);

                if (!Regex.IsMatch(replacedPhone, @"^[1]?([0-9]{3})([0-9]{3})([0-9]{4})$"))
                    throw new ValidationException(350, 0, "The format of the phonenumber was invalid.");

                entity.Number = replacedPhone;
            }
        }
        private static List<string> MapStatusReasons(Account account)
        {
            var result = new List<string>();

            var reasons = account?.AccountStatusReasons;

            if (reasons != null && reasons.Count > 0)
            {
                foreach (var statusReason in reasons)
                {
                    result.Add(statusReason.ToString());
                }
            }
            return result;
        }

        private static DirectDepositInformation MapDirectDepositInformation(Account account)
        {
            if (account == null) return null;
            return new DirectDepositInformation
            {
                AccountNumber = account.AccountNumber,
                RoutingNumber = account.RoutingNumber
            };
        }

        private Task<SamplesEnrollmentResponse> HandleByProspectId(SamplesEnrollmentRequest request)
        {
            string enrollmentRequestIdentifier = null;
            if (request.RequestHeader.Options != null && request.RequestHeader.Options.ContainsKey("X-GD-EnrollmentRequestIdentifier"))
            {
                enrollmentRequestIdentifier = request.RequestHeader.Options["X-GD-EnrollmentRequestIdentifier"].ToString();
            }

            var newAccountIdentifier = Guid.NewGuid();
            var existingRequestAccountIdentifier = _requestDataAccess.InsertRequestId(RequestType.Enroll,
                request.RequestHeader.RequestId, newAccountIdentifier);

            //
            var denialResponse = DenyRestrictedRegionsEnrollment(request);
            if (denialResponse != null)
                return denialResponse;

            //1.GetProspectDetailsById
            UserName userName;
            var addresses = new List<DomainAddress>();
            var phoneNumbers = new List<DomainPhoneNumber>();
            List<DomainTermsAcceptance> terms = new List<DomainTermsAcceptance>();
            Email email;
            string dateOfBirth = null;
            string ssn = null;
            string ssnToken = null;
            SourceSystem? sourceSystem = null;
            if (!string.IsNullOrWhiteSpace(request.RequestHeader?.Source))
            {
                if (Enum.TryParse(request.RequestHeader.Source, true, out SourceSystem ss))
                {
                    sourceSystem = ss;
                }
            }

            var prospectDetails = _prospectService.GetProspectDetailsById(new GetProspectDetailsByIdRequest
            {
                RequestHeader = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.RequestHeader
                { RequestId = request.RequestHeader.RequestId },
                ProspectIdentifier = request.ProspectIdentifier,
                ProgramCode = request.ProgramCode
            });

            Logger.Info(
                $"get prospectdetails has been called response:{MaskEngine.MaskMessage(JsonConvert.SerializeObject(prospectDetails))}");

            if (prospectDetails.ResponseHeader?.StatusCode != 0)
            {
                return Task.FromResult(new SamplesEnrollmentResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = prospectDetails.ResponseHeader.StatusCode,
                        SubStatusCode = prospectDetails.ResponseHeader.SubStatusCode,
                        Message = prospectDetails.ResponseHeader.Details,
                    }
                });
            }

            //request.ProgramCode = "gbr";
            //var prospectDetails = new GetProspectDetailsByIdResponse()
            //{
            //    ProspectDetail = new ProspectDetail
            //    {
            //        SampleType = 1,
            //        Address = new ProspectAddress
            //        { AddressLine = "add line", City = "Pasdena", CountryCode = "", State = "CA", ZipCode = "86391" },
            //        FirstName = "testy",
            //        LastName = "lastname",
            //        Phone = "(836)821-0486",
            //        EmbossedName = "embossedn",
            //        CardProxy = "1234",
            //        Dob = DateTime.Now.AddYears(-19),
            //        EmailAddress = "kevin@test.com",
            //        ProductCode = "40002",
            //        CardStockCode = "123",
            //        SsnToken = "GU72XCHCE3QK",
            //        ProspectIdentifier = Guid.NewGuid().ToString()
            //    }
            //};

            if (prospectDetails.ProspectDetail.SampleType == (int)SampleType.WinBack
                || prospectDetails.ProspectDetail.SampleType == (int)SampleType.TsysMigrateToGBOS
                || prospectDetails.ProspectDetail.SampleType == (int)SampleType.LegacyMigrateToGBOS
                || prospectDetails.ProspectDetail.SampleType == (int)SampleType.AciWinback)//wb
            {
                dateOfBirth = !string.IsNullOrEmpty(request.UserData.DateOfBirth)
                     ? request.UserData.DateOfBirth
                     :
                     prospectDetails.ProspectDetail.Dob.HasValue
                         ?
                         prospectDetails.ProspectDetail.Dob.Value.ToString("yyyy-MM-dd")
                         : string.Empty;

                addresses.Add(
                    new DomainAddress
                    {
                        State = prospectDetails.ProspectDetail.Address.State,
                        AddressLine1 = prospectDetails.ProspectDetail.Address.AddressLine,
                        AddressLine2 = prospectDetails.ProspectDetail.Address.AddressLine2,
                        City = prospectDetails.ProspectDetail.Address.City,
                        Type = AddressType.Home.ToString(),
                        ZipCode = prospectDetails.ProspectDetail.Address.ZipCode,
                        IsDefault = true,
                        IsVerified = true
                    });

                userName = new UserName(
                    prospectDetails.ProspectDetail.FirstName,
                    null,
                    prospectDetails.ProspectDetail.LastName);

                // set possible changed name
                if (!string.IsNullOrWhiteSpace(request.UserData.Name.FirstName))
                    userName.FirstName = request.UserData.Name.FirstName;

                if (!string.IsNullOrWhiteSpace(request.UserData.Name.MiddleName))
                    userName.MiddleName = request.UserData.Name.MiddleName;

                if (!string.IsNullOrWhiteSpace(request.UserData.Name.LastName))
                    userName.LastName = request.UserData.Name.LastName;

                //  email = new Email(prospectDetails.ProspectDetail.EmailAddress, false, true);
                var dmEmailAddress = string.Empty;
                var dmPhoneNumber = string.Empty;

                if (!string.IsNullOrEmpty(request.UserData?.Email?.EmailAddress))
                {
                    dmEmailAddress = request.UserData?.Email?.EmailAddress;
                }
                else if (!string.IsNullOrEmpty(prospectDetails.ProspectDetail.EmailAddress))
                {
                    dmEmailAddress = prospectDetails.ProspectDetail.EmailAddress;
                }

                email = new Email(dmEmailAddress, false, true);

                if (!string.IsNullOrEmpty(request.UserData?.Phone?.Number))
                {
                    dmPhoneNumber = request.UserData?.Phone?.Number;
                }
                else if (!string.IsNullOrEmpty(prospectDetails.ProspectDetail.Phone))
                {
                    dmPhoneNumber = prospectDetails.ProspectDetail.Phone;
                }
                else if (OptionsContext.Current.ContainsKey("X-Gd-Bos-IgnorePhoneLimits"))
                {
                    dmPhoneNumber = null;
                }
                else
                    throw new ValidationException(101, 0, "phonenumber is not found by Prospect returned in WB flow");

                if (!string.IsNullOrEmpty(dmPhoneNumber))
                {
                    phoneNumbers = new List<DomainPhoneNumber>()
                    {
                        new DomainPhoneNumber
                        {
                            Type = PhoneType.Unspecified, //?
                            IsDefault = true,
                            IsVerified = false,
                            Number = dmPhoneNumber
                        }
                    };
                }
                else
                    phoneNumbers = new List<DomainPhoneNumber>();

                ssnToken = prospectDetails.ProspectDetail.SsnToken;
                ssn = _tokenizerService.DeTokenizeSsn(ssnToken, request.ProgramCode);

            }
            else if (prospectDetails.ProspectDetail.SampleType == (int)SampleType.DirectMail || prospectDetails.ProspectDetail.SampleType == (int)SampleType.AciDirectMail) //dm
            {
                //
                if (request.UserData?.Address == null ||
                    request.UserData?.Email == null ||
                    request.UserData?.Name == null ||
                    request.UserData?.Phone == null ||
                    request.UserData?.Ssn == null ||
                    string.IsNullOrEmpty(request.UserData?.DateOfBirth))
                    throw new ValidationException(101, 0,
                        "UserData:Ssn,Address,Email,Name,Phone,DateOfBirth is required in DM flow");

                addresses.Add(new DomainAddress
                {
                    State = request.UserData.Address.State,
                    AddressLine1 = request.UserData.Address.AddressLine1,
                    AddressLine2 = request.UserData.Address.AddressLine2,
                    City = request.UserData.Address.City,
                    Type = request.UserData.Address.Type,
                    ZipCode = request.UserData.Address.ZipCode,
                    IsDefault = true,
                    IsVerified = request.UserData.Address.IsVerified
                });
                userName = new UserName(
                    request.UserData.Name.FirstName,
                    request.UserData.Name.MiddleName,
                    request.UserData.Name.LastName);

                email = request.UserData?.Email?.ToDomain();
                email.IsPrimary = true;

                phoneNumbers = new List<DomainPhoneNumber>
                {
                    new DomainPhoneNumber
                    {
                        Type = request.UserData.Phone.Type,
                        IsDefault = true,
                        IsVerified = request.UserData.Phone.IsVerified,
                        Number = request.UserData.Phone.Number
                    }
                };
                dateOfBirth = request.UserData.DateOfBirth;
                ssnToken = _tokenizerService.TokenizeSsn(request.UserData.Ssn, request.ProgramCode);
                ssn = request.UserData.Ssn;
            }
            else
                throw new ArgumentNullException(
                    $"not implemented for SampleType:{prospectDetails.ProspectDetail.SampleType} flow");

            DomainContext.Current.ProspectType = (SampleType)prospectDetails.ProspectDetail.SampleType;

            if (!string.IsNullOrEmpty(ssnToken))
                DomainContext.Current.TokenizedIdentity = ssnToken;

            if (!request.UpgradeToEMV.HasValue)
                request.UpgradeToEMV = true;


            //filter symbol for phonenumber and format it
            if (!OptionsContext.Current.ContainsKey("X-Gd-Bos-IgnorePhoneLimits"))
                FilterPhoneNumber(phoneNumbers);

            //2.verifProductCode & Terms Verification
            _programRepository.GetByProgramIdentifier(ProgramCode.FromString(request.ProgramCode));

            _productRepository.GetByProductCode(
                ProductCode.FromString(prospectDetails.ProspectDetail.ProductCode),
                ProgramCode.FromString(request.ProgramCode));

            Logger.Info($"RequestId:{request.RequestHeader.RequestId}:ProductCode and Program validate Success");

            if (request.AccountCreationData?.TermsAcceptances != null &&
                request.AccountCreationData.TermsAcceptances.Any())
            {
                var brandAgreementTypeResult = _agreementRepository.ValidateBrandAgreementType(
                    request.AccountCreationData.TermsAcceptances,
                    prospectDetails.ProspectDetail.ProductCode, request.ProgramCode);

                if (brandAgreementTypeResult.ResponseHeader.StatusCode != 0)
                    return Task.FromResult(new SamplesEnrollmentResponse()
                    {
                        ResponseHeader = new ResponseHeader()
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = brandAgreementTypeResult.ResponseHeader.StatusCode,
                            SubStatusCode = 0,
                            Details = brandAgreementTypeResult.ResponseHeader.Details
                        }
                    });

                var agreement =
                    _agreementRepository.GetAgreementsByProductCode(prospectDetails.ProspectDetail.ProductCode);

                var termsResponse = _agreementRepository.IsTermAgreementAccepted(agreement,
                    request.AccountCreationData.TermsAcceptances,
                    prospectDetails.ProspectDetail.ProductCode,
                    request.RequestHeader.RequestId);

                if (!termsResponse.Item1)
                    return Task.FromResult(new SamplesEnrollmentResponse { ResponseHeader = termsResponse.Item2 });

                terms = request.AccountCreationData.TermsAcceptances?.ToDomain(agreement);
                Logger.Info($"RequestId:{request.RequestHeader.RequestId}:Terms Validate Success");
            }

            //3.Copa Verification age>=18
            var userIdentifyingData = new UserIdentifyingData(
                dateOfBirth,
                string.Empty,
                ssn,
                string.Empty);

            //4.Validate account limit
            AccountLimit accountLimit = _accountService.AccountLimitVerification(userIdentifyingData.Ssn,
                string.Empty,
                userIdentifyingData.GetIdentityTypeKey().ToString(),
                false,
                prospectDetails.ProspectDetail.ProductCode,
                request.ProgramCode);

            accountLimit.ResponseCode = accountLimit.ResponseCode ?? "0";
            if (accountLimit.ResponseCode != "0")
                _lazyCache?.Value?.Set(request.RequestHeader?.RequestId.ToString(), accountLimit.ResponseCode,
                    new TimeSpan(1, 0, 0, 0));

            //If SSN limit succeeds then try phone limit
            string phoneNumber = phoneNumbers.FirstOrDefault()?.Number;
            if (accountLimit.ResponseCode == "0" &&
                !string.IsNullOrEmpty(phoneNumber))
            {
                accountLimit = _accountService.PhoneLimitVerification(
                    phoneNumber,
                    "PhoneNumber",
                    prospectDetails.ProspectDetail.ProductCode,
                    request.ProgramCode);

                accountLimit.ResponseCode = accountLimit.ResponseCode ?? "0";
                if (accountLimit.ResponseCode != "0")
                    _lazyCache?.Value?.Set(request.RequestHeader?.RequestId.ToString(), accountLimit.ResponseCode,
                        new TimeSpan(1, 0, 0, 0));
            }

            //If phone limit succeeds then try email limit
            if (accountLimit.ResponseCode == "0" && !string.IsNullOrEmpty(email.EmailAddress))
            {
                accountLimit = _accountService.EmailLimitVerification(
                    email.EmailAddress,
                    prospectDetails.ProspectDetail.ProductCode,
                    request.ProgramCode);

                accountLimit.ResponseCode ??= "0";
                if (accountLimit.ResponseCode != "0")
                    _lazyCache?.Value?.Set(request.RequestHeader?.RequestId.ToString(), accountLimit.ResponseCode,
                        new TimeSpan(1, 0, 0, 0));
            }

            //return account information if the prospectId already associated to an existing account
            string prospectInfo =
                        _userRepository.GetAccountIdentifierByProspectId(request.ProspectIdentifier);
            string existingAccountIdentifier = null;
            if (!string.IsNullOrWhiteSpace(prospectInfo))
            {
                existingAccountIdentifier = JsonConvert
                    .DeserializeObject<ProspectProfile>(prospectInfo)
                    .AccountIdentifier;

            }
            if (existingRequestAccountIdentifier.HasValue || accountLimit.AccountIdentifier != null)
            {
                newAccountIdentifier = !string.IsNullOrWhiteSpace(existingAccountIdentifier) ?
                    new Guid(existingAccountIdentifier) : (
                    accountLimit.AccountIdentifier == null
                    ? existingRequestAccountIdentifier.Value
                    : accountLimit.AccountIdentifier.ToGuid());

                var kycStateData = new Gd.Bos.RequestHandler.Core.Domain.Model.Account.KycStateData();

                var getEnrollmentResponse =
                     _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(newAccountIdentifier.ToString(),
                         request.ProgramCode, true);

                if (accountLimit.ResponseCode != "0")
                {
                    switch (accountLimit.ResponseCode)
                    {
                        case "260":
                            throw new RequestHandlerException(2, 60, "Number of Active Accounts Exceeded.");
                        case "261":
                            throw new RequestHandlerException(2, 61, "Number of Activated Accounts over Lifetime exceeded.");
                        case "264":
                            throw new RequestHandlerException(2, 64, "Account Holder limits are exceeded.");
                        case "267":
                            throw new RequestHandlerException(2, 67, "7 day opened account limit exceeded.");
                        case "268":
                            throw new RequestHandlerException(2, 68, "30 day opened account limit exceeded.");
                    }
                }

                if (getEnrollmentResponse?.Account != null)
                {
                    var existingResponse = GetSamplesEnrollIdempotentResponse(
                        getEnrollmentResponse,
                        userIdentifyingData,
                        phoneNumbers,
                        kycStateData,
                        newAccountIdentifier,
                        request.RequestHeader.RequestId,
                        request.ProgramCode,
                        enrollmentRequestIdentifier: enrollmentRequestIdentifier);

                    var ah = existingResponse.AccountHolders.FirstOrDefault();

                    //Need to set BCD and AccountStatus here. https://pd/browse/GBOS-30134
                    if (ah?.User?.KycStateData?.PendingKycGate == "healthy" &&
                        existingResponse.AccountCycleDay == 0 && ah.PaymentInstruments != null && ah.PaymentInstruments.Any())
                    {
                        var account = _accountService.GetAccount(existingResponse.AccountIdentifier);
                        //warning, if you need to use this account, it will only have the accountIdentifier and accountKey
                        string status = existingResponse.Status;
                        short? accountCycleDay = 0;

                        accountCycleDay = (short)_accountService.SetBillCycle(
                        request.RequestHeader.RequestId,
                        account.AccountIdentifier.ToString(),
                        request.ProgramCode);

                        existingResponse.Status = status;
                        existingResponse.AccountCycleDay = accountCycleDay;
                        existingResponse.StatusReasons = new List<string>
                        {
                            Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountStatusReason.healthy.ToString()
                        };
                    }

                    Logger.Info($"RequestId:{request.RequestHeader.RequestId}:existing response");

                    // this this until we need this for multiple account holders
                    existingResponse.KycStateData = null;

                    return Task.FromResult(existingResponse);
                }
            }

            _accountService.EmailLimitVerification(request.ProgramCode, email?.EmailAddress, 5);

            var sampleType = Enum.IsDefined(typeof(SampleType), prospectDetails.ProspectDetail.SampleType) ?
                (SampleType)prospectDetails.ProspectDetail.SampleType : SampleType.Default;

            var enrollResponse = _samplesEnrollService.Enroll(
                newAccountIdentifier.ToString(),
                request.ProgramCode,
                userName,
                userIdentifyingData,
                email,
                addresses,
                phoneNumbers,
                true,
                terms,
                prospectDetails.ProspectDetail,
                request.UpgradeToEMV.Value,
                request.AccountCreationData.FraudData,
                sourceSystem,
                sampleType,
                request.RequestHeader.Source,
                enrollmentRequestIdentifier: enrollmentRequestIdentifier,
                mappingIdentifier: null);

            return GenerateResponse(enrollResponse, request);
        }

        private static SourceSystem? MapSourceSystem(SamplesEnrollmentRequest request)
        {
            SourceSystem? sourceSystem = null;
            if (!string.IsNullOrWhiteSpace(request.RequestHeader?.Source))
            {
                if (Enum.TryParse(request.RequestHeader.Source, true, out SourceSystem ss))
                {
                    sourceSystem = ss;
                }
            }

            return sourceSystem;
        }

        private bool MapUpgradeToEmv(SamplesEnrollmentRequest request)
        {
            return !request.UpgradeToEMV.HasValue || request.UpgradeToEMV.Value;
        }

        private Task<SamplesEnrollmentResponse> GenerateResponse(Tuple<Account, Gd.Bos.RequestHandler.Core.Domain.Model.User.User, PaymentIdentifier, AccountBalance, Gd.Bos.RequestHandler.Core.Application.PrivateCardData, string, Gd.Bos.RequestHandler.Core.Domain.Model.Account.KycStateData> enrollResponse, SamplesEnrollmentRequest request)
        {
            var response = new SamplesEnrollmentResponse();
            var newAccount = enrollResponse.Item1;
            var newUser = enrollResponse.Item2;
            var newPaymentIdentifier = enrollResponse.Item3;
            var newAccountBalance = enrollResponse.Item4;
            var privateCardData = enrollResponse.Item5;
            var activationStatus = enrollResponse.Item6;
            response.KycStateData = enrollResponse.Item7 != null ? new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData
            {
                KycStatus = enrollResponse.Item7.KycStatus.ToString(),
                PendingKycGate = enrollResponse.Item7.KycPendingGate,
                OfacStatus = enrollResponse.Item7.OfacStatus.ToString()
            } : null;

            Logger.Info(
                $"RequestId:{request.RequestHeader.RequestId}:accountIdentifier:{newAccount.AccountIdentifier} call enroll service returned,{MaskEngine.MaskMessage(JsonConvert.SerializeObject(enrollResponse))}");

            string errorCode = _lazyCache?.Value?.Get<string>(request.RequestHeader?.RequestId.ToString());

            Logger.Info($"GenerateResponse from lazy cache errorcode:{errorCode}");
            if (!string.IsNullOrEmpty(errorCode) && errorCode != "0")
            {
                response.ResponseHeader =
                    response.ResponseHeader.GetResponseHeader(errorCode, request.RequestHeader.RequestId);
            }
            else
            {

                response.ResponseHeader = response.ResponseHeader.GetResponseHeader(newAccount.ErrorCode.ToString(),
                    request.RequestHeader.RequestId);
                _lazyCache?.Value?.Set(request.RequestHeader?.RequestId.ToString(), newAccount.ErrorCode.ToString(),
                    new TimeSpan(1, 0, 0, 0));
            }

            // Logger.Info($"start response requestid:request.RequestHeader.RequestId,{JsonConvert.SerializeObject(enrollResponse)}");
            response.AccountIdentifier = newAccount.AccountIdentifier.ToString();
            response.AccountReferenceNumber = newAccount.CustomerAccountNumber;
            response.AccountNumber = newAccount.AccountNumber;
            response.Status = newAccount.AccountStatus.ToString().ToLower();
            response.PaymentInstrumentIdentifier =
                newPaymentIdentifier?.PaymentInstrument.PaymentInstrumentIdentifier.ToString();
            response.ActivationStatus = activationStatus;

            var accountResp =
                _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(newAccount.AccountIdentifier.ToString(),
                    request.ProgramCode, false);
            response.AccountCycleDay = accountResp.Account.AccountCycleDay;
            Logger.Info($"RequestId:{request?.RequestHeader?.RequestId} accountResp from GetEnrollmentByAccountIdentifier，Detail:{JsonConvert.SerializeObject(accountResp)}");

            DateTime accountStatusDateChange = newAccount.AccountStatusChangedDateTime;
            accountStatusDateChange = accountStatusDateChange.ToUniversalTime();
            response.AccountStatusChangedDateTime =
                accountStatusDateChange.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");

            response.StatusReasons = MapStatusReasons(newAccount);
            response.DirectDepositInformation = MapDirectDepositInformation(newAccount);

            if (newAccountBalance != null)
            {
                response.Purses = new List<Purse>();
                var purse = new Purse
                {
                    PurseIdentifier = newAccountBalance.AccountBalanceIdentifier.ToString(),
                    PurseType = PurseType.Primary,
                    AvailableBalance = newAccountBalance.AvailableBalance,
                    LedgerBalance = newAccountBalance.CurrentBalance,
                    AvailableBalanceAsOfDateTime = newAccountBalance.AvailableBalanceAsOfDate,
                    LedgerBalanceAsOfDateTime = newAccountBalance.CurrentBalanceAsOfDate,
                    Status = newAccountBalance.Status
                };
                response.Purses.Add(purse);
            }

            response.AccountHolders = new List<Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.AccountHolder>();
            var accountHolder = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.AccountHolder();

            foreach (Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolder ah in newAccount.AccountHolders)
            {
                accountHolder.User = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.User
                {
                    UserIdentifier = newUser.UserIdentifier.ToString(),
                    Status = UserStatus.Active,
                    IsPrimaryAccountHolder = true,
                    KycStateData = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData
                    {
                        OfacStatus = ah.kycStateData.OfacStatus.ToString().ToLower(),
                        KycStatus = ah.kycStateData.KycStatus.ToString().ToLower(),
                        PendingKycGate = ah.kycStateData.KycPendingGate.ToLower()
                    }
                };


                if (newPaymentIdentifier != null)
                {
                    accountHolder.PaymentInstruments = new List<PaymentInstrument>();
                    var paymentInstrument = new PaymentInstrument();
                    //PaymentInstrumentStatus paymentInstrumentStatus;
                    Enum.TryParse(newPaymentIdentifier.PaymentInstrument.Status,
                        out PaymentInstrumentStatus paymentInstrumentStatus);

                    paymentInstrument.PaymentIdentifier = newPaymentIdentifier.PaymentIdentifierIdentifier.ToString();
                    paymentInstrument.PaymentInstrumentIdentifier = newPaymentIdentifier?.PaymentInstrument
                        .PaymentInstrumentIdentifier.ToString();
                    paymentInstrument.PaymentInstrumentType =
                        newPaymentIdentifier.PaymentInstrument.PaymentInstrumentType;
                    paymentInstrument.Status = paymentInstrumentStatus;
                    paymentInstrument.IsPinSet = newPaymentIdentifier.PaymentInstrument.PinSetDate.HasValue;
                    paymentInstrument.Last4Pan = newPaymentIdentifier?.PaymentInstrument.Last4Pan;
                    paymentInstrument.ActivatedDateTime = newPaymentIdentifier?.PaymentInstrument.ActivatedDateTime;
                    paymentInstrument.IssuedDateTime = newPaymentIdentifier?.PaymentInstrument.IssuedDateTime;


                    //if (privateCardData != null)
                    //{
                    //    paymentInstrument.PrivateCardData =
                    //        new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PrivateCardData
                    //        {
                    //            Pan = privateCardData?.Pan,
                    //            Cvv = privateCardData?.Cvv,
                    //            ExpirationDate = new CardExpirationDate
                    //            {
                    //                CardExpirationMonth = privateCardData?.CardExpirationDate.CardExpirationMonth,
                    //                CardExpirationyear = privateCardData?.CardExpirationDate.CardExpirationYear
                    //            }
                    //        };

                    //    if (paymentInstrument.PaymentInstrumentType == PaymentInstrumentType.Virtual)
                    //        paymentInstrument.IsPrivateDataViewable = "true";
                    //}



                    accountHolder.PaymentInstruments.Add(paymentInstrument);
                }

                response.AccountHolders.Add(accountHolder);
            }


            response.AccountCycleDay = accountResp.Account.AccountCycleDay;

            _notificationPublisher.PublishNotification(request.ProgramCode, accountResp.Account,
                EventType.AccountUpdated, request.RequestHeader.RequestId.ToString());
            if (accountResp.Account.Status.Equals("normal", StringComparison.OrdinalIgnoreCase))
                _welcomeNotificationService.RaiseWelcomeNotification(request.ProgramCode,
                    accountResp.Account.AccountIdentifier, request.RequestHeader.RequestId);

            Logger.Info($"RequestId:{request.RequestHeader.RequestId}:notification send out");

            if (response.ResponseHeader.StatusCode == 0 && IsDisbursementEnrollmentRequired(request.ProgramCode))
            {
                Logger.Info("Disbursement Enrollment Required requestID: {0}", request.RequestHeader.RequestId);

                var customerResponse = _disbursementGatewayClient.CreateCustomer(new CreateCustomerRequest
                {
                    FirstName = request.UserData?.Name?.FirstName,
                    LastName = request.UserData?.Name?.LastName,
                    CustomerId = Guid.NewGuid().ToString(), // response.AccountIdentifier,
                    PhoneNumber = request.UserData?.Phone?.Number,
                    DateOfBirth = request.UserData?.DateOfBirth,
                    ProductCode = newAccount.AccountHolders.FirstOrDefault(x => x.IsPrimary)?.ProductCode,
                    ProgramCode = request.ProgramCode,
                    Email = request.UserData?.Email?.EmailAddress,
                    RequestId = request.RequestHeader.RequestId.ToString(),
                    LastFourSsn = string.IsNullOrEmpty(request.UserData?.Ssn)
                        ? null
                        : request.UserData?.Ssn.Substring(request.UserData.Ssn.Length - 4, 4),
                    SocialSecurityNumber = request.UserData?.Ssn,
                    Address =
                        new DisbursementAddress
                        {
                            Address1 = newUser.Addresses.FirstOrDefault()?.AddressLine1,
                            Address2 = newUser.Addresses.FirstOrDefault()?.AddressLine2,
                            City = newUser.Addresses.FirstOrDefault()?.City,
                            State = newUser.Addresses.FirstOrDefault()?.State,
                            ZipCode = newUser.Addresses.FirstOrDefault()?.ZipCode,
                            IsDefault = newUser.Addresses.FirstOrDefault()?.IsDefault ?? false
                        }
                });

                if (customerResponse != null
                    && customerResponse.ResponseDetails != null
                    && customerResponse.ResponseDetails[0].Code == 0)
                    return Task.FromResult(response);
                else
                {
                    return Task.FromResult(new SamplesEnrollmentResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            Message = customerResponse.ResponseDetails[0].Description,
                            StatusCode = customerResponse.ResponseDetails[0].Code,
                            SubStatusCode = customerResponse.ResponseDetails[0].SubCode
                        }
                    });
                }
            }
            Logger.Info($"Samples enrollment success, prospectId:{DomainContext.Current.ProspectIdentifier},prospectType:{DomainContext.Current.ProspectType},accountStatus:{accountResp.Account?.Status},activationStatus:{response.ActivationStatus}");

            // this this until we need this for multiple account holders
            response.KycStateData = null;

            return Task.FromResult(response);
        }
    }
}
