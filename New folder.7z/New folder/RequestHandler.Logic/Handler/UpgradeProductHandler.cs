﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class UpgradeProductHandler : CommandHandlerBase<UpgradeProductRequest, UpgradeProductResponse>
    {
        public UpgradeProductHandler(IAccountService accountService, IValidateIdentifier validateIdentifier)
        {
            _accountService = accountService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(UpgradeProductRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<UpgradeProductResponse> VerifyIdentifiers(UpgradeProductRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new UpgradeProductResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpgradeProductResponse>(e, request));
            }
        }

        public override Task<UpgradeProductResponse> Handle(UpgradeProductRequest request)
        {
            try
            {
                _accountService.UpgradeProduct(request.AccountIdentifier, request.ProgramCode, request.ProductMaterialType);
                var resp = new UpgradeProductResponse()
                {
                    ResponseHeader = ResponseHeader.SuccessForRequest(request.RequestHeader),
                };

                return Task.FromResult(resp);

            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpgradeProductResponse>(e, request));
            }
        }

        private readonly IAccountService _accountService;
        private readonly IValidateIdentifier _validateIdentifier;
    }
}
