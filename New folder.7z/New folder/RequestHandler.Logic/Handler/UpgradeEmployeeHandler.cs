﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using System;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Logic.Service;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using Gd.Bos.RequestHandler.Core.Application.UpgradeAccount;
using NLog;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class UpgradeEmployeeHandler : CommandHandlerBase<UpgradeEmployeeRequest, UpgradeEmployeeResponse>
    {
        private readonly IUpgradeAccountService _upgradeAccountService;
        private readonly ILockService _lockService;
        private readonly IValidateIdentifier _validateIdentifier;
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        public UpgradeEmployeeHandler(IUpgradeAccountService upgradeAccountService,
            IValidateIdentifier validateIdentifier,
            ILockService lockService
        )
        {
            _validateIdentifier = validateIdentifier;
            _upgradeAccountService = upgradeAccountService;
            _lockService = lockService;
        }

        public override void SetDomainContext(UpgradeEmployeeRequest request)
        {
            DomainContext.Current.IgnoreMfa = request.RequestHeader?.IgnoreMfa;
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<UpgradeEmployeeResponse> VerifyIdentifiers(UpgradeEmployeeRequest request)
        {
            _validateIdentifier.ValidateProgramCode(request.AccountIdentifier, DomainContext.Current.ProgramCode);
            return Task.FromResult(new UpgradeEmployeeResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override async Task<UpgradeEmployeeResponse> ObtainLock(UpgradeEmployeeRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock(OptionsContext.Current.GetString("requestId"));

                return new UpgradeEmployeeResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<UpgradeEmployeeResponse>(e, request);
            }
        }
        public override async Task<UpgradeEmployeeResponse> Handle(UpgradeEmployeeRequest request)
        {
            try
            {
                return _upgradeAccountService.UpgradeEmployee(request);
            }
            catch (Exception e)
            {
                return e.HandleException<UpgradeEmployeeResponse>(e, request);
            }
        }

        public override void ReleaseLock(UpgradeEmployeeRequest request)
        {
            _lockService.ReleaseApiLock(OptionsContext.Current.GetString("requestId"));
        }
    }
}