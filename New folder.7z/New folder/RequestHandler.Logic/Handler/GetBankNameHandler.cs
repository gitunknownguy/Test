﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using NLog;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetBankNameHandler : CommandHandlerBase<GetBankNameRequest, GetBankNameResponse>
    {
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        private readonly ITransferService _transferService;
        private readonly IValidateIdentifier _validateIdentifier;


        public GetBankNameHandler(ITransferService transferService, IValidateIdentifier validateIdentifier)
        {
            _transferService = transferService;
            _validateIdentifier = validateIdentifier;
        }
        public override void SetDomainContext(GetBankNameRequest request)
        {
            DomainContext.Current.ProgramCode = ProgramCode.FromString(request.ProgramCode);
        }

        public override Task<GetBankNameResponse> VerifyIdentifiers(GetBankNameRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetBankNameResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetBankNameResponse>(e, request));
            }
        }

        public override Task<GetBankNameResponse> Handle(GetBankNameRequest request)
        {
            GetBankNameResponse response;

            try
            {
                _logger.Info($"Start to get BankName for request {request.RequestHeader?.RequestId}");
                response = _transferService.GetBankName(request);
            }
            catch (Exception e)
            {
                _logger.Error(e, $"Error occured for request {request.RequestHeader?.RequestId}: Error : {e.Message}");
                response = e.HandleException<GetBankNameResponse>(e, request);
            }

            return Task.FromResult(response);
        }
    }
}
