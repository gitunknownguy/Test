﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RabbitMQ.Client.Impl;

namespace RequestHandler.Logic.Handler
{
    public class GetAuthCustomerSSOTokenHandler : CommandHandlerBase<GetAuthCustomerSSOTokenRequest, GetAuthCustomerSSOTokenResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IAccountService _accountService;

        public GetAuthCustomerSSOTokenHandler(IAccountService accountService, IValidateIdentifier validateIdentifier)
        {
            _accountService = accountService;
            _validateIdentifier = validateIdentifier;
        }
        public override void SetDomainContext(GetAuthCustomerSSOTokenRequest request)
        {
            if (!String.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;

        }

        public override Task<GetAuthCustomerSSOTokenResponse> VerifyIdentifiers(GetAuthCustomerSSOTokenRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetAuthCustomerSSOTokenResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetAuthCustomerSSOTokenResponse>(e, request));
            }
        }

        public override Task<GetAuthCustomerSSOTokenResponse> Handle(GetAuthCustomerSSOTokenRequest request)
        {
            try
            {

                if (request.RequestHeader.RequestId == Guid.Empty)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId, $"{nameof(request)}.RequestHeader.RequestId must be specified");
                }

                if (string.IsNullOrEmpty(request.AccountIdentifier) || request.AccountIdentifier == Guid.Empty.ToString())
                {
                    throw new RequestHandlerException(350, 0, $"The format of accountIdentifier is invalid.");
                }

                var result = _accountService.GetAuthCustomerSSOToken(request.RequestHeader.RequestId.ToString(),
                    request.AccountIdentifier, request.UserIdentifier, request.ProgramCode);


                return Task.FromResult(new GetAuthCustomerSSOTokenResponse()
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                    SsoToken = result.Item1,
                    CustomerId = result.Item2
                });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetAuthCustomerSSOTokenResponse>(e, request));
            }
        }
    }
}
