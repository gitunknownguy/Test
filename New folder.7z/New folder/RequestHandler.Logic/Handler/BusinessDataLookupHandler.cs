﻿using Amazon.SecretsManager.Model;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;
using System;

using System.Diagnostics.CodeAnalysis;

using System.Threading.Tasks;

namespace RequestHandler.Logic.Handler
{
    public class BusinessDataLookupHandler : CommandHandlerBase<BusinessDataLookupRequest, BusinessDataLookupResponse>
    {
        private readonly IBusinessDataLookupService _businessDataLookupService;
        private readonly IValidateIdentifier _validateIdentifier;

        public BusinessDataLookupHandler(IBusinessDataLookupService businessDataLookupService
       , IValidateIdentifier validateIdentifier)
        {
            _businessDataLookupService = businessDataLookupService;
            _validateIdentifier = validateIdentifier;

        }
        public override void SetDomainContext(BusinessDataLookupRequest request)
        {

        }
        public override Task<BusinessDataLookupResponse> VerifyIdentifiers(BusinessDataLookupRequest request)
        {

            return Task.FromResult(new BusinessDataLookupResponse()
            {

                ResponseHeader = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader
                {
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "",
                    ResponseId = request.RequestHeader.RequestId
                }

            });
        }
        public override Task<BusinessDataLookupResponse> Handle(BusinessDataLookupRequest request)
        {
            try
            {
                if (request == null)
                    throw new InvalidRequestException("Invalid Request.");
                if (string.IsNullOrEmpty(request.ProgramCode))
                    throw new ArgumentNullException($"ProgramCode: Program Code cannot be null or empty.");
                var info = _businessDataLookupService.GetBusinessDataLookupInfo(request);
                return Task.FromResult(info);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<BusinessDataLookupResponse>(e, request));
            }

        }
    }
}
