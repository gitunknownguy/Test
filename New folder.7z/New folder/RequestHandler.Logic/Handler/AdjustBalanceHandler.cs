﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Fraud.Api.Common.Exceptions;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using ValidationException = Gd.Bos.RequestHandler.Core.Infrastructure.ValidationException;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class AdjustBalanceHandler : CommandHandlerBase<AdjustBalanceRequest, AdjustBalanceResponse>
    {
        private static readonly string UnspecifiedGuid = Guid.Empty.ToString();

        public AdjustBalanceHandler(ITransferService transferService, IValidateIdentifier validateIdentifier)
        {
            _transferService = transferService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(AdjustBalanceRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<AdjustBalanceResponse> VerifyIdentifiers(AdjustBalanceRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new AdjustBalanceResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AdjustBalanceResponse>(e, request));
            }
        }

        public override Task<AdjustBalanceResponse> Handle(AdjustBalanceRequest request)
        {
            try
            {
                Tuple<TransferStatus, List<Account>> response = null;

                if (request.RequestHeader.RequestId == Guid.Empty)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId, $"{nameof(request)}.RequestHeader.RequestId must be specified");

                }

                if (string.IsNullOrEmpty(request.TransferIdentifier) || request.TransferIdentifier == UnspecifiedGuid)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier, $"{nameof(request)}.TransferIdentifier must be specified");
                }

                response = HandleAdjustBalance(request);

                return Task.FromResult(new AdjustBalanceResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                    TransferIdentifier = request.TransferIdentifier,
                    TransferStatus = response.Item1.ToString().ToLower(),
                    Accounts = response.Item2
                });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AdjustBalanceResponse>(e, request));
            }
        }

        private Tuple<TransferStatus, List<Account>> HandleAdjustBalance(AdjustBalanceRequest request)
        {
            TransferRequestValidation.HandleAdjustBalanceValidation(request);

            if (request.TransClass == "2-041" || request.TransClass == "10-027")
            {
                if (string.IsNullOrEmpty(request.ReferenceNumber) ||
                    !Guid.TryParse(request.ReferenceNumber, out Guid _))
                {
                    throw new ValidationException(3, 768, "Invalid wire identifier");
                }

                request.TransferIdentifier = request.ReferenceNumber;
            }

            if (string.IsNullOrEmpty(request.AccountBalanceIdentifier))
                return _transferService.TransferAdjustBalance(
                    request.ProgramCode,
                    request.TransferIdentifier,
                    request.AccountIdentifier,
                    request.Amount,
                    request.AllowNegativeBalance,
                    request.TransClass,
                    request.AdjustmentData,
                    request.Description,
                    request.SourceSystem,
                    request.SkipAccountStatusValidation);

            return _transferService.TransferAdjustPurseBalance(request.ProgramCode,
                request.TransferIdentifier,
                request.AccountIdentifier,
                request.AccountBalanceIdentifier,
                request.Amount,
                request.AllowNegativeBalance,
                request.TransClass,
                request.AdjustmentData,
                request.Description,
                request.SourceSystem,
                request.SkipAccountStatusValidation,
                request.TransactionReferenceId,
                request.SkipAccountStatusValidation);
        }

        private readonly ITransferService _transferService;
        private readonly IValidateIdentifier _validateIdentifier;
    }
}
