﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using RequestHandler.Core.Application;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class UpgradeEmvCardHandler : CommandHandlerBase<UpgradeEmvCardRequest, UpgradeEmvCardResponse>
    {
        public UpgradeEmvCardHandler(IPaymentInstrumentService paymentInstrumentService, ISampleCardService sampleCardService, IValidateIdentifier validateIdentifier)
        {
            _sampleCardService = sampleCardService;
            _validateIdentifier = validateIdentifier;
            _paymentInstrumentService = paymentInstrumentService;
        }

        public override void SetDomainContext(UpgradeEmvCardRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<UpgradeEmvCardResponse> VerifyIdentifiers(UpgradeEmvCardRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new UpgradeEmvCardResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpgradeEmvCardResponse>(e, request));
            }
        }

        public override Task<UpgradeEmvCardResponse> Handle(UpgradeEmvCardRequest request)
        {
            try
            {
                var paymentInfo =
                    _paymentInstrumentService.GetPaymentIdentifierInfoByAccountIdentifier(request.AccountIdentifier);
                var paymentIdentifierInfo = paymentInfo.Item2.FirstOrDefault(it =>
                    it.PaymentIdentifierStatus == PaymentIdentifierStatus.Activated);
                var paymentInstrumentInfo = paymentInfo.Item3.FirstOrDefault(it =>
                    it.PaymentInstrumentStatus == PaymentInstrumentStatus.Activated);
                if (paymentIdentifierInfo?.PaymentIdentifierIdentifier is null)
                {
                    return Task.FromResult(new UpgradeEmvCardResponse()
                    {
                        ResponseHeader = new ResponseHeader()
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 90001,
                            Message = "Not found account's paymentIdentifierIdentifier"
                        }
                    });
                }

                if (paymentInstrumentInfo?.PaymentInstrumentIdentifier is null)
                {
                    return Task.FromResult(new UpgradeEmvCardResponse()
                    {
                        ResponseHeader = new ResponseHeader()
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 90001,
                            Message = "Not found account's PaymentInstrumentIdentifier"
                        }
                    });
                }
                if (paymentInstrumentInfo?.PaymentInstrumentType != PaymentInstrumentType.MagStripe)
                {
                    return Task.FromResult(new UpgradeEmvCardResponse()
                    {
                        ResponseHeader = new ResponseHeader()
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 90001,
                            Message = $"Not mag card for PaymentInstrumentIdentifier {paymentInstrumentInfo?.PaymentInstrumentIdentifier}"
                        }
                    });
                }

                _sampleCardService.UpgradeToEmv(request.AccountIdentifier,
                    PaymentIdentifierIdentifier.FromString(paymentIdentifierInfo.PaymentIdentifierIdentifier
                        .ToString()),
                    PaymentInstrumentIdentifier.FromString(paymentInstrumentInfo.PaymentInstrumentIdentifier
                        .ToString()), request.ProgramCode);
                var resp = new UpgradeEmvCardResponse()
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        Message = "Success"
                    },
                };

                return Task.FromResult(resp);

            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpgradeEmvCardResponse>(e, request));
            }
        }

        private readonly ISampleCardService _sampleCardService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IPaymentInstrumentService _paymentInstrumentService;
    }
}
