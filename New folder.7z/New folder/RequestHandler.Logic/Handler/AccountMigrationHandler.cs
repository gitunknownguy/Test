﻿using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace RequestHandler.Logic.Handler
{
    public class AccountMigrationHandler : CommandHandlerBase<AccountMigrationRequest, AccountMigrationResponse>
    {
        private ISampleCardService _sampleCardService;

        public AccountMigrationHandler(ISampleCardService sampleCardService)
        {
            _sampleCardService = sampleCardService;
        }

        public override void SetDomainContext(AccountMigrationRequest request)
        {

        }

        public override Task<AccountMigrationResponse> Handle(AccountMigrationRequest request)
        {
            if (request.RequestHeader == null)
            {
                request.RequestHeader = new RequestHeader()
                {
                    RequestId = Guid.NewGuid()
                };
            }

            var response = new AccountMigrationResponse()
            {
                ResponseHeader = new ResponseHeader()
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                }
            };
            try
            {
                response = _sampleCardService.AccountMigration(request);
                return Task.FromResult(response);

            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AccountMigrationResponse>(e, request));
            }
        }

        public override Task<AccountMigrationResponse> VerifyIdentifiers(AccountMigrationRequest request)
        {
            if (string.IsNullOrEmpty(request?.ProspectIdentifier))
            {
                return Task.FromResult(new AccountMigrationResponse()
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        StatusCode = 601,
                        SubStatusCode = 0,
                        Message = $"Prospect record is not found for {request?.ProspectIdentifier}"
                    }
                });
            }

            return Task.FromResult(new AccountMigrationResponse()
            {
                ResponseHeader = new ResponseHeader()
            });
        }
    }
}
