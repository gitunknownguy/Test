﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using NLog;
using RequestHandler.Core.Domain.Services.RetailCard;
using Account = Gd.Bos.RequestHandler.Core.Domain.Model.Account.Account;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using VerifyPinRequest = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.VerifyPinRequest;
using VerifyPinResponse = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.VerifyPinResponse;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class VerifyPinHandler : CommandHandlerBase<VerifyPinRequest, VerifyPinResponse>
    {
        private readonly IPaymentInstrumentService _paymentInstrumentService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly INotificationService _notificationService;
        private readonly ILockService _lockService;
        private readonly IRetailCardService _retailCardService;
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        public VerifyPinHandler(IPaymentInstrumentService paymentInstrumentService, IValidateIdentifier validateIdentifier, INotificationService notificationService, ILockService lockService, IRetailCardService retailCardService)
        {
            _paymentInstrumentService = paymentInstrumentService;
            _validateIdentifier = validateIdentifier;
            _notificationService = notificationService;
            _lockService = lockService;
            _retailCardService = retailCardService;
        }

        public override void SetDomainContext(VerifyPinRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            if (!string.IsNullOrEmpty(request.PaymentInstrumentIdentifier))
                DomainContext.Current.PaymentInstrumentIdentifier = request.PaymentInstrumentIdentifier;
        }

        public override Task<VerifyPinResponse> VerifyIdentifiers(VerifyPinRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidatePaymentInstrumentIdentifier(DomainContext.Current.AccountIdentifier, DomainContext.Current.PaymentInstrumentIdentifier);
                _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 4, 105);
                return Task.FromResult(new VerifyPinResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<VerifyPinResponse>(e, request));
            }
        }

        public override async Task<VerifyPinResponse> ObtainLock(VerifyPinRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock("Card_" + DomainContext.Current.AccountIdentifier.ToString());
                return new VerifyPinResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<VerifyPinResponse>(e, request);
            }
        }

        public override Task<VerifyPinResponse> Handle(VerifyPinRequest request)
        {
            try
            {
                var isPinValid = _paymentInstrumentService.VerifyPin(request.AccountIdentifier, request.PaymentInstrumentIdentifier,
                    request.Pin, request.ProgramCode);


                var response = new VerifyPinResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                    IsPinValid = isPinValid
                };

                return Task.FromResult(response);

            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<VerifyPinResponse>(e, request));
            }
        }

        public override void ReleaseLock(VerifyPinRequest request)
        {
            _lockService.ReleaseApiLock("Card_" + DomainContext.Current.AccountIdentifier.ToString());
        }

    }
}