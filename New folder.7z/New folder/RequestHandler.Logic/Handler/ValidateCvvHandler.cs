﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using NLog;
using RequestHandler.Core.Domain.Services.RetailCard;

namespace Gd.Bos.RequestHandler.Logic.Handler
{

    public class ValidateCvvHandler : CommandHandlerBase<ValidateCvvRequest, ValidateCvvResponse>
    {
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();
        private readonly IPaymentInstrumentService _paymentInstrumentService;
        private readonly IRetailCardService _retailCardService;
        private readonly IAccountService _accountService;
        private readonly IValidateIdentifier _validateIdentifier;
        
        public ValidateCvvHandler(
            IPaymentInstrumentService paymentInstrumentService, 
            IValidateIdentifier validateIdentifier, 
            IRetailCardService retailCardService, 
            IAccountService accountService)
        {
            _paymentInstrumentService = paymentInstrumentService;
            _validateIdentifier = validateIdentifier;
            _retailCardService = retailCardService;
            _accountService = accountService;
        }

        public override void SetDomainContext(ValidateCvvRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            if (!string.IsNullOrEmpty(request.Pan))
                DomainContext.Current.PlainTextPAN = request.Pan;
        }

        public override Task<ValidateCvvResponse> VerifyIdentifiers(ValidateCvvRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);

                if (CanValidateAccountClosed(request))
                {
                    _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 4, 105);
                }
                
                _validateIdentifier.ValidatePAN(DomainContext.Current.AccountIdentifier, DomainContext.Current.PlainTextPAN);
                return Task.FromResult(new ValidateCvvResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (AccountValidationException avex)
            {
                return Task.FromResult(new ValidateCvvResponse()
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = avex.Code,
                        SubStatusCode = avex.SubCode,
                        Message = avex.Message,
                        Details = avex.ToString()
                    },
                    ActivationStatus = avex.ActivationStatus,
                    IsDOBVerified = null,
                    IsDOBMatched = null,
                    AccountIdentifier = avex.AccountIdentifier,
                    PaymentInstrumentIdentifier = avex.PaymentInstrumentIdentifier
                });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<ValidateCvvResponse>(e, request));
            }
        }

        private bool CanValidateAccountClosed(ValidateCvvRequest request)
        {
            var bypassErrorOnClosedAccount = request?.RequestHeader?.Options?.FirstOrDefault(a => "X-GD-BypassErrorOnClosedAccount".Equals(a.Key, StringComparison.OrdinalIgnoreCase)).Value;
            if (bypassErrorOnClosedAccount != null) return bypassErrorOnClosedAccount.ToLower() == "false";
            return true;
        }

        public override Task<ValidateCvvResponse> Handle(ValidateCvvRequest request)
        {
            try
            {
                ValidateCvvResponse response = null;

                var isRetailCard = IsRetailBin(request?.Pan, request?.ProgramCode);

                var isFetchingAccountIdentifier = string.IsNullOrEmpty(request.ProgramCode);

                if (isFetchingAccountIdentifier || !isRetailCard)
                {
                    //Default Flow
                    response = _paymentInstrumentService.ValidateCard(request);
                }
                
                if (!isRetailCard && response?.IsRetailCard == true
                                 && response.ResponseHeader.StatusCode == -1)
                {
                    isRetailCard = true;
                    request.Pan = response.ResponseHeader.Details;
                }
                
                if (!isFetchingAccountIdentifier && isRetailCard)
                {
                    //Retail Card Flow
                    response = _retailCardService.ValidateCard(request);
                }
                
                
                if (!string.IsNullOrEmpty(response.AccountIdentifier))
                {
                    var userProfileIdentities = _paymentInstrumentService.GetUserProfileIdentities(response.AccountIdentifier);
                    
                    if (userProfileIdentities.Count > 0)
                    {
                        var identityTypes = new System.Collections.Generic.List<Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.IdentityTypes>();

                        foreach (var userProfileIdentity in userProfileIdentities)
                        {
                            identityTypes.Add(new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.IdentityTypes()
                            {
                                IdentityType = userProfileIdentity.IdentityType,
                                CreatedDateTime = userProfileIdentity.CreateDateUtc.UtcDateTime,
                                CountryCode = userProfileIdentity.CountryCode
                            });
                        }

                        response.IdentityTypes = identityTypes.OrderByDescending(a => a.CreatedDateTime).ToArray();
                    }
                }

                response.IsDirectSignUp = IsDirectSignUpCard(request.RequestHeader.RequestId, response.ProgramCode, response.AccountIdentifier);
                
                return Task.FromResult(response);

            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<ValidateCvvResponse>(e, request));
            }
        }

        private bool IsRetailBin(string pan, string programCode)
        {

            if (pan == null || pan.Length <= 12) return false; //we expect full PAN for retail card and to extract bin

            // _paymentInstrumentService.GetBinByPan(pan);// pan.Substring(0, 6);
            
            if (string.IsNullOrWhiteSpace(Configuration.Current.RetailCardLegacyTempBin))
            {
                return false;
            }
            var tempBins = Configuration.Current.RetailCardLegacyTempBin.Split(",");
            foreach (var tempBin in tempBins)
            {
                var index = tempBin.IndexOf(":", StringComparison.Ordinal);
                if (index == -1)
                {
                    continue;
                }
                var bin = tempBin.Substring(0, index);
                var programCodes = tempBin.Substring(index + 1);
                if (pan.StartsWith(bin, StringComparison.InvariantCultureIgnoreCase) &&
                    (programCode == null || programCodes.ToLowerInvariant().Contains(programCode.ToLowerInvariant())))
                {
                    return true;
                }
            }

            return false;

        }

        /// <summary>
        /// Get whether the card is a direct sign-up card based on the account identifier
        /// Configuration for the specific program and productTier needs to be added.
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="programCode"></param>
        /// <param name="accountIdentifier"></param>
        /// <returns>True/False is there is configuration for the program. Null otherwise</returns>
        [ExcludeFromCodeCoverage(Justification = "Tested in main method")]
        private bool? IsDirectSignUpCard(Guid requestId, string programCode, string accountIdentifier)
        {
            if (string.IsNullOrWhiteSpace(accountIdentifier) || string.IsNullOrEmpty(programCode))
            {
                Logger.Info("[{RequestId}] No values provided for IsDirectSignUp", requestId);
                return null;
            }

            programCode = programCode.ToLowerInvariant();

            try
            {
                var directSignUpProductTypes = Configuration.Current.DirectSignUpProductTypes;
                if (string.IsNullOrWhiteSpace(directSignUpProductTypes))
                {
                    Logger.Info("[{RequestId}] Configuration 'DirectSignUpProductTypes' not found", requestId);
                    return null;
                }

                var account = _accountService.GetAccount(accountIdentifier);
                // only return a value when the specific configuration for the program is found
                var foundProgramConfiguration = false;
                var isDirectSignUp = false; 
                
                foreach (var type in directSignUpProductTypes.Split(","))
                {
                    var index = type.IndexOf(":", StringComparison.Ordinal);
                    if (index == -1)
                        continue;

                    var productTierKey = type[..index];
                    var programCodes = type[(index + 1)..].ToLowerInvariant();

                    if (!programCodes.Contains(programCode))
                        continue;

                    Logger.Info("[{RequestId}] DirectSignUpProductTypes configuration found for program", requestId);
                    foundProgramConfiguration = true;

                    if (!int.TryParse(productTierKey, out var key))
                    {
                        Logger.Info("[{RequestId}] DirectSignUpProductTypes could not parse ProductTierKey {ProductTierKey}", requestId, productTierKey);
                        continue;
                    }
                        

                    if (key != account.ProductTierKey)
                        continue;

                    isDirectSignUp = true;
                    break; // No need to check further, we found a match
                }

                if (foundProgramConfiguration)
                {
                    Logger.Info("[{RequestId}] IsDirectSignUp: {IsDirectSignUp}", requestId, isDirectSignUp);
                    return isDirectSignUp;
                }

                Logger.Info("[{RequestId}] DirectSignUpProductTypes configuration NOT found for program", requestId);
                return null;
            }
            catch (Exception e)
            {
                Logger.Error(e, "[{RequestId}] IsDirectSignUpCard error: {Message}", requestId, e.Message);
                return null;
            }
        }
    }
}
