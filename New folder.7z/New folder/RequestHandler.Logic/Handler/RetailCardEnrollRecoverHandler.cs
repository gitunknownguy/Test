﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Core.Common.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Domain.Model.Inventory;

namespace RequestHandler.Logic.Handler
{
    public class RetailCardEnrollRecoverHandler : CommandHandlerBase<RetailCardEnrollmentRecoverRequest, RetailCardEnrollmentResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IRetailCardEnrollService _retailCardEnrollService;
        private readonly ILazyCache _lazyCache;
        private readonly IEnrollmentDataAccess _enrollmentDataAccess;
        private readonly IRetailCardBosEnrollService _retailCardBosEnrollService;
        private readonly IProductRepository _productRepository;
        private readonly IInstantIssueCardInventoryRepository _instantIssueCardInventoryRepository;

        public RetailCardEnrollRecoverHandler(IValidateIdentifier validateIdentifier, IRetailCardEnrollService retailCardEnrollService,
            ILazyCache lazyCache, IEnrollmentDataAccess enrollmentDataAccess,
            IRetailCardBosEnrollService retailCardBosEnrollService,
            IProductRepository productRepository,
            IInstantIssueCardInventoryRepository instantIssueCardInventoryRepository)
        {
            _validateIdentifier = validateIdentifier;
            _retailCardEnrollService = retailCardEnrollService;
            _lazyCache = lazyCache;
            _enrollmentDataAccess = enrollmentDataAccess;
            _retailCardBosEnrollService = retailCardBosEnrollService;
            _productRepository = productRepository;
            _instantIssueCardInventoryRepository = instantIssueCardInventoryRepository;
        }

        public override void SetDomainContext(RetailCardEnrollmentRecoverRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<RetailCardEnrollmentResponse> VerifyIdentifiers(RetailCardEnrollmentRecoverRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier,
                    DomainContext.Current.ProgramCode);
                return Task.FromResult(new RetailCardEnrollmentResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<RetailCardEnrollmentResponse>(e, request));
            }
        }

        public override Task<RetailCardEnrollmentResponse> Handle(RetailCardEnrollmentRecoverRequest request)
        {
            try
            {
                DateTime dob = DateTime.Parse(request.DateOfBirth);
                var getEnrollmentResponse = _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(request.AccountIdentifier, request.ProgramCode, true);

                Tuple<Account, User, PaymentIdentifier, AccountBalance, PrivateCardData> enrollResponse = null;
                if (IsGbosRetailCard(request.AccountIdentifier))
                {
                    enrollResponse = _retailCardBosEnrollService.EnrollRecover(getEnrollmentResponse, request.ProgramCode,
                        request.RequestHeader.RequestId, dob, request.Last4Ssn, request.FraudData, request.RequestTempCardOnly);
                }
                else
                {
                    enrollResponse = _retailCardEnrollService.EnrollRecover(getEnrollmentResponse, request.ProgramCode,
                        request.RequestHeader.RequestId, dob, request.Last4Ssn, request.FraudData);
                }
                

                if (enrollResponse.Item1.ErrorCode == 11005577)
                {
                    var existingResponse = new RetailCardEnrollmentResponse()
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 0,
                            SubStatusCode = 0,
                            Message = "Success"
                        },
                        AccountIdentifier = getEnrollmentResponse.Account.AccountIdentifier,
                        AccountReferenceNumber = getEnrollmentResponse.Account.CustomerReferenceNumber,
                        Status = getEnrollmentResponse.Account.Status,
                        StatusReasons = getEnrollmentResponse.Account.StatusReasons,
                        StatusCure = getEnrollmentResponse.Account.StatusCure,
                        DirectDepositInformation = getEnrollmentResponse.Account.DirectDepositInformation,
                        Purses = getEnrollmentResponse.Account.Purses,
                        AccountHolders = getEnrollmentResponse.Account.AccountHolders,
                        AccountStatusChangedDateTime = getEnrollmentResponse.Account?.AccountStatusChangedDateTime,
                        AccountCycleDay = getEnrollmentResponse.Account.AccountCycleDay
                    };
                    var errorCode = _lazyCache?.Value?.Get<string>(request.RequestHeader?.RequestId.ToString());

                    if (!string.IsNullOrEmpty(errorCode))
                        existingResponse.ResponseHeader = existingResponse.ResponseHeader?.GetResponseHeader(errorCode, request.RequestHeader.RequestId);

                    return Task.FromResult(existingResponse);
                }

                var rtlExtn = new RetailEnrollmentExtensions(_lazyCache, _enrollmentDataAccess);
                var response = rtlExtn.GenerateRetailCardEnrollmentResponse(request, enrollResponse, NpNrReason.GoodStanding, null);

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<RetailCardEnrollmentResponse>(e, request));
            }
        }
        
        private bool IsGbosRetailCard(string accountIdentifier)
        {
            var cardExternalId = _instantIssueCardInventoryRepository.GetInstantIssueCardInventoryByAccountIdentifier(
                Guid.Parse(accountIdentifier));

            return !string.IsNullOrEmpty(cardExternalId);
        }
    }
}
