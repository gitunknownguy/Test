﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;

using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.BillPay;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class BillPayeeSearchPayeeHandler : CommandHandlerBase<BillPaySearchPayeeRequest, BillPaySearchPayeeResponse>
    {
        private readonly IBillPayService _billPayService;
        public BillPayeeSearchPayeeHandler(IBillPayService billPayService)
        {
            _billPayService = billPayService;
        }
        public override void SetDomainContext(BillPaySearchPayeeRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<BillPaySearchPayeeResponse> VerifyIdentifiers(BillPaySearchPayeeRequest request)
        {
            return Task.FromResult(new BillPaySearchPayeeResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<BillPaySearchPayeeResponse> Handle(BillPaySearchPayeeRequest request)
        {
            try
            {
                var response = _billPayService.SearchPayees(new SearchPayeesRequest() { Name = request.Name }, request.ProgramCode, request.AccountIdentifier);

                var result = default(BillPaySearchPayeeResponse);
                if (response?.ErrorCode == "0")
                {
                    var payees = new List<Payee>();
                    if (response != null)
                    {
                        foreach (PayeeSearch payeeSearch in response.Payees)
                        {
                            payees.Add(new Payee()
                            {
                                Name = payeeSearch.Name,
                                MerchantId = payeeSearch.MerchantId,
                                MerchantZipRequired = payeeSearch.MerchantZipRequired,
                                Address = new Address()
                                {
                                    AddressLine1 = payeeSearch.Address1,
                                    AddressLine2 = payeeSearch.Address2,
                                    City = payeeSearch.City,
                                    State = payeeSearch.State,
                                    ZipCode = payeeSearch.Zip,
                                    CountryCode = payeeSearch.Country,
                                }
                            });
                        }
                    }

                    result = new BillPaySearchPayeeResponse()
                    {
                        Payees = payees,
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 0,
                            SubStatusCode = 0,
                            Message = "success"
                        },
                    };
                }
                else
                {
                    result = new BillPaySearchPayeeResponse()
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            SubStatusCode = 0,
                            Message = response.ErrorMessage
                        },
                    };
                    if (!string.IsNullOrEmpty(response.ErrorCode) && int.TryParse(response.ErrorCode, out var tempErrorCode))
                    {
                        result.ResponseHeader.StatusCode = tempErrorCode;
                    }
                    else
                    {
                        result.ResponseHeader.StatusCode = 0; //Default
                    }
                }

                return Task.FromResult(result);
            }
            catch (Exception ex)
            {
                return Task.FromResult(ex.HandleException<BillPaySearchPayeeResponse>(ex, request));
            }
        }
    }
}
