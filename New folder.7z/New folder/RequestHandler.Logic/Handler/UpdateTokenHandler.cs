﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class UpdateTokenHandler : CommandHandlerBase<UpdateTokenRequest, UpdateTokenResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IPaymentInstrumentService _paymentInstrumentService;

        public UpdateTokenHandler(IValidateIdentifier validateIdentifier, IPaymentInstrumentService paymentInstrumentService)
        {
            _validateIdentifier = validateIdentifier;
            _paymentInstrumentService = paymentInstrumentService;
        }
        public override void SetDomainContext(UpdateTokenRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<UpdateTokenResponse> VerifyIdentifiers(UpdateTokenRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new UpdateTokenResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpdateTokenResponse>(e, request));
            }
        }

        public override Task<UpdateTokenResponse> Handle(UpdateTokenRequest request)
        {
            try
            {
                var updateTokenResponse = _paymentInstrumentService.UpdateToken(request.AccountIdentifier, request.TokenId,
                     request.TokenAction,
                     request.Comment);

                updateTokenResponse.ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                };
                return Task.FromResult(updateTokenResponse);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpdateTokenResponse>(e, request));
            }
        }
    }
}
