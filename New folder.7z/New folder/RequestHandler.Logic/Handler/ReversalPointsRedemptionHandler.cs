﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.PointsSystem;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class ReversalPointsRedemptionHandler : CommandHandlerBase<ReversalPointsRedemptionRequest, ReversalPointsRedemptionResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IPointsSystemService _pointsSystemService;

        public ReversalPointsRedemptionHandler(IPointsSystemService pointsSystemService, IValidateIdentifier validateIdentifier)
        {
            _pointsSystemService = pointsSystemService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(ReversalPointsRedemptionRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<ReversalPointsRedemptionResponse> VerifyIdentifiers(ReversalPointsRedemptionRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new ReversalPointsRedemptionResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<ReversalPointsRedemptionResponse>(e, request));
            }
        }

        public override Task<ReversalPointsRedemptionResponse> Handle(ReversalPointsRedemptionRequest request)
        {
            try
            {
                var response = _pointsSystemService.ReversalPointsRedemption(request);

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<ReversalPointsRedemptionResponse>(e, request));
            }
        }
    }
}
