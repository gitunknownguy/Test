﻿using System;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transactions;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;

namespace RequestHandler.Logic.Handler
{
    public class GetAccountFeesHandler : CommandHandlerBase<GetAccountFeesRequest, GetAccountFeesResponse>
    {
        private readonly ITransactionsRepository _transactionsRepository;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IAccountService _accountService;

        public GetAccountFeesHandler(ITransactionsRepository transactionsRepository, IValidateIdentifier validateIdentifier, IAccountService accountService)
        {
            _transactionsRepository = transactionsRepository;
            _validateIdentifier = validateIdentifier;
            _accountService = accountService;
        }

        public override void SetDomainContext(GetAccountFeesRequest request)
        {
            DomainContext.Current.ProgramCode = ProgramCode.FromString(request.ProgramCode);
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetAccountFeesResponse> VerifyIdentifiers(GetAccountFeesRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetAccountFeesResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetAccountFeesResponse>(e, request));
            }
        }

        public override Task<GetAccountFeesResponse> Handle(GetAccountFeesRequest request)
        {
            try
            {
                if (!_accountService.IsAccountFeesAllowedForAccount(request.ProgramCode, request.AccountIdentifier))
                {
                    var err = new GetAccountFeesResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 4610,
                            SubStatusCode = 4611,
                            Message = "PRODUCT_NOT_SUPPORT_FEE"
                        },
                    };
                    return Task.FromResult(err);
                }

                var priorMonthFees = _transactionsRepository.GetAccountPreviousMonthFees(Guid.Parse(request.AccountIdentifier));

                var yearToDateFees =
                    _accountService.GetYearToDateFeeForAccount(request.RequestHeader.RequestId, request.ProgramCode, request.AccountIdentifier);

                var response = new GetAccountFeesResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                    PriorMonthFee = priorMonthFees,
                    YearToDateFee = yearToDateFees
                };

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetAccountFeesResponse>(e, request));
            }
        }
    }
}
