﻿using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Domain.Model.User;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RequestHandler.Logic.Handler
{
    internal class ValidateIdentityHandler : CommandHandlerBase<ValidateIdentityRequest, ValidateIdentityResponse>
    {
        private readonly IUserService _userService;
        private readonly IValidateIdentifier _validateIdentifier;

        public ValidateIdentityHandler(IUserService userService,
            IValidateIdentifier validateIdentifier)
        {
            _userService = userService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(ValidateIdentityRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<ValidateIdentityResponse> VerifyIdentifiers(ValidateIdentityRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new ValidateIdentityResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<ValidateIdentityResponse>(e, request));
            }
        }

        public override Task<ValidateIdentityResponse> Handle(ValidateIdentityRequest request)
        {
            ValidateIdentityResult result;
            ValidateIdentityResponse response = new ValidateIdentityResponse();
            try
            {
                result = _userService.ValidateIdentity(request.ProgramCode, request.AccountIdentifier, request.UserIdentifier, request.IdentityHashCode);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<ValidateIdentityResponse>(e, request));
            }

            response.MismatchCount = result.MismatchCount;
            if (result.IsMatch)
            {
                response.ResponseHeader = new ResponseHeader()
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                };
            }
            else
            {
                response.ResponseHeader = new ResponseHeader()
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 760,
                    SubStatusCode = 1001,
                    Message = "Invalid Identity"
                };
            }

            return Task.FromResult(response);
        }
    }
}
