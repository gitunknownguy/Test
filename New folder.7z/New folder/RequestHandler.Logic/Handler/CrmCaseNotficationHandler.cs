﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class CrmCaseNotificationHandler : CommandHandlerBase<CrmNotificationToPartnerRequest, CrmNotificationToPartnerResponse>
    {
        private readonly INotificationService _notificationPublisher;
        public CrmCaseNotificationHandler(IValidateIdentifier validateIdentifier,
                                           INotificationService notificationPublisher)
        {
            _validateIdentifier = validateIdentifier;
            _notificationPublisher = notificationPublisher;

        }

        public override void SetDomainContext(CrmNotificationToPartnerRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<CrmNotificationToPartnerResponse> VerifyIdentifiers(CrmNotificationToPartnerRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new CrmNotificationToPartnerResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CrmNotificationToPartnerResponse>(e, request));
            }
        }

        public override Task<CrmNotificationToPartnerResponse> Handle(CrmNotificationToPartnerRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.CreatedDate))
                    request.CreatedDate = DateTime
                        .Parse(DateTime.UtcNow.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'")).ToUniversalTime().ToShortDateString();

                if (!request.IsUpdate.Equals("update", StringComparison.InvariantCultureIgnoreCase))
                {
                    request.IsUpdate = null;
                    _notificationPublisher.PublishCrmNotification(request.ProgramCode, request, EventType.postCrmCase);
                }
                else
                {
                    request.IsUpdate = null;
                    _notificationPublisher.PublishCrmNotification(request.ProgramCode, request,
                        EventType.updateCrmCase);
                }


                var response = new CrmNotificationToPartnerResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                };

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CrmNotificationToPartnerResponse>(e, request));
            }
        }

        private readonly IValidateIdentifier _validateIdentifier;

    }
}
