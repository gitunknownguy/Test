﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Services.CareSharedApi;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using NLog;
using RequestHandler.Core.Domain.Services.TokenManagementService;
using RequestHandler.Core.Domain.Services.TokenManagementService.EventMessage;
using IServiceBusNotificationPublisher = RequestHandler.Core.Domain.Services.AzureServiceBus.IServiceBusNotificationPublisher;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using UserProfile = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.UserProfile;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class UpdateUserNameHandler : CommandHandlerBase<UpdateUserNameRequest, UpdateUserNameResponse>
    {
        private readonly IPaymentInstrumentService _paymentInstrumentService;
        private readonly INotificationService _notificationPublisher;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ICareSharedApiService _careSharedApiService;
        private readonly IAccountRepository _accountRepository;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        private readonly ITokenManagementService _tokenManagementService;

        public UpdateUserNameHandler(IPaymentInstrumentService paymentInstrumentService,
            INotificationService notificationPublisher,
            IValidateIdentifier validateIdentifier,
            ICareSharedApiService careSharedApiService,
            IAccountRepository accountRepository, 
            ITokenManagementService tokenManagementService)
        {
            _paymentInstrumentService = paymentInstrumentService;
            _notificationPublisher = notificationPublisher;
            _validateIdentifier = validateIdentifier;
            _careSharedApiService = careSharedApiService;
            _accountRepository = accountRepository;
            _tokenManagementService = tokenManagementService;
        }

        public override void SetDomainContext(UpdateUserNameRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<UpdateUserNameResponse> VerifyIdentifiers(UpdateUserNameRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new UpdateUserNameResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpdateUserNameResponse>(e, request));
            }
        }

        public override async Task<UpdateUserNameResponse> Handle(UpdateUserNameRequest request)
        {

            UserName name = new UserName(request?.ProfileData?.FirstName, request?.ProfileData?.MiddleName, request?.ProfileData?.LastName);

            if (name.FirstName == null && name.LastName == null)
                name = null;

            try
            {
                _paymentInstrumentService.UpdateUserNameAndReIssueCard(name, AccountIdentifier.FromString(request?.AccountIdentifier), UserIdentifier.FromString(request?.UserIdentifier), request.ProgramCode);

                await _tokenManagementService.PublishUserProfileUpdatedMessageAsync(request.RequestHeader.RequestId,
                    request.ProgramCode,
                    new UserProfileUpdatedMessage
                    {
                        FirstName = request?.ProfileData?.FirstName,
                        LastName = request?.ProfileData?.LastName,
                        AccountIdentifier = request.AccountIdentifier,
                        ProgramCode = request.ProgramCode
                    });
            }
            catch (Exception e)
            {
                return e.HandleException<UpdateUserNameResponse>(e, request);
            }

            CreateCareCase(request, name);

            var response = new UpdateUserNameResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                },
            };

            UserProfile updatedName = new UserProfile
            {
                AccountIdentifier = request.AccountIdentifier,
                UserIdentifier = request.UserIdentifier,
                ProfileData = new ProfileData
                {
                    FirstName = name?.FirstName,
                    LastName = name?.LastName,
                    MiddleName = name?.MiddleName,
                    LastUpdatedDateTime = DateTime.Parse(DateTime.UtcNow.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'")).ToUniversalTime()
                }
            };

            if (!request.ProgramCode.Equals(Configuration.Current.GBRProgramCode, StringComparison.OrdinalIgnoreCase))
            {
                _notificationPublisher.PublishNotification(request.ProgramCode, updatedName, EventType.UserUpdate);
            }
            return response;
        }


        private string GetFullName(UserName name)
        {
            var fullName = "";

            if (!string.IsNullOrWhiteSpace(name?.FirstName))
            {
                fullName = name.FirstName;
            }

            if (!string.IsNullOrWhiteSpace(name?.MiddleName))
            {
                fullName = !string.IsNullOrWhiteSpace(fullName) ? $"{fullName} {name.MiddleName}" : name.MiddleName;
            }

            if (!string.IsNullOrWhiteSpace(name?.LastName))
            {
                fullName = !string.IsNullOrWhiteSpace(fullName) ? $"{fullName} {name.LastName}" : name.LastName;
            }

            return fullName;
        }

        private void CreateCareCase(UpdateUserNameRequest request, UserName name)
        {
            try
            {
                var consumer = _accountRepository.GetAccountPrimaryConsumerProfile(AccountIdentifier.FromString(request.AccountIdentifier));
                var address = request.ProfileData?.Addresses?.FirstOrDefault();

                _careSharedApiService.CreateNameChangeCareCase(new NameChangeCareCaseRequest
                {
                    RecordType = "Correspondence_Name_Change",
                    AccountIdentifier = request.AccountIdentifier,
                    Status = "Closed",
                    City__c = address?.City ?? "N/A",
                    State__c = address?.State ?? "N/A",
                    Street__c = address?.AddressLine1 ?? "N/A",
                    MailingAptSuite__c = address?.AddressLine2 ?? "N/A",
                    Zip__c = address?.ZipCode ?? "N/A",
                    Change_Name_to_First_Name__c = name?.FirstName,
                    Change_Name_to_Last_Name__c = name?.LastName,
                    Request_Channel__c = "Partner",
                    CustomerName__c = GetFullName(name),
                    Consumer_Profile_Key__c = consumer.ConsumerProfileKey.ToString()
                });
            }
            catch (Exception e)
            {
                _logger.Error(e, $"Correspondence_Name_Change create case failed for AccountIdentifier:{request.AccountIdentifier}. Message:{e.Message}");
            }
        }
    }
}
