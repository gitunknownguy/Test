﻿using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System;
using System.Threading.Tasks;
using NLog;
using RequestHandler.Core.Domain.Services.GlobalFundTransfer;
using RequestHandler.Core.Domain.Services.GlobalFundTransfer.Contracts;
using Address = RequestHandler.Core.Domain.Services.GlobalFundTransfer.Contracts.Address;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.GFTCustomers;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.GFTCustomers;
using System.Linq;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Common;

namespace RequestHandler.Logic.Handler
{
    public class GFTCustomersCreateCustomerProfileHandler : CommandHandlerBase<GFTCustomersCreateCustomerProfileRequest, GFTCustomersCreateCustomerProfileResponse>
    {
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        private readonly IGlobalFundTransferService _globalFundTransferService;
        private readonly IPaymentInstrumentService _paymentInstrumentService;
        private readonly IBaasConfiguration _baasConfiguration;

        public GFTCustomersCreateCustomerProfileHandler(IGlobalFundTransferService globalFundTransferService, IPaymentInstrumentService paymentInstrumentService, IBaasConfiguration baasConfiguration)
        {
            _globalFundTransferService = globalFundTransferService;
            _paymentInstrumentService = paymentInstrumentService;
            _baasConfiguration = baasConfiguration;
        }

        public override void SetDomainContext(GFTCustomersCreateCustomerProfileRequest request)
        {
        }

        public override Task<GFTCustomersCreateCustomerProfileResponse> VerifyIdentifiers(GFTCustomersCreateCustomerProfileRequest request)
        {
            try
            {
                return Task.FromResult(new GFTCustomersCreateCustomerProfileResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GFTCustomersCreateCustomerProfileResponse>(e, request));
            }
        }

        public override Task<GFTCustomersCreateCustomerProfileResponse> Handle(GFTCustomersCreateCustomerProfileRequest request)
        {
            try
            {
                if (!GFTCustomerTokenMapping.IsValidCustomerType(request.CustomerType))
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier, $"{nameof(request)}.Customer type is invalid");
                }

                bool needBaasAccount = false;
                string bin = null;
                string last4Pan = null;

                if (GFTCustomerTokenMapping.CUSTOMER_TYPE_BAAS.Equals(request.CustomerType))
                {
                    (needBaasAccount, bin, last4Pan) = GetBaasAccount(request.RequestHeader.RequestId, request.ProgramCode, request.CustomerToken);
                }

                CreateCustomerProfileRequest createCustomerProfileRequest = new CreateCustomerProfileRequest
                {
                    FirstName = request.FirstName,
                    LastName = request.LastName,
                    MiddleName = request.MiddleName,
                    Email = request.Email,
                    PhoneNumber = request.PhoneNumber,
                    DateOfBirth = request.DateOfBirth,
                    ProgramCode = request.ProgramCode,
                    Address = new Address
                    {
                        AddressLine1 = request.Address.AddressLine1,
                        AddressLine2 = request.Address.AddressLine2,
                        City = request.Address.City,
                        State = request.Address.State,
                        ZipCode = request.Address.ZipCode
                    },
                    CustomerToken = request.CustomerToken,
                    RequestId = request.RequestHeader.RequestId.ToString()
                };

                if (needBaasAccount)
                {
                    createCustomerProfileRequest.BaasAccount = new BaasAccount()
                    {
                        AccountIdentifier = request.CustomerToken,
                        Bin = bin,
                        Last4PAN = last4Pan
                    };
                }

                var createCustomerProfileResponse = _globalFundTransferService.CreateCustomerProfile(createCustomerProfileRequest);

                if (createCustomerProfileResponse == null || createCustomerProfileResponse.ResponseDetails == null)
                    throw new RequestHandlerException(0, 404, "createCustomerProfileResponse is null");

                GFTCustomersCreateCustomerProfileResponse response = new GFTCustomersCreateCustomerProfileResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                    Status = createCustomerProfileResponse.Customer?.Status,
                    CustomerToken = createCustomerProfileResponse.Customer?.CustomerToken,
                    CustomerType = request.CustomerType,
                };

                if (createCustomerProfileResponse.ResponseDetails.Any())
                {
                    var firstDetail = createCustomerProfileResponse.ResponseDetails.First();

                    if (string.Compare(firstDetail.Description, "success", StringComparison.OrdinalIgnoreCase) != 0)
                    {
                        response.ResponseHeader.Message = firstDetail.Description;
                        response.ResponseHeader.Details = firstDetail.Description;
                        response.ResponseHeader.StatusCode = firstDetail.Code;
                        response.ResponseHeader.SubStatusCode = firstDetail.SubCode;
                    }
                }
                else
                {
                    response.ResponseHeader.Message = "Unknown Error";
                    response.ResponseHeader.Details = "Unknown Error";
                    response.ResponseHeader.StatusCode = 4214;
                    response.ResponseHeader.SubStatusCode = 1514;
                }

                return Task.FromResult(response);
            }

            catch (InvalidProductMaterialException e)
            {
                var response = new GFTCustomersCreateCustomerProfileResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 4,
                        SubStatusCode = 312,
                        Message = e.Message
                    },
                };
                return Task.FromResult(response);
            }
            catch (PaymentInstrumentNotFoundException e)
            {
                var response = new GFTCustomersCreateCustomerProfileResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 4601,
                        SubStatusCode = 0,
                        Message = "Can not create customer profile as missing source account data."
                    },
                };
                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                var eResult = e.HandleException<GFTCustomersCreateCustomerProfileResponse>(e, request);

                Logger.Info($"post CreateCustomerProfile failure, prospectId:{DomainContext.Current.ProspectIdentifier},prospectType:{DomainContext.Current.ProspectType},statusCode:{eResult.ResponseHeader.StatusCode},subStatusCode:{eResult.ResponseHeader.SubStatusCode},statusMessage:{eResult.ResponseHeader.Message},statusDetails:{eResult.ResponseHeader.Details}");
                return Task.FromResult(eResult);
            }
        }

        private (bool needBaasAccount, string bin, string Last4Pan) GetBaasAccount(Guid requestId, string programCode, string accountIdentifier)
        {
            try
            {
                if (!_baasConfiguration.NeedBaasAccount(programCode))
                {
                    Logger.Info($"request id = {requestId}, this program {programCode} does not need baas account when creating customer profile");
                    return (false, string.Empty, string.Empty);
                }

                var paymentInstruments = _paymentInstrumentService.GetPaymentInstruments(accountIdentifier, null);
                var isEmpty = paymentInstruments?.Any() != true;
                var latestActivate = ((paymentInstruments?.Where(p => p?.PaymentInstrumentStatus == PaymentInstrumentStatus.Activated)) ?? Array.Empty<PaymentInstrumentAllInfo>()).MaxBy(p => p.PaymentInstrument?.ActivatedDateTime);
                if (isEmpty || latestActivate == null)
                {
                    throw new PaymentInstrumentNotFoundException();
                }

                var paymentIdentifier = _paymentInstrumentService.GetPaymentIdentifier(accountIdentifier, latestActivate.PaymentInstrument?.PaymentInstrumentIdentifier);
                if (paymentIdentifier?.PaymentInstrument == null)
                {
                    throw new PaymentInstrumentNotFoundException();
                }

                if (paymentIdentifier.AccountIdentifier != AccountIdentifier.FromString(accountIdentifier) || string.IsNullOrWhiteSpace(paymentIdentifier.PaymentInstrument.Pan))
                {
                    throw new PaymentInstrumentNotFoundException();
                }

                var bin = _paymentInstrumentService.GetBinByPan(paymentIdentifier.PaymentInstrument.Pan);

                return (true, bin, latestActivate!.PaymentInstrument!.Last4Pan);
            }
            catch (Exception e)
            {
                Logger.Error(e, $"Get baas account fail, request id:{requestId}, message : {e.Message}");
                throw new PaymentInstrumentNotFoundException();
            }
        }

    }
}
