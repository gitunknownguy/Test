﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using NLog;

namespace RequestHandler.Logic.Handler
{
    public class
        SubmitPaperCheckPaymentHandler : CommandHandlerBase<CheckPaymentFulfillmentRequest,
            CheckPaymentFulfillmentResponse>
    {
        private readonly INotificationService _notificationService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IAccountTransactionService _accountTransactionService;
        private readonly ITransClassService _transClassService;
        private readonly IBaasConfiguration _baasConfiguration;
        private static readonly Logger _logger = LogManager.GetCurrentClassLogger();



        public SubmitPaperCheckPaymentHandler(IAccountTransactionService accountTransactionService,
            INotificationService notificationService,
            IValidateIdentifier validateIdentifier, ITransClassService transClassService,
            IBaasConfiguration baasConfiguration)
        {
            _notificationService = notificationService;
            _validateIdentifier = validateIdentifier;
            _accountTransactionService = accountTransactionService;
            _transClassService = transClassService;
            _baasConfiguration = baasConfiguration;
        }

        public override void SetDomainContext(CheckPaymentFulfillmentRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }
        
        public override Task<CheckPaymentFulfillmentResponse> VerifyIdentifiers(CheckPaymentFulfillmentRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier,
                    DomainContext.Current.ProgramCode);
            }
            catch (Exception e)
            {
                var adjustBalanceResponse = e.HandleException<AdjustAccountBalanceBaseResponse>(e, request);
                var response = TransformResponse(adjustBalanceResponse, request);
                return Task.FromResult(response);
            }

            return Task.FromResult(new CheckPaymentFulfillmentResponse { ResponseHeader = new ResponseHeader() });
        }

        public override Task<CheckPaymentFulfillmentResponse> Handle(CheckPaymentFulfillmentRequest request)
        {

            var adjustmentData = new AdjustAccountBalanceRequest
            {
                RequestHeader = request.RequestHeader,

                ProgramCode = DomainContext.Current.ProgramCode.ToString(),
                AccountIdentifier = DomainContext.Current.AccountIdentifier.ToString(),
                AdjustmentDescription = request.AdjustmentDescription,
                Amount = request.Amount,
                Currency = "USD"
            };

            if (request.CheckPaymentNotificationType == CheckPaymentNotificationType.Fulfillment)
            {
                adjustmentData.AdjustmentIdentifier = request.AdjustmentIdentifier ?? Guid.Empty;
                adjustmentData.AdjustmentType = AdjustmentType.CheckDebit;
            }
            else //for PN only
            {
                //todo: add PN handler from here
                return Task.FromResult(new CheckPaymentFulfillmentResponse { ResponseHeader = new ResponseHeader() });
            }

            try
            {
                var transClass = _transClassService.GetTransClassesByAdjustmentType(adjustmentData.AdjustmentType);
                if (transClass.Item1 == null)
                {
                    _logger.Warn(
                        $"Cannot get transClass for AdjustmentType {adjustmentData.AdjustmentType} of Request {request.RequestHeader?.RequestId}");
                }
                else
                {
                    _logger.Info(
                        $"Request {request.RequestHeader?.RequestId}, AdjustmentType: {adjustmentData.AdjustmentType} IsCredit: {transClass.Item1?.IsCredit}");
                }

                var isConfigured = _baasConfiguration.AllowNegativeBalanceForProgram(request.ProgramCode);
                if (adjustmentData.DebitToNegative.HasValue && !isConfigured)
                {
                    throw new ValidationException(3, 200, "Not allowed to debit account balance to negative.");
                }

                if (isConfigured && !adjustmentData.DebitToNegative.HasValue && transClass.Item1 != null &&
                    !transClass.Item1.IsCredit)
                {
                    adjustmentData.DebitToNegative = false;
                }

                var adjustmentResponse = _accountTransactionService.Adjustment(adjustmentData);
                var response = TransformResponse(adjustmentResponse, request);
                return Task.FromResult(response);
            }
            catch (AccountTransactionException<AdjustAccountBalanceBaseResponse> ae)
            {
                var response = TransformResponse(ae.ResponseData, request);

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                var adjustBalanceResponse = e.HandleException<AdjustAccountBalanceBaseResponse>(e, request);
                var response = TransformResponse(adjustBalanceResponse, request);
                return Task.FromResult(response);
            }
        }

        public CheckPaymentFulfillmentResponse TransformResponse(
            AdjustAccountBalanceBaseResponse adjustmentResponse, CheckPaymentFulfillmentRequest request)
        {
            var response = new CheckPaymentFulfillmentResponse
            {
                ResponseHeader = adjustmentResponse.ResponseHeader,
                Status = CheckPaymentFulfillmentStatus.Completed,
                StatusReason = CheckPaymentFulfillmentStatusReason.Success
            };

            if (adjustmentResponse.Status == AdjustmentStatus.Failed && adjustmentResponse.StatusReason == AdjustmentStatusReason.SystemError)
            {
                response.Status = CheckPaymentFulfillmentStatus.Failed;
                response.StatusReason = CheckPaymentFulfillmentStatusReason.SystemError;
            }
            else if (adjustmentResponse.ResponseHeader?.StatusCode == 3)
            {
                response.Status = CheckPaymentFulfillmentStatus.Declined;
                switch (adjustmentResponse.ResponseHeader?.SubStatusCode)
                {
                    case 103:
                        response.StatusReason = CheckPaymentFulfillmentStatusReason.InsufficientFund;
                        break;
                    case 105:
                        response.StatusReason = CheckPaymentFulfillmentStatusReason.AccountClosed;
                        break;
                    case 106:
                        response.StatusReason = CheckPaymentFulfillmentStatusReason.AccountLocked;
                        break;
                    case 100:
                        response.StatusReason = CheckPaymentFulfillmentStatusReason.AccountRestricted;
                        break;
                    case 108:
                        response.StatusReason = CheckPaymentFulfillmentStatusReason.DuplicatedAdjustment;
                        break;
                    default:
                        response.StatusReason = CheckPaymentFulfillmentStatusReason.SystemError;
                        break;
                }
            }
            else if (adjustmentResponse.ResponseHeader?.StatusCode == 10
                     && adjustmentResponse.ResponseHeader?.SubStatusCode == 0)
            {
                response.Status = CheckPaymentFulfillmentStatus.Declined;
                response.StatusReason = CheckPaymentFulfillmentStatusReason.AccountNotFound;
            }

            var paperCheckEvent = new PaperCheckEvent
            {
                AccountIdentifier = DomainContext.Current.AccountIdentifier.ToString(),
                TransactionAmount = request.Amount,
                TransactionDescription = request.AdjustmentDescription,
                CheckNumber = request.CheckNumber,
                AssociatedTransactionIdentifier = request.AdjustmentIdentifier?.ToString(),
                EventDateTime = DateTime.Now,
                StatusReason = response.StatusReason.ToString(),
                Status = response.Status.ToString(),
                TransactionType = "paperCheck"
            };

            if (request.IsFinalAttempt && adjustmentResponse.Status != AdjustmentStatus.Completed)
            {
                paperCheckEvent.Status = CheckPaymentFulfillmentStatus.Declined.ToString();
            }

            if (response?.ResponseHeader?.StatusCode == 0 && response.Status == CheckPaymentFulfillmentStatus.Completed && response.StatusReason == CheckPaymentFulfillmentStatusReason.Success)
            {
                _notificationService.PublishNotification(DomainContext.Current.ProgramCode.ToString(), paperCheckEvent, EventType.PaperCheck);
            }

            return response;
        }
    }
}
