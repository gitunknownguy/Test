﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Enums;
using Gd.Bos.RequestHandler.Core.Domain.Services.CareSharedApi;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using NLog;
using RequestHandler.Core.Application;
using RequestHandler.Core.Domain.Services.AzureServiceBus;
using RequestHandler.Core.Domain.Services.TokenManagementService;
using RequestHandler.Core.Domain.Services.TokenManagementService.EventMessage;
using RequestHandler.Logic.Queue;
using Account = Gd.Bos.RequestHandler.Core.Domain.Model.Account.Account;
using AccountHolderCure = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolderCure;
using AccountStatus = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountStatus;
using AccountStatusReason = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountStatusReason;
using BinType = Gd.Bos.RequestHandler.Core.Domain.Enums.BinType;
using IServiceBusNotificationPublisher = RequestHandler.Core.Domain.Services.AzureServiceBus.IServiceBusNotificationPublisher;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;

namespace RequestHandler.Logic.Handler
{
    public class UpdateAccountStatusHandler : CommandHandlerBase<UpdateAccountStatusRequest, UpdateAccountStatusResponse>
    {
        private readonly INotificationService _notificationPublisher;
        private readonly IEnrollmentDataAccess _enrollmentDataAccess;
        private readonly IValidateIdentifier _validateIdentifier;

        private readonly IAccountStatusService _accountStatusService;
        private readonly ILockService _lockService;
        private readonly IAccountService _accountService;
        private readonly ISccAccountStatusService _sccAccountStatusService;
        private readonly ICareSharedApiService _careSharedApiService;
        private readonly ICreditBuilderLoanService _creditBuilderLoanService;
        private readonly ITokenManagementService _tokenManagementService;

        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        private bool isClosed = false;

        public UpdateAccountStatusHandler(
            INotificationService notificationPublisher,
            IAccountStatusService accountStatusService,
            IEnrollmentDataAccess enrollmentDataAccess,
            IValidateIdentifier validateIdentifier,
            ILockService lockService,
            IAccountService accountService,
            ISccAccountStatusService sccAccountStatusService,
            ICareSharedApiService careSharedApiService,
            ICreditBuilderLoanService creditBuilderLoanService,
            ITokenManagementService tokenManagementService

        )
        {
            _notificationPublisher = notificationPublisher;
            _accountStatusService = accountStatusService;
            _enrollmentDataAccess = enrollmentDataAccess;
            _validateIdentifier = validateIdentifier;
            _lockService = lockService;
            _accountService = accountService;
            _sccAccountStatusService = sccAccountStatusService;
            _careSharedApiService = careSharedApiService;
            _creditBuilderLoanService = creditBuilderLoanService;
            _tokenManagementService = tokenManagementService;
        }

        public override void SetDomainContext(UpdateAccountStatusRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;

            if (!string.IsNullOrEmpty(request.AccountHolderIdentifier))
                DomainContext.Current.AccountHolderIdentifier = request.AccountHolderIdentifier;
        }

        public override Task<UpdateAccountStatusResponse> VerifyIdentifiers(UpdateAccountStatusRequest request)
        {
            try
            {
                var accountBinType = GetAccountBinType(request);
                var allowUpdateForClosedStatus = false;
                if (BinType.Credit == accountBinType)
                {
                    Enum.TryParse<AccountStatus>(request.AccountStatus, true, out AccountStatus newStatus);
                    Account oldAccount = _accountService.GetAccountByAccountIdentifier(request.AccountIdentifier);
                    isClosed = oldAccount.AccountStatus == AccountStatus.Closed;
                    var newAccountStatusReasons = _accountStatusService.GetAccountStatusReasons(request.AccountStatusReasons).ToList();
                    List<AccountStatusReason> allowUpdateReasonsForClosedStatus = new List<AccountStatusReason>
                    {
                        AccountStatusReason.bnkrpy, //24
                        AccountStatusReason.gdClosedDeceased, //57
                        AccountStatusReason.bnkrpyChapter13,//72
                        AccountStatusReason.bnkrpyChapter11,//73
                        AccountStatusReason.bnkrpyChapter7,//74
                        AccountStatusReason.confirmedFraud,//6
                        AccountStatusReason.confirmedAccountTakeover,//28
                        AccountStatusReason.identityTheft,//12
                        AccountStatusReason.confirmedIdentityTheft,//54
                        AccountStatusReason.d30,
                        AccountStatusReason.d60,
                        AccountStatusReason.d90,
                        AccountStatusReason.d120,
                        AccountStatusReason.d150,
                        AccountStatusReason.d180,
                        AccountStatusReason.d210,
                        AccountStatusReason.chgoff,
                    };
                    if (
                       isClosed &&
                       newStatus == AccountStatus.Closed &&
                       newAccountStatusReasons != null &&
                       newAccountStatusReasons.Any(r => allowUpdateReasonsForClosedStatus.Any(c => c == r)))
                    {
                        allowUpdateForClosedStatus = true;
                    }
                }

                if (!allowUpdateForClosedStatus)
                {
                    _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 5, 105);
                }

                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier,
                    DomainContext.Current.ProgramCode);
                return Task.FromResult(new UpdateAccountStatusResponse { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpdateAccountStatusResponse>(e, request));
            }
        }

        private BinType GetAccountBinType(UpdateAccountStatusRequest request)
        {
            var accountBinType = _accountService.GetAccountBinType(request.AccountIdentifier);
            return accountBinType;
        }

        public override async Task<UpdateAccountStatusResponse> ObtainLock(UpdateAccountStatusRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock(DomainContext.Current.AccountIdentifier.ToString());
                await _lockService.ObtainApiLock(DomainContext.Current?.AccountHolderIdentifier?.ToString());
                return new UpdateAccountStatusResponse { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<UpdateAccountStatusResponse>(e, request);
            }
        }

        public override async Task<UpdateAccountStatusResponse> Handle(UpdateAccountStatusRequest request)
        {
            UpdateAccountStatusResponse response;
            UpdateAccountStatusResponse sccResponse = null;
            try
            {
                if (request == null)
                    throw new ArgumentNullException(nameof(request));
                if (string.IsNullOrEmpty(request.AccountIdentifier))
                    throw new ArgumentException("AccountIdentifier must be specified", nameof(request));

                var accountBinType = GetAccountBinType(request);
                if (BinType.Credit == accountBinType)
                {
                    if (request.AccountStatusReasons != null &&
                        (request.AccountStatusReasons.Contains(AccountStatusReason.spendDown.ToString()) ||
                         request.AccountStatusReasons.Contains(AccountStatusReason.customerInitiatedSpendDown
                             .ToString())))
                    {
                        throw new RequestHandlerException(4, 107,
                            "Credit cards aren’t eligible for spend down.");
                    }

                    sccResponse = await _sccAccountStatusService.UpdateAccountStatus(request);
                    if (!isClosed)
                    {
                        await UpdateDdaAccount(request); //when update SCC account impact DDA account
                        await UpdateCblAccount(request, true); //when update SCC account impact CBL account
                    }
                }
                else
                {
                    Account oldDdaAccount = _accountService.GetAccountByAccountIdentifier(request.AccountIdentifier);
                    await _accountStatusService.UpdateAccountStatus(request);
                    await UpdateSccAccount(request, oldDdaAccount); //when update DDA account impact SCC account
                    await UpdateCblAccount(request, false); //when update DDA account impact CBL account
                }
            }
            catch (AccountValidationException ave)
            {
                response = new UpdateAccountStatusResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request?.RequestHeader.RequestId ?? Guid.NewGuid(),
                        StatusCode = ave.Code,
                        SubStatusCode = ave.SubCode,
                        Message = ave.Message
                    },
                };

                return response;
            }
            catch (Exception e)
            {

                if (e.Message.Contains("CARDSTATUSCHANGE_INVALIDSTATUSCHANGE") ||
                    e.Message.Contains("CARDSTATUS_CHANGE_NEW_OLD_STATUS_RSN_CODE_CANNOT_BE_EQUAL"))
                {
                    response = new UpdateAccountStatusResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request?.RequestHeader.RequestId ?? Guid.NewGuid(),
                            StatusCode = 4,
                            SubStatusCode = 314,
                            Message = "Card already blocked.  Statuses updated."
                        },
                    };

                    return response;
                }

                return e.HandleException<UpdateAccountStatusResponse>(e, request);
            }

            response = new UpdateAccountStatusResponse
            {
                ResponseHeader = ResponseHeader.SuccessForRequest(request.RequestHeader)
            };

            if (sccResponse?.ResponseHeader != null && response?.ResponseHeader != null)
            {
                response.ResponseHeader.StatusCode = sccResponse.ResponseHeader.StatusCode;
                response.ResponseHeader.SubStatusCode = sccResponse.ResponseHeader.SubStatusCode;
                response.ResponseHeader.Message = sccResponse.ResponseHeader.Message;
            }

            if (!isClosed)
            {
                try
                {
                    await PublishNotification(request);
                }
                catch (Exception ex)
                {
                    _logger.Error(ex, "Exception occured while publishing notification");
                    response.ResponseHeader.Details = "Exception occurred while publishing notification";
                }
            }

            await _tokenManagementService.PublishUserProfileUpdatedMessageAsync(request.RequestHeader.RequestId,
                request.ProgramCode,
                new UserProfileUpdatedMessage
                {
                    AccountStatus = request.AccountStatus,
                    AccountIdentifier = request.AccountIdentifier,
                    ProgramCode = request.ProgramCode
                });

            return response;
        }

        public override void ReleaseLock(UpdateAccountStatusRequest request)
        {
            _lockService.ReleaseApiLock(DomainContext.Current.AccountIdentifier.ToString());
            _lockService.ReleaseApiLock(DomainContext.Current?.AccountHolderIdentifier?.ToString());
        }

        /// <summary>
        /// When update SCC, impact DDA
        /// </summary>
        private async Task UpdateDdaAccount(UpdateAccountStatusRequest request)
        {
            var statusReasons = _accountStatusService.GetAccountStatusReasons(request.AccountStatusReasons)
                .ToList();
            bool isIdentityTheft = statusReasons.Contains(AccountStatusReason.identityTheft); //IdentityTheft
            bool isAccountTakeover = statusReasons.Contains(AccountStatusReason.confirmedAccountTakeover); //ATO
            bool isBankrupt = statusReasons.Contains(AccountStatusReason.bnkrpy); // B - Bankrupt
            bool isGDClosedDead = statusReasons.Contains(AccountStatusReason.gdClosedDeceased); // GBOS-62907
            if (isIdentityTheft || isAccountTakeover || isBankrupt || isGDClosedDead)
            {
                var linkedAccounts = _accountService.GetLinkedAccount(request.AccountIdentifier, true);
                var linkedAccount =
                    linkedAccounts?.FirstOrDefault(a => a.AccountLinkType == AccountLinkType.SecureCreditCard);
                if (linkedAccount != null)
                {
                    if (isIdentityTheft)
                    {
                        if (linkedAccount.PrimaryAccountStatus != AccountStatus.Closed)
                        {
                            UpdateAccountStatusRequest newRequest = new UpdateAccountStatusRequest
                            {
                                AccountIdentifier = linkedAccount.PrimaryAccountIdentifier,
                                AccountStatus = AccountStatus.Locked.ToString(),
                                AccountStatusReasons =
                                    new List<string> { AccountStatusReason.potentialFraud.ToString() },
                                Cure = AccountHolderCure.Manual.ToString(),
                                Source = request.Source,
                                ProgramCode = request.ProgramCode,
                                RequestHeader = new RequestHeader
                                {
                                    RequestId = request.RequestHeader.RequestId,
                                    Source = request.RequestHeader.Source
                                }
                            };
                            newRequest.CustomData = CreateCustomData(newRequest.AccountIdentifier, newRequest.Cure);

                            await _accountStatusService.UpdateAccountStatus(newRequest);
                            await PublishNotification(newRequest);
                            CreateCustomerCareCase(request.RequestHeader.RequestId,
                                linkedAccount.PrimaryAccountIdentifier,
                                newRequest.AccountStatusReasons);
                        }
                    }
                    else if (isGDClosedDead) // GBOS-62907
                    {
                        UpdateAccountStatusRequest newRequest = new UpdateAccountStatusRequest
                        {
                            AccountIdentifier = linkedAccount.PrimaryAccountIdentifier,
                            AccountStatus = AccountStatus.Locked.ToString(),
                            AccountStatusReasons =
                                new List<string> { AccountStatusReason.gdClosedDeceased.ToString() },
                            Cure = AccountHolderCure.Manual.ToString(),
                            Source = request.Source,
                            ProgramCode = request.ProgramCode,
                            RequestHeader = new RequestHeader
                            {
                                RequestId = request.RequestHeader.RequestId,
                                Source = request.RequestHeader.Source
                            }
                        };
                        newRequest.CustomData = CreateCustomData(newRequest.AccountIdentifier, newRequest.Cure);

                        await _accountStatusService.UpdateAccountStatus(newRequest);
                        await _sccAccountStatusService.UpdateAccountStatus(newRequest, true);
                        await PublishNotification(newRequest);
                    }
                    else if (isBankrupt)
                    {
                        CreateCustomerCareCase(request.RequestHeader.RequestId,
                            linkedAccount.PrimaryAccountIdentifier,
                            new List<string>());
                    }
                }
            }
        }

        /// <summary>
        /// When update DDA, impact SCC
        /// </summary>
        private async Task UpdateSccAccount(UpdateAccountStatusRequest request, Account oldDdaAccount)
        {
            var statusReasons = _sccAccountStatusService.GetAccountStatusReasons(request.AccountStatusReasons)
                .ToList();
            Enum.TryParse(request.AccountStatus, true, out AccountStatus ddaAccountStatus);

            bool isGDClosedDead = statusReasons.Contains(AccountStatusReason.gdClosedDeceased); //GBOS-62907
            bool isNoneCure =
                request.Cure.Equals(AccountHolderCure.None.ToString(), StringComparison.OrdinalIgnoreCase) ||
                (request.CustomData != null && request.CustomData.Values.Any(c =>
                    c.Equals(AccountHolderCure.None.ToString(), StringComparison.OrdinalIgnoreCase)));
            bool isIdvCure =
                request.Cure.Equals(AccountHolderCure.IDV.ToString(), StringComparison.OrdinalIgnoreCase) ||
                (request.CustomData != null && request.CustomData.Values.Any(c =>
                    c.Equals(AccountHolderCure.IDV.ToString(), StringComparison.OrdinalIgnoreCase)));
            bool isRestricted = ddaAccountStatus == AccountStatus.Restricted && isNoneCure;
            bool isConfirmedFraud = statusReasons.Contains(AccountStatusReason.confirmedFraud);
            bool isIdentityTheft = statusReasons.Contains(AccountStatusReason.identityTheft);
            bool isIdvToNormal = oldDdaAccount.AccountStatus == AccountStatus.Locked
                                 && oldDdaAccount.AccountHolders?.FirstOrDefault(ah => ah.IsPrimary)
                                     ?.AccountHolderCure == AccountHolderCure.IDV
                                 && ddaAccountStatus == AccountStatus.Normal
                                 && !isIdvCure; //DDA is from (Status=Locked, Cure=IDV) to (Status=Normal, Cure!=IDV)
            if (isRestricted || isConfirmedFraud || isIdentityTheft || isIdvToNormal || isGDClosedDead)
            {
                var linkedAccounts = _accountService.GetLinkedAccount(request.AccountIdentifier, true);
                var linkedAccount =
                    linkedAccounts?.FirstOrDefault(a => a.AccountLinkType == AccountLinkType.SecureCreditCard);
                if (linkedAccount != null && linkedAccount.LinkAccountStatus != AccountStatus.Closed)
                {
                    if (isRestricted) //AccountStatus=Restricted&&Cure=None
                    {
                        UpdateAccountStatusRequest newRequest = new UpdateAccountStatusRequest
                        {
                            AccountIdentifier = linkedAccount.LinkAccountIdentifier,
                            Source = request.Source,
                            ProgramCode = request.ProgramCode,
                            RequestHeader = new RequestHeader
                            {
                                RequestId = request.RequestHeader.RequestId,
                                Source = request.RequestHeader.Source
                            },
                            AccountStatus = linkedAccount.LinkAccountStatus == AccountStatus.Locked
                                ? AccountStatus.Locked.ToString()
                                : AccountStatus.Restricted.ToString(),
                            AccountStatusReasons = new List<string> { AccountStatusReason.underReview.ToString() },
                            Cure = AccountHolderCure.Manual.ToString()
                        };
                        newRequest.CustomData = CreateCustomData(newRequest.AccountIdentifier, newRequest.Cure);

                        await _sccAccountStatusService.UpdateAccountStatus(newRequest, true);
                        await PublishNotification(newRequest);
                        CreateCustomerCareCase(request.RequestHeader.RequestId, linkedAccount.LinkAccountIdentifier,
                            newRequest.AccountStatusReasons);
                    }
                    else if (isGDClosedDead) // GBOS-62907
                    {
                        UpdateAccountStatusRequest newRequest = new UpdateAccountStatusRequest
                        {
                            AccountIdentifier = linkedAccount.LinkAccountIdentifier,
                            AccountStatus = AccountStatus.Locked.ToString(),
                            AccountStatusReasons =
                                new List<string> { AccountStatusReason.gdClosedDeceased.ToString() },
                            Cure = AccountHolderCure.Manual.ToString(),
                            Source = request.Source,
                            ProgramCode = request.ProgramCode,
                            RequestHeader = new RequestHeader
                            {
                                RequestId = request.RequestHeader.RequestId,
                                Source = request.RequestHeader.Source
                            }
                        };
                        newRequest.CustomData = CreateCustomData(newRequest.AccountIdentifier, newRequest.Cure);

                        await _accountStatusService.UpdateAccountStatus(newRequest);
                        await _sccAccountStatusService.UpdateAccountStatus(newRequest, true);
                        await PublishNotification(newRequest);
                    }
                    else if (isConfirmedFraud) //ConfirmedFraud
                    {
                        UpdateAccountStatusRequest newRequest = new UpdateAccountStatusRequest
                        {
                            AccountIdentifier = linkedAccount.LinkAccountIdentifier,
                            Source = request.Source,
                            ProgramCode = request.ProgramCode,
                            RequestHeader =
                                new RequestHeader
                                {
                                    RequestId = request.RequestHeader.RequestId,
                                    Source = request.RequestHeader.Source
                                },
                            AccountStatus = AccountStatus.Locked.ToString(),
                            AccountStatusReasons =
                                new List<string> { AccountStatusReason.potentialFraud.ToString() },
                            Cure = AccountHolderCure.None.ToString()
                                .Equals(request.Cure, StringComparison.OrdinalIgnoreCase)
                                ? AccountHolderCure.Manual.ToString()
                                : request.Cure
                        };
                        newRequest.CustomData = CreateCustomData(newRequest.AccountIdentifier, newRequest.Cure);

                        await _sccAccountStatusService.UpdateAccountStatus(newRequest, false, true);
                        await PublishNotification(newRequest);
                        CreateCustomerCareCase(request.RequestHeader.RequestId, linkedAccount.LinkAccountIdentifier,
                            newRequest.AccountStatusReasons);
                    }
                    else if (isIdentityTheft)
                    {
                        UpdateAccountStatusRequest newRequest = new UpdateAccountStatusRequest
                        {
                            AccountIdentifier = linkedAccount.LinkAccountIdentifier,
                            Source = request.Source,
                            ProgramCode = request.ProgramCode,
                            RequestHeader =
                                new RequestHeader
                                {
                                    RequestId = request.RequestHeader.RequestId,
                                    Source = request.RequestHeader.Source
                                },
                            AccountStatus = AccountStatus.Locked.ToString(),
                            AccountStatusReasons =
                                new List<string> { AccountStatusReason.potentialFraud.ToString() },
                            Cure = AccountHolderCure.None.ToString()
                                .Equals(request.Cure, StringComparison.OrdinalIgnoreCase)
                                ? AccountHolderCure.Manual.ToString()
                                : request.Cure
                        };
                        newRequest.CustomData = CreateCustomData(newRequest.AccountIdentifier, newRequest.Cure);

                        await _sccAccountStatusService.UpdateAccountStatus(newRequest, false, false, true);
                        await PublishNotification(newRequest);
                        CreateCustomerCareCase(request.RequestHeader.RequestId, linkedAccount.LinkAccountIdentifier,
                            newRequest.AccountStatusReasons);
                    }
                    else //DDA is from (Status=Locked, Cure=IDV) to (Status=Normal, Cure!=IDV), then update SCC to normal too.
                    {
                        Account oldSccAccount =
                            _accountService.GetAccountByAccountIdentifier(linkedAccount.LinkAccountIdentifier);
                        if (oldSccAccount.AccountStatus == AccountStatus.Locked
                            && oldSccAccount.AccountStatusReasons.Any(r => r == AccountStatusReason.potentialFraud)
                            && oldSccAccount.AccountHolders?.FirstOrDefault(ah => ah.IsPrimary)
                                ?.AccountHolderCure ==
                            AccountHolderCure.IDV)
                        {
                            UpdateAccountStatusRequest newRequest = new UpdateAccountStatusRequest
                            {
                                AccountIdentifier = linkedAccount.LinkAccountIdentifier,
                                Source = request.Source,
                                ProgramCode = request.ProgramCode,
                                RequestHeader =
                                    new RequestHeader
                                    {
                                        RequestId = request.RequestHeader.RequestId,
                                        Source = request.RequestHeader.Source
                                    },
                                AccountStatus = AccountStatus.Normal.ToString(),
                                AccountStatusReasons = request.AccountStatusReasons,
                                Cure = request.Cure
                            };
                            newRequest.CustomData = CreateCustomData(newRequest.AccountIdentifier, newRequest.Cure);

                            await _sccAccountStatusService.UpdateAccountStatus(newRequest);
                            await PublishNotification(newRequest);


                        }
                    }
                }

            }
        }

        /// <summary>
        /// When update DDA/SCC, impact CBL
        /// </summary>
        private async Task UpdateCblAccount(UpdateAccountStatusRequest request, bool isFromScc)
        {
            var isIdvCure = !isFromScc && (request.Cure.Equals(AccountHolderCure.IDV.ToString(), StringComparison.OrdinalIgnoreCase) ||
                                           request.CustomData != null && request.CustomData.Values.Any(c =>
                                               c.Equals(AccountHolderCure.IDV.ToString(), StringComparison.OrdinalIgnoreCase)));
            Enum.TryParse(request.AccountStatus, true, out AccountStatus accountStatus);
            if (isIdvCure)
            {
                AccountLoanPlanStatus accountLoanPlanStatus;
                switch (accountStatus)
                {
                    case AccountStatus.Locked:
                        accountLoanPlanStatus = AccountLoanPlanStatus.Locked;
                        break;
                    case AccountStatus.Restricted:
                        accountLoanPlanStatus = AccountLoanPlanStatus.Restricted;
                        break;
                    default:
                        return;
                }

                await UpdateCbl(request, request.AccountIdentifier, AccountLoanPlanStatusReason.AccountUnderReview, accountLoanPlanStatus);
                return;
            }

            var statusReasons = _sccAccountStatusService.GetAccountStatusReasons(request.AccountStatusReasons).ToList();
            var isNoCure = request.Cure.Equals(AccountHolderCure.None.ToString(), StringComparison.OrdinalIgnoreCase) ||
                           request.CustomData != null && request.CustomData.Values.Any(c =>
                               c.Equals(AccountHolderCure.None.ToString(), StringComparison.OrdinalIgnoreCase));
            var isLockedNoCure = accountStatus == AccountStatus.Locked && isNoCure;
            var isConfirmedFraud = statusReasons.Contains(AccountStatusReason.confirmedFraud);
            var isIdentityTheft = statusReasons.Contains(AccountStatusReason.identityTheft);
            var isBankruptcy = statusReasons.Contains(AccountStatusReason.bnkrpy);

            if (isLockedNoCure && (isConfirmedFraud || isIdentityTheft || isBankruptcy))
            {
                var accountIdentifier = request.AccountIdentifier;
                if (isFromScc)
                {
                    var linkedAccounts = _accountService.GetLinkedAccount(request.AccountIdentifier, true);
                    accountIdentifier = linkedAccounts
                        ?.FirstOrDefault(a => a.AccountLinkType == AccountLinkType.SecureCreditCard)
                        ?.PrimaryAccountIdentifier;

                    if (accountIdentifier == null)
                        return;
                }

                if (isConfirmedFraud)
                    await UpdateCbl(request, accountIdentifier, AccountLoanPlanStatusReason.ConfirmedFraud);
                else if (isIdentityTheft)
                    await UpdateCbl(request, accountIdentifier, AccountLoanPlanStatusReason.IdentityTheft);
                else
                    await UpdateCbl(request, accountIdentifier, AccountLoanPlanStatusReason.Bankruptcy);
            }
        }

        private async Task UpdateCbl(UpdateAccountStatusRequest request, string accountIdentifier, AccountLoanPlanStatusReason reason, AccountLoanPlanStatus accountLoanPlanStatus = AccountLoanPlanStatus.Locked)
        {
            try
            {
                await _creditBuilderLoanService.UpdateLoan(new CblUpdateLoanRequest
                {
                    RequestHeader = new RequestHeader { RequestId = request.RequestHeader.RequestId },
                    AccountIdentifier = accountIdentifier,
                    AccountLoanPlanStatus = accountLoanPlanStatus,
                    AccountLoanPlanStatusReason = reason,
                    ProgramCode = request.ProgramCode
                });
            }
            catch (ValidationException)
            {
                // Ignored due to no CBL
            }
        }

        private async Task PublishNotification(UpdateAccountStatusRequest request)
        {
            var accountResp =
                _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(request.AccountIdentifier, request.ProgramCode,
                    true);
            await _notificationPublisher.PublishNotification(request.ProgramCode, accountResp.Account,
                EventType.AccountUpdated);
        }

        private Dictionary<string, string> CreateCustomData(string accountIdentifier, string cure)
        {
            var accountHolders = _accountService.GetAccountHoldersByAccountIdentifier(accountIdentifier)
                ?.Where(a => a.ConsumerProfileType == ConsumerProfileType.Individual).ToList();
            if (accountHolders == null || accountHolders.Count == 1) return null; //No join account

            Dictionary<string, string> customData = new Dictionary<string, string>();
            foreach (var accountHolder in accountHolders)
            {
                customData.Add(accountHolder.AccountHolderIdentifier.ToString(), cure);
            }

            return customData;
        }

        private void CreateCustomerCareCase(Guid requestId, string accountIdentifier, List<string> reasons)
        {
            Task.Run(() =>
            {
                try
                {
                    CreateCareCaseRequest request = new CreateCareCaseRequest
                    {
                        RequestHeader = new Gd.Bos.Shared.Common.Contract.Message.Request.RequestHeader
                        {
                            RequestId = requestId
                        },
                        RecordType = "Fraud_Referral",
                        AccountIdentifier = accountIdentifier,
                        Reason__c = string.Join(",", reasons),
                        Subject = "Account status reason changed"
                    };

                    _careSharedApiService.CreateCustomerCareCase(request);
                    _logger.Info($"Create case for account {accountIdentifier}, reason:{request.Reason__c}.");
                }
                catch (Exception ex)
                {
                    _logger.Error(ex, "Exception occured while create customer care case.");
                }
            });
        }

    }
}
