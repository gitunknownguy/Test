﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;

namespace RequestHandler.Logic.Handler
{
    public class GetPurchaseStatusHandler : CommandHandlerBase<GetPurchaseStatusRequest, GetPurchaseStatusResponse>
    {
        private readonly ITransactionService _transactionService;
        public GetPurchaseStatusHandler(ITransactionService transactionService)
        {
            _transactionService = transactionService;
        }

        public override Task<GetPurchaseStatusResponse> Handle(GetPurchaseStatusRequest request)
        {
            try
            {
                var response = new GetPurchaseStatusResponse
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    }
                };
                var paymentStatusDetailList = _transactionService.GetPaymentStatusByRRNPaymentInstrumentIdentifier(request.PaymentInstrumentIdentifier, request.RetrievalReferenceNumber);
                if (!paymentStatusDetailList.Any())
                {
                    response.ResponseHeader.StatusCode = 10;
                    response.ResponseHeader.Message = "Payment Not found";
                    return Task.FromResult(response);
                }
                response.PaymentStatus = paymentStatusDetailList;
                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetPurchaseStatusResponse>(e, request));
            }
        }

        public override void SetDomainContext(GetPurchaseStatusRequest request)
        {
        }

        public override Task<GetPurchaseStatusResponse> VerifyIdentifiers(GetPurchaseStatusRequest request)
        {
            return Task.FromResult(new GetPurchaseStatusResponse() { ResponseHeader = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader() });
        }
    }
}
