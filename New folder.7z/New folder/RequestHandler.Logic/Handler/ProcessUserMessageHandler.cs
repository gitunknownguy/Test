﻿using RequestHandler.Core.Application;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.Common.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;

namespace RequestHandler.Logic.Handler
{
    public class ProcessUserMessageHandler : CommandHandlerBase<ProcessUserMessageRequest, ProcessUserMessageResponse>
    {
        private readonly IUserMessageService _userMessageService;

        public ProcessUserMessageHandler(IUserMessageService userMessageService)
        {
            _userMessageService = userMessageService;
        }

        public override void SetDomainContext(ProcessUserMessageRequest request)
        {

        }

        public override Task<ProcessUserMessageResponse> VerifyIdentifiers(ProcessUserMessageRequest request)
        {
            return Task.FromResult(new ProcessUserMessageResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override async Task<ProcessUserMessageResponse> Handle(ProcessUserMessageRequest request)
        {

            try
            {
                return _userMessageService.ProcessUserMessage(request);

            }
            catch (Exception e)
            {
                var result = e.HandleException<ProcessUserMessageResponse>(e, request);
                return result;
            }
        }

    }
}
