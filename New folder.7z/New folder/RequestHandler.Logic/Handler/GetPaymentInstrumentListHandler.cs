﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;


namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetPaymentInstrumentListHandler : CommandHandlerBase<GetPaymentInstrumentListRequest, GetPaymentInstrumentListResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IPaymentInstrumentService _paymentInstrumentService;
        private readonly IBaasConfiguration _baasConfiguration;
        private readonly IRequestHandlerSettings _configuration;

        public GetPaymentInstrumentListHandler(
            IPaymentInstrumentService paymentInstrumentService,
            IValidateIdentifier validateIdentifier,
            IBaasConfiguration baasConfiguration, IRequestHandlerSettings requestHandlerSettings)
        {
            _paymentInstrumentService = paymentInstrumentService;
            _validateIdentifier = validateIdentifier;
            _baasConfiguration = baasConfiguration;
            _configuration = requestHandlerSettings;
        }

        public override void SetDomainContext(GetPaymentInstrumentListRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            if (!string.IsNullOrEmpty(request.UserIdentifier))
                DomainContext.Current.UserIdentifier = request.UserIdentifier;
        }

        public override Task<GetPaymentInstrumentListResponse> VerifyIdentifiers(
            GetPaymentInstrumentListRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier,
                    DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidateConsumerProfileIdentifier(DomainContext.Current.AccountIdentifier,
                    DomainContext.Current.UserIdentifier);
                return Task.FromResult(new GetPaymentInstrumentListResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetPaymentInstrumentListResponse>(e, request));
            }
        }

        public override Task<GetPaymentInstrumentListResponse> Handle(GetPaymentInstrumentListRequest request)
        {
            try
            {
                string message = "Success";

                var paymentInstrumentLights = new List<PaymentInstrumentLight>();
                var paymentInstrumentInfos = _paymentInstrumentService.GetPaymentInstruments(request.AccountIdentifier, request.UserIdentifier);
                if (paymentInstrumentInfos != null && paymentInstrumentInfos.Count > 0)
                {
                    foreach (var pi in paymentInstrumentInfos)
                    {
                        var paymentInstrument = pi.PaymentInstrument;
                        paymentInstrument.Status =
                            StatusMapper.GetPaymentInstrumentStatus(pi.PaymentIdentifierStatus,
                                pi.PaymentInstrumentStatus);
                        paymentInstrument.StatusReasons = StatusMapper.GetPaymentInstrumentStatusReasons(
                            pi.PaymentIdentifierStatus, pi.PaymentInstrumentStatus, pi.PaymentInstrumentStatusReason,
                            pi.PaymentIdentifierStatusReason);
                        paymentInstrument.IsPrivateDataViewable = VerifyPrivateDataViewable(paymentInstrument, request.ProgramCode);

                        // GBOS-46414 skip RetailTempCard records based on Type:MagStripe and Last4Pan:0000
                        if (paymentInstrument.PaymentInstrumentType == PaymentInstrumentType.MagStripe
                            && paymentInstrument.Last4Pan == "0000")
                        {
                            continue;
                        }
                        paymentInstrument.IsOverIssuedDaysLimit = _baasConfiguration.IsOverIssuedDaysLimit(request.ProgramCode, _configuration.ValidOverIssuedDaysLimitProgramCodeList, paymentInstrument);
                        paymentInstrumentLights.Add(paymentInstrument);
                    }
                }
                else
                {
                    message += ". The user don't have any payment Instrument";
                }

                var getPaymentInstrumentsResponse = new GetPaymentInstrumentListResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = message
                    },
                    PaymentInstruments = paymentInstrumentLights
                };

                return Task.FromResult(getPaymentInstrumentsResponse);

            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetPaymentInstrumentListResponse>(e, request));
            }
        }

        private bool VerifyPrivateDataViewable(PaymentInstrumentLight paymentInstrument, string programCode)
        {
            bool isPrivateDataViewable = IsVirtualCard(paymentInstrument.PaymentInstrumentType)
                && IsActiveCard(paymentInstrument.Status)
                && _baasConfiguration.IsPinSetNeed(programCode, paymentInstrument.IsPinSet)
                && IsIssued(paymentInstrument.IssuedDateTime)
                && _baasConfiguration.IsPrivateDataViewable(programCode, paymentInstrument.IssuedDateTime)
                && _baasConfiguration.IsCvvViewable(programCode, paymentInstrument.IssuedDateTime);

            return isPrivateDataViewable;
        }

        private static bool IsVirtualCard(PaymentInstrumentType paymentInstrumentType)
        {
            return paymentInstrumentType == PaymentInstrumentType.Virtual;
        }

        private static bool IsActiveCard(PaymentInstrumentStatus status)
        {
            return status == PaymentInstrumentStatus.Activated;
        }

        private static bool IsIssued(DateTime? issuedDateTime)
        {
            return issuedDateTime != null;
        }

    }
}