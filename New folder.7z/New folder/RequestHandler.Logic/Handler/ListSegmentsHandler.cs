﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class ListSegmentsHandler : CommandHandlerBase<ListSegmentsRequest, ListSegmentsResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IPaymentIdentifierRepository _paymentIdentifierRepository;

        public ListSegmentsHandler(IValidateIdentifier validateIdentifier, IPaymentIdentifierRepository paymentIdentifierRepository)
        {

            _validateIdentifier = validateIdentifier;
            _paymentIdentifierRepository = paymentIdentifierRepository;
        }


        public override Task<ListSegmentsResponse> Handle(ListSegmentsRequest request)
        {
            try
            {
                ListSegmentsResponse response = new ListSegmentsResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "success"
                    },

                };

                if (request.RequestHeader.RequestId == Guid.Empty)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId, $"{nameof(request)}.RequestHeader.RequestId must be specified");

                }

                if (string.IsNullOrEmpty(request.PaymentIdentifier))
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Account, $"{nameof(request)}.PaymentIdentifier must be specified");
                }



                var segements =
                    _paymentIdentifierRepository.GetPaymentIdentifierSegmentByPaymentIdentifier(
                        request.PaymentIdentifier);

                // response.ResponseHeader.ResponseId = request.RequestHeader.RequestId;
                response.Segments = segements.OrderByDescending(s => s.StartDate).ToList();
                return Task.FromResult(response);
            }

            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<ListSegmentsResponse>(e, request));
            }

        }

        public override void SetDomainContext(ListSegmentsRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<ListSegmentsResponse> VerifyIdentifiers(ListSegmentsRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                //          _validateIdentifier.ValidatePAN(DomainContext.Current.AccountIdentifier, DomainContext.Current.PlainTextPAN);
                return Task.FromResult(new ListSegmentsResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<ListSegmentsResponse>(e, request));
            }
        }
    }
}
