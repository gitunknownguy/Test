﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Microsoft.AspNetCore.Server.IIS.Core;
using RequestHandler.Core.Domain.Services.PaperCheck;

namespace RequestHandler.Logic.Handler
{
    public class GetCheckBookImageHandler : CommandHandlerBase<GetCheckBookImageRequest, GetCheckBookImageResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IPaperCheckService _paperCheckService;

        //Constructor
        public GetCheckBookImageHandler(IValidateIdentifier validateIdentifier, IPaperCheckService paperCheckService)
        {
            _validateIdentifier = validateIdentifier;
            _paperCheckService = paperCheckService;
        }

        public override void SetDomainContext(GetCheckBookImageRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetCheckBookImageResponse> VerifyIdentifiers(GetCheckBookImageRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);

                return Task.FromResult(new GetCheckBookImageResponse { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetCheckBookImageResponse>(e, request));
            }
        }

        public override Task<GetCheckBookImageResponse> Handle(GetCheckBookImageRequest request)
        {
            try
            {
                var result = new GetCheckBookImageResponse();

                var serviceResponse = _paperCheckService.GetCheckBookImages(request);

                if (serviceResponse.ErrorCode == "0")
                {
                    result.ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    };

                    result.RequestedImageFaces = serviceResponse.RequestedImageFaces;
                    result.ImageFetchStatuses = serviceResponse.ImageFetchStatuses;
                    result.Images = (List<CheckBookImage>)GetCheckBookImagesFromModel(serviceResponse.Images);
                }
                else
                {
                    HandlePartnerErrorResponse(serviceResponse);
                }

                return Task.FromResult(result);
            }
            catch (Exception ex)
            {
                return Task.FromResult(ex.HandleException<GetCheckBookImageResponse>(ex, request));
            }
        }

        private IEnumerable<CheckBookImage> GetCheckBookImagesFromModel(List<CheckBookImage> images)
        {
            var result = new List<CheckBookImage>();

            foreach (var image in images)
            {
                result.Add(new CheckBookImage
                {
                    CheckFulfillmentKey = image.CheckFulfillmentKey,
                    FaceType = image.FaceType,
                    Data = image.Data,
                });
            }

            return result;
        }

        private void HandlePartnerErrorResponse(GetCheckBookImageResponseModel response)
        {
            //Ask to Chen where this codes are obtained
            switch (response.ErrorCode)
            {
                case "02001":
                    throw new RequestHandlerException(10, 0, "CheckNumber provided was not found.");

                case "02005":
                    throw new RequestHandlerException(101, 0, "CheckNumber provided was not presented for clearing yet.");

                case "02006": 
                    throw new RequestHandlerException(10, 0, "CheckNumber provided does not have an associated ImageId.");

                case "0": // success
                    return;

                default:
                    {
                        throw new RequestHandlerException(400, 0,
                            $"Unhandled error code from downstream service. ErrorCode:{response.ErrorCode} ErrorMessage:{response.ErrorMessage}");
                    }
            }

        }
    }
}
