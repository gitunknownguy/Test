﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;


namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetBusinessProfileHandler : CommandHandlerBase<GetBusinessProfileRequest, GetBusinessProfileResponse>
    {
        private readonly IBusinessProfileService _businessProfileService;
        private readonly IValidateIdentifier _validateIdentifier;

        public GetBusinessProfileHandler(IBusinessProfileService businessProfileService
        , IValidateIdentifier validateIdentifier)
        {
            _businessProfileService = businessProfileService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(GetBusinessProfileRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
            {
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            }
        }

        public override Task<GetBusinessProfileResponse> VerifyIdentifiers(GetBusinessProfileRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetBusinessProfileResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetBusinessProfileResponse>(e, request));
            }
        }

        public override Task<GetBusinessProfileResponse> Handle(GetBusinessProfileRequest request)
        {
            var response = new GetBusinessProfileResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0
                }
            };

            try
            {
                var info = _businessProfileService.GetBusinessProfile(new Guid(request.AccountIdentifier));

                if (info == null)
                {
                    response.ResponseHeader.StatusCode = 10;
                    response.ResponseHeader.SubStatusCode = 0;
                    response.ResponseHeader.Message = "Account not found.";

                    return Task.FromResult(response);
                }

                if (info.ConsumerProfileType == null)
                {
                    response.ResponseHeader.StatusCode = 10;
                    response.ResponseHeader.SubStatusCode = 0;
                    response.ResponseHeader.Message = "Business profile not found.";

                    return Task.FromResult(response);
                }

                response.BusinessProfile = new BusinessProfile()
                {
                    AccountIdentifier = info.AccountIdentifier.ToString(),
                    Address1 = info.Address1,
                    Address2 = info.Address2,
                    City = info.City,
                    ConsumerProfileType = info.ConsumerProfileType,
                    Country = info.Country,
                    Email = info.Email,
                    Name = info.Name,
                    LegalName = info.LegalName,
                    EmbossedName = info.EmbossedName,
                    State = info.State,
                    ZipCode = info.ZipCode,
                    PhoneNumber = info.PhoneNumber
                };

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetBusinessProfileResponse>(e, request));
            }
        }
    }
}
