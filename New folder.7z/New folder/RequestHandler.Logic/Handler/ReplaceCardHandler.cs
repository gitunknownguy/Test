﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using RequestHandler.Core.Application;
using RequestHandler.Core.Domain.Enums;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class ReplaceCardHandler : CommandHandlerBase<ReplaceCardRequest, ReplaceCardResponse>
    {
        private readonly IPaymentInstrumentService _paymentInstrumentService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ILockService _lockService;
        private readonly ISampleCardService _sampleCardService;

        public ReplaceCardHandler(IPaymentInstrumentService paymentInstrumentService, IValidateIdentifier validateIdentifier, ILockService lockService, ISampleCardService sampleCardService)
        {
            _paymentInstrumentService = paymentInstrumentService;
            _validateIdentifier = validateIdentifier;
            _lockService = lockService;
            _sampleCardService = sampleCardService;
        }

        public override void SetDomainContext(ReplaceCardRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            DomainContext.Current.PaymentInstrumentIdentifier = request.PaymentInstrumentIdentifier;
            DomainContext.Current.CardExternalId = request.CardExternalId;
        }


        public override Task<ReplaceCardResponse> VerifyIdentifiers(ReplaceCardRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidatePaymentInstrumentIdentifier(DomainContext.Current.AccountIdentifier, DomainContext.Current.PaymentInstrumentIdentifier);
                return Task.FromResult(new ReplaceCardResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<ReplaceCardResponse>(e, request));
            }
        }


        public override async Task<ReplaceCardResponse> ObtainLock(ReplaceCardRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock("Card_" + DomainContext.Current.AccountIdentifier);
                if (!string.IsNullOrEmpty(DomainContext.Current.CardExternalId))
                {
                    await _lockService.ObtainApiLock("CardExternalId_" + DomainContext.Current.CardExternalId);
                }
                return new ReplaceCardResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<ReplaceCardResponse>(e, request);
            }
        }

        public override Task<ReplaceCardResponse> Handle(ReplaceCardRequest request)
        {
            try
            {
                //add dcpp.upgradeproduct for prospect product when replacecard

                var sampleType = _sampleCardService.GetAcquisitionChannelByAccountIdentifier(request.AccountIdentifier, request.RequestHeader.RequestId);
                if (sampleType == AcquisitionChannel.WB || sampleType == AcquisitionChannel.DM || sampleType == AcquisitionChannel.ACIDM || sampleType == AcquisitionChannel.ACIWB)
                {
                    request.ProductMaterialType = _sampleCardService.UpgradeEmvProduct(request.AccountIdentifier,
                         PaymentInstrumentIdentifier.FromString(request.PaymentInstrumentIdentifier), request.ProgramCode);
                }

                var accountReferenceNumber = _paymentInstrumentService.ReplaceCard(AccountIdentifier.FromString(request.AccountIdentifier),
                    PaymentInstrumentIdentifier.FromString(request.PaymentInstrumentIdentifier),
                    request.ProgramCode,
                    request.LossType,
                    request.DeliveryMethod,
                    request.DateLastUsed,
                    request.DateDiscoveredMissing,
                    request.PoliceNotified,
                    request.Notes,
                    request.Override10DayLimit,
                    request.ProductMaterialType,
                    request.CustomCardImageIdentifier,
                    request.CreateVirtualCard,
                    request.RequestHeader.RequestId,
                    waiveFee: request.WaiveFee,
                    waiveOvernightFee: request.WaiveOvernightFee,
                    source: request.Source,
                    needEmbossing: request.NeedEmbossing ?? true,
                    cardExternalId: request.CardExternalId,
                    override24HourLimit: request.Override24HourLimit ?? false,
                    storeId: request.StoreId,
                    orderEmvCard: request.OrderEmvCard);

                var response = new ReplaceCardResponse
                {
                    AccountReferenceNumber = accountReferenceNumber,
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                };

                return Task.FromResult(response);

            }
            catch (InvalidOperationOnVirtualCardException e)
            {
                var response = new ReplaceCardResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 4,
                        SubStatusCode = 311,
                        Message = e.Message
                    },
                };
                return Task.FromResult(response);
            }
            catch (InvalidProductMaterialException e)
            {
                var response = new ReplaceCardResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 4,
                        SubStatusCode = 312,
                        Message = e.Message
                    },
                };
                return Task.FromResult(response);
            }
            catch (FeeException e)
            {
                var response = new ReplaceCardResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = e.Code,
                        SubStatusCode = e.SubCode,
                        Message = e.Message
                    },
                };
                return Task.FromResult(response);
            }
            catch (DcppException e)
            {
                var response = new ReplaceCardResponse();

                if (e.SubCode == 308 && e.Code == 4)
                {
                    response.ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 4,
                        SubStatusCode = 308,
                        Message = "Duplicate Payment Instrument request within 10 days of last request."
                    };
                    return Task.FromResult(response);
                }
                else if (e.SubCode == 303 && e.Code == 4)
                {
                    response.ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 4,
                        SubStatusCode = 303,
                        Message = "Replacement request was made against a PAN/Instrument which is no longer current."
                    };
                    return Task.FromResult(response);
                }
                else if (e.SubCode == 300 && e.Code == 4)
                {
                    response.ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 4,
                        SubStatusCode = 300,
                        Message = "Payment Instrument was already reported Lost or Stolen."
                    };
                    return Task.FromResult(response);
                }
                else if (e.SubCode == 310 && e.Code == 4)
                {
                    response.ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 4,
                        SubStatusCode = 310,
                        Message = "An initial physical card cannot be requested on an account that already has a physical card."
                    };
                    return Task.FromResult(response);
                }
                else if (e.SubCode == 704 && e.Code == 4)
                {
                    response.ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 4,
                        SubStatusCode = 704,
                        Message = "Not received was made against a PAN/Instrument which is already activated."
                    };
                    return Task.FromResult(response);
                }

                return Task.FromResult(e.HandleException<ReplaceCardResponse>(e, request));
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<ReplaceCardResponse>(e, request));
            }
        }


        public override void ReleaseLock(ReplaceCardRequest request)
        {
            _lockService.ReleaseApiLock("Card_" + DomainContext.Current.AccountIdentifier);
            if (!string.IsNullOrEmpty(DomainContext.Current.CardExternalId))
            {
                _lockService.ReleaseApiLock("CardExternalId_" + DomainContext.Current.CardExternalId);
            }
        }
    }
}
