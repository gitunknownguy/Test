﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Data;
using NLog;
using RequestHandler.Core.Domain.Services.Experian;
using RequestHandler.Core.Domain.Services.Experian.Contracts;
using RequestHandler.Core.Domain.Services.Experian.Enum;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;

namespace RequestHandler.Logic.Handler
{
    public class ExperianUpdateOptInHandler : CommandHandlerBase<ExperianUpdateOptInRequest, ExperianUpdateOptInResponse>
    {
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        private readonly IExperianService _experianService;
        private readonly IAccountRepository _accountRepository;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IDataAccess _dataAccess;
        private readonly ILazyCache _lazyCache;
        private readonly IUserRepository _userRepository;
        private readonly ITokenizerService _tokenizerService;
        private readonly IFinancialDataService _financialDataService;
        private readonly IExperianServiceHelper _experianServiceHelper;

        public ExperianUpdateOptInHandler(IExperianService experianService, IAccountRepository accountRepository, IValidateIdentifier validateIdentifier,
                                            IDataAccess dataAccess, ILazyCache lazyCache, IUserRepository userRepository, ITokenizerService tokenizerService,
                                            IFinancialDataService financialDataService, IExperianServiceHelper experianServiceHelper)
        {
            _validateIdentifier = validateIdentifier;
            _accountRepository = accountRepository;
            _experianService = experianService;
            _lazyCache = lazyCache;
            _dataAccess = dataAccess;
            _userRepository = userRepository;
            _tokenizerService = tokenizerService;
            _financialDataService = financialDataService;
            _experianServiceHelper = experianServiceHelper;
        }

        public override Task<ExperianUpdateOptInResponse> Handle(ExperianUpdateOptInRequest request)
        {
            var response = new ExperianUpdateOptInResponse()
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                }
            };

            var helperResponse = _experianServiceHelper.CreateCustomer(new CreateCustomerHelperRequest()
            {
                RequestId = request.RequestHeader.RequestId,
                ProgramCode = request.ProgramCode,
                AccountIdentifier = request.AccountIdentifier,
                OptIn = request.OptIn,
                Source = CreateCustomerSource.CreateCustomer
            });

            if (helperResponse.StatusCode == 0)
                return Task.FromResult(response);

            response.ResponseHeader.StatusCode = helperResponse.StatusCode;
            response.ResponseHeader.Message = helperResponse.Message;

            return Task.FromResult(response);
        }

        public override Task<ExperianUpdateOptInResponse> VerifyIdentifiers(ExperianUpdateOptInRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new ExperianUpdateOptInResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<ExperianUpdateOptInResponse>(e, request));
            }
        }

        public override void SetDomainContext(ExperianUpdateOptInRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }
    }
}
