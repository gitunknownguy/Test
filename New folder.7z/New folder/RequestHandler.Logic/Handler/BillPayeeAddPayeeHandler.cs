﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.BillPay;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class BillPayeeAddPayeeHandler : CommandHandlerBase<BillPayAddPayeeRequest, BillPayAddPayeeResponse>
    {
        private readonly IBillPayService _billPayService;
        private readonly IValidateIdentifier _validateIdentifier;

        public BillPayeeAddPayeeHandler(IBillPayService billPayService, IValidateIdentifier validateIdentifier)
        {
            _validateIdentifier = validateIdentifier;
            _billPayService = billPayService;
        }

        public override void SetDomainContext(BillPayAddPayeeRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<BillPayAddPayeeResponse> VerifyIdentifiers(BillPayAddPayeeRequest request)
        {
            _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 3, 105);
            return Task.FromResult(new BillPayAddPayeeResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<BillPayAddPayeeResponse> Handle(BillPayAddPayeeRequest request)
        {
            try
            {
                var response = _billPayService.AddBillPayee(GetAddBillPayeeRequest(request), request.ProgramCode, request.AccountIdentifier);
                PayeeStatus myPayeeStatus = default(PayeeStatus);
                if (!string.IsNullOrEmpty(response.PayeeStatus))
                    Enum.TryParse(response.PayeeStatus, true, out myPayeeStatus);
                var result = default(BillPayAddPayeeResponse);
                if (response?.ErrorCode == "0")
                {
                    result = new BillPayAddPayeeResponse()
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 0,
                            SubStatusCode = 0,
                            Message = "success"
                        },

                        PayeeIdentifier = response.PayeeIdentifier,
                        PayeeStatus = myPayeeStatus
                    };
                }
                else
                {
                    result = new BillPayAddPayeeResponse()
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            SubStatusCode = 0,
                            Message = response.ErrorMessage
                        },
                        PayeeStatus = null
                    };
                    if (!string.IsNullOrEmpty(response.ErrorCode) &&
                        int.TryParse(response.ErrorCode, out var tempErrorCode))
                    {
                        result.ResponseHeader.StatusCode = tempErrorCode;
                    }
                    else
                    {
                        result.ResponseHeader.StatusCode = 0; //Default
                    }
                }
                return Task.FromResult(result);
            }
            catch (Exception ex)
            {
                return Task.FromResult(ex.HandleException<BillPayAddPayeeResponse>(ex, request));
            }
        }

        private AddBillPayeeRequest GetAddBillPayeeRequest(BillPayAddPayeeRequest request)
        {
            if (request == null)
            {
                throw new RequestHandlerException(400, 0, $"request was null");
            }

            var addBillPayeeRequest = new AddBillPayeeRequest()
            {
                AccountNumber = request.AccountNumber,
                PayeeType = request.PayeeType.ToString(),
                PhoneNumber = request.PhoneNumber,
                Email = request.Email,
                NickName = request.NickName,

                Name = request.PayeeInfo?.Name,
                Address1 = request.PayeeInfo?.Address?.AddressLine1,
                Address2 = request.PayeeInfo?.Address?.AddressLine2,
                City = request.PayeeInfo?.Address?.City,
                State = request.PayeeInfo?.Address?.State,
                Zip = request.PayeeInfo?.Address?.ZipCode,

                Country = request.PayeeInfo?.Address?.CountryCode,

                MerchantId = request.MerchantInfo?.MerchantId,
                Zip4 = request.MerchantInfo?.Zip4

            };

            return addBillPayeeRequest;
        }
    }
}
