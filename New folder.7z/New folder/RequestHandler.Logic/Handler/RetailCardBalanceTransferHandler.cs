﻿using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using Newtonsoft.Json;
using RequestHandler.Core.Domain.Services.RetailCard.Model;
using RequestHandler.Core.Domain.Services.RetailCard;
using NLog;

namespace RequestHandler.Logic.Handler
{
    public class RetailCardBalanceTransferHandler : CommandHandlerBase<RetailCardBalanceTransferRequest, RetailCardBalanceTransferResponse>
    {
        private readonly IRetailCardService _retailCardService;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();

        public RetailCardBalanceTransferHandler(IRetailCardService retailCardService)
        {
            _retailCardService = retailCardService;
        }

        public override void SetDomainContext(RetailCardBalanceTransferRequest request)
        {

        }

        public override Task<RetailCardBalanceTransferResponse> VerifyIdentifiers(RetailCardBalanceTransferRequest request)
        {
            return Task.FromResult(new RetailCardBalanceTransferResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<RetailCardBalanceTransferResponse> Handle(RetailCardBalanceTransferRequest request)
        {
            try
            {
                var transferRetailTempCardBalanceResponse = _retailCardService.TransferRetailTempCardBalance(request.ProgramCode,
                    request.AccountIdentifier,
                    new MigrateAccountRequest()
                    {
                        ProgramCode = request.ProgramCode,
                        RequestId = request.RequestHeader.RequestId
                    });


                if (transferRetailTempCardBalanceResponse.StatusCode != 0)
                {
                    _logger.Error($"Error occurred in RetailCardBalanceTransferHandler. Invalid Response from TransferRetailTempCardBalance: {JsonConvert.SerializeObject(transferRetailTempCardBalanceResponse)}, requestId:{request.RequestHeader.RequestId},accountIdentifier:{request.AccountIdentifier},ProgramCode:{request.ProgramCode}");
                    throw new Exception($"Invalid Response from TransferRetailTempCardBalance call.");
                }

                var response = new RetailCardBalanceTransferResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    }
                };

                return Task.FromResult(response);
            }
            catch (Exception ex)
            {
                return Task.FromResult(ex.HandleException<RetailCardBalanceTransferResponse>(ex, request));
            }
        }
    }
}
