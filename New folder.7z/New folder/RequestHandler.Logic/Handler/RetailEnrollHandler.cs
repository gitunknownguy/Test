﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Services.Crypto;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Caching.Contract;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Infrastructure.DataAccesses;
using AccountHolder = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.AccountHolder;
using CardExpirationDate = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.CardExpirationDate;
using KycStateData = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class RetailEnrollHandler : CommandHandlerBase<RetailEnrollRequest, RetailEnrollResponse>
    {
        private readonly IRequestDataAccess _requestDataAccess;
        private readonly IEnrollmentDataAccess _enrollmentDataAccess;
        private readonly IRetailEnrollmentService _enrollmentService;
        private readonly ICryptoService _cryptoService;
        private readonly IIdempotentService _idempotentService;
        private readonly IAccountService _accountService;
        private readonly ILazyCache _lazyCache;
        private readonly IAgreementDataAccess _agreementRepository;


        public RetailEnrollHandler(IRequestDataAccess requestDataAccess, IEnrollmentDataAccess enrollmentDataAccess,
            IRetailEnrollmentService enrollmentService, ICryptoService cryptoService,
            IIdempotentService idempotentService,
            IAccountService accountService,
            ILazyCache lazyCache, IAgreementDataAccess agreementRepository)
        {
            _requestDataAccess = requestDataAccess;
            _enrollmentDataAccess = enrollmentDataAccess;
            _enrollmentService = enrollmentService;
            _cryptoService = cryptoService;
            _idempotentService = idempotentService;
            _accountService = accountService;
            _lazyCache = lazyCache;
            _agreementRepository = agreementRepository;
        }

        public override void SetDomainContext(RetailEnrollRequest request)
        {

        }

        public override Task<RetailEnrollResponse> VerifyIdentifiers(RetailEnrollRequest request)
        {
            return Task.FromResult(new RetailEnrollResponse() { ResponseHeader = new ResponseHeader() });
        }


        public override Task<RetailEnrollResponse> Handle(RetailEnrollRequest request)
        {
            try
            {
                //Does not hit since we currently used fixed address.
                //Keeping it though for potential future use.
                var denialResponse = DenyRestrictedRegionsEnrollment(request);
                if (denialResponse != null)
                    return denialResponse;

                var newAccountIdentifier = Guid.NewGuid();

                var existingRequestAccountIdentifier = _requestDataAccess.InsertRequestId(RequestType.Enroll,
                    request.RequestHeader.RequestId, newAccountIdentifier);

                //Account Limit is not checked in current retail card enrollment.
                //but Creating empty object accountLimit to pass into GetEnrollIdempotentResponse() method.

                var accountLimit = new AccountLimit();

                if (existingRequestAccountIdentifier.HasValue || accountLimit.AccountIdentifier != null)
                {
                    newAccountIdentifier = accountLimit.AccountIdentifier == null
                        ? existingRequestAccountIdentifier.Value
                        : accountLimit.AccountIdentifier.ToGuid();

                    var kycStateData = new Core.Domain.Model.Account.KycStateData();
                    var getEnrollmentResponse =
                        _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(newAccountIdentifier.ToString(),
                            request.ProgramCode, false);

                    if (getEnrollmentResponse?.Account != null)
                    {
                        var existingResponse = GetEnrollIdempotentResponse(getEnrollmentResponse, request, accountLimit, kycStateData, existingRequestAccountIdentifier, request.ContactVerificationIdentifiers);

                        return Task.FromResult(existingResponse);
                    }
                }

                var response = new RetailEnrollResponse();

                var userName = new UserName(request.UserCreationData?.ProfileData?.FirstName,
                    request.UserCreationData?.ProfileData?.MiddleName, request.UserCreationData?.ProfileData?.LastName);

                var email = request.UserCreationData?.Email?.ToDomain();

                var addresses =
                    request.UserCreationData?.ProfileData?.Addresses?.ToDomain();

                var phoneNumbers =
                    request.UserCreationData?.PhoneNumbers?.ToDomain();

                var userIdentifyingData = request.UserCreationData?.IdentifyingData?.ToDomain();

                var agreement =
                    _agreementRepository.GetAgreementsByProductCode(request.AccountCreationData.ProductCode);

                var terms = request.AccountCreationData.TermsAcceptances?.ToDomain(agreement);

                var enrollResponse = _enrollmentService.Enroll(newAccountIdentifier.ToString(), request.ProgramCode,
                    request.AccountCreationData.ProductCode, userName, userIdentifyingData, email, addresses,
                    phoneNumbers,
                    request.ContactVerificationIdentifiers,
                    request.ExecuteKycFlag,
                    request.RequestPhysicalCardFlag, terms,
                    request.AccountCreationData.ProductMaterialType,
                    request.AccountCreationData.CipLevel,
                    request.AccountCreationData.ProductClass,
                    request.AccountCreationData.Language,
                    true);


                var newUser = enrollResponse.Item2;
                var newAccount = enrollResponse.Item1;
                var newPaymentIdentifier = enrollResponse.Item3;
                var newAccountBalance = enrollResponse.Item4;
                var privateCardData = enrollResponse.Item5;

                _lazyCache?.Value?.Set(newAccount.AccountIdentifier.ToString(), newAccount.ErrorCode.ToString(),
                    new TimeSpan(1, 0, 0, 0));
                response.ResponseHeader = response.ResponseHeader.GetResponseHeader(newAccount.ErrorCode.ToString(),
                    request.RequestHeader.RequestId);

                response.AccountIdentifier = newAccount.AccountIdentifier.ToString();
                response.CustomerReferenceNumber = newAccount.CustomerAccountNumber;
                response.Status = newAccount.AccountStatus.ToString().ToLower();

                DateTime accountStatusDateChange = newAccount.AccountStatusChangedDateTime;
                accountStatusDateChange = accountStatusDateChange.ToUniversalTime();
                response.AccountStatusChangedDateTime =
                    accountStatusDateChange.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");


                if (newAccount.AccountStatusReasons?.Count > 0)
                {
                    response.StatusReasons = new List<string>();

                    foreach (Core.Domain.Model.Account.AccountStatusReason statusReason in newAccount
                        .AccountStatusReasons)
                    {
                        response.StatusReasons.Add(statusReason.ToString());
                    }
                }

                response.DirectDepositInformation = new DirectDepositInformation
                {
                    AccountNumber = newAccount.AccountNumber,
                    RoutingNumber = newAccount.RoutingNumber
                };


                if (newAccountBalance != null)
                {
                    response.Purses = new List<Purse>();
                    var purse = new Purse
                    {
                        PurseIdentifier = newAccountBalance.AccountBalanceIdentifier.ToString(),
                        PurseType = PurseType.Primary,
                        AvailableBalance = newAccountBalance.AvailableBalance,
                        LedgerBalance = newAccountBalance.CurrentBalance,
                        AvailableBalanceAsOfDateTime = newAccountBalance.AvailableBalanceAsOfDate,
                        LedgerBalanceAsOfDateTime = newAccountBalance.CurrentBalanceAsOfDate,
                        Status = newAccountBalance.Status
                    };
                    response.Purses.Add(purse);
                }

                response.AccountHolders = new List<AccountHolder>();
                var accountHolder = new AccountHolder();

                foreach (Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolder ah in newAccount.AccountHolders)
                {
                    accountHolder.User = new Bos.Shared.Common.Core.CoreApi.Contract.Data.User
                    {
                        UserIdentifier = newUser.UserIdentifier.ToString(),
                        Status = UserStatus.Active,
                        IsPrimaryAccountHolder = true,
                        KycStateData = new KycStateData
                        {
                            OfacStatus = ah.kycStateData.OfacStatus.ToString().ToLower(),
                            KycStatus = ah.kycStateData.KycStatus.ToString().ToLower(),
                            PendingKycGate = ah.kycStateData.KycPendingGate.ToLower()
                        }
                    };


                    if (newPaymentIdentifier != null)
                    {
                        accountHolder.PaymentInstruments = new List<PaymentInstrument>();
                        var paymentInstrument = new PaymentInstrument();
                        //PaymentInstrumentStatus paymentInstrumentStatus;
                        Enum.TryParse(newPaymentIdentifier.PaymentInstrument.Status, out PaymentInstrumentStatus paymentInstrumentStatus);

                        paymentInstrument.PaymentInstrumentIdentifier = newPaymentIdentifier?.PaymentInstrument
                            .PaymentInstrumentIdentifier.ToString();
                        paymentInstrument.PaymentInstrumentType =
                            newPaymentIdentifier.PaymentInstrument.PaymentInstrumentType;
                        paymentInstrument.Status = paymentInstrumentStatus;
                        paymentInstrument.IsPinSet = newPaymentIdentifier.PaymentInstrument.PinSetDate.HasValue;
                        paymentInstrument.Last4Pan = newPaymentIdentifier?.PaymentInstrument.Last4Pan;
                        paymentInstrument.ActivatedDateTime = newPaymentIdentifier?.PaymentInstrument.ActivatedDateTime;
                        paymentInstrument.IssuedDateTime = newPaymentIdentifier?.PaymentInstrument.IssuedDateTime;

                        if (paymentInstrument.PrivateCardData != null)
                        {
                            paymentInstrument.PrivateCardData =
                                new Bos.Shared.Common.Core.CoreApi.Contract.Data.PrivateCardData
                                {
                                    Pan = privateCardData?.Pan,
                                    Cvv = privateCardData?.Cvv,
                                    ExpirationDate = new CardExpirationDate
                                    {
                                        CardExpirationMonth = privateCardData?.CardExpirationDate.CardExpirationMonth,
                                        CardExpirationyear = privateCardData?.CardExpirationDate.CardExpirationYear
                                    }
                                };

                        }

                        accountHolder.PaymentInstruments.Add(paymentInstrument);
                    }

                    response.AccountHolders.Add(accountHolder);
                }

                //var accountResp = _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(newAccount.AccountIdentifier.ToString(), request.ProgramCode, false);

                //Turning off.
                //request is system generated with no actual client.
                //if (!request.RequestPhysicalCardFlag)
                //    MassagePNMessage(accountResp.Account);

                //_notificationPublisher.PublishNotification(request.ProgramCode, accountResp.Account, Bos.Shared.Common.Core.CoreApi.Contract.Data.EventType.AccountUpdated);
                //if (accountResp.Account.Status == "normal")
                //    _welcomeNotificationService.RaiseWelcomeNotification(request.ProgramCode, accountResp.Account.AccountIdentifier);

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<RetailEnrollResponse>(e, request));
            }
        }

        private Task<RetailEnrollResponse> DenyRestrictedRegionsEnrollment(RetailEnrollRequest request)
        {
            var state = request?.UserCreationData?.ProfileData?.Addresses?.FirstOrDefault()?.State;
            if (state != null && (state.Equals("PR", StringComparison.InvariantCultureIgnoreCase) ||
                state.Equals("GU", StringComparison.InvariantCultureIgnoreCase)))
            {
                return Task.FromResult(new RetailEnrollResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 5,
                        SubStatusCode = 65,
                        Message = "This product may not be registered in the requested region"
                    }
                });
            }

            return null;
        }




        //private void PublishUserUpdateNotification(UserName userName, List<Core.Domain.Model.User.Address> addresses,
        //    List<Core.Domain.Model.User.PhoneNumber> numbers,
        //    Core.Domain.Model.User.Email email, string accountIdentifier, string userIdentifier, string programCode)
        //{
        //    var profile = new Bos.Shared.Common.Core.CoreApi.Contract.Data.UserProfile
        //    {
        //        AccountIdentifier = accountIdentifier,
        //        UserIdentifier = userIdentifier
        //    };

        //    var profileData = new ProfileData
        //    {
        //        FirstName = userName?.FirstName,
        //        MiddleName = userName?.MiddleName,
        //        LastName = userName?.LastName,
        //        Addresses = ConvertToCommonAddresses(addresses)
        //    };

        //    profile.ProfileData = profileData;

        //    profile.PhoneNumbers = ConvertToCommonNumbers(numbers);            

        //    if (email != null)
        //    {
        //        var commonEmail = new Bos.Shared.Common.Core.CoreApi.Contract.Data.Email()
        //        {
        //            EmailAddress = email.EmailAddress,
        //            IsVerified = email.IsVerified,
        //            LastUpdatedDateTime = DateTime.UtcNow
        //        };
        //        profile.Email = commonEmail;
        //    }

        //    _notificationPublisher.PublishNotification(programCode, profile, EventType.UserUpdate);
        //}

        //private List<Address> ConvertToCommonAddresses(List<Core.Domain.Model.User.Address> addresses)
        //{

        //    if (addresses == null)
        //        return null;

        //    var newAddresses = new List<Address>();

        //    foreach (var address in addresses)
        //    {
        //        var newAddress = new Address()
        //        {
        //            AddressLine1 = address.AddressLine1,
        //            AddressLine2 = address.AddressLine2,
        //            City = address.City,
        //            IsDefault = address.IsDefault,
        //            IsReturned = false,
        //            IsVerified = false,
        //            LastUpdatedDateTime = DateTime.UtcNow,
        //            State = address.State,
        //            Type = address.Type,
        //            ZipCode = address.ZipCode
        //        };

        //        newAddresses.Add(newAddress);
        //    }

        //    return newAddresses;
        //}

        //private List<PhoneNumber> ConvertToCommonNumbers(List<Core.Domain.Model.User.PhoneNumber> phoneNumbers)
        //{
        //    if (phoneNumbers == null)
        //        return null;

        //    var commonNumbers = new List<PhoneNumber>();

        //    foreach (var phoneNumber in phoneNumbers)
        //    {
        //        var commonNumber = new PhoneNumber
        //        {
        //            IsDefault = phoneNumber.IsDefault,
        //            IsVerified = phoneNumber.IsVerified,
        //            Number = phoneNumber.Number,
        //            Type = phoneNumber.Type,
        //            LastUpdatedDateTime = DateTime.UtcNow
        //        };

        //        commonNumbers.Add(commonNumber);
        //    }

        //    return commonNumbers;
        //}

        private RetailEnrollResponse GetEnrollIdempotentResponse(GetEnrollmentResponse getEnrollmentResponse,
                                                           RetailEnrollRequest request,
                                                           AccountLimit accountLimit,
                                                           Core.Domain.Model.Account.KycStateData kycStateData,
                                                           Guid? existingRequestAccountIdentifier,
                                                           Guid[] contactVerificationIdentifiers)
        {
            string errorCode = string.Empty;
            var phoneNumbers = request.UserCreationData?.PhoneNumbers?.ToDomain();
            // keep only activated virtual as first enrollment does not 
            // return the magStripe payment instrument
            foreach (var ah in getEnrollmentResponse.Account.AccountHolders)
            {
                if (ah?.User?.DateOfBirth != request.UserCreationData?.IdentifyingData?.DateOfBirth)
                    throw new RequestHandlerException(2, 60, "Number of Active Accounts Exceeded.");

                if (string.IsNullOrEmpty(request.UserCreationData.IdentifyingData.OnBoardingId))
                {
                    if (string.IsNullOrEmpty(request.UserCreationData?.IdentifyingData?.Ssn))
                        _accountService.AccountLimitVerificationBySsnToken(ah?.SsnToken, request.AccountCreationData?.ProductCode, request.ProgramCode);
                }

                if (ah.PaymentInstruments == null ||
                    (ah.PaymentInstruments.Count(n =>
                         n.PaymentInstrumentType == PaymentInstrumentType.MagStripe ||
                         n.PaymentInstrumentType == PaymentInstrumentType.Emv ||
                         n.PaymentInstrumentType == PaymentInstrumentType.ContactlessEmv) == 0) &&
                    request.RequestPhysicalCardFlag)
                {
                    Core.Domain.Model.Account.KycStateData kycData = ah.User.KycStateData.ToDomain();

                    kycStateData = _idempotentService?.EnrollIdempotent(
                        existingRequestAccountIdentifier.Value.ToString(), ah.User?.UserIdentifier,
                        kycData, request.AccountCreationData.ProductMaterialType, request.ProgramCode,
                        request.RequestPhysicalCardFlag, request.AccountCreationData.CipLevel, request.UserCreationData?.IdentifyingData?.OnBoardingId, contactVerificationIdentifiers, phoneNumbers, ProductCode.FromString(getEnrollmentResponse.Account.ProductCode), getEnrollmentResponse.Account.ProductName);

                    errorCode = _lazyCache?.Value?.Get<string>(existingRequestAccountIdentifier.Value
                        .ToString());

                    if (kycStateData?.KycPendingGate != null)
                        getEnrollmentResponse =
                            _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(
                                existingRequestAccountIdentifier.Value.ToString(), request.ProgramCode,
                                true);

                    if (kycStateData?.KycPendingGate == "healthy")
                        foreach (var accHolder in getEnrollmentResponse.Account.AccountHolders)
                            accHolder.PaymentInstruments = accHolder.PaymentInstruments
                                ?.Where(x => x.PaymentInstrumentType == PaymentInstrumentType.Virtual)
                                .ToList();
                }
                else if (!request.RequestPhysicalCardFlag)
                {
                    ah.PaymentInstruments = ah.PaymentInstruments
                        ?.Where(x => x.PaymentInstrumentType == PaymentInstrumentType.Virtual).ToList();
                }
            }

            var existingResponse = new RetailEnrollResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                },
                AccountIdentifier = getEnrollmentResponse.Account.AccountIdentifier,
                CustomerReferenceNumber = getEnrollmentResponse.Account.CustomerReferenceNumber,
                Status = getEnrollmentResponse.Account.Status,
                StatusReasons = getEnrollmentResponse.Account.StatusReasons,
                StatusCure = getEnrollmentResponse.Account.StatusCure,
                DirectDepositInformation = getEnrollmentResponse.Account.DirectDepositInformation,
                Purses = getEnrollmentResponse.Account.Purses,
                AccountHolders = getEnrollmentResponse.Account.AccountHolders,
                AccountStatusChangedDateTime = getEnrollmentResponse.Account?.AccountStatusChangedDateTime
            };

            existingResponse.ResponseHeader = existingResponse.ResponseHeader?.GetResponseHeader(!string.IsNullOrEmpty(errorCode) ?
                errorCode : kycStateData?.ResponseCode.ToString(), request.RequestHeader.RequestId);

            if (accountLimit?.ResponseCode == "260" && !existingRequestAccountIdentifier.HasValue)
            {
                existingResponse.ResponseHeader =
                    existingResponse.ResponseHeader?.GetResponseHeader(
                        accountLimit.ResponseCode, request.RequestHeader.RequestId);
            }

            var existingPaymentInstrument = existingResponse.AccountHolders.FirstOrDefault()
                ?.PaymentInstruments?.FirstOrDefault();
            var existingPrivateCardData = existingPaymentInstrument?.PrivateCardData;

            if (existingPrivateCardData != null
                && existingPaymentInstrument.PaymentInstrumentType == PaymentInstrumentType.Virtual)
            {
                var generateCvvResponse = _cryptoService.GenerateCvv(
                    AccountIdentifier.FromString(getEnrollmentResponse.Account.AccountIdentifier),
                    existingPrivateCardData.Pan,
                    existingPrivateCardData.ExpirationDate.CardExpirationyear.Substring(2) +
                    existingPrivateCardData.ExpirationDate.CardExpirationMonth,
                    existingPaymentInstrument.PaymentInstrumentType);

                existingPrivateCardData.Pan = existingPrivateCardData.Pan;
                existingPrivateCardData.Cvv = generateCvvResponse.Cvv;
            }


            if (existingPaymentInstrument?.IsPinSet == false)
                existingPaymentInstrument.PrivateCardData = null;

            //No notification.
            ////_notificationPublisher.PublishNotification(request.ProgramCode, getEnrollmentResponse.Account, EventType.AccountUpdated);

            return existingResponse;
        }

        ///// <summary>
        ///// make PN message equivalent to enrollment response
        ///// </summary>
        ///// <param name="account"></param>
        ///// <returns></returns>
        //private Account MassagePNMessage(Account account)
        //      {
        //          foreach (var accHolder in account.AccountHolders)
        //          {
        //              // remove all PI which are not virtual cards
        //              accHolder.PaymentInstruments = accHolder.PaymentInstruments?.Where(x => x.PaymentInstrumentType == PaymentInstrumentType.Virtual).ToList();
        //          }
        //          return account; 
        //      }

    }
}
