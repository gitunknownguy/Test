﻿using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Model.User.PreInterventions;
using Gd.Bos.RequestHandler.Core.Domain.Services.Crypto;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Core.Infrastructure.DataAccesses;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Logic.Service;
using RequestHandler.Core.Application;
using RequestHandler.Core.Utils;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;

namespace RequestHandler.Logic.Handler
{
    public class BusinessOwnerInfoHandler : CommandHandlerBase<OwnerProfileRequest, OwnerProfileResponse>
    {
        private readonly ISaveBusinessOwnerInfoService _saveBusinessOwnerInfoService;
        private readonly IValidateIdentifier _validateIdentifier;

        public BusinessOwnerInfoHandler(ISaveBusinessOwnerInfoService saveBusinessOwnerInfoService
       , IValidateIdentifier validateIdentifier)
        {
            _saveBusinessOwnerInfoService = saveBusinessOwnerInfoService;
            _validateIdentifier = validateIdentifier;

        }
        public override void SetDomainContext(OwnerProfileRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
            {
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            }
        }
        public override Task<OwnerProfileResponse> VerifyIdentifiers(OwnerProfileRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidatePartner_AccountIdProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new OwnerProfileResponse()
                {
                    ResponseHeader = new ResponseHeader()
                });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<OwnerProfileResponse>(e, request));
            }
        }
        public override Task<OwnerProfileResponse> Handle(OwnerProfileRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.AccountIdentifier))
                    throw new AccountNotFoundException();
                var addOwnerProfileRequest = new OwnerProfileRequest()
                {
                    AccountIdentifier = request.AccountIdentifier,
                    ProgramCode = request.ProgramCode,
                    RequestHeader = request.RequestHeader,
                    OwnerProfileData = new OwnerProfileData()
                    {
                        IsVerified = request.OwnerProfileData.IsVerified,
                        IsConfirmedIndividual = request.OwnerProfileData.IsConfirmedIndividual,
                        FirstName = request.OwnerProfileData.FirstName,
                        MiddleName = request.OwnerProfileData.MiddleName,
                        LastName = request.OwnerProfileData.LastName,
                        AddressLineOne = request.OwnerProfileData.AddressLineOne,
                        AddressLineTwo = request.OwnerProfileData.AddressLineTwo,
                        State = request.OwnerProfileData.State,
                        City = request.OwnerProfileData.City,
                        SSN = request.OwnerProfileData.SSN,
                        DOB = request.OwnerProfileData.DOB,
                        Zip = request.OwnerProfileData.Zip

                    }
                };

                var response = _saveBusinessOwnerInfoService.SaveBusinessOwnerInfo(addOwnerProfileRequest);
                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<OwnerProfileResponse>(e, request));
            }

        }

    }
}
