﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class UpdateCheckHandler : CommandHandlerBase<UpdateCheckRequest, UpdateCheckResponse>
    {
        private static string unspecifiedGuid = Guid.Empty.ToString();
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ITransferService _transferService;
        private readonly ILockService _lockService;
        public UpdateCheckHandler(ITransferService transferService, IValidateIdentifier validateIdentifier, ILockService lockService)
        {
            _transferService = transferService;
            _validateIdentifier = validateIdentifier;
            _lockService = lockService;
        }

        public override void SetDomainContext(UpdateCheckRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<UpdateCheckResponse> VerifyIdentifiers(UpdateCheckRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new UpdateCheckResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpdateCheckResponse>(e, request));
            }
        }

        public override Task<UpdateCheckResponse> Handle(UpdateCheckRequest request)
        {
            try
            {
                if (request.RequestHeader.RequestId == Guid.Empty)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId,
                        $"{nameof(request)}.RequestHeader.RequestId must be specified");
                }

                if (string.IsNullOrEmpty(request.TransferIdentifier) || request.TransferIdentifier == unspecifiedGuid)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier,
                        $"{nameof(request)}.TransferIdentifier must be specified");
                }

                UpdateCheckResponse response = _transferService.UpdateCheck(request);
                return Task.FromResult(new UpdateCheckResponse()
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "success"
                    },
                    Transfer = new MrdcTransfer()
                    {
                        CheckDeposit = new CheckDeposit()
                        {
                            CheckDepositStatus = response.Transfer?.CheckDeposit.CheckDepositStatus,
                            CheckDepositSubStatus = response.Transfer?.CheckDeposit.CheckDepositSubStatus,
                            TransactionAmount = response.Transfer?.CheckDeposit.TransactionAmount ?? 0,
                        },
                        TransferStatus = response.Transfer?.TransferStatus,
                        TransferIdentifier = response.Transfer?.TransferIdentifier
                    }
                });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpdateCheckResponse>(e, request));
            }

        }

        public override async Task<UpdateCheckResponse> ObtainLock(UpdateCheckRequest request)
        {
            try
            {
                var lockId = request.AccountIdentifier + request.TransferIdentifier;

                await _lockService.ObtainApiLock($"MRDC_UpdateCheck_{lockId}");

                return new UpdateCheckResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<UpdateCheckResponse>(e, request);
            }
        }


        public override void ReleaseLock(UpdateCheckRequest request)
        {
            var lockId = request.AccountIdentifier + request.TransferIdentifier;

            _lockService.ReleaseApiLock($"MRDC_UpdateCheck_{lockId}");
        }
    }
}
