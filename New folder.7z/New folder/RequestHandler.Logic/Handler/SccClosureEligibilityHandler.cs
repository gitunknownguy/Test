﻿using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Enums;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Services.Core;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.UtilityCoreApi.Contract.Enum;
using Gd.Bos.Shared.Common.UtilityCoreApi.Contract.Message.Request;
using RequestHeader = Gd.Bos.Shared.Common.Contract.Message.Request.RequestHeader;
using Gd.Bos.Shared.Common.UtilityCoreApi.Contract.Data;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class SccClosureEligibilityHandler : CommandHandlerBase<SccClosureEligibilityRequest, SccClosureEligibilityResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IRiskService _riskService;
        private readonly IAccountService _accountService;
        private readonly IUtilityCoreWebApiClient _utilityCoreClient;

        public SccClosureEligibilityHandler(IValidateIdentifier validateIdentifier,
            IRiskService riskService,
            IAccountService accountService,
            IUtilityCoreWebApiClient utilityCoreClient)
        {
            _validateIdentifier = validateIdentifier;
            _riskService = riskService;
            _accountService = accountService;
            _utilityCoreClient = utilityCoreClient;
        }
        public override void SetDomainContext(SccClosureEligibilityRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            if (!string.IsNullOrEmpty(request.ProgramCode))
                DomainContext.Current.ProgramCode = ProgramCode.FromString(request.ProgramCode);
        }

        public override Task<SccClosureEligibilityResponse> VerifyIdentifiers(SccClosureEligibilityRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new SccClosureEligibilityResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<SccClosureEligibilityResponse>(e, request));
            }
        }

        public override Task<SccClosureEligibilityResponse> Handle(SccClosureEligibilityRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.AccountIdentifier))
                    throw new ArgumentNullException(nameof(request.AccountIdentifier));

                var response = new SccClosureEligibilityResponse()
                {
                    ResponseHeader = new ResponseHeader
                    {
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success",
                        ResponseId = request.RequestHeader.RequestId
                    }
                };

                //GetAccountsBySccAccountIdentifier will return both dda and scc accounts，when you call this with a dda account with scc
                //but this api is for scc only
                //so GetAccountsBySccAccountIdentifier even returns all info we need we have to call GetAccountBinType first
                var accountBinType = _accountService.GetAccountBinType(request.AccountIdentifier);
                if (BinType.Credit != accountBinType)
                {
                    throw new ValidationException(10, 0, "This is not an SCC account");
                }


                var sccAccounts = _accountService.GetAccountsBySccAccountIdentifier(request.AccountIdentifier);
                var sccAccount = sccAccounts.SingleOrDefault(a => a.BinType == BinType.Credit && a.AccountIdentifier.ToString().ToLower() == request.AccountIdentifier.ToLower());

                //here keep return code=10 confirmed with po
                if (sccAccount == null || BinType.Credit != sccAccount.BinType)
                {
                    throw new ValidationException(10, 0, "This is not an SCC account");
                }

                //here to replace the old risk API
                if (sccAccount.AccountStatus == AccountStatus.Closed ||
                    sccAccount.AccountHolderCureKey == AccountHolderCure.None)
                {
                    response.ResponseHeader.StatusCode = 5;
                    response.ResponseHeader.SubStatusCode = 361;
                    response.ResponseHeader.Message = "SCC account can not be closed due to being closed already or cure being none";
                    return Task.FromResult(response);
                }

                var paymentInfoResult = GetActiveAmmRuleData(request);
                response.ScheduledPaymentInfo = paymentInfoResult.Item1;
                response.HasActiveScheduledPayments = paymentInfoResult.Item2;

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<SccClosureEligibilityResponse>(e, request));
            }
        }

        private Tuple<ScheduledPaymentInfo, bool> GetActiveAmmRuleData(SccClosureEligibilityRequest request)
        {
            var getAmmRuleRequest = new GetAMMRuleRequest
            {
                RequestHeader = new RequestHeader
                {
                    RequestId = request.RequestHeader.RequestId
                },
                TargetAccountId = Guid.Parse(request.AccountIdentifier),
                TransferType = AMMTransferType.SccPayment,
                IncludeTransactions = true,
                ProgramCode = request.ProgramCode
            };

            var getAmmRulesResponse = _utilityCoreClient.GetActiveAmmRules(getAmmRuleRequest);
            if ((getAmmRulesResponse.Rules?.Count ?? 0) == 0)
            {
                return new Tuple<ScheduledPaymentInfo, bool>(null, false);
            }

            var processNextPayment = getAmmRulesResponse.Rules.Any(r => r.NextExecutionDate?.Date == DateTime.Today);

            var recurringPayments = getAmmRulesResponse.Rules.Where(r =>
                r.RuleFrequencyType == AMMRuleFrequencyType.Monthly && r.EndDate > DateTime.Now.AddMonths(1)).ToList();

            ScheduledPaymentInfo paymentInfo = null;
            if (recurringPayments.Any())
            {
                var recurringPayment = recurringPayments.OrderBy(r => r.NextExecutionDate).First();
                paymentInfo = ConvertScheduledPayment(recurringPayment, true);
                return new Tuple<ScheduledPaymentInfo, bool>(paymentInfo, processNextPayment);
            }

            var latestPayment = getAmmRulesResponse.Rules.Where(r => r.NextExecutionDate != null)
                .OrderBy(r => r.NextExecutionDate).FirstOrDefault();

            paymentInfo = ConvertScheduledPayment(latestPayment, false);
            return new Tuple<ScheduledPaymentInfo, bool>(paymentInfo, processNextPayment);
        }

        private ScheduledPaymentInfo ConvertScheduledPayment(AMMRule rule, bool isRecurring)
        {


            var nextExecutionDate = rule.NextExecutionDate > DateTime.Now ? rule.NextExecutionDate : DateTime.Now;
            var schedulePayment = new ScheduledPaymentInfo
            {
                Type = !isRecurring ? "oneTime" : "recurring",
                PaymentDay = GetPaymentDay(rule),
                ProcessNextPayment = nextExecutionDate.Value.Date == DateTime.Today,


            };

            SetInfo(schedulePayment);

            return schedulePayment;

        }

        private string GetPaymentDay(AMMRule rule)
        {
            if (rule.RuleFrequencyType == AMMRuleFrequencyType.OneTime)
            {
                return rule.StartDate.ToString("MM/dd/yyyy");
            }

            return $"{AddOrdinal(rule.ScheduleDay)} of every month";
        }

        private void SetInfo(ScheduledPaymentInfo paymentInfo)
        {
            paymentInfo.Info = !paymentInfo.ProcessNextPayment
                ? $"Payment has been set up on your account for {paymentInfo.PaymentDay} which is later than today. Your account will be closed after that payment has been automatically cancelled."
                : $"Payment has been set up on your account for {paymentInfo.PaymentDay} which is today. Your account will be closed after that payment has been processed.";
        }

        private string AddOrdinal(short num)
        {
            if (num <= 0) return num.ToString();

            switch (num % 100)
            {
                case 11:
                case 12:
                case 13:
                    return num + "th";
            }

            switch (num % 10)
            {
                case 1:
                    return num + "st";
                case 2:
                    return num + "nd";
                case 3:
                    return num + "rd";
                default:
                    return num + "th";
            }
        }

    }
}
