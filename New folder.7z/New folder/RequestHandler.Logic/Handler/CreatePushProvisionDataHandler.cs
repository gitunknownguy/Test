﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;


namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class CreatePushProvisionDataHandler : CommandHandlerBase<CreatePushProvisionDataRequest, CreatePushProvisionDataResponse>
    {
        public CreatePushProvisionDataHandler(
            IPushProvisioningService pushProvisioningService,
            IValidateIdentifier validateIdentifier)
        {
            _pushProvisioningService = pushProvisioningService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(CreatePushProvisionDataRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            if (!string.IsNullOrEmpty(request.PaymentInstrumentIdentifier))
                DomainContext.Current.PaymentInstrumentIdentifier = request.PaymentInstrumentIdentifier;
        }

        public override Task<CreatePushProvisionDataResponse> VerifyIdentifiers(CreatePushProvisionDataRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidatePaymentInstrumentIdentifier(DomainContext.Current.AccountIdentifier, DomainContext.Current.PaymentInstrumentIdentifier);
                return Task.FromResult(new CreatePushProvisionDataResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CreatePushProvisionDataResponse>(e, request));
            }
        }

        public override Task<CreatePushProvisionDataResponse> Handle(CreatePushProvisionDataRequest request)
        {
            try
            {
                if (request.WalletProvider == WalletProvider.Apple)
                {
                    return Task.FromResult(_pushProvisioningService.CreateApplePushProvisioningData(request));
                }

                return Task.FromResult(_pushProvisioningService.CreateGooglePushProvisioningData(request));
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CreatePushProvisionDataResponse>(e, request));
            }
        }

        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IPushProvisioningService _pushProvisioningService;
    }
}