﻿using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.GFTCustomers;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.GFTCustomers;
using RequestHandler.Core.Domain.Services.GlobalFundTransfer;
using System;
using System.Collections.Generic;
using System.Text;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using NLog;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using RequestHandler.Core.Domain.Services.GlobalFundTransfer.Contracts;
using System.Linq;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Common;

namespace RequestHandler.Logic.Handler
{
    public class GFTCustomersGetCustomerProfileHandler : CommandHandlerBase<GFTCustomersGetCustomerProfileRequest, GFTCustomersGetCustomerProfileResponse>
    {
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        private readonly IGlobalFundTransferService _globalFundTransferService;
        private readonly IBaasConfiguration _baasConfiguration;

        public GFTCustomersGetCustomerProfileHandler(IGlobalFundTransferService globalFundTransferService, IBaasConfiguration baasConfiguration)
        {
            _globalFundTransferService = globalFundTransferService;
            _baasConfiguration = baasConfiguration;
        }

        public override void SetDomainContext(GFTCustomersGetCustomerProfileRequest request)
        {

        }

        public override Task<GFTCustomersGetCustomerProfileResponse> VerifyIdentifiers(GFTCustomersGetCustomerProfileRequest request)
        {
            try
            {
                return Task.FromResult(new GFTCustomersGetCustomerProfileResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GFTCustomersGetCustomerProfileResponse>(e, request));
            }
        }

        public override Task<GFTCustomersGetCustomerProfileResponse> Handle(GFTCustomersGetCustomerProfileRequest request)
        {
            try
            {
                if (!GFTCustomerTokenMapping.IsValidCustomerType(request.CustomerType))
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier, $"{nameof(request)}.Customer type is invalid");
                }

                var getCustomerProfileRequest = new GetCustomerProfileRequest
                {
                    ProgramCode = request.ProgramCode,
                    CustomerToken = request.CustomerToken,
                    RequestId = request.RequestHeader.RequestId.ToString()
                };

                var getCustomerProfileResponse = _globalFundTransferService.GetCustomerProfile(getCustomerProfileRequest, getCustomerProfileRequest.CustomerToken);

                if (getCustomerProfileResponse == null || getCustomerProfileResponse.ResponseDetails == null)
                    throw new RequestHandlerException(0, 404, "getCustomerProfileResponse is null");

                GFTCustomersGetCustomerProfileResponse response = new GFTCustomersGetCustomerProfileResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    }
                };

                if (getCustomerProfileResponse.ResponseDetails.Any())
                {
                    var firstDetail = getCustomerProfileResponse.ResponseDetails.First();

                    if (string.Compare(firstDetail.Description, "Success", StringComparison.OrdinalIgnoreCase) == 0)
                    {
                        response.ResponseHeader.Message = firstDetail.Description;
                        response.ResponseHeader.Details = firstDetail.Description;
                        response.ResponseHeader.StatusCode = firstDetail.Code;
                        response.ResponseHeader.SubStatusCode = firstDetail.SubCode;

                        response.Customer = new GFTCustomersGetCustomerProfileResponse._.Customer
                        {
                            CustomerToken = request.CustomerToken,
                            CustomerType = request.CustomerType,
                            FirstName = getCustomerProfileResponse.Customer?.FirstName,
                            LastName = getCustomerProfileResponse.Customer?.LastName,
                            MiddleName = getCustomerProfileResponse.Customer?.MiddleName,
                            Email = getCustomerProfileResponse.Customer?.Email,
                            PhoneNumber = getCustomerProfileResponse.Customer?.PhoneNumber,
                            DateOfBirth = getCustomerProfileResponse.Customer?.DateOfBirth,
                            ProgramCode = getCustomerProfileResponse.Customer?.ProgramCode,
                            Status = getCustomerProfileResponse.Customer?.Status,
                            Address = new GFTCustomersGetCustomerProfileResponse._.Address
                            {
                                AddressLine1 = getCustomerProfileResponse.Customer?.Address?.AddressLine1,
                                AddressLine2 = getCustomerProfileResponse.Customer?.Address?.AddressLine2,
                                City = getCustomerProfileResponse.Customer?.Address?.AddressLine1,
                                State = getCustomerProfileResponse.Customer?.Address?.State,
                                ZipCode = getCustomerProfileResponse.Customer?.Address?.ZipCode,
                            },
                            CustomerKey = (long)(getCustomerProfileResponse.Customer?.CustomerKey),
                            CustomerId = getCustomerProfileResponse.Customer?.CustomerId,
                        };

                    }
                }
                else
                {
                    response.ResponseHeader.Message = "Unknown Error";
                    response.ResponseHeader.Details = "Unknown Error";
                    response.ResponseHeader.StatusCode = 4214;
                    response.ResponseHeader.SubStatusCode = 1514;
                }

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                var eResult = e.HandleException<GFTCustomersGetCustomerProfileResponse>(e, request);

                Logger.Info($"post GetCustomerProfile failure, prospectId:{DomainContext.Current.ProspectIdentifier},prospectType:{DomainContext.Current.ProspectType},statusCode:{eResult.ResponseHeader.StatusCode},subStatusCode:{eResult.ResponseHeader.SubStatusCode},statusMessage:{eResult.ResponseHeader.Message},statusDetails:{eResult.ResponseHeader.Details}");
                return Task.FromResult(eResult);
            }
        }
    }
}
