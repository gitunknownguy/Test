﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Event;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.PointsSystem;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class SendPointsEventHandler : CommandHandlerBase<PointsBehavioralEventRequest, PointsBehavioralEventResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IPointsSystemService _pointsSystemService;

        public SendPointsEventHandler(IPointsSystemService pointsSystemService, IValidateIdentifier validateIdentifier)
        {
            _pointsSystemService = pointsSystemService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(PointsBehavioralEventRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<PointsBehavioralEventResponse> VerifyIdentifiers(PointsBehavioralEventRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new PointsBehavioralEventResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<PointsBehavioralEventResponse>(e, request));
            }
        }

        public override Task<PointsBehavioralEventResponse> Handle(PointsBehavioralEventRequest request)
        {
            try
            {
                var response = _pointsSystemService.SendPointsEvent(request);

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<PointsBehavioralEventResponse>(e, request));
            }
        }
    }
}
