﻿using System;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;

namespace RequestHandler.Logic.Handler
{
    public class GetStatementTypeConfigHandler : CommandHandlerBase<GetStatementTypeConfigRequest, GetStatementTypeConfigResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IBaasConfiguration _baasConfiguration;

        public GetStatementTypeConfigHandler(IValidateIdentifier validateIdentifier, IBaasConfiguration baasConfiguration)
        {
            _validateIdentifier = validateIdentifier;
            _baasConfiguration = baasConfiguration;
        }

        public override void SetDomainContext(GetStatementTypeConfigRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.ProgramCode))
                return;
            
            DomainContext.Current.ProgramCode = ProgramCode.FromString(request.ProgramCode);
        }

        public override Task<GetStatementTypeConfigResponse> VerifyIdentifiers(GetStatementTypeConfigRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetStatementTypeConfigResponse { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetStatementTypeConfigResponse>(e, request));
            }
        }

        public override Task<GetStatementTypeConfigResponse> Handle(GetStatementTypeConfigRequest request)
        {
            try
            {
                var config = _baasConfiguration.GetProgramConfigByProgramCodeAsync(request.ProgramCode);

                if (!Enum.TryParse(config, out StatementTypeConfig statementTypeConfig))
                {
                    statementTypeConfig = StatementTypeConfig.ProgramCode;
                }

                return Task.FromResult(
                    new GetStatementTypeConfigResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 0,
                            SubStatusCode = 0,
                            Message = "Success"
                        },
                        StatementTypeConfig = statementTypeConfig,
                        ProgramCode = request.ProgramCode
                    });
            }
            catch (Exception e)
            {
                return Task
                    .FromResult(e.HandleException<GetStatementTypeConfigResponse>(e, request));
            }
        }
    }
}
