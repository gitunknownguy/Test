﻿using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;

namespace RequestHandler.Logic.Handler
{
    public class IdvSocureDocumentUrlRequestHandler : CommandHandlerBase<SocureIDVDocumentUrlRequest, SocureIDVDocumentUrlResponse>
    {
        private readonly IIdvSocureService _idvSocureService;

        public IdvSocureDocumentUrlRequestHandler(IIdvSocureService idvSocureService)
        {
            _idvSocureService = idvSocureService;
        }

        public override Task<SocureIDVDocumentUrlResponse> Handle(SocureIDVDocumentUrlRequest request)
        {
            var response = _idvSocureService.ProcessDocumentUrlRequest(request);
            return Task.FromResult(response);
        }
        public override void SetDomainContext(SocureIDVDocumentUrlRequest request)
        {
        }
        public override Task<SocureIDVDocumentUrlResponse> VerifyIdentifiers(SocureIDVDocumentUrlRequest request)
        {
            return Task.FromResult(new SocureIDVDocumentUrlResponse() { ResponseHeader = new ResponseHeader() });
        }
    }
}
