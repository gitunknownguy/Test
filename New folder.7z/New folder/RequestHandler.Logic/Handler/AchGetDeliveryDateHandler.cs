﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Services.Ach;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using GetAchDeliveryDateRequest = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.GetAchDeliveryDateRequest;
using GetAchDeliveryDateResponse = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.GetAchDeliveryDateResponse;


namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class AchGetDeliveryDateHandler : CommandHandlerBase<GetAchDeliveryDateRequest, GetAchDeliveryDateResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IAchService _achService;
        public AchGetDeliveryDateHandler(IValidateIdentifier validateIdentifier, IAchService achService)
        {
            _validateIdentifier = validateIdentifier;
            _achService = achService;
        }

        public override void SetDomainContext(GetAchDeliveryDateRequest request)
        {
        }

        public override Task<GetAchDeliveryDateResponse> VerifyIdentifiers(GetAchDeliveryDateRequest request)
        {
            return Task.FromResult(new GetAchDeliveryDateResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<GetAchDeliveryDateResponse> Handle(GetAchDeliveryDateRequest request)
        {
            var domainRequest = new Core.Domain.Services.Ach.GetAchDeliveryDateRequest()
            {
                PartnerID = request.ProgramCode,
                ACHDeliveryType = request.AchDeliveryType,
                ScheduleDate = request.ScheduleDate,
                TransferType = request.TransferType
            };
            try
            {
                var domainResponse = _achService.GetAchDeliveryDate(domainRequest);
                if (domainResponse == null)
                    throw new RequestHandlerException(503, 0,
                        $"Unable to Get Delivery Date for ProgramCode: {domainRequest.PartnerID}, " +
                        $"ACHDeliveryType: {domainRequest.ACHDeliveryType}, ScheduleDate: {domainRequest.ScheduleDate}, TransferType: {domainRequest.TransferType}");
                var response = new GetAchDeliveryDateResponse()
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                    AchDeliveryDate = domainResponse.AchDeliveryDate
                };
                SetResponseCode(response, domainResponse);
                return Task.FromResult(response);

            }
            catch (Exception ex)
            {
                return Task.FromResult(ex.HandleException<GetAchDeliveryDateResponse>(ex, request));
            }

        }

        private void SetResponseCode(GetAchDeliveryDateResponse response,
            Gd.Bos.RequestHandler.Core.Domain.Services.Ach.GetAchDeliveryDateResponse domainResponse)
        {

            switch (domainResponse.ErrorCode)
            {
                case "00001":
                    response.ResponseHeader.StatusCode = 400;
                    response.ResponseHeader.SubStatusCode = 0;
                    response.ResponseHeader.Message = "Some required input values are invalid.";
                    break;
                case "00003":
                    response.ResponseHeader.StatusCode = 400;
                    response.ResponseHeader.SubStatusCode = 0;
                    response.ResponseHeader.Message = "Schedule Window Elapsed.";
                    break;
                case "00004":
                    response.ResponseHeader.StatusCode = 400;
                    response.ResponseHeader.SubStatusCode = 0;
                    response.ResponseHeader.Message = "Invalid ACH Schedule Date.";
                    break;
                case "00218":
                    response.ResponseHeader.StatusCode = 101;
                    response.ResponseHeader.SubStatusCode = 218;
                    response.ResponseHeader.Message = "Invalid Program Code.";
                    break;
                case "00219":
                    response.ResponseHeader.StatusCode = 600;
                    response.ResponseHeader.SubStatusCode = 219;
                    response.ResponseHeader.Message = "Invalid Delivery Type.";
                    break;

            }
        }
    }
}
