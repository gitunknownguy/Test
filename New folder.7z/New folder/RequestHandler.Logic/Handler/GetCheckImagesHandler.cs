﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetCheckImagesHandler : CommandHandlerBase<GetCheckImagesRequest, GetCheckImagesResponse>
    {
        private static string unspecifiedGuid = Guid.Empty.ToString();
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ITransferService _transferService;
        public GetCheckImagesHandler(ITransferService transferService, IValidateIdentifier validateIdentifier)
        {
            _transferService = transferService;
            _validateIdentifier = validateIdentifier;
        }
        public override Task<GetCheckImagesResponse> Handle(GetCheckImagesRequest request)
        {
            try
            {
                if (request.RequestHeader.RequestId == Guid.Empty)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId,
                        $"{nameof(request)}.RequestHeader.RequestId must be specified");
                }

                if (string.IsNullOrEmpty(request.TransferIdentifier) || request.TransferIdentifier == unspecifiedGuid)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier,
                        $"{nameof(request)}.TransferIdentifier must be specified");
                }

                GetCheckImagesResponse response = _transferService.GetCheckImages(request);
                return Task.FromResult(new GetCheckImagesResponse()
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "success"
                    },
                    BackImage = response.BackImage,
                    FrontImage = response.FrontImage
                });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetCheckImagesResponse>(e, request));
            }
        }

        public override void SetDomainContext(GetCheckImagesRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetCheckImagesResponse> VerifyIdentifiers(GetCheckImagesRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetCheckImagesResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetCheckImagesResponse>(e, request));
            }
        }
    }
}
