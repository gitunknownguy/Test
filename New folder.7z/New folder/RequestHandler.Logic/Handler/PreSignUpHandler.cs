﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DnsClient;
using Gd.Bos.Logging.Common.Constants;
using Gd.Bos.Logging.Common.IManagers;
using Gd.Bos.Logging.Common.Managers;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Business;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Model.User.PreInterventions;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;
using RequestHandler.Core.Domain.Enums;
using RequestHandler.Core.Domain.Services.Risk;
using RequestHandler.Core.Infrastructure.Enrollment;
using RequestHandler.Logic.Handler;
using AccountHolderCure = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.AccountHolderCure;
using RequestHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.RequestHeader;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using VerificationStatus = Gd.Bos.RequestHandler.Core.Domain.Model.Account.VerificationStatus;

namespace RequestHandler.Logic.Handler
{
    public class PreSignUpHandler : CommandHandlerBase<PreSignUpRequest, PreSignUpResponse>
    {
        private readonly ITokenizerService _tokenizerService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IRequestDataAccess _requestDataAccess;
        private readonly IBaasConfiguration _baasConfiguration;
        private readonly IAccountService _accountService;
        private readonly ILazyCache _lazyCache;
        private readonly IEnrollmentService _enrollmentService;
        private readonly IProductService _productService;
        private readonly IAddressIntervention _addressIntervention;
        private readonly IGssFraudEventService _gssFraudEventService;
        private readonly IIdvSocureService _idvSocureService;
        private const string FraudIdentityReasonGovSan = "gov-mi-san";


        private readonly ILogManager _logManager = new LogManager();

        public PreSignUpHandler(
            ITokenizerService tokenizerService,
            IValidateIdentifier validateIdentifier,
            IRequestDataAccess requestDataAccess,
            IBaasConfiguration baasConfiguration,
            ILazyCache lazyCache,
            IEnrollmentService enrollmentService,
            IProductService productService,
            IAddressIntervention addressIntervention,
            IGssFraudEventService gssFraudEventService,
            IAccountService accountService,
            IIdvSocureService idvSocureService)
        {
            _tokenizerService = tokenizerService;
            _validateIdentifier = validateIdentifier;
            _requestDataAccess = requestDataAccess;
            _baasConfiguration = baasConfiguration;
            _lazyCache = lazyCache;
            _enrollmentService = enrollmentService;
            _productService = productService;
            _addressIntervention = addressIntervention;
            _accountService = accountService;
            _gssFraudEventService = gssFraudEventService;
            _idvSocureService = idvSocureService;
        }

        public override void SetDomainContext(PreSignUpRequest request)
        {
            if (!string.IsNullOrEmpty(request.UserCreationData.IdentifyingData?.Ssn))
                DomainContext.Current.TokenizedIdentity = _tokenizerService.TokenizeSsn(request.UserCreationData.IdentifyingData.Ssn, DomainContext.Current.ProgramCode.ToString());

            DomainContext.Current.IgnoreMfa = request.RequestHeader?.IgnoreMfa;
        }

        public override Task<PreSignUpResponse> VerifyIdentifiers(PreSignUpRequest request)
        {
            return Task.FromResult(new PreSignUpResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<PreSignUpResponse> Handle(PreSignUpRequest request)
        {
            var isAcceptMinorEnrollment = _baasConfiguration.IsAcceptMinorEnrollment(request.ProgramCode, request.AccountCreationData.ProductCode);

            if (string.IsNullOrEmpty(request.UserCreationData.IdentifyingData.IdentityValue))
            {
                return Task.FromResult(new PreSignUpResponse()
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 400,
                        SubStatusCode = 1543,
                        Message = "IdentityValue is required",
                        Details = "IdentityValue is required"
                    },
                    RegistrationToken = String.Empty,
                    VerificationStatus = String.Empty
                });
            }
            if (string.IsNullOrEmpty(request.UserCreationData.IdentifyingData.IdentityCountryCode))
            {
                return Task.FromResult(new PreSignUpResponse()
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 400,
                        SubStatusCode = 1541,
                        Message = "IdentityCountryCode is required",
                        Details = "IdentityCountryCode is required"
                    },
                    RegistrationToken = String.Empty,
                    VerificationStatus = String.Empty
                });
            }

            bool validCountry = Enum.IsDefined(typeof(CountryCode), request.UserCreationData.IdentifyingData.IdentityCountryCode);

            if (!validCountry)
            {
                return Task.FromResult(new PreSignUpResponse()
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 400,
                        SubStatusCode = 1542,
                        Message = "Invalid countryCode",
                        Details = "Invalid countryCode, please use alpha code"
                    },
                    RegistrationToken = String.Empty,
                    VerificationStatus = String.Empty
                });
            }
            var identityCountryCode = (CountryCode)Enum.Parse(typeof(CountryCode), request.UserCreationData.IdentifyingData.IdentityCountryCode);

            if ((request.UserCreationData.IdentifyingData.IdentityType == IdentityType.NationalIdCard ||
                 request.UserCreationData.IdentifyingData.IdentityType == IdentityType.Passport)
               )
            {
                if (string.IsNullOrEmpty(request.UserCreationData.IdentifyingData.IdentityExpirationDate))
                {
                    return Task.FromResult(new PreSignUpResponse()
                    {
                        ResponseHeader = new ResponseHeader()
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 400,
                            SubStatusCode = 1544,
                            Message = "IdentityExpirationDate is required",
                            Details = "IdentityExpirationDate is required"
                        },
                        RegistrationToken = String.Empty,
                        VerificationStatus = String.Empty
                    });
                }

                if (
                    (identityCountryCode == CountryCode.VEN &&
                     request.UserCreationData.IdentifyingData.HasVenezuelaRelationship == null) ||
                    (identityCountryCode == CountryCode.CUB &&
                     request.UserCreationData.IdentifyingData.HasCubaRelationship == null))
                {
                    return Task.FromResult(new PreSignUpResponse()
                    {
                        ResponseHeader = new ResponseHeader()
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 400,
                            SubStatusCode = 1545,
                            Message = "Questions required for Cuba/Venezuela gov or military",
                            Details = "Questions required for Cuba/Venezuela gov or military"
                        },
                    });
                }
            }

            var newVerificationIdentifier = Guid.NewGuid();
            var existingRequestVerificationIdentifier = _requestDataAccess.InsertRequestId(RequestType.Enroll, request.RequestHeader.RequestId, newVerificationIdentifier, newVerificationIdentifier);

            if (request.AccountCreationData == null)
            {
                throw new ArgumentNullException("Enroll: AccountCreationData");
            }

            var email = request.UserCreationData?.Email?.ToDomain();

            var addresses = request.UserCreationData?.ProfileData?.Addresses?.ToDomain();

            var phoneNumbers = request.UserCreationData?.PhoneNumbers?.ToDomain();

            if ((request.UserCreationData.IdentifyingData.IdentityType == IdentityType.NationalIdCard ||
                request.UserCreationData.IdentifyingData.IdentityType == IdentityType.Passport) && (
                    (identityCountryCode == CountryCode.VEN &&
                     request.UserCreationData.IdentifyingData.HasVenezuelaRelationship == true) ||
                    (identityCountryCode == CountryCode.CUB &&
                     request.UserCreationData.IdentifyingData.HasCubaRelationship == true)
                ))
            {
                //add neg match
                var mobilePhones = phoneNumbers?.Where(p => p.Type == PhoneType.Mobile).ToList();
                _gssFraudEventService.AddFraudIdentity(request.ProgramCode, null, null, email, mobilePhones,
                    FraudIdentityReasonGovSan);
                return Task.FromResult(new PreSignUpResponse()
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 400,
                        SubStatusCode = 1546,
                        Message = "Member Gov / Military Sanctioned Country",
                        Details = "Member Gov / Military Sanctioned Country"
                    },
                });
            }

            _enrollmentService.SaveEnrollRequest(request, newVerificationIdentifier.ToString());

            var userName = new UserName(request.UserCreationData?.ProfileData?.FirstName,
                request.UserCreationData?.ProfileData?.MiddleName, request.UserCreationData?.ProfileData?.LastName);
            _addressIntervention.SetHomeAddressToDefault(addresses);
            _addressIntervention.ValidAddresses(addresses, true);

            Dictionary<string, object> fraudData = null;
            if (request.RequestHeader.Options != null &&
                request.RequestHeader.Options.ContainsKey("identityValidationSendTo") &&
                request.RequestHeader.Options["identityValidationSendTo"] == "socure")
            {
                fraudData = new Dictionary<string, object>
                {
                    { "IdentityValidationVendor", "Socure" }
                };

                request.AccountCreationData.FraudData ??= fraudData;
            }

            var result = _enrollmentService.PreEnroll(
                    request.ProgramCode,
                    request.AccountCreationData,
                    newVerificationIdentifier.ToString(),
                    userName,
                    request.UserCreationData?.IdentifyingData?.ToDomain(isAcceptMinorEnrollment, true),
                    email,
                    addresses,
                    phoneNumbers,
                    request.ExecuteKycFlag,
                    request.AccountCreationData.Language,
                    true, /*https://pd/browse/GBOS-6925 - Scenario 1 request.OverrideAddressStandardization*/
                    fraudData,
                    request.AccountCreationData.FraudData,
                    request.RequestHeader.Source);


            ResponseHeader responseHeader = new ResponseHeader()
            {
                ResponseId = request.RequestHeader.RequestId,
                StatusCode = 0,
                SubStatusCode = 0
            };

            var preSignUpResponse = new PreSignUpResponse()
            {
                ResponseHeader = new ResponseHeader()
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0
                },
                RegistrationToken = result.VerificationRequestIdentifier.ToString(),
                VerificationStatus = result.KycGate
            };

            switch (result.KycGate.ToLower())
            {
                case "ofac":
                    {
                        preSignUpResponse.ResponseHeader.StatusCode = 400;
                        preSignUpResponse.ResponseHeader.SubStatusCode = 336;
                        preSignUpResponse.ResponseHeader.Message = "OFAC hard decline";
                        preSignUpResponse.ResponseHeader.Details = "OFAC hard decline";

                    }
                    break;
                case "idv":
                    {
                        preSignUpResponse.ResponseHeader.StatusCode = 400;
                        preSignUpResponse.ResponseHeader.SubStatusCode = 342;
                        preSignUpResponse.ResponseHeader.Message = "IDV soft decline";
                        preSignUpResponse.ResponseHeader.Details = "IDV soft decline";
                        
                        //Temp: This Lgic is temparily added to send the notification for Socure IDV Document URL until PLS stores is fully integrated with Socure IDV. 
                        //For all other partners its shall send notifications. This logic will be removed once PLS stores are fully integrated with Socure IDV.
                        if ((string.Equals(request.ProgramCode, CommonConstants.ProgramPLS, StringComparison.OrdinalIgnoreCase) && request.RequestHeader.Options != null &&
                            request.RequestHeader.Options.ContainsKey(CommonConstants.OptionIdentityValidationSendTo) &&
                            string.Equals(request.RequestHeader.Options[CommonConstants.OptionIdentityValidationSendTo], CommonConstants.Socure, StringComparison.OrdinalIgnoreCase)) || !(string.Equals(request.ProgramCode, CommonConstants.ProgramPLS, StringComparison.OrdinalIgnoreCase)))
                            SendCompleteVerificationNotification(request, preSignUpResponse.RegistrationToken);
                    }
                    break;
                case "failed":
                    {
                        preSignUpResponse.ResponseHeader.StatusCode = 400;
                        preSignUpResponse.ResponseHeader.SubStatusCode = 343;
                        preSignUpResponse.ResponseHeader.Message = "Hard decline";
                        preSignUpResponse.ResponseHeader.Details = "Hard decline";
                    }
                    break;
            }


            return Task.FromResult(preSignUpResponse);
        }

        private void SendCompleteVerificationNotification(PreSignUpRequest request, string registrationToken)
        {
            // if this is turned off, do not send the notification
            if (!Configuration.Current.SendCompleteVerificationNotification)
                return;

            var idvRequest = new SocureIDVDocumentUrlRequest
            {
                ProgramCode = request.ProgramCode,
                RequestHeader = new RequestHeader { RequestId = request.RequestHeader.RequestId },
                RegistrationToken = registrationToken,
                IsCustomerVerified = false, // already verified with the KYC gate at this point
                SDKVersion = "5.0", // default version, can be updated later to be passed from upper layers
                IsSendNotification = true // Enable notification by default in PreSignUp flow
            };

            try
            {
                var response = _idvSocureService.ProcessDocumentUrlRequest(idvRequest);
                if (response.ResponseHeader.StatusCode != 0)
                {
                    var error = $"PreSignUpHandler - Failed ProcessDocumentUrlRequest: [{response.ResponseHeader.StatusCode}] {response.ResponseHeader.SubStatusCode}: {response.ResponseHeader.Message}";

                    _logManager
                        .LogError(LoggingConstants.ErrorCode.ResponseInfo, error, nameof(SendCompleteVerificationNotification), []);

                    return;
                }

                _logManager.LogInfo(
                    LoggingConstants.ErrorCode.Success,
                    "Successfully handled IdvDocumentURL notification",
                    nameof(SendCompleteVerificationNotification),
                    []);
            }
            catch (Exception e)
            {
                _logManager.LogError(
                        LoggingConstants.ErrorCode.ResponseInfo,
                        "Failed to handle IdvDocumentURL notification",
                        nameof(SendCompleteVerificationNotification), [],
                        e);
            }
        }
    }
}
