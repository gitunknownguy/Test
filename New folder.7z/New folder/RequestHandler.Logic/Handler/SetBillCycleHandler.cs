﻿using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Queue;
using NLog;
using SetBillCycleRequest = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.SetBillCycleRequest;
using SetBillCycleResponse = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.SetBillCycleResponse;
using System;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class SetBillCycleHandler : CommandHandlerBase<SetBillCycleRequest, SetBillCycleResponse>
    {
        private readonly IAccountService _accountService;
        private readonly ILogger _logger;
        public SetBillCycleHandler(IAccountService accountService, ILogger logger)
        {
            _accountService = accountService;
            _logger = logger;
        }

        public override void SetDomainContext(SetBillCycleRequest request)
        {
            var req = request;
            if (req != null)
                DomainContext.Current.AccountIdentifier = req.AccountIdentifier;
        }

        public override Task<SetBillCycleResponse> VerifyIdentifiers(SetBillCycleRequest request)
        {
            return Task.FromResult(new SetBillCycleResponse { ResponseHeader = new ResponseHeader() });
        }

        public override Task<SetBillCycleResponse> Handle(SetBillCycleRequest request)
        {
            var req = request;
            if (req != null)
            {
                return Task.FromResult(SetBillCycle(req));
            }

            return null;
        }

        private SetBillCycleResponse SetBillCycle(SetBillCycleRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;

            _accountService.SetBillCycle(
                requestId: request.RequestHeader.RequestId,
                accountIdentifier: request.AccountIdentifier,
                programCode: request.ProgramCode,
                isFunded: request.AccountIsFunded,
                legFirstBillingCycleDate: request.FirstBillingCycleDate);

            return new SetBillCycleResponse()
            {
                ResponseHeader = new ResponseHeader()
                {
                    ResponseId = request.RequestHeader.RequestId,
                    Message = "success"
                }
            };
        }
    }
}
