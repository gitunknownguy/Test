﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Interest;
using Gd.Bos.RequestHandler.Core.Domain.Services.Dcpp;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Logic.ProcessorSelector.Contract;
using NLog;
using RequestHandler.Core.Application;
using RequestHandler.Core.Domain.Services.RetailCard;
using RequestHandler.Core.Domain.Services.RetailCard.Model;
using RequestHandler.Core.Domain.Services.CPM;

namespace Gd.Bos.RequestHandler.Logic.Handler
{

    public class GetPursesHandler : CommandHandlerBase<GetPursesRequest, GetPursesResponse>
    {
        private readonly IAccountDataAccess _accountDataAccess;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IInterestRateRepository _interestRateRepository;
        private readonly IAccountBalanceRepository _accountBalanceRepository;
        private readonly IRetailCardTransactionService _retailCardTransactionService;
        private readonly IRetailCardService _retailCardService;
        private readonly IRequestHandlerSettings _configuration;
        private static readonly Logger logger = LogManager.GetCurrentClassLogger();
        private readonly IProcessorSelectorService _processorSelectorService;
        private readonly IDcppService _dcppService;
        private readonly ICpmService _cpmService;

        private readonly ILazyCache _lazyCache;
        public GetPursesHandler(IAccountDataAccess accountDataAccess,
            IValidateIdentifier validateIdentifier,
            IInterestRateRepository interestRateRepository,
            IAccountBalanceRepository accountBalanceRepository,
            ILazyCache lazyCache, 
            IRetailCardTransactionService retailCardTransactionService,
            IRetailCardService retailCardService,
            IRequestHandlerSettings requestHandlerSettings,
            IProcessorSelectorService processorSelectorService,
            IDcppService dcppService,
            ICpmService cpmService
            )
        {
            _accountDataAccess = accountDataAccess;
            _validateIdentifier = validateIdentifier;
            _interestRateRepository = interestRateRepository;
            _accountBalanceRepository = accountBalanceRepository;
            _lazyCache = lazyCache;
            _retailCardTransactionService = retailCardTransactionService;
            _retailCardService = retailCardService;
            _configuration = requestHandlerSettings;
            _processorSelectorService = processorSelectorService;
            _dcppService = dcppService;
            _cpmService = cpmService;
        }

        public override void SetDomainContext(GetPursesRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetPursesResponse> VerifyIdentifiers(GetPursesRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetPursesResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetPursesResponse>(e, request));
            }
        }

        public override Task<GetPursesResponse> Handle(GetPursesRequest request)
        {
            Purse multranPurse = null;
            Purse collectionPurse = null;
            try
            {
                RetailCardTransferStatus transferStatus = RetailCardTransferStatus.Undefined;

                if(request.IsRealTimeBalanceRequired)
                {
                    try
                    {
                        bool isRetailNonPerson = false;
                        if (_configuration.ProgramCodesHaveRetailCard.Contains(request.ProgramCode.ToLower()))
                        {
                            //RetailCard GetBalance From GSS/NEC for RetailCardTemp/Perso
                            var retailCardPurseBalance =
                                _retailCardTransactionService.GetRetailCardPurseBalance(request, out transferStatus);

                            if (retailCardPurseBalance != null && retailCardPurseBalance.ResponseHeader.StatusCode == 0) //For Non Perso Case
                            {
                                isRetailNonPerson = true;
                                //call GSS LegacyAccountUtility $"/programs/{request.ProgramCode}/retailcard/updateBalance //GSS-45314
                                var updateBalanceResponse = _retailCardService.UpdateBalance(
                                    new GetBalanceRequest()
                                    {
                                        RequestId = request.RequestHeader.RequestId.ToString(),
                                        AccountIdentifier = request.AccountIdentifier,
                                        ProgramCode = request.ProgramCode
                                    });
                            }
                        }

                        if (!isRetailNonPerson)
                        {
                            var pursesResponse =
                                _accountDataAccess.GetPurses(request.AccountIdentifier, request.ProgramCode);
                            if (pursesResponse != null)
                            {
                                var primayPurse = pursesResponse.Purses.FirstOrDefault(p =>
                                    p.PurseType == PurseType.Primary);
                                if (primayPurse != null)
                                {
                                    DateTime cstDateTime = ConvertToCentralStandardDateTime(DateTime.Now);
                                    Dcpp.Contract.Message.GetAccountBalanceResponse balanceResponse =
                                        _cpmService.GetAccountBalance(request.ProgramCode, request.AccountIdentifier);
                                    
                                    if (balanceResponse != null && 
                                        (balanceResponse.AvailableBalance.Amount!=primayPurse.AvailableBalance || balanceResponse.CurrentBalance.Amount!=primayPurse.LedgerBalance))
                                    {
                                        _accountBalanceRepository.UpdateForAci(Guid.Parse(primayPurse.PurseIdentifier),
                                            balanceResponse.AvailableBalance.Amount, cstDateTime,
                                            balanceResponse.CurrentBalance.Amount, cstDateTime);
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        //add log, force balance update should not break the get purse function 
                        logger.Warn(ex, $"GetPursesHandler - Force update account balance failed, Message: {ex.Message}, IsRealTimeBalanceRequired: {request.IsRealTimeBalanceRequired}, ProgramCode: {request.ProgramCode}, AccountIdentifier: {request.AccountIdentifier}");
                    }
                }

                if (_configuration.ProgramCodesHaveRetailCard.Contains(request.ProgramCode.ToLower()))
                //if(Configuration.Current.ProgramCodesHaveRetailCard.Contains(request.ProgramCode.ToLower()))
                {
                    //RetailCard GetBalance From GSS/NEC for RetailCardTemp/Perso
                    var retailCardPurseBalance = _retailCardTransactionService.GetRetailCardPurseBalance(request, out transferStatus);

                    if (retailCardPurseBalance != null) //For Non Perso Case
                    {
                        return Task.FromResult(retailCardPurseBalance);
                    }
                }

                var getPursesResponse = _accountDataAccess.GetPurses(request.AccountIdentifier, request.ProgramCode);

                if (getPursesResponse == null)
                {
                    // check if account identifier was valid, but actually no purses available
                    if (_accountDataAccess.GetAccountKey(request.AccountIdentifier, request.ProgramCode).GetValueOrDefault() > 0)
                    {
                        throw new PurseNotFoundException();
                    }
                    throw new AccountNotFoundException();
                }

                var accountBalanceInterests = _interestRateRepository.GetAccountBalanceInterests(request.AccountIdentifier);
                var programInterestTierMetaData =
                    _interestRateRepository.GetProductInterestTierInfoByProgramCode(request.ProgramCode);

                foreach (var purse in getPursesResponse.Purses)
                {
                    var activeTier = _interestRateRepository.GetActiveTier(
                        accountBalanceInterests.Where(a =>
                            a.AccountBalanceIdentifier == purse.PurseIdentifier));

                    purse.InterestRateTierIdentifier = activeTier?.AccountBalanceInterestIdentifier.ToString();
                    purse.APY = activeTier?.APY;
                    purse.InterestRate = activeTier?.InterestRate;
                    purse.InterestRateTier = (activeTier != null) ? programInterestTierMetaData.Tiers.FirstOrDefault(p => p.Key == activeTier?.InterestRateTierKey)!.Name : String.Empty;
                    purse.InterestYieldStartDate = activeTier?.InterestYieldStartDate.Value.ToString("yyyy-MM-dd");
                    purse.InterestYieldEndDate = activeTier?.InterestYieldEndDate?.ToString("yyyy-MM-dd");
                    if (purse.PurseType == PurseType.Multran)
                    {
                        multranPurse = purse;
                    }
                    if (purse.PurseType == PurseType.Collection)
                    {
                        collectionPurse = purse;
                    }
                }

                if (multranPurse != null)
                {
                    var primaryPurse = getPursesResponse.Purses?.Where(x => x.PurseType == Shared.Common.Core.CoreApi.Contract.Data.Enum.PurseType.Primary).FirstOrDefault();

                    if (IsAccountBalanceAciMode())
                    {
                        GetAccountBalanceFromProcessor(primaryPurse, request.ProgramCode,
                            request.AccountIdentifier);
                    }

                    decimal sccPostedBalance = 0;
                    //SCC Posted balance can't be negative 

                    if (primaryPurse!.LedgerBalance < 0)
                    {
                        sccPostedBalance = primaryPurse.LedgerBalance * -1;
                    }
                    //Here is the calculation for SCC Balanace Object Properties
                    //"availableCredit" =  primary.availablebalance
                    //"postedBalance" =  primaryPurse.LedgerBalance * -1
                    // "totalCredit"  = multran.ledgerBalance  

                    var isFunded = IsAccountBalanceIdentifierSccFunded(AccountBalanceIdentifier.FromString(multranPurse.PurseIdentifier));
                    var acctToken = _accountDataAccess.GetAccountToken(request.AccountIdentifier);
                    if (string.IsNullOrEmpty(acctToken))
                    {
                        isFunded = false;
                    }

                    if (collectionPurse != null)
                    {
                        getPursesResponse.SccBalance = new SccBalance()
                        {
                            TotalCredit = 0,
                            AvailableCredit = primaryPurse.AvailableBalance + collectionPurse.AvailableBalance,
                            PostedBalance = Math.Abs(primaryPurse.AvailableBalance + collectionPurse.AvailableBalance),
                            fundingStatus = isFunded ? SccFundingStatus.Funded : SccFundingStatus.NotFunded
                        };
                    }
                    else
                    {
                        getPursesResponse.SccBalance = new SccBalance()
                        {
                            TotalCredit = multranPurse.LedgerBalance,
                            AvailableCredit = primaryPurse.AvailableBalance,
                            PostedBalance = sccPostedBalance,
                            fundingStatus = isFunded ? SccFundingStatus.Funded : SccFundingStatus.NotFunded
                        };
                    }
                }

                getPursesResponse.ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                };
                if (transferStatus != RetailCardTransferStatus.Undefined) getPursesResponse.PurseBalanceTransferStatus = transferStatus;
                return Task.FromResult(getPursesResponse);

            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetPursesResponse>(e, request));
            }
        }

        public bool IsAccountBalanceIdentifierSccFunded(AccountBalanceIdentifier accountBalanceIdentifier)
        {
            Func<string, bool> getAB = (key) =>
            {
                var isFunded = _lazyCache.Value.Get<bool>(key);
                if (isFunded == false)
                {
                    var aBal = _accountBalanceRepository.GetAccountBalanceByAccountBalanceIdentifier(accountBalanceIdentifier);

                    if ((aBal.AvailableBalance != 0 || aBal.CreateDate < aBal.ChangeDate))
                    {
                        isFunded = true;
                        _lazyCache.Value.Set(key, true, new TimeSpan(10, 0, 0, 0));
                    }
                }
                return isFunded;
            };

            var balance = getAB($"SccFunded-" + accountBalanceIdentifier);
            return balance;
        }

        private bool IsAccountBalanceAciMode()
        {
            return _configuration.GetBalanceMode == "ACI";
        }

        private void GetAccountBalanceFromProcessor(Purse purse, string programCode, string accountIdentifier)
        {
            var response = _dcppService.GetAccountBalance(programCode, accountIdentifier);
            purse.LedgerBalance = response.CurrentBalance.Amount;
        }

        private DateTime ConvertToCentralStandardDateTime(DateTime dt)
        {
            var cstTimeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time");
            return TimeZoneInfo.ConvertTime(dt, cstTimeZoneInfo);
        }
    }
}
