﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers.Exceptions;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Exceptions;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using TransferType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class AssessUpdateTransferHandler : CommandHandlerBase<AssessUpdateTransferRequest, AssessUpdateTransferResponse>
    {
        public AssessUpdateTransferHandler(ITransferService transferService, IValidateIdentifier validateIdentifier, ILimitTypeService limitTypeService, ITransferRepository transferRepository)
        {
            _transferService = transferService;
            _validateIdentifier = validateIdentifier;
            _limitTypeService = limitTypeService;
            _transferRepository = transferRepository;
        }

        public override void SetDomainContext(AssessUpdateTransferRequest request)
        {
            if (!string.IsNullOrEmpty(request.TransferEndPoint.Identifier))
                DomainContext.Current.AccountIdentifier = request.TransferEndPoint.Identifier;
        }

        public override Task<AssessUpdateTransferResponse> VerifyIdentifiers(AssessUpdateTransferRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new AssessUpdateTransferResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AssessUpdateTransferResponse>(e, request));
            }
        }

        public override Task<AssessUpdateTransferResponse> Handle(AssessUpdateTransferRequest request)
        {
            Tuple<TransferStatus, List<Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Account>> response = null;
            List<Limits> filteredlimits = null;
            try
            {
                if (request.RequestHeader.RequestId == Guid.Empty)
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId,
                        $"{nameof(request)}.RequestHeader.RequestId must be specified");
                }

                if (string.IsNullOrEmpty(request.TransferIdentifier) || request.TransferIdentifier == Guid.Empty.ToString())
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier,
                        $"{nameof(request)}.TransferIdentifier must be specified");
                }


                var transfer = _transferRepository.GetByTransferIdentifier(TransferIdentifier.FromString(request.TransferIdentifier), false, request.ProgramCode);
                if (transfer == null)
                    throw new TransferValidationException(10, 0, "Transfer Not Found");

                var accountIdForLimits = request.TransferEndPoint.Identifier;
                try
                {
                    TransferType transferType = (TransferType)transfer.TransferType;
                    filteredlimits = _limitTypeService.GetApplicableLimits(accountIdForLimits, request.ProgramCode, transferType, request.TransferEndPoint.IsSource);
                }
                catch (Exception e) { }

                var transferStatus = _transferService.UpdateTransfer(request.ProgramCode,
                    transfer,
                    request.TransferEndPoint.Identifier,
                    request.TransferEndPoint.CardData?.FirstName,
                    request.TransferEndPoint.CardData?.LastName,
                    request.TransferEndPoint.CardData?.CardNumber,
                    request.TransferEndPoint.CardData?.Expiration,
                    request.TransferEndPoint.CardData?.Cvv,
                    request.TransferEndPoint.CardData?.AddressLine1,
                    request.TransferEndPoint.CardData?.AddressLine2,
                    request.TransferEndPoint.CardData?.City,
                    request.TransferEndPoint.CardData?.State,
                    request.TransferEndPoint.CardData?.ZipCode,
                    request.AuthorizationType,
                    request.TransferEndPoint.IsSource,
                    request.TransferEndPoint.TransferEndPointType,
                    null,
                    true);

                return Task.FromResult(new AssessUpdateTransferResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = transferStatus == TransferStatus.Completed ? "Success" : transferStatus.ToString()
                    },
                    Limits = filteredlimits,
                });
            }
            catch (TransferAccountStateException ex)
            {
                var rs = ex.HandleException<AssessUpdateTransferResponse>(ex, request);
                rs.Limits = filteredlimits;
                return Task.FromResult(rs);
            }
            catch (RequestHandlerException e)
            {
                var rs = e.HandleException<AssessUpdateTransferResponse>(e, request);
                rs.Limits = filteredlimits;
                return Task.FromResult(rs);
            }
            catch (Exception e)
            {
                var rs = e.HandleException<AssessUpdateTransferResponse>(e, request);
                rs.Limits = filteredlimits;
                return Task.FromResult(rs);
            }

        }

        private readonly ITransferService _transferService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ILimitTypeService _limitTypeService;
        private readonly ITransferRepository _transferRepository;
    }
}
