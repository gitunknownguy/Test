﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers.Exceptions;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Locking.ApiLock.Contract;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class UpdateTransferHandler : CommandHandlerBase<UpdateTransferRequest, UpdateTransferResponse>
    {
        private readonly ITransferService _transferService;
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ITransferRepository _transferRepository;
        private readonly ILockService _lockService;
        private readonly IAccountRepository _accountRepository;
        public UpdateTransferHandler(ITransferService transferService,
            IValidateIdentifier validateIdentifier,
            ITransferRepository transferRepository,
            IAccountRepository accountRepository,
            ILockService lockService)
        {
            _transferService = transferService;
            _validateIdentifier = validateIdentifier;
            _transferRepository = transferRepository;
            _lockService = lockService;
            _accountRepository = accountRepository;
        }

        public override void SetDomainContext(UpdateTransferRequest request)
        {
            if (!string.IsNullOrEmpty(request.TransferEndPoint?.Identifier))
                DomainContext.Current.AccountIdentifier = request.TransferEndPoint.Identifier;
            DomainContext.Current.TransferIdentifier = request.TransferIdentifier;
        }

        public override Task<UpdateTransferResponse> VerifyIdentifiers(UpdateTransferRequest request)
        {
            try
            {
                _validateIdentifier.ValidatePartner_AccountIdProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new UpdateTransferResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpdateTransferResponse>(e, request));
            }
        }

        /// <summary>
        /// Obtains api lock on transfer identifier
        /// </summary>
        public override async Task<UpdateTransferResponse> ObtainLock(UpdateTransferRequest request)
        {
            try
            {
                await _lockService.ObtainApiLock(DomainContext.Current.TransferIdentifier);
                return new UpdateTransferResponse() { ResponseHeader = new ResponseHeader() };
            }
            catch (Exception e)
            {
                return e.HandleException<UpdateTransferResponse>(e, request);
            }
        }

        public override async Task<UpdateTransferResponse> Handle(UpdateTransferRequest request)
        {
            string handle = null;
            try
            {
                TransferRequestValidation.HandleUpdateTransferValidation(request);

                var transfer =
                    _transferRepository.GetByTransferIdentifier(
                        TransferIdentifier.FromString(request.TransferIdentifier), request.AllowNegativeBalance, request.ProgramCode);

                if (transfer == null)
                    throw new TransferValidationException(10, 0, "Transfer Not Found");

                // check if the account has the option to reverse the transaction
                if (request.AuthorizationType == Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.AuthorizationType.Reverse &&
                    (transfer.TransferType == TransferType.DisbursementIn || transfer.TransferType == TransferType.DisbursementOut))
                {
                    var accountIdentifier = transfer.InitiatorAccountIdentifier;

                    if (transfer.TransferType == TransferType.DisbursementIn)
                        accountIdentifier = transfer.Target.TransferEndpoint.AccountIdentifier;
                    else if (transfer.TransferType == TransferType.DisbursementOut)
                        accountIdentifier = transfer.Source.TransferEndpoint.AccountIdentifier;

                    // check if the account is active
                    var accountStatus = _accountRepository.GetStatus(accountIdentifier);

                    // Scenario 1:  Closed or Locked/Incurable

                    if (accountStatus.accountStatus == AccountStatus.Closed)
                    {
                        return new UpdateTransferResponse
                        {
                            ResponseHeader = new ResponseHeader
                            {
                                ResponseId = request.RequestHeader.RequestId,
                                StatusCode = 3,
                                SubStatusCode = 105,
                                Message = "Account is " + accountStatus.accountStatus
                            }
                        };
                    }
                    else if (accountStatus.accountStatus == AccountStatus.Locked && accountStatus.accountHolderCure == AccountHolderCure.None)
                    {
                        // accountHolder tble accountHolderCure 
                        return new UpdateTransferResponse
                        {
                            ResponseHeader = new ResponseHeader
                            {
                                ResponseId = request.RequestHeader.RequestId,
                                StatusCode = 3,
                                SubStatusCode = 106,
                                Message = "Account is " + accountStatus.accountStatus
                            }
                        };
                    }

                    if (transfer.TransferType == TransferType.DisbursementOut &&
                        accountStatus.accountStatus == AccountStatus.Restricted &&
                        accountStatus.accountStatusReasons.Contains(AccountStatusReason.spendDown))
                    {
                        return new UpdateTransferResponse
                        {
                            ResponseHeader = new ResponseHeader
                            {
                                ResponseId = request.RequestHeader.RequestId,
                                StatusCode = 3,
                                SubStatusCode = 106,
                                Message = "Account is " + accountStatus.accountStatus
                            }
                        };
                    }

                    // Scenario 4:  Disallow DisbursementIn if account status Restricted or Locked or Pending or Closed 
                    if (transfer.TransferType == TransferType.DisbursementIn)
                    {
                        if (accountStatus.accountStatus == AccountStatus.Pending)
                        {
                            return new UpdateTransferResponse
                            {
                                ResponseHeader = new ResponseHeader
                                {
                                    ResponseId = request.RequestHeader.RequestId,
                                    StatusCode = 3,
                                    SubStatusCode = 100,
                                    Message = "Account is " + accountStatus.accountStatus
                                }
                            };
                        }

                        if (accountStatus.accountStatus == AccountStatus.Locked || accountStatus.accountStatus == AccountStatus.Closed)
                        {
                            return new UpdateTransferResponse
                            {
                                ResponseHeader = new ResponseHeader
                                {
                                    ResponseId = request.RequestHeader.RequestId,
                                    StatusCode = 3,
                                    SubStatusCode = 106,
                                    Message = "Account is " + accountStatus.accountStatus
                                }
                            };
                        }
                    }
                }

                if (transfer.Target is AccountTransferLeg targetAccountLeg)
                {
                    //if (request.TransferEndPoint?.TransferEndPointType != EndpointType.Account)
                    //    throw new TransferValidationException(3, 128, "Only a non-account holder can accept a pending P2P to an external target.");
                    if (!(request.TransferEndPoint?.IsSource ?? false)
                        && !string.IsNullOrEmpty(request.TransferEndPoint?.Identifier)
                        && targetAccountLeg?.AccountTransferEndpoint != null
                        && targetAccountLeg.AccountTransferEndpoint?.AccountIdentifier.ToString().ToLower() !=
                        request.TransferEndPoint.Identifier.ToLower())
                        throw new TransferValidationException(3, 119,
                            $"Only the requestee can {request.AuthorizationType.ToString()?.ToLower()} a P2P");

                }
                else if (!(transfer.Target is HandleTransferLeg)) // target not handle
                {
                    if (!request.TransferEndPoint?.IsSource ?? false) // is target
                        throw new TransferValidationException(3, 128,
                            "Only a non-account holder can accept a pending P2P to an external target.");
                }
                else
                {
                    var handleEndpoint = (HandleTransferEndpoint)transfer.Target.TransferEndpoint;
                    handle = handleEndpoint.Handle;
                    //Api lock on phone number as IFT guest out
                    await _lockService.ObtainApiLock(handle);
                }

                var transferStatus = _transferService.UpdateTransfer(
                    request.ProgramCode,
                    transfer,
                    request.TransferEndPoint?.Identifier,
                    request.TransferEndPoint?.CardData?.FirstName,
                    request.TransferEndPoint?.CardData?.LastName,
                    request.TransferEndPoint?.CardData?.CardNumber,
                    request.TransferEndPoint?.CardData?.Expiration,
                    request.TransferEndPoint?.CardData?.Cvv,
                    request.TransferEndPoint?.CardData?.AddressLine1,
                    request.TransferEndPoint?.CardData?.AddressLine2,
                    request.TransferEndPoint?.CardData?.City,
                    request.TransferEndPoint?.CardData?.State,
                    request.TransferEndPoint?.CardData?.ZipCode,
                    request.AuthorizationType,
                    request.TransferEndPoint?.IsSource ?? false,
                    request.TransferEndPoint?.TransferEndPointType,
                    request.Device);

                // Api release lock on phone number as IFT guest out
                if (!string.IsNullOrEmpty(handle))
                    _lockService.ReleaseApiLock(handle);
                return new UpdateTransferResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                    Transfer = new UpdatedTranfer { TransferStatus = transferStatus.ToString().ToLower() }
                };
            }
            catch (TransferException e)
            {
                var response = e.HandleException<UpdateTransferResponse>(e, request);

                if (e.IsPending)
                    response.Transfer = new UpdatedTranfer { TransferStatus = TransferStatus.Pending.ToString() };
                else
                    response.Transfer = new UpdatedTranfer { TransferStatus = TransferStatus.Failed.ToString() };

                return response;
            }
            catch (Exception e)
            {
                return e.HandleException<UpdateTransferResponse>(e, request);
            }
            finally
            {
                if (!string.IsNullOrEmpty(handle))
                    _lockService.ReleaseApiLock(handle);
            }
        }

        /// <summary>
        /// Release lock on transfer Identifier
        /// </summary>
        public override void ReleaseLock(UpdateTransferRequest request)
        {
            _lockService.ReleaseApiLock(DomainContext.Current.TransferIdentifier);
        }
    }
}
