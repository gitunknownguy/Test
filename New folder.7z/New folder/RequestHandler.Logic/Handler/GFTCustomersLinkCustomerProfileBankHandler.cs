﻿using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System;
using System.Threading.Tasks;
using NLog;
using RequestHandler.Core.Domain.Services.GlobalFundTransfer;
using RequestHandler.Core.Domain.Services.GlobalFundTransfer.Contracts;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.GFTCustomers;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.GFTCustomers;
using System.Linq;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.Common;

namespace RequestHandler.Logic.Handler
{
    public class GFTCustomersLinkCustomerProfileBankHandler : CommandHandlerBase<GFTCustomersLinkCustomerProfileBankRequest, GFTCustomersLinkCustomerProfileResponse>
    {
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        private readonly IGlobalFundTransferService _globalFundTransferService;
        private readonly IBaasConfiguration _baasConfiguration;

        public GFTCustomersLinkCustomerProfileBankHandler(IGlobalFundTransferService globalFundTransferService, IBaasConfiguration baasConfiguration)
        {
            _globalFundTransferService = globalFundTransferService;
            _baasConfiguration = baasConfiguration;
        }

        public override void SetDomainContext(GFTCustomersLinkCustomerProfileBankRequest request)
        {
        }

        public override Task<GFTCustomersLinkCustomerProfileResponse> VerifyIdentifiers(GFTCustomersLinkCustomerProfileBankRequest request)
        {
            try
            {
                return Task.FromResult(new GFTCustomersLinkCustomerProfileResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GFTCustomersLinkCustomerProfileResponse>(e, request));
            }
        }

        public override Task<GFTCustomersLinkCustomerProfileResponse> Handle(GFTCustomersLinkCustomerProfileBankRequest request)
        {
            try
            {
                if (!GFTCustomerTokenMapping.IsValidCustomerType(request.CustomerType))
                {
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier, $"{nameof(request)}.Customer type is invalid");
                }

                var linkCustomerProfileRequest = new LinkCustomerProfileBankRequest
                {
                    ProgramCode = request.ProgramCode,
                    RequestId = request.RequestHeader.RequestId.ToString(),
                    CustomerToken = request.CustomerToken,
                    FirstName = request.FirstName,
                    LastName = request.LastName,
                    NickName = request.NickName,
                    AbaRoutingNumber = request.AbaRoutingNumber,
                    BankAccountNumber = request.BankAccountNumber,
                    BankAccountType = request.BankAccountType
                };

                var linkCustomerProfileResponse = _globalFundTransferService.LinkCustomerProfileBank(linkCustomerProfileRequest);

                if (linkCustomerProfileResponse == null || linkCustomerProfileResponse.ResponseDetails == null)
                    throw new RequestHandlerException(0, 404, "LinkCustomerProfileResponse is null");

                var response = new GFTCustomersLinkCustomerProfileResponse
                {
                    Link = new GFTCustomersLinkCustomerProfileResponse._.Link
                    {
                        LinkId = linkCustomerProfileResponse.Link?.LinkId,
                    },
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    }
                };

                if (linkCustomerProfileResponse.ResponseDetails.Any())
                {
                    var firstDetail = linkCustomerProfileResponse.ResponseDetails.First();

                    if (string.Compare(firstDetail.Description, "success", StringComparison.OrdinalIgnoreCase) != 0)
                    {
                        response.ResponseHeader.Message = firstDetail.Description;
                        response.ResponseHeader.Details = firstDetail.Description;
                        response.ResponseHeader.StatusCode = firstDetail.Code;
                        response.ResponseHeader.SubStatusCode = firstDetail.SubCode;
                    }
                }
                else
                {
                    response.ResponseHeader.Message = "Unknown Error";
                    response.ResponseHeader.Details = "Unknown Error";
                    response.ResponseHeader.StatusCode = 4214;
                    response.ResponseHeader.SubStatusCode = 1514;
                }

                return Task.FromResult(response);
            }

            catch (InvalidProductMaterialException e)
            {
                var response = new GFTCustomersLinkCustomerProfileResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 4,
                        SubStatusCode = 312,
                        Message = e.Message
                    },
                };
                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                var eResult = e.HandleException<GFTCustomersLinkCustomerProfileResponse>(e, request);

                Logger.Info($"post LinkCustomerProfile failure, prospectId:{DomainContext.Current.ProspectIdentifier},prospectType:{DomainContext.Current.ProspectType},statusCode:{eResult.ResponseHeader.StatusCode},subStatusCode:{eResult.ResponseHeader.SubStatusCode},statusMessage:{eResult.ResponseHeader.Message},statusDetails:{eResult.ResponseHeader.Details}");
                return Task.FromResult(eResult);
            }
        }
    }
}
