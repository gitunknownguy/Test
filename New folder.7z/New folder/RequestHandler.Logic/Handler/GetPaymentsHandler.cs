﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CareCoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CareCoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using RequestHandler.Core.Application;
using Gd.Bos.Shared.Common.Configuration.ConfigManager;

namespace RequestHandler.Logic.Handler
{
    public class GetPaymentsHandler : CommandHandlerBase<GetSccPaymentRequest, GetSccPaymentResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly ISCCTransactionService _sccTransactionService;
        private readonly IAccountService _accountService;
        private readonly IBaasConfigManager _baasConfigManager;
        private string[] _sccProductCodes;

        public GetPaymentsHandler(IValidateIdentifier validateIdentifier, ISCCTransactionService sccTransactionService, IAccountService accountService, IBaasConfigManager baasConfigManager)
        {
            _validateIdentifier = validateIdentifier;
            _sccTransactionService = sccTransactionService;
            _accountService = accountService;
            _baasConfigManager = baasConfigManager;
            _sccProductCodes = Configuration.Current.SccProductCodes.Split(',');
        }

        public override Task<GetSccPaymentResponse> Handle(GetSccPaymentRequest request)
        {
            try
            {
                if (request.RequestHeader.RequestId == Guid.Empty)
                    throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId, $"{nameof(request)}.RequestHeader.RequestId must be specified");

                if (string.IsNullOrEmpty(request.AccountIdentifier) || request.AccountIdentifier == Guid.Empty.ToString())
                    throw new RequestHandlerException(350, 0, $"The format of accountIdentifier is invalid.");

                var account = _accountService.GetAccountByAccountIdentifier(request.AccountIdentifier);

                var sccData = _baasConfigManager.GetSccConfigData(Configuration.Current.SccConfigKeySpaceName, request.ProgramCode);

                if (account == null || sccData == null || sccData.Products == null || !sccData.Products.Exists(p => p.ProductCode.Contains(account.Product?.ProductCode?.ToString())))
                //if (account==null || !_sccProductCodes.Contains(account.Product?.ProductCode?.ToString()))
                {
                    throw new RequestHandlerException(400, (int)207, $"SCC Account not found");
                }

                var getSccPaymentResponse =
                    _sccTransactionService.GetSccStatementSummary(Guid.Parse(request.AccountIdentifier));

                getSccPaymentResponse.ResponseHeader = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                };
                return Task.FromResult(getSccPaymentResponse);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetSccPaymentResponse>(e, request));
            }
        }

        public override void SetDomainContext(GetSccPaymentRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetSccPaymentResponse> VerifyIdentifiers(GetSccPaymentRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new GetSccPaymentResponse() { ResponseHeader = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<GetSccPaymentResponse>(e, request));
            }
        }
    }
}
