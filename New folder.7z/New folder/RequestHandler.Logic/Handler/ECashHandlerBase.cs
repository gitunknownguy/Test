﻿using System;
using System.Diagnostics.CodeAnalysis;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Services.ECash;
using Gd.Bos.RequestHandler.Logic.Queue;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public abstract class ECashHandlerBase<TRequest, TResponse> : CommandHandlerBase<TRequest, TResponse>
        where TRequest : BaseRequest where TResponse : BaseResponse
    {
        protected readonly IECashService ECashService;

        protected ECashHandlerBase(IECashService eCashService)
        {
            ECashService = eCashService;
        }

        protected ResponseHeader MapResponse(ResponseDetail detail, Guid requestId)
        {
            if (detail == null)
            {
                return new ResponseHeader
                {
                    StatusCode = ECashStatusCode.OperationFailed, // 950,
                    SubStatusCode = ECashSubStatusCode.SystemError, // 601,
                    Message = "System Error",
                    ResponseId = requestId
                };
            }

            return new ResponseHeader
            {
                StatusCode = detail.Code, // int.TryParse(detail.Code, out var code) ? code : 99,
                SubStatusCode = detail.SubCode, //int.TryParse(detail.SubCode, out var subStatusCode) ? subStatusCode : 99,
                Message = detail.Description,
                ResponseId = requestId
            };

        }
    }
}
