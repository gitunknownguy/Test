﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.Ach;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using RequestHandler.Core.Domain.Services.Ach;
using DeviceType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.DeviceType;
using ResponseDetails = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseDetails;

namespace RequestHandler.Logic.Handler
{
    public class CreateExternalAccountLinkTokenHandler : CommandHandlerBase<CreateLinkTokenExternalAccountRequest, CreateLinkTokenExternalAccountResponse>
    {
        private readonly IAchService _achService;
        private readonly IValidateIdentifier _validateIdentifier;
        public CreateExternalAccountLinkTokenHandler(IAchService achService, IValidateIdentifier validateIdentifier)
        {
            _achService = achService;
            _validateIdentifier = validateIdentifier;
        }
        public override Task<CreateLinkTokenExternalAccountResponse> Handle(CreateLinkTokenExternalAccountRequest request)
        {
            try
            {
                CreateACHLinkTokenResponse gssResponse;
                if (request.ExternalAccountProvider == ExternalAccountProviderType.Finicity)
                {
                    GenerateConnectUrlRequest generateConnectUrlRequest = new 
                        GenerateConnectUrlRequest()
                    {
                        Options = request.Options,
                        RequestId = request.RequestId,
                        DeviceType = request.DeviceType,
                        CustomerId = request.CustomerId
                    }; 
                    gssResponse = _achService.GenerateConnectUrl(request.ProgramCode, request.AccountId, generateConnectUrlRequest);
                }
                else
                {
                    CreateACHLinkTokenRequest createACHLinkTokenRequest = new CreateACHLinkTokenRequest()
                    {
                        Options = request.Options,
                        RequestId = request.RequestId,
                        DeviceType = request.DeviceType
                    };
                    gssResponse = _achService.CreateExternalBankAccountLinkToken(request.ProgramCode, request.AccountId, createACHLinkTokenRequest);
                }

                CreateLinkTokenExternalAccountResponse response = new CreateLinkTokenExternalAccountResponse()
                {
                    ErrorCode = gssResponse.ErrorCode,
                    ErrorMessage = gssResponse.ErrorMessage,
                    ErrorType = gssResponse.ErrorType,
                    LinkToken = gssResponse.LinkToken,
                    ResponseCode = gssResponse.ResponseCode,
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    },
                };

                if (gssResponse.ResponseDetails != null)
                {
                    foreach (var rs in gssResponse.ResponseDetails)
                    {
                        response.ResponseDetails.Add(new ResponseDetails()
                        {
                            Code = rs.Code,
                            Description = rs.Description,
                            URL = rs.URL,
                            SubCode = rs.SubCode
                        });
                    }
                }

                return Task.FromResult(response);
            }
            catch (Exception ex)
            {
                return Task.FromResult(ex.HandleException<CreateLinkTokenExternalAccountResponse>(ex, request));
            }
        }

        public override void SetDomainContext(CreateLinkTokenExternalAccountRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountId;
        }

        public override Task<CreateLinkTokenExternalAccountResponse> VerifyIdentifiers(CreateLinkTokenExternalAccountRequest request)
        {
            _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
            return Task.FromResult(new CreateLinkTokenExternalAccountResponse() { ResponseHeader = new ResponseHeader() });
        }
    }
}
