﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using NLog.LayoutRenderers.Wrappers;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class GetLinkedAccountHandler : CommandHandlerBase<GetLinkedAccountRequest, GetLinkedAccountResponse>
    {
        private IValidateIdentifier _validateIdentifier;
        private IAccountService _accountService;

        public GetLinkedAccountHandler(IValidateIdentifier validateIdentifier, IAccountService accountService)
        {
            _validateIdentifier = validateIdentifier;
            _accountService = accountService;

        }

        public override void SetDomainContext(GetLinkedAccountRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<GetLinkedAccountResponse> VerifyIdentifiers(GetLinkedAccountRequest request)
        {
            _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
            //_validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 5, 105);
            return Task.FromResult(new GetLinkedAccountResponse { ResponseHeader = new ResponseHeader() });
        }

        public override Task<GetLinkedAccountResponse> Handle(GetLinkedAccountRequest request)
        {
            bool isActive = true;
            if (request.IsActive.HasValue)
                isActive = request.IsActive.Value;

            var accountLinkList = _accountService.GetLinkedAccount(request.AccountIdentifier, isActive);
            var accs = new List<AccountLink>();

            foreach (var link in accountLinkList)
            {
                var acc = new AccountLink()
                {
                    AccountLinkType = link.AccountLinkType,
                    PrimaryAccountIdentifier = link.PrimaryAccountIdentifier,
                    LinkAccountIdentifier = link.LinkAccountIdentifier,
                    StartDate = link.StartDate,
                    EndDate = link.EndDate
                };
                accs.Add(acc);
            }

            var result = new GetLinkedAccountResponse
            {
                AccountLinks = accs,
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                }
            };

            if (accs.Count == 0)
            {
                result.ResponseHeader.StatusCode = 11;
                result.ResponseHeader.SubStatusCode = 1154;
                result.ResponseHeader.Message = "No Data Found";
            }

            return Task.FromResult(result);
        }
    }
}
