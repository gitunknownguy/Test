﻿using System;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class ClosePurseHandler : CommandHandlerBase<ClosePurseRequest, ClosePurseResponse>
    {
        private readonly IAccountService _accountService;
        private readonly IValidateIdentifier _validateIdentifier;

        public ClosePurseHandler(IAccountService accountService, IValidateIdentifier validateIdentifier)
        {
            _accountService = accountService;
            _validateIdentifier = validateIdentifier;
        }
        public override void SetDomainContext(ClosePurseRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<ClosePurseResponse> VerifyIdentifiers(ClosePurseRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 4, 105);
                return Task.FromResult(new ClosePurseResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<ClosePurseResponse>(e, request));
            }
        }

        public override Task<ClosePurseResponse> Handle(ClosePurseRequest request)
        {
            try
            {
                var response = new ClosePurseResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    }
                };
                _accountService.ClosePurse(request.AccountIdentifier, request.PurseIdentifier);
                return Task.FromResult(response);
            }
            catch (DcppException e)
            {
                return Task.FromResult(e.HandleException<ClosePurseResponse>(e, request));
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<ClosePurseResponse>(e, request));
            }
        }
    }
}
