﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.PointsSystem;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class CalculatePointsHandler : CommandHandlerBase<CalculatePointsRequest, CalculatePointsResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IPointsSystemService _pointsSystemService;

        public CalculatePointsHandler(IPointsSystemService pointsSystemService, IValidateIdentifier validateIdentifier)
        {
            _pointsSystemService = pointsSystemService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(CalculatePointsRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<CalculatePointsResponse> VerifyIdentifiers(CalculatePointsRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new CalculatePointsResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CalculatePointsResponse>(e, request));
            }
        }

        public override Task<CalculatePointsResponse> Handle(CalculatePointsRequest request)
        {
            try
            {
                var response = _pointsSystemService.CalculateTotalPoints(request);

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<CalculatePointsResponse>(e, request));
            }
        }
    }
}
