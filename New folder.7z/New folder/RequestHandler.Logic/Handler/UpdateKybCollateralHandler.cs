﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CareCoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    /// <summary>
    /// Handles updating KYB (Know-Your-Business).
    /// <para><seealso href="https://pd/browse/GBOS-16411"/></para>
    /// </summary>
    public class UpdateKybCollateralHandler : CommandHandlerBase<UpdateKybCollateralRequest, UpdateKybCollateralResponse>
    {
        private readonly IRiskService _riskService;
        private readonly IValidateIdentifier _validateIdentifier;


        //
        // Constructors

        /// <summary>
        /// Initializes a new instance of <see cref="UpdateKybCollateralHandler"/> using the supplied <paramref name="riskService"/> and <paramref name="validateIdentifier"/>.
        /// </summary>
        /// <param name="validateIdentifier">An instance of <see cref="IValidateIdentifier"/>.</param>
        public UpdateKybCollateralHandler(IRiskService riskService, IValidateIdentifier validateIdentifier)
        {
            this._riskService = riskService;
            this._validateIdentifier = validateIdentifier;
        }


        //
        // CommandHandlerBase Implementation

        public override void SetDomainContext(UpdateKybCollateralRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<UpdateKybCollateralResponse> VerifyIdentifiers(UpdateKybCollateralRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidateConsumerProfileIdentifier(DomainContext.Current.AccountIdentifier, DomainContext.Current.UserIdentifier);
                return Task.FromResult(new UpdateKybCollateralResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpdateKybCollateralResponse>(e, request));
            }
        }

        public override Task<UpdateKybCollateralResponse> Handle(UpdateKybCollateralRequest request)
        {
            UpdateKybCollateralResponse response = null;

            try
            {
                response = _riskService.UpdateKybCollateral(request);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<UpdateKybCollateralResponse>(e, request));
            }

            return Task.FromResult(response);
        }
    }
}