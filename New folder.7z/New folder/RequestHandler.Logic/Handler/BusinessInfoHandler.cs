﻿using Amazon.SecretsManager.Model;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;

namespace RequestHandler.Logic.Handler
{
    public class BusinessInfoHandler : CommandHandlerBase<BusinessInfoRequest, BusinessInfoResponse>
    {
        private readonly IBusinessInfoService _businessInfoService;
        private readonly IValidateIdentifier _validateIdentifier;

        public BusinessInfoHandler(IBusinessInfoService businessInfoService
        , IValidateIdentifier validateIdentifier)
        {
            _businessInfoService = businessInfoService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(BusinessInfoRequest request)
        {
            if (!string.IsNullOrEmpty(request.AccountIdentifier))
            {
                DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
            }
        }

        public override Task<BusinessInfoResponse> VerifyIdentifiers(BusinessInfoRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                _validateIdentifier.ValidatePartner_AccountIdProgramCode(DomainContext.Current.AccountIdentifier, DomainContext.Current.ProgramCode);
                return Task.FromResult(new BusinessInfoResponse()
                {
                    ResponseHeader = new ResponseHeader()
                });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<BusinessInfoResponse>(e, request));
            }
        }

        public override Task<BusinessInfoResponse> Handle(BusinessInfoRequest request)
        {
            var response = new BusinessInfoResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success"
                }
            };

            try
            {
                if (request == null || request.BusinessInfo == null)
                    throw new InvalidRequestException("Invalid Request.");

                if (string.IsNullOrEmpty(request.AccountIdentifier))
                    throw new AccountNotFoundException();

                if (string.IsNullOrEmpty(request.ProgramCode))
                    throw new ArgumentNullException($"ProgramCode: Program Code cannot be null or empty.");

                var businessInfo = new BusinessInfoRequest
                {
                    AccountIdentifier = request.AccountIdentifier,
                    ProgramCode = request.ProgramCode,
                    RequestHeader = request.RequestHeader,
                    BusinessInfo = new BusinessInfoData
                    {
                        BusinessName = request.BusinessInfo.BusinessName,
                        BusinessIndustryCode = request.BusinessInfo.BusinessIndustryCode,
                        StartDate = request.BusinessInfo.StartDate,
                        IncorporatedState = request.BusinessInfo.IncorporatedState,
                        TaxId = request.BusinessInfo.TaxId,
                        CompanyProfileTypeCode = request.BusinessInfo.CompanyProfileTypeCode,
                        CompanyProfileRoleCode = request.BusinessInfo.CompanyProfileRoleCode
                    }
                };

                response = _businessInfoService.SaveBusinessInfo(businessInfo);

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<BusinessInfoResponse>(e, request));
            }
        }
    }
}