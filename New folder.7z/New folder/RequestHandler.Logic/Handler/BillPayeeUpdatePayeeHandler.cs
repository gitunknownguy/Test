﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.BillPay;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;

namespace Gd.Bos.RequestHandler.Logic.Handler
{
    public class BillPayeeUpdatePayeeHandler : CommandHandlerBase<BillPayUpdatePayeeRequest, BillPayUpdatePayeeResponse>
    {
        private readonly IBillPayService _billPayService;
        private readonly IValidateIdentifier _validateIdentifier;

        public BillPayeeUpdatePayeeHandler(IBillPayService billPayService, IValidateIdentifier validateIdentifier)
        {
            _billPayService = billPayService;
            _validateIdentifier = validateIdentifier;
        }

        public override void SetDomainContext(BillPayUpdatePayeeRequest request)
        {
            DomainContext.Current.AccountIdentifier = request.AccountIdentifier;
        }

        public override Task<BillPayUpdatePayeeResponse> VerifyIdentifiers(BillPayUpdatePayeeRequest request)
        {
            _validateIdentifier.ValidateAccountClosed(DomainContext.Current.AccountIdentifier, 3, 105);
            return Task.FromResult(new BillPayUpdatePayeeResponse() { ResponseHeader = new ResponseHeader() });
        }

        public override Task<BillPayUpdatePayeeResponse> Handle(BillPayUpdatePayeeRequest request)
        {
            try
            {
                var response = _billPayService.UpdateBillPayee(GetUpdateBillPayeeRequest(request), request.ProgramCode, request.AccountIdentifier, request.PayeeIdentifier);
                var result = default(BillPayUpdatePayeeResponse);
                if (response?.ErrorCode == "0")
                {
                    result = new BillPayUpdatePayeeResponse()
                    {

                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 0,
                            SubStatusCode = 0,
                            Message = "success"
                        }
                    };
                }
                else
                {
                    result = new BillPayUpdatePayeeResponse()
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            SubStatusCode = 0,
                            Message = response.ErrorMessage
                        },
                    };
                    if (!string.IsNullOrEmpty(response.ErrorCode) && int.TryParse(response.ErrorCode, out var tempErrorCode))
                    {
                        result.ResponseHeader.StatusCode = tempErrorCode;
                    }
                    else
                    {
                        result.ResponseHeader.StatusCode = 0; //Default
                    }


                }
                return Task.FromResult(result);
            }
            catch (Exception ex)
            {
                return Task.FromResult(ex.HandleException<BillPayUpdatePayeeResponse>(ex, request));
            }
        }

        private UpdateBillPayeeRequest GetUpdateBillPayeeRequest(BillPayUpdatePayeeRequest request)
        {
            if (request == null)
            {
                throw new RequestHandlerException(400, 0, $"request was null");
            }

            var updateBillPayeeRequest = new UpdateBillPayeeRequest()
            {
                PayeeType = request.PayeeType.ToString(),
                Name = request.Name,
                NickName = request.NickName,
                Address1 = request.Address?.AddressLine1,
                Address2 = request.Address?.AddressLine2,
                City = request.Address?.City,
                State = request.Address?.State,
                Zip = request.Address?.ZipCode,
                Zip4 = null,
                Country = request.Address?.CountryCode,
                AccountNumber = request.AccountNumber,
                PhoneNumber = request.PhoneNumber,
                Email = request.Email
            };

            return updateBillPayeeRequest;
        }


    }
}
