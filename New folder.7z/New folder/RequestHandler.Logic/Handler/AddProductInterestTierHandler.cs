﻿using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Services.InterestRate;
using Gd.Bos.RequestHandler.Logic.Extension;
using Gd.Bos.RequestHandler.Logic.Queue;
using Gd.Bos.RequestHandler.Logic.Service;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RequestHandler.Logic.Handler
{
    public class AddProductInterestTierHandler : CommandHandlerBase<AddProductInterestTierRequest, AddProductInterestTierResponse>
    {
        private readonly IValidateIdentifier _validateIdentifier;
        private readonly IInterestRateService _interestRateService;

        public AddProductInterestTierHandler(IValidateIdentifier validateIdentifier,
             IInterestRateService interestRateService)
        {
            _validateIdentifier = validateIdentifier;
            _interestRateService = interestRateService;
        }

        public override void SetDomainContext(AddProductInterestTierRequest request)
        {
        }

        public override Task<AddProductInterestTierResponse> VerifyIdentifiers(AddProductInterestTierRequest request)
        {
            try
            {
                _validateIdentifier.ValidateProgramCode(DomainContext.Current.ProgramCode);
                return Task.FromResult(new AddProductInterestTierResponse() { ResponseHeader = new ResponseHeader() });
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AddProductInterestTierResponse>(e, request));
            }

        }

        public override Task<AddProductInterestTierResponse> Handle(AddProductInterestTierRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.ProgramCode))
                    throw new ArgumentNullException($"ProgramCode: Program Code cannot be null or empty.");

                var response = new AddProductInterestTierResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Error"
                    },
                };

                var dbUpdated =
                    _interestRateService.AddProductInterestTier(request);

                if (!dbUpdated)
                {
                    return Task.FromResult(response);
                }

                response.ResponseHeader.Message = "Success";

                return Task.FromResult(response);
            }
            catch (Exception e)
            {
                return Task.FromResult(e.HandleException<AddProductInterestTierResponse>(e, request));
            }
        }
    }
}
