﻿using Gd.Bos.RequestHandler.Core.Domain.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Gd.Bos.RequestHandler.Logic
{
    public static class ServiceInvoker
    {
        /// <summary>
        /// GetResponseAsync
        /// </summary>
        /// <param name="json"></param>
        /// <param name="url"></param>
        /// <param name="options"></param>
        /// <returns></returns>
        public static async Task<HttpWebResponse> GetResponseAsync(string uri, string method, string requestJson, Dictionary<string, string> options, int? requestTimeout = null)
        {
            var httpWebRequest = (HttpWebRequest)WebRequest.Create(uri);
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = method;
            httpWebRequest.Credentials = CredentialCache.DefaultNetworkCredentials;
            if (options.Count > 0)
            {
                foreach (var keyItem in options)
                    httpWebRequest.Headers.Add(keyItem.Key, keyItem.Value);
            }

            using (StreamWriter streamWriter = new StreamWriter(await httpWebRequest.GetRequestStreamAsync()))
            {
                await streamWriter.WriteAsync(requestJson);
                streamWriter.Flush();
                streamWriter.Close();
            }

            HttpWebResponse httpResponse = (HttpWebResponse)await httpWebRequest.GetResponseAsync();

            return httpResponse;
        }


        public static string SerializeToJson<T>(this T obj)
        {
            var trans = JsonConvert.SerializeObject(obj,
                new JsonSerializerSettings { DateFormatHandling = DateFormatHandling.IsoDateFormat, NullValueHandling = NullValueHandling.Ignore });

            return Newtonsoft.Json.JsonConvert.SerializeObject(trans);
        }

        public static Tout SerializeJsonToClass<Tout>(this string jsonString)
        {
            return Newtonsoft.Json.JsonConvert.DeserializeObject<Tout>(jsonString);
        }

        public static MemoryStream SerializeToJsonMemoryStream<T>(this T obj)
        {
            var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(obj);
            var ms = new MemoryStream();
            var writer = new Newtonsoft.Json.JsonTextWriter(new StreamWriter(ms));
            writer.WriteRaw(jsonString);
            writer.Flush();
            ms.Seek(0, 0);
            return ms;
        }

        public static byte[] SerializeToJsonBytes<T>(this T obj)
        {
            var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(obj);
            return Encoding.UTF8.GetBytes(jsonString);
        }

        public static T DeserializeFromJsonBytes<T>(byte[] jsonBytes)
        {
            var jsonString = Encoding.UTF8.GetString(jsonBytes);
            return Newtonsoft.Json.JsonConvert.DeserializeObject<T>(jsonString);
        }

        public static T GetWebResponse<T>(string uri, string method, string requestJson, int? requestTimeout = null)
        {
            Task<HttpWebResponse> webResponse = GetResponseAsync(uri, method, requestJson, null, requestTimeout);
            if (webResponse == null) return default(T);
            return Deserialize<T>(webResponse.Result.GetResponseStream());
        }


        public static T Deserialize<T>(Stream s)
        {
            var jd = new Newtonsoft.Json.JsonSerializer();
            T result = jd.Deserialize<T>(new Newtonsoft.Json.JsonTextReader(new StreamReader(s)));
            return result;
        }
    }
}
