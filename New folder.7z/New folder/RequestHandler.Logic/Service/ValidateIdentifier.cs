﻿using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Model.ProgramFunding;
using Gd.Bos.RequestHandler.Core.Domain.Model.Systems;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.Shared.Common.Caching;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Logic.FeatureLimitsFees.Contract.Enum;
using NLog;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;

namespace Gd.Bos.RequestHandler.Logic.Service
{
    public class ValidateIdentifier : IValidateIdentifier
    {
        public ValidateIdentifier(ILazyCache lazyCache,
            IRequestDataAccess requestDataAccess,
            ITokenizerService tokenizerService,
            IProgramRepository programRepository,
            IProgramFundingRepository programFundingRepository,
            IActivationSystemRepository activationSystemRepository,
            IAccountRepository accountRepository,
            IFeatureService featureService)
        {
            _lazyCache = lazyCache;
            _requestDataAccess = requestDataAccess;
            _tokenizerService = tokenizerService;
            _programRepository = programRepository;
            _programFundingRepository = programFundingRepository;
            _activationSystemRepository = activationSystemRepository;
            _accountRepository = accountRepository;
            _featureService = featureService;
        }

        public void ValidateProgramCode(ProgramCode programCode)
        {
            if (programCode == null) return;
            _programRepository.GetByProgramIdentifier(programCode); //It throws exception if program code not found.
        }

        public void ValidateProgramCode(AccountIdentifier accountIdentifier, ProgramCode programCode)
        {
            if (programCode == null) return;
            ValidateProgramCode(programCode);

            if (accountIdentifier == null) return;
            var resp = _lazyCache.Get(
                "ValidateProgramCode_" + accountIdentifier.ToString().ToUpper() + "_" + programCode.ToString().ToUpper(),
                TIME_SPAN,
                () => _requestDataAccess.ValidateProgramCode(accountIdentifier, programCode));
            if (!resp.Value)
                throw new ValidationException(10, 0, "Account Not Found.");
        }

        /// <summary>
        /// If account is closed then throw error
        /// </summary>
        public void ValidateAccountClosed(AccountIdentifier accountIdentifier, int code, int subCode)
        {
            if (accountIdentifier == null) return;
            Account account = null;
            try
            {
                account = _accountRepository.GetByAccountIdentifier(accountIdentifier);
            }
            catch
            {
                //do nothing
            }
            if (account?.AccountStatus == AccountStatus.Closed) throw new AccountValidationException(code, subCode, "Account is closed.", "accountClosed");
        }

        public void ValidatePAN(AccountIdentifier accountIdentifier, string plainTextPAN)
        {
            if (string.IsNullOrEmpty(plainTextPAN)) return;
            if (IsPan4(plainTextPAN)) return;
            if (accountIdentifier == null) return;

            var tokenizedPAN = _tokenizerService.TokenizePan(plainTextPAN);
            var resp = _lazyCache.Get(
                "ValidateTokenizedPAN_" + accountIdentifier.ToString().ToUpper() + "_" + tokenizedPAN.ToUpper(),
                TIME_SPAN,
                () => _requestDataAccess.ValidateTokenizedPAN(accountIdentifier, tokenizedPAN));
            if (!resp.Value)
                throw new ValidationException(4, 302, $"Identification Failed", $"ValidateTokenizedPAN_failed_{accountIdentifier}");
        }

        public void ValidateConsumerProfileIdentifier(AccountIdentifier accountIdentifier, UserIdentifier userIdentifier)
        {
            if (userIdentifier == null || accountIdentifier == null) return;

            var resp = _lazyCache.Get(
                "ValidateConsumerProfileIdentifier_" + accountIdentifier.ToString().ToUpper() + "_" + userIdentifier.ToString().ToUpper(),
                TIME_SPAN,
                () => _requestDataAccess.ValidateConsumerProfileIdentifier(accountIdentifier, userIdentifier));
            if (!resp.Value)
                throw new ValidationException(10, 0, "User Not Found");
        }

        public void ValidateSystemSource(string source)
        {
            var list = _activationSystemRepository.GetSystems();
            if (!list.Exists(a => string.Equals(a.System, source, StringComparison.OrdinalIgnoreCase)))
                throw new ValidationException(10, 0, "ActivationSystem Not Found");
        }

        public void ValidatePaymentInstrumentIdentifier(AccountIdentifier accountIdentifier,
            PaymentInstrumentIdentifier paymentInstrumentIdentifier)
        {
            if (paymentInstrumentIdentifier == null || accountIdentifier == null) return;

            var resp = _lazyCache.Get(
                "ValidatePaymentInstrumentIdentifier_" + accountIdentifier.ToString().ToUpper() + "_" + paymentInstrumentIdentifier.ToString().ToUpper(),
                TIME_SPAN,
                () => _requestDataAccess.ValidatePaymentInstrumentIdentifier(accountIdentifier, paymentInstrumentIdentifier));
            if (!resp.Value)
                throw new ValidationException(10, 0, "Payment Instrument Not Found");
        }

        public void ValidateProgramFunding(ProgramFundingIdentifier programFundingIdentifier, ProgramCode programCode)
        {
            if (programCode == null) return;
            if (programFundingIdentifier == null) return;

            _logger.Info("ValidateProgramFunding cache lookup.");
            var resp = _lazyCache.Get<BoolWrapper>(
                "ValidateProgramFunding_" + programFundingIdentifier.ToString().ToUpper() + "_" +
                programCode.ToString().ToUpper(),
                TIME_SPAN, () => Fetch(programFundingIdentifier, programCode));

            if (!resp.Value)
                throw new ValidationException(3, 109, "Program Funding Source is not associated with the Program.");
        }

        public void ValidatePartner_AccountIdProgramCode(AccountIdentifier accountIdentifier, ProgramCode programCode)
        {
            if (programCode == null) return;
            ValidateProgramCode(programCode);

            if (accountIdentifier == null) return;

            var resp = _lazyCache.Get(
                "ValidatePartner_AccountIdProgramCode_" + accountIdentifier.ToString().ToUpper() + "_" + programCode.ToString().ToUpper(),
                TIME_SPAN,
                () => Fetch(accountIdentifier, programCode));
            if (!resp.Value)
                throw new ValidationException(10, 0, "Account Not Found.");
        }

        public void ValidatePartner_PartialFunding(MrdcPartialTransferRequest request, ProgramCode programCode)
        {
            if (programCode == null) return;
            ValidateProgramCode(programCode);

            var postingInfos = request.TransferRoute?.SourceTransferEndpoint?.PostingInfos;

            if (postingInfos == null)
                throw new ValidationException(10, 0, "Posting funding should have at least one item");

            if (request.TransferRoute.TransactionAmount != postingInfos.Sum(p => p.Amount))
                throw new ValidationException(10, 0, "Check amount should be equal to the sum of postingInfo amount");

            if (postingInfos.Any(p => p.Amount == 0))
                throw new ValidationException(10, 0, "The amount of posting list should not be greater than 0");
        }

        public void ValidateProduct(ProgramCode programCode, ProductCode productCode)
        {
            if (programCode == null || productCode == null) return;

            var productInfo = _featureService.GetProductInfo(productCode.ToString(), programCode.ToString());
            var features = productInfo.ProductTiers.Select(pt =>
                pt.Features.FirstOrDefault(ft => ft.FeatureType == FeatureType.BlockCardCreation));
            if (features.Any())
            {
                var blockCardCreationFeature = features.FirstOrDefault();
                if (blockCardCreationFeature != null && blockCardCreationFeature.StartDate != null && blockCardCreationFeature.StartDate < DateTime.Now)
                {
                    throw new ValidationException(1000, 0, $"The product code {productCode} is unknown for program code {programCode}.");
                }
            }
            return;
        }

        public void ValidateDOB(string dateOfBirth)
        {
            var minDateTime = new DateTime(1901, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            if (DateTime.TryParseExact(dateOfBirth, "yyyy-MM-dd", new DateTimeFormatInfo(), DateTimeStyles.None, out var date))
            {
                if (date.AddYears(18) > DateTime.Now)
                {
                    throw new ValidationException(701, 0, "DOB is invalid, the minimum age must be 18.");
                }

                if (date < minDateTime)
                {
                    throw new ValidationException(620, 0, "dateOfBirth must be between Jan. 1, 1901 and today.");
                }
            }
            else
            {
                throw new ValidationException("dateOfBirth must be in the form of YYYY-MM-DD.");
            }
        }

        public void ValidateAccountInHealthyStatus(AccountIdentifier accountIdentifier)
        {
            if (accountIdentifier == null)
                return;

            var resp = _lazyCache.Get($"ValidateAccountInHealthyStatus_{accountIdentifier.ToString().ToUpper()}",
                TIME_SPAN,
                () => _accountRepository.GetAccountStatusByAccountIdentifier(accountIdentifier));

            if (resp == null)
                throw new ValidationException(4200, 2000, "Account not found.");
            if (resp.AccountStatus != AccountStatus.Normal)
                throw new ValidationException(4200, 2001, "Account is not in Normal status.");
        }

        private BoolWrapper Fetch(ProgramFundingIdentifier programFundingIdentifier, ProgramCode programCode)
        {
            var partnerInfo = _programFundingRepository.GetPartnerInfoByAccountIdentifier(programFundingIdentifier.ToString());

            if (partnerInfo == null) return new BoolWrapper(false);
            if (String.IsNullOrEmpty(partnerInfo.ProgramCode) || partnerInfo.ProgramCode.ToLower() != programCode.ToString().ToLower())
                return new BoolWrapper(false);

            return new BoolWrapper(true);
        }

        private BoolWrapper Fetch(AccountIdentifier accountIdentifier, ProgramCode programCode)
        {
            var partnerInfo = _programFundingRepository.GetProgramInfoByAccountIdentifier(accountIdentifier.ToString());
            var productProgramInfo = _programRepository.GetProductProgramPartner(programCode);

            if (partnerInfo == null) return new BoolWrapper(false);
            if (productProgramInfo == null) return new BoolWrapper(false);
            if (partnerInfo.PartnerKey != productProgramInfo.PartnerKey)
                return new BoolWrapper(false);

            return new BoolWrapper(true);
        }

        private bool IsPan4(string pan)
        {
            return pan != null && pan.Trim().Length == 4;
        }

        private TimeSpan TIME_SPAN = new TimeSpan(1, 0, 0, 0);
        private readonly ILazyCache _lazyCache;
        private readonly IRequestDataAccess _requestDataAccess;
        private readonly IProgramFundingRepository _programFundingRepository;
        private readonly ITokenizerService _tokenizerService;
        private readonly IProgramRepository _programRepository;
        private static readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        private IActivationSystemRepository _activationSystemRepository;
        private IAccountRepository _accountRepository;
        private IFeatureService _featureService;
    }
}
