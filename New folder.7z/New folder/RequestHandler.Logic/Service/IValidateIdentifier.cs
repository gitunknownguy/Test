﻿using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;

namespace Gd.Bos.RequestHandler.Logic.Service
{
    public interface IValidateIdentifier
    {
        void ValidateProgramCode(Core.Domain.Model.ProgramCode programCode);
        void ValidateProgramCode(Core.Domain.Model.Account.AccountIdentifier accountIdentifier, Core.Domain.Model.ProgramCode programCode);
        void ValidatePAN(Core.Domain.Model.Account.AccountIdentifier accountIdentifier, string tokenizedPAN);
        void ValidateConsumerProfileIdentifier(Core.Domain.Model.Account.AccountIdentifier accountIdentifier,
            Core.Domain.Model.User.UserIdentifier userIdentifier);
        void ValidatePaymentInstrumentIdentifier(Core.Domain.Model.Account.AccountIdentifier accountIdentifier,
            Core.Domain.Model.Payment.PaymentInstrumentIdentifier paymentInstrumentIdentifier);
        void ValidateProgramFunding(Core.Domain.Model.ProgramFunding.ProgramFundingIdentifier programFundingIdentifier,
            Core.Domain.Model.ProgramCode programCode);
        void ValidatePartner_AccountIdProgramCode(Core.Domain.Model.Account.AccountIdentifier accountIdentifier,
            Core.Domain.Model.ProgramCode programCode);
        void ValidatePartner_PartialFunding(MrdcPartialTransferRequest request, ProgramCode programCode);
        void ValidateSystemSource(string source);
        void ValidateAccountClosed(Core.Domain.Model.Account.AccountIdentifier accountIdentifier, int code, int subCode);
        void ValidateProduct(ProgramCode programCode, ProductCode productCode);
        void ValidateDOB(string dateOfBirth);
        void ValidateAccountInHealthyStatus(Core.Domain.Model.Account.AccountIdentifier accountIdentifier);
    }
}
