﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;

namespace Gd.Bos.RequestHandler.Logic.Common
{
    public static class StatusMapper
    {
        public static PaymentInstrumentStatus GetPaymentInstrumentStatus(PaymentIdentifierStatus paymentIdentifierStatus, PaymentInstrumentStatus paymentInstrumentStatus)
        {
            if (paymentIdentifierStatus == PaymentIdentifierStatus.Closed)
                return PaymentInstrumentStatus.Closed;
            else if (paymentIdentifierStatus == PaymentIdentifierStatus.Blocked
                     && paymentInstrumentStatus != PaymentInstrumentStatus.Deactivated)
                return PaymentInstrumentStatus.Blocked;

            return paymentInstrumentStatus;
        }
        public static List<PaymentInstrumentStatusReason> GetPaymentInstrumentStatusReasons(PaymentIdentifierStatus paymentIdentifierStatus, PaymentInstrumentStatus paymentInstrumentStatus, PaymentInstrumentStatusReason? paymentInstrumentStatusReason, PaymentIdentifierStatusReason? paymentIdentifierStatusReason)
        {
            List<PaymentInstrumentStatusReason> reasons = new List<PaymentInstrumentStatusReason>();
            if (paymentIdentifierStatus == PaymentIdentifierStatus.Closed)
            {
                if (paymentInstrumentStatusReason != null) reasons.Add(paymentInstrumentStatusReason.Value);
            }
            else if (paymentIdentifierStatus == PaymentIdentifierStatus.Blocked
                     && paymentInstrumentStatus != PaymentInstrumentStatus.Deactivated)
            {
                if (paymentInstrumentStatusReason != null) reasons.Add(paymentInstrumentStatusReason.Value);
                if (paymentIdentifierStatusReason == PaymentIdentifierStatusReason.AccountBlock)
                    reasons.Add(PaymentInstrumentStatusReason.AccountBlocked);
                if (paymentIdentifierStatusReason == PaymentIdentifierStatusReason.CustomerInitiatedHold)
                    reasons.Add(PaymentInstrumentStatusReason.CustomerInitiatedHold);
            }

            else
            if (paymentInstrumentStatusReason != null) reasons.Add(paymentInstrumentStatusReason.Value);

            if (reasons.Count == 0)
                reasons = null;
            return reasons;
        }

    }
}
