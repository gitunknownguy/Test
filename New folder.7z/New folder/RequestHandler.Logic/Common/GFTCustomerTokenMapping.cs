﻿using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;

namespace RequestHandler.Logic.Common
{
    public static class GFTCustomerTokenMapping
    {
        public static readonly string CUSTOMER_TYPE_BAAS = "baas";
        public static readonly string CUSTOMER_TYPE_EXTERNAL = "external";

        public static bool IsValidCustomerType(string customerType)
        {
            return CUSTOMER_TYPE_BAAS.Equals(customerType) || CUSTOMER_TYPE_EXTERNAL.Equals(customerType);
        }
    }
}
