﻿using System;
using System.Diagnostics.CodeAnalysis;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers.Exceptions;
using Gd.Bos.RequestHandler.Core.Infrastructure;

namespace Gd.Bos.RequestHandler.Logic.Common
{
    public static class TransferRequestValidation
    {
        public static bool HandleDisbursementInValidation(TransferRequest request)
        {
            if (request.TransferRoute.SourceTransferEndPoint.TransferEndPointType != EndpointType.ProgramFundingSource)
                throw new InvalidTransferRouteException("DisbursementIn must have source endpoint type of ProgramFundingSource.");

            if (request.TransferRoute.TargetTransferEndPoint.TransferEndPointType != EndpointType.Account)
                throw new InvalidTransferRouteException("DisbursementIn must have target endpoint type of Account.");

            return true;
        }

        public static bool HandleDisbursementOutValidation(TransferRequest request)
        {
            if (request.TransferRoute.SourceTransferEndPoint.TransferEndPointType != EndpointType.Account)
                throw new InvalidTransferRouteException("DisbursementOut must have source endpoint type of Account.");

            if (request.TransferRoute.TargetTransferEndPoint.TransferEndPointType != EndpointType.ProgramFundingSource)
                throw new InvalidTransferRouteException("DisbursementOut must have target endpoint type of ProgramFundingSource.");

            return true;
        }

        public static bool HandleAchOutValidation(TransferRequest request)
        {
            if (request.TransferRoute?.SourceTransferEndPoint?.TransferEndPointType != EndpointType.Account)
                throw new InvalidTransferRouteException("AchOut must have source endpoint type of Account.");

            if (request.TransferRoute?.TargetTransferEndPoint?.TransferEndPointType != EndpointType.BankAccount)
                throw new InvalidTransferRouteException("AchOut must have target endpoint type of BankAccount.");

            if (request.TransferRoute?.TargetTransferEndPoint?.BankAccount == null && String.IsNullOrEmpty(request.TransferRoute?.TargetTransferEndPoint?.BankAccountReferenceId))
                throw new InvalidTransferRouteException("BankAccount data or BankAccountReferenceId must be provided for a BankAccount transfer endpoint type.");

            if (string.IsNullOrEmpty(request.TransferRoute.TargetTransferEndPoint.BankAccountReferenceId))
                AssertBankAccountValid(request.TransferRoute?.TargetTransferEndPoint?.BankAccount, "targetTransferEndpoint.bankAccount");

            return true;
        }

        public static bool HandleAchPullValidation(TransferRequest request)
        {
            if (request.TransferRoute?.SourceTransferEndPoint?.TransferEndPointType != EndpointType.BankAccount)
                throw new InvalidTransferRouteException("AchPull must have source endpoint type of Account.");

            if (String.IsNullOrEmpty(request.TransferRoute?.SourceTransferEndPoint.BankAccountReferenceId) && request.TransferRoute?.SourceTransferEndPoint?.BankAccount == null)
                throw new InvalidTransferRouteException("BankAccount data or BankAccountReferenceId must be provided for a BankAccount transfer endpoint type.");

            if (request.TransferRoute?.SourceTransferEndPoint?.BankAccount != null)
                AssertBankAccountValid(request.TransferRoute?.SourceTransferEndPoint?.BankAccount, "SourceTransferEndpoint.bankAccount");

            return true;
        }

        public static bool HandleMrdcTransferValidation(TransferRequest request, bool isAccessTransfer = false)
        {

            if (request.TransferRoute?.SourceTransferEndPoint?.TransferEndPointType != EndpointType.Check)
                throw new InvalidTransferRouteException("MrdcTransfer must have target endpoint type of Check.");

            if (!isAccessTransfer)
            {
                if (request.TransferRoute.TransactionAmount <= 0)
                    throw new InvalidTransferRouteException(
                        "MrdcTransfer must have TransactionAmount greater than zero.");
                if (request.TransferRoute?.SourceTransferEndPoint?.Check == null)
                    throw new InvalidTransferRouteException(
                        "Check details must be provided for a MrdcTransfer endpoint type.");

                // AssertCheckValid - Add Check validations
                AssertCheckValid(request.TransferRoute?.SourceTransferEndPoint?.Check, "SourceTransferEndpoint.check");
            }

            return true;
        }

        public static bool HandleMrdcX9TransferValidation(MrdcPartialTransferRequest request, bool isAccessTransfer = false)
        {
            if (!isAccessTransfer)
            {
                if (request.TransferRoute.TransactionAmount <= 0)
                    throw new InvalidTransferRouteException(
                        "MrdcTransfer must have TransactionAmount greater than zero.");
                if (request.TransferRoute?.SourceTransferEndpoint?.Check == null)
                    throw new InvalidTransferRouteException(
                        "Check details must be provided for a MrdcTransfer endpoint type.");

                // AssertCheckValid - Add Check validations
                AssertCheckValid(request.TransferRoute?.SourceTransferEndpoint?.Check, "SourceTransferEndpoint.check");
            }

            return true;
        }

        public static bool HandleSwipeReloadValidation(TransferRequest request)
        {
            if (request.IsReversal)
            {
                if (request.TransferRoute?.SourceTransferEndPoint?.TransferEndPointType != EndpointType.Account)
                    throw new InvalidTransferRouteException("SwipeReloadReversal must have source endpoint type of Account.");

                if (request.TransferRoute?.TargetTransferEndPoint?.TransferEndPointType != EndpointType.RetailSale)
                    throw new InvalidTransferRouteException("SwipeReloadReversal must have target endpoint type of RetailSale.");
            }
            else
            {
                if (request.TransferRoute?.SourceTransferEndPoint?.TransferEndPointType != EndpointType.RetailSale)
                    throw new InvalidTransferRouteException("SwipeReload must have source endpoint type of RetailSale.");

                if (request.TransferRoute?.TargetTransferEndPoint?.TransferEndPointType != EndpointType.Account)
                    throw new InvalidTransferRouteException("SwipeReload must have target endpoint type of Account.");
            }

            return true;
        }

        public static bool HandleAdjustBalanceValidation(AdjustBalanceRequest request)
        {
            return true;
        }

        public static bool HandlePurseToPurseValidation(TransferRequest request)
        {
            if (request.TransferRoute.SourceTransferEndPoint.TransferEndPointType != EndpointType.Purse)
                throw new InvalidTransferRouteException("Purse must have source endpoint type of Purse.");

            if (request.TransferRoute.TargetTransferEndPoint.TransferEndPointType != EndpointType.Purse)
                throw new InvalidTransferRouteException("Purse must have target endpoint type of Purse.");

            if (request.TransferRoute.SourceTransferEndPoint.Identifier == request.TransferRoute.TargetTransferEndPoint.Identifier)
                throw new TransferValidationException(3, 116, "Cannot Transfer from an account/purse to same account/purse.");
            return true;
        }

        public static bool HandleECashLoadValidation(TransferRequest request)
        {
            if (request.TransferRoute?.SourceTransferEndPoint?.TransferEndPointType != EndpointType.RetailSale)
                throw new InvalidTransferRouteException("ECashLoad must have source endpoint type of RetailSale.");

            if (request.TransferRoute?.TargetTransferEndPoint?.TransferEndPointType != EndpointType.Account)
                throw new InvalidTransferRouteException("ECashLoad must have target endpoint type of Account.");

            if (string.IsNullOrEmpty(request.TransferRoute?.TargetTransferEndPoint?.Identifier) ||
               !Guid.TryParse(request.TransferRoute?.TargetTransferEndPoint?.Identifier, out var acct))
                throw new InvalidTransferRouteException("Target endpoint type of Account must have a valid identifier.");

            if (request.Initiator != request.TransferRoute.TargetTransferEndPoint.Identifier)
                throw new TransferValidationException(3, 112, "Initiator does not match target account.");

            return true;
        }

        public static bool HandleECashSendValidation(TransferRequest request)
        {
            if (request.TransferRoute?.SourceTransferEndPoint?.TransferEndPointType != EndpointType.RetailSale)
                throw new InvalidTransferRouteException("SwipeReload must have source endpoint type of RetailSale.");

            if (request.TransferRoute.TargetTransferEndPoint.TransferEndPointType != EndpointType.Account
                && request.TransferRoute.TargetTransferEndPoint.TransferEndPointType != EndpointType.Handle)
                throw new InvalidTransferRouteException("SwipeReload must have target endpoint type of Account or Handle.");

            if (request.TransferRoute?.TargetTransferEndPoint?.TransferEndPointType == EndpointType.Account)
            {
                if (string.IsNullOrEmpty(request.TransferRoute?.TargetTransferEndPoint?.Identifier) ||
                    !Guid.TryParse(request.TransferRoute?.TargetTransferEndPoint?.Identifier, out var acct))
                {
                    throw new InvalidTransferRouteException("Target endpoint type of Account must have a valid identifier.");
                }
                if (request.Initiator == request.TransferRoute.TargetTransferEndPoint.Identifier)
                    throw new TransferValidationException(3, 117, "P2P Source and Target Accounts are same.");
            }

            return true;
        }

        public static bool HandleIFTLoadValidation(TransferRequest request)
        {
            if (request.TransferRoute?.SourceTransferEndPoint?.TransferEndPointType != EndpointType.Card)
                throw new InvalidTransferRouteException("IFTLoad must have source endpoint type of Card.");

            if (request.TransferRoute.TargetTransferEndPoint.TransferEndPointType != EndpointType.Account)
                throw new InvalidTransferRouteException("IFTLoad must have target endpoint type of Account.");

            //if (String.IsNullOrEmpty(request.TransferRoute?.SourceTransferEndPoint?.CardData?.Cvv))
            //    throw new InvalidTransferRouteException("Endpoint type of Card should have cvv as well.");

            return true;
        }

        public static bool HandleIFTSendValidation(TransferRequest request)
        {
            if (request.TransferRoute?.SourceTransferEndPoint?.TransferEndPointType != EndpointType.Card)
                throw new InvalidTransferRouteException("IFTSend must have source endpoint type of Card.");

            //if (String.IsNullOrEmpty(request.TransferRoute?.SourceTransferEndPoint?.CardData?.Cvv))
            //    throw new InvalidTransferRouteException("Endpoint type of Card should have cvv as well.");

            if (request.TransferRoute.TargetTransferEndPoint.TransferEndPointType != EndpointType.Account
                && request.TransferRoute.TargetTransferEndPoint.TransferEndPointType != EndpointType.Handle)
                throw new InvalidTransferRouteException("IFTSend must have target endpoint type of Account or Handle.");

            return true;
        }

        public static bool HandleIFTOutValidation(TransferRequest request)
        {
            if (request.TransferRoute?.SourceTransferEndPoint?.TransferEndPointType != EndpointType.Account)
                throw new InvalidTransferRouteException("IFTOut must have source endpoint type of Account.");

            if (request.TransferRoute.TargetTransferEndPoint.TransferEndPointType != EndpointType.Card)
                throw new InvalidTransferRouteException("IFTOut must have target endpoint type of Card.");

            return true;
        }

        public static bool HandleSCCPaymentValidation(TransferRequest request)
        {
            if (request.TransferRoute?.SourceTransferEndPoint?.TransferEndPointType != EndpointType.Account)
                throw new InvalidTransferRouteException("SCCPayment must have source endpoint type of Account.");

            if (request.TransferRoute.TargetTransferEndPoint.TransferEndPointType != EndpointType.Account)
                throw new InvalidTransferRouteException("SCCPayment must have target endpoint type of Account.");

            return true;
        }

        public static bool HandleSCCFundingValidation(TransferRequest request)
        {
            if (request.TransferRoute?.SourceTransferEndPoint?.TransferEndPointType != EndpointType.Account)
                throw new InvalidTransferRouteException("SCCFunding must have source endpoint type of Account.");

            if (request.TransferRoute.TargetTransferEndPoint.TransferEndPointType != EndpointType.Account)
                throw new InvalidTransferRouteException("SCCFunding must have target endpoint type of Account.");

            return true;
        }
        public static bool HandleCreditLineIncrease(TransferRequest request)
        {
            if (request.TransferRoute?.SourceTransferEndPoint?.TransferEndPointType != EndpointType.Account)
                throw new InvalidTransferRouteException("SCCFunding must have source endpoint type of Account.");

            if (request.TransferRoute.TargetTransferEndPoint.TransferEndPointType != EndpointType.Account)
                throw new InvalidTransferRouteException("SCCFunding must have target endpoint type of Account.");

            return true;
        }
        /// <summary>
        /// Verify the endpoint object type is corresponding by reversal direction
        /// </summary>
        /// <param name="request">Request object</param>
        /// <returns></returns>
        /// <exception cref="InvalidTransferRouteException"></exception>
        public static bool HandleUnLoadValidation(TransferRequest request)
        {
            if (!request.IsReversal)
            {
                if (request.TransferRoute?.SourceTransferEndPoint?.TransferEndPointType != EndpointType.Account)
                    throw new InvalidTransferRouteException("unload must have source endpoint type of Account.");

                if (request.TransferRoute?.TargetTransferEndPoint?.TransferEndPointType != EndpointType.RetailSale)
                    throw new InvalidTransferRouteException("unload must have target endpoint type of RetailSale.");
            }
            else
            {
                if (request.TransferRoute?.SourceTransferEndPoint?.TransferEndPointType != EndpointType.RetailSale)
                    throw new InvalidTransferRouteException("unload must have source endpoint type of RetailSale.");

                if (request.TransferRoute?.TargetTransferEndPoint?.TransferEndPointType != EndpointType.Account)
                    throw new InvalidTransferRouteException("unload must have target endpoint type of Account.");
            }
            return true;
        }
        public static bool HandleInitialLoadValidation(TransferRequest request)
        {
            if (request.IsReversal)
            {
                if (request.TransferRoute?.SourceTransferEndPoint?.TransferEndPointType != EndpointType.Account)
                    throw new InvalidTransferRouteException("Initial Load Reversal must have source endpoint type of Account.");

                if (request.TransferRoute?.TargetTransferEndPoint?.TransferEndPointType != EndpointType.RetailSale)
                    throw new InvalidTransferRouteException("Initial Load Reversal must have target endpoint type of RetailSale.");
            }
            else
            {
                if (request.TransferRoute?.SourceTransferEndPoint?.TransferEndPointType != EndpointType.RetailSale)
                    throw new InvalidTransferRouteException("Initial Load must have source endpoint type of RetailSale.");

                if (request.TransferRoute?.TargetTransferEndPoint?.TransferEndPointType != EndpointType.Account)
                    throw new InvalidTransferRouteException("Initial Load must have target endpoint type of Account.");
            }

            return true;
        }
        internal static void AssertCheckValid(Check check, string objectName)
        {
            //TODO: Using the same subcodes as ACH, later to be changed. 
            if (string.IsNullOrEmpty(check.FrontImage))
                throw FieldNotSpecified(objectName, "FrontImage", ResponseSubcodes.Invalid_ACH_First_Name);
            if (string.IsNullOrEmpty(check.BackImage))
                throw FieldNotSpecified(objectName, "BackImage", ResponseSubcodes.Invalid_ACH_Last_Name);
        }

        /// <param name="account">BankAccount instance to test</param>
        /// <param name="objectName">name of the bank account being tested e.g. targetAccount, used for message formatting.</param>
        internal static void AssertBankAccountValid(BankAccount account, string objectName)
        {
            if (account == null)
                throw new RequestHandlerException(200, 0, $"{objectName} must be specified");

            if (string.IsNullOrEmpty(account.BusinessName))
            {
                if (string.IsNullOrEmpty(account.FirstName))
                    throw FieldNotSpecified(objectName, "FirstName", ResponseSubcodes.Invalid_ACH_First_Name);
                if (string.IsNullOrEmpty(account.LastName))
                    throw FieldNotSpecified(objectName, "LastName", ResponseSubcodes.Invalid_ACH_Last_Name);
            }

            if (string.IsNullOrEmpty(account.AccountNumber))
                throw FieldNotSpecified(objectName, "AccountNumber", ResponseSubcodes.Invalid_ACH_Account_Number);

            if (string.IsNullOrEmpty(account.RoutingNumber))
                throw FieldNotSpecified(objectName, "RoutingNumber", ResponseSubcodes.Invalid_ACH_Routing_Number);

            if (string.IsNullOrEmpty(account.BankName))
                throw FieldNotSpecified(objectName, "BankName", ResponseSubcodes.Invalid_ACH_Bank_Name);

            if (string.IsNullOrEmpty(account.AccountType))
            {
                throw FieldNotSpecified(objectName, "AccountType", ResponseSubcodes.Invalid_ACH_Account_Type);
            }

        }
        private static RequestHandlerException FieldNotSpecified(string className, string fieldName, ResponseSubcodes subCode)
        {
            return new RequestHandlerException(200, (int)subCode, $"{className} {fieldName} must be specified");
        }

        public static bool HandlePeerPaymentValidation(TransferRequest request)
        {
            if (request.TransferRoute.SourceTransferEndPoint.TransferEndPointType != EndpointType.Account
                 && request.TransferRoute.SourceTransferEndPoint.TransferEndPointType != EndpointType.Handle)
                throw new InvalidTransferRouteException("PeerPayment must have source endpoint type of Account or Handle.");

            if (request.TransferRoute.TargetTransferEndPoint.TransferEndPointType != EndpointType.Account
                && request.TransferRoute.TargetTransferEndPoint.TransferEndPointType != EndpointType.Handle)
                throw new InvalidTransferRouteException("PeerPayment must have target endpoint type of Account or Handle.");

            if (request.TransferRoute.TargetTransferEndPoint.TransferEndPointType == EndpointType.Handle &&
                (request.TransferRoute.TargetTransferEndPoint.HandleData == null
                 || string.IsNullOrEmpty(request.TransferRoute.TargetTransferEndPoint.HandleData.Handle)))
                throw new ValidationException(200, 0, "TargetEndpointType is handle and handle not provided.");

            if (request.SourceSystem != 0 && !(request.SourceSystem == SourceSystem.Partner
                  || request.SourceSystem == SourceSystem.AMM
                  || request.SourceSystem == SourceSystem.IVR
                  || request.SourceSystem == SourceSystem.CRM))
                throw new TransferValidationException(3, 121, "Invalid sourceSystemType.");

            return true;
        }

        public static bool HandleEGiftValidation(TransferRequest request)
        {
            if (request.TransferRoute.SourceTransferEndPoint.TransferEndPointType != EndpointType.Account)
                throw new InvalidTransferRouteException("EGift purchase must have source endpoint type of Account.");

            if (request.TransferRoute.SourceTransferEndPoint.Identifier != request.Initiator)
                throw new InvalidTransferRouteException("EGift purchase initiator account must match source account.");

            /*Change to EGift
             EndpointType = EGiftPurchase
             EgiftTransferEndpoint inherits TransferEndpoint, adds property called "ProductConfigurationId"
             EgiftTransferEndpoint.ProductConfigurationId should exits and be valid
             EgiftTransferEndpoint.EndpointType == EGiftPurchase (The new EndpointType Enum value)
             */

            if (request.TransferRoute.TargetTransferEndPoint.TransferEndPointType != EndpointType.Check /*EGiftPurchase*/)
                throw new InvalidTransferRouteException("PeerPayment must have target endpoint type of Account.");

            return true;
        }

        public static void HandleUpdateTransferValidation(UpdateTransferRequest request)
        {
            if (request.RequestHeader.RequestId == Guid.Empty)
                throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_RequestId, $"{nameof(request)}.RequestHeader.RequestId must be specified");

            if (string.IsNullOrEmpty(request.TransferIdentifier) || request.TransferIdentifier == Guid.Empty.ToString())
                throw new RequestHandlerException(200, (int)ResponseSubcodes.Invalid_Transfer_Identifier, $"{nameof(request)}.TransferIdentifier must be specified");

            if (request.TransferEndPoint?.TransferEndPointType != EndpointType.Account && (request.TransferEndPoint?.IsSource ?? false))
                throw new RequestHandlerException(200, (int)ResponseSubcodes.Operation_Not_Supported, "Operation Supported only on Target Accounts currently");

            if (!(request.AuthorizationType == AuthorizationType.Execute ||
                  request.AuthorizationType == AuthorizationType.Cancel ||
                  request.AuthorizationType == AuthorizationType.Reject ||
                  request.AuthorizationType == AuthorizationType.Reverse))
                throw new TransferValidationException(3, 121, "Invalid transferAuthorizationType");
        }
    }
}
