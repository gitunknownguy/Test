﻿
namespace Gd.Bos.RequestHandler.Logic.Common
{
    /// <summary>
    /// response subcodes generated from  https://confluence/display/PROD/BaaS+API+Response+Codes
    /// </summary>
    public enum ResponseSubcodes
    {
        ///<summary>The enrollment API call was successful, but the user must complete a KYC cure and then the registration must be completed using the PaymentInstruments endpoint.   </summary>
        KYC_Required_Curable = 10,


        ///<summary>There is no cure or treatment in this case.</summary>
        KYC_Failed_No_Cure = 11,
        ///<summary>The KYC Gate provided needs to match kycPendingGate</summary>
        KYC_Gate_needs_to_match_kycPendingGate = 12,


        ///<summary></summary>
        Future_placeholder = 20,
        ///<summary>Image needs to be retaken and resubmitted</summary>
        IDV_Scan_Upload_Failure = 21,
        ///<summary>This is non-curable</summary>
        IDV_Scan_Upload_Success___Verification_Failed = 22,
        ///<summary>TBD</summary>
        IDV_Not_Readable = 23,
        ///<summary>TBD</summary>
        IDV_Name_Mismatch = 24,
        ///<summary>User must provide a U.S. Identity</summary>
        Non_US_Identity_given_for_KYC = 30,
        ///<summary>Either No cure or Manual.  2 business day SLA for manual.</summary>
        OFAC_Partial_Match = 31,
        ///<summary>No cure.  This is set as a result of a manually confirmed OFAC hit.</summary>
        OFAC_Hard_Decline = 32,
        ///<summary>There is no cure or treatment in this case.</summary>
        KYC_and_OFAC_Fail = 33,
        ///<summary>KYC can be cured.  OFAC could still fall into a manual review if KYC Passes.</summary>
        KYC_and_OFAC_Failed_KYC_Failure_is_Curable = 34,
        ///<summary>User must be at least 18 years of age.   Note: This error occurs if a user provided a Date Of Birth greater than 18 years ago but the identity verification responded that the User was under 18 years old.</summary>
        User_birthdate_under_age_required_for_KYC = 40,


        ///<summary>Check kycPendingGate for the specific cure.</summary>
        Suspect_Fraud = 50,
        ///<summary>There is no cure for confirmed fraud.</summary>
        Confirmed_Fraud = 51,

        ///<summary>Check the account.status and kycPendingGate for the specific cure (if any)</summary>
        Operation_not_allowed_for_the_Account_Status = 100,
        ///<summary>Partner returns message to user that maximum limit was exceeded and to try again with an amount within the limit</summary>
        Transfer_Limit_exceeded = 101,
        ///<summary>Partner returns message to user that maximum account balance was exceeded and to try again with an amount that will not cause the balance to be exceeded.</summary>
        Account_balance_limit_reached_or_exceeded = 102,
        ///<summary>Partner returns message to user that the account has insufficient funds for the transaction and to try again with an amount within the remaining available balance.</summary>
        Insufficient_Funds = 103,
        ///<summary>There is no treatment</summary>
        Account_is_closed = 105,
        ///<summary>Check kycPendingGate for the specific cure (if any). </summary>
        Account_is_locked = 106,
        ///<summary>Partner updates their transfer status</summary>
        Transfer_request_already_completed = 107,
        ///<summary>A previously used transferIdentifier was used again.</summary>
        Duplicate_transfer_Identifier = 108,
        ///<summary>Try again with the correct Guid for the Funding Account.  This should have been provided to the client offline.</summary>
        Invalid_Funding_Account = 109,
        ///<summary>Check kycPendingGate for the specific cure (if any). </summary>
        Declined_by_Fraud_check = 110,
        ///<summary>Correct one of the initiator, source or target account identifiers.</summary>
        Initiator_does_not_match_the_source_or_target_account = 111,
        ///<summary></summary>
        Invalid_Transfer_Identifier = 112,
        ///<summary></summary>
        Invalid_RequestId = 113,
        Account_is_Pending = 114,
        Account_is_Restricted = 115,
        Account_Invalid_Status = 116,


        ///<summary>The end user will need to resubmit the transfer request with a corrected ACH Routing Number.</summary>
        Invalid_ACH_Routing_Number = 200,
        ///<summary></summary>
        Invalid_ACH_Account_Number = 201,
        ///<summary></summary>
        Invalid_ACH_Bank_Name = 202,
        ///<summary></summary>
        Invalid_ACH_First_Name = 203,
        ///<summary></summary>
        Invalid_ACH_Last_Name = 204,
        ///<summary>Must be a positive amount.</summary>
        Invalid_ACH_Amount = 205,
        ///<summary></summary>
        Invalid_ACH_Account_Type = 206,
        Invalid_Account = 207,

        ///<summary></summary>
        Card_is_Closed = 300,
        ///<summary></summary>
        Card_is_Blocked = 301,
        ///<summary>The PAN/Expiration Date/CVV/Last 4 SSN combination failed identification.   This will apply to GD IVR initially.</summary>
        Card_and_User_Identification_Failed = 302,
        ///<summary>A different card must be activated.</summary>
        A_Payment_Instrument_must_be_in_a_notActivated_state_to_be_activated = 303,
        ///<summary>No action required.  The card is already active.</summary>
        Payment_Instrument_was_already_activated = 304,
        ///<summary>Pin cannot repeat the same digits 3 or more times</summary>
        Invalid_Pin_Provided = 305,

        ///<summary>Pin must be exactly 4 digits</summary>
        Invalid_Pin_Length = 306,
        ///<summary>A Payment Instrument cannot be created for a pending account unless kycPendingGate is healthy.  If kycPendingGate is “idv” then use the kycGates endpoint.  If kycPendingGate is “manual” then an accountUpdated alert will be sent when the account is updated.  If it is “none” then the account registration cannot be completed.</summary>
        Operation_cannot_be_completed_since_the_account_is_not_healthy = 307,
        ///<summary>Operation Not supported at this time</summary>
        Operation_Not_Supported = 308,

        Account_Statement_Not_Found = 309,

        Invalid_BillCycleDay = 310,

        TempCard_Activation_Failed = 311,
        Invalid_CardStatusUpdate_Parameters = 312,
        Card_StatusUpdate_Failed = 313
    }
}
