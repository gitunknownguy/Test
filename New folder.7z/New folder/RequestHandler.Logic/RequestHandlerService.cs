﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Services.AsyncCommandService;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.RequestHandler.Logic.Queue;
using Microsoft.Extensions.Hosting;
using NLog;
using RequestHandler.Logic.Queue;

namespace Gd.Bos.RequestHandler.Logic
{
    public class RequestHandlerService : BackgroundService
    {
        public RequestHandlerService(
            IAccountDataAccess accountDataAccess,
            ICommandChannelServer commandChannelServer,
            IBatchCommandChannelServer batchCommandChannelServer,
            IAsyncCommandService asyncCommandService)
        {
            _accountDataAccess = accountDataAccess;
            _commandChannelServer = commandChannelServer;
            _batchCommandChannelServer = batchCommandChannelServer;
            _asyncCommandService = asyncCommandService;
        }


        public override void Dispose()
        {
            _commandChannelServer.Dispose();
            _batchCommandChannelServer.Dispose();
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.Info("RequestHandlerService ExecuteAsync");

            await Task.Run(async () => await KeepTryingToConnect(stoppingToken), stoppingToken);
            await Task.CompletedTask;
        }

        private async Task KeepTryingToConnect(CancellationToken cToken)
        {
            bool connected = false;
            bool asyncCommandServiceConnected = false;

            while (!connected && !cToken.IsCancellationRequested)
            {
                lock (this)
                {
                    if (!cToken.IsCancellationRequested)
                    {
                        if (!asyncCommandServiceConnected)
                        {
                            try
                            {
                                _logger.Info("Calling Start() on AsyncCommandService...");
                                _asyncCommandService.Start();
                                _logger.Info("AsyncCommandService started.");
                                asyncCommandServiceConnected = true;
                            }
                            catch (Exception e)
                            {
                                _logger.Warn(e, "Exception calling Start() on AsyncCommandService.");
                            }
                        }

                        try
                        {
                            _logger.Info("Calling Start() on CommandChannelServer...");
                            _commandChannelServer.Start();
                            _batchCommandChannelServer.Start();
                            _logger.Info("CommandChannelServer started.");
                            connected = true;
                        }
                        catch (Exception e)
                        {
                            _logger.Error(e, "Exception calling Start() in CommandChannelServer.");
                        }
                    }
                }

                if (connected)
                    _logger.Info("RequestHandlerService started.");
                else
                {
                    _logger.Error("Could not start RequestHandlerService.  Retrying after 30 seconds.");
                    await Task.Delay(30000, cToken);
                }
            }
        }

        public override Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.Info("RequestHandlerService stopping...");

            try
            {
                lock (this)
                {
                    try
                    {
                        _asyncCommandService.Stop();
                    }
                    catch (Exception e)
                    {
                        _logger.Warn(e, "Exception calling Stop() on AsyncCommandService.");
                    }

                    _commandChannelServer.Stop();
                    _batchCommandChannelServer.Stop();
                }
            }
            catch (Exception e)
            {
                _logger.Error(e, "Exception stopping RequestHandlerService.");
            }

            _logger.Info("RequestHandlerService stopped.");

            return Task.CompletedTask;
        }

        private readonly ICommandChannelServer _commandChannelServer;
        private readonly IBatchCommandChannelServer _batchCommandChannelServer;
        private readonly IAsyncCommandService _asyncCommandService;
        private readonly IAccountDataAccess _accountDataAccess;
        private static readonly Logger _logger = LogManager.GetCurrentClassLogger();
    }
}
