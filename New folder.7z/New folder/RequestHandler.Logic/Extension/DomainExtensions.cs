﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment.Exceptions;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers.Exceptions;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.Shared.Common.Configuration;
using Gd.Bos.Shared.Common.Core.Logic;
using NLog;
using BusinessAddress = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.BusinessAddress;
using ContractAddress = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Address;
using ContractEmail = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Email;
using ContractPhoneNumber = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PhoneNumber;
using DomainAddress = Gd.Bos.RequestHandler.Core.Domain.Model.User.Address;
using DomainEmail = Gd.Bos.RequestHandler.Core.Domain.Model.User.Email;
using DomainKycStateData = Gd.Bos.RequestHandler.Core.Domain.Model.Account.KycStateData;
using DomainPhoneNumber = Gd.Bos.RequestHandler.Core.Domain.Model.User.PhoneNumber;
using DomainTermAcceptance = Gd.Bos.RequestHandler.Core.Domain.Model.Account.TermAcceptance;
using KycStateData = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData;
using DomainBusinessAddress = Gd.Bos.RequestHandler.Core.Domain.Model.Business.BusinessAddress;
using DomainBusinessAccount = Gd.Bos.RequestHandler.Core.Domain.Model.Business.BusinessAccount;
using Gd.Bos.RequestHandler.Logic.Exceptions;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.DeviceProvisioning;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.GFTCustomers;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.LoanManagement;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.DeviceProvisioning;
using RequestHandler.Core.Application.Exception;
using CareCaseException = RequestHandler.Core.Infrastructure.CareCaseException;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.GFTCustomers;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.LoanManagement;
using RequestHandler.Core.Infrastructure;
using System.Net;
using System.IO;
using System.Text.RegularExpressions;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using RequestHandler.Core.Utils;
using BusinessType = Gd.Bos.RequestHandler.Core.Domain.Model.Business.BusinessType;
using VerificationStatus = Gd.Bos.RequestHandler.Core.Domain.Model.Account.VerificationStatus;

namespace Gd.Bos.RequestHandler.Logic.Extension
{
    public static class DomainExtensions
    {
        private static readonly Logger _logger = LogManager.GetCurrentClassLogger();
        private static readonly string _termIdentifierForMinors = "addConsent";

        public static List<DomainAddress> ToDomain(this List<ContractAddress> input)
        {
            List<DomainAddress> returnValue = new List<DomainAddress>();

            foreach (ContractAddress currAddress in input)
            {
                var newAddress = new DomainAddress();

                newAddress.State = currAddress.State;
                newAddress.AddressLine1 = currAddress.AddressLine1;
                newAddress.AddressLine2 = currAddress.AddressLine2;
                newAddress.City = currAddress.City;
                newAddress.Type = currAddress.Type;
                newAddress.ZipCode = currAddress.ZipCode;
                newAddress.IsDefault = currAddress.IsDefault;
                newAddress.IsVerified = currAddress.IsVerified;

                returnValue.Add(newAddress);
            }

            return returnValue;
        }

        public static DomainBusinessAddress ToDomain(this BusinessAddress input)
        {
            DomainBusinessAddress newAddress = new DomainBusinessAddress();

            newAddress.BusinessState = input.BusinessState;
            newAddress.BusinessAddressLine1 = input.BusinessAddressLine1;
            newAddress.BusinessAddressLine2 = input.BusinessAddressLine2;
            newAddress.BusinessCity = input.BusinessCity;
            newAddress.BusinessZipCode = input.BusinessZipCode;
            newAddress.BusinessCountryCode = input.BusinessCountryCode;

            return newAddress;
        }

        public static DomainBusinessAccount ToDomain(this BusinessData input)
        {
            DomainBusinessAccount businessAccount = new DomainBusinessAccount
            {
                BusinessName = input.BusinessName,
                BusinessLegalName = input.BusinessLegalName,
                BusinessEmbossedName = input.BusinessEmbossedName,
                BusinessType = (BusinessType)input.BusinessType,
                BusinessIndustry = input.BusinessIndustry,
                BusinessEmailAddress = input.BusinessEmailAddress,
                BusinessTaxID = input.BusinessTaxID,
                Url = input.URL,
                AvgMonthlyProcessingVolume = input.AvgMonthlyProcessingVolume,
                BusinessPhoneNumber = input.BusinessPhoneNumber,
            };
            return businessAccount;
        }

        public static DomainKycStateData ToDomain(this KycStateData input)
        {
            var newkycData = new DomainKycStateData();
            newkycData.KycPendingGate = input.PendingKycGate;
            if (input.KycStatus == "pending")
            {
                newkycData.KycStatus = VerificationStatus.pending;
            }

            return newkycData;
        }

        public static UserIdentifyingData ToDomain(this IdentifyingData input)
        {
            return new UserIdentifyingData(input.DateOfBirth, input.SsnSuffix, input.Ssn, input.OnBoardingId);
        }

        public static UserIdentifyingData ToDomain(this IdentifyingData input, bool acceptMinors)
        {
            return new UserIdentifyingData(input.DateOfBirth, input.SsnSuffix, input.Ssn, input.OnBoardingId,
                 acceptMinors)
            {
                IdentityType = input.IdentityType,
                IdentityValue = input.IdentityValue,
                IdentityExpirationDate = input.IdentityExpirationDate,
                IdentityCountryCode = input.IdentityCountryCode,
                Occupation = input.Occupation,
                SourceFunds = input.SourceFunds
            }; 
        }

        public static UserIdentifyingData ToDomain(this IdentifyingData input, bool acceptMinors, bool isForeignId)
        {

            if (isForeignId)
                return new UserIdentifyingData(input.DateOfBirth, input.SsnSuffix, input.Ssn, input.OnBoardingId,
                        input.IdentityType, input.IdentityValue, input.IdentityExpirationDate, input.IdentityCountryCode);
            else
                return new UserIdentifyingData(input.DateOfBirth, input.SsnSuffix, input.Ssn, input.OnBoardingId,
                acceptMinors);
        }

        public static List<DomainPhoneNumber> ToDomain(this List<ContractPhoneNumber> input)
        {
            List<DomainPhoneNumber> returnValue = new List<DomainPhoneNumber>();

            foreach (ContractPhoneNumber currPhoneNumber in input)
            {
                var newPhoneNumber = new DomainPhoneNumber
                {
                    Type = currPhoneNumber.Type,
                    IsDefault = currPhoneNumber.IsDefault,
                    IsVerified = currPhoneNumber.IsVerified,
                    Number = currPhoneNumber.Number
                };

                returnValue.Add(newPhoneNumber);
            }

            return returnValue;
        }

        public static DomainEmail ToDomain(this ContractEmail input)
        {
            return new DomainEmail(input.EmailAddress, input.IsVerified, input.IsDefault);
        }

        public static List<DomainTermsAcceptance> ToDomain(this List<TermsAcceptance> contract,
            List<Bos.Shared.Common.Core.Common.Data.Agreement> agreementsPerProduct)
        {
            var lst = new List<DomainTermsAcceptance>();

            foreach (var ta in contract)
            {
                var domainModel = new DomainTermsAcceptance(agreementsPerProduct,
                    ta.TermsIdentifier, ta.TermsAcceptanceDateTime, ta.TermsAcceptanceFlag);
                if (domainModel.ProductAgreementTypeKey != 0)
                {
                    lst.Add(domainModel);
                }
            }

            return lst;
        }

        public static IdentityType GetIdentityTypeBySsn(string ssn)
        {
            return string.IsNullOrEmpty(ssn) ? IdentityType.SSN : (ssn[0] == '9' ? IdentityType.ITIN : IdentityType.SSN);
        }
        public static bool CheckExistAgreementForMinorEnroll(
            this List<Bos.Shared.Common.Core.Common.Data.Agreement> agreementsPerProduct)
        {
            if (agreementsPerProduct == null)
            {
                return false;
            }

            return agreementsPerProduct.Exists(agreement =>
                agreement.BrandAgreementTypeIdentifier == _termIdentifierForMinors);
        }

        public static bool CheckExistAgreementForMinorEnroll(this List<TermsAcceptance> contract)
        {
            if (contract == null)
            {
                return false;
            }

            var agreementObj =
                contract.FirstOrDefault(agreement => agreement.TermsIdentifier == _termIdentifierForMinors);
            return agreementObj != null && agreementObj.TermsAcceptanceFlag;
        }

        public static ResponseHeader GetResponseHeader(this ResponseHeader responseHeader, string errorCode,
            Guid requestId)
        {
            switch (errorCode)
            {
                case "110":
                    responseHeader = new ResponseHeader
                    {
                        ResponseId = requestId,
                        StatusCode = 1,
                        SubStatusCode = 10,
                        Message = "KYC Cure required."
                    };
                    break;
                case "211":
                    responseHeader = new ResponseHeader
                    {
                        ResponseId = requestId,
                        StatusCode = 2,
                        SubStatusCode = 11,
                        Message = "KYC Failed. No cure available."
                    };
                    break;
                case "212":
                    responseHeader = new ResponseHeader
                    {
                        ResponseId = requestId,
                        StatusCode = 2,
                        SubStatusCode = 12,
                        Message = "Customer Has SSN"
                    };
                    break;
                case "231":
                    responseHeader = new ResponseHeader
                    {
                        ResponseId = requestId,
                        StatusCode = 2,
                        SubStatusCode = 31,
                        Message = "OFAC Match."

                    };
                    break;
                case "134":
                    responseHeader = new ResponseHeader
                    {
                        ResponseId = requestId,
                        StatusCode = 1,
                        SubStatusCode = 34,
                        Message = "KYC and OFAC Failed. KYC is curable."
                    };
                    break;
                case "233":
                    responseHeader = new ResponseHeader
                    {
                        ResponseId = requestId,
                        StatusCode = 2,
                        SubStatusCode = 33,
                        Message = "KYC and OFAC Failed. No cure available.",

                    };
                    break;
                case "236":
                    responseHeader = new ResponseHeader
                    {
                        ResponseId = requestId,
                        StatusCode = 2,
                        SubStatusCode = 36,
                        Message = "KYC and OFAC Failed. OFAC with manual cure.",

                    };
                    break;
                case "240":
                    responseHeader = new ResponseHeader
                    {
                        ResponseId = requestId,
                        StatusCode = 2,
                        SubStatusCode = 40,
                        Message = "User must be at least 18 years of age."
                    };
                    break;
                case "230":
                    responseHeader = new ResponseHeader
                    {
                        ResponseId = requestId,
                        StatusCode = 2,
                        SubStatusCode = 30,
                        Message = "Address used for KYC must be a valid U.S. address."
                    };
                    break;
                case "135":
                    responseHeader = new ResponseHeader
                    {
                        ResponseId = requestId,
                        StatusCode = 1,
                        SubStatusCode = 35,
                        Message = "KYC Failed due to Invalid email. KYC Failure is Curable."
                    };
                    break;
                case "180":
                    responseHeader = new ResponseHeader
                    {
                        ResponseId = requestId,
                        StatusCode = 1,
                        SubStatusCode = 80,
                        Message =
                            "Partial failure during enrollment. Use POST Enrollments (with same RequestId) or POST PaymentInstruments to complete."
                    };
                    break;
                case "260":
                    responseHeader = new ResponseHeader
                    {
                        ResponseId = requestId,
                        StatusCode = 2,
                        SubStatusCode = 60,
                        Message = "Number of Active Accounts Exceeded."
                    };
                    break;
                case "261":
                    responseHeader = new ResponseHeader
                    {
                        ResponseId = requestId,
                        StatusCode = 2,
                        SubStatusCode = 61,
                        Message = "Number of Activated Accounts over Lifetime exceeded."
                    };
                    break;
                case "263":
                    responseHeader = new ResponseHeader
                    {
                        ResponseId = requestId,
                        StatusCode = 2,
                        SubStatusCode = 63,
                        Message = "Number of Active Accounts Exceeded."
                    };
                    break;
                case "264":
                    responseHeader = new ResponseHeader
                    {
                        ResponseId = requestId,
                        StatusCode = 2,
                        SubStatusCode = 64,
                        Message = "The Account Holder limit has been reached."
                    };
                    break;
                case "267":
                    responseHeader = new ResponseHeader
                    {
                        ResponseId = requestId,
                        StatusCode = 2,
                        SubStatusCode = 67,
                        Message = "7 day opened account limit exceeded."
                    };
                    break;
                case "268":
                    responseHeader = new ResponseHeader
                    {
                        ResponseId = requestId,
                        StatusCode = 2,
                        SubStatusCode = 68,
                        Message = "30 day opened account limit exceeded."
                    };
                    break;

                case "225":
                    responseHeader = new ResponseHeader
                    {
                        ResponseId = requestId,
                        StatusCode = 2,
                        SubStatusCode = 25,
                        Message = "Maximum KYC attempts reached."
                    };
                    break;
                case "275":
                    responseHeader = new ResponseHeader
                    {
                        ResponseId = requestId,
                        StatusCode = 2,
                        SubStatusCode = 75,
                        Message = "Converted to NPNR due to contact verification skipped or failed."
                    };
                    break;
                default:
                    responseHeader = new ResponseHeader()
                    {
                        ResponseId = requestId,
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success"
                    };
                    break;
            }

            return responseHeader;

        }

        [ExcludeFromCodeCoverage(Justification = "Clean up logs GBOS-133556")]
        public static (bool, string) TryMatchServiceName(string responseBody)
        {
            var regexFinancialData = new Regex(@"https://[^/]*gss[^/]*/(?<serviceName>FinancialData[^/]*)", RegexOptions.IgnoreCase);

            if (regexFinancialData.IsMatch(responseBody))
            {
                var serviceName = regexFinancialData.Match(responseBody).Groups["serviceName"].Value;
                return (true, serviceName);
            }

            return (false, string.Empty);
        }

        [ExcludeFromCodeCoverage(Justification = "Clean up logs GBOS-133556")]
        public static TResponse HandleException<TResponse>(this Exception ex, Exception e, BaseRequest request)
            where TResponse : BaseResponse, new()
        {
            var response = new TResponse();

            switch (response)
            {
                //case GetActivationMethodsResponse getActivationMethodsResponse:
                //    getActivationMethodsResponse.TokenId = (request as GetActivationMethodsRequest)?.TokenId;
                //    break;
                //case CreateCustomerProfileGlobalFundTransferResponse createCustomerProfileGlobalFundTransferResponse:
                //    createCustomerProfileGlobalFundTransferResponse.CustomerToken =
                //        (request as CreateCustomerProfileGlobalFundTransferRequest)?.CustomerToken;
                //    break;
                //case CreateTransactionResponse createTransactionResponse:
                //    createTransactionResponse.TransactionId = (request as CreateTransactionRequest)?.TransactionId;
                //    break;
                //case UpdateLoanManagementAccountResponse updateLoanManagementAccountResponse:
                //    updateLoanManagementAccountResponse.LoanManagementAccountID =
                //        (request as UpdateLoanManagementAccountRequest)?.LoanManagementAccountID;
                //    break;
                //case ActivateCardResponse activateCardResponse:
                //    activateCardResponse.PaymentIntrumentIdentifier =
                //        (request as ActivateCardRequest)?.PaymentInstrumentIdentifier;
                //    break;
                //case AddAccountHolderResponse addAccountHolderResponse:
                //    addAccountHolderResponse.AccountIdentifier =
                //        (request as AddAccountHolderRequest)?.AccountIdentifier;
                //    break;
                case AdjustAccountBalanceResponse adjustAccountBalanceResponse:
                    adjustAccountBalanceResponse.AdjustmentIdentifier =
                        (request as AdjustAccountBalanceRequest)?.AdjustmentIdentifier ?? default;
                    break;
                //case AdjustBalanceResponse adjustBalanceResponse:
                //    adjustBalanceResponse.TransferIdentifier = (request as AdjustBalanceRequest)?.TransferIdentifier;
                //    break;
                //case BillPayGetPayeeResponse billPayGetPayeeResponse:
                //    billPayGetPayeeResponse.BillPayPayeeIdentifier =
                //        (request as BillPayGetPayeeRequest)?.PayeeIdentifier;
                //    break;
                //case CalculatePointsResponse calculatePointsResponse:
                //    calculatePointsResponse.AccountIdentifier =
                //        (request as CalculatePointsRequest)?.AccountIdentifier ?? default;
                //    calculatePointsResponse.UserIdentifier =
                //        (request as CalculatePointsRequest)?.UserIdentifier ?? default;
                //    break;
                //case CblVelocityCheckResponse cblVelocityCheckResponse:
                //    cblVelocityCheckResponse.AccountIdentifier =
                //        (request as CblVelocityCheckRequest)?.AccountIdentifier;
                //    break;
                //case EnrollFundingResponse enrollFundingResponse:
                //    enrollFundingResponse.AccountIdentifier = (request as EnrollFundingRequest)?.AccountIdentifier;
                //    break;
                case GetAdjustAccountBalanceStatusResponse getAdjustAccountBalanceStatusResponse:
                    getAdjustAccountBalanceStatusResponse.AdjustmentIdentifier =
                        (Guid.TryParse((request as GetAdjustAccountBalanceStatusRequest)?.AdjustmentIdentifier,
                            out var adiGuid))
                            ? adiGuid
                            : default;
                    break;
                    //case GetHistoricTransactionsResponse getHistoricTransactionsResponse:
                    //    getHistoricTransactionsResponse.AccountIdentifier =
                    //        (request as GetHistoricTransactionsRequest)?.AccountIdentifier.ToString("D");
                    //    break;
                    //case InstantEnrollResponse instantEnrollResponse:
                    //    instantEnrollResponse.CardExternalId = (request as InstantEnrollRequest)?.CardExternalId;
                    //    break;
                    //case LinkAccountResponse linkAccountResponse:
                    //    linkAccountResponse.PrimaryAccountIdentifier =
                    //        (request as LinkAccountRequest)?.PrimaryAccountIdentifier;
                    //    linkAccountResponse.LinkAccountIdentifier = (request as LinkAccountRequest)?.LinkAccountIdentifier;
                    //    break;
                    //case PrePrintedEnrollmentResponse prePrintedEnrollmentResponse:
                    //    prePrintedEnrollmentResponse.ExternalId = (request as PrePrintedEnrollmentRequest)?.ExternalId;
                    //    break;
                    //case RetailAccountVerificationResponse retailAccountVerificationResponse:
                    //    retailAccountVerificationResponse.AccountIdentifier =
                    //        (request as RetailAccountVerificationRequest)?.AccountIdentifier;
                    //    break;
                    //case ReversalPointsRedemptionResponse reversalPointsRedemptionResponse:
                    //    reversalPointsRedemptionResponse.TransactionIdentifier =
                    //        (request as ReversalPointsRedemptionRequest)?.TransactionIdentifier ?? default;
                    //    break;
                    //case TransferResponse transferResponse:
                    //    transferResponse.TransferIdentifier = (request as TransferRequest)?.TransferIdentifier;
                    //    break;
                    //case UpdateMrdcX9CheckResponse updateMrdcX9CheckResponse:
                    //    updateMrdcX9CheckResponse.TransferIdentifier =
                    //        (request as UpdateMrdcX9CheckRequest)?.TransferIdentifier;
                    //    break;
                    //case UpdateTokenResponse updateTokenResponse:
                    //    updateTokenResponse.AccountIdentifier = (request as UpdateTokenRequest)?.AccountIdentifier;
                    //    break;
                    //case ValidateCardActivationResponse validateCardActivationResponse:
                    //    validateCardActivationResponse.AccountIdentifier =
                    //        (Guid.TryParse((request as ValidateCardActivationRequest)?.AccountIdentifier, out var accGuid))
                    //            ? accGuid
                    //            : default;
                    //    validateCardActivationResponse.PaymentInstrumentIdentifier =
                    //        (Guid.TryParse((request as ValidateCardActivationRequest)?.PaymentInstrumentIdentifier,
                    //            out var piGuid))
                    //            ? piGuid
                    //            : default;
                    //    break;
                    //case ValidateCvvResponse validateCvvResponse:
                    //    validateCvvResponse.AccountIdentifier = (request as ValidateCvvRequest)?.AccountIdentifier;
                    //    validateCvvResponse.PaymentInstrumentIdentifier =
                    //        (request as ValidateCvvRequest)?.PaymentInstrumentIdentifier;
                    //    break;
                    //case WireOutResponse wireOutResponse:
                    //    wireOutResponse.WireIdentifier = (request as WireOutRequest)?.WireIdentifier;
                    //    break;

            }

            var exMessageUpper = ex.Message.ToUpperInvariant();

            if (exMessageUpper.Contains("Cannot adjust available balance to be negative".ToUpperInvariant()))
            {
                response.ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 3,
                    SubStatusCode = 103,
                    Message = "Cannot adjust account balance to be negative.",
                    Details = e.ToString()
                };
            }
            else if (exMessageUpper.Contains("No rows returned for AccountID".ToUpperInvariant()))
            {
                response.ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 10,
                    SubStatusCode = 0,
                    Message = "AccountIdentifier is invalid or account does not exist.",
                    Details = e.ToString()
                };
            }
            else if (exMessageUpper.Contains("CVV must be a 3-digit number.".ToUpperInvariant()))
            {
                response.ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 4,
                    SubStatusCode = 302,    // CVV must be 3 digit
                    Message = "Identification Failed.",
                    Details = $"CVV must be 3 digit.  {e.ToString()}"
                };
            }
            else
            {
                switch (e)
                {
                    case ValidationException validationException:
                        _logger.Warn("ValidationException " + e.Message);
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = validationException.Code == 0 ? 700 : validationException.Code,
                            SubStatusCode = validationException.SubCode,
                            Message = validationException.Message,
                            Details = $"{validationException.Details} {validationException.ToString()}"
                        };
                        break;
                    case Core.Domain.Model.Transfers.Exceptions.AccountNotFoundException _:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 10,
                            SubStatusCode = 0,
                            Message = "Account Not Found.",
                            Details = e.ToString()
                        };
                        break;
                    case WebException webEx when webEx.Status == WebExceptionStatus.ProtocolError:
                        var httpResponse = (HttpWebResponse)webEx.Response;
                        if (httpResponse != null && httpResponse.StatusCode == HttpStatusCode.NotFound)
                        {
                            string responseBody;
                            using (var reader = new StreamReader(httpResponse.GetResponseStream()))
                            {
                                responseBody = reader.ReadToEnd();
                            }

                            var (isMatch, serviceName) = TryMatchServiceName(responseBody);

                            if (isMatch)
                            {
                                _logger.Warn($"Resource not found (404) for service '{serviceName}'. RequestId: {request.RequestHeader.RequestId}. Error: {ex.Message}");
                                response.ResponseHeader = new ResponseHeader
                                {
                                    ResponseId = request.RequestHeader.RequestId,
                                    StatusCode = (int)HttpStatusCode.NotFound,
                                    SubStatusCode = 0,
                                    Message = $"The requested resource '{serviceName}' was not found (404)."
                                };
                            }
                            else
                            {
                                _logger.Error(webEx);
                                response.ResponseHeader = new ResponseHeader
                                {
                                    ResponseId = request.RequestHeader.RequestId,
                                    StatusCode = (int)webEx.Status,
                                    SubStatusCode = 0,
                                    Message = $"Failed, a protocol error occurred."
                                };
                            }
                        }
                        else if (httpResponse != null && httpResponse.StatusCode == HttpStatusCode.BadRequest)
                        {
                            // Handle 400 Bad Request
                            _logger.Warn(e.Message);
                            response.ResponseHeader = new ResponseHeader
                            {
                                ResponseId = request.RequestHeader.RequestId,
                                StatusCode = 503,
                                SubStatusCode = 0,
                                Message = "Fail",
                                Details = e.ToString()
                            };
                        }
                        else
                        {
                            // Handle other WebExceptions with ProtocolError status
                            _logger.Error(webEx);
                            response.ResponseHeader = new ResponseHeader
                            {
                                ResponseId = request.RequestHeader.RequestId,
                                StatusCode = (int)webEx.Status,
                                SubStatusCode = 0,
                                Message = $"A protocol error occurred."
                            };
                        }
                        break;
                    case PurseNotFoundException _:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 10,
                            SubStatusCode = 0,
                            Message = "Purse Not Found.",
                            Details = e.ToString()
                        };
                        break;
                    case PaymentInstrumentNotFoundException _:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 10,
                            SubStatusCode = 0,
                            Message = "PaymentInstrumentIdentifier is invalid or not found",
                            Details = e.ToString()
                        };
                        break;
                    case TransferValidationException transferValidationException:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = transferValidationException.Code,
                            SubStatusCode = transferValidationException.SubCode,
                            Message = transferValidationException.Message,
                            Details = e.ToString()
                        };
                        break;
                    case TransferAccountStateException transferAccountStateException:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = transferAccountStateException.Code,
                            SubStatusCode = transferAccountStateException.SubCode,
                            Message = transferAccountStateException.Message,
                            Details = e.ToString()
                        };
                        break;
                    case AccountHolderNotFoundException _:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 10,
                            SubStatusCode = 0,
                            Message = "Account Holder not found.",
                            Details = e.ToString()
                        };
                        break;
                    case InvalidKycGateException _:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 1,
                            SubStatusCode = 12,
                            Message = "kycGate does not match pendingKycGate.",
                            Details = e.ToString()
                        };
                        break;
                    case InvalidDocumentType _:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 200,
                            SubStatusCode = 0,
                            Message = "Invalid document type",
                            Details = e.ToString()
                        };
                        break;
                    case MissingIDVImageException _:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 200,
                            SubStatusCode = 0,
                            Message = e.Message
                        };
                        break;
                    case PaymentInstrumentValidationException piValidationException:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = piValidationException.Code,
                            SubStatusCode = piValidationException.SubCode,
                            Message = piValidationException.Message,
                            Details = $"{piValidationException.Reason} {piValidationException.ToString()}"
                        };
                        break;
                    case RequestHandlerException validation:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = validation.Code,
                            SubStatusCode = validation.SubCode,
                            Message = validation.Message,
                            Details = e.ToString()
                        };
                        break;
                    case InvalidTransferTypeException _:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 600,
                            SubStatusCode = 0,
                            Message = e.Message,
                            Details = e.ToString()
                        };
                        break;
                    case InvalidCallBackTypeException _:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 600,
                            SubStatusCode = 0,
                            Message = e.Message,
                            Details = e.ToString()
                        };
                        break;
                    case InvalidReturnTypeException _:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 600,
                            SubStatusCode = 0,
                            Message = e.Message,
                            Details = e.ToString()
                        };
                        break;
                    case InvalidInitiatorException _:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 3,
                            SubStatusCode = 111,
                            Message = e.Message,
                            Details = e.ToString()
                        };
                        break;
                    case InvalidFundingAccountException _:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 3,
                            SubStatusCode = 109,
                            Message = e.Message,
                            Details = e.ToString()
                        };
                        break;
                    case InvalidTransferRouteException _:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 3,
                            SubStatusCode = 200,
                            Message = e.Message,
                            Details = e.ToString()
                        };
                        break;
                    case AccountValidationException avException:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = avException.Code,
                            SubStatusCode = avException.SubCode,
                            Message = avException.Message,
                            Details = e.ToString()
                        };
                        break;
                    case AlreadyActivePaymentInstrumentException alreadyActiveEx:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = alreadyActiveEx.Code,
                            SubStatusCode = alreadyActiveEx.SubCode,
                            Message = alreadyActiveEx.Message,
                            Details = e.ToString()
                        };
                        break;
                    case TransferFraudException _:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 3,
                            SubStatusCode = 110,
                            Message = e.Message,
                            Details = e.ToString()
                        };
                        break;
                    case TransferPrerequisitesException _:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 3,
                            SubStatusCode = 131,
                            Message = e.Message,
                            Details = e.ToString()
                        };
                        break;
                    case TransferReversalFailedException _:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 14200,
                            SubStatusCode = 0,
                            Message = e.Message,
                            Details = e.ToString()
                        };
                        break;
                    case DcppException dcppEx:
                        if (dcppEx.Code == 500 && dcppEx.SubCode == 2636)
                        {
                            response.ResponseHeader = new ResponseHeader
                            {
                                ResponseId = request.RequestHeader.RequestId,
                                StatusCode = dcppEx.Code,
                                SubStatusCode = dcppEx.SubCode,
                                Message = dcppEx.Message,
                                Details = e.ToString()
                            };
                        }
                        else
                        {
                            response.ResponseHeader = new ResponseHeader
                            {
                                ResponseId = request.RequestHeader.RequestId,
                                StatusCode = 5030,
                                SubStatusCode = 0,
                                Message = dcppEx.Message,
                                Details = e.ToString()
                            };
                        }

                        break;
                    case CpmException cpmEx:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = cpmEx.Code,
                            SubStatusCode = cpmEx.SubCode,
                            Message = cpmEx.Message,
                            Details = e.ToString()
                        };
                        break;
                    case TransferException transferEx:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = transferEx.IsPending ? 12 : transferEx.Code,
                            SubStatusCode = transferEx.SubCode,
                            Message = transferEx.IsPending ? "Pending Retry" : transferEx.Message,
                            Details = e.ToString()
                        };
                        break;
                    case MrdcException mrdcEx:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = mrdcEx.Code,
                            SubStatusCode = mrdcEx.SubCode,
                            Message = mrdcEx.Message,
                            Details = e.ToString()
                        };
                        break;
                    case AtmLocationException atmException:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = atmException.Code,
                            SubStatusCode = atmException.SubCode,
                            Message = atmException.Message,
                            Details = e.ToString()
                        };
                        break;
                    case AchTransferException achException:
                        if (response.GetType() == typeof(TransferResponse) &&
                            (achException.Code == 3 && achException.SubCode == 231) ||
                            (achException.Code == 12 && achException.SubCode == 901))
                        {
                            response.Cast<TransferResponse>().PublicToken = achException.PublicToken;
                        }

                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = achException.Code,
                            SubStatusCode = achException.SubCode,
                            Message = achException.Message,
                            Details = e.ToString()
                        };
                        break;
                    case AchTransferTimeOutException achTimeoutException:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = achTimeoutException.Code,
                            SubStatusCode = achTimeoutException.SubCode,
                            Message = achTimeoutException.Message,
                            Details = e.ToString()
                        };
                        break;
                    case ContactVerificationException contactException:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = contactException.Code,
                            SubStatusCode = contactException.SubCode,
                            Message = contactException.Message,
                            Details = e.ToString()
                        };
                        break;
                    case IFTException iftEx:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = iftEx.Code,
                            SubStatusCode = iftEx.SubCode,
                            Message = iftEx.Message,
                            Details = e.ToString()
                        };
                        break;
                    case AddressValidationException addressEx:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = addressEx.Code,
                            SubStatusCode = addressEx.SubCode,
                            Message = addressEx.Message,
                            Details = e.ToString()
                        };
                        break;
                    case PhoneValidationException phoneEx:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = phoneEx.Code,
                            SubStatusCode = phoneEx.SubCode,
                            Message = phoneEx.Message,
                            Details = e.ToString()
                        };
                        break;
                    case VerifyIdentityTokenException identityTokenEx:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = identityTokenEx.Code,
                            SubStatusCode = identityTokenEx.SubCode,
                            Message = identityTokenEx.Message,
                            Details = e.ToString()
                        };
                        break;
                    case ConfigDataAccessException configException:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = configException.Code,
                            SubStatusCode = configException.SubCode,
                            Message = configException.Message,
                            Details = configException.Details
                        };
                        break;
                    case Shared.Common.Contract.Exceptions.BaseException baseException:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = baseException.Code,
                            SubStatusCode = baseException.SubCode,
                            Message = baseException.Message,
                            Details = string.IsNullOrEmpty(baseException.Details)
                                ? baseException.ToString()
                                : baseException.Details
                        };
                        break;
                    case LoanManagementException lmsEx:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = lmsEx.Code,
                            SubStatusCode = lmsEx.SubCode,
                            Message = lmsEx.Message,
                            Details = e.ToString()
                        };
                        break;
                    case LoanManagementRetryableException lmsEx:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = lmsEx.Code,
                            SubStatusCode = lmsEx.SubCode,
                            Message = lmsEx.Message,
                            Details = e.ToString()
                        };
                        break;
                    case RiskServiceNoResponseException riskServiceNoResponseException:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 503,
                            SubStatusCode = 503,
                            Message = riskServiceNoResponseException.Message,
                            Details = riskServiceNoResponseException.ToString()
                        };
                        break;
                    case SqlValidationException sqlValidationException:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = sqlValidationException.Code,
                            SubStatusCode = sqlValidationException.SubCode,
                            Message = sqlValidationException.Message,
                            Details = e.ToString()
                        };
                        break;
                    case CareCaseException careCaseException:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = careCaseException.Code,
                            SubStatusCode = careCaseException.SubCode,
                            Message = careCaseException.Message,
                            Details = e.ToString()
                        };
                        break;
                    case VerifyRiskException verifyRiskException:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = verifyRiskException.Status,
                            SubStatusCode = verifyRiskException.Substatus,
                            Message = verifyRiskException.Message,
                            Details = verifyRiskException.Details
                        };
                        break;
                    case FraudException fraudException:
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = fraudException.Code,
                            SubStatusCode = fraudException.SubCode,
                            Message = fraudException.Message,
                            Details = fraudException.ToString()
                        };
                        break;
                    case ArgumentNullException argNullException:
                        _logger.Warn(argNullException.Message);
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 503,
                            SubStatusCode = 0,
                            Message = "Fail",
                            Details = argNullException.ToString()
                        };
                        break;
                    default:
                        _logger.Error(e);
                        response.ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = 503,
                            SubStatusCode = 0,
                            Message = "Fail",
                            Details = e.ToString()
                        };
                        break;
                }
            }

            return response;
        }
    }
}
