﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Logic.DataAccess;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Account = Gd.Bos.RequestHandler.Core.Domain.Model.Account.Account;
using PaymentInstrument = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PaymentInstrument;
using PrivateCardData = Gd.Bos.RequestHandler.Core.Application.PrivateCardData;
using User = Gd.Bos.RequestHandler.Core.Domain.Model.User.User;
using System.Linq;

namespace Gd.Bos.RequestHandler.Logic.Extension
{
    public class RetailEnrollmentExtensions
    {
        private readonly ILazyCache _lazyCache;
        private readonly IEnrollmentDataAccess _enrollmentDataAccess;

        public RetailEnrollmentExtensions(ILazyCache lazyCache, IEnrollmentDataAccess enrollmentDataAccess)
        {
            _lazyCache = lazyCache;
            _enrollmentDataAccess = enrollmentDataAccess;
        }

        public RetailCardEnrollmentResponse GenerateRetailCardEnrollmentResponse(BaseRequest request,
          Tuple<Account, User, PaymentIdentifier, AccountBalance, PrivateCardData> enrollResponse,
          NpNrReason npnrReason, Tuple<bool, ResponseHeader> termsResponse)
        {
            var newAccount = enrollResponse.Item1;
            var newUser = enrollResponse.Item2;
            var newPaymentIdentifier = enrollResponse.Item3;
            var newAccountBalance = enrollResponse.Item4;
            //var privateCardData = enrollResponse.Item5;
            var response = new RetailCardEnrollmentResponse();

            string errorCode = _lazyCache?.Value?.Get<string>(request.RequestHeader?.RequestId.ToString());
            if (!string.IsNullOrEmpty(errorCode) && errorCode != "0")
                response.ResponseHeader = response.ResponseHeader.GetResponseHeader(errorCode, request.RequestHeader.RequestId);
            else if (npnrReason == NpNrReason.TermNotAccepted)
                response.ResponseHeader = termsResponse.Item2;
            else
            {
                response.ResponseHeader =
                    response.ResponseHeader.GetResponseHeader(newAccount.ErrorCode.ToString(), request.RequestHeader.RequestId);
                _lazyCache?.Value?.Set(request.RequestHeader?.RequestId.ToString(), newAccount.ErrorCode.ToString(),
                    new TimeSpan(1, 0, 0, 0));
            }

            response.DirectDepositInformation = new DirectDepositInformation()
            {
                AccountNumber = newAccount.AccountNumber,
                RoutingNumber = newAccount.RoutingNumber,
            };

            response.AccountIdentifier = newAccount.AccountIdentifier.ToString();
            response.AccountReferenceNumber = newAccount.CustomerAccountNumber;
            response.Status = newAccount.AccountStatus.ToString().ToLower();
            response.StatusReasons = newAccount.AccountStatusReasons?.Select(x => x.ToString()).ToList();

            response.PaymentInstrumentIdentifier =
                newPaymentIdentifier?.PaymentInstrument.PaymentInstrumentIdentifier.ToString();

            var accountResp =
                _enrollmentDataAccess.GetEnrollmentByAccountIdentifier(newAccount.AccountIdentifier.ToString(),
                    request.ProgramCode, false);

            response.AccountCycleDay = accountResp.Account.AccountCycleDay;

            DateTime accountStatusDateChange = newAccount.AccountStatusChangedDateTime;
            accountStatusDateChange = accountStatusDateChange.ToUniversalTime();
            response.AccountStatusChangedDateTime =
                accountStatusDateChange.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");

            if (newAccountBalance != null)
            {
                response.Purses = new List<Purse>();
                var purse = new Purse
                {
                    PurseIdentifier = newAccountBalance.AccountBalanceIdentifier.ToString(),
                    PurseType = PurseType.Primary,
                    AvailableBalance = newAccountBalance.AvailableBalance,
                    LedgerBalance = newAccountBalance.CurrentBalance,
                    AvailableBalanceAsOfDateTime = newAccountBalance.AvailableBalanceAsOfDate,
                    LedgerBalanceAsOfDateTime = newAccountBalance.CurrentBalanceAsOfDate,
                    Status = newAccountBalance.Status
                };
                response.Purses.Add(purse);
            }

            response.AccountHolders = new List<Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.AccountHolder>();
            var accountHolder = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.AccountHolder();

            foreach (Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolder ah in newAccount.AccountHolders)
            {
                accountHolder.User = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.User
                {
                    UserIdentifier = newUser.UserIdentifier.ToString(),
                    Status = UserStatus.Active,
                    IsPrimaryAccountHolder = true,
                    KycStateData = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData
                    {
                        OfacStatus = ah.kycStateData.OfacStatus.ToString().ToLower(),
                        KycStatus = ah.kycStateData.KycStatus.ToString().ToLower(),
                        PendingKycGate = ah.kycStateData.KycPendingGate?.ToLower()
                    }
                };


                if (newPaymentIdentifier != null)
                {
                    accountHolder.PaymentInstruments = new List<PaymentInstrument>();
                    var paymentInstrument = new PaymentInstrument();
                    //PaymentInstrumentStatus paymentInstrumentStatus;
                    Enum.TryParse(newPaymentIdentifier.PaymentInstrument.Status,
                        out PaymentInstrumentStatus paymentInstrumentStatus);

                    paymentInstrument.PaymentIdentifier =
                        newPaymentIdentifier.PaymentIdentifierIdentifier.ToString();
                    paymentInstrument.PaymentInstrumentIdentifier = newPaymentIdentifier?.PaymentInstrument
                        .PaymentInstrumentIdentifier.ToString();
                    paymentInstrument.PaymentInstrumentType =
                        newPaymentIdentifier.PaymentInstrument.PaymentInstrumentType;
                    paymentInstrument.Status = paymentInstrumentStatus;
                    paymentInstrument.IsPinSet = newPaymentIdentifier.PaymentInstrument.PinSetDate.HasValue;
                    paymentInstrument.Last4Pan = newPaymentIdentifier?.PaymentInstrument.Last4Pan;
                    paymentInstrument.ActivatedDateTime = newPaymentIdentifier?.PaymentInstrument.ActivatedDateTime;
                    paymentInstrument.IssuedDateTime = newPaymentIdentifier?.PaymentInstrument.IssuedDateTime;

                    accountHolder.PaymentInstruments.Add(paymentInstrument);
                }

                response.AccountHolders.Add(accountHolder);
            }

            return response;
        }
    }
}
