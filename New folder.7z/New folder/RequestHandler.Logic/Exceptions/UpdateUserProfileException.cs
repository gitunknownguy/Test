﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Gd.Bos.RequestHandler.Logic.Exceptions
{
    public class UpdateUserProfileException : Exception
    {
        public UpdateUserProfileException() : base() { }

        public UpdateUserProfileException(string message) : base(message) { }

        public UpdateUserProfileException(string message, Exception innerException) : base(message, innerException) { }
    }
}