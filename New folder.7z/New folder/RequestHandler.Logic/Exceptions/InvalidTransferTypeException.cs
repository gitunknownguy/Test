﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gd.Bos.RequestHandler.Logic.Exceptions
{
    public class InvalidTransferTypeException : Exception
    {
        public InvalidTransferTypeException() : base() { }

        public InvalidTransferTypeException(string message) : base(message) { }

        public InvalidTransferTypeException(string message, Exception innerException) : base(message, innerException) { }
    }
}
