﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;

namespace Gd.Bos.RequestHandler.Logic.DataAccess
{
    public interface IAccountDataAccess
    {
        GetAccountResponse GetAccountByAccountIdentifier(string accountIdentifier, string programCode, bool includeCardData, bool details = false);
        Task<GetAccountResponse> GetAccountByAccountIdentifierAsync(string accountIdentifier, string programCode, bool includeCardData, CancellationToken token, bool details = false);
        GetPursesResponse GetPurses(string accountIdentifier, string programCode);
        long? GetAccountKey(string accountIdentifier, string programCode);
        int? GetAccountProductTierKey(string accountIdentifier, string programCode);
        Dictionary<Guid, decimal> GetEGiftCashBackTransactionAmounts(string accountIdentifier);
        DateTime? GetAccountTransaction(Guid transactionReferenceIdentifier);
        string GetAccountToken(string accountIdentifier);
    }
}
