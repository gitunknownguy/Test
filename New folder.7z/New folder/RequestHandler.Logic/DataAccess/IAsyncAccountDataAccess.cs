﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;

namespace RequestHandler.Logic.DataAccess
{
    public interface IAsyncAccountDataAccess
    {
        Task<GetAccountResponse> GetAccountByAccountIdentifier(string accountIdentifier, string programCode, bool includeCardData, bool details = false);
        GetPursesResponse GetPurses(string accountIdentifier, string programCode);
        long? GetAccountKey(string accountIdentifier, string programCode);
        Task<int?> GetAccountProductTierKey(string accountIdentifier, string programCode);
        Dictionary<Guid, decimal> GetEGiftCashBackTransactionAmounts(string accountIdentifier);
        DateTime? GetAccountTransaction(Guid transactionReferenceIdentifier);
        string GetAccountToken(string accountIdentifier);
    }
}
