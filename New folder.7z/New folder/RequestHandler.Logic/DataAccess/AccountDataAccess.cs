﻿using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System.Data;
using System.Linq;
using Gd.Bos.Shared.Common.Core.Logic.AdjustedBalance.Contract;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.EGift;
using Gd.Bos.RequestHandler.Core.Domain.Model.Interest;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.Shared.Common;
using Gd.Bos.Shared.Common.Core.Logic;
using Microsoft.Data.SqlClient.Server;
using TransferType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType;

using VerificationStatus = Gd.Bos.RequestHandler.Core.Domain.Model.Account.VerificationStatus;
using VerificationActivityType = Gd.Bos.RequestHandler.Core.Domain.Model.Account.VerificationActivityType;
using ContractKycStateData = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData;
using TriggerType = Gd.Bos.RequestHandler.Core.Domain.Model.Account.TriggerType;
using VerificationActivity = Gd.Bos.RequestHandler.Core.Domain.Model.Account.VerificationActivity;
using AccountHolderIdentifier = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolderIdentifier;
using System.Threading;
using System.Threading.Tasks;

namespace Gd.Bos.RequestHandler.Logic.DataAccess
{
    public class AccountDataAccess : IAccountDataAccess
    {
        private readonly IDataAccess _dataAccess;
        private readonly ITokenizerService _tokenizerService;
        private readonly IBalanceProvider _balanceProvider;

        private readonly int[] EGiftTransClassKeys = { 93, 95 };

        public AccountDataAccess(IDataAccess dataAccess, ITokenizerService tokenizerService, IBalanceProvider balanceProvider)
        {
            _dataAccess = dataAccess;
            _tokenizerService = tokenizerService;
            _balanceProvider = balanceProvider;
        }

        /// <summary>
        /// GetAccountByAccountIdentifier
        /// </summary>
        /// <param name="accountIdentifier"></param>
        /// <param name="programCode"></param>
        /// <param name="includeCardData"></param>
        /// <returns></returns>
        public GetAccountResponse GetAccountByAccountIdentifier(string accountIdentifier, string programCode, bool includeCardData, bool includeDetails = false)
        {
            GetAccountResponse getAccountResponse = null;
            SqlParameter[] parameters = null;
            string pan = null;

            try
            {
                parameters = new[]
                {
                new SqlParameter() { ParameterName = "AccountIdentifier",Value = Guid.Parse(accountIdentifier) },
                new SqlParameter() { ParameterName = "ProgramCode",Value = programCode}
            };
            }// Try/Catch added to validate the accountidentifier (GUID) and catch the exception upfront before sending to database
            catch (Exception ex) { throw new AccountNotFoundException(); }

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccount]", _dataAccess.CreateConnectionWithColumnEncryption(), parameters))
            {
                if (reader.Read())
                {
                    getAccountResponse = new GetAccountResponse();
                    getAccountResponse.Account = new Account();
                    getAccountResponse.Account.AccountHolders = new List<AccountHolder>();
                    getAccountResponse.Account.AccountIdentifier = reader["AccountIdentifier"].ToString();
                    getAccountResponse.Account.Status = ((AccountStatus)(short)reader["AccountStatusKey"]).ToString().ToLower();

                    DateTime accountStatusDateChange = reader.GetDateTime(reader.GetOrdinal("StatusChangeDate"));
                    accountStatusDateChange = accountStatusDateChange.ToUniversalTime();
                    getAccountResponse.Account.AccountStatusChangedDateTime =
                        accountStatusDateChange.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");

                    getAccountResponse.Account.ProductCode = reader["ProductCode"].ToString();
                    var accountProductKey = Convert.ToInt32(reader["ProductKey"]);
                    int.TryParse(reader["ProductTierKey"]?.ToString(), out int productTierKey);                   
                    getAccountResponse.Account.ProductTierKey = productTierKey;
                    getAccountResponse.Account.ProductName = reader["ProductName"].ToString();
                    getAccountResponse.Account.DirectDepositInformation = new DirectDepositInformation();
                    getAccountResponse.Account.DirectDepositInformation.AccountNumber = reader["AccountNumber"].ToString();
                    getAccountResponse.Account.DirectDepositInformation.RoutingNumber = reader["RoutingNumber"].ToString();
                    getAccountResponse.Account.CustomerReferenceNumber = reader["AccountReferenceNumber"].ToString();
                    getAccountResponse.Account.ActivationDate = reader["ActivationDate"] == DBNull.Value ? null
                        : reader.GetDateTime(reader.GetOrdinal("ActivationDate")).ToString("yyyy-MM-ddTHH:mm:ss.fff");
                    getAccountResponse.Account.AccountCycleDay = reader["BillCycleDay"] == DBNull.Value ? (short)0 : (short)reader["BillCycleDay"];
                    getAccountResponse.Account.SystemKey = reader["SystemKey"] == DBNull.Value ? null : (short)reader["SystemKey"];
                    reader.NextResult();
                    if (reader.Read())
                    {
                        getAccountResponse.Account.Currency = reader["CurrencyKey"] == DBNull.Value ? null : ((CurrencyType)(short)reader["CurrencyKey"]).ToString();
                    }

                    reader.NextResult();

                    getAccountResponse.Account.AccountHolders = new List<AccountHolder>();
                    Dictionary<long, string> ahKeyIdentifier = new Dictionary<long, string>();
                    while (reader.Read())
                    {
                        if (Convert.ToInt32(reader["ConsumerProfileTypeKey"]) == 1 || programCode.Equals("credibly", StringComparison.OrdinalIgnoreCase))
                        {
                            User user = new User();
                            var accountHolderKey = Convert.ToInt64(reader["AccountHolderKey"]);
                            user.UserIdentifier = reader["ConsumerProfileIdentifier"].ToString();
                            bool isTransferAutoAccept = reader["IsTransferAutoAccept"] != DBNull.Value && bool.Parse(reader["IsTransferAutoAccept"].ToString());
                            user.PeerTransferAcceptPreference = isTransferAutoAccept == false ? "manual" : "automatic";
                            user.ConsumerProfileKey = reader.GetInt64(reader.GetOrdinal("ConsumerProfileKey"));
                            user.FirstName = reader["FirstName"] == DBNull.Value
                                ? string.Empty
                                : reader["FirstName"].ToString();
                            user.LastName = reader["LastName"] == DBNull.Value
                                ? string.Empty
                                : reader["LastName"].ToString();
                            bool isVerified = reader["IsDOBVerified"] == DBNull.Value
                                ? false
                                : Convert.ToBoolean(reader["IsDOBVerified"]);
                            bool isDOBBMatched = reader["IsDOBMatched"] == DBNull.Value
                                ? false
                                : Convert.ToBoolean(reader["IsDOBMatched"]);
                            if (isVerified)
                                user.DobStatus = "verified";
                            else
                                user.DobStatus = isDOBBMatched ? "matched" : "notMatched";
                            user.Status = UserStatus.Active;
                            user.IsPrimaryAccountHolder = reader["IsPrimaryAccountHolder"] != DBNull.Value &&
                                                          (bool)reader["IsPrimaryAccountHolder"];
                            user.KycStateData = new KycStateData
                            {
                                OfacStatus = "pending",
                                KycStatus = "pending",
                                PendingKycGate = reader["AccountHolderCureKey"] == DBNull.Value
                                    ? "kyc2"
                                    : ((Core.Domain.Model.Account.AccountHolderCure)(short)reader[
                                        "AccountHolderCureKey"]).ToString().ToLower()
                            };

                            AccountHolder accountHolder = new AccountHolder
                            {
                                User = user,
                                AccountHolderIdentifier = reader["AccountHolderIdentifier"].ToString()
                            };
                            accountHolder.PaymentInstruments = new List<PaymentInstrument>();
                            ahKeyIdentifier.Add(accountHolderKey, accountHolder.AccountHolderIdentifier);
                            getAccountResponse.Account.AccountHolders.Add(accountHolder);
                        }
                    }

                    reader.NextResult();

                    while (reader.Read())
                    {
                        var currentKey = Convert.ToInt64(reader["AccountHolderKey"]);
                        if (ahKeyIdentifier.TryGetValue(currentKey, out string currentAHIdentifier))
                        {
                            var currentAccountHolder = getAccountResponse.Account.AccountHolders.Find(ah =>
                                string.Equals(currentAHIdentifier, ah.AccountHolderIdentifier,
                                    StringComparison.InvariantCultureIgnoreCase));

                            if (reader["PaymentInstrumentIdentifier"] != DBNull.Value)
                            {
                                PaymentInstrument paymentInstrument = new PaymentInstrument
                                {
                                    PaymentInstrumentIdentifier = reader["PaymentInstrumentIdentifier"].ToString(),
                                    PaymentIdentifier = reader["PaymentIdentifier"].ToString(),
                                    PaymentInstrumentType =
                                        (PaymentInstrumentType)(short)reader["PaymentInstrumentTypeKey"],
                                    Status = (PaymentInstrumentStatus)(short)reader["PaymentInstrumentStatusKey"],
                                    IsPinSet = reader["ATMPinSetDate"] != DBNull.Value,
                                    Last4Pan = reader["Last4PAN"].ToString(),
                                    ActivatedDateTime = reader["ActivationDate"] == DBNull.Value
                                        ? null
                                        : (DateTime?)reader["ActivationDate"],
                                    IssuedDateTime = reader["IssuedDateTime"] == DBNull.Value
                                        ? DateTime.Now
                                        : (DateTime)reader["IssuedDateTime"],
                                    PaymentInstrumentStatusReason =
                                        reader.IsDBNull(reader.GetOrdinal("PaymentInstrumentStatusReasonKey"))
                                            ? (PaymentInstrumentStatusReason?)null
                                            : (PaymentInstrumentStatusReason)(short)reader[
                                                "PaymentInstrumentStatusReasonKey"],
                                    PaymentIdentifierStatusReason =
                                        reader.IsDBNull(reader.GetOrdinal("PaymentIdentifierStatusReasonKey"))
                                            ? (PaymentIdentifierStatusReason?)null
                                            : (PaymentIdentifierStatusReason)(short)reader[
                                                "PaymentIdentifierStatusReasonKey"],
                                    CustomCardImageIdentifier = reader["CustomCardImageIdentifier"] == DBNull.Value
                                        ? null
                                        : reader["CustomCardImageIdentifier"].ToString()

                                };

                                paymentInstrument.ActivatedDateTime =
                                    paymentInstrument.ActivatedDateTime?.ToUniversalTime();
                                paymentInstrument.IssuedDateTime = paymentInstrument.IssuedDateTime?.ToUniversalTime();

                                PaymentIdentifierStatus pIdStatus =
                                    (PaymentIdentifierStatus)(short)reader["PaymentIdentifierStatusKey"];
                                paymentInstrument.Status =
                                    StatusMapper.GetPaymentInstrumentStatus(pIdStatus, paymentInstrument.Status);
                                paymentInstrument.PaymentInstrumentStatusReasons =
                                    StatusMapper.GetPaymentInstrumentStatusReasons(pIdStatus, paymentInstrument.Status,
                                        paymentInstrument.PaymentInstrumentStatusReason,
                                        paymentInstrument.PaymentIdentifierStatusReason);

                                // initialize to "false"
                                paymentInstrument.IsPrivateDataViewable = "false";
                                currentAccountHolder.PaymentInstruments.Add(paymentInstrument);
                            }
                        }
                    }

                    foreach (var ah in getAccountResponse.Account.AccountHolders)
                    {
                        if (ah.PaymentInstruments.Count == 0)
                        {
                            ah.PaymentInstruments = null;
                        }
                    }

                    GetAccountInfo(reader, getAccountResponse, ahKeyIdentifier, accountProductKey);

                    reader.NextResult();
                    var userProfileIdentities = ReadUserProfileIdentities(reader);
                    foreach (var accountHolder in getAccountResponse.Account.AccountHolders)
                    {
                        var identity = userProfileIdentities
                            .FindAll(u => u.ConsumerProfileKey == accountHolder.User.ConsumerProfileKey && u.IdentityType != IdentityType.EIN)
                            .OrderByDescending(c => c.CreateDateUtc).FirstOrDefault();
                        accountHolder.SsnToken = identity?.IdentityToken;
                        if (null != identity && identity.IdentityType != 0)
                        {
                            accountHolder.User.IdentityType = identity.IdentityType;
                            accountHolder.User.Last4Identity = identity.Last4Identity;
                        }
                        else
                        {
                            accountHolder.User.IdentityType = null;
                            accountHolder.User.Last4Identity = null;
                        }

                        // https://pd/browse/GBOS-29170 - Uncomment this
                        //if (!accountHolder.User.KycStateData.KycStatus.Equals("passed",
                        //        StringComparison.InvariantCultureIgnoreCase) ||
                        //    !accountHolder.User.KycStateData.OfacStatus.Equals("passed",
                        //        StringComparison.InvariantCultureIgnoreCase))
                        //{
                        //    if (accountHolder.User.KycStateData.PendingKycGate.Equals("none",
                        //        StringComparison.InvariantCultureIgnoreCase))
                        //    {
                        //        if (accountHolder.PaymentInstruments == null || accountHolder.PaymentInstruments.Count == 0)
                        //            accountHolder.User.Status = "regFailedNoCure";
                        //        else
                        //            accountHolder.User.Status = "undefined"; //out of scope in GBOS-27104
                        //    }
                        //    else if (accountHolder.User.KycStateData.PendingKycGate.Equals("healthy",
                        //        StringComparison.InvariantCultureIgnoreCase))
                        //    {
                        //        accountHolder.User.Status = "notAllowed";
                        //    }
                        //    else
                        //    {
                        //        if (accountHolder.PaymentInstruments == null || accountHolder.PaymentInstruments.Count == 0)
                        //            accountHolder.User.Status = "pending";
                        //        else
                        //            accountHolder.User.Status = "undefined"; //out of scope in GBOS-27104
                        //    }
                        //}
                        //else if (accountHolder.User.KycStateData.KycStatus.Equals("passed",
                        //                StringComparison.InvariantCultureIgnoreCase) &&
                        //            accountHolder.User.KycStateData.OfacStatus.Equals("passed",
                        //                StringComparison.InvariantCultureIgnoreCase))
                        //{
                        //    if (accountHolder.PaymentInstruments == null || accountHolder.PaymentInstruments.Count == 0)
                        //    {
                        //        if (accountHolder.User.KycStateData.PendingKycGate.Equals("healthy",
                        //            StringComparison.InvariantCultureIgnoreCase))
                        //        {
                        //            accountHolder.User.Status = "pendingCardCreation";
                        //        }
                        //        else
                        //        {
                        //            accountHolder.User.Status = "notAllowed";
                        //        }
                        //    }
                        //    else
                        //    {
                        //        if (accountHolder.PaymentInstruments.Exists(c =>
                        //            c.Status == PaymentInstrumentStatus.Activated ||
                        //            c.Status == PaymentInstrumentStatus.NotActivated ||
                        //            c.Status == PaymentInstrumentStatus.Blocked))
                        //        {
                        //            accountHolder.User.Status = "active";
                        //        }
                        //        else
                        //        {
                        //            accountHolder.User.Status = "closed";
                        //        }
                        //    }
                        //}
                    }

                    if (!includeDetails)
                    {
                        //GBOS-31685  keep the response data is same as before
                        foreach (var accountHolder in getAccountResponse.Account.AccountHolders)
                        {
                            accountHolder.PaymentInstruments = null;
                        }
                    }
                }
                return getAccountResponse;
            }
        }

        /// <summary>
        /// GetAccountByAccountIdentifierAsync
        /// </summary>
        /// <param name="accountIdentifier"></param>
        /// <param name="programCode"></param>
        /// <param name="includeCardData"></param>
        /// <returns></returns>
        [ExcludeFromCodeCoverage(Justification = "Converting method to async for perf")]
        public async Task<GetAccountResponse> GetAccountByAccountIdentifierAsync(string accountIdentifier, string programCode, bool includeCardData, CancellationToken token, bool includeDetails = false)
        {
            GetAccountResponse getAccountResponse = null;
            SqlParameter[] parameters = null;
            string pan = null;

            try
            {
                parameters = new[]
                {
                    new SqlParameter() { ParameterName = "AccountIdentifier",Value = Guid.Parse(accountIdentifier) },
                    new SqlParameter() { ParameterName = "ProgramCode",Value = programCode}
                };
            }
            catch (Exception ex) { throw new AccountNotFoundException(); }

            using (var reader = await _dataAccess.ExecuteReaderAsync("[dbo].[GetAccount]", CommandType.StoredProcedure, 
                _dataAccess.CreateConnectionWithColumnEncryption(), token, parameters))
            {
                if (await reader.ReadAsync(token))
                {
                    getAccountResponse = new GetAccountResponse();
                    getAccountResponse.Account = new Account();
                    getAccountResponse.Account.AccountHolders = new List<AccountHolder>();
                    getAccountResponse.Account.AccountIdentifier = reader["AccountIdentifier"].ToString();
                    getAccountResponse.Account.Status = ((AccountStatus)(short)reader["AccountStatusKey"]).ToString().ToLower();

                    DateTime accountStatusDateChange = reader.GetDateTime(reader.GetOrdinal("StatusChangeDate"));
                    accountStatusDateChange = accountStatusDateChange.ToUniversalTime();
                    getAccountResponse.Account.AccountStatusChangedDateTime =
                        accountStatusDateChange.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");

                    getAccountResponse.Account.ProductCode = reader["ProductCode"].ToString();
                    var accountProductKey = Convert.ToInt32(reader["ProductKey"]);
                    int.TryParse(reader["ProductTierKey"]?.ToString(), out int productTierKey);
                    getAccountResponse.Account.ProductTierKey = productTierKey;
                    getAccountResponse.Account.ProductName = reader["ProductName"].ToString();
                    getAccountResponse.Account.DirectDepositInformation = new DirectDepositInformation();
                    getAccountResponse.Account.DirectDepositInformation.AccountNumber = reader["AccountNumber"].ToString();
                    getAccountResponse.Account.DirectDepositInformation.RoutingNumber = reader["RoutingNumber"].ToString();
                    getAccountResponse.Account.CustomerReferenceNumber = reader["AccountReferenceNumber"].ToString();
                    getAccountResponse.Account.ActivationDate = reader["ActivationDate"] == DBNull.Value ? null
                        : reader.GetDateTime(reader.GetOrdinal("ActivationDate")).ToString("yyyy-MM-ddTHH:mm:ss.fff");
                    getAccountResponse.Account.AccountCycleDay = reader["BillCycleDay"] == DBNull.Value ? (short)0 : (short)reader["BillCycleDay"];
                    getAccountResponse.Account.SystemKey = reader["SystemKey"] == DBNull.Value ? null : (short)reader["SystemKey"];
                    await reader.NextResultAsync(token);
                    if (await reader.ReadAsync(token))
                    {
                        getAccountResponse.Account.Currency = reader["CurrencyKey"] == DBNull.Value ? null : ((CurrencyType)(short)reader["CurrencyKey"]).ToString();
                    }

                    await reader.NextResultAsync(token);

                    getAccountResponse.Account.AccountHolders = new List<AccountHolder>();
                    Dictionary<long, string> ahKeyIdentifier = new Dictionary<long, string>();
                    while (await reader.ReadAsync(token))
                    {
                        if (Convert.ToInt32(reader["ConsumerProfileTypeKey"]) == 1 || programCode.Equals("credibly", StringComparison.OrdinalIgnoreCase))
                        {
                            User user = new User();
                            var accountHolderKey = Convert.ToInt64(reader["AccountHolderKey"]);
                            user.UserIdentifier = reader["ConsumerProfileIdentifier"].ToString();
                            bool isTransferAutoAccept = reader["IsTransferAutoAccept"] != DBNull.Value && bool.Parse(reader["IsTransferAutoAccept"].ToString());
                            user.PeerTransferAcceptPreference = isTransferAutoAccept == false ? "manual" : "automatic";
                            user.ConsumerProfileKey = reader.GetInt64(reader.GetOrdinal("ConsumerProfileKey"));
                            user.FirstName = reader["FirstName"] == DBNull.Value
                                ? string.Empty
                                : reader["FirstName"].ToString();
                            user.LastName = reader["LastName"] == DBNull.Value
                                ? string.Empty
                                : reader["LastName"].ToString();
                            bool isVerified = reader["IsDOBVerified"] == DBNull.Value
                                ? false
                                : Convert.ToBoolean(reader["IsDOBVerified"]);
                            bool isDOBBMatched = reader["IsDOBMatched"] == DBNull.Value
                                ? false
                                : Convert.ToBoolean(reader["IsDOBMatched"]);
                            if (isVerified)
                                user.DobStatus = "verified";
                            else
                                user.DobStatus = isDOBBMatched ? "matched" : "notMatched";
                            user.Status = UserStatus.Active;
                            user.IsPrimaryAccountHolder = reader["IsPrimaryAccountHolder"] != DBNull.Value &&
                                                          (bool)reader["IsPrimaryAccountHolder"];
                            user.KycStateData = new KycStateData
                            {
                                OfacStatus = "pending",
                                KycStatus = "pending",
                                PendingKycGate = reader["AccountHolderCureKey"] == DBNull.Value
                                    ? "kyc2"
                                    : ((Core.Domain.Model.Account.AccountHolderCure)(short)reader[
                                        "AccountHolderCureKey"]).ToString().ToLower()
                            };

                            AccountHolder accountHolder = new AccountHolder
                            {
                                User = user,
                                AccountHolderIdentifier = reader["AccountHolderIdentifier"].ToString()
                            };
                            accountHolder.PaymentInstruments = new List<PaymentInstrument>();
                            ahKeyIdentifier.Add(accountHolderKey, accountHolder.AccountHolderIdentifier);
                            getAccountResponse.Account.AccountHolders.Add(accountHolder);
                        }
                    }

                    await reader.NextResultAsync(token);

                    while (await reader.ReadAsync(token))
                    {
                        var currentKey = Convert.ToInt64(reader["AccountHolderKey"]);
                        if (ahKeyIdentifier.TryGetValue(currentKey, out string currentAHIdentifier))
                        {
                            var currentAccountHolder = getAccountResponse.Account.AccountHolders.Find(ah =>
                                string.Equals(currentAHIdentifier, ah.AccountHolderIdentifier,
                                    StringComparison.InvariantCultureIgnoreCase));

                            if (reader["PaymentInstrumentIdentifier"] != DBNull.Value)
                            {
                                PaymentInstrument paymentInstrument = new PaymentInstrument
                                {
                                    PaymentInstrumentIdentifier = reader["PaymentInstrumentIdentifier"].ToString(),
                                    PaymentIdentifier = reader["PaymentIdentifier"].ToString(),
                                    PaymentInstrumentType =
                                        (PaymentInstrumentType)(short)reader["PaymentInstrumentTypeKey"],
                                    Status = (PaymentInstrumentStatus)(short)reader["PaymentInstrumentStatusKey"],
                                    IsPinSet = reader["ATMPinSetDate"] != DBNull.Value,
                                    Last4Pan = reader["Last4PAN"].ToString(),
                                    ActivatedDateTime = reader["ActivationDate"] == DBNull.Value
                                        ? null
                                        : (DateTime?)reader["ActivationDate"],
                                    IssuedDateTime = reader["IssuedDateTime"] == DBNull.Value
                                        ? DateTime.Now
                                        : (DateTime)reader["IssuedDateTime"],
                                    PaymentInstrumentStatusReason =
                                        reader.IsDBNull(reader.GetOrdinal("PaymentInstrumentStatusReasonKey"))
                                            ? (PaymentInstrumentStatusReason?)null
                                            : (PaymentInstrumentStatusReason)(short)reader[
                                                "PaymentInstrumentStatusReasonKey"],
                                    PaymentIdentifierStatusReason =
                                        reader.IsDBNull(reader.GetOrdinal("PaymentIdentifierStatusReasonKey"))
                                            ? (PaymentIdentifierStatusReason?)null
                                            : (PaymentIdentifierStatusReason)(short)reader[
                                                "PaymentIdentifierStatusReasonKey"],
                                    CustomCardImageIdentifier = reader["CustomCardImageIdentifier"] == DBNull.Value
                                        ? null
                                        : reader["CustomCardImageIdentifier"].ToString()

                                };

                                paymentInstrument.ActivatedDateTime =
                                    paymentInstrument.ActivatedDateTime?.ToUniversalTime();
                                paymentInstrument.IssuedDateTime = paymentInstrument.IssuedDateTime?.ToUniversalTime();

                                PaymentIdentifierStatus pIdStatus =
                                    (PaymentIdentifierStatus)(short)reader["PaymentIdentifierStatusKey"];
                                paymentInstrument.Status =
                                    StatusMapper.GetPaymentInstrumentStatus(pIdStatus, paymentInstrument.Status);
                                paymentInstrument.PaymentInstrumentStatusReasons =
                                    StatusMapper.GetPaymentInstrumentStatusReasons(pIdStatus, paymentInstrument.Status,
                                        paymentInstrument.PaymentInstrumentStatusReason,
                                        paymentInstrument.PaymentIdentifierStatusReason);

                                // initialize to "false"
                                paymentInstrument.IsPrivateDataViewable = "false";

                                currentAccountHolder.PaymentInstruments.Add(paymentInstrument);
                            }
                        }
                    }

                    foreach (var ah in getAccountResponse.Account.AccountHolders)
                    {
                        if (ah.PaymentInstruments.Count == 0)
                        {
                            ah.PaymentInstruments = null;
                        }
                    }

                    await GetAccountInfoAsync(reader, getAccountResponse, accountProductKey, token);

                    await reader.NextResultAsync(token);
                    var userProfileIdentities = await ReadUserProfileIdentitiesAsync(reader, token);
                    foreach (var accountHolder in getAccountResponse.Account.AccountHolders)
                    {
                        var identity = userProfileIdentities
                            .FindAll(u => u.ConsumerProfileKey == accountHolder.User.ConsumerProfileKey && u.IdentityType != IdentityType.EIN)
                            .OrderByDescending(c => c.CreateDateUtc).FirstOrDefault();
                        accountHolder.SsnToken = identity?.IdentityToken;
                        if (null != identity && identity.IdentityType != 0)
                        {
                            accountHolder.User.IdentityType = identity.IdentityType;
                            accountHolder.User.Last4Identity = identity.Last4Identity;
                        }
                        else
                        {
                            accountHolder.User.IdentityType = null;
                            accountHolder.User.Last4Identity = null;
                        }
                    }

                    if (!includeDetails)
                    {
                        foreach (var accountHolder in getAccountResponse.Account.AccountHolders)
                        {
                            accountHolder.PaymentInstruments = null;
                        }
                    }
                }
                return getAccountResponse;
            }
        }

        private List<Core.Domain.Model.User.UserProfileIdentity> ReadUserProfileIdentities(IDataReader reader)
        {
            var userProfileIdentities = new List<Core.Domain.Model.User.UserProfileIdentity>();
            while (reader.Read())
            {
                var userProfileIdentity = new Core.Domain.Model.User.UserProfileIdentity
                {
                    ConsumerProfileKey = reader.GetInt64(reader.GetOrdinal("ConsumerProfileKey")),
                    IdentityToken = reader.GetString(reader.GetOrdinal("IdentityToken")),
                    Last4Identity = reader["Last4Identity"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Last4Identity")),
                    IdentityType = (IdentityType)(short)reader["IdentityTypeKey"],
                    CreateDateUtc = reader.GetDateTime(reader.GetOrdinal("CreateDate"))
                };

                userProfileIdentities.Add(userProfileIdentity);
            }

            return userProfileIdentities;
        }

        /// <summary>
        /// ReadUserProfileIdentitiesAsync
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        [ExcludeFromCodeCoverage(Justification = "Converting method to async for perf")]
        private async Task<List<Core.Domain.Model.User.UserProfileIdentity>> ReadUserProfileIdentitiesAsync(SqlDataReader reader, CancellationToken token)
        {
            var userProfileIdentities = new List<Core.Domain.Model.User.UserProfileIdentity>();
            while (await reader.ReadAsync(token))
            {
                var userProfileIdentity = new Core.Domain.Model.User.UserProfileIdentity
                {
                    ConsumerProfileKey = reader.GetInt64(reader.GetOrdinal("ConsumerProfileKey")),
                    IdentityToken = reader.GetString(reader.GetOrdinal("IdentityToken")),
                    Last4Identity = reader["Last4Identity"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Last4Identity")),
                    IdentityType = (IdentityType)(short)reader["IdentityTypeKey"],
                    CreateDateUtc = reader.GetDateTime(reader.GetOrdinal("CreateDate"))
                };

                userProfileIdentities.Add(userProfileIdentity);
            }
            return userProfileIdentities;
        }

        public GetPursesResponse GetPurses(string accountIdentifier, string programCode)
        {
            GetPursesResponse getAccountResponse = null;
            SqlParameter[] parameters;

            try
            {
                parameters = new[]
                {
                  new SqlParameter() { ParameterName = "AccountIdentifier",Value = Guid.Parse(accountIdentifier) }
                };
            }// Try/Catch added to validate the accountidentifier (GUID) and catch the exception upfront before sending to database
            catch (Exception ex) { throw new AccountNotFoundException(); }

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountBalanceByAccountIdentifier]", _dataAccess.CreateConnectionWithColumnEncryption(), parameters))
            {

                var purses = new List<Purse>();
                while (reader.Read())
                {
                    var purse = new Purse
                    {
                        PurseIdentifier = reader["AccountBalanceIdentifier"].ToString(),
                        PurseType = (PurseType)(short)reader["AccountBalanceTypeKey"],
                        AvailableBalance = reader["AvailableBalance"] == DBNull.Value ? 0 : (decimal)reader["AvailableBalance"],
                        LedgerBalance = reader["LedgerBalance"] == DBNull.Value ? 0 : (decimal)reader["LedgerBalance"],
                        AvailableBalanceAsOfDateTime = reader["AvailableBalanceAsOfDate"] == DBNull.Value ? DateTime.Now : (DateTime?)reader["AvailableBalanceAsOfDate"],
                        LedgerBalanceAsOfDateTime = reader["LedgerBalanceAsOfDate"] == DBNull.Value ? DateTime.Now : (DateTime?)reader["LedgerBalanceAsOfDate"],
                        PurseDescription = reader["UserDescription"] == DBNull.Value ? null : reader["UserDescription"].ToString(),
                        IsHidden = reader["IsHidden"] != DBNull.Value && ((bool)reader["IsHidden"]),
                        Status = (PurseStatus)(short)reader["AccountBalanceStatusKey"],
                        GoalAmount = reader["GoalAmount"] == DBNull.Value ? null : (decimal?)reader["GoalAmount"],
                        GoalDate = reader["GoalDate"] == DBNull.Value ? null : (DateTime?)reader["GoalDate"],
                        IconName = reader["IconName"] == DBNull.Value ? null : reader["IconName"].ToString(),
                        CreateDate = reader["CreateDate"] == DBNull.Value ? null : (DateTime?)reader["CreateDate"],
                        ChangeDate = reader["ChangeDate"] == DBNull.Value ? null : (DateTime?)reader["ChangeDate"],
                        PurseNumber = reader["AccountBalanceNumber"] == DBNull.Value ? null : reader["AccountBalanceNumber"].ToString(),
                        PurseSubType = reader["AccountBalanceTypeSubCategory"] == DBNull.Value ? null : reader["AccountBalanceTypeSubCategory"].ToString(),
                        IsRoundUp = reader["IsRoundUp"] != DBNull.Value && ((bool)reader["IsRoundUp"])
                    };

                    purses.Add(purse);
                }

                if (purses.Count > 0)
                {
                    getAccountResponse = new GetPursesResponse { Purses = purses.ToArray() };
                }

                return getAccountResponse;
            }
        }

        public long? GetAccountKey(string accountIdentifier, string programCode)
        {
            var accountKey = default(long?);
            SqlParameter[] parameters;

            try
            {
                parameters = new[]
                {
                new SqlParameter() { ParameterName = "AccountIdentifier",Value = Guid.Parse(accountIdentifier) }
            };
            }// Try/Catch added to validate the accountidentifier (GUID) and catch the exception upfront before sending to database
            catch (Exception ex) { throw new AccountNotFoundException(); }

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountByAccountIdentifier]", _dataAccess.CreateConnectionWithColumnEncryption(), parameters))
            {

                if (reader.Read())
                {
                    accountKey = (long)reader["AccountKey"];
                }

                return accountKey;
            }
        }

        public int? GetAccountProductTierKey(string accountIdentifier, string programCode)
        {
            var productTierKey = default(int?);
            SqlParameter[] parameters;

            try
            {
                parameters = new[]
                {
                    new SqlParameter { ParameterName = "AccountIdentifier", Value = Guid.Parse(accountIdentifier) }
                };
            }
            catch
            {
                throw new AccountNotFoundException();
            }

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountByAccountIdentifier]",
                       _dataAccess.CreateConnectionWithColumnEncryption(), parameters))
            {
                if (reader.Read())
                {
                    productTierKey = (int)reader["ProductTierKey"];
                }

                return productTierKey;
            }
        }

        public string GetAccountToken(string accountIdentifier)
        {
            string accountToken = string.Empty;
            SqlParameter[] parameters;

            try
            {
                parameters = new[]
                {
                    new SqlParameter() { ParameterName = "AccountIdentifier",Value = Guid.Parse(accountIdentifier) }
                };
            }// Try/Catch added to validate the accountidentifier (GUID) and catch the exception upfront before sending to database
            catch (Exception ex) { throw new AccountNotFoundException(); }

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountByAccountIdentifier]", _dataAccess.CreateConnectionWithColumnEncryption(), parameters))
            {

                if (reader.Read())
                {
                    accountToken = reader["AccountToken"] == DBNull.Value ? "" : reader["AccountToken"].ToString(); ;
                }

                return accountToken;
            }
        }

        /// <summary>
        /// GetAccountInfo
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="getAccountResponse"></param>
        /// <param name="ahKeyIdentifier"></param>
        /// <param name="accountProductKey"></param>
        /// <returns></returns>
        private GetAccountResponse GetAccountInfo(IDataReader reader, GetAccountResponse getAccountResponse, Dictionary<long, string> ahKeyIdentifier, int accountProductKey)
        {
            reader.NextResult();

            getAccountResponse.Account.StatusReasons = new List<string>();
            while (reader.Read())
            {
                getAccountResponse.Account.StatusReasons.Add(((Core.Domain.Model.Account.AccountStatusReason)(short)reader["AccountStatusReasonKey"]).ToString());
            }

            if (getAccountResponse.Account.StatusReasons.Count == 0)
                getAccountResponse.Account.StatusReasons = null;

            reader.NextResult();
            var verificationKeyIdentifier = new Dictionary<long, string>();
            var requestTriggerTypes = new Dictionary<long, TriggerType>();
            while (reader.Read())
            {
                var verificationRequestKey = Convert.ToInt64(reader["VerificationRequestKey"]);
                requestTriggerTypes[verificationRequestKey] = (TriggerType)Convert.ToInt16(reader["VerificationTriggerTypeKey"]);
                if (getAccountResponse.Account.ProductCode != "50400" || getAccountResponse.Account.AccountHolders.Count <= 1)
                {
                    continue;
                }

                var accountHolderKey = Convert.ToInt64(reader["AccountHolderKey"]);
                if (ahKeyIdentifier.TryGetValue(accountHolderKey, out string currentAhIdentifier))
                {
                    verificationKeyIdentifier.Add(verificationRequestKey, currentAhIdentifier);
                }
            }
            reader.NextResult();
            while (reader.Read())
            {
                var verificationRequestKey = Convert.ToInt64(reader["VerificationRequestKey"]);
                var isUpgrade = requestTriggerTypes[verificationRequestKey] == TriggerType.AccountUpgrade;
                if (isUpgrade)
                {
                    if (getAccountResponse.Account.UpgradeKycStateData == null)
                    {
                        getAccountResponse.Account.UpgradeKycStateData = new ContractKycStateData();
                    }
                    var activityType = (VerificationActivityType)Convert.ToInt16(reader["VerificationActivityTypeKey"]);
                    var status = (VerificationStatus)Convert.ToInt16(reader["VerificationActivityStatusKey"]);
                    switch (activityType)
                    {
                        case VerificationActivityType.KYC:
                            getAccountResponse.Account.UpgradeKycStateData.KycStatus = status.ToString().ToLower();
                            break;
                        case VerificationActivityType.OFAC:
                            getAccountResponse.Account.UpgradeKycStateData.OfacStatus = status.ToString().ToLower();
                            break;
                        case VerificationActivityType.IDV:
                            if (status == VerificationStatus.Passed)
                                getAccountResponse.Account.UpgradeKycStateData.KycStatus = VerificationStatus.Passed.ToString().ToLower();
                            break;
                    }
                }
                else
                {
                    foreach (var ah in getAccountResponse.Account.AccountHolders)
                    {
                        if (getAccountResponse.Account.ProductCode == "50400" 
                            && getAccountResponse.Account.AccountHolders.Count > 1 
                            && verificationKeyIdentifier.TryGetValue(verificationRequestKey, out string accountHolderIdentifier)
                            && !string.Equals(ah.AccountHolderIdentifier, accountHolderIdentifier, StringComparison.InvariantCultureIgnoreCase))
                        {
                            continue;
                        }
                        
                        string idvStatus = string.Empty;
                        if (reader["VerificationActivityTypeKey"] != DBNull.Value)
                        {
                            if (Convert.ToInt32(reader["VerificationActivityTypeKey"]) == 2)
                            {
                                ah.User.KycStateData.OfacStatus = ((Core.Domain.Model.Account.VerificationStatus)(short)Convert.ToInt32(reader["VerificationActivityStatusKey"])).ToString().ToLower();
                            }
                            else if (Convert.ToInt32(reader["VerificationActivityTypeKey"]) == 1 || Convert.ToInt32(reader["VerificationActivityTypeKey"]) == 11)
                            {
                                ah.User.KycStateData.KycStatus = ((Core.Domain.Model.Account.VerificationStatus)(short)Convert.ToInt32(reader["VerificationActivityStatusKey"])).ToString().ToLower();
                            }
                            else if (Convert.ToInt32(reader["VerificationActivityTypeKey"]) == 5)
                            {
                                idvStatus = ((Core.Domain.Model.Account.VerificationStatus)(short)Convert.ToInt32(reader["VerificationActivityStatusKey"])).ToString().ToLower();
                            }
                        }

                        if (ah.User.KycStateData.KycStatus == "failed" && idvStatus == "passed")
                        {
                            ah.User.KycStateData.KycStatus = "passed";
                        }
                    }
                }
            }

            reader.NextResult();
            getAccountResponse.Account.TermsAcceptances = new List<TermsAcceptance>();
            while (reader.Read())
            {
                if (reader["IsPrimaryAccountHolder"].Cast<bool>())
                {
                    bool hasAccepted = false;
                    long accountHolderAgreementKey = reader.GetInt64(reader.GetOrdinal("AccountHolderAgreementKey"));
                    string brandAgreementTypeIdentifier = reader["BrandAgreementTypeIdentifier"].ToString().Trim();
                    DateTime acceptanceDate = reader.GetDateTime(reader.GetOrdinal("AcceptanceDate"));
                    acceptanceDate = DateTime.SpecifyKind(acceptanceDate, DateTimeKind.Local);
                    acceptanceDate = acceptanceDate.ToUniversalTime();
                    // hasAccepted = reader.GetBoolean(reader.GetOrdinal("HasAccepted"));
                    DateTime? optOutDate = reader.IsDBNull(reader.GetOrdinal("OptOutDate")) ? (DateTime?)null
                        : reader.GetDateTime(reader.GetOrdinal("OptOutDate"));

                    if (optOutDate == null)
                        hasAccepted = true;

                    if (accountProductKey != Convert.ToInt32(reader["ProductKey"]) && !hasAccepted)
                        continue;
                    getAccountResponse.Account.TermsAcceptances.Add(
                        new TermsAcceptance
                        {
                            TermsIdentifier = brandAgreementTypeIdentifier,
                            TermsAcceptanceDateTime = acceptanceDate.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
                            TermsAcceptanceFlag = hasAccepted
                        });
                }

            }

            return getAccountResponse;
        }

        /// <summary>
        /// GetAccountInfoAsync
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="getAccountResponse"></param>
        /// <returns></returns>
        [ExcludeFromCodeCoverage(Justification = "Converting method to async for perf")]
        private async Task<GetAccountResponse> GetAccountInfoAsync(SqlDataReader reader, GetAccountResponse getAccountResponse, int accountProductKey, CancellationToken token)
        {
            await reader.NextResultAsync(token);

            getAccountResponse.Account.StatusReasons = new List<string>();
            while (await reader.ReadAsync(token))
            {
                getAccountResponse.Account.StatusReasons.Add(((Core.Domain.Model.Account.AccountStatusReason)(short)reader["AccountStatusReasonKey"]).ToString());
            }

            if (getAccountResponse.Account.StatusReasons.Count == 0)
                getAccountResponse.Account.StatusReasons = null;

            await reader.NextResultAsync(token);
            var requestTriggerTypes = new Dictionary<long, TriggerType>();
            while (await reader.ReadAsync(token))
            {
                var verificationRequestKey = Convert.ToInt64(reader["VerificationRequestKey"]);
                requestTriggerTypes[verificationRequestKey] = (TriggerType)Convert.ToInt16(reader["VerificationTriggerTypeKey"]);
            }
            await reader.NextResultAsync(token);
            while (await reader.ReadAsync(token))
            {
                var verificationRequestKey = Convert.ToInt64(reader["VerificationRequestKey"]);
                var isUpgrade = requestTriggerTypes[verificationRequestKey] == TriggerType.AccountUpgrade;
                if (isUpgrade)
                {
                    if (getAccountResponse.Account.UpgradeKycStateData == null)
                    {
                        getAccountResponse.Account.UpgradeKycStateData = new ContractKycStateData();
                    }
                    var activityType = (VerificationActivityType)Convert.ToInt16(reader["VerificationActivityTypeKey"]);
                    var status = (VerificationStatus)Convert.ToInt16(reader["VerificationActivityStatusKey"]);
                    switch (activityType)
                    {
                        case VerificationActivityType.KYC:
                            getAccountResponse.Account.UpgradeKycStateData.KycStatus = status.ToString().ToLower();
                            break;
                        case VerificationActivityType.OFAC:
                            getAccountResponse.Account.UpgradeKycStateData.OfacStatus = status.ToString().ToLower();
                            break;
                        case VerificationActivityType.IDV:
                            if (status == VerificationStatus.Passed)
                                getAccountResponse.Account.UpgradeKycStateData.KycStatus = VerificationStatus.Passed.ToString().ToLower();
                            break;
                    }
                }
                else
                {
                    foreach (var ah in getAccountResponse.Account.AccountHolders)
                    {
                        string idvStatus = string.Empty;
                        if (reader["VerificationActivityTypeKey"] != DBNull.Value)
                        {
                            if (Convert.ToInt32(reader["VerificationActivityTypeKey"]) == 2)
                            {
                                ah.User.KycStateData.OfacStatus = ((VerificationStatus)(short)Convert.ToInt32(reader["VerificationActivityStatusKey"])).ToString().ToLower();
                            }
                            else if (Convert.ToInt32(reader["VerificationActivityTypeKey"]) == 1 || Convert.ToInt32(reader["VerificationActivityTypeKey"]) == 11)
                            {
                                ah.User.KycStateData.KycStatus = ((VerificationStatus)(short)Convert.ToInt32(reader["VerificationActivityStatusKey"])).ToString().ToLower();
                            }
                            else if (Convert.ToInt32(reader["VerificationActivityTypeKey"]) == 5)
                            {
                                idvStatus = ((VerificationStatus)(short)Convert.ToInt32(reader["VerificationActivityStatusKey"])).ToString().ToLower();
                            }
                        }

                        if (ah.User.KycStateData.KycStatus == "failed" && idvStatus == "passed")
                        {
                            ah.User.KycStateData.KycStatus = "passed";
                        }
                    }
                }
            }

            await reader.NextResultAsync(token);
            getAccountResponse.Account.TermsAcceptances = new List<TermsAcceptance>();
            while (await reader.ReadAsync(token))
            {
                if (reader["IsPrimaryAccountHolder"].Cast<bool>())
                {
                    bool hasAccepted = false;
                    long accountHolderAgreementKey = reader.GetInt64(reader.GetOrdinal("AccountHolderAgreementKey"));
                    string brandAgreementTypeIdentifier = reader["BrandAgreementTypeIdentifier"].ToString().Trim();
                    DateTime acceptanceDate = reader.GetDateTime(reader.GetOrdinal("AcceptanceDate"));
                    acceptanceDate = DateTime.SpecifyKind(acceptanceDate, DateTimeKind.Local);
                    acceptanceDate = acceptanceDate.ToUniversalTime();
                    DateTime? optOutDate = reader.IsDBNull(reader.GetOrdinal("OptOutDate")) ? (DateTime?)null
                        : reader.GetDateTime(reader.GetOrdinal("OptOutDate"));

                    if (optOutDate == null)
                        hasAccepted = true;

                    if (accountProductKey != Convert.ToInt32(reader["ProductKey"]) && !hasAccepted)
                        continue;
                    getAccountResponse.Account.TermsAcceptances.Add(
                        new TermsAcceptance
                        {
                            TermsIdentifier = brandAgreementTypeIdentifier,
                            TermsAcceptanceDateTime = acceptanceDate.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
                            TermsAcceptanceFlag = hasAccepted
                        });
                }

            }
            return getAccountResponse;
        }

        public Dictionary<Guid, decimal> GetEGiftCashBackTransactionAmounts(string accountIdentifier)
        {
            var historyStartDate = new DateTime(2019, 8, 1); // beginning of rewards marketplace

            // map by fund transfer key as a string
            var allTransactions = new Dictionary<string, EGiftCashBackRewardsTransaction>();

            var parameters = new[]
            {
                new SqlParameter()
                {
                    ParameterName = "Identifier", Value = Guid.Parse(accountIdentifier),
                    SqlDbType = SqlDbType.UniqueIdentifier
                },
                new SqlParameter()
                {
                    ParameterName = "FundTransferStatusKey",
                    Value = CreateTypeStatusKey().Convert(),
                    SqlDbType = SqlDbType.Structured, TypeName = "dbo.typeStatusKey"
                },
                new SqlParameter() {ParameterName = "StartDate", Value = historyStartDate, SqlDbType = SqlDbType.DateTime2},
                new SqlParameter() {ParameterName = "EndDate", Value = DateTime.Now, SqlDbType = SqlDbType.DateTime2},
                new SqlParameter() {ParameterName = "FundTransferTypeKey", Value = 13, SqlDbType = SqlDbType.SmallInt} // 13 == EGiftPurchase
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetFundTransferByIdentifierAndStatusV3]",
                _dataAccess.CreateConnection(), parameters.ToArray()))
            {
                while (reader.Read())
                {
                    var isSource = reader["IsSource"].ToString();
                    var transClassKey = int.Parse(reader["TransClassKey"].ToString());

                    if (!EGiftTransClassKeys.Contains(transClassKey))
                        continue; // shouldn't happen, SP should only be returning EGift purchase and EGift reward details, but if it does skip it

                    if (transClassKey == 93 && isSource == "1")
                        continue; // dont need anything from this record



                    var fundTransferKey = reader["FundTransferKey"].ToString();

                    if (transClassKey == 93) // EGiftPurchase, isSource == 0 is implied
                    {
                        // this record holds the EGiftId
                        var transactionReferenceID = reader["TransactionReferenceID"].ToString();

                        if (allTransactions.ContainsKey(fundTransferKey))
                        {
                            // dictonary already has this key, so update with the EGiftId
                            allTransactions[fundTransferKey].EGiftId = transactionReferenceID;
                        }
                        else
                        {
                            // dictonary doesn't have the record yet, create new
                            allTransactions.Add(fundTransferKey, new EGiftCashBackRewardsTransaction
                            {
                                FundTransferKey = fundTransferKey,
                                EGiftId = transactionReferenceID
                            });
                        }
                    }

                    if (transClassKey == 95) // CashBackReward Transaction
                    {
                        // this record contains the CashBack Reward Amount
                        var cashBackRewardAmount = Decimal.Parse(reader["DetailTransactionAmount"].ToString());

                        if (allTransactions.ContainsKey(fundTransferKey))
                        {
                            // dictonary already has this key, so update with the CBR Amount
                            allTransactions[fundTransferKey].CashBackAmount = cashBackRewardAmount;
                        }
                        else
                        {
                            // dictonary doesn't have the record yet, create new
                            allTransactions.Add(fundTransferKey, new EGiftCashBackRewardsTransaction
                            {
                                FundTransferKey = fundTransferKey,
                                CashBackAmount = cashBackRewardAmount
                            });
                        }
                    }
                }
            }

            // map the return of EGiftID to CBR amount
            var result = new Dictionary<Guid, decimal>();

            foreach (var transaction in allTransactions)
            {
                if (string.IsNullOrWhiteSpace(transaction.Value.EGiftId)
                    || !Guid.TryParse(transaction.Value.EGiftId, out var egiftId))
                    continue; // egiftid was not a valid guid (maybe null)

                if (result.ContainsKey(egiftId))
                {
                    continue; // shouldnt happen, there should only be one FundTransfer per EGiftID, but if it does, skip
                }

                result.Add(egiftId, Decimal.Parse(transaction.Value.CashBackAmount.ToString("0.00"))); // truncate to set decimal to 2 places
            }

            return result;
        }

        public DateTime? GetAccountTransaction(Guid transactionReferenceIdentifier)
        {
            DateTime? transactionDate = null;

            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "TransactionReferenceID",Value = transactionReferenceIdentifier }
            };
            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountTransactionByTransactionReferenceID]", _dataAccess.CreateConnection(), parameters))
            {
                if (reader.Read())
                {
                    transactionDate = (DateTime)reader["TransactionDate"];
                }

                return transactionDate;
            }
        }

        private List<SqlDataRecord> CreateTypeStatusKey()
        {
            List<SqlDataRecord> returnValue = new List<SqlDataRecord>();
            SqlMetaData[] metadata = new SqlMetaData[1];

            metadata[0] = new SqlMetaData("StatusKey", SqlDbType.SmallInt);

            SqlDataRecord record = new SqlDataRecord(metadata);
            record.SetInt16(0, (short)TransferStatus.Completed);
            returnValue.Add(record);

            return returnValue;
        }

        private IList<AccountHolder> GetAccountHolderInfo(Guid userIdentifier)
        {
            throw new NotImplementedException();
        }
    }


}
