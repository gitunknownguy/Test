﻿using System;
using Gd.Bos.Shared.Common.Caching;

namespace Gd.Bos.RequestHandler.Logic.DataAccess
{
    public interface IRequestDataAccess
    {
        Guid? InsertRequestId(RequestType requestType, Guid requestId, Guid accountIdentifier, Guid? verificationRequest = null);
        BoolWrapper ValidateProgramCode(Core.Domain.Model.Account.AccountIdentifier accountIdentifier, Core.Domain.Model.ProgramCode programCode);
        BoolWrapper ValidateTokenizedPAN(Core.Domain.Model.Account.AccountIdentifier accountIdentifier, string tokenizedPAN);
        BoolWrapper ValidateConsumerProfileIdentifier(Core.Domain.Model.Account.AccountIdentifier accountIdentifier,
            Core.Domain.Model.User.UserIdentifier userIdentifier);
        BoolWrapper ValidatePaymentInstrumentIdentifier(Core.Domain.Model.Account.AccountIdentifier accountIdentifier,
            Core.Domain.Model.Payment.PaymentInstrumentIdentifier paymentInstrumentIdentifier);
    }
}
