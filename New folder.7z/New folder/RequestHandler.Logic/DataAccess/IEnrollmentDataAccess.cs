﻿using System.Threading;
using System.Threading.Tasks;
using Gd.Bos.Dcpp.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;

namespace Gd.Bos.RequestHandler.Logic.DataAccess
{
    public interface IEnrollmentDataAccess
    {
        GetEnrollmentResponse GetEnrollmentByAccountIdentifier(string accountIdentifier, string programCode, bool includeCardData);

        Task<GetEnrollmentResponse> GetEnrollmentByAccountIdentifierAsync(string accountIdentifier, string programCode, bool includeCardData, CancellationToken token);

        ExternalProcessor GetProcessorByProductCode(string productCode);
    }
}
