﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.DeviceProvisioning;
using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.Shared.Common.Messaging.Hashing;
using Microsoft.Data.SqlClient;
using NLog;
using PaymentIdentifierDeviceInfo = RequestHandler.Core.Domain.Model.Payment.PaymentIdentifierDeviceInfo;

namespace RequestHandler.Logic.DataAccess
{
    public class DeviceProvisioningMessageDataAccess : IDeviceProvisioningMessageDataAccess
    {
        private readonly IDataAccess _dataAccess;

        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();

        public DeviceProvisioningMessageDataAccess(IDataAccess dataAccess)
        {
            _dataAccess = dataAccess;
        }

        public async Task InsertDeviceProvisioningMessage(GetActivationMethodsRequest message, string paymentIdentifierProxy)
        {
            await InsertDeviceProvisioningMessage(message.Provider, message.TokenReferenceId, message.PanReferenceId, FindRequestorId(message.WalletInfo), null, message.DeviceIdentifier, paymentIdentifierProxy, null, CancellationToken.None);
        }

        public async Task InsertDeviceProvisioningMessage(SendPasscodeRequest message, string paymentIdentifierProxy, string notificationChannel)
        {
            await InsertDeviceProvisioningMessage(message.Provider, message.TokenReferenceId, message.PanReferenceId, FindRequestorId(message.WalletInfo), message.ExpirationDateTime, message.DeviceIdentifier, paymentIdentifierProxy, notificationChannel, CancellationToken.None);
        }

        public string FindRequestorId(WalletInfo walletInfo)
        {
            if (walletInfo == null)
                return null;

            if (!string.IsNullOrWhiteSpace(walletInfo.TokenRequestorId))
                return walletInfo.TokenRequestorId;

            if ((!string.IsNullOrWhiteSpace(walletInfo.Name) && walletInfo.Name.Contains("Apple", StringComparison.OrdinalIgnoreCase)) ||
                string.CompareOrdinal(walletInfo.WalletId, "103") == 0)
                return "50110030273";

            if ((!string.IsNullOrWhiteSpace(walletInfo.Name) && walletInfo.Name.Contains("Google", StringComparison.OrdinalIgnoreCase)) ||
                string.CompareOrdinal(walletInfo.WalletId, "216") == 0)
                return "50120834693";

            if ((!string.IsNullOrWhiteSpace(walletInfo.Name) && walletInfo.Name.Contains("Samsung", StringComparison.OrdinalIgnoreCase)) ||
                string.CompareOrdinal(walletInfo.WalletId, "217") == 0)
                return "50139059239";

            return null;
        }

        private async Task InsertDeviceProvisioningMessage(string provider, string tokenReferenceId, string panReferenceId, string tokenRequestorId, DateTime? expirationDateTime, string deviceIdentifier, string paymentIdentifierProxy, string notificationChannel, CancellationToken cancellationToken)
        {
            string insertStoredProcedure = "[dbo].[InsDeviceProvisioningMessage]";

            try
            {
                string processingCode = null;
                string tokenEvent = string.Empty;

                if (provider?.Equals("MasterCard", StringComparison.InvariantCultureIgnoreCase) ==
                    true)
                {
                    processingCode = "860000";
                    tokenEvent = "MDESACTV";
                }
                else if (provider?.Equals("Visa", StringComparison.InvariantCultureIgnoreCase) ==
                         true)
                {
                    processingCode = null;
                    tokenEvent = "VTS OTP";
                }


                List<SqlParameter> parameters = new List<SqlParameter>
                {
                    new() { ParameterName = "ChangeBy", Value = Environment.MachineName },
                    new()
                    {
                        ParameterName = "ProcessorCreateDate", Value = DateTime.UtcNow, SqlDbType = SqlDbType.DateTime2
                    },
                    new()
                    {
                        ParameterName = "MessageHashID", Value = GenerateHashKey(Guid.NewGuid()),
                        SqlDbType = SqlDbType.VarBinary, Size = 64
                    },
                    new()
                    {
                        ParameterName = "EventFeedMessageID", Value = Guid.NewGuid(),
                        SqlDbType = SqlDbType.UniqueIdentifier
                    },
                    new()
                    {
                        ParameterName = "TokenEvent",
                        Value = tokenEvent,
                        SqlDbType = SqlDbType.NVarChar, Size = 16
                    },
                    new()
                    {
                        ParameterName = "ProcessingCode",
                        Value = string.IsNullOrEmpty(processingCode) ? DBNull.Value : processingCode,
                        SqlDbType = SqlDbType.NVarChar, Size = 6
                    },
                    new()
                    {
                        ParameterName = "AuthResponseCodeKey",
                        Value = DBNull.Value,
                        SqlDbType = SqlDbType.SmallInt
                    },
                    new()
                    {
                        ParameterName = "TokenRequestorID",
                        Value = string.IsNullOrEmpty(tokenRequestorId) ? DBNull.Value : tokenRequestorId,
                        SqlDbType = SqlDbType.NVarChar, Size = 11
                    },
                    new()
                    {
                        ParameterName = "PaymentIdentifierProxy",
                        Value = paymentIdentifierProxy,
                        SqlDbType = SqlDbType.NVarChar, Size = 100
                    },
                    new()
                    {
                        ParameterName = "ProcessorKey",
                        Value = 5,
                        SqlDbType = SqlDbType.SmallInt
                    },
                    new()
                    {
                        ParameterName = "DPANID",
                        Value = string.IsNullOrEmpty(tokenReferenceId)
                            ? DBNull.Value
                            : tokenReferenceId,
                        SqlDbType = SqlDbType.NVarChar, Size = 48
                    },
                    new()
                    {
                        ParameterName = "FPANID",
                        Value = string.IsNullOrEmpty(panReferenceId)
                            ? DBNull.Value
                            : panReferenceId,
                        SqlDbType = SqlDbType.NVarChar, Size = 48
                    },
                    new()
                    {
                        ParameterName = "NotificationChannel",
                        Value = string.IsNullOrEmpty(notificationChannel) ? DBNull.Value : notificationChannel,
                        SqlDbType = SqlDbType.NVarChar, Size = 1
                    },
                    new()
                    {
                        ParameterName = "DeviceIdentifier",
                        Value = string.IsNullOrEmpty(deviceIdentifier)
                            ? DBNull.Value
                            : deviceIdentifier,
                        SqlDbType = SqlDbType.NVarChar, Size = 48
                    },
                    new()
                    {
                        ParameterName = "ActivationExpirationDate",
                         Value = expirationDateTime == null
                            ? DBNull.Value
                            : expirationDateTime,
                        SqlDbType = SqlDbType.DateTime
                    }
                };

                var count = await _dataAccess.ExecuteNonQueryAsync(insertStoredProcedure, CommandType.StoredProcedure,
                    _dataAccess.CreateConnection(), CancellationToken.None, parameters.ToArray());

                if (count == 0)
                    throw new Exception($"Not inserted for {paymentIdentifierProxy}");
            }
            catch (Exception ex)
            {
                _logger.Error(
                    $"[{nameof(DeviceProvisioningMessageDataAccess)}.{nameof(InsertDeviceProvisioningMessage)}] [Provider = {provider}] Error while calling stored procedure: {insertStoredProcedure}. Exception: {ex}");
                throw;
            }
        }

        public List<PaymentIdentifierDeviceInfo> GetPaymentIdentifierDeviceByPaymentIdentifierProxy(string paymentIdentifierProxy, string last4DPAN)
        {
            try
            {
                List<PaymentIdentifierDeviceInfo> devices = new List<PaymentIdentifierDeviceInfo>();
                List<SqlParameter> parameters = new List<SqlParameter>
                {
                    new() {ParameterName = "pPaymentIdentifierProxy", Value = paymentIdentifierProxy },
                    new(){ParameterName = "pLast4DPAN", Value = last4DPAN}
                };

                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetPaymentIdentifierDeviceByPaymentIdentifierProxy]",
                           _dataAccess.CreateConnection(), parameters.ToArray()))
                {
                    while (reader.Read())
                    {
                        PaymentIdentifierDeviceInfo device = new PaymentIdentifierDeviceInfo()
                        {
                            DPANID = reader["DPANID"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("DPANID")),
                            DeviceStatusKey = reader["DeviceStatusKey"] == DBNull.Value ? (short)0 : reader.GetInt16(reader.GetOrdinal("DeviceStatusKey")),
                            PaymentIdentifierKey = reader["PaymentIdentifierKey"] == DBNull.Value ? (long)0 : reader.GetInt64(reader.GetOrdinal("PaymentIdentifierKey")),
                            PaymentIdentifierStatusKey = reader["PaymentIdentifierStatusKey"] == DBNull.Value ? (short)0 : reader.GetInt16(reader.GetOrdinal("PaymentIdentifierStatusKey")),
                            PaymentIdentifierStatusReasonKey = reader["PaymentIdentifierStatusReasonKey"] == DBNull.Value ? (short)0 : reader.GetInt16(reader.GetOrdinal("PaymentIdentifierStatusReasonKey"))
                        };
                        devices.Add(device);
                    }
                }

                return devices;
            }
            catch (SqlException ex)
            {
                throw new Exception("GetPaymentIdentifierDeviceByPaymentIdentifierProxy: " + ex.Message);
            }
        }

        private byte[] GenerateHashKey(Guid id)
        {
            Fnv1A64Hash fnv = new Fnv1A64Hash();
            byte[] hash = fnv.HashValue(id.ToString());
            return hash;
        }
    }
}