﻿namespace Gd.Bos.RequestHandler.Logic.DataAccess
{
    public enum RequestType
    {
        Enroll = 1,
        Transfer = 2,
        Adjustment = 3,
        InventoryOrder = 4,
        Upgrade = 5,
        CreateLinkedAccount = 6
    }
}
