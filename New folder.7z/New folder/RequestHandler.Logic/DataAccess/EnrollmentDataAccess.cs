﻿using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.Shared.Common.Core.Logic;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using Account = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Account;
using AccountHolder = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.AccountHolder;
using AccountStatus = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.AccountStatus;
using ExternalProcessor = Gd.Bos.Dcpp.Contract.Data.ExternalProcessor;
using KycStateData = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData;

using VerificationStatus = Gd.Bos.RequestHandler.Core.Domain.Model.Account.VerificationStatus;
using VerificationActivityType = Gd.Bos.RequestHandler.Core.Domain.Model.Account.VerificationActivityType;
using ContractKycStateData = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData;
using TriggerType = Gd.Bos.RequestHandler.Core.Domain.Model.Account.TriggerType;
using System.Threading.Tasks;
using System.Threading;
using RequestHandler.Logic.Extension;

namespace Gd.Bos.RequestHandler.Logic.DataAccess
{
    public class EnrollmentDataAccess : IEnrollmentDataAccess
    {
        private readonly IDataAccess _dataAccess;
        private readonly ITokenizerService _tokenizerService;
        private readonly IBaasConfiguration _baasConfiguration;
        private readonly IAccountRepository _accountRepository;

        public EnrollmentDataAccess(IDataAccess dataAccess, ITokenizerService tokenizerService,
            IBaasConfiguration baasConfiguration, IAccountRepository accountRepository)
        {
            _dataAccess = dataAccess;
            _tokenizerService = tokenizerService;
            _baasConfiguration = baasConfiguration;
            _accountRepository = accountRepository;
        }

        /// <summary>
        /// GetAccountByAccountIdentifier
        /// </summary>
        /// <param name="accountIdentifier"></param>
        /// <param name="programCode"></param>
        /// <param name="includeCardData"></param>
        /// <returns></returns>
        public GetEnrollmentResponse GetEnrollmentByAccountIdentifier(string accountIdentifier, string programCode,
            bool includeCardData)
        {
            // TODO please do not use or modify this method.
            // Please use or modify the same method in GBOS-RH-RequestHandler\Gd.Bos.RequestHandler.Core\Infrastructure\AccountRepository.cs file.
            // Current method need refactor later.

            GetEnrollmentResponse getEnrollmentResponse = new GetEnrollmentResponse();
            SqlParameter[] parameters;
            string pan = null;

            try
            {
                parameters = new[]
                {
                    new SqlParameter() {ParameterName = "AccountIdentifier", Value = Guid.Parse(accountIdentifier)},
                    new SqlParameter() {ParameterName = "ProgramCode", Value = programCode}
                };
            } // Try/Catch added to validate the account identifier (GUID) and catch the exception upfront before sending to database
            catch (Exception)
            {
                throw new AccountNotFoundException();
            }

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccount]",
                _dataAccess.CreateConnectionWithColumnEncryption(), parameters))
            {
                if (reader.Read())
                {
                    getEnrollmentResponse.Account = new Account
                    {
                        AccountHolders = new List<AccountHolder>(),
                        AccountIdentifier = reader["AccountIdentifier"].ToString(),
                        Status = ((AccountStatus)(short)reader["AccountStatusKey"]).ToString().ToLower()
                    };


                    DateTime accountStatusDateChange = reader.GetDateTime(reader.GetOrdinal("StatusChangeDate"));
                    accountStatusDateChange = accountStatusDateChange.ToUniversalTime();
                    getEnrollmentResponse.Account.AccountStatusChangedDateTime =
                        accountStatusDateChange.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");

                    getEnrollmentResponse.Account.ProductCode = reader["ProductCode"].ToString();
                    var accountProductKey = Convert.ToInt32(reader["ProductKey"]);
                    int.TryParse(reader["ProductTierKey"]?.ToString(), out int productTierKey);
                    getEnrollmentResponse.Account.ProductTierKey = productTierKey;
                    getEnrollmentResponse.Account.ProductName = reader["ProductName"].ToString();
                    getEnrollmentResponse.Account.DirectDepositInformation = new DirectDepositInformation
                    {
                        AccountNumber = reader["AccountNumber"].ToString(),
                        RoutingNumber = reader["RoutingNumber"].ToString()
                    };
                    getEnrollmentResponse.Account.CustomerReferenceNumber = reader["AccountReferenceNumber"].ToString();
                    getEnrollmentResponse.Account.AccountCycleDay = reader["BillCycleDay"] == DBNull.Value ? (short)0 : (short)reader["BillCycleDay"];
                    getEnrollmentResponse.Account.AccountToken = reader["AccountToken"] == DBNull.Value ? null : reader["AccountToken"].ToString();

                    reader.NextResult();
                    getEnrollmentResponse.Account.Purses = new List<Purse>();

                    while (reader.Read())
                    {
                        if (reader["AccountBalanceIdentifier"] != DBNull.Value)
                        {
                            getEnrollmentResponse.Account.Currency = reader["CurrencyKey"] == DBNull.Value
                                ? null
                                : ((CurrencyType)(short)reader["CurrencyKey"]).ToString();
                            var purseStatusKey = reader["AccountBalanceStatusKey"] == DBNull.Value
                                ? 1
                                : (short)reader["AccountBalanceStatusKey"];
                            Purse purse = new Purse
                            {
                                PurseIdentifier = reader["AccountBalanceIdentifier"].ToString(),
                                PurseType = (PurseType)(short)reader["AccountBalanceTypeKey"],
                                AvailableBalance = reader["AvailableBalance"] == DBNull.Value
                                    ? 0
                                    : (decimal)reader["AvailableBalance"],
                                LedgerBalance = reader["LedgerBalance"] == DBNull.Value
                                    ? 0
                                    : (decimal)reader["LedgerBalance"],
                                AvailableBalanceAsOfDateTime = reader["AvailableBalanceAsOfDate"] == DBNull.Value
                                    ? DateTime.Now
                                    : (DateTime?)reader["AvailableBalanceAsOfDate"],
                                LedgerBalanceAsOfDateTime = reader["LedgerBalanceAsOfDate"] == DBNull.Value
                                    ? DateTime.Now
                                    : (DateTime?)reader["LedgerBalanceAsOfDate"],
                                PurseDescription = reader["UserDescription"] == DBNull.Value
                                    ? null
                                    : reader["UserDescription"].ToString(),
                                Status = (PurseStatus)purseStatusKey
                            };

                            getEnrollmentResponse.Account.Purses.Add(purse);
                        }
                    }

                    if (getEnrollmentResponse.Account.Purses.Count == 0)
                        getEnrollmentResponse.Account.Purses = null;

                    reader.NextResult();

                    Dictionary<long, string> ahKeyIdentifier = new Dictionary<long, string>();
                    while (reader.Read())
                    {
                        if (Convert.ToInt32(reader["ConsumerProfileTypeKey"]) == 1)
                        {
                            User user = new User();
                            var accountHolderKey = Convert.ToInt64(reader["AccountHolderKey"]);
                            AccountHolder accountHolder = new AccountHolder();
                            bool isTransferAutoAccept =
                                reader["IsTransferAutoAccept"] != DBNull.Value &&
                                bool.Parse(reader["IsTransferAutoAccept"].ToString());
                            accountHolder.AccountHolderIdentifier = reader["AccountHolderIdentifier"] == DBNull.Value
                                ? null
                                : reader["AccountHolderIdentifier"].ToString();
                            user.PeerTransferAcceptPreference = isTransferAutoAccept == false ? "manual" : "automatic";
                            user.UserIdentifier = reader["ConsumerProfileIdentifier"].ToString();
                            user.ConsumerProfileKey = reader.GetInt64(reader.GetOrdinal("ConsumerProfileKey"));
                            user.FirstName = reader["FirstName"] == DBNull.Value
                                ? string.Empty
                                : reader["FirstName"].ToString();
                            user.LastName = reader["LastName"] == DBNull.Value
                                ? string.Empty
                                : reader["LastName"].ToString();
                            bool isVerified = reader["IsDOBVerified"] == DBNull.Value
                                ? false
                                : Convert.ToBoolean(reader["IsDOBVerified"]);
                            bool isDOBBMatched = reader["IsDOBMatched"] == DBNull.Value
                                ? false
                                : Convert.ToBoolean(reader["IsDOBMatched"]);
                            if (isVerified)
                                user.DobStatus = "verified";
                            else
                                user.DobStatus = isDOBBMatched ? "matched" : "notMatched";
                            user.Status = UserStatus.Active;
                            user.IsPrimaryAccountHolder = reader["IsPrimaryAccountHolder"] != DBNull.Value &&
                                                          (bool)reader["IsPrimaryAccountHolder"];
                            user.DateOfBirth = reader["EncryptedDOB"].ToString();
                            user.SsnSuffux = reader["Last4SSN"] == DBNull.Value ? null : reader["Last4SSN"].ToString();
                            user.KycStateData = new KycStateData
                            {
                                OfacStatus = "pending",
                                KycStatus = "pending"
                            };
                            user.KycStateData.PendingKycGate = reader["AccountHolderCureKey"] == DBNull.Value
                                ? "kyc2"
                                : ((Core.Domain.Model.Account.AccountHolderCure)(short)reader["AccountHolderCureKey"])
                                .ToString().ToLower();

                            ahKeyIdentifier.Add(accountHolderKey, accountHolder.AccountHolderIdentifier);
                            accountHolder.User = user;
                            accountHolder.PaymentInstruments = new List<PaymentInstrument>();
                            getEnrollmentResponse.Account.AccountHolders.Add(accountHolder);
                        }
                    }

                    reader.NextResult();

                    while (reader.Read())
                    {
                        var currentKey = Convert.ToInt64(reader["AccountHolderKey"]);
                        if (ahKeyIdentifier.TryGetValue(currentKey, out string currentAHIdentifier))
                        {
                            var currentAccountHolder = getEnrollmentResponse.Account.AccountHolders.Find(ah =>
                                string.Equals(currentAHIdentifier, ah.AccountHolderIdentifier,
                                    StringComparison.InvariantCultureIgnoreCase));

                            if (includeCardData)
                                pan = _tokenizerService.DeTokenizePan(reader["TokenizedPAN"].ToString());

                            if (reader["PaymentInstrumentIdentifier"] != DBNull.Value)
                            {
                                PaymentInstrument paymentInstrument = new PaymentInstrument
                                {
                                    PaymentInstrumentIdentifier = reader["PaymentInstrumentIdentifier"].ToString(),
                                    PaymentIdentifier = reader["PaymentIdentifier"].ToString(),
                                    PaymentInstrumentType =
                                        (PaymentInstrumentType)(short)reader["PaymentInstrumentTypeKey"],
                                    Status = (PaymentInstrumentStatus)(short)reader["PaymentInstrumentStatusKey"],
                                    IsPinSet = reader["ATMPinSetDate"] != DBNull.Value,
                                    Last4Pan = reader["Last4PAN"].ToString(),
                                    ActivatedDateTime = reader["ActivationDate"] == DBNull.Value
                                        ? null
                                        : (DateTime?)reader["ActivationDate"],
                                    IssuedDateTime = reader["IssuedDateTime"] == DBNull.Value
                                        ? DateTime.Now
                                        : (DateTime)reader["IssuedDateTime"],
                                    PaymentInstrumentStatusReason =
                                        reader.IsDBNull(reader.GetOrdinal("PaymentInstrumentStatusReasonKey"))
                                            ? (PaymentInstrumentStatusReason?)null
                                            : (PaymentInstrumentStatusReason)(short)reader[
                                                "PaymentInstrumentStatusReasonKey"],
                                    PaymentIdentifierStatusReason =
                                        reader.IsDBNull(reader.GetOrdinal("PaymentIdentifierStatusReasonKey"))
                                            ? (PaymentIdentifierStatusReason?)null
                                            : (PaymentIdentifierStatusReason)(short)reader[
                                                "PaymentIdentifierStatusReasonKey"],
                                    CustomCardImageIdentifier = reader["CustomCardImageIdentifier"] == DBNull.Value
                                        ? null
                                        : reader["CustomCardImageIdentifier"].ToString(),
                                    IsTemp = reader["IsTemp"] != DBNull.Value && (bool)reader["IsTemp"]
                                };

                                if ((programCode == "gbr" || programCode == "chirp") &&
                                    Configuration.Current.RetailCardProductCode.Contains(getEnrollmentResponse.Account
                                        .ProductCode))
                                {
                                    bool? IsTemp = reader["IsTemp"] == DBNull.Value ? null : (bool?)reader["IsTemp"];

                                    if (IsTemp.HasValue && IsTemp == true)
                                        paymentInstrument.PaymentInstrumentLevel = PaymentInstrumentLevel.NonPersonalized;
                                    else
                                        paymentInstrument.PaymentInstrumentLevel = PaymentInstrumentLevel.Personalized;
                                }
                                else paymentInstrument.PaymentInstrumentLevel = null;


                                paymentInstrument.ActivatedDateTime =
                                    paymentInstrument.ActivatedDateTime?.ToUniversalTime();
                                paymentInstrument.IssuedDateTime = paymentInstrument.IssuedDateTime?.ToUniversalTime();



                                if (includeCardData && _baasConfiguration.IsPinSetNeed(programCode, paymentInstrument.IsPinSet.Value))
                                {
                                    paymentInstrument.PrivateCardData = new PrivateCardData
                                    {
                                        Pan = pan,
                                        Cvv = null,

                                        ExpirationDate = new CardExpirationDate()
                                    };
                                    paymentInstrument.PrivateCardData.ExpirationDate.CardExpirationMonth =
                                        reader["EncryptedExpirationDate"] == DBNull.Value
                                            ? ""
                                            : reader["EncryptedExpirationDate"].ToString().Substring(0, 2);
                                    paymentInstrument.PrivateCardData.ExpirationDate.CardExpirationyear =
                                        reader["EncryptedExpirationDate"] == DBNull.Value
                                            ? ""
                                            : reader["EncryptedExpirationDate"].ToString().Substring(2, 4);
                                }

                                PaymentIdentifierStatus pIdStatus =
                                    (PaymentIdentifierStatus)(short)reader["PaymentIdentifierStatusKey"];
                                paymentInstrument.Status =
                                    StatusMapper.GetPaymentInstrumentStatus(pIdStatus, paymentInstrument.Status);
                                paymentInstrument.PaymentInstrumentStatusReasons =
                                    StatusMapper.GetPaymentInstrumentStatusReasons(pIdStatus, paymentInstrument.Status,
                                        paymentInstrument.PaymentInstrumentStatusReason,
                                        paymentInstrument.PaymentIdentifierStatusReason);


                                // initialize to "false"
                                paymentInstrument.IsPrivateDataViewable = "false";

                                if (paymentInstrument.PaymentInstrumentType == PaymentInstrumentType.Virtual
                                    && paymentInstrument.Status == PaymentInstrumentStatus.Activated
                                    && _baasConfiguration.IsPinSetNeed(programCode, paymentInstrument.IsPinSet.Value)
                                    && _baasConfiguration.IsPrivateDataViewable(programCode,
                                        paymentInstrument.IssuedDateTime)
                                    && _baasConfiguration.IsCvvViewable(programCode,
                                        paymentInstrument.IssuedDateTime))
                                {
                                    paymentInstrument.IsPrivateDataViewable = "true";
                                }

                                if (reader.HasColumn("bin"))
                                {
                                    paymentInstrument.PaymentIdentifierBin = reader["bin"].Cast<string>();
                                }

                                currentAccountHolder.PaymentInstruments.Add(paymentInstrument);
                            }
                        }
                    }

                    foreach (var ah in getEnrollmentResponse.Account.AccountHolders)
                    {
                        if (ah.PaymentInstruments.Count == 0)
                        {
                            ah.PaymentInstruments = null;
                        }
                    }

                    GetAccountInfo(reader, getEnrollmentResponse, ahKeyIdentifier, accountProductKey);

                    reader.NextResult();
                    var userProfileIdentities = ReadUserProfileIdentities(reader);
                    foreach (var accountHolder in getEnrollmentResponse.Account.AccountHolders)
                    {
                        var identity = userProfileIdentities
                            .FindAll(u => u.ConsumerProfileKey == accountHolder.User.ConsumerProfileKey && u.IdentityType != IdentityType.EIN)
                            .OrderByDescending(c => c.CreateDateUtc).FirstOrDefault();
                        accountHolder.SsnToken = identity?.IdentityToken;
                        if (null != identity && identity.IdentityType != 0)
                        {
                            accountHolder.User.IdentityType = identity.IdentityType;
                            accountHolder.User.Last4Identity = identity.Last4Identity;
                        }
                        else
                        {
                            accountHolder.User.IdentityType = null;
                            accountHolder.User.Last4Identity = null;
                        }

                        // https://pd/browse/GBOS-29170 - Uncomment this
                        //if (!accountHolder.User.KycStateData.KycStatus.Equals("passed",
                        //        StringComparison.InvariantCultureIgnoreCase) ||
                        //    !accountHolder.User.KycStateData.OfacStatus.Equals("passed",
                        //        StringComparison.InvariantCultureIgnoreCase))
                        //{
                        //    if (accountHolder.User.KycStateData.PendingKycGate.Equals("none",
                        //        StringComparison.InvariantCultureIgnoreCase))
                        //    {
                        //        if (accountHolder.PaymentInstruments == null || accountHolder.PaymentInstruments.Count == 0)
                        //            accountHolder.User.Status = "regFailedNoCure";
                        //        else
                        //            accountHolder.User.Status = "undefined"; //out of scope in GBOS-27104
                        //    }
                        //    else if (accountHolder.User.KycStateData.PendingKycGate.Equals("healthy",
                        //        StringComparison.InvariantCultureIgnoreCase))
                        //    {
                        //        accountHolder.User.Status = "notAllowed";
                        //    }
                        //    else
                        //    {
                        //        if (accountHolder.PaymentInstruments == null || accountHolder.PaymentInstruments.Count == 0)
                        //            accountHolder.User.Status = "pending";
                        //        else
                        //            accountHolder.User.Status = "undefined"; //out of scope in GBOS-27104
                        //    }
                        //}
                        //else if (accountHolder.User.KycStateData.KycStatus.Equals("passed",
                        //                StringComparison.InvariantCultureIgnoreCase) &&
                        //            accountHolder.User.KycStateData.OfacStatus.Equals("passed",
                        //                StringComparison.InvariantCultureIgnoreCase))
                        //{
                        //    if (accountHolder.PaymentInstruments == null || accountHolder.PaymentInstruments.Count == 0)
                        //    {
                        //        if (accountHolder.User.KycStateData.PendingKycGate.Equals("healthy",
                        //            StringComparison.InvariantCultureIgnoreCase))
                        //        {
                        //            accountHolder.User.Status = "pendingCardCreation";
                        //        }
                        //        else
                        //        {
                        //            accountHolder.User.Status = "notAllowed";
                        //        }
                        //    }
                        //    else
                        //    {
                        //        if (accountHolder.PaymentInstruments.Exists(c =>
                        //            c.Status == PaymentInstrumentStatus.Activated ||
                        //            c.Status == PaymentInstrumentStatus.NotActivated ||
                        //            c.Status == PaymentInstrumentStatus.Blocked))
                        //        {
                        //            accountHolder.User.Status = "active";
                        //        }
                        //        else
                        //        {
                        //            accountHolder.User.Status = "closed";
                        //        }
                        //    }
                        //}
                    }
                }

                return getEnrollmentResponse;
            }
        }

        /// <summary>
        /// GetAccountByAccountIdentifier
        /// </summary>
        /// <param name="accountIdentifier"></param>
        /// <param name="programCode"></param>
        /// <param name="includeCardData"></param>
        /// <returns></returns>
        [ExcludeFromCodeCoverage(Justification = "Converting method to async for perf")]
        public async Task<GetEnrollmentResponse> GetEnrollmentByAccountIdentifierAsync(string accountIdentifier, string programCode,
            bool includeCardData, CancellationToken token)
        {
            GetEnrollmentResponse getEnrollmentResponse = new GetEnrollmentResponse();
            SqlParameter[] parameters;
            string pan = null;

            try
            {
                parameters = new[]
                {
                    new SqlParameter() {ParameterName = "AccountIdentifier", Value = Guid.Parse(accountIdentifier)},
                    new SqlParameter() {ParameterName = "ProgramCode", Value = programCode}
                };
            }
            catch (Exception)
            {
                throw new AccountNotFoundException();
            }

            using (var reader = await _dataAccess.ExecuteReaderAsync("[dbo].[GetAccount]", CommandType.StoredProcedure,
                _dataAccess.CreateConnectionWithColumnEncryption(), token, parameters))
            {
                if (await reader.ReadAsync(token))
                {
                    getEnrollmentResponse.Account = new Account
                    {
                        AccountHolders = new List<AccountHolder>(),
                        AccountIdentifier = reader["AccountIdentifier"].ToString(),
                        Status = ((AccountStatus)(short)reader["AccountStatusKey"]).ToString().ToLower()
                    };


                    DateTime accountStatusDateChange = reader.GetDateTime(reader.GetOrdinal("StatusChangeDate"));
                    accountStatusDateChange = accountStatusDateChange.ToUniversalTime();
                    getEnrollmentResponse.Account.AccountStatusChangedDateTime =
                        accountStatusDateChange.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");

                    getEnrollmentResponse.Account.ProductCode = reader["ProductCode"].ToString();
                    var accountProductKey = Convert.ToInt32(reader["ProductKey"]);
                    int.TryParse(reader["ProductTierKey"]?.ToString(), out int productTierKey);
                    getEnrollmentResponse.Account.ProductTierKey = productTierKey;
                    getEnrollmentResponse.Account.ProductName = reader["ProductName"].ToString();
                    getEnrollmentResponse.Account.DirectDepositInformation = new DirectDepositInformation
                    {
                        AccountNumber = reader["AccountNumber"].ToString(),
                        RoutingNumber = reader["RoutingNumber"].ToString()
                    };
                    getEnrollmentResponse.Account.CustomerReferenceNumber = reader["AccountReferenceNumber"].ToString();
                    getEnrollmentResponse.Account.AccountCycleDay = reader["BillCycleDay"] == DBNull.Value ? (short)0 : (short)reader["BillCycleDay"];
                    getEnrollmentResponse.Account.AccountToken = reader["AccountToken"] == DBNull.Value ? null : reader["AccountToken"].ToString();

                    await reader.NextResultAsync(token);
                    getEnrollmentResponse.Account.Purses = new List<Purse>();

                    while (await reader.ReadAsync(token))
                    {
                        if (reader["AccountBalanceIdentifier"] != DBNull.Value)
                        {
                            getEnrollmentResponse.Account.Currency = reader["CurrencyKey"] == DBNull.Value
                                ? null
                                : ((CurrencyType)(short)reader["CurrencyKey"]).ToString();
                            var purseStatusKey = reader["AccountBalanceStatusKey"] == DBNull.Value
                                ? 1
                                : (short)reader["AccountBalanceStatusKey"];
                            Purse purse = new Purse
                            {
                                PurseIdentifier = reader["AccountBalanceIdentifier"].ToString(),
                                PurseType = (PurseType)(short)reader["AccountBalanceTypeKey"],
                                AvailableBalance = reader["AvailableBalance"] == DBNull.Value
                                    ? 0
                                    : (decimal)reader["AvailableBalance"],
                                LedgerBalance = reader["LedgerBalance"] == DBNull.Value
                                    ? 0
                                    : (decimal)reader["LedgerBalance"],
                                AvailableBalanceAsOfDateTime = reader["AvailableBalanceAsOfDate"] == DBNull.Value
                                    ? DateTime.Now
                                    : (DateTime?)reader["AvailableBalanceAsOfDate"],
                                LedgerBalanceAsOfDateTime = reader["LedgerBalanceAsOfDate"] == DBNull.Value
                                    ? DateTime.Now
                                    : (DateTime?)reader["LedgerBalanceAsOfDate"],
                                PurseDescription = reader["UserDescription"] == DBNull.Value
                                    ? null
                                    : reader["UserDescription"].ToString(),
                                Status = (PurseStatus)purseStatusKey
                            };

                            getEnrollmentResponse.Account.Purses.Add(purse);
                        }
                    }

                    if (getEnrollmentResponse.Account.Purses.Count == 0)
                        getEnrollmentResponse.Account.Purses = null;

                    await reader.NextResultAsync(token);

                    Dictionary<long, string> ahKeyIdentifier = new Dictionary<long, string>();
                    while (await reader.ReadAsync(token))
                    {
                        if (Convert.ToInt32(reader["ConsumerProfileTypeKey"]) == 1)
                        {
                            User user = new User();
                            var accountHolderKey = Convert.ToInt64(reader["AccountHolderKey"]);
                            AccountHolder accountHolder = new AccountHolder();
                            bool isTransferAutoAccept =
                                reader["IsTransferAutoAccept"] != DBNull.Value &&
                                bool.Parse(reader["IsTransferAutoAccept"].ToString());
                            accountHolder.AccountHolderIdentifier = reader["AccountHolderIdentifier"] == DBNull.Value
                                ? null
                                : reader["AccountHolderIdentifier"].ToString();
                            user.PeerTransferAcceptPreference = isTransferAutoAccept == false ? "manual" : "automatic";
                            user.UserIdentifier = reader["ConsumerProfileIdentifier"].ToString();
                            user.ConsumerProfileKey = reader.GetInt64(reader.GetOrdinal("ConsumerProfileKey"));
                            user.FirstName = reader["FirstName"] == DBNull.Value
                                ? string.Empty
                                : reader["FirstName"].ToString();
                            user.LastName = reader["LastName"] == DBNull.Value
                                ? string.Empty
                                : reader["LastName"].ToString();
                            bool isVerified = reader["IsDOBVerified"] == DBNull.Value
                                ? false
                                : Convert.ToBoolean(reader["IsDOBVerified"]);
                            bool isDOBBMatched = reader["IsDOBMatched"] == DBNull.Value
                                ? false
                                : Convert.ToBoolean(reader["IsDOBMatched"]);
                            if (isVerified)
                                user.DobStatus = "verified";
                            else
                                user.DobStatus = isDOBBMatched ? "matched" : "notMatched";
                            user.Status = UserStatus.Active;
                            user.IsPrimaryAccountHolder = reader["IsPrimaryAccountHolder"] != DBNull.Value &&
                                                          (bool)reader["IsPrimaryAccountHolder"];
                            user.DateOfBirth = reader["EncryptedDOB"].ToString();
                            user.SsnSuffux = reader["Last4SSN"] == DBNull.Value ? null : reader["Last4SSN"].ToString();
                            user.KycStateData = new KycStateData
                            {
                                OfacStatus = "pending",
                                KycStatus = "pending"
                            };
                            user.KycStateData.PendingKycGate = reader["AccountHolderCureKey"] == DBNull.Value
                                ? "kyc2"
                                : ((Core.Domain.Model.Account.AccountHolderCure)(short)reader["AccountHolderCureKey"])
                                .ToString().ToLower();

                            ahKeyIdentifier.Add(accountHolderKey, accountHolder.AccountHolderIdentifier);
                            accountHolder.User = user;
                            accountHolder.PaymentInstruments = new List<PaymentInstrument>();
                            getEnrollmentResponse.Account.AccountHolders.Add(accountHolder);
                        }
                    }

                    await reader.NextResultAsync(token);

                    while (await reader.ReadAsync(token))
                    {
                        var currentKey = Convert.ToInt64(reader["AccountHolderKey"]);
                        if (ahKeyIdentifier.TryGetValue(currentKey, out string currentAHIdentifier))
                        {
                            var currentAccountHolder = getEnrollmentResponse.Account.AccountHolders.Find(ah =>
                                string.Equals(currentAHIdentifier, ah.AccountHolderIdentifier,
                                    StringComparison.InvariantCultureIgnoreCase));

                            if (includeCardData)
                                pan = await _tokenizerService.DeTokenizePanAsync(reader["TokenizedPAN"].ToString());

                            if (reader["PaymentInstrumentIdentifier"] != DBNull.Value)
                            {
                                PaymentInstrument paymentInstrument = new PaymentInstrument
                                {
                                    PaymentInstrumentIdentifier = reader["PaymentInstrumentIdentifier"].ToString(),
                                    PaymentIdentifier = reader["PaymentIdentifier"].ToString(),
                                    PaymentInstrumentType =
                                        (PaymentInstrumentType)(short)reader["PaymentInstrumentTypeKey"],
                                    Status = (PaymentInstrumentStatus)(short)reader["PaymentInstrumentStatusKey"],
                                    IsPinSet = reader["ATMPinSetDate"] != DBNull.Value,
                                    Last4Pan = reader["Last4PAN"].ToString(),
                                    ActivatedDateTime = reader["ActivationDate"] == DBNull.Value
                                        ? null
                                        : (DateTime?)reader["ActivationDate"],
                                    IssuedDateTime = reader["IssuedDateTime"] == DBNull.Value
                                        ? DateTime.Now
                                        : (DateTime)reader["IssuedDateTime"],
                                    PaymentInstrumentStatusReason =
                                        reader.IsDBNull(reader.GetOrdinal("PaymentInstrumentStatusReasonKey"))
                                            ? (PaymentInstrumentStatusReason?)null
                                            : (PaymentInstrumentStatusReason)(short)reader[
                                                "PaymentInstrumentStatusReasonKey"],
                                    PaymentIdentifierStatusReason =
                                        reader.IsDBNull(reader.GetOrdinal("PaymentIdentifierStatusReasonKey"))
                                            ? (PaymentIdentifierStatusReason?)null
                                            : (PaymentIdentifierStatusReason)(short)reader[
                                                "PaymentIdentifierStatusReasonKey"],
                                    CustomCardImageIdentifier = reader["CustomCardImageIdentifier"] == DBNull.Value
                                        ? null
                                        : reader["CustomCardImageIdentifier"].ToString(),
                                    IsTemp = reader["IsTemp"] != DBNull.Value && (bool)reader["IsTemp"]
                                };

                                if ((programCode == "gbr" || programCode == "chirp") &&
                                    Configuration.Current.RetailCardProductCode.Contains(getEnrollmentResponse.Account
                                        .ProductCode))
                                {
                                    bool? IsTemp = reader["IsTemp"] == DBNull.Value ? null : (bool?)reader["IsTemp"];

                                    if (IsTemp.HasValue && IsTemp == true)
                                        paymentInstrument.PaymentInstrumentLevel = PaymentInstrumentLevel.NonPersonalized;
                                    else
                                        paymentInstrument.PaymentInstrumentLevel = PaymentInstrumentLevel.Personalized;
                                }
                                else paymentInstrument.PaymentInstrumentLevel = null;


                                paymentInstrument.ActivatedDateTime =
                                    paymentInstrument.ActivatedDateTime?.ToUniversalTime();
                                paymentInstrument.IssuedDateTime = paymentInstrument.IssuedDateTime?.ToUniversalTime();



                                if (includeCardData && _baasConfiguration.IsPinSetNeed(programCode, paymentInstrument.IsPinSet.Value))
                                {
                                    paymentInstrument.PrivateCardData = new PrivateCardData
                                    {
                                        Pan = pan,
                                        Cvv = null,

                                        ExpirationDate = new CardExpirationDate()
                                    };
                                    paymentInstrument.PrivateCardData.ExpirationDate.CardExpirationMonth =
                                        reader["EncryptedExpirationDate"] == DBNull.Value
                                            ? ""
                                            : reader["EncryptedExpirationDate"].ToString().Substring(0, 2);
                                    paymentInstrument.PrivateCardData.ExpirationDate.CardExpirationyear =
                                        reader["EncryptedExpirationDate"] == DBNull.Value
                                            ? ""
                                            : reader["EncryptedExpirationDate"].ToString().Substring(2, 4);
                                }

                                PaymentIdentifierStatus pIdStatus =
                                    (PaymentIdentifierStatus)(short)reader["PaymentIdentifierStatusKey"];
                                paymentInstrument.Status =
                                    StatusMapper.GetPaymentInstrumentStatus(pIdStatus, paymentInstrument.Status);
                                paymentInstrument.PaymentInstrumentStatusReasons =
                                    StatusMapper.GetPaymentInstrumentStatusReasons(pIdStatus, paymentInstrument.Status,
                                        paymentInstrument.PaymentInstrumentStatusReason,
                                        paymentInstrument.PaymentIdentifierStatusReason);


                                // initialize to "false"
                                paymentInstrument.IsPrivateDataViewable = "false";

                                if (paymentInstrument.PaymentInstrumentType == PaymentInstrumentType.Virtual
                                    && paymentInstrument.Status == PaymentInstrumentStatus.Activated
                                    && _baasConfiguration.IsPinSetNeed(programCode, paymentInstrument.IsPinSet.Value)
                                    && _baasConfiguration.IsPrivateDataViewable(programCode,
                                        paymentInstrument.IssuedDateTime)
                                    && _baasConfiguration.IsCvvViewable(programCode,
                                        paymentInstrument.IssuedDateTime))
                                {
                                    paymentInstrument.IsPrivateDataViewable = "true";
                                }

                                currentAccountHolder.PaymentInstruments.Add(paymentInstrument);
                            }
                        }
                    }

                    foreach (var ah in getEnrollmentResponse.Account.AccountHolders)
                    {
                        if (ah.PaymentInstruments.Count == 0)
                        {
                            ah.PaymentInstruments = null;
                        }
                    }

                    await GetAccountInfoAsync(reader, getEnrollmentResponse, ahKeyIdentifier, accountProductKey, token);

                    await reader.ReadAsync(token);
                    var userProfileIdentities = await ReadUserProfileIdentitiesAsync(reader, token);
                    foreach (var accountHolder in getEnrollmentResponse.Account.AccountHolders)
                    {
                        var identity = userProfileIdentities
                            .FindAll(u => u.ConsumerProfileKey == accountHolder.User.ConsumerProfileKey && u.IdentityType != IdentityType.EIN)
                            .OrderByDescending(c => c.CreateDateUtc).FirstOrDefault();
                        accountHolder.SsnToken = identity?.IdentityToken;
                        if (null != identity && identity.IdentityType != 0)
                        {
                            accountHolder.User.IdentityType = identity.IdentityType;
                            accountHolder.User.Last4Identity = identity.Last4Identity;
                        }
                        else
                        {
                            accountHolder.User.IdentityType = null;
                            accountHolder.User.Last4Identity = null;
                        }
                    }
                }
                return getEnrollmentResponse;
            }
        }

        /// <summary>
        /// ReadUserProfileIdentitiesAsync
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        [ExcludeFromCodeCoverage(Justification = "Converting method to async for perf")]
        private async Task<List<Core.Domain.Model.User.UserProfileIdentity>> ReadUserProfileIdentitiesAsync(SqlDataReader reader, CancellationToken token)
        {
            var userProfileIdentities = new List<Core.Domain.Model.User.UserProfileIdentity>();
            while (await reader.ReadAsync(token))
            {
                var userProfileIdentity = new Core.Domain.Model.User.UserProfileIdentity
                {
                    ConsumerProfileKey = reader.GetInt64(reader.GetOrdinal("ConsumerProfileKey")),
                    IdentityToken = reader.GetString(reader.GetOrdinal("IdentityToken")),
                    Last4Identity = reader["Last4Identity"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Last4Identity")),
                    IdentityType = (IdentityType)(short)reader["IdentityTypeKey"],
                    CreateDateUtc = reader.GetDateTime(reader.GetOrdinal("CreateDate"))
                };

                userProfileIdentities.Add(userProfileIdentity);
            }

            return userProfileIdentities;
        }


        private List<Core.Domain.Model.User.UserProfileIdentity> ReadUserProfileIdentities(IDataReader reader)
        {
            // TODO please do not use or modify this method. Please use or modify the same method in GBOS-RH-RequestHandler\Gd.Bos.RequestHandler.Core\Infrastructure\AccountRepository.cs file. Current method need refactor later.

            var userProfileIdentities = new List<Core.Domain.Model.User.UserProfileIdentity>();
            while (reader.Read())
            {
                var userProfileIdentity = new Core.Domain.Model.User.UserProfileIdentity
                {
                    ConsumerProfileKey = reader.GetInt64(reader.GetOrdinal("ConsumerProfileKey")),
                    IdentityToken = reader.GetString(reader.GetOrdinal("IdentityToken")),
                    Last4Identity = reader["Last4Identity"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Last4Identity")),
                    IdentityType = (IdentityType)(short)reader["IdentityTypeKey"],
                    CreateDateUtc = reader.GetDateTime(reader.GetOrdinal("CreateDate"))
                };

                userProfileIdentities.Add(userProfileIdentity);
            }

            return userProfileIdentities;
        }

        /// <summary>
        /// GetAccountInfo
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="getEnrollmentResponse"></param>
        /// <returns></returns>
        private void GetAccountInfo(IDataReader reader, GetEnrollmentResponse getEnrollmentResponse, Dictionary<long, string> ahKeyIdentifier, int accountProductKey)
        {
            // TODO please do not use or modify this method. Please use or modify the same method in GBOS-RH-RequestHandler\Gd.Bos.RequestHandler.Core\Infrastructure\AccountRepository.cs file. Current method need refactor later.

            reader.NextResult();

            getEnrollmentResponse.Account.StatusReasons = new List<string>();
            while (reader.Read())
            {
                getEnrollmentResponse.Account.StatusReasons.Add(
                    ((Core.Domain.Model.Account.AccountStatusReason)(short)reader["AccountStatusReasonKey"])
                    .ToString());
            }

            if (getEnrollmentResponse.Account.StatusReasons.Count == 0)
                getEnrollmentResponse.Account.StatusReasons = null;

            reader.NextResult();
            Dictionary<long, string> verificationKeyIdentifier = new Dictionary<long, string>();
            var requestTriggerTypes = new Dictionary<long, TriggerType>();
            while (reader.Read())
            {
                var verificationRequestKey = Convert.ToInt64(reader["VerificationRequestKey"]);
                requestTriggerTypes[verificationRequestKey] = (TriggerType)Convert.ToInt16(reader["VerificationTriggerTypeKey"]);
                var accountHolderKey = Convert.ToInt64(reader["AccountHolderKey"]);
                if (ahKeyIdentifier.TryGetValue(accountHolderKey, out string currentAHIdentifier))
                {
                    verificationKeyIdentifier.Add(verificationRequestKey, currentAHIdentifier);
                }
            }

            reader.NextResult();
            while (reader.Read())
            {
                var verificationRequestKey = Convert.ToInt64(reader["VerificationRequestKey"]);
                var isUpgrade = requestTriggerTypes[verificationRequestKey] == TriggerType.AccountUpgrade;
                if (isUpgrade)
                {
                    if (getEnrollmentResponse.Account.UpgradeKycStateData == null)
                    {
                        getEnrollmentResponse.Account.UpgradeKycStateData = new ContractKycStateData();
                    }
                    var activityType = (VerificationActivityType)Convert.ToInt16(reader["VerificationActivityTypeKey"]);
                    var status = (VerificationStatus)Convert.ToInt16(reader["VerificationActivityStatusKey"]);
                    switch (activityType)
                    {
                        case VerificationActivityType.KYC:
                            getEnrollmentResponse.Account.UpgradeKycStateData.KycStatus = status.ToString().ToLower();
                            break;
                        case VerificationActivityType.OFAC:
                            getEnrollmentResponse.Account.UpgradeKycStateData.OfacStatus = status.ToString().ToLower();
                            break;
                        case VerificationActivityType.IDV:
                            if (status == VerificationStatus.Passed)
                                getEnrollmentResponse.Account.UpgradeKycStateData.KycStatus = VerificationStatus.Passed.ToString().ToLower();
                            break;
                    }
                }
                else
                {
                    if (verificationKeyIdentifier.TryGetValue(verificationRequestKey, out string accountHolderIdentifier))
                    {
                        var ah = getEnrollmentResponse.Account.AccountHolders.FirstOrDefault(p => string.Equals(accountHolderIdentifier, p.AccountHolderIdentifier,
                            StringComparison.InvariantCultureIgnoreCase));
                        if (ah != null)
                        {
                            string idvStatus = string.Empty;
                            if (reader["VerificationActivityTypeKey"] != DBNull.Value)
                            {
                                if (Convert.ToInt32(reader["VerificationActivityTypeKey"]) == 2)
                                {
                                    ah.User.KycStateData.OfacStatus =
                                        ((Core.Domain.Model.Account.VerificationStatus)(short)Convert.ToInt32(
                                            reader["VerificationActivityStatusKey"])).ToString().ToLower();
                                }
                                else if (Convert.ToInt32(reader["VerificationActivityTypeKey"]) == 1 ||
                                         Convert.ToInt32(reader["VerificationActivityTypeKey"]) == 11)
                                {
                                    ah.User.KycStateData.KycStatus =
                                        ((Core.Domain.Model.Account.VerificationStatus)(short)Convert.ToInt32(
                                            reader["VerificationActivityStatusKey"])).ToString().ToLower();
                                }
                                else if (Convert.ToInt32(reader["VerificationActivityTypeKey"]) == 5)
                                {
                                    idvStatus =
                                        ((Core.Domain.Model.Account.VerificationStatus)(short)Convert.ToInt32(
                                            reader["VerificationActivityStatusKey"])).ToString().ToLower();
                                }
                            }

                            if (ah.User.KycStateData.KycStatus == "failed" && idvStatus == "passed")
                            {
                                ah.User.KycStateData.KycStatus = "passed";
                            }
                        }
                    }
                }
            }

            reader.NextResult();
            getEnrollmentResponse.Account.TermsAcceptances = new List<TermsAcceptance>();
            while (reader.Read())
            {
                if (reader["IsPrimaryAccountHolder"].Cast<bool>())
                {
                    var brandAgreementTypeIdentifier = reader["BrandAgreementTypeIdentifier"].Cast<string>().Trim();
                    var optOutDate = reader["OptOutDate"].Cast<DateTime?>();
                    var acceptanceDate = reader["AcceptanceDate"].Cast<DateTime>().ToUniversalTime();
                    var hasAccepted = optOutDate == null;
                    if (accountProductKey != Convert.ToInt32(reader["ProductKey"]) && !hasAccepted)
                        continue;
                    getEnrollmentResponse.Account.TermsAcceptances.Add(
                        new TermsAcceptance
                        {
                            TermsIdentifier = brandAgreementTypeIdentifier,
                            TermsAcceptanceDateTime = acceptanceDate.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
                            TermsAcceptanceFlag = hasAccepted
                        });
                }
            }

            //reader.NextResult();

            //foreach (var ah in getEnrollmentResponse.Account.AccountHolders)
            //{
            //    ah.SsnToken = _accountRepository.ReadUserProfileIdentity(reader)?.IdentityToken;
            //}
        }

        /// <summary>
        /// GetAccountInfoAsync
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="getEnrollmentResponse"></param>
        /// <param name="ahKeyIdentifier"></param>
        /// <param name="accountProductKey"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        [ExcludeFromCodeCoverage(Justification = "Converting method to async for perf")]
        private async Task GetAccountInfoAsync(SqlDataReader reader, GetEnrollmentResponse getEnrollmentResponse, Dictionary<long, string> ahKeyIdentifier, int accountProductKey, CancellationToken token)
        {
            await reader.NextResultAsync(token);

            getEnrollmentResponse.Account.StatusReasons = new List<string>();
            while (await reader.ReadAsync(token))
            {
                getEnrollmentResponse.Account.StatusReasons.Add(
                    ((Core.Domain.Model.Account.AccountStatusReason)(short)reader["AccountStatusReasonKey"])
                    .ToString());
            }

            if (getEnrollmentResponse.Account.StatusReasons.Count == 0)
                getEnrollmentResponse.Account.StatusReasons = null;

            await reader.NextResultAsync(token);
            Dictionary<long, string> verificationKeyIdentifier = new Dictionary<long, string>();
            var requestTriggerTypes = new Dictionary<long, TriggerType>();
            while (await reader.ReadAsync(token))
            {
                var verificationRequestKey = Convert.ToInt64(reader["VerificationRequestKey"]);
                requestTriggerTypes[verificationRequestKey] = (TriggerType)Convert.ToInt16(reader["VerificationTriggerTypeKey"]);
                var accountHolderKey = Convert.ToInt64(reader["AccountHolderKey"]);
                if (ahKeyIdentifier.TryGetValue(accountHolderKey, out string currentAHIdentifier))
                {
                    verificationKeyIdentifier.Add(verificationRequestKey, currentAHIdentifier);
                }
            }

            await reader.NextResultAsync(token);
            while (await reader.ReadAsync(token))
            {
                var verificationRequestKey = Convert.ToInt64(reader["VerificationRequestKey"]);
                var isUpgrade = requestTriggerTypes[verificationRequestKey] == TriggerType.AccountUpgrade;
                if (isUpgrade)
                {
                    if (getEnrollmentResponse.Account.UpgradeKycStateData == null)
                    {
                        getEnrollmentResponse.Account.UpgradeKycStateData = new ContractKycStateData();
                    }
                    var activityType = (VerificationActivityType)Convert.ToInt16(reader["VerificationActivityTypeKey"]);
                    var status = (VerificationStatus)Convert.ToInt16(reader["VerificationActivityStatusKey"]);
                    switch (activityType)
                    {
                        case VerificationActivityType.KYC:
                            getEnrollmentResponse.Account.UpgradeKycStateData.KycStatus = status.ToString().ToLower();
                            break;
                        case VerificationActivityType.OFAC:
                            getEnrollmentResponse.Account.UpgradeKycStateData.OfacStatus = status.ToString().ToLower();
                            break;
                        case VerificationActivityType.IDV:
                            if (status == VerificationStatus.Passed)
                                getEnrollmentResponse.Account.UpgradeKycStateData.KycStatus = VerificationStatus.Passed.ToString().ToLower();
                            break;
                    }
                }
                else
                {
                    if (verificationKeyIdentifier.TryGetValue(verificationRequestKey, out string accountHolderIdentifier))
                    {
                        var ah = getEnrollmentResponse.Account.AccountHolders.FirstOrDefault(p => string.Equals(accountHolderIdentifier, p.AccountHolderIdentifier,
                            StringComparison.InvariantCultureIgnoreCase));
                        if (ah != null)
                        {
                            string idvStatus = string.Empty;
                            if (reader["VerificationActivityTypeKey"] != DBNull.Value)
                            {
                                if (Convert.ToInt32(reader["VerificationActivityTypeKey"]) == 2)
                                {
                                    ah.User.KycStateData.OfacStatus =
                                        ((Core.Domain.Model.Account.VerificationStatus)(short)Convert.ToInt32(
                                            reader["VerificationActivityStatusKey"])).ToString().ToLower();
                                }
                                else if (Convert.ToInt32(reader["VerificationActivityTypeKey"]) == 1 ||
                                         Convert.ToInt32(reader["VerificationActivityTypeKey"]) == 11)
                                {
                                    ah.User.KycStateData.KycStatus =
                                        ((VerificationStatus)(short)Convert.ToInt32(
                                            reader["VerificationActivityStatusKey"])).ToString().ToLower();
                                }
                                else if (Convert.ToInt32(reader["VerificationActivityTypeKey"]) == 5)
                                {
                                    idvStatus =
                                        ((VerificationStatus)(short)Convert.ToInt32(
                                            reader["VerificationActivityStatusKey"])).ToString().ToLower();
                                }
                            }

                            if (ah.User.KycStateData.KycStatus == "failed" && idvStatus == "passed")
                            {
                                ah.User.KycStateData.KycStatus = "passed";
                            }
                        }
                    }
                }
            }

            await reader.NextResultAsync(token);
            getEnrollmentResponse.Account.TermsAcceptances = new List<TermsAcceptance>();
            while (await reader.ReadAsync(token))
            {
                if (reader["IsPrimaryAccountHolder"].Cast<bool>())
                {
                    var brandAgreementTypeIdentifier = reader["BrandAgreementTypeIdentifier"].Cast<string>().Trim();
                    var optOutDate = reader["OptOutDate"].Cast<DateTime?>();
                    var acceptanceDate = reader["AcceptanceDate"].Cast<DateTime>().ToUniversalTime();
                    var hasAccepted = optOutDate == null;
                    if (accountProductKey != Convert.ToInt32(reader["ProductKey"]) && !hasAccepted)
                        continue;
                    getEnrollmentResponse.Account.TermsAcceptances.Add(
                        new TermsAcceptance
                        {
                            TermsIdentifier = brandAgreementTypeIdentifier,
                            TermsAcceptanceDateTime = acceptanceDate.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
                            TermsAcceptanceFlag = hasAccepted
                        });
                }
            }
        }


        public ExternalProcessor GetProcessorByProductCode(string productCode)
        {
            SqlParameter[] parameters = new[]
            {
                new SqlParameter() {ParameterName = "ProductCode", Value = productCode}
            };

            ExternalProcessor processor = ExternalProcessor.Pts;

            using (SqlDataReader reader = (SqlDataReader)_dataAccess.ExecuteReader("[dbo].[GetProcessorByProductCode]",
                _dataAccess.CreateConnectionWithColumnEncryption(), parameters))
            {
                if (!reader.HasRows)
                {
                    throw new AccountNotFoundException($"No rows returned in GetProcessorByProductCode for product code: {productCode}.");
                }
                while (reader.Read())
                {
                    processor = (ExternalProcessor)Enum.Parse(typeof(ExternalProcessor), reader["ProcessorKey"].ToString());
                }
            }
            return processor;
        }
    }
}
