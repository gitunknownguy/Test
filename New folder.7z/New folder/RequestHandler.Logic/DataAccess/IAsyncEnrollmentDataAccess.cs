﻿using System.Threading;
using System.Threading.Tasks;
using Gd.Bos.Dcpp.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;

namespace Gd.Bos.RequestHandler.Logic.DataAccess
{
    public interface IAsyncEnrollmentDataAccess
    {
        Task<GetEnrollmentResponse> GetEnrollmentByAccountIdentifier(string accountIdentifier, string programCode, bool includeCardData);

        Task<ExternalProcessor> GetProcessorByProductCode(string productCode);
    }
}
