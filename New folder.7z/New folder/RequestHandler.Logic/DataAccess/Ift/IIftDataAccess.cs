﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Services.ExternalCard;



namespace Gd.Bos.RequestHandler.Logic.DataAccess
{
    public interface IIftDataAccess
    {
        //string ConnectionString { get; set; }
        BinDetail GetBinDetail(string requestBin);
    }
}
