﻿using System;
using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.RequestHandler.Core.Domain.Services.ExternalCard;
using NLog;
using Microsoft.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;


namespace Gd.Bos.RequestHandler.Logic.DataAccess
{
    public class IftDataAccess : IIftDataAccess
    {

        public IftDataAccess(IDataAccess dataAccess)
        {
            _dataAccess = dataAccess;
        }

        public BinDetail GetBinDetail(string requestBin)
        {
            BinDetail res = new BinDetail();
            SqlParameter[] param = new[]
            {
                new SqlParameter() { ParameterName = "BIN", Value = requestBin.ToString() }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetBinDetail]", _dataAccess.CreateConnectionWithColumnEncryption(), param))
            {
                if (!reader.Read()) return null;

                res.BankName = reader["IssuerBankName"].ToString();
                res.BIN = reader["BIN"].ToString();
                res.CountryCode = reader["CountryCode"].ToString();
                res.DetailCardIndicator = reader["DetailCardIndicator"].ToString();
                res.DetailCardProduct = reader["DetailCardProduct"].ToString();
                res.CardType = reader["CardType"].ToString();
                res.IsFastFundCapable = reader["IsFastFundCapable"].ToString();
                return res;
            }
        }

        private readonly IDataAccess _dataAccess;
    }
}
