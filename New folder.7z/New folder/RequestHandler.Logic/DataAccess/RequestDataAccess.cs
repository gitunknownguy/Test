﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;
using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.Shared.Common.Caching;
using Gd.Bos.RequestHandler.Core.Utils;

namespace Gd.Bos.RequestHandler.Logic.DataAccess
{
    public class RequestDataAccess : IRequestDataAccess
    {
        public RequestDataAccess(IDataAccess dataAccess)
        {
            _dataAccess = dataAccess;
        }

        public Guid? InsertRequestId(RequestType requestType, Guid requestId, Guid accountIdentifier, Guid? verificationIdentifier)
        {
            SqlParameter[] parameters = null;
            Guid? returnValue = null;

            parameters = new[]
            {
                new SqlParameter() { ParameterName = "ChangeBy", SqlDbType = SqlDbType.NVarChar, Size = 200, Value = _userName },
                new SqlParameter() { ParameterName = "RequestId", SqlDbType = SqlDbType.UniqueIdentifier, Value = requestId },
                new SqlParameter() { ParameterName = "RequestTypeKey", SqlDbType = SqlDbType.SmallInt, Value = (short)requestType },
                new SqlParameter() { ParameterName = "AccountIdentifier", SqlDbType = SqlDbType.UniqueIdentifier, Value = accountIdentifier },
                new SqlParameter() { ParameterName = "VerificationIdentifier", SqlDbType = SqlDbType.UniqueIdentifier, Value = verificationIdentifier }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[InsRequest]", _dataAccess.CreateConnection(), parameters))
            {
                reader.Read();

                if (reader.GetInt32(reader.GetOrdinal("AlreadyExists")) == 1)
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        if (reader.GetName(i) == "VerificationIdentifier")
                        {
                            if (!reader.IsDBNull(reader.GetOrdinal("VerificationIdentifier")))
                                returnValue = reader.GetGuid(reader.GetOrdinal("VerificationIdentifier"));

                            break;
                        }
                    }

                    if (returnValue == null)
                    {
                        returnValue = reader.GetGuid(reader.GetOrdinal("AccountIdentifier"));
                    }
                }
            }

            return returnValue;
        }

        public BoolWrapper ValidateProgramCode(Core.Domain.Model.Account.AccountIdentifier accountIdentifier,
            Core.Domain.Model.ProgramCode programCode)
        {
            SqlParameter[] parameters = new[]
            {
                new SqlParameter() { ParameterName = "AccountIdentifier", SqlDbType = SqlDbType.UniqueIdentifier, Value = accountIdentifier.ToGuid()},
                new SqlParameter() { ParameterName = "ProgramCode", SqlDbType = SqlDbType.NVarChar, Size = 20, Value = programCode.ToString()},
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[ValidateProgramCode]", _dataAccess.CreateConnection(), parameters))
            {
                if (reader.Read()) return new BoolWrapper(true);
            }

            return new BoolWrapper(false);
        }

        public BoolWrapper ValidateTokenizedPAN(Core.Domain.Model.Account.AccountIdentifier accountIdentifier, string tokenizedPAN)
        {
            SqlParameter[] parameters = new[]
            {
                new SqlParameter() { ParameterName = "AccountIdentifier", SqlDbType = SqlDbType.UniqueIdentifier, Value = accountIdentifier.ToGuid()},
                new SqlParameter() { ParameterName = "TokenizedPAN", SqlDbType = SqlDbType.NVarChar, Size = 200, Value = tokenizedPAN},
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[ValidateTokenizedPAN]", _dataAccess.CreateConnection(), parameters))
            {
                if (reader.Read()) return new BoolWrapper(true);
            }

            return new BoolWrapper(false);
        }

        public BoolWrapper ValidateConsumerProfileIdentifier(Core.Domain.Model.Account.AccountIdentifier accountIdentifier,
            Core.Domain.Model.User.UserIdentifier userIdentifier)
        {
            SqlParameter[] parameters = new[]
            {
                new SqlParameter() { ParameterName = "AccountIdentifier", SqlDbType = SqlDbType.UniqueIdentifier, Value = accountIdentifier.ToGuid()},
                new SqlParameter() { ParameterName = "ConsumerProfileIdentifier", SqlDbType = SqlDbType.UniqueIdentifier,
                    Size = 200, Value = Guid.Parse(userIdentifier.ToString())},
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[ValidateConsumerProfileIdentifier]", _dataAccess.CreateConnection(), parameters))
            {
                if (reader.Read()) return new BoolWrapper(true);
            }

            return new BoolWrapper(false);
        }

        public BoolWrapper ValidatePaymentInstrumentIdentifier(Core.Domain.Model.Account.AccountIdentifier accountIdentifier,
            Core.Domain.Model.Payment.PaymentInstrumentIdentifier paymentInstrumentIdentifier)
        {
            SqlParameter[] parameters = new[]
            {
                new SqlParameter() { ParameterName = "AccountIdentifier", SqlDbType = SqlDbType.UniqueIdentifier, Value = accountIdentifier.ToGuid()},
                new SqlParameter() { ParameterName = "PaymentInstrumentIdentifier", SqlDbType = SqlDbType.UniqueIdentifier,
                    Size = 200, Value = Guid.Parse(paymentInstrumentIdentifier.ToString())},
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[ValidatePaymentInstrumentIdentifier]", _dataAccess.CreateConnection(), parameters))
            {
                if (reader.Read()) return new BoolWrapper(true);
            }

            return new BoolWrapper(false);
        }

        private readonly IDataAccess _dataAccess;
        private readonly string _userName = IdentityHelper.GetIdentityName();

        private bool ReaderExists(IDataReader dr, string columnName)
        {
            if (dr == null || dr.FieldCount <= 0)
            {
                return false;
            }
            int count = dr.FieldCount;
            for (int i = 0; i < count; i++)
            {
                if (dr.GetName(i).Equals(columnName))
                {
                    return true;
                }
            }
            return false;
        }
    }

}
