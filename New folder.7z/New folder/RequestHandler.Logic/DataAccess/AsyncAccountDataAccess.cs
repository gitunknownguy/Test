﻿using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using System.Data;
using System.Linq;
using Gd.Bos.Shared.Common.Core.Logic.AdjustedBalance.Contract;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.EGift;
using Gd.Bos.RequestHandler.Core.Domain.Model.Interest;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers;
using Gd.Bos.RequestHandler.Logic.Common;
using Gd.Bos.Shared.Common;
using Gd.Bos.Shared.Common.Core.Logic;
using Microsoft.Data.SqlClient.Server;
using TransferType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType;

using VerificationStatus = Gd.Bos.RequestHandler.Core.Domain.Model.Account.VerificationStatus;
using VerificationActivityType = Gd.Bos.RequestHandler.Core.Domain.Model.Account.VerificationActivityType;
using ContractKycStateData = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData;
using TriggerType = Gd.Bos.RequestHandler.Core.Domain.Model.Account.TriggerType;
using VerificationActivity = Gd.Bos.RequestHandler.Core.Domain.Model.Account.VerificationActivity;
using AccountHolderIdentifier = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolderIdentifier;
using RequestHandler.Logic.DataAccess;
using System.Threading.Tasks;
using System.Threading;

namespace Gd.Bos.RequestHandler.Logic.DataAccess
{
    [ExcludeFromCodeCoverage(Justification = "Not tested previously and currently can't be easily mocked and will be taken care of on GBOS-116633")]
    public class AsyncAccountDataAccess : IAsyncAccountDataAccess
    {
        private readonly IDataAccess _dataAccess;
        private readonly ITokenizerService _tokenizerService;
        private readonly IBalanceProvider _balanceProvider;

        private readonly int[] EGiftTransClassKeys = { 93, 95 };
        private readonly string wfProductCode = "50400";

        public AsyncAccountDataAccess(IDataAccess dataAccess, ITokenizerService tokenizerService, IBalanceProvider balanceProvider)
        {
            _dataAccess = dataAccess;
            _tokenizerService = tokenizerService;
            _balanceProvider = balanceProvider;
        }

        /// <summary>
        /// GetAccountByAccountIdentifier
        /// </summary>
        /// <param name="accountIdentifier"></param>
        /// <param name="programCode"></param>
        /// <param name="includeCardData"></param>
        /// <returns></returns>
        public async Task<GetAccountResponse> GetAccountByAccountIdentifier(string accountIdentifier, string programCode, bool includeCardData, bool includeDetails = false)
        {
            GetAccountResponse getAccountResponse = null;
            SqlParameter[] parameters = null;
            string pan = null;

            try
            {
                parameters = new[]
                {
                    new SqlParameter() { ParameterName = "AccountIdentifier",Value = Guid.Parse(accountIdentifier) },
                    new SqlParameter() { ParameterName = "ProgramCode",Value = programCode}
                };
            }
            catch (Exception ex) { throw new AccountNotFoundException(); }

            using var connection = _dataAccess.CreateConnectionWithColumnEncryption();
            using (var reader = await _dataAccess.ExecuteReaderAsync("[dbo].[GetAccount]", CommandType.StoredProcedure,
                connection, default, parameters))
            {
                if (await reader.ReadAsync())
                {
                    getAccountResponse = new GetAccountResponse();
                    getAccountResponse.Account = new Account();
                    getAccountResponse.Account.AccountHolders = new List<AccountHolder>();
                    getAccountResponse.Account.AccountIdentifier = reader["AccountIdentifier"].ToString();
                    getAccountResponse.Account.Status = ((AccountStatus)(short)reader["AccountStatusKey"]).ToString().ToLower();

                    DateTime accountStatusDateChange = reader.GetDateTime(reader.GetOrdinal("StatusChangeDate"));
                    accountStatusDateChange = accountStatusDateChange.ToUniversalTime();
                    getAccountResponse.Account.AccountStatusChangedDateTime =
                        accountStatusDateChange.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");

                    getAccountResponse.Account.ProductCode = reader["ProductCode"].ToString();
                    var accountProductKey = Convert.ToInt32(reader["ProductKey"]);
                    int.TryParse(reader["ProductTierKey"]?.ToString(), out int productTierKey);
                    getAccountResponse.Account.ProductTierKey = productTierKey;
                    getAccountResponse.Account.ProductName = reader["ProductName"].ToString();
                    getAccountResponse.Account.DirectDepositInformation = new DirectDepositInformation();
                    getAccountResponse.Account.DirectDepositInformation.AccountNumber = reader["AccountNumber"].ToString();
                    getAccountResponse.Account.DirectDepositInformation.RoutingNumber = reader["RoutingNumber"].ToString();
                    getAccountResponse.Account.CustomerReferenceNumber = reader["AccountReferenceNumber"].ToString();
                    getAccountResponse.Account.ActivationDate = reader["ActivationDate"] == DBNull.Value ? null
                        : reader.GetDateTime(reader.GetOrdinal("ActivationDate")).ToString("yyyy-MM-ddTHH:mm:ss.fff");
                    getAccountResponse.Account.AccountCycleDay = reader["BillCycleDay"] == DBNull.Value ? (short)0 : (short)reader["BillCycleDay"];
                    getAccountResponse.Account.SystemKey = reader["SystemKey"] == DBNull.Value ? null : (short)reader["SystemKey"];
                    await reader.NextResultAsync();
                    if (await reader.ReadAsync())
                    {
                        getAccountResponse.Account.Currency = reader["CurrencyKey"] == DBNull.Value ? null : ((CurrencyType)(short)reader["CurrencyKey"]).ToString();
                    }

                    await reader.NextResultAsync();

                    getAccountResponse.Account.AccountHolders = new List<AccountHolder>();
                    Dictionary<long, string> ahKeyIdentifier = new Dictionary<long, string>();
                    while (await reader.ReadAsync())
                    {
                        if (Convert.ToInt32(reader["ConsumerProfileTypeKey"]) == 1 || programCode.Equals("credibly", StringComparison.OrdinalIgnoreCase))
                        {
                            User user = new User();
                            var accountHolderKey = Convert.ToInt64(reader["AccountHolderKey"]);
                            user.UserIdentifier = reader["ConsumerProfileIdentifier"].ToString();
                            bool isTransferAutoAccept = reader["IsTransferAutoAccept"] != DBNull.Value && bool.Parse(reader["IsTransferAutoAccept"].ToString());
                            user.PeerTransferAcceptPreference = isTransferAutoAccept == false ? "manual" : "automatic";
                            user.ConsumerProfileKey = reader.GetInt64(reader.GetOrdinal("ConsumerProfileKey"));
                            user.FirstName = reader["FirstName"] == DBNull.Value
                                ? string.Empty
                                : reader["FirstName"].ToString();
                            user.LastName = reader["LastName"] == DBNull.Value
                                ? string.Empty
                                : reader["LastName"].ToString();
                            bool isVerified = reader["IsDOBVerified"] == DBNull.Value
                                ? false
                                : Convert.ToBoolean(reader["IsDOBVerified"]);
                            bool isDOBBMatched = reader["IsDOBMatched"] == DBNull.Value
                                ? false
                                : Convert.ToBoolean(reader["IsDOBMatched"]);
                            if (isVerified)
                                user.DobStatus = "verified";
                            else
                                user.DobStatus = isDOBBMatched ? "matched" : "notMatched";
                            user.Status = UserStatus.Active;
                            user.IsPrimaryAccountHolder = reader["IsPrimaryAccountHolder"] != DBNull.Value &&
                                                          (bool)reader["IsPrimaryAccountHolder"];
                            user.KycStateData = new KycStateData
                            {
                                OfacStatus = "pending",
                                KycStatus = "pending",
                                PendingKycGate = reader["AccountHolderCureKey"] == DBNull.Value
                                    ? "kyc2"
                                    : ((Core.Domain.Model.Account.AccountHolderCure)(short)reader[
                                        "AccountHolderCureKey"]).ToString().ToLower()
                            };

                            AccountHolder accountHolder = new AccountHolder
                            {
                                User = user,
                                AccountHolderIdentifier = reader["AccountHolderIdentifier"].ToString()
                            };
                            accountHolder.PaymentInstruments = new List<PaymentInstrument>();
                            ahKeyIdentifier.Add(accountHolderKey, accountHolder.AccountHolderIdentifier);
                            getAccountResponse.Account.AccountHolders.Add(accountHolder);
                        }
                    }

                    await reader.NextResultAsync();

                    while (await reader.ReadAsync())
                    {
                        var currentKey = Convert.ToInt64(reader["AccountHolderKey"]);
                        if (ahKeyIdentifier.TryGetValue(currentKey, out string currentAHIdentifier))
                        {
                            var currentAccountHolder = getAccountResponse.Account.AccountHolders.Find(ah =>
                                string.Equals(currentAHIdentifier, ah.AccountHolderIdentifier,
                                    StringComparison.InvariantCultureIgnoreCase));

                            if (reader["PaymentInstrumentIdentifier"] != DBNull.Value)
                            {
                                PaymentInstrument paymentInstrument = new PaymentInstrument
                                {
                                    PaymentInstrumentIdentifier = reader["PaymentInstrumentIdentifier"].ToString(),
                                    PaymentIdentifier = reader["PaymentIdentifier"].ToString(),
                                    PaymentInstrumentType =
                                        (PaymentInstrumentType)(short)reader["PaymentInstrumentTypeKey"],
                                    Status = (PaymentInstrumentStatus)(short)reader["PaymentInstrumentStatusKey"],
                                    IsPinSet = reader["ATMPinSetDate"] != DBNull.Value,
                                    Last4Pan = reader["Last4PAN"].ToString(),
                                    ActivatedDateTime = reader["ActivationDate"] == DBNull.Value
                                        ? null
                                        : (DateTime?)reader["ActivationDate"],
                                    IssuedDateTime = reader["IssuedDateTime"] == DBNull.Value
                                        ? DateTime.Now
                                        : (DateTime)reader["IssuedDateTime"],
                                    PaymentInstrumentStatusReason =
                                        reader.IsDBNull(reader.GetOrdinal("PaymentInstrumentStatusReasonKey"))
                                            ? (PaymentInstrumentStatusReason?)null
                                            : (PaymentInstrumentStatusReason)(short)reader[
                                                "PaymentInstrumentStatusReasonKey"],
                                    PaymentIdentifierStatusReason =
                                        reader.IsDBNull(reader.GetOrdinal("PaymentIdentifierStatusReasonKey"))
                                            ? (PaymentIdentifierStatusReason?)null
                                            : (PaymentIdentifierStatusReason)(short)reader[
                                                "PaymentIdentifierStatusReasonKey"],
                                    CustomCardImageIdentifier = reader["CustomCardImageIdentifier"] == DBNull.Value
                                        ? null
                                        : reader["CustomCardImageIdentifier"].ToString()

                                };

                                paymentInstrument.ActivatedDateTime =
                                    paymentInstrument.ActivatedDateTime?.ToUniversalTime();
                                paymentInstrument.IssuedDateTime = paymentInstrument.IssuedDateTime?.ToUniversalTime();

                                PaymentIdentifierStatus pIdStatus =
                                    (PaymentIdentifierStatus)(short)reader["PaymentIdentifierStatusKey"];
                                paymentInstrument.Status =
                                    StatusMapper.GetPaymentInstrumentStatus(pIdStatus, paymentInstrument.Status);
                                paymentInstrument.PaymentInstrumentStatusReasons =
                                    StatusMapper.GetPaymentInstrumentStatusReasons(pIdStatus, paymentInstrument.Status,
                                        paymentInstrument.PaymentInstrumentStatusReason,
                                        paymentInstrument.PaymentIdentifierStatusReason);

                                // initialize to "false"
                                paymentInstrument.IsPrivateDataViewable = "false";

                                currentAccountHolder.PaymentInstruments.Add(paymentInstrument);
                            }
                        }
                    }

                    foreach (var ah in getAccountResponse.Account.AccountHolders)
                    {
                        if (ah.PaymentInstruments.Count == 0)
                        {
                            ah.PaymentInstruments = null;
                        }
                    }

                    await GetAccountInfo(reader, getAccountResponse, ahKeyIdentifier, accountProductKey);

                    await reader.NextResultAsync();
                    var userProfileIdentities = await ReadUserProfileIdentities(reader);
                    foreach (var accountHolder in getAccountResponse.Account.AccountHolders)
                    {
                        var identity = userProfileIdentities
                            .FindAll(u => u.ConsumerProfileKey == accountHolder.User.ConsumerProfileKey && u.IdentityType != IdentityType.EIN)
                            .OrderByDescending(c => c.CreateDateUtc).FirstOrDefault();
                        accountHolder.SsnToken = identity?.IdentityToken;
                        if (null != identity && identity.IdentityType != 0)
                        {
                            accountHolder.User.IdentityType = identity.IdentityType;
                            accountHolder.User.Last4Identity = identity.Last4Identity;
                        }
                        else
                        {
                            accountHolder.User.IdentityType = null;
                            accountHolder.User.Last4Identity = null;
                        }
                    }

                    if (!includeDetails)
                    {
                        foreach (var accountHolder in getAccountResponse.Account.AccountHolders)
                        {
                            accountHolder.PaymentInstruments = null;
                        }
                    }
                }
                return getAccountResponse;
            }
        }

        public long? GetAccountKey(string accountIdentifier, string programCode)
        {
            throw new NotImplementedException();
        }

        public async Task<int?> GetAccountProductTierKey(string accountIdentifier, string programCode)
        {
            var productTierKey = default(int?);
            SqlParameter[] parameters;

            try
            {
                parameters = new[]
                {
                    new SqlParameter { ParameterName = "AccountIdentifier", Value = Guid.Parse(accountIdentifier) }
                };
            }
            catch
            {
                throw new AccountNotFoundException();
            }

            using var connection = _dataAccess.CreateConnectionWithColumnEncryption();
            using (var reader = await _dataAccess.ExecuteReaderAsync("[dbo].[GetAccountByAccountIdentifier]", CommandType.StoredProcedure,
                       connection, default, parameters))
            {
                if (await reader.ReadAsync())
                {
                    productTierKey = (int)reader["ProductTierKey"];
                }

                return productTierKey;
            }
        }

        public string GetAccountToken(string accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public DateTime? GetAccountTransaction(Guid transactionReferenceIdentifier)
        {
            throw new NotImplementedException();
        }

        public Dictionary<Guid, decimal> GetEGiftCashBackTransactionAmounts(string accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public GetPursesResponse GetPurses(string accountIdentifier, string programCode)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// GetAccountInfoAsync
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="getAccountResponse"></param>
        /// <param name="ahKeyIdentifier"></param>
        /// <param name="accountProductKey"></param>
        /// <returns></returns>
        private async Task<GetAccountResponse> GetAccountInfo(SqlDataReader reader, GetAccountResponse getAccountResponse, Dictionary<long, string> ahKeyIdentifier, int accountProductKey)
        {
            await reader.NextResultAsync();

            getAccountResponse.Account.StatusReasons = new List<string>();
            while (await reader.ReadAsync())
            {
                getAccountResponse.Account.StatusReasons.Add(((Core.Domain.Model.Account.AccountStatusReason)(short)reader["AccountStatusReasonKey"]).ToString());
            }

            if (getAccountResponse.Account.StatusReasons.Count == 0)
                getAccountResponse.Account.StatusReasons = null;

            await reader.NextResultAsync();
            var verificationKeyIdentifier = new Dictionary<long, string>();
            var requestTriggerTypes = new Dictionary<long, TriggerType>();
            while (await reader.ReadAsync())
            {
                var verificationRequestKey = Convert.ToInt64(reader["VerificationRequestKey"]);
                requestTriggerTypes[verificationRequestKey] = (TriggerType)Convert.ToInt16(reader["VerificationTriggerTypeKey"]);
                
                if (getAccountResponse.Account.ProductCode != wfProductCode || getAccountResponse.Account.AccountHolders.Count <= 1)
                {
                    continue;
                }

                var accountHolderKey = Convert.ToInt64(reader["AccountHolderKey"]);
                if (ahKeyIdentifier.TryGetValue(accountHolderKey, out string currentAhIdentifier))
                {
                    verificationKeyIdentifier.Add(verificationRequestKey, currentAhIdentifier);
                }
            }
            await reader.NextResultAsync();
            while (await reader.ReadAsync())
            {
                var verificationRequestKey = Convert.ToInt64(reader["VerificationRequestKey"]);
                var isUpgrade = requestTriggerTypes[verificationRequestKey] == TriggerType.AccountUpgrade;
                if (isUpgrade)
                {
                    if (getAccountResponse.Account.UpgradeKycStateData == null)
                    {
                        getAccountResponse.Account.UpgradeKycStateData = new ContractKycStateData();
                    }
                    var activityType = (VerificationActivityType)Convert.ToInt16(reader["VerificationActivityTypeKey"]);
                    var status = (VerificationStatus)Convert.ToInt16(reader["VerificationActivityStatusKey"]);
                    switch (activityType)
                    {
                        case VerificationActivityType.KYC:
                            getAccountResponse.Account.UpgradeKycStateData.KycStatus = status.ToString().ToLower();
                            break;
                        case VerificationActivityType.OFAC:
                            getAccountResponse.Account.UpgradeKycStateData.OfacStatus = status.ToString().ToLower();
                            break;
                        case VerificationActivityType.IDV:
                            if (status == VerificationStatus.Passed)
                                getAccountResponse.Account.UpgradeKycStateData.KycStatus = VerificationStatus.Passed.ToString().ToLower();
                            break;
                    }
                }
                else
                {
                    foreach (var ah in getAccountResponse.Account.AccountHolders)
                    {
                        if (getAccountResponse.Account.ProductCode == wfProductCode
                            && getAccountResponse.Account.AccountHolders.Count > 1 
                            && verificationKeyIdentifier.TryGetValue(verificationRequestKey, out string accountHolderIdentifier)
                            && !string.Equals(ah.AccountHolderIdentifier, accountHolderIdentifier, StringComparison.InvariantCultureIgnoreCase))
                        {
                            continue;
                        }
                        
                        string idvStatus = string.Empty;
                        if (reader["VerificationActivityTypeKey"] != DBNull.Value)
                        {
                            if (Convert.ToInt32(reader["VerificationActivityTypeKey"]) == 2)
                            {
                                ah.User.KycStateData.OfacStatus = ((VerificationStatus)(short)Convert.ToInt32(reader["VerificationActivityStatusKey"])).ToString().ToLower();
                            }
                            else if (Convert.ToInt32(reader["VerificationActivityTypeKey"]) == 1 || Convert.ToInt32(reader["VerificationActivityTypeKey"]) == 11)
                            {
                                ah.User.KycStateData.KycStatus = ((VerificationStatus)(short)Convert.ToInt32(reader["VerificationActivityStatusKey"])).ToString().ToLower();
                            }
                            else if (Convert.ToInt32(reader["VerificationActivityTypeKey"]) == 5)
                            {
                                idvStatus = ((VerificationStatus)(short)Convert.ToInt32(reader["VerificationActivityStatusKey"])).ToString().ToLower();
                            }
                        }

                        if (ah.User.KycStateData.KycStatus == "failed" && idvStatus == "passed")
                        {
                            ah.User.KycStateData.KycStatus = "passed";
                        }
                    }
                }
            }

            await reader.NextResultAsync();
            getAccountResponse.Account.TermsAcceptances = new List<TermsAcceptance>();
            while (await reader.ReadAsync())
            {
                if (reader["IsPrimaryAccountHolder"].Cast<bool>())
                {
                    bool hasAccepted = false;
                    long accountHolderAgreementKey = reader.GetInt64(reader.GetOrdinal("AccountHolderAgreementKey"));
                    string brandAgreementTypeIdentifier = reader["BrandAgreementTypeIdentifier"].ToString().Trim();
                    DateTime acceptanceDate = reader.GetDateTime(reader.GetOrdinal("AcceptanceDate"));
                    acceptanceDate = DateTime.SpecifyKind(acceptanceDate, DateTimeKind.Local);
                    acceptanceDate = acceptanceDate.ToUniversalTime();
                    DateTime? optOutDate = reader.IsDBNull(reader.GetOrdinal("OptOutDate")) ? (DateTime?)null
                        : reader.GetDateTime(reader.GetOrdinal("OptOutDate"));

                    if (optOutDate == null)
                        hasAccepted = true;

                    if (accountProductKey != Convert.ToInt32(reader["ProductKey"]) && !hasAccepted)
                        continue;
                    getAccountResponse.Account.TermsAcceptances.Add(
                        new TermsAcceptance
                        {
                            TermsIdentifier = brandAgreementTypeIdentifier,
                            TermsAcceptanceDateTime = acceptanceDate.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
                            TermsAcceptanceFlag = hasAccepted
                        });
                }

            }
            return getAccountResponse;
        }

        /// <summary>
        /// ReadUserProfileIdentitiesAsync
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        private async Task<List<Core.Domain.Model.User.UserProfileIdentity>> ReadUserProfileIdentities(SqlDataReader reader)
        {
            var userProfileIdentities = new List<Core.Domain.Model.User.UserProfileIdentity>();
            while (await reader.ReadAsync())
            {
                var userProfileIdentity = new Core.Domain.Model.User.UserProfileIdentity
                {
                    ConsumerProfileKey = reader.GetInt64(reader.GetOrdinal("ConsumerProfileKey")),
                    IdentityToken = reader.GetString(reader.GetOrdinal("IdentityToken")),
                    Last4Identity = reader["Last4Identity"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Last4Identity")),
                    IdentityType = (IdentityType)(short)reader["IdentityTypeKey"],
                    CreateDateUtc = reader.GetDateTime(reader.GetOrdinal("CreateDate"))
                };

                userProfileIdentities.Add(userProfileIdentity);
            }
            return userProfileIdentities;
        }
    }
}
