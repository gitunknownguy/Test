﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.DeviceProvisioning;
using RequestHandler.Core.Domain.Model.Payment;

namespace RequestHandler.Logic.DataAccess
{
    public interface IDeviceProvisioningMessageDataAccess
    {
        Task InsertDeviceProvisioningMessage(GetActivationMethodsRequest message, string paymentIdentifierProxy);
        Task InsertDeviceProvisioningMessage(SendPasscodeRequest message, string paymentIdentifierProxy, string notificationChannel);
        List<PaymentIdentifierDeviceInfo> GetPaymentIdentifierDeviceByPaymentIdentifierProxy(string paymentIdentifierProxy, string last4DPAN);
    }
}