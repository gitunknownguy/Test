﻿using System;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using Azure.Messaging.ServiceBus;
using NLog;
using RequestHandler.Core.Domain.Services.AzureServiceBus;

namespace RequestHandler.Logic.Queue;

public class ServiceBusNotificationPublisher(ServiceBusClient client) : IServiceBusNotificationPublisher
{
    private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

    private static readonly JsonSerializerOptions Options = new()
    {
        AllowTrailingCommas = false,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        WriteIndented = false,
        ReadCommentHandling = JsonCommentHandling.Skip
    };

    public async Task PublishHealthCheckMessage(string queueName)
    {
        try
        {
            if (string.IsNullOrEmpty(queueName))
                throw new ArgumentNullException(nameof(queueName));

            var sender = client.CreateSender(queueName);
            var msg = new ServiceBusMessage("Gd.Bos.RequestHandler")
            {
                MessageId = $"test-{Guid.NewGuid()}",
                ContentType = "text/plain",
                Subject = "HealthCheck",
                TimeToLive = TimeSpan.FromMinutes(10)
            };

            await sender.SendMessageAsync(msg);
        }
        catch (Exception e)
        {
            Logger.Error(e, "Azure-Service-Bus: Could not send HealthCheck message");
        }
    }


    public async Task PublishAsync(string queueName, string requestId, string messageName, object message)
    {
        try
        {
            Logger.Debug("Azure-Service-Bus: Sending message to {queueName}", queueName);

            if (string.IsNullOrEmpty(queueName))
                throw new ArgumentNullException(nameof(queueName));

            if (string.IsNullOrEmpty(requestId))
                throw new ArgumentNullException(nameof(requestId));

            if (string.IsNullOrEmpty(messageName))
                throw new ArgumentNullException(nameof(messageName));

            if (message is null)
                throw new ArgumentNullException(nameof(message));

            var sender = client.CreateSender(queueName);
            var serviceBusMessage = new ServiceBusMessage(JsonSerializer.Serialize(message, Options))
            {
                MessageId = requestId, ContentType = "application/json", Subject = messageName
            };

            await sender.SendMessageAsync(serviceBusMessage);

            Logger.Debug("Azure-Service-Bus: Message sent to {queueName}", queueName);
        }
        catch (Exception e)
        {
            Logger.Error(e, "Azure-Service-Bus: Could not send message");
        }
    }
}
