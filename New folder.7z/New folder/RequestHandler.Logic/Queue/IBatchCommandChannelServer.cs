﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Logic.Queue;

namespace RequestHandler.Logic.Queue
{
    public interface IBatchCommandChannelServer : IDisposable
    {
        void SetCommandHandlerFactory(ICommandHandlerFactory factory);
        void Start();
        void Stop();
    }
}
