using System;
using System.Text;
using Newtonsoft.Json;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Logic.Queue;
using NLog;
using RequestHandler.Logic.Queue.JsonRpc.Model;

namespace RequestHandler.Logic.Queue.JsonRpc
{
    public interface IJsonRpcCommandChannelHandler
    {
        Task<JsonRpcResponse<Response>> HandleRequest<Request, Response>(JsonRpcRequest<Request> request);
    }

    public class JsonRpcCommandChannelHandler : IJsonRpcCommandChannelHandler
    {
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        ICommandHandlerFactory _commandHandlerFactory;

        public JsonRpcCommandChannelHandler(ICommandHandlerFactory commandHandlerFactory)
        {
            _commandHandlerFactory = commandHandlerFactory;
        }

        public async Task<JsonRpcResponse<Response>> HandleRequest<Request, Response>(JsonRpcRequest<Request> request)
        {
            try
            {
                _logger.Info("Handling request method = {method} requestId = {requestId}", request.Method, request.Id);
                var handler = _commandHandlerFactory.CreateCommandHandler(request.Method);
                var serializedParams = JsonConvert.SerializeObject(request.Params);
                _logger.Debug("Got handler request method = {method} requestId = {requestId} params = {params}", request.Method, request.Id, serializedParams);
                var requestBodyBytes = Encoding.UTF8.GetBytes(serializedParams);
                var responseBuffer = await handler.HandleAsync(requestBodyBytes);
                var result = Encoding.UTF8.GetString(responseBuffer);
                _logger.Debug("Got handler result method = {method} requestId = {requestId} result = {result}", request.Method, request.Id, result);
                Response deserializedResult = JsonConvert.DeserializeObject<Response>(result);
                return new JsonRpcResponse<Response>
                {
                    JsonRpc = "2.0",
                    Result = deserializedResult,
                    Id = request.Id
                };
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error handling request method = {method} requestId = {requestId}", request.Method, request.Id);
                return new JsonRpcResponse<Response>
                {
                    JsonRpc = "2.0",
                    Error = new JsonRpcError { Code = -32603, Message = ex.Message },
                    Id = request.Id
                };
            }
        }
    }
}
