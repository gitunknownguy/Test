﻿using System;
using Newtonsoft.Json;

namespace RequestHandler.Logic.Queue.JsonRpc.Model
{
    public class JsonRpcRequest<T>
    {
        [JsonProperty("jsonrpc")]
        public string JsonRpc { get; set; } = "2.0";

        [JsonProperty("method")]
        public string Method { get; set; } = string.Empty;

        [JsonProperty("params")]
        public T? Params { get; set; }

        [JsonProperty("id")]
        public object Id { get; set; } = Guid.NewGuid();
    }
}
