﻿using Newtonsoft.Json;

namespace RequestHandler.Logic.Queue.JsonRpc.Model
{
    public class JsonRpcSuccessResponse<T>
    {
        [JsonProperty("jsonrpc")]
        public string JsonRpc { get; set; } = "2.0";

        [JsonProperty("result")]
        public T Result { get; set; }

        [JsonProperty("id")]
        public object Id { get; set; }
    }

}
