﻿using Newtonsoft.Json;

namespace RequestHandler.Logic.Queue.JsonRpc.Model
{
    public class JsonRpcErrorResponse
    {
        [JsonProperty("jsonrpc")]
        public string JsonRpc { get; set; } = "2.0";

        [JsonProperty("error")]
        public JsonRpcError Error { get; set; }

        [JsonProperty("id")]
        public object? Id { get; set; }
    }
}
