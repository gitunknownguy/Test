﻿using Newtonsoft.Json;

namespace RequestHandler.Logic.Queue.JsonRpc.Model
{
    public class JsonRpcResponse<T>
    {
        [JsonProperty("jsonrpc")]
        public string JsonRpc { get; set; } = "2.0";

        [JsonProperty("result")]
        public T? Result { get; set; }

        [JsonProperty("error")]
        public JsonRpcError? Error { get; set; }

        [JsonProperty("id")]
        public object Id { get; set; }
    }
}
