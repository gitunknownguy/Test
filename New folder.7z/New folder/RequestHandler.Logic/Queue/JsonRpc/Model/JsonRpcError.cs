﻿using Newtonsoft.Json;

namespace RequestHandler.Logic.Queue.JsonRpc.Model
{
    public class JsonRpcError
    {
        [JsonProperty("code")]
        public int Code { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; } = string.Empty;

        [JsonProperty("data")]
        public object? Data { get; set; }
    }

}
