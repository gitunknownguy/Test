﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gd.Bos.RequestHandler.Logic.Queue
{
    public interface ICommandHandlerFactory
    {
        ICommandHandler CreateCommandHandler(string commandType);
    }
}
