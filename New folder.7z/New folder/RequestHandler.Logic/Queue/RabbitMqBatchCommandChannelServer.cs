﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Net.NetworkInformation;
using System.Net.Security;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration.RabbitMq;
using Newtonsoft.Json;
using NLog;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using RequestHandler.Core.Infrastructure.Configuration;
using RequestHandler.Logic.Queue;

namespace Gd.Bos.RequestHandler.Logic.Queue
{
    [ExcludeFromCodeCoverage(Justification = "RabbitMq")]
    public class RabbitMqBatchCommandChannelServer : IBatchCommandChannelServer
    {
        private readonly IRequestHandlerSettings _settings;

        public RabbitMqBatchCommandChannelServer(RabbitMqConfig config,
            ICommandHandlerFactory factory,
            IRequestHandlerSettings settings)
        {
            _configuration = new RabbitMqConfig
            {
                HostName = config.HostName,
                Username = config.UseSsl ? default(string) : config.Username,
                Password = config.UseSsl ? default(string) : config.Password,
                Port = config.Port.GetValueOrDefault(),
                VirtualHost = Environment.ExpandEnvironmentVariables(config.VirtualHost ?? "/"),
                RequestQueueName = config.RequestQueueName,
                PrefetchCount = config.PrefetchCount ?? 3,
                MaxExecutingCommands = config.MaxExecutingCommandsForBatch ?? 30,
                UseSsl = config.UseSsl,
                CertSubject = config.CertSubject,
                ExchangeDeclaration = config.ExchangeDeclaration ??
                                      new ExchangeDeclaration
                                      {
                                          ExchangeName = settings.RabbitBatchJobExchange,
                                          ExchangeType = "topic",
                                          Durable = false,
                                          AutoDelete = false
                                      },
                QueueDeclaration = config.QueueDeclaration ??
                                   new QueueDeclaration
                                   {
                                       QueueName = settings.RabbitMqBatchJobQueueName,
                                       Durable = settings.RabbitMqQueueDurable,
                                       AutoDelete = false,
                                       Exclusive = false
                                   },
                QueueBind = config.QueueBind ??
                            new QueueBind
                            {
                                QueueName = settings.RabbitMqBatchJobQueueName,
                                Exchange = settings.RabbitBatchJobExchange,
                                RoutingKey = "*"
                            }
            };

            _semaphore = new SemaphoreSlim(_configuration.MaxExecutingCommands.Value);

            _consumerTag = Environment.MachineName + "." + Process.GetCurrentProcess().Id + "." + Guid.NewGuid();
            _commandHandlerFactory = factory;
            _settings = settings;
        }

        public void SetCommandHandlerFactory(ICommandHandlerFactory factory)
        {

        }

        public void Start()
        {
            CheckDisposed();

            if (_running)
                throw new InvalidOperationException("RabbitMqBatchCommandChannelServer is already running.");

            try
            {
                Connect();
            }
            catch (Exception ex)
            {
                Disconnect();

                throw;
            }
        }

        public void Stop()
        {
            CheckDisposed();

            if (!_running)
                throw new InvalidOperationException("RabbitMqBatchCommandChannelServer is not running.");

            Disconnect();
        }

        private readonly int _interval = 1000 * 60;

        private void Connect()
        {
            ConnectionFactory factory = new ConnectionFactory();

            factory.HostName = _configuration.HostName;
            factory.UserName = _configuration.Username;
            factory.Password = _configuration.Password;
            factory.VirtualHost = _configuration.VirtualHost;
            factory.Port = _configuration.Port.GetValueOrDefault();
            factory.Ssl = _configuration.UseSsl ? new SslOption
            {
                Enabled = true,
                ServerName = factory.HostName,
                AcceptablePolicyErrors = SslPolicyErrors.RemoteCertificateNameMismatch |
                                         SslPolicyErrors.RemoteCertificateChainErrors,
                CertificateSelectionCallback = ConfigOnCertificateSelection,
                Version = SslProtocols.Tls12
            } : factory.Ssl;
            factory.AuthMechanisms = _configuration.UseSsl
             ? new AuthMechanismFactory[] { new ExternalMechanismFactory() }
                : ConnectionFactory.DefaultAuthMechanisms;

            bool hasClientProvidedName = _settings.ClientName != null;
            Logger.Info(hasClientProvidedName
                ? $"RabbitMqBatchCommandChannelServer using client provided name for connection: {_settings.ClientName}"
                : $"RabbitMqBatchCommandChannelServer configuration field for client name not found. Using machine name: {Environment.MachineName}");
            _connection = hasClientProvidedName
                ? factory.CreateConnection(_settings.ClientName)
                : factory.CreateConnection(Environment.MachineName);

            _connection.ConnectionRecoveryError += _connection_ConnectionRecoveryError;
            _connection.ConnectionShutdown += _connection_ConnectionShutdown;
            _connection.RecoverySucceeded += _connection_RecoverySucceeded;

            _model = _connection.CreateModel();
            _model.BasicQos(0, _configuration.PrefetchCount!.Value, false);

            _model.ExchangeDeclare(_configuration.ExchangeDeclaration.ExchangeName,
                _configuration.ExchangeDeclaration.ExchangeType,
                _configuration.ExchangeDeclaration.Durable,
                _configuration.ExchangeDeclaration.AutoDelete);

            _model.QueueDeclare(_configuration.QueueDeclaration.QueueName,
                _configuration.QueueDeclaration.Durable,
                _configuration.QueueDeclaration.Exclusive,
                _configuration.QueueDeclaration.AutoDelete);

            _model.QueueBind(_configuration.QueueBind.QueueName,
                _configuration.QueueBind.Exchange,
                _configuration.QueueBind.RoutingKey);

            _consumer = new EventingBasicConsumer(_model);
            _consumer.Received += OnMessageReceived;
            _model.BasicConsume(_configuration.RequestQueueName, false, _consumerTag, _consumer);

            _running = true;

            Logger.Info("RabbitMqBatchCommandChannelServer: connection to RabbitMQ established.");

        }

        private void CheckConnection()
        {
            if (_model == null || _model.IsOpen == false)
            {
                lock (_locker)
                {
                    if (_model == null || _model.IsOpen == false)
                    {
                        Connect();
                    }
                }
            }
        }

        private X509Certificate2 CertFactory()
        {
            var storeLocation = ConfigurationHelper.GetStoreLocation();
            using (var store = new X509Store(StoreName.My, storeLocation))
            {
                store.Open(OpenFlags.ReadOnly);
                var certFindType = X509FindType.FindBySubjectName;
                var certFindValue = _configuration.CertSubject;
                var certificateCol = store.Certificates.Find(certFindType, certFindValue, true);
                store.Close();
                return certificateCol[0];
            }
        }

        private X509Certificate ConfigOnCertificateSelection(object sender, string targetHost, X509CertificateCollection localCertificates, X509Certificate remoteCertificate, string[] acceptableIssuers)
        {
            _lazyCert = _lazyCert ?? new Lazy<X509Certificate2>(CertFactory);
            return _lazyCert.Value;
        }

        private void Disconnect()
        {
            if (_running)
            {
                _disconnecting = true;

                try
                {
                    _model?.BasicCancel(_consumerTag);
                }
                catch (Exception e)
                {
                    Logger.Error(e, "RabbitMqBatchCommandChannelServer: exception calling BasicCancel on consumer.");
                }
                finally
                {
                    _consumer = null;
                }

                Stopwatch waitTime = Stopwatch.StartNew();

                while (_semaphore.CurrentCount < _configuration.MaxExecutingCommands && waitTime.Elapsed.Seconds < 60)
                    Thread.Sleep(100);

                waitTime.Stop();

                if (_semaphore.CurrentCount < _configuration.MaxExecutingCommands)
                    Logger.Error("RabbitMqBatchCommandChannelServer: timeout waiting for all commands to complete.  Disposing of model.");

                try
                {
                    _model?.Dispose();
                }
                catch (Exception e)
                {
                    Logger.Error(e, "RabbitMqBatchCommandChannelServer: exception disposing model.");
                }
                finally
                {
                    _model = null;
                }

                try
                {
                    _connection?.Dispose();
                }
                catch (Exception e)
                {
                    Logger.Error(e, "Exception disposing connection.");
                }
                finally
                {
                    _connection = null;
                }

                _disconnecting = false;
                _running = false;

                Logger.Info("RabbitMqBatchCommandChannelServer disconnected from RabbitMQ.");
            }
        }

        private void _connection_ConnectionShutdown(object sender, ShutdownEventArgs e)
        {
            if (!_disconnecting)
                Logger.Error("RabbitMqBatchCommandChannelServer: Connection to RabbitMQ lost.");
        }

        private void _connection_ConnectionRecoveryError(object sender, ConnectionRecoveryErrorEventArgs e)
        {
            Logger.Error(e.Exception, "RabbitMqBatchCommandChannelServer: Error reconnecting to RabbitMQ.");
        }

        private void _connection_RecoverySucceeded(object sender, EventArgs e)
        {
            Logger.Info("RabbitMqBatchCommandChannelServer: Connection to RabbitMQ reestablished.");
        }

        private void OnMessageReceived(object source, BasicDeliverEventArgs eventArgs)
        {
            var model = ((EventingBasicConsumer)source).Model;

            ICommandHandler handler;

            try
            {
                handler = _commandHandlerFactory.CreateCommandHandler(eventArgs.BasicProperties.Type);
            }
            catch (Exception e)
            {
                Logger.Error(e, "RabbitMqBatchCommandChannelServer: Exception calling CreateCommandHandler.");
                model.BasicAck(eventArgs.DeliveryTag, false);
                handler = null;
            }

            if (handler != null)
            {
                Task newTask = new Task(
                    async () =>
                    {
                        try
                        {
                            Interlocked.Increment(ref _commandEntered);
                            model.BasicAck(eventArgs.DeliveryTag, false);

                            var responseBuffer = await handler.HandleAsync(eventArgs.Body);

                            ReplyTo(eventArgs.BasicProperties.ReplyTo, eventArgs.BasicProperties.CorrelationId, responseBuffer);
                        }
                        catch (Exception e)
                        {
                            Logger.Error(e, "RabbitMqBatchCommandChannelServer: Exception while executing command.");
                        }
                        finally
                        {
                            _semaphore.Release();
                        }
                    });

                _semaphore.Wait();

                newTask.Start();
            }
        }

        private long _commandEntered;

        private void ReplyTo(string replyTo, string correlationId, byte[] responseBuffer)
        {
            CheckConnection();

            var responseProperties = _model.CreateBasicProperties();

            responseProperties.CorrelationId = correlationId;

            _model.BasicPublish("", replyTo, responseProperties, responseBuffer);
        }

        #region IDisposable

        public void Dispose()
        {
            Dispose(true);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                Disconnect();
            }

            _disposed = true;
        }

        private void CheckDisposed()
        {
            if (_disposed)
                throw new ObjectDisposedException(GetType().Name);
        }

        private bool _disposed;

        #endregion

        private readonly RabbitMqConfig _configuration;
        private readonly ICommandHandlerFactory _commandHandlerFactory;
        private IConnection _connection;
        private IModel _model;
        private EventingBasicConsumer _consumer;
        private readonly string _consumerTag;
        private Dictionary<string, IModel> _replyTos;
        private readonly SemaphoreSlim _semaphore;
        private bool _running;
        private bool _disconnecting;
        private Timer _reconnectionTimer;
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();
        private Lazy<X509Certificate2> _lazyCert;
        private static readonly object _locker = new object();

    }
}
