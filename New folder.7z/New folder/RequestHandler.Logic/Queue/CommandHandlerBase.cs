﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Logic.Extension;
using Newtonsoft.Json;
using NLog;
using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Datadog.Trace.Annotations;
using Gd.Bos.Logging.Common.IManagers;
using SharedOptionsContext = Gd.Bos.Shared.Common.Core.Logic.Options.OptionsContext;

namespace Gd.Bos.RequestHandler.Logic.Queue
{
    [ExcludeFromCodeCoverage(Justification = "This class is abstract and provides a generic framework for request handling. Its functionality is indirectly tested through integration tests of derived classes, where the actual business logic is implemented")]
    public abstract class CommandHandlerBase<TRequest, TResponse> : ICommandHandler where TRequest : BaseRequest
        where TResponse : BaseResponse
    {
        [Trace(OperationName = "CommandHandler", ResourceName = "RequestHandler.CommandHandler")]
        public async Task<byte[]> HandleAsync(byte[] requestBuffer)
        {
            var serializer = new JsonSerializer();
            var correlationId = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 0);
            string requestId;
            byte[] responseBuffer;
            BaseResponse response;

            using (var ms = new MemoryStream(requestBuffer))
            using (var requestString = new StreamReader(ms))
            using (var reader = new JsonTextReader(requestString))
            {
                var request = serializer.Deserialize<TRequest>(reader);
                requestId = request.RequestHeader.RequestId.ToString();

                if (string.IsNullOrEmpty(requestId))
                {
                    requestId = Guid.NewGuid().ToString();
                    request.RequestHeader.RequestId = Guid.Parse(requestId);
                }

                MappedDiagnosticsLogicalContext.Set("requestId", requestId);
                MappedDiagnosticsLogicalContext.Set("programCode", request.ProgramCode);

                OptionsContext.Current = OptionsContext.Current.Add("requestId", requestId);
                OptionsContext.Current = OptionsContext.Current.Add("programCode", request.ProgramCode);

                if (request.RequestHeader.Options != null)
                {
                    OptionsContext.Current = OptionsContext.Current.Add(request.RequestHeader.Options);
                    SharedOptionsContext.Current = SharedOptionsContext.Current.Add(request.RequestHeader.Options);
                }

                response = new BaseResponse();

                try
                {
                    _logManager.LogRequest(correlationId, requestId, Encoding.UTF8.GetString(requestBuffer),
                        DateTime.Now, "RequestHandlerService", typeof(TRequest).Name, "");

                    CreateDomainContext(request);
                    SetDomainContext(request);

                    response = await VerifyIdentifiers(request);
                    if (response.ResponseHeader.StatusCode == 0)
                    {
                        response = await ObtainLock(request);
                        if (response == null || response.ResponseHeader.StatusCode == 0)
                            response = await Handle(request);
                    }
                    else
                        _logManager.LogWarn(response.ResponseHeader.StatusCode, $"Identifier validation failed. {response}", typeof(TRequest).Name, null);
                }
                catch (Exception e)
                {
                    response = e.HandleException<BaseResponse>(e, request);
                }
                finally
                {
                    if (response?.ResponseHeader?.StatusCode != 409)
                    {
                        _logManager.LogWarn(0, $"Releasing api lock", typeof(TRequest).Name, null);
                        ReleaseLock(request);
                    }
                }

                using (var responseStream = new MemoryStream())
                {
                    var sw = new StreamWriter(responseStream);
                    serializer.Serialize(sw, response);
                    sw.Flush();
                    responseBuffer = responseStream.ToArray();
                }


                _logManager.LogResponse(correlationId, requestId, Encoding.UTF8.GetString(responseBuffer), DateTime.Now,
                    response?.ResponseHeader?.StatusCode.ToString(), "", "RequestHandlerService", typeof(TRequest).Name);
                return responseBuffer;
            }
        }


        private void CreateDomainContext(TRequest request)
        {
            if (string.IsNullOrEmpty(request.ProgramCode))
                DomainContext.Current = DomainContext.Empty();
            else
                DomainContext.Current =
                    new DomainContext(ProgramCode.FromString(request.ProgramCode), null, null, null, null, null, null, null);
        }

        public abstract void SetDomainContext(TRequest request);
        public abstract Task<TResponse> VerifyIdentifiers(TRequest request);
        public abstract Task<TResponse> Handle(TRequest request);

        /// <summary>
        /// ObtainLock and ReleaseLock left empty on purpose so individual handlers can implement their own functionality
        /// </summary>
        /// <param name="request"></param>
        public virtual async Task<TResponse> ObtainLock(TRequest request)
        {
            return null;
        }

        public virtual void ReleaseLock(TRequest request) { }

        private readonly ILogManager _logManager = new Logging.Common.Managers.LogManager();
    }
}
