﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;

namespace Gd.Bos.RequestHandler.Logic.Queue
{
    public interface INotificationPublisher
    {

    }
}
