﻿//using Easy.Logger;
//using Gd.Bos.Shared.Common.Core.Contract.Interface;
//using Gd.Bos.Shared.Common.Core.Logic;

//namespace Gd.Bos.RequestHandler.Logic.Queue
//{
//    public class MessageProcessor : MessageProcessorBase
//    {
//        public MessageProcessor(string qPath, int threadCount, IMessageHandlerFactory messageHandlers, ILogger logger) : base(qPath, threadCount, messageHandlers, logger, null)
//        {
//        }

//        public MessageProcessor(IRoundRobin<string> queueList, int threadCount, IMessageHandlerFactory messageHandlers, ILogger logger) : base(queueList, threadCount, messageHandlers, logger, null)
//        {
//        }

//        protected override void OnMessageProcessed()
//        {
//        }

//        protected override void OnMessageReceived()
//        {
//        }
//    }
//}
