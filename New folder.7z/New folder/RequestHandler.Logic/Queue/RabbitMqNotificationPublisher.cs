﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.RabbitMQ.Contract;

using Newtonsoft.Json;
using NLog;

namespace Gd.Bos.RequestHandler.Logic.Queue
{
    public class RabbitMqNotificationPublisher : INotificationPublisher
    {
        private readonly IWriter<string> _queueWriter;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();

        public RabbitMqNotificationPublisher(IWriter<string> queueWriter)
        {
            _queueWriter = queueWriter;
        }

    }
}
