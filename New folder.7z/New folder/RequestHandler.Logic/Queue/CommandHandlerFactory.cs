﻿using System;
using System.Diagnostics.CodeAnalysis;
using NLog;

namespace Gd.Bos.RequestHandler.Logic.Queue
{
    public class CommandHandlerFactory : ICommandHandlerFactory
    {
        ILogger _logger = LogManager.GetCurrentClassLogger();

        public CommandHandlerFactory(
            Func<string, ICommandHandler> factoryDelegate
            )
        {
            _factory = factoryDelegate;

        }

        public ICommandHandler CreateCommandHandler(string commandType)
        {
            try
            {
                return _factory(commandType);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw new Exception($"Unknown command type: {commandType}");
            }
        }

        private readonly Func<string, ICommandHandler> _factory;

    }
}
