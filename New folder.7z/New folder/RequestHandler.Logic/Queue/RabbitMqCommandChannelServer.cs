﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net.Security;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.RabbitMQ.Contract;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration.RabbitMq;
using NLog;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using System.Net.NetworkInformation;
using Datadog.Trace;
using Newtonsoft.Json;
using RequestHandler.Core.Infrastructure.Configuration;

namespace Gd.Bos.RequestHandler.Logic.Queue
{
    [ExcludeFromCodeCoverage(Justification ="RabbitMq")]
    public class RabbitMqCommandChannelServer : ICommandChannelServer
    {
        private readonly IRequestHandlerSettings _settings;

        public RabbitMqCommandChannelServer(RabbitMqConfig config, ICommandHandlerFactory factory, IRequestHandlerSettings settings)
        {
            _configuration = new RabbitMqConfig
            {
                HostName = config.HostName,
                Username = config.UseSsl ? default(string) : config.Username,
                Password = config.UseSsl ? default(string) : config.Password,
                Port = config.Port.GetValueOrDefault(),
                VirtualHost = Environment.ExpandEnvironmentVariables(config.VirtualHost ?? "/"),
                RequestQueueName = config.RequestQueueName,
                PrefetchCount = config.PrefetchCount ?? 3,
                MaxExecutingCommands = config.MaxExecutingCommands ?? 50,
                UseSsl = config.UseSsl,
                CertSubject = config.CertSubject,
                ExchangeDeclaration = config.ExchangeDeclaration ??
                                      new ExchangeDeclaration
                                      {
                                          ExchangeName = settings.RabbitMQRequestExchange,
                                          ExchangeType = "topic",
                                          Durable = false,
                                          AutoDelete = false
                                      },
                QueueDeclaration = config.QueueDeclaration ??
                                   new QueueDeclaration
                                   {
                                       QueueName = settings.RabbitMQRequestQueueName,
                                       Durable = settings.RabbitMqQueueDurable,
                                       AutoDelete = false,
                                       Exclusive = false
                                   },
                QueueBind = config.QueueBind ??
                            new QueueBind
                            {
                                QueueName = settings.RabbitMQRequestQueueName,
                                Exchange = settings.RabbitMQRequestExchange,
                                RoutingKey = "*"
                            }
            };

            _semaphore = new SemaphoreSlim(_configuration.MaxExecutingCommands.Value);

            _consumerTag = Environment.MachineName + "." + Process.GetCurrentProcess().Id + "." + Guid.NewGuid();
            _commandHandlerFactory = factory;
            _settings = settings;
        }

        public void SetCommandHandlerFactory(ICommandHandlerFactory factory)
        {

        }

        public void Start()
        {
            CheckDisposed();

            if (_running)
                throw new InvalidOperationException("Service is already running.");

            try
            {
                Connect();
            }
            catch (Exception)
            {
                Disconnect();

                throw;
            }
        }

        public void Stop()
        {
            CheckDisposed();

            if (!_running)
                throw new InvalidOperationException("Service is not running.");

            Disconnect();
        }

        private int _interval = 1000 * 60;

        private void Connect()
        {
            ConnectionFactory factory = new ConnectionFactory();

            factory.HostName = _configuration.HostName;
            factory.UserName = _configuration.Username;
            factory.Password = _configuration.Password;
            factory.VirtualHost = _configuration.VirtualHost;
            factory.Port = _configuration.Port.GetValueOrDefault();
            factory.Ssl = _configuration.UseSsl ? new SslOption
            {
                Enabled = true,
                ServerName = factory.HostName,
                AcceptablePolicyErrors = SslPolicyErrors.RemoteCertificateNameMismatch |
                                         SslPolicyErrors.RemoteCertificateChainErrors,
                CertificateSelectionCallback = ConfigOnCertificateSelection,
                Version = SslProtocols.Tls12
            } : factory.Ssl;
            factory.AuthMechanisms = _configuration.UseSsl
                 ? new AuthMechanismFactory[] { new ExternalMechanismFactory() }
                : ConnectionFactory.DefaultAuthMechanisms;

            bool hasClientProvidedName = _settings.ClientName != null;
            _logger.Info(hasClientProvidedName
                ? $"Using client provided name for connection: {_settings.ClientName}"
                : $"Configuration field for client name not found. Using machine name: {Environment.MachineName}");
            _connection = hasClientProvidedName
                ? factory.CreateConnection(_settings.ClientName)
                : factory.CreateConnection(Environment.MachineName);

            _connection.ConnectionRecoveryError += _connection_ConnectionRecoveryError;
            _connection.ConnectionShutdown += _connection_ConnectionShutdown;
            _connection.RecoverySucceeded += _connection_RecoverySucceeded;

            _model = _connection.CreateModel();
            _model.BasicQos(0, _configuration.PrefetchCount.Value, false);

            _model.ExchangeDeclare(_configuration.ExchangeDeclaration.ExchangeName,
                _configuration.ExchangeDeclaration.ExchangeType,
                _configuration.ExchangeDeclaration.Durable,
                _configuration.ExchangeDeclaration.AutoDelete);

            _model.QueueDeclare(_configuration.QueueDeclaration.QueueName,
                _configuration.QueueDeclaration.Durable,
                _configuration.QueueDeclaration.Exclusive,
                _configuration.QueueDeclaration.AutoDelete);

            _model.QueueBind(_configuration.QueueBind.QueueName,
                _configuration.QueueBind.Exchange,
                _configuration.QueueBind.RoutingKey);

            _consumer = new EventingBasicConsumer(_model);
            _consumer.Received += OnMessageReceived;
            _model.BasicConsume(_configuration.RequestQueueName, false, _consumerTag, _consumer);

            _running = true;

            _logger.Info("Connection to RabbitMQ established.");

        }
       
        private void CheckConnection()
        {
            if (_model == null || _model.IsOpen == false)
            {
                lock (_locker)
                {
                    if (_model == null || _model.IsOpen == false)
                    {
                        Connect();
                    }
                }
            }
        }

        private X509Certificate2 CertFactory()
        {
            var storeLocation = ConfigurationHelper.GetStoreLocation();
            using (var store = new X509Store(StoreName.My, storeLocation))
            {
                store.Open(OpenFlags.ReadOnly);
                var certFindType = X509FindType.FindBySubjectName;
                var certFindValue = _configuration.CertSubject;
                var certificateCol = store.Certificates.Find(certFindType, certFindValue, true);
                store.Close();
                return certificateCol[0];
            }
        }

        private X509Certificate ConfigOnCertificateSelection(object sender, string targetHost, X509CertificateCollection localCertificates, X509Certificate remoteCertificate, string[] acceptableIssuers)
        {
            _lazyCert = _lazyCert ?? new Lazy<X509Certificate2>(CertFactory);
            return _lazyCert.Value;
        }

        private void Disconnect()
        {
            if (_running)
            {
                _disconnecting = true;

                try
                {
                    _model?.BasicCancel(_consumerTag);
                }
                catch (Exception e)
                {
                    _logger.Error(e, "Exception calling BasicCancel on consumer.");
                }
                finally
                {
                    _consumer = null;
                }

                Stopwatch waitTime = Stopwatch.StartNew();

                while (_semaphore.CurrentCount < _configuration.MaxExecutingCommands && waitTime.Elapsed.Seconds < 60)
                    Thread.Sleep(100);

                waitTime.Stop();

                if (_semaphore.CurrentCount < _configuration.MaxExecutingCommands)
                    _logger.Error("Timeout waiting for all commands to complete.  Disposing of model.");

                try
                {
                    _model?.Dispose();
                }
                catch (Exception e)
                {
                    _logger.Error(e, "Exception disposing model.");
                }
                finally
                {
                    _model = null;
                }

                try
                {
                    _connection?.Dispose();
                }
                catch (Exception e)
                {
                    _logger.Error(e, "Exception disposing connection.");
                }
                finally
                {
                    _connection = null;
                }

                _disconnecting = false;
                _running = false;

                _logger.Info("Disconnected from RabbitMQ.");
            }
        }

        private void _connection_ConnectionShutdown(object sender, ShutdownEventArgs e)
        {
            if (!_disconnecting)
                _logger.Error("Connection to RabbitMQ lost.");
        }

        private void _connection_ConnectionRecoveryError(object sender, ConnectionRecoveryErrorEventArgs e)
        {
            _logger.Error(e.Exception, "Error reconnecting to RabbitMQ.");
        }

        private void _connection_RecoverySucceeded(object sender, EventArgs e)
        {
            _logger.Info("Connection to RabbitMQ reestablished.");
        }

        private void OnMessageReceived(object source, BasicDeliverEventArgs eventArgs)
        {
            var model = ((EventingBasicConsumer)source).Model;

            ICommandHandler handler;

            try
            {
                handler = _commandHandlerFactory.CreateCommandHandler(eventArgs.BasicProperties.Type);
            }
            catch (Exception e)
            {
                _logger.Error(e, "Exception calling CreateCommandHandler.");
                model.BasicAck(eventArgs.DeliveryTag, false);
                handler = null;
            }

            if (handler != null)
            {
                Task newTask = new Task(
                    async () =>
                    {
                        try
                        {
                            Interlocked.Increment(ref _commandEntered);
                            model.BasicAck(eventArgs.DeliveryTag, false);

                            var responseBuffer = await handler.HandleAsync(eventArgs.Body);

                            ReplyTo(eventArgs.BasicProperties.ReplyTo, eventArgs.BasicProperties.CorrelationId, responseBuffer);
                        }
                        catch (Exception e)
                        {
                            _logger.Error(e, "Exception while executing command.");
                        }
                        finally
                        {
                            _semaphore.Release();
                        }
                    });

                _semaphore.Wait();

                newTask.Start();
            }
        }

        private long _commandEntered;

        private void ReplyTo(string replyTo, string correlationId, byte[] responseBuffer)
        {
            CheckConnection();

            var responseProperties = _model.CreateBasicProperties();

            responseProperties.CorrelationId = correlationId;

            _model.BasicPublish("", replyTo, responseProperties, responseBuffer);
        }

        #region IDisposable

        public void Dispose()
        {
            Dispose(true);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                Disconnect();
            }

            _disposed = true;
        }

        private void CheckDisposed()
        {
            if (_disposed)
                throw new ObjectDisposedException(GetType().Name);
        }

        private bool _disposed;

        #endregion

        private RabbitMqConfig _configuration;
        private ICommandHandlerFactory _commandHandlerFactory;
        private IConnection _connection;
        private IModel _model;
        private EventingBasicConsumer _consumer;
        private string _consumerTag;
        private Dictionary<string, IModel> _replyTos;
        private SemaphoreSlim _semaphore;
        private bool _running;
        private bool _disconnecting;
        private Timer _reconnectionTimer;
        private static readonly Logger _logger = LogManager.GetCurrentClassLogger();
        private Lazy<X509Certificate2> _lazyCert;
        private static readonly object _locker = new object();
    }
}
