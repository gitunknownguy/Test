﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Castle.DynamicProxy;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Logic.Handler;
using Newtonsoft.Json;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Logic.Handler;

namespace Gd.Bos.RequestHandler.Logic.Interceptor
{
    public class CommandHandlerInterceptor : IInterceptor
    {
        private readonly IBinRepository _binRepository;
        private static readonly JsonSerializer Serializer = new JsonSerializer();
        private static readonly List<string> WhiteList = new List<string>()
        {
            //EGift
            nameof(EGiftCatalogHandler),
            nameof(EGiftGetBalanceHandler),
            nameof(EGiftGetBalanceRefreshHandler),
            nameof(EGiftGetLifeTimeRewardsHandler),
            nameof(EGiftGetPurchaseHistoryHandler),
            nameof(EGiftGetWalletHandler),

            nameof(AchGetDeliveryDateHandler),
            nameof(AtmLocationsHandler),
            
            // BillPay
            nameof(BillPayeeSearchPayeeHandler),
            nameof(BillPayGetAllPaymentsHandler),
            nameof(BillPayGetPayeeHandler),
            nameof(BillPayGetPayeeListHandler),
            nameof(BillPayGetPaymentHandler),
            nameof(BusinessDataLookupHandler),
            nameof(ECashPartnersHandler),
            nameof(ECashPartnersByLocationHandler),
            nameof(ExperianGetOptInHandler),
            nameof(GetAccountByPhoneHandler),
            nameof(GetAccountByTokenizedPanHandler),
            nameof(GetAccountFeesHandler),
            nameof(GetAccountMigrationItemConfirmationHandler),
            nameof(GetAchTransfersHandler),
            nameof(GetActivationMethodsHandler),
            nameof(GetAdjustBalanceStatusHandler),
            nameof(GetAllFeaturesHandler),
            nameof(GetAllFundFulfillmentMrdcTransfersHandler),
            nameof(GetAllMrdcTransfersHandler),
            nameof(GetAuthCustomerEnrollmentHandler),
            nameof(GetAuthCustomerSSOTokenHandler),
            nameof(GetBankNameHandler),
            nameof(GetBarcodeDetailsHandler),
            nameof(GetBusinessMetaDataHandler),
            nameof(GetBusinessProfileHandler),
            nameof(GetCardDeliveryMethodsHandler),
            nameof(GetCareShareCrmStatusHandler),
            nameof(GetChallengesWithStatusHandler),
            nameof(GetCheckBookOrdersHandler),
            nameof(GetCheckDetailByTransactionHandler),
            nameof(GetCheckImagesHandler),
            nameof(GetContactVerificationStatusHandler),
            nameof(GetCreditLineRangeHandler),
            nameof(GetCreditScoreHistoryHandler),
            nameof(GetECashBarcodesHandler),
            nameof(GetEnrollmentHandler),
            nameof(GetEnrollmentHandlerV2),
            nameof(GetExternalCardsHandler),
            nameof(GetFinancialDataAccountHandler),
            nameof(GetFundFulfillmentMrdcTransferHandler),
            nameof(GetGracePeriodHistoryHandler),
            nameof(GetIdvUsersHandler),
            nameof(GetInterestEarnedHandler),
            nameof(GetLegacyTransactionHandler),
            nameof(GetLegacyTransactionsBySearchTermHandler),
            nameof(GetLinkedAccountHandler),
            nameof(GetMrdcTransferHandler),
            nameof(GetODFeeEligibleTransactionsHandler),
            nameof(GetPanByAccountIdentifiersHandler),
            nameof(GetPaymentInstrumentHandler),
            nameof(GetPaymentInstrumentHandlerV2),
            nameof(GetPaymentInstrumentListHandler),
            nameof(GetPaymentsHandler),
            nameof(GetPnEventsHandler),
            nameof(GetPointsConversionRateHandler),
            nameof(GetProductInterestRateTierHandler),
            nameof(GetProspectDetailsByIdHandler),
            nameof(GetPurseInterestDetailsHandler),
            nameof(GetPurseInterestRateTiersHandler),
            nameof(GetPursesHandler),
            nameof(GetSccStatementHistoryHandler),
            nameof(GetTermAcceptanceHistoryHandler),
            nameof(GetTrackMyMailHistoryHandler),
            nameof(GetTransferByTokenHandler),
            nameof(GetUserHandler),
            nameof(GetWiresHandler),
            nameof(GetConsumerProfileAddressHistoryHandler),
            nameof(HealthCheckHandler),
            nameof(InstantIssueGetPaymentInstrumentListHandler),
            nameof(InventoryHandler),
            nameof(ListSegmentsHandler),
            nameof(GetExternalCardProfileHandler),
        };

        public CommandHandlerInterceptor(IBinRepository binRepository)
        {
            _binRepository = binRepository;
        }

        public void Intercept(IInvocation invocation)
        {
            var requestBuffer = (byte[])invocation.Arguments[0];

            using (var ms = new MemoryStream(requestBuffer))
            using (var requestString = new StreamReader(ms))
            using (var reader = new JsonTextReader(requestString))
            {
                var request = Serializer.Deserialize<BaseRequest>(reader);

                if (IsRequestShouldBeBlock(request.ProgramCode, invocation.TargetType.Name))
                {
                    invocation.ReturnValue = Task.FromResult(BuildRejectResponse(request));
                }
                else
                {
                    invocation.Proceed();
                }
            }
        }

        public byte[] BuildRejectResponse(BaseRequest request)
        {
            var response = new BaseResponse()
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 503,
                    SubStatusCode = 0,
                    Message = "Service is in maintenance.",
                    Details = ""
                }
            };
            using (var responseStream = new MemoryStream())
            {
                var sw = new StreamWriter(responseStream);
                Serializer.Serialize(sw, response);
                sw.Flush();
                var responseBuffer = responseStream.ToArray();
                return responseBuffer;
            }
        }

        public bool IsRequestShouldBeBlock(string programCode, string targetTypeName)
        {
            if (string.IsNullOrEmpty(programCode))
            {
                return false;
            }

            if (WhiteList.Any(n => n.Equals(targetTypeName)))
            {
                return false;
            }

            var bins = _binRepository.GetProductBinsByProgramCode(programCode);
            var allConversionBins = _binRepository.GetBinConversions();

            foreach (var bin in bins)
            {
                var conversionBin = allConversionBins.FirstOrDefault(n => n.BIN.Equals(bin));
                if (conversionBin == null)
                {
                    continue;
                }

                if (DateTime.Now > conversionBin.ConversionWindowStartTime && DateTime.Now < conversionBin.CutoverDateTime)
                {
                    return true;
                }
            }

            return false;
        }
    }
}
