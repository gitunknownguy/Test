﻿using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.Logic;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.Shared.Common.Caching;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.Shared.Common.Logic.FeatureLimitsFees.Contract.Enum;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class ProductFeatureLimitRepository : IProductFeatureLimitRepository
    {
        private readonly IDataAccess _dataAccess;
        private readonly ILazyCache _lazyCache;

        public ProductFeatureLimitRepository(IDataAccess dataAccess, ILazyCache lazyCache)
        {
            _dataAccess = dataAccess;
            _lazyCache = lazyCache;
        }

        public List<FeatureLimit> GetProductFeatureLimits(string productCode, FeatureType feature)
        {
            var featureLimitList = new List<FeatureLimit>();

            Func<string, List<FeatureLimit>> getAllLimits = key
                => _lazyCache.Get(key, new TimeSpan(0, 2, 0, 0), () => GetAllLimits());

            var limits = getAllLimits("REQUEST_HANDLER_PRODUCT_LIMITS");
            featureLimitList = limits.Where(p => string.Equals(p.ProductCode, productCode, StringComparison.OrdinalIgnoreCase) && p.Feature == feature).ToList();

            return featureLimitList;
        }
        private List<FeatureLimit> GetAllLimits()
        {
            var featureLimitList = new List<FeatureLimit>();

            using (var reader = _dataAccess.ExecuteReader("GetAllLimits",
                _dataAccess.CreateConnection()))
            {
                while (reader.Read())
                {
                    var limit = new FeatureLimit();
                    limit.LimitType = (LimitType)reader.GetInt16(reader.GetOrdinal("LimitTypeKey"));
                    limit.Frequency = (Frequency)reader.GetInt16(reader.GetOrdinal("FrequencyKey"));
                    limit.Feature = (FeatureType)reader.GetInt16(reader.GetOrdinal("FeatureKey"));
                    limit.MinAmount = reader["LimitAmountMin"] == DBNull.Value ? default(decimal?) : reader.GetDecimal(reader.GetOrdinal("LimitAmountMin"));
                    limit.MaxAmount = reader["LimitAmountMax"] == DBNull.Value ? default(decimal?) : reader.GetDecimal(reader.GetOrdinal("LimitAmountMax"));
                    limit.Count = reader["LimitCount"] == DBNull.Value ? default(int?) : reader.GetInt16(reader.GetOrdinal("LimitCount"));
                    limit.ProductClass = reader.GetString(reader.GetOrdinal("ProductClass"));
                    limit.ProductTierKey = reader.GetInt32(reader.GetOrdinal("ProductTierKey"));
                    limit.ProductTierClass = reader.GetString(reader.GetOrdinal("ProductTierClass"));
                    limit.IsDefault = reader.GetBoolean(reader.GetOrdinal("IsDefault"));
                    limit.ProductCode = reader.GetString(reader.GetOrdinal("ProductCode"));

                    featureLimitList.Add(limit);
                }
            }
            return featureLimitList;
        }
    }
}
