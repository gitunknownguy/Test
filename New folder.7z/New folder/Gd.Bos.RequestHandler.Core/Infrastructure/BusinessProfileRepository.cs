﻿using Gd.Bos.RequestHandler.Core.Domain.Enums;
using Gd.Bos.RequestHandler.Core.Domain.Model.Business;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Utils;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Data;
using Microsoft.Data.SqlClient;
using NLog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Security.Principal;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class BusinessProfileRepository : IBusinessProfileRepository
    {
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        private readonly string _userName = IdentityHelper.GetIdentityName();
        private readonly IBaasConfiguration _baasConfiguration;
        private readonly IDataAccess _dataAccess;
        private readonly IUserRepository _userRepository;
        private const int ownerLimit = 1;

        public BusinessProfileRepository(IDataAccess dataAccess, IUserRepository userRepository, IBaasConfiguration bassConfiguration)
        {
            _dataAccess = dataAccess;
            _userRepository = userRepository;
            _baasConfiguration = bassConfiguration;
        }

        public BusinessProfileInfo GetBusinessProfileInfo(Guid accountIdentifier)
        {
            BusinessProfileInfo businessProfileInfo = null;

            SqlParameter[] parameters =
            {
                new SqlParameter()
                {
                    ParameterName = "@AccountIdentifier"
                    , SqlDbType = SqlDbType.UniqueIdentifier
                    , Value = accountIdentifier
                }
            };

            using (var reader = _dataAccess.ExecuteReader(
                "[dbo].GetBusinessProfileByAccountIdentifier"
                , _dataAccess.CreateConnection()
                , parameters))
            {
                if (reader.Read())
                {
                    businessProfileInfo = new BusinessProfileInfo
                    {
                        AccountIdentifier = (Guid)reader["AccountIdentifier"],
                        ConsumerProfileType = Cast<string>(reader["ConsumerProfileType"]),
                        Name = Cast<string>(reader["Name"]),
                        LegalName = Cast<string>(reader["LegalName"]),
                        EmbossedName = Cast<string>(reader["EmbossedName"]),
                        Address1 = Cast<string>(reader["Address1"]),
                        Address2 = Cast<string>(reader["Address2"]),
                        City = Cast<string>(reader["City"]),
                        State = Cast<string>(reader["State"]),
                        ZipCode = Cast<string>(reader["ZipCode"]),
                        Country = Cast<string>(reader["Country"]),
                        Email = Cast<string>(reader["Email"]),
                        PhoneNumber = Cast<string>(reader["PhoneNumber"])
                    };
                }
            }

            return businessProfileInfo;
        }

        public bool UpdateBusinessProfileInfo(BusinessProfileInfo info)
        {
            try
            {
                var returnParameter = new SqlParameter
                {
                    ParameterName = "return_value",
                    Direction = ParameterDirection.ReturnValue
                };

                SqlParameter[] parameters = new[]
                {
                    new SqlParameter
                    {
                        ParameterName = "ChangeBy", Value = _userName
                    },
                    new SqlParameter
                    {
                        ParameterName = "AccountIdentifier", Value = info.AccountIdentifier
                    },
                    new SqlParameter
                    {
                        ParameterName = "ConsumerProfileType", Value = info.ConsumerProfileType
                    },
                    new SqlParameter
                    {
                        ParameterName = "Name",Value =  info.Name
                    },
                    new SqlParameter
                    {
                        ParameterName = "Address1",Value = info.Address1
                    },
                    new SqlParameter
                    {
                        ParameterName = "Address2",Value = info.Address2
                    },
                    new SqlParameter
                    {
                        ParameterName = "City",Value = info.City
                    },
                    new SqlParameter
                    {
                        ParameterName = "State",Value = info.State
                    },
                    new SqlParameter
                    {
                        ParameterName = "ZipCode",Value = info.ZipCode
                    },
                    new SqlParameter
                    {
                        ParameterName = "Country",Value = info.Country
                    },
                    new SqlParameter
                    {
                        ParameterName = "Email",Value = info.Email
                    },
                    new SqlParameter
                    {
                        ParameterName = "LegalName",Value = info.LegalName
                    },
                    new SqlParameter
                    {
                        ParameterName = "PhoneNumber",Value = info.PhoneNumber
                    },
                    new SqlParameter
                    {
                        ParameterName = "EmbossedName",Value = info.EmbossedName
                    },
                    returnParameter
                };

                _dataAccess.ExecuteNonQuery("[dbo].[UpdBusinessProfileByAccountIdentifier]", _dataAccess.CreateConnection(), parameters);

                return (int)returnParameter.Value == 1;
            }
            catch (Exception ex)
            {
                Logger.Error(ex, @"BusinessProfileRepository.Update, error occurred when updating user business profile: " + ex.Message);
                throw;
            }
        }

        public BusinessDataLookupResponse GetBusinessDataLookupInfo(BusinessDataLookupRequest request, List<BusinessIndustry> industries)
        {
            var businessDataLookupResponse = new BusinessDataLookupResponse();
            businessDataLookupResponse.ConsumerProfileType = new List<BusinessStructure>();
            businessDataLookupResponse.ConsumerProfileRole = new List<BusinessRole>();
            businessDataLookupResponse.BusinessIndustry = new List<Industry>();

            var config = _baasConfiguration.GetBusinessEnrollmentConfiguration(request.ProgramCode);

            foreach (var industry in industries)
            {
                var _industry = new Industry();
                _industry.BusinessIndustryCode = industry.BusinessIndustryTypeCode;
                _industry.Description = industry.BusinessIndustryType;
                businessDataLookupResponse.BusinessIndustry.Add(_industry);
            }

            using (var reader = _dataAccess.ExecuteReader(
                 "[dbo].GetConsumerProfileRoleConsumerProfileType"
                 , _dataAccess.CreateConnection()
                ))

            {
                while (reader.Read())
                {
                    var structure = new BusinessStructure();
                    var role = new BusinessRole();
                    role.ConsumerProfileTypeCodes = new List<string>();

                    structure.ConsumerProfileTypeCode = (reader["ConsumerProfileType"]).ToString();
                    structure.Description = (reader["Description"]).ToString();
                    if ((structure.ConsumerProfileTypeCode == ConsumerProfileType.SoleProp.ToString() ||
                         structure.ConsumerProfileTypeCode == ConsumerProfileType.SingleLLC.ToString()) &&
                         request.ProgramCode == "credibly")
                    {
                        structure.NumberOfOwnersAllowed = ownerLimit;
                    }
                    else if (config != null)
                    {
                        structure.NumberOfOwnersAllowed = config.OwnerLimit;
                    }

                    bool isRolePresent = businessDataLookupResponse.ConsumerProfileRole.Any(cus => cus.ConsumerProfileRoleCode == (reader["ConsumerProfileRoleCode"]).ToString());
                    if (isRolePresent)
                    {
                        var _role = businessDataLookupResponse.ConsumerProfileRole.Where(cus => cus.ConsumerProfileRoleCode == (reader["ConsumerProfileRoleCode"]).ToString()).First();
                        var indexOf = businessDataLookupResponse.ConsumerProfileRole.IndexOf(businessDataLookupResponse.ConsumerProfileRole.Find(cus => cus.ConsumerProfileRoleCode == (reader["ConsumerProfileRoleCode"]).ToString()));
                        role = _role;
                        _role.ConsumerProfileTypeCodes.Add(structure.ConsumerProfileTypeCode);
                        businessDataLookupResponse.ConsumerProfileRole[indexOf] = _role;
                    }
                    else
                    {
                        role.ConsumerProfileRoleCode = (reader["ConsumerProfileRoleCode"]).ToString();
                        role.Description = (reader["ConsumerProfileRole"]).ToString();
                        role.ConsumerProfileTypeCodes.Add(structure.ConsumerProfileTypeCode);
                        businessDataLookupResponse.ConsumerProfileRole.Add(role);
                    }
                    bool isStructurePresent = businessDataLookupResponse.ConsumerProfileType.Any(cus => cus.ConsumerProfileTypeCode == (reader["ConsumerProfileType"]).ToString());
                    if (!isStructurePresent)
                    {
                        businessDataLookupResponse.ConsumerProfileType.Add(structure);
                    }
                }
                businessDataLookupResponse.ConsumerProfileType = businessDataLookupResponse.ConsumerProfileType.GroupBy(x => x.ConsumerProfileTypeCode)
                    .Select(g => g.FirstOrDefault()).ToList();
                businessDataLookupResponse.ConsumerProfileRole = businessDataLookupResponse.ConsumerProfileRole.GroupBy(x => x.ConsumerProfileRoleCode)
                  .Select(g => g.FirstOrDefault()).ToList();
                businessDataLookupResponse.ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0,
                    SubStatusCode = 0,
                    Message = "Success",
                };
                return businessDataLookupResponse;
            }
        }
        private T Cast<T>(object value, T defaultValue = default(T))
        {
            if (value == DBNull.Value)
                return defaultValue;

            return (T)value;
        }
    }
}
