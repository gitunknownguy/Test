﻿using System;
using System.Data;
using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.RequestHandler.Core.Utils;
using Microsoft.Data.SqlClient;
using RequestHandler.Core.Domain.Model.Inventory;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class InstantIssueCardInventoryRepository : IInstantIssueCardInventoryRepository
    {
        public InstantIssueCardInventoryRepository(IDataAccess dataAccess)
        {
            _dataAccess = dataAccess;
        }
        public string InsertInstantIssueCardInventory(Guid accountIdentifier, string mappingIdentifier)
        {
            var dataConnection = _dataAccess.CreateConnection();
            string returnValue = "";
            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "ChangeBy", SqlDbType = SqlDbType.NVarChar, Size = 200, Value = _userName },
                new SqlParameter() { ParameterName = "AccountIdentifier", SqlDbType = SqlDbType.UniqueIdentifier, Value = accountIdentifier },
                new SqlParameter() { ParameterName = "MappingIdentifier", SqlDbType = SqlDbType.NVarChar,Size = 20, Value = mappingIdentifier}
            };
            using (var reader = _dataAccess.ExecuteReader("[dbo].[InsInstantIssueCardInventory]", dataConnection, parameters))
            {
                reader.Read();

                if (reader.GetInt32(reader.GetOrdinal("IsExist")) == 1)
                {
                    returnValue = reader["MappingIdentifier"].ToString();
                }
            }
            return returnValue;
        }

        public string GetInstantIssueCardInventoryByAccountIdentifier(Guid accountIdentifier)
        {
            string returnValue = "";
            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "AccountIdentifier", SqlDbType = SqlDbType.UniqueIdentifier, Value = accountIdentifier },
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetInstantIssueCardInventoryByAccountIdentifier]", _dataAccess.CreateConnection(), parameters))
            {
                if (reader.Read())
                {
                    returnValue = reader["MappingIdentifier"].ToString();
                }
            }
            return returnValue;
        }

        public Guid? GetInstantIssueCardInventoryByMappingIdentifier(string mappingIdentifier)
        {
            Guid? returnValue = null;
            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "MappingIdentifier", SqlDbType = SqlDbType.NVarChar, Size = 20 , Value = mappingIdentifier },
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetInstantIssueCardInventoryByMappingIdentifier]", _dataAccess.CreateConnection(), parameters))
            {
                if (reader.Read())
                {
                    returnValue = reader.GetGuid(reader.GetOrdinal("AccountIdentifier"));
                }
            }
            return returnValue;
        }
        private readonly IDataAccess _dataAccess;
        private readonly string _userName = IdentityHelper.GetIdentityName();
    }
}
