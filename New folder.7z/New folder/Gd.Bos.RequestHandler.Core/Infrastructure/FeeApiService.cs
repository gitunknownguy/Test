﻿using System;
using Gd.Bos.RequestHandler.Core.Domain.Services.FeeApi;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.UtilityCoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.UtilityCoreApi.Contract.Message.Response;
using NLog;
using System.Diagnostics.CodeAnalysis;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class FeeApiService : IFeeApiService
    {
        private readonly string _feeApiUrl;
        private readonly string _chargeFeeUrl = @"programs/{0}/ChargeFee";
        private readonly string _reverseeFeeUrl = @"programs/{0}/ReverseeFee";
        private readonly string _getFeeUrl = @"programs/{0}/GetFee";
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        private readonly IServiceInvokeProvider _serviceInvokerProvider;

        public FeeApiService(IServiceInvokeProvider serviceInvokeProvider)
        {
            _feeApiUrl = Configuration.Configuration.Current.FeeApiBaseUrl;
            _serviceInvokerProvider = serviceInvokeProvider;
        }

        public ChargeFeeResponse ChargeFee(ChargeFeeRequest request)
        {
            string url = _feeApiUrl + string.Format(_chargeFeeUrl, request?.ProgramCode);
            var response = _serviceInvokerProvider.GetWebResponse<ChargeFeeRequest, ChargeFeeResponse>(url, "POST", request);
            return response;
        }

        public ReverseFeeResponse ReverseeFee(ReverseFeeRequest request)
        {
            string url = _feeApiUrl + string.Format(_reverseeFeeUrl, request?.ProgramCode);
            var response = _serviceInvokerProvider.GetWebResponse<ReverseFeeRequest, ReverseFeeResponse>(url, "POST", request);

            if (response?.ResponseHeader?.StatusCode == 400 && response?.ResponseHeader?.SubStatusCode == 1)
            {
                _logger.Info($"FeeAPI return statusCode {response?.ResponseHeader?.StatusCode}, subStatusCode {response?.ResponseHeader?.SubStatusCode}, message {response?.ResponseHeader?.Message}");
                throw new FeeException(5, 365, $"{request?.FeatureType.ToString()} Not Configured");
            }
            return response;
        }

        [ExcludeFromCodeCoverage(Justification = "Clean up errors GBOS-135690 ")]
        public EvaluateFeeResponse GetFee(EvaluateFeeRequest request)
        {
            string url = _feeApiUrl + string.Format(_getFeeUrl, request?.ProgramCode);
            EvaluateFeeResponse response = null;
            try
            {
                response = _serviceInvokerProvider.GetWebResponse<EvaluateFeeRequest, EvaluateFeeResponse>(url, "POST",
                    request);
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("No fees found for the ProductTierKey"))
                {
                    _logger.Warn(ex, $"RequestId: {request?.RequestHeader?.RequestId} Error:{ex.Message}");
                    throw new FeeException(5, 365, $"{request?.FeatureType.ToString()} Not Configured");
                }
                
                _logger.Error(ex, $"RequestId: {request?.RequestHeader?.RequestId} Error:{ex.Message}");
                throw;
            }

            if ((response?.ResponseHeader?.StatusCode == 400 && response?.ResponseHeader?.SubStatusCode == 1))
            {
                _logger.Info($"FeeAPI return statusCode {response?.ResponseHeader?.StatusCode}, subStatusCode {response?.ResponseHeader?.SubStatusCode}, message {response?.ResponseHeader?.Message}");
                throw new FeeException(5, 365, $"{request?.FeatureType.ToString()} Not Configured");
            }
            return response;
        }
    }
}
