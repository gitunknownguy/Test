﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.Shared.Common.Core.Common.Enum;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.Shared.Common;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Microsoft.Data.SqlClient;
using Microsoft.Data.SqlClient.Server;
using RequestHandler.Core.Domain.Model.Account;
using Account = Gd.Bos.RequestHandler.Core.Domain.Model.Account.Account;
using AccountHolder = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolder;
using AccountStatus = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountStatus;
using AccountStatusReason = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountStatusReason;
using PhoneNumber = Gd.Bos.RequestHandler.Core.Domain.Model.User.PhoneNumber;
using User = Gd.Bos.RequestHandler.Core.Domain.Model.User.User;
using VerificationActivityType = Gd.Bos.RequestHandler.Core.Domain.Model.Account.VerificationActivityType;
using RequestHandler.Core.Domain.Model.Payment;
using PaymentInstrumentInfo = Gd.Bos.RequestHandler.Core.Domain.Model.Payment.PaymentInstrumentInfo;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    partial class AccountRepository
    {
        private static T Cast<T>(object value)
        {
            if (value == DBNull.Value || value == null)
                return default(T);

            return (T)value;
        }

        /// <summary>
        /// retrieve Account, AccountHolder, and AccountStatusReasons (at a minimum) for a specific account.
        /// Added this for account status update scenario -- &quot;GetByAccountIdentifier&quot; does no include this information.
        /// </summary>
        /// <param name="accountIdentifier"></param>
        /// <returns>Account with identifiers, AccountHolders, and StatusReasons </returns>
        public Account GetAccountInfoByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            using (var reader = _dataAccess.ExecuteReader(
                "[dbo].[GetAccountInfoByAccountIdentifier]",
                _dataAccess.CreateConnection(),
                new Microsoft.Data.SqlClient.SqlParameter("AccountIdentifier", (Guid)accountIdentifier)
                ))
            {
                Account account = null;

                while (reader.Read())
                {
                    long accountKey = reader.GetInt64(reader.GetOrdinal("AccountKey"));
                    Guid accountGuid = reader.GetGuid(reader.GetOrdinal("AccountIdentifier"));
                    long consumerProfileKey = reader.GetInt64(reader.GetOrdinal("ConsumerProfileKey"));
                    string productCode = reader.GetString(reader.GetOrdinal("ProductCode"));
                    string firstName = reader.IsDBNull(reader.GetOrdinal("FirstName")) ? null : reader.GetString(reader.GetOrdinal("FirstName"));
                    string lastName = reader.IsDBNull(reader.GetOrdinal("LastName")) ? null : reader.GetString(reader.GetOrdinal("LastName"));
                    long accountHolderKey = reader.GetInt64(reader.GetOrdinal("AccountHolderKey"));
                    Guid accountHolderIdentifier = reader.GetGuid(reader.GetOrdinal("AccountHolderIdentifier"));
                    int productKey = reader.GetInt32(reader.GetOrdinal("ProductKey"));
                    DateTime ahCreateDate = reader.GetDateTime(reader.GetOrdinal("CreateDate"));
                    DateTime? activationDate = reader.IsDBNull(reader.GetOrdinal("ActivationDate")) ? (DateTime?)null : reader.GetDateTime(reader.GetOrdinal("ActivationDate"));
                    short accountStatusKey = reader.GetInt16(reader.GetOrdinal("AccountStatusKey"));
                    bool isPrimary = reader.GetBoolean(reader.GetOrdinal("IsPrimaryAccountHolder"));
                    var accountHolderCureKey = reader["AccountHolderCureKey"] == DBNull.Value ? 0 : Int16.Parse(reader["AccountHolderCureKey"].ToString()); //reader.GetInt16(16);
                    var accountCreateDate = Cast<DateTime>(reader["AccountCreateDate"]);
                    bool isTemp = reader["IsTemp"] != DBNull.Value && Convert.ToBoolean(reader["IsTemp"]);

                    long paymentIdentifierKey = reader.IsDBNull(reader.GetOrdinal("PaymentIdentifierKey")) ? 0 : reader.GetInt64(reader.GetOrdinal("PaymentIdentifierKey"));
                    int paymentIdentifierStatusKey = reader.IsDBNull(reader.GetOrdinal("PaymentIdentifierStatusKey")) ? 0 : reader.GetInt16(reader.GetOrdinal("PaymentIdentifierStatusKey"));
                    int paymentIdentifierStatusReasonKey = reader.IsDBNull(reader.GetOrdinal("PaymentIdentifierStatusReasonKey")) ? 0 : reader.GetInt16(reader.GetOrdinal("PaymentIdentifierStatusReasonKey"));
                    int consumerProfileTypeKey = reader.IsDBNull(reader.GetOrdinal("ConsumerProfileTypeKey")) ? 0 : reader.GetInt16(reader.GetOrdinal("ConsumerProfileTypeKey"));
                    var paymentIdentifier = reader.IsDBNull(reader.GetOrdinal("PaymentIdentifier"))
                        ? (Guid?)null
                        : reader.GetGuid(reader.GetOrdinal("PaymentIdentifier"));
                    var last4Pan = reader["Last4PAN"] == DBNull.Value
                        ? ""
                        : reader["Last4PAN"].ToString();
                    Guid userIdentifier = reader.GetGuid(reader.GetOrdinal("ConsumerProfileIdentifier"));
                    DateTime accountStatusDateChange = reader.GetDateTime(reader.GetOrdinal("StatusChangeDate"));
                    string accountNumber = reader.IsDBNull(reader.GetOrdinal("AccountNumber"))
                        ? null
                        : reader.GetString(reader.GetOrdinal("AccountNumber"));
                    string routingNumber = reader.IsDBNull(reader.GetOrdinal("RoutingNumber"))
                        ? null
                        : reader.GetString(reader.GetOrdinal("RoutingNumber"));
                    string accountReferenceNumber = reader.IsDBNull(reader.GetOrdinal("AccountReferenceNumber"))
                        ? null
                        : reader.GetString(reader.GetOrdinal("AccountReferenceNumber"));

                    string accountExternalProxy = reader.IsDBNull(reader.GetOrdinal("AccountExternalProxy"))
                        ? ""
                        : reader.GetString(reader.GetOrdinal("AccountExternalProxy"));
                    string businessName = reader.IsDBNull(reader.GetOrdinal("BusinessName")) ? null : reader.GetString(reader.GetOrdinal("BusinessName"));
                    int productTierKey = reader.IsDBNull(reader.GetOrdinal("ProductTierKey")) ? 0 : reader.GetInt32(reader.GetOrdinal("ProductTierKey"));
                    string aciAccountExternalID = reader.IsDBNull(reader.GetOrdinal("ACIAccountExternalID"))
                      ? ""
                      : reader.GetString(reader.GetOrdinal("ACIAccountExternalID"));
                    if (account == null)
                        account = new Account(accountIdentifier)
                        {
                            AccountKey = accountKey,
                            AccountStatus = (AccountStatus)accountStatusKey,
                            FirstName = firstName,
                            LastName = lastName,
                            Product = new Domain.Model.Product(ProductCode.FromString(productCode), null, productKey, "", "", "")
                            {

                            },
                            ProductTierKey = productTierKey,
                            ActivationDate = activationDate,
                            AccountStatusReasons = new List<AccountStatusReason>(),
                            AccountStatusChangedDateTime = accountStatusDateChange,
                            AccountCreateDate = accountCreateDate,
                            AccountNumber = accountNumber,
                            RoutingNumber = routingNumber,
                            CustomerAccountNumber = accountReferenceNumber,
                            AccountExternalProxy = accountExternalProxy,
                            AciAccountExternalID = aciAccountExternalID
                        };

                    var accountHolder = new AccountHolder(
                        accountHolderIdentifier: accountHolderIdentifier,
                        isPrimary: isPrimary
                        )
                    {
                        ProductCode = productCode,
                        UserIdentifier = UserIdentifier.FromGuid(userIdentifier),
                        AccountIdentifier = accountIdentifier,
                        AccountHolderKey = accountHolderKey,
                        CreateDate = ahCreateDate,
                        ConsumerProfileKey = consumerProfileKey,
                        PaymentIdentifierKey = paymentIdentifierKey,
                        PaymentIdentifier = paymentIdentifier,
                        IsTemp = isTemp,
                        Last4Pan = last4Pan,
                        PaymentIdentifierStatus = (PaymentIdentifierStatus)paymentIdentifierStatusKey,
                        PaymentIdentifierStatusReason = (PaymentIdentifierStatusReason)paymentIdentifierStatusReasonKey,
                        AccountHolderCure = (Domain.Model.Account.AccountHolderCure)accountHolderCureKey,
                        ConsumerProfileTypeKey = consumerProfileTypeKey,
                        BusinessName = businessName
                    };

                    account.AddAccountHolder(accountHolder);

                }
                reader.NextResult();
                while (reader.Read())
                {
                    AccountStatusReason reason = (AccountStatusReason)reader.GetInt16(1);
                    if (account == null)
                    {
                        account = new Account(accountIdentifier)
                        {
                            AccountStatusReasons = new List<AccountStatusReason>()
                        };
                    }
                    account.AccountStatusReasons.Add(reason);

                }
                reader.NextResult();
                while (reader.Read())
                {
                    var paymentInstrumentInfo = new PaymentInstrumentInfo();

                    paymentInstrumentInfo.PaymentInstrumentIdentifier = Guid.Parse(reader["PaymentInstrumentIdentifier"].ToString());

                    if (reader["PaymentInstrumentKey"] != DBNull.Value)
                        paymentInstrumentInfo.PaymentInstrumentKey = Convert.ToInt64(reader["PaymentInstrumentKey"]);

                    if (reader["PaymentIdentifierKey"] != DBNull.Value)
                        paymentInstrumentInfo.PaymentIdentifierKey = (long)reader["PaymentIdentifierKey"];

                    if (Enum.TryParse(reader["PaymentInstrumentStatusKey"].ToString(),
                        out PaymentInstrumentStatus paymentInstrumentStatus))
                    {
                        paymentInstrumentInfo.PaymentInstrumentStatus = paymentInstrumentStatus;
                    }

                    if (Enum.TryParse(reader["PaymentInstrumentTypeKey"].ToString(),
                        out Shared.Common.Core.CoreApi.Contract.Data.PaymentInstrumentType paymentInstrumentType))
                    {
                        paymentInstrumentInfo.PaymentInstrumentType = paymentInstrumentType;
                    }
                    if (reader["ActivationDate"] != DBNull.Value)
                    {
                        paymentInstrumentInfo.ActivatedDateTime = reader.GetDateTime(reader.GetOrdinal("ActivationDate"));
                    }
                    account.PaymentInstrumentInfoList.Add(paymentInstrumentInfo);
                }

                return account;
            };
        }
        public Tuple<List<VerificationActivity>, long> ReturnVerificationActivities(AccountHolderIdentifier accountHolderIdentifier)
        {
            long verificationRequestKey = 0;
            VerificationActivity activity = new VerificationActivity();
            List<VerificationActivity> activities = new List<VerificationActivity>();

            using (var verificationDataReader = _dataAccess.ExecuteReader(
                "[dbo].[GetVerificationRequestByAccountHolderIdentifier]",
                _dataAccess.CreateConnection(),
                new Microsoft.Data.SqlClient.SqlParameter("AccountHolderIdentifier", Guid.Parse(accountHolderIdentifier.ToString())),
                new Microsoft.Data.SqlClient.SqlParameter("VerificationActivityTypeKey",
                    Domain.Model.Account.VerificationActivityType.KYC)))
            {
                while (verificationDataReader.Read())
                {
                    verificationRequestKey = verificationDataReader.GetInt64(0);
                    activity.ActivityKey = verificationDataReader.GetInt64(2);
                    activity.ActivityTypeKey = verificationDataReader.GetInt16(3);
                    activity.StatusKey = 2;
                    activity.EndDate = DateTime.Now.ToString();

                    activities.Add(activity);
                }
            }

            using (var verificationDataReader = _dataAccess.ExecuteReader(
                "[dbo].[GetVerificationRequestByAccountHolderIdentifier]",
                _dataAccess.CreateConnection(),
                new Microsoft.Data.SqlClient.SqlParameter("AccountHolderIdentifier", Guid.Parse(accountHolderIdentifier.ToString())),
                new Microsoft.Data.SqlClient.SqlParameter("VerificationActivityTypeKey",
                    Domain.Model.Account.VerificationActivityType.IDV)))
            {
                while (verificationDataReader.Read())
                {
                    verificationRequestKey = verificationDataReader.GetInt64(0);
                    activity.StatusKey = 2;
                    activity.ActivityKey = verificationDataReader.GetInt64(2);
                    activity.ActivityTypeKey = verificationDataReader.GetInt16(3);
                    activity.EndDate = DateTime.Now.ToString();

                    activities.Add(activity);
                }
            }

            return new Tuple<List<VerificationActivity>, long>(activities, verificationRequestKey);
        }

        public VerificationActivity ReturnVerificationActivity(AccountHolderIdentifier accountHolderIdentifier, Domain.Model.Account.VerificationActivityType activityType)
        {

            VerificationActivity result = null;

            using (var verificationDataReader = _dataAccess.ExecuteReader(
                "[dbo].[GetVerificationRequestByAccountHolderIdentifier]",
                _dataAccess.CreateConnection(),
                new Microsoft.Data.SqlClient.SqlParameter("AccountHolderIdentifier", Guid.Parse(accountHolderIdentifier.ToString())),
                new Microsoft.Data.SqlClient.SqlParameter("VerificationActivityTypeKey",
                    activityType)))
            {
                while (verificationDataReader.Read())
                {
                    var activity = new VerificationActivity();
                    activity.ActivityKey = Cast<long>(verificationDataReader["VerificationActivityKey"]);
                    activity.ActivityTypeKey = Cast<short>(verificationDataReader["VerificationActivityTypeKey"]);
                    activity.StatusKey = Cast<short>(verificationDataReader["ActivityStatusKey"]);
                    result = activity;
                }
            }

            return result;
        }

        public List<Tuple<Account, User>> GetAccountInfoByPhoneNumber(string phone)
        {
            var lst = new List<Tuple<Account, User>>();

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountInfoByPhoneNumber]", _dataAccess.CreateConnection(),
              new Microsoft.Data.SqlClient.SqlParameter("PhoneNumber", phone)))
            {
                while (reader.Read())
                {
                    long accountKey = reader.GetInt64(reader.GetOrdinal("AccountKey"));
                    Guid accountIdentifier = reader.GetGuid(reader.GetOrdinal("AccountIdentifier"));
                    short accountStatusKey = reader.GetInt16(reader.GetOrdinal("AccountStatusKey"));
                    int productKey = reader.GetInt32(reader.GetOrdinal("ProductKey"));
                    string programCode = reader["ProgramCode"] == DBNull.Value ? string.Empty : reader["ProgramCode"].ToString();
                    string productCode = reader["ProductCode"] == DBNull.Value ? string.Empty : reader["ProductCode"].ToString();
                    Guid accountHolderIdentifier = reader.GetGuid(reader.GetOrdinal("AccountHolderIdentifier"));
                    bool IsPrimaryAccountHolder = reader.GetBoolean(reader.GetOrdinal("IsPrimaryAccountHolder"));
                    var accountHolderCureKey = reader["AccountHolderCureKey"] == DBNull.Value ? 0 : Int16.Parse(reader["AccountHolderCureKey"].ToString());
                    var binTypeKey = reader.GetInt16(reader.GetOrdinal("BinTypeKey"));

                    Account account = new Account(accountIdentifier)
                    {
                        AccountKey = accountKey,
                        AccountStatus = (AccountStatus)accountStatusKey,
                        Product = new Domain.Model.Product(ProductCode.FromString(productCode), ProgramCode.FromString(programCode),
                            productKey, null, "", ""),
                        AccountStatusReasons = new List<AccountStatusReason>()
                    };

                    account.BinType = (Core.Domain.Enums.BinType)binTypeKey;

                    var accountHolder = new AccountHolder(accountHolderIdentifier: accountHolderIdentifier, isPrimary: IsPrimaryAccountHolder)
                    {
                        AccountIdentifier = accountIdentifier,
                        //AccountHolderKey = accountHolderKey,
                        //ConsumerProfileKey = consumerProfileKey,
                        //PaymentIdentifierKey = paymentIdentifierKey,
                        //PaymentIdentifierStatus = (PaymentIdentifierStatus)paymentIdentifierStatusKey,
                        AccountHolderCure = (Domain.Model.Account.AccountHolderCure)accountHolderCureKey
                    };

                    account.AddAccountHolder(accountHolder);

                    Guid userIdentifier = reader.GetGuid(reader.GetOrdinal("ConsumerProfileIdentifier"));
                    string firstName = reader["FirstName"] == DBNull.Value ? string.Empty : reader["FirstName"].ToString();
                    string middleName = reader["MiddleName"] == DBNull.Value ? string.Empty : reader["MiddleName"].ToString();
                    string lastName = reader["LastName"] == DBNull.Value ? string.Empty : reader["LastName"].ToString();
                    string phoneNumber = reader["PhoneNumber"] == DBNull.Value ? string.Empty : reader["PhoneNumber"].ToString();
                    bool isVerified = reader["IsVerified"] != DBNull.Value && reader.GetBoolean(reader.GetOrdinal("IsVerified"));
                    bool isPrimaryPhone = reader["IsPrimaryPhone"] != DBNull.Value && reader.GetBoolean(reader.GetOrdinal("IsPrimaryPhone"));

                    User user = new User(UserIdentifier.FromGuid(userIdentifier), null, null, null, null, null);
                    user.SetName(new UserName(firstName, middleName, lastName));
                    user.ConsumerProfileKey = reader.GetInt64(reader.GetOrdinal("ConsumerProfileKey"));
                    user.AddPhoneNumber(new PhoneNumber()
                    {
                        IsDefault = isPrimaryPhone,
                        IsVerified = isVerified,
                        Number = phoneNumber,
                    });
                    lst.Add(new Tuple<Account, User>(account, user));
                }

                reader.NextResult();
                reader.NextResult();

                var paymentIdentifierList = new List<PaymentIdentifierData>();
                while (reader.Read())
                {
                    long accountHolderKey = reader.GetInt64(reader.GetOrdinal("AccountHolderKey"));
                    long accountKey = reader.GetInt64(reader.GetOrdinal("AccountKey"));
                    long paymentIdentifierKey = reader.GetInt64(reader.GetOrdinal("PaymentIdentifierKey"));
                    string last4Pan = reader["Last4PAN"] == DBNull.Value ? null : reader["Last4PAN"].ToString();
                    paymentIdentifierList.Add(new PaymentIdentifierData
                    {
                        AccountHolderKey = accountHolderKey,
                        AccountKey = accountKey,
                        PaymentIdentifierKey = paymentIdentifierKey,
                        Last4Pan = last4Pan
                    });
                }

                lst.ForEach(a =>
                {
                    var paymentIdentifier = paymentIdentifierList
                        .Where(p => p.AccountKey == a.Item1.AccountKey)
                        .OrderByDescending(p => p.PaymentIdentifierKey).FirstOrDefault();
                    a.Item1.AccountHolders[0].Last4Pan = paymentIdentifier?.Last4Pan;
                });


            }

            return lst;
        }

        /// <summary>
        /// retrieve Account and AccountStatusReasons (at a minimum) for a specific account in pending status.
        /// Added this for account status update scenario -- &quot;GetByAccountIdentifier&quot; does no include this information.
        /// </summary>
        /// <param name="accountIdentifier"></param>
        /// <returns>Account with identifiers and StatusReasons </returns>
        public Account GetAccountInfoByAccountIdentifierWithNoPaymentIdentifier(AccountIdentifier accountIdentifier)
        {
            using (var reader = _dataAccess.ExecuteReader(
                "[dbo].[GetAccountInfoByAccountIdentifier]",
                _dataAccess.CreateConnection(),
                new Microsoft.Data.SqlClient.SqlParameter("AccountIdentifier", (Guid)accountIdentifier)
                ))
            {
                Account account = null;

                while (reader.Read())
                {
                    long accountKey = reader.GetInt64(0);
                    Guid accountGuid = reader.GetGuid(1);
                    short accountStatusKey = reader.GetInt16(12);

                    if (account == null)
                        account = new Account(accountIdentifier)
                        {
                            AccountKey = accountKey,
                            AccountStatus = (AccountStatus)accountStatusKey,
                            AccountStatusReasons = new List<AccountStatusReason>()
                        };
                }

                return account;
            };

        }


        public List<Account> GetAccountInfoByConsumerIdentifierProductCodes(string consumerIdentifier, List<string> productCodes)
        {
            var result = new List<Account>();
            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "ConsumerProfileIdentifier", SqlDbType = SqlDbType.UniqueIdentifier, Value =Guid.Parse(consumerIdentifier)},
                new SqlParameter() { ParameterName = "typeProductCode", Value = CreateTypeProductCodeRows(productCodes).Convert(), TypeName = "typeProductCode", SqlDbType = SqlDbType.Structured },
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountByConsumerProfileIdentifier]", _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    var accountGuid = reader.GetGuid(reader.GetOrdinal("AccountIdentifier"));
                    var accountStatusKey = reader.GetInt16(reader.GetOrdinal("AccountStatusKey"));

                    var account = new Account(accountGuid)
                    {
                        AccountStatus = (AccountStatus)accountStatusKey,
                    };
                    result.Add(account);
                }
            }
            return result;
        }

        public List<AccountIdentity> GetAccountStatusAndIdentity(string consumerIdentifier, string accountIdentifier, List<string> productCodes)
        {
            var result = new List<AccountIdentity>();
            var parameters = new[]
            {
                new SqlParameter { ParameterName = "ConsumerProfileIdentifier", SqlDbType = SqlDbType.UniqueIdentifier, Value =string.IsNullOrEmpty(consumerIdentifier)? (object) DBNull.Value: Guid.Parse(consumerIdentifier)},
                new SqlParameter { ParameterName = "AccountIdentifier", SqlDbType = SqlDbType.UniqueIdentifier, Value =string.IsNullOrEmpty(accountIdentifier)? (object) DBNull.Value: Guid.Parse(accountIdentifier)},
                new SqlParameter { ParameterName = "typeProductCode", Value = CreateTypeProductCodeRows(productCodes).Convert(), TypeName = "typeProductCode", SqlDbType = SqlDbType.Structured }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountStatusAndIdentity]", _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    var accountIdentity = new AccountIdentity
                    {
                        AccountIdentifier = AccountIdentifier.FromGuid(Cast<Guid>(reader["AccountIdentifier"])),
                        AccountStatus = (AccountStatus)Cast<short>(reader["AccountStatusKey"]),
                        IdentityType = (IdentityType)Cast<short>(reader["IdentityTypeKey"]),
                        IdentityToken = Cast<string>(reader["IdentityToken"]),
                        ProductCode = Cast<string>(reader["ProductCode"])
                    };
                    result.Add(accountIdentity);
                }
            }
            return result;
        }

        private List<SqlDataRecord> CreateTypeProductCodeRows(List<string> productCodes)
        {
            var returnValue = new List<SqlDataRecord>();
            var metadata = new SqlMetaData[1];
            metadata[0] = new SqlMetaData("ProductCode", SqlDbType.NVarChar, 10);

            foreach (var val in productCodes)
            {
                var record = new SqlDataRecord(metadata);
                record.SetString(0, val);
                returnValue.Add(record);
            }

            return returnValue;
        }


    }
}
