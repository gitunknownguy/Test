﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using System.Threading.Tasks;

namespace RequestHandler.Core.Infrastructure
{
    public interface IAmmAccountStatusNotificationService
    {
        Task PublishNotification(AmmAccountStatusNotificationRequest request);
    }
}
