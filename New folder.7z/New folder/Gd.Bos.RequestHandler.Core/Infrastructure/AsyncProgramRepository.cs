﻿using Gd.Bos.Shared.Common.Core.Common.Data;
using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.Shared.Common.Caching;
using Gd.Bos.Shared.Common.Caching.Contract;
using System;
using System.Collections.Generic;
using System.Data;
using Program = Gd.Bos.RequestHandler.Core.Domain.Model.Program;
using RequestHandler.Core.Domain.Model.Product;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;
using Gd.Bos.RequestHandler.Core.Utils;
using Microsoft.IdentityModel.Tokens;
using System.Linq;
using RequestHandler.Core.Utils;
using Microsoft.Extensions.Caching.Memory;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    [ExcludeFromCodeCoverage(Justification = "Not tested previously and currently can't be easily mocked and will be taken care of on GBOS-116633")]
    public class AsyncProgramRepository : IAsyncProgramRepository
    {
        private readonly IDataAccess _dataAccess;
        private readonly ILazyCache _lazyCache;

        public AsyncProgramRepository(IDataAccess dataAccess, ILazyCache lazyCache)
        {
            _dataAccess = dataAccess;
            _lazyCache = lazyCache;
        }

        public async Task<Program> GetByProgramIdentifier(ProgramCode programCode)
        {
            var programs = await _lazyCache.GetAsync(
                    "PROGRAM_NAMES",
                    new TimeSpan(0, 2, 0, 0),
                    GetAllPrograms
                );

            var program = programs.Find(p => ProgramCode.FromString(p.Item5).Equals(programCode));
            if (program == null)
                throw new ValidationException(1000, 0, $"The program code {programCode} in the API path is unknown.");

            return new Program(programCode, program.Item1, program.Item6);
        }

        public ProductProgramPartner GetProductProgramPartner(ProgramCode programCode)
        {
            throw new NotImplementedException();
        }

        public ProductTypeInfo GetProductTypeByProductKey(int productKey)
        {
            throw new NotImplementedException();
        }

        public async Task<ProgramInfo> GetProgramTierInfo(int programKey)
        {
            return await _lazyCache.GetAsync(
                    "PROGRAM_TIER_" + programKey,
                    new TimeSpan(0, 2, 0, 0),
                    () => GetProgramInfo(programKey)
                );
        }

        private async Task<List<Tuple<int, int, string, string, string, string>>> GetAllPrograms()
        {
            var returnValue = new List<Tuple<int, int, string, string, string, string>>();

            using var connection = _dataAccess.CreateConnection();
            using (var reader = await _dataAccess.ExecuteReaderAsync("GetAllProgram", CommandType.StoredProcedure, connection, default, null))
            {
                while (await reader.ReadAsync())
                {
                    var programKey = reader.GetInt32(0);
                    var brandKey = reader.GetInt32(1);
                    var programName = reader.IsDBNull(reader.GetOrdinal("ProgramName")) ? null : reader.GetString(reader.GetOrdinal("ProgramName"));
                    var programDescription = reader.IsDBNull(reader.GetOrdinal("ProgramDescription")) ? null : reader.GetString(reader.GetOrdinal("ProgramDescription"));
                    var programCode = reader.IsDBNull(reader.GetOrdinal("ProgramCode")) ? null : reader.GetString(reader.GetOrdinal("ProgramCode"));
                    var achPrefix = reader.IsDBNull(reader.GetOrdinal("ACHPrefix")) ? null : reader.GetString(reader.GetOrdinal("ACHPrefix"));

                    returnValue.Add(new Tuple<int, int, string, string, string, string>(programKey, brandKey, programName, programDescription, programCode, achPrefix));
                }
            }

            return returnValue;
        }

        private async Task<ProgramInfo> GetProgramInfo(int programKey)
        {
            var rs = new ProgramInfo()
            {
                ProductTiers = new List<ProductTierInfo>(),
                ProductmaterialTypes = new List<ProductmaterialType>()
            };
            var parameters = new[] { new SqlParameter() { ParameterName = "ProgramKey", Value = programKey, SqlDbType = SqlDbType.Int } };

            using var connection = _dataAccess.CreateConnection();
            using (var reader = await _dataAccess.ExecuteReaderAsync("[dbo].[GetProgramInfo]", CommandType.StoredProcedure, connection, default, parameters))
            {
                while (await reader.ReadAsync())
                {
                    if (!reader.IsDBNull((reader.GetOrdinal("productTierclasskey"))))
                    {
                        var item = new ProductTierInfo();
                        item.ProductKey = reader.GetInt32(reader.GetOrdinal("ProductKey"));
                        item.ProductCode = reader.GetString(reader.GetOrdinal("ProductCode"));
                        item.ProductClassKey = reader.GetInt16(reader.GetOrdinal("ProductClassKey"));
                        item.ProductTierKey = reader.GetInt32(reader.GetOrdinal("ProductTierKey"));
                        item.ProductTier = reader.GetString(reader.GetOrdinal("ProductTier"));
                        item.ProductTierClasskey = reader.GetInt16(reader.GetOrdinal("productTierclasskey"));
                        item.IsDefault = reader.GetBoolean(reader.GetOrdinal("IsDefault"));
                        item.ProductTierAttributeKey = reader.GetInt16(reader.GetOrdinal("ProductTierAttributeKey"));
                        item.ProductTierAttribute = reader.GetString(reader.GetOrdinal("ProductTierAttribute"));
                        item.Value = reader.GetString(reader.GetOrdinal("Value"));
                        item.ProcessorKey = reader.GetInt16(reader.GetOrdinal("ProcessorKey"));
                        rs.ProductTiers.Add(item);
                    }
                }

                reader.NextResult();
                while (reader.Read())
                {
                    var item = new ProductmaterialType();

                    item.ProcessorKey = reader.GetInt16(reader.GetOrdinal("ProcessorKey"));
                    item.ProductMaterialType = reader.GetString((reader.GetOrdinal("ProductmaterialType")));
                    item.ProcessorValue = reader.GetString(reader.GetOrdinal("Value"));
                    item.IsDefault = reader["IsDefault"] != DBNull.Value && (bool)reader["IsDefault"];
                    rs.ProductmaterialTypes.Add(item);
                }
            }
            return rs;
        }
    }
}
