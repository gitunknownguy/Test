﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.RabbitMQ.Contract;
using Newtonsoft.Json;
using NLog;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;

namespace RequestHandler.Core.Infrastructure
{
    public class AmmAccountStatusNotificationService : IAmmAccountStatusNotificationService
    {
        private readonly IWriter<string> _queueWriter;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();

        public AmmAccountStatusNotificationService(IWriter<string> queueWriter)
        {
            _queueWriter = queueWriter;
        }

        public Task PublishNotification(AmmAccountStatusNotificationRequest request)
        {
            if (request.RequestHeader == null)
            {
                request.RequestHeader = new RequestHeader { RequestId = Guid.NewGuid() };
            }

            if (request.RequestHeader?.RequestId == default(Guid))
            {
                request.RequestHeader.RequestId = Guid.NewGuid();
            }

            var message = JsonConvert.SerializeObject(request,
                new JsonSerializerSettings { DateFormatHandling = DateFormatHandling.IsoDateFormat, NullValueHandling = NullValueHandling.Ignore });

            lock (_queueWriter)
            {
                var headers = new Dictionary<string, object>()
                {
                    {"AccountIdentifier", request.AccountIdentifier },
                    {"ProgramCode", request.ProgramCode },
                    {"NotificationType", request.NotificationType.ToString() },
                    {"RequestId", request?.RequestHeader?.RequestId.ToString() }
                };
                _queueWriter.Write(message, string.Empty, headers);
            }

            LogPublishNotificationRequest(request.RequestHeader?.RequestId.ToString(), message);

            return Task.CompletedTask;
        }

        private void LogPublishNotificationRequest(string requestId, string message)
        {
            _logger.Info($"Sending message with request id {requestId} to AmmAccountStatusNotification queue: {Gd.Bos.Logging.Common.Managers.MaskEngine.MaskMessage(message)}");
        }
    }
}
