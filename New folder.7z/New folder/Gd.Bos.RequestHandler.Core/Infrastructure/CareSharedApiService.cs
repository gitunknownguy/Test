﻿using Gd.Bos.RequestHandler.Core.Domain.Services.CareSharedApi;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using NLog;
using RequestHandler.Core.Infrastructure;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class CareSharedApiService : ICareSharedApiService
    {
        private readonly string _careSharedApiUrl;
        private readonly string _createCustomerCareCaseUrl = @"/api/Case";
        private readonly string _timeOutHeaderName = "X-GD-Bos-RH-CreateCareCaseTimeOut";
        private readonly string _rejectedHeaderName = "X-GD-Bos-RH-CreateCareCaseRejected";
        private readonly IServiceInvokeProvider _serviceInvokerProvider;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();

        public CareSharedApiService(IServiceInvokeProvider serviceInvokeProvider)
        {
            _careSharedApiUrl = Configuration.Configuration.Current.CareSharedApiBaseUrl;
            _serviceInvokerProvider = serviceInvokeProvider;
        }

        public CreateCareCaseResponse CreateCustomerCareCase(CreateCareCaseRequest request)
        {
            int? requestTimeout = null;
            if (OptionsContext.Current.IsDefined(_timeOutHeaderName))
            {
                if (int.TryParse(OptionsContext.Current.GetString(_timeOutHeaderName), out var rt))
                    requestTimeout = rt;
            }

            if (OptionsContext.Current.IsDefined(_rejectedHeaderName))
            {
                throw new CareCaseException(3, 242, "Creating customer care case was rejected.");
            }

            string url = $"{_careSharedApiUrl}{_createCustomerCareCaseUrl}";
            _logger.Info($"CareSharedApi url:{url}");
            var response = _serviceInvokerProvider.GetResponseAsync<CreateCareCaseRequest, CreateCareCaseResponse>(url, "POST", request, 
                null, requestTimeout).Result;
            if (response != null && !response.Success) throw new CareCaseException(3, 242, response.ErrorMessage ?? "Creating customer care case was rejected.");
            if (response == null || !response.Success || string.IsNullOrEmpty(response.CaseNumber)) throw new System.Exception("Create customer care case failed.");
            return response;
        }

        public CreateCareCaseResponse CreateNameChangeCareCase(NameChangeCareCaseRequest request)
        {
            int? requestTimeout = null;
            if (OptionsContext.Current.IsDefined(_timeOutHeaderName))
            {
                if (int.TryParse(OptionsContext.Current.GetString(_timeOutHeaderName), out var rt))
                    requestTimeout = rt;
            }

            if (OptionsContext.Current.IsDefined(_rejectedHeaderName))
            {
                throw new CareCaseException(3, 242, "Creating customer care case was rejected.");
            }

            string url = $"{_careSharedApiUrl}{_createCustomerCareCaseUrl}";
            _logger.Info($"CareSharedApi url:{url}");
            var response = _serviceInvokerProvider.GetResponseAsync<NameChangeCareCaseRequest, CreateCareCaseResponse>(url, "POST", request, 
                null, requestTimeout).Result;
            if (response != null && !response.Success) throw new CareCaseException(3, 242, response.ErrorMessage ?? "Creating customer care case was rejected.");
            if (response == null || !response.Success || string.IsNullOrEmpty(response.CaseNumber)) throw new System.Exception("Create customer care case failed.");
            return response;
        }
    }
}
