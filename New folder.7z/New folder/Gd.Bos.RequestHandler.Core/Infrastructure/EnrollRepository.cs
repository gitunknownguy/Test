﻿using Cassandra;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Core.Infrastructure.Enrollment;
using Gd.Bos.Shared.Common.Cassandra.Contract;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.Shared.Common.Cosmos.Contract;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using NLog;
using RequestHandler.Core.Application;
using RequestHandler.Core.Domain.Enums;
using RequestHandler.Core.Domain.Model.Business;
using RequestHandler.Core.Infrastructure.Enrollment;
using RequestHandler.Core.Utils;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Runtime.InteropServices;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    [ExcludeFromCodeCoverage(Justification = "Due to time constraint on migration we need to revisit")]
    public class EnrollRepository : IEnrollRepository
    {
        private readonly ICassandraAccess _cassandraAccess;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        private const string key = "dFXv0dSOrXyaWrBVdt/V0w==";
        private IDataAccess _dataAccess;
        private readonly IUserService _userService;
        private readonly IBusinessDataLookupService _businessDataLookupService;
        private readonly IAccountRepository _accountRepository;
        private readonly ICosmosAccess _cosmosAccess;
        private readonly IRequestHandlerSettings _configurationProvider;

        public EnrollRepository(IAccountRepository accountRepository, IBusinessDataLookupService businessDataLookupService, ICassandraAccess cassandraAccess, IDataAccess dataAccess, IUserService userService, IRequestHandlerSettings configurationProvider, ICosmosAccess cosmosAccess)
        {
            _accountRepository = accountRepository;
            _cassandraAccess = cassandraAccess;
            _dataAccess = dataAccess;
            _userService = userService;
            _businessDataLookupService = businessDataLookupService;
            _configurationProvider = configurationProvider;
            _cosmosAccess = cosmosAccess;
        }
        public EnrollEvent GetEnrollEventByRequestId(Guid requestId)
        {
            try
            {
                const string returnEvent =
                    "select * from enrollment.event_info where request_id=?";
                var parms = new object[] { requestId };
                var rowset = CosmosUtils.UseCosmos(_configurationProvider) ? _cosmosAccess.ExecuteStatementAsync(returnEvent,parms).Result : _cassandraAccess.ExecuteStatementAsync(returnEvent, parms).Result;
                var result = rowset.FirstOrDefault();
                if (result == null) return default(EnrollEvent);
                var state_id = result.GetValue<int>("event_state_id");
                var eventState = (EnrollEvent)state_id;
                return eventState;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"RequestId: {requestId} Error:{ex.Message}");
            }

            return default(EnrollEvent);
        }

        public PreSignupEnrollmentRequest GetTempCardEnrollRequestByRequestId(Guid verificationIdentifier)
        {
            try
            {

                const string returnEnrollRequest_cassandra =
                    @"SELECT * FROM enrollment.event_info_by_verification_identifier 
                    where verification_identifier = ? allow filtering;";
                const string returnEnrollRequest_cosmos =
                    @"SELECT * FROM enrollment.event_info_by_verification_identifier 
                    where verification_identifier = ?;";
                var parms = new object[] { verificationIdentifier };
                var rowset = CosmosUtils.UseCosmos(_configurationProvider) ? _cosmosAccess.ExecuteStatement(returnEnrollRequest_cosmos, parms) : _cassandraAccess.ExecuteStatement(returnEnrollRequest_cassandra, parms);
                var result = rowset.FirstOrDefault();

                if (result == null) return null;
                var json = result.GetValue<string>("event_data");

                var response = JsonConvert.DeserializeObject<PreSignupEnrollmentRequest>(json);
                response.UserCreationData.IdentifyingData.DateOfBirth =
                    AesOperation.DecryptString(key, response.UserCreationData.IdentifyingData.DateOfBirth);

                return response;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"RequestId: {verificationIdentifier} Error:{ex.Message}");
            }

            return null;
        }

        public void SaveEnrollRequest(EnrollRequest enrollRequest, string accountIdentifier)
        {
            try
            {
                if (OptionsContext.Current.IsDefined("X-GD-Bos-RequestHandler-Cassandra"))
                    throw new ArgumentException("Cassandra failed.");
                string tempDOB = null;
                if (enrollRequest?.UserCreationData?.IdentifyingData != null)
                {
                    tempDOB = enrollRequest?.UserCreationData?.IdentifyingData?.DateOfBirth;
                    enrollRequest.UserCreationData.IdentifyingData.DateOfBirth =
                        AesOperation.EncryptString(key, enrollRequest?.UserCreationData?.IdentifyingData?.DateOfBirth);
                }

                var json = JsonConvert.SerializeObject(enrollRequest);
                const string saveAccountHolderRequest = "insert into " +
                    "enrollment.event_info(request_id,account_identifier,event_data,event_date,event_id,event_name,event_state,event_state_id,product_material_type,request_physical_card) " +
                    "values(?,?,?,?,?,?,?,?,?,?)";
                const string saveAccountHolderRequest_account_identifer = "insert into " +
                    "enrollment.event_info_by_account_identifier(request_id,account_identifier,event_data,event_date,event_id,event_name,event_state,event_state_id,product_material_type,request_physical_card) " +
                    "values(?,?,?,?,?,?,?,?,?,?)";
                //if it does not have verification identifer it does not need to be update in event_info_by_verification_identifier

                var parms = new object[] { enrollRequest.RequestHeader.RequestId, Guid.Parse(accountIdentifier), json, DateTime.Now, Convert.ToInt32(EnrollEvent.EnrollAccountHolder),
                    EnrollEvent.EnrollAccountHolder.ToString(), EnrollState.CreateAccountHolder.ToString(), Convert.ToInt32(EnrollState.CreateAccountHolder), enrollRequest.AccountCreationData.ProductMaterialType,enrollRequest.RequestPhysicalCardFlag};
                if(CosmosUtils.UseCosmos(_configurationProvider))
                {
                    _cosmosAccess.ExecuteStatement(saveAccountHolderRequest, parms);
                    _cosmosAccess.ExecuteStatement(saveAccountHolderRequest_account_identifer, parms);
                }
                else
                {
                    _cassandraAccess.ExecuteStatement(saveAccountHolderRequest, parms);
                }

                if (enrollRequest?.UserCreationData?.IdentifyingData != null)
                {
                    enrollRequest.UserCreationData.IdentifyingData.DateOfBirth = tempDOB;
                }

            }
            catch (Exception ex)
            {
                if (enrollRequest?.UserCreationData?.IdentifyingData != null)
                    enrollRequest.UserCreationData.IdentifyingData.DateOfBirth =
                                                            AesOperation.DecryptString(key, enrollRequest?.UserCreationData?.IdentifyingData?.DateOfBirth);
                _logger.Error(ex, $"RequestId: {enrollRequest.RequestHeader?.RequestId} Error:{ex.Message}");

                // TODO : throw error when we are ready to implement idempotency for enrollment
                //throw new RequestHandlerException(503, 0, "Connection has been timed out, pls retry");
            }
        }

        public void SaveEnrollRequest(PreSignUpRequest PreSignUpRequest, string verificationIdentifier)
        {
            try
            {
                if (OptionsContext.Current.IsDefined("X-GD-Bos-RequestHandler-Cassandra"))
                    throw new ArgumentException("Cassandra failed.");
                string tempDOB = null;
                if (PreSignUpRequest?.UserCreationData?.IdentifyingData != null)
                {
                    tempDOB = PreSignUpRequest?.UserCreationData?.IdentifyingData?.DateOfBirth;
                    PreSignUpRequest.UserCreationData.IdentifyingData.DateOfBirth =
                        AesOperation.EncryptString(key, PreSignUpRequest?.UserCreationData?.IdentifyingData?.DateOfBirth);
                }

                var json = JsonConvert.SerializeObject(PreSignUpRequest);
                const string saveAccountHolderRequest = "insert into enrollment.event_info(" +
                    "request_id,account_identifier,event_data,event_date,event_id,event_name,event_state,event_state_id,product_material_type,request_physical_card, verification_identifier) " +
                    "values(?,?,?,?,?,?,?,?,?,?,?)";
                const string saveAccountHolderRequest_event_info_by_verification_identifier = "insert into enrollment.event_info_by_verification_identifier(" +
                    "request_id,account_identifier,event_data,event_date,event_id,event_name,event_state,event_state_id,product_material_type,request_physical_card, verification_identifier) " +
                    "values(?,?,?,?,?,?,?,?,?,?,?)";
                const string saveAccountHolderRequest_event_info_by_account_identifier = "insert into enrollment.event_info_by_account_identifier(" +
                    "request_id,account_identifier,event_data,event_date,event_id,event_name,event_state,event_state_id,product_material_type,request_physical_card, verification_identifier) " +
                    "values(?,?,?,?,?,?,?,?,?,?,?)";

                var parms = new object[] {
                    PreSignUpRequest.RequestHeader.RequestId,
                    Guid.Parse(verificationIdentifier),
                    json,
                    DateTime.Now,
                    Convert.ToInt32(EnrollEvent.EnrollAccountHolder),
                    EnrollEvent.EnrollAccountHolder.ToString(),
                    EnrollState.CreateAccountHolder.ToString(),
                    Convert.ToInt32(EnrollState.CreateAccountHolder),
                    PreSignUpRequest.AccountCreationData.ProductMaterialType,
                    false,
                    Guid.Parse(verificationIdentifier)
                };
                if(CosmosUtils.UseCosmos(_configurationProvider))
                {
                    _cosmosAccess.ExecuteStatement(saveAccountHolderRequest, parms);
                    _cosmosAccess.ExecuteStatement(saveAccountHolderRequest_event_info_by_verification_identifier, parms);
                    _cosmosAccess.ExecuteStatement(saveAccountHolderRequest_event_info_by_account_identifier, parms);
                }
                else
                {
                    _cassandraAccess.ExecuteStatement(saveAccountHolderRequest, parms);
                }

                if (PreSignUpRequest?.UserCreationData?.IdentifyingData != null)
                {
                    PreSignUpRequest.UserCreationData.IdentifyingData.DateOfBirth = tempDOB;
                }

            }
            catch (Exception ex)
            {
                if (PreSignUpRequest?.UserCreationData?.IdentifyingData != null)
                    PreSignUpRequest.UserCreationData.IdentifyingData.DateOfBirth =
                        AesOperation.DecryptString(key, PreSignUpRequest?.UserCreationData?.IdentifyingData?.DateOfBirth);
                _logger.Error(ex, $"RequestId: {PreSignUpRequest.RequestHeader?.RequestId} Error:{ex.Message}");

                // TODO : throw error when we are ready to implement idempotency for enrollment
                //throw new RequestHandlerException(503, 0, "Connection has been timed out, pls retry");
            }
        }

        public void UpdateEnrollRequestByRequestId(EnrollRequest enrollRequest, string accountIdentifier)
        {
            try
            {
                if (OptionsContext.Current.IsDefined("X-GD-Bos-RequestHandler-Cassandra"))
                    throw new ArgumentException("Cassandra failed.");

                string tempDOB = null;
                if (enrollRequest?.UserCreationData?.IdentifyingData != null)
                {
                    tempDOB = enrollRequest?.UserCreationData?.IdentifyingData?.DateOfBirth;
                    enrollRequest.UserCreationData.IdentifyingData.DateOfBirth =
                        AesOperation.EncryptString(key, enrollRequest?.UserCreationData?.IdentifyingData?.DateOfBirth);
                }

                var json = JsonConvert.SerializeObject(enrollRequest);
                const string updateEvent = "update enrollment.event_info set event_data=?,account_identifier=? where request_id=?";



                var parms = new object[] { json, Guid.Parse(accountIdentifier), enrollRequest.RequestHeader.RequestId };
                if (!CosmosUtils.UseCosmos(_configurationProvider))
                {
                    var rowset = _cassandraAccess.ExecuteStatement(updateEvent, parms);
                }
                else
                {
                    // Cosmos update for event_info_by_verification_identifier
                    Guid? verification_identifer = GetVerificationIdentifier(enrollRequest.RequestHeader.RequestId);
                    Guid? verification_identifer_in_VF = GetVerificationIdentifier_in_verificationidentifer(verification_identifer.Value);
                    if (verification_identifer.HasValue && verification_identifer_in_VF.HasValue)
                    {
                        const string updateEvent_event_info_by_verification_identifier = "update enrollment.event_info_by_verification_identifier set event_data=?,account_identifier=? where verification_identifier=?";
                        var parms1 = new object[] { json, Guid.Parse(accountIdentifier), verification_identifer };
                        _cosmosAccess.ExecuteStatement(updateEvent_event_info_by_verification_identifier, parms1);
                        var rowset1 = _cosmosAccess.ExecuteStatement(updateEvent, parms1);
                    }
                    else
                    {
                        _logger.Warn("Verification Identifier not found for request id, So it is not upadted in event_info_by_verification_identifier table" + enrollRequest.RequestHeader.RequestId);
                    }
                    // cosmos update for event_info_by_account_identifier
                    Guid? account_identifier = GetAccountIdentifier(enrollRequest.RequestHeader.RequestId);
                    if(account_identifier.HasValue)
                    {
                        const string updateEvent_event_info_by_account_identifier = "update enrollment.event_info_by_account_identifier set event_data=? where account_identifier=?";
                        var parms1 = new object[] { json, Guid.Parse(accountIdentifier)};
                        _cosmosAccess.ExecuteStatement(updateEvent_event_info_by_account_identifier, parms1);
                    }
                    else
                    {
                        _logger.Warn("Account Identifier not found for request id, So it is not upadted in event_info_by_account_identifier table" + enrollRequest.RequestHeader.RequestId);
                    }
                }
                if (enrollRequest?.UserCreationData?.IdentifyingData != null)
                {
                    enrollRequest.UserCreationData.IdentifyingData.DateOfBirth = tempDOB;
                }
          
            }
            catch (Exception ex)
            {
                if (enrollRequest?.UserCreationData?.IdentifyingData?.DateOfBirth != null)
                    enrollRequest.UserCreationData.IdentifyingData.DateOfBirth =
                        AesOperation.DecryptString(key, enrollRequest.UserCreationData?.IdentifyingData?.DateOfBirth);

                _logger.Error(ex, $"RequestId: {enrollRequest.RequestHeader?.RequestId} Error:{ex.Message}");

                // TODO : throw error when we are ready to implement idempotency for enrollment
                //throw new RequestHandlerException(503, 0, "Connection has been timed out, pls retry");
            }
        }

        public void InsertCardArt(Guid requestId, string cardArt)
        {
            try
            {
                const string updateEvent = "update  " +
                    "enrollment.event_info set card_art=?" +
                    " where request_id=?";

                var parms = new object[] { cardArt, requestId };
                if(!CosmosUtils.UseCosmos(_configurationProvider))
                {
                    var rowset = _cassandraAccess.ExecuteStatement(updateEvent, parms);
                }
                else
                {
                    // Cosmos update for event_info_by_verification_identifier
                    Guid? verification_identifer = GetVerificationIdentifier(requestId);
                    Guid? verification_identifer_in_VF = GetVerificationIdentifier_in_verificationidentifer(verification_identifer.Value);
                    if (verification_identifer.HasValue && verification_identifer_in_VF.HasValue)
                    {
                        const string updateEvent_event_info_by_verification_identifier = "update  " +
                            "enrollment.event_info_by_verification_identifier set card_art=?" +
                            " where verification_identifier=?";
                        var parms1 = new object[] { cardArt, verification_identifer };
                        var rowset = _cosmosAccess.ExecuteStatement(updateEvent, parms);
                        var rowset1 = _cosmosAccess.ExecuteStatement(updateEvent_event_info_by_verification_identifier, parms1);
                    }
                    else
                    {
                        _logger.Warn("Verification Identifier not found for request id, So it is not upadted in event_info_by_verification_identifier table" + requestId);
                    }
                    // Cosmos update for event_info_by_account_identifier
                    Guid? account_identifer = GetAccountIdentifier(requestId);
                    if (account_identifer.HasValue)
                    {
                        const string updateEvent_event_info_by_account_identifier = "update  " +
                            "enrollment.event_info_by_account_identifier set card_art=?" +
                            " where account_identifier=?";
                        var parms1 = new object[] { cardArt, verification_identifer };
                        var rowset1 = _cosmosAccess.ExecuteStatement(updateEvent_event_info_by_account_identifier, parms1);
                    }
                    else
                    {
                        _logger.Warn("account Identifier not found for request id, So it is not upadted in event_info_by_account_identifier table" + requestId);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"UpdateEnrollEventByRequestId: {requestId} Error:{ex.Message}");
            }
        }

        public void SetEventByRequestId(Guid requestId, EnrollState enrollEvent)
        {
            try
            {
                const string updateEvent = "update  " +
                    "enrollment.event_info set event_state_id=?,event_state=?" +
                    " where request_id=?";

                var parms = new object[] { Convert.ToInt32(enrollEvent), enrollEvent.ToString(), requestId };
                if(!CosmosUtils.UseCosmos(_configurationProvider))
                {
                    var rowset = _cassandraAccess.ExecuteStatement(updateEvent, parms);
                }
                else
                {
                    var rowset = _cosmosAccess.ExecuteStatement(updateEvent, parms);
                    // Cosmos update for event_info_by_verification_identifier
                    Guid? verification_identifer = GetVerificationIdentifier(requestId);
                    Guid? verification_identifer_in_VF = GetVerificationIdentifier_in_verificationidentifer(verification_identifer.Value);
                    if (verification_identifer.HasValue && verification_identifer_in_VF.HasValue)
                    {
                        const string updateEvent_event_info_by_verification_identifier = "update  " +
                            "enrollment.event_info_by_verification_identifier set event_state_id=?,event_state=?" +
                            " where verification_identifier=?";
                        var parms1 = new object[] { Convert.ToInt32(enrollEvent), enrollEvent.ToString(), verification_identifer };
                        var rowset1 = _cosmosAccess.ExecuteStatement(updateEvent_event_info_by_verification_identifier, parms1);
                    }
                    else
                    {
                        _logger.Warn("Verification Identifier not found for request id, So it is not upadted in event_info_by_verification_identifier table" + requestId);
                    }
                    // Cosmos update for event_info_by_verification_identifier
                    Guid? account_identifer = GetAccountIdentifier(requestId);
                    if (account_identifer.HasValue)
                    {
                        const string updateEvent_event_info_by_account_identifier = "update  " +
                            "enrollment.event_info_by_account_identifier set event_state_id=?,event_state=?" +
                            " where account_identifier=?";
                        var parms1 = new object[] { Convert.ToInt32(enrollEvent), enrollEvent.ToString(), account_identifer };
                        var rowset1 = _cosmosAccess.ExecuteStatement(updateEvent_event_info_by_account_identifier, parms1);
                    }
                    else
                    {
                        _logger.Warn("account Identifier not found for request id, So it is not upadted in event_info_by_account_identifier table" + requestId);
                    }
                }              
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"UpdateEnrollEventByRequestId: {requestId} Error:{ex.Message}");
            }
        }

        public BusinessInfoResponse SaveBusinessEnrollRequest(BusinessInfoRequest businessInfoRequest)
        {
            var response = new BusinessInfoResponse();
            response.ResponseHeader = new ResponseHeader();
            try
            {
                if (OptionsContext.Current.IsDefined("X-GD-Bos-RequestHandler-Cassandra"))
                    throw new ArgumentException("Cassandra failed.");

                var existingBusinessInfo = GetExistingBusinessInfo(businessInfoRequest);

                var businessEnrollmentRequest = new BusinessEnrollment();
                var json = "";
                var _enrollowner = new OwnerProfileData();
                bool isOwner = false;

                var consumerProfileId = _userService.GetBusinessUser(businessInfoRequest.AccountIdentifier).Item1.UserIdentifier;

                if (businessInfoRequest.BusinessInfo.CompanyProfileRoleCode == ConsumerProfileRole.OWNR.ToString() ||
                    businessInfoRequest.BusinessInfo.CompanyProfileRoleCode == ConsumerProfileRole.OME25.ToString())
                {
                    isOwner = true;
                    _enrollowner = GetOwner(_enrollowner, consumerProfileId.ToString(), businessInfoRequest.AccountIdentifier);
                }

                BusinessDataLookupRequest request = new BusinessDataLookupRequest
                {
                    RequestHeader = new RequestHeader
                    {
                        RequestId = businessInfoRequest.RequestHeader.RequestId,
                    },
                    ProgramCode = businessInfoRequest.ProgramCode
                };

                // Update BusinessInfo
                if (existingBusinessInfo.Item2 && existingBusinessInfo.Item4 == 1)
                {
                    var owners = new List<OwnerProfileData>();
                    if (existingBusinessInfo.Item1.OwnersInfo != null)
                        owners = existingBusinessInfo?.Item1?.OwnersInfo;

                    if (existingBusinessInfo.Item5.CompanyProfileRoleCode != businessInfoRequest.BusinessInfo.CompanyProfileRoleCode
                        || existingBusinessInfo.Item5.CompanyProfileTypeCode != businessInfoRequest.BusinessInfo.CompanyProfileTypeCode)
                    {
                        if (isOwner)
                        {
                            if (existingBusinessInfo.Item5.CompanyProfileRoleCode != ConsumerProfileRole.OWNR.ToString()
                                || existingBusinessInfo.Item5.CompanyProfileRoleCode != ConsumerProfileRole.OME25.ToString())
                            {
                                DeleteExistingOwner(businessInfoRequest.AccountIdentifier, existingBusinessInfo.Item1, existingBusinessInfo?.Item1?.OwnersInfo);
                                owners.Add(_enrollowner);
                                existingBusinessInfo.Item1.OwnersInfo = new List<OwnerProfileData>();
                                existingBusinessInfo.Item1.OwnersInfo = owners;
                            }
                            else
                            {
                                bool isOwnerExist = false;
                                if (owners != null)
                                {
                                    foreach (var owner in owners)
                                    {
                                        if (owner.IsVerified)
                                        {
                                            isOwnerExist = true;
                                        }
                                    }
                                }
                                if (!isOwnerExist && (existingBusinessInfo.Item5.CompanyProfileRoleCode != ConsumerProfileRole.OME25.ToString() || existingBusinessInfo.Item5.CompanyProfileRoleCode != ConsumerProfileRole.OWNR.ToString()))
                                {
                                    DeleteExistingOwner(businessInfoRequest.AccountIdentifier, existingBusinessInfo.Item1, existingBusinessInfo?.Item1?.OwnersInfo);
                                }
                                if (!isOwnerExist)
                                {
                                    owners.Add(_enrollowner);
                                    existingBusinessInfo.Item1.OwnersInfo = new List<OwnerProfileData>();
                                    existingBusinessInfo.Item1.OwnersInfo = owners;
                                }
                            }
                        }
                        else
                        {
                            DeleteExistingOwner(businessInfoRequest.AccountIdentifier, existingBusinessInfo.Item1, existingBusinessInfo?.Item1?.OwnersInfo);
                        }
                    }
                    json = JsonConvert.SerializeObject(existingBusinessInfo.Item1);
                    
                    const string updateBusinessProfileRequest = "update enrollment.event_info " +
                                                                "set event_data=? " +
                                                                "where request_id=?;";
                    var parameters = new object[] { json, existingBusinessInfo.Item3 };
                    _cosmosAccess.ExecuteStatement(updateBusinessProfileRequest, parameters);

                    Guid? verificationIdentifier = GetVerificationIdentifier(existingBusinessInfo.Item3);
                    if (verificationIdentifier != Guid.Empty)
                    {
                        const string updateBusinessProfileRequestEventInfoByVerificationIdentifier = "update enrollment.event_info_by_verification_identifier " +
                            "set event_data=? " +
                            "where verification_identifier=?;";
                        var parameters1 = new object[] { json, verificationIdentifier };
                        _cosmosAccess.ExecuteStatement(updateBusinessProfileRequestEventInfoByVerificationIdentifier, parameters1);
                    }
                    else
                    {
                        _logger.Warn("Verification Identifier not found for request id, So it is not upadted in event_info_by_verification_identifier table" + existingBusinessInfo.Item3);
                    }
                    // Cosmos update for event_info_by_account_identifier
                    Guid? accountIdentifier = GetAccountIdentifier(existingBusinessInfo.Item3);
                    if (accountIdentifier != Guid.Empty)
                    {
                        const string updateBusinessProfileRequestAccountIdentifier = "update enrollment.event_info_by_account_identifier " +
                            "set event_data=? " +
                            "where account_identifier=?;";
                        var parameters2 = new object[] { json, accountIdentifier };
                        _cosmosAccess.ExecuteStatement(updateBusinessProfileRequestAccountIdentifier, parameters2);
                    }
                    else
                    {
                        _logger.Warn("account Identifier not found for request id, So it is not upadted in event_info_by_account_identifier table" + existingBusinessInfo.Item3);
                    }
                }
                // Create New BusinessInfo
                else if (existingBusinessInfo.Item4 == 0)
                {
                    if (isOwner)
                    {
                        businessEnrollmentRequest.OwnersInfo = new List<OwnerProfileData>();
                        businessEnrollmentRequest.OwnersInfo.Add(_enrollowner);
                    }

                    businessEnrollmentRequest.BusinessInfo = businessInfoRequest.BusinessInfo;
                    json = JsonConvert.SerializeObject(businessEnrollmentRequest);
                    const string saveBusinessProfileRequest = "insert into enrollment.event_info(" +
                                                              "request_id," +
                                                              "account_identifier," +
                                                              "event_data," +
                                                              "event_date," +
                                                              "event_id," +
                                                              "event_name," +
                                                              "event_state," +
                                                              "event_state_id," +
                                                              "product_material_type," +
                                                              "request_physical_card) " +
                                                              "values(?,?,?,?,?,?,?,?,?,?)";
                    const string saveBusinessProfileRequestAccountIdentifier =
                        "insert into enrollment.event_info_by_account_identifier(" +
                        "request_id," +
                        "account_identifier," +
                        "event_data," +
                        "event_date," +
                        "event_id," +
                        "event_name," +
                        "event_state," +
                        "event_state_id," +
                        "product_material_type," +
                        "request_physical_card) " +
                        "values(?,?,?,?,?,?,?,?,?,?)";
                    // this insert does not have verification identifier so it does not need to be update in event_info_by_verification_identifier
                    var parameters = new object[]
                    {
                        businessInfoRequest.RequestHeader.RequestId,
                        Guid.Parse(businessInfoRequest.AccountIdentifier), json, DateTime.Now,
                        Convert.ToInt32(EnrollEvent.EnrollBusinessAccount),
                        EnrollEvent.EnrollBusinessAccount.ToString(), EnrollState.CreateBusinessAccount.ToString(),
                        Convert.ToInt32(EnrollState.CreateBusinessAccount), "1", false
                    };
                    _cosmosAccess.ExecuteStatement(saveBusinessProfileRequest, parameters);
                    _cosmosAccess.ExecuteStatement(saveBusinessProfileRequestAccountIdentifier, parameters);
                }

                response.ResponseHeader.Message = "Success";
                return response;

            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"RequestId: {businessInfoRequest.RequestHeader?.RequestId} Error:{ex.Message}");
                response.ResponseHeader.StatusCode = 503;
                response.ResponseHeader.SubStatusCode = 0;
                response.ResponseHeader.Message = "Fail";
                response.ResponseHeader.ResponseId = businessInfoRequest.RequestHeader.RequestId;
                // TODO : throw error when we are ready to implement idempotency for enrollment
                //throw new RequestHandlerException(503, 0, "Connection has been timed out, pls retry");
            }
            return response;
        }

        private OwnerProfileData GetOwner(OwnerProfileData _enrollowner, string consumerProfileId, string accountId)
        {
            Guid accountHolderId = Guid.Parse(_accountRepository.GetAccountInfoByAccountIdentifier(accountId).AccountHolders?.FirstOrDefault()?.AccountHolderIdentifier?.ToString());
            var _parameters = new[] {
                        new SqlParameter()
                          {
                          ParameterName = "ConsumerProfileIdentifier",
                         Value =Guid.Parse(consumerProfileId)
                           }
                        };
            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetConsumerProfile]",
                  _dataAccess.CreateConnectionWithColumnEncryption(), _parameters))
                if (reader.Read())
                {
                    _enrollowner.FirstName = reader["FirstName"].ToString();
                    _enrollowner.MiddleName = reader["MiddleName"] == DBNull.Value ? null : reader["MiddleName"].ToString();
                    _enrollowner.LastName = reader["LastName"].ToString();
                    _enrollowner.SSN = reader["Last4SSN"].ToString();
                    _enrollowner.DOB = AesOperation.EncryptString(key, reader["EncryptedDOB"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("EncryptedDOB")));
                }
            var _sqlparameters = new[] {
                        new SqlParameter()
                          {
                          ParameterName = "ConsumerProfileIdentifier",
                         Value =Guid.Parse(consumerProfileId)
                           },
                        };
            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetConsumerProfileAddress]",
                  _dataAccess.CreateConnection(), _sqlparameters))
                if (reader.Read())
                {
                    _enrollowner.AddressLineOne = reader["Address1"].ToString();
                    _enrollowner.AddressLineTwo = reader["Address2"] == DBNull.Value ? null : reader["Address2"].ToString();
                    _enrollowner.City = reader["City"].ToString();
                    _enrollowner.State = reader["State"].ToString();
                    _enrollowner.Zip = reader["ZipCode"].ToString();
                }
            _sqlparameters = new[] {
                    new SqlParameter()
                    {
                    ParameterName = "ConsumerProfileIdentifier",
                    Value =Guid.Parse(consumerProfileId)
                    },
                    new SqlParameter(){
                    ParameterName = "AccountIdentifier",
                    Value =Guid.Parse(accountId)
                    },
                    new SqlParameter(){
                    ParameterName = "AccountHolderIdentifier",
                    Value =accountHolderId
                    },
                };
            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetPrimaryConsumerProfileV3]",
               _dataAccess.CreateConnection(), _sqlparameters))
                if (reader.Read())
                {
                    reader.NextResult();
                    reader.NextResult();
                    _enrollowner.SSN = _accountRepository.ReadUserProfileIdentity(reader, 0)?.IdentityToken;
                }
            _enrollowner.IsVerified = true;
            _enrollowner.OwnerIdentifier = Guid.NewGuid().ToString();
            _enrollowner.IsConfirmedIndividual = true;
            return _enrollowner;
        }

        private void DeleteExistingOwner(string accountIdentifier, BusinessEnrollment item1, List<OwnerProfileData> ownerProfiles)
        {
            int i = 0;
            while (ownerProfiles != null && i < ownerProfiles.Count)
            {
                var ownerId = ownerProfiles[i].OwnerIdentifier;
                item1.OwnersInfo.RemoveAll(item =>
            item.OwnerIdentifier.Equals(ownerId,
                StringComparison.OrdinalIgnoreCase));

                UpdateBusinessMetaData(accountIdentifier, item1);
            }
        }

        public Tuple<BusinessEnrollment, bool, Guid, int, BusinessInfoData> GetExistingBusinessInfo(BusinessInfoRequest businessInfoRequest)
        {
            var jsonDataToUpdate = GetBusinessInfo(businessInfoRequest.AccountIdentifier);
            var businessInfoData = new BusinessInfoData();
            var businessContactInfoData = new BusinessContactInfoData();
            var ownerData = new List<OwnerProfileData>();
            var businessEnrollment = new BusinessEnrollment();
            bool isBusinessAlreadyExist = false;
            if (jsonDataToUpdate.Item3 == 1)
            {
                businessInfoData = JsonConvert.DeserializeObject<BusinessEnrollment>(jsonDataToUpdate.Item1).BusinessInfo == null ? null : JsonConvert.DeserializeObject<BusinessEnrollment>(jsonDataToUpdate.Item1).BusinessInfo;
                businessContactInfoData = JsonConvert.DeserializeObject<BusinessEnrollment>(jsonDataToUpdate.Item1).BusinessContactInfo == null ? null : JsonConvert.DeserializeObject<BusinessEnrollment>(jsonDataToUpdate.Item1).BusinessContactInfo;
                ownerData = JsonConvert.DeserializeObject<BusinessEnrollment>(jsonDataToUpdate.Item1).OwnersInfo == null ? null : JsonConvert.DeserializeObject<BusinessEnrollment>(jsonDataToUpdate.Item1).OwnersInfo;
                if (businessInfoData.BusinessName != null || businessInfoData.CompanyProfileTypeCode != null || businessInfoData.IncorporatedState != null || businessInfoData.CompanyProfileRoleCode != null || businessInfoData.BusinessIndustryCode != null || businessInfoData.TaxId != null)
                {
                    isBusinessAlreadyExist = true;
                    businessEnrollment.BusinessInfo = businessInfoRequest.BusinessInfo;
                    businessEnrollment.BusinessContactInfo = businessContactInfoData;
                    businessEnrollment.OwnersInfo = ownerData;
                }
            }

            return new Tuple<BusinessEnrollment, bool, Guid, int, BusinessInfoData>(businessEnrollment, isBusinessAlreadyExist, jsonDataToUpdate.Item2, jsonDataToUpdate.Item3, businessInfoData);
        }

        public BusinessContactInfoResponse SaveBusinessContactEnrollRequest(BusinessContactInfoRequest businessContactInfoRequest)
        {
            var response = new BusinessContactInfoResponse()
            {
                ResponseHeader = new ResponseHeader()
                {
                    StatusCode = 0,
                    SubStatusCode = 0
                }
            };
            try
            {
                if (OptionsContext.Current.IsDefined("X-GD-Bos-RequestHandler-Cassandra"))
                    throw new ArgumentException("Cassandra failed.");

                _logger.Info($"AccounIdentifier: {businessContactInfoRequest.AccountIdentifier}");
                _logger.Info($"RequestId: {businessContactInfoRequest.RequestHeader.RequestId}");
                var jsonDataToUpdate = GetBusinessInfo(businessContactInfoRequest.AccountIdentifier);
                if (jsonDataToUpdate.Item3 == 0)
                {
                    _logger.Error("Business information is null");
                    response.ResponseHeader.StatusCode = 400;
                    response.ResponseHeader.SubStatusCode = 4106;
                    response.ResponseHeader.Message = "Fail";
                    response.ResponseHeader.ResponseId = businessContactInfoRequest.RequestHeader.RequestId;
                    response.ResponseHeader.Details = "Business Information Not Found;Please Update Business Details";
                }

                else
                {
                    var businessInfoData = JsonConvert.DeserializeObject<BusinessEnrollment>(jsonDataToUpdate.Item1).BusinessInfo;
                    var ownerInfoData = JsonConvert.DeserializeObject<BusinessEnrollment>(jsonDataToUpdate.Item1).OwnersInfo;
                    if (ownerInfoData == null)
                        ownerInfoData = new List<OwnerProfileData>();
                    if (businessInfoData == null)
                        _logger.Error("Business information is null");

                    var businessEnrollmentRequest = new BusinessEnrollment()
                    {
                        BusinessContactInfo = businessContactInfoRequest.BusinessContactInfo,
                        BusinessInfo = businessInfoData,
                        OwnersInfo = ownerInfoData
                    };

                    var json = JsonConvert.SerializeObject(businessEnrollmentRequest);
                    const string saveBusinessContactInfoRequest = "update enrollment.event_info set event_data=? where request_id=?;";
                    var parameters = new object[] { json, jsonDataToUpdate.Item2 };
                    const string saveBusinessContactInfoRequest_event_info_by_verification_identifier = "update enrollment.event_info_by_verification_identifier set event_data=? where verification_identifier=?;";
                    const string saveBusinessContactInfoRequest_event_info_by_account_identifier = "update enrollment.event_info_by_account_identifier set event_data=? where account_identifier=?;";
                    if (CosmosUtils.UseCosmos(_configurationProvider))
                    {
                        _logger.Info("Executing the Cosmos DataBase");
                        _cosmosAccess.ExecuteStatement(saveBusinessContactInfoRequest, parameters);
                        Guid? verification_identifer = GetVerificationIdentifier(jsonDataToUpdate.Item2);
                        Guid? verification_identifer_in_VF = GetVerificationIdentifier_in_verificationidentifer(verification_identifer.Value);
                        if (verification_identifer.HasValue && verification_identifer_in_VF.HasValue)
                        {
                            var parameters1 = new object[] { json, verification_identifer };
                            _cosmosAccess.ExecuteStatement(saveBusinessContactInfoRequest_event_info_by_verification_identifier, parameters1);
                        }
                        else
                        {
                            _logger.Warn("Verification Identifier not found for request id, So it is not upadted in event_info_by_verification_identifier table" + jsonDataToUpdate.Item2);
                        }
                        // account identifier
                        Guid? account_identifer = GetAccountIdentifier(jsonDataToUpdate.Item2);

                        if (account_identifer.HasValue)
                        {
                            var parameters1 = new object[] { json, account_identifer };
                            _cosmosAccess.ExecuteStatement(saveBusinessContactInfoRequest_event_info_by_account_identifier, parameters1);
                        }
                        else
                        {
                            _logger.Warn("Account Identifier not found for request id, So it is not upadted in event_info_by_account_identifier table" + jsonDataToUpdate.Item2);
                        }
                    }
                    else
                    {
                        _logger.Info("Executing the cassandra DataBase");
                        _cassandraAccess.ExecuteStatement(saveBusinessContactInfoRequest, parameters);
                    }
                    response.ResponseHeader.Message = "Success";
                    response.ResponseHeader.ResponseId = businessContactInfoRequest.RequestHeader.RequestId;
                    if (CosmosUtils.UseCosmos(_configurationProvider))
                    {
                        _logger.Info("BusinessContact Information are added successfully in Cosmos DB");
                    }
                    else
                    {
                        _logger.Info("BusinessContact Information are added successfully in cassandra DB");
                    }
                }

            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"RequestId: {businessContactInfoRequest.RequestHeader?.RequestId} Error:{ex.Message}");

                // TODO : throw error when we are ready to implement idempotency for enrollment
                //throw new RequestHandlerException(503, 0, "Connection has been timed out, pls retry");
            }
            return response;
        }

        public virtual Tuple<string, Guid, int> GetBusinessInfo(string accountIdentifier)
        {
            string existingJsonData = string.Empty;
            var requestId = Guid.Empty;
            try
            {
                //const string returnEnrollRequest =
                //        "select event_data, request_id from enrollment.event_info where account_identifier=? and event_name='EnrollBusinessAccount' allow filtering;";
                const string returnEnrollRequest =
                        "select event_data, request_id, event_name from enrollment.event_info_by_account_identifier where account_identifier=?;";
                var parms = new object[] { Guid.Parse(accountIdentifier) };
                var rowCount = CosmosUtils.UseCosmos(_configurationProvider) ? _cosmosAccess.ExecuteStatement(returnEnrollRequest, parms) : _cassandraAccess.ExecuteStatement(returnEnrollRequest, parms);
                var businessInfoCount = rowCount.Where(x => x.GetValue<string>("event_name") == "EnrollBusinessAccount").Count();
                var rowset = CosmosUtils.UseCosmos(_configurationProvider) ? _cosmosAccess.ExecuteStatement(returnEnrollRequest, parms) : _cassandraAccess.ExecuteStatement(returnEnrollRequest, parms);
                var result = rowset.FirstOrDefault(x => x.GetValue<string>("event_name") == "EnrollBusinessAccount");
                if (businessInfoCount >= 1)
                {
                    existingJsonData = result?.GetValue<string>("event_data");
                    requestId = result.GetValue<Guid>("request_id");
                    return new Tuple<string, Guid, int>(existingJsonData, requestId, businessInfoCount);
                }
                else
                {
                    return new Tuple<string, Guid, int>("", requestId, businessInfoCount);
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"accountIdentifier: {accountIdentifier} Error:{ex.Message}");
                throw new RequestHandlerException(503, 0, "Business Information not found");
            }
        }


        public OwnerProfileResponse SaveBusinessOwnerInfo(OwnerProfileRequest addOwnerProfileRequest)
        {
            var response = new OwnerProfileResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    StatusCode = 0,
                    SubStatusCode = 0,
                },
                OwnerIdentifier = ""
            };
            try
            {
                if (OptionsContext.Current.IsDefined("X-GD-Bos-RequestHandler-Cassandra"))
                    throw new ArgumentException("Cassandra failed.");
                var jsonDataToUpdate = GetBusinessInfo(addOwnerProfileRequest.AccountIdentifier);
                var businessContactInfoData = jsonDataToUpdate.Item3 != 0 ? JsonConvert.DeserializeObject<BusinessEnrollment>(jsonDataToUpdate.Item1).BusinessContactInfo : null;
                if (jsonDataToUpdate.Item3 == 0 && businessContactInfoData == null)
                {
                    _logger.Error("Both Business information and Business Contact information is null");
                    response.ResponseHeader.StatusCode = 400;
                    response.ResponseHeader.SubStatusCode = 4107;
                    response.ResponseHeader.Message = "Both Business information and Business Contact information is null";
                    response.ResponseHeader.ResponseId = addOwnerProfileRequest.RequestHeader.RequestId;
                    response.ResponseHeader.Details = "Business Information Not Found;Please Update Business Details";
                }
                else if (jsonDataToUpdate.Item3 == 1 && businessContactInfoData == null)
                {
                    _logger.Error("Business Contact information is null");
                    response.ResponseHeader.StatusCode = 400;
                    response.ResponseHeader.SubStatusCode = 4108;
                    response.ResponseHeader.Message = "Business Contact information is null";
                    response.ResponseHeader.ResponseId = addOwnerProfileRequest.RequestHeader.RequestId;
                    response.ResponseHeader.Details = "Business Information Not Found;Please Update Business Details";
                }
                else
                {
                    //DOB Encrypted
                    addOwnerProfileRequest.OwnerProfileData.DOB = AesOperation.EncryptString(key, addOwnerProfileRequest?.OwnerProfileData?.DOB);
                    _logger.Info($"Date Of Birth : {addOwnerProfileRequest.OwnerProfileData.DOB}");
                    //Set Parameters for Cassandra Update
                    var json = mapBusinessEnrollmentInfo(addOwnerProfileRequest);
                    const string addOwnerInfoRequest = "update enrollment.event_info set event_data=? where request_id=? ;";
                  
                    var parameters = new object[]
                    {
                        json.Item1,json.Item2
                    };

                    RowSet resultdata = null;
                    if (CosmosUtils.UseCosmos(_configurationProvider))
                    {
                        _cosmosAccess.ExecuteStatement(addOwnerInfoRequest, parameters);
                        // cosmos update for event_info_by_verification_identifier
                        Guid? Vefification_identifier = GetVerificationIdentifier(json.Item2);
                        Guid? verification_identifer_in_VF = GetVerificationIdentifier_in_verificationidentifer(Vefification_identifier.Value);
                        if (Vefification_identifier.HasValue && verification_identifer_in_VF.HasValue)
                        {
                            var parameters1 = new object[] { json.Item1, Vefification_identifier };
                            const string addOwnerInfoRequest_event_info_by_verification_identifier = "update enrollment.event_info_by_verification_identifier set event_data=? where verification_identifier=? ;";
                            _cosmosAccess.ExecuteStatement(addOwnerInfoRequest_event_info_by_verification_identifier, parameters1);
                        }
                        // cosmos update for event_info_by_account_identifier
                        Guid? account_identifier = GetAccountIdentifier(json.Item2);
                        if (account_identifier.HasValue)
                        {
                            var parameters1 = new object[] { json.Item1, account_identifier };
                            const string addOwnerInfoRequest_event_info_by_account_identifier = "update enrollment.event_info_by_account_identifier set event_data=? where account_identifier=? ;";
                            _cosmosAccess.ExecuteStatement(addOwnerInfoRequest_event_info_by_account_identifier, parameters1);
                        }
                    }
                    else
                    {
                        resultdata = _cassandraAccess.ExecuteStatement(addOwnerInfoRequest, parameters);
                        var result = resultdata.FirstOrDefault();
                    }
                    
                    response.ResponseHeader.Message = "Success";
                    response.OwnerIdentifier = json.Item3;
                }
                return response;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"RequestId: {addOwnerProfileRequest.RequestHeader?.RequestId} Error:{ex.Message}");
                response.ResponseHeader.Message = "Fail";
                response.ResponseHeader.StatusCode = 503;
                response.ResponseHeader.SubStatusCode = 0;
                response.ResponseHeader.ResponseId = addOwnerProfileRequest.RequestHeader.RequestId;
            }
            return response;
        }

        public ResponseHeader UpdateBusinessMetaData(string accountIdentifier, BusinessEnrollment businessEnrollmentMetaData)
        {
            var response = new ResponseHeader
            {
                StatusCode = 0,
                SubStatusCode = 0,
            };
            try
            {
                if (OptionsContext.Current.IsDefined("X-GD-Bos-RequestHandler-Cassandra"))
                    throw new ArgumentException("Cassandra failed.");

                var cassandraBusinessInfo = DeserialiseBusinessEnrollmentInfo(accountIdentifier);
                //Set Parameters for Cassandra Update
                var json = JsonConvert.SerializeObject(businessEnrollmentMetaData);
                string updateBusinessEnrollmentRequest = "update enrollment.event_info set event_data=? where request_id=? ;";
                var parameters = new object[]
                {
                    json,cassandraBusinessInfo.Item4
                };

                RowSet resultdata = null;
                if (CosmosUtils.UseCosmos(_configurationProvider))
                {
                    resultdata = _cosmosAccess.ExecuteStatement(updateBusinessEnrollmentRequest, parameters);
                    // cosmos update for event_info_by_verification_identifier
                    Guid? verification_identifer = GetVerificationIdentifier(cassandraBusinessInfo.Item4);
                    Guid? verification_identifer_in_VF = GetVerificationIdentifier_in_verificationidentifer(verification_identifer.Value);
                    if (verification_identifer.HasValue && verification_identifer_in_VF.HasValue)
                    {
                        var parameters1 = new object[] { json, verification_identifer };
                        string updateBusinessEnrollmentRequest_event_info_by_verification_identifier = "update enrollment.event_info_by_verification_identifier set event_data=? where verification_identifier=? ;";
                        _cosmosAccess.ExecuteStatement(updateBusinessEnrollmentRequest_event_info_by_verification_identifier, parameters1);
                    }
                    else
                    {
                        _logger.Warn("Verification Identifier not found for request id, So it is not upadted in event_info_by_verification_identifier table" + cassandraBusinessInfo.Item4);
                    }
                    // cosmos update for event_info_by_account_identifier
                    Guid? account_identifer = GetAccountIdentifier(cassandraBusinessInfo.Item4);
                    if (account_identifer.HasValue)
                    {
                        var parameters1 = new object[] { json, account_identifer };
                        string updateBusinessEnrollmentRequest_event_info_by_account_identifier = "update enrollment.event_info_by_account_identifier set event_data=? where account_identifier=? ;";
                        _cosmosAccess.ExecuteStatement(updateBusinessEnrollmentRequest_event_info_by_account_identifier, parameters1);
                    }
                    else
                    {
                        _logger.Warn("account Identifier not found for request id, So it is not upadted in event_info_by_account_identifier table" + cassandraBusinessInfo.Item4);
                    }
                }
                else
                {
                    resultdata = _cassandraAccess.ExecuteStatement(updateBusinessEnrollmentRequest, parameters);
                }
                var result = resultdata.FirstOrDefault();
                response.Message = "Success";
                return response;
            }
            catch (Exception ex)
            {
                // TODO: request ID?
                _logger.Error(ex, $"AccountIdentifier: {accountIdentifier} Error:{ex.Message}");
                response.Message = "Fail";
                response.StatusCode = 503;
                response.SubStatusCode = 0;
            }
            return response;
        }

        public Tuple<BusinessInfoData, BusinessContactInfoData, List<OwnerProfileData>, Guid> DeserialiseBusinessEnrollmentInfo(string accountIdentifier)
        {

            var BusinessData = GetBusinessInfo(accountIdentifier);
            if (BusinessData == null)
            {
                _logger.Error("Business information is null");
                throw new Exception("Business data not found");
            }

            var jsonBusinessData = JsonConvert.SerializeObject(BusinessData);
            var businessInfoData = JsonConvert.DeserializeObject<BusinessEnrollment>(BusinessData.Item1).BusinessInfo;
            var ContactInfoData = JsonConvert.DeserializeObject<BusinessEnrollment>(BusinessData.Item1).BusinessContactInfo;
            var ownerInfoData = JsonConvert.DeserializeObject<BusinessEnrollment>(BusinessData.Item1).OwnersInfo;
            return new Tuple<BusinessInfoData, BusinessContactInfoData, List<OwnerProfileData>, Guid>(businessInfoData, ContactInfoData, ownerInfoData, BusinessData.Item2);

        }
        public virtual Tuple<string, Guid, string> mapBusinessEnrollmentInfo(OwnerProfileRequest addOwnerProfileRequest)
        {
            var businessInfo = DeserialiseBusinessEnrollmentInfo(addOwnerProfileRequest.AccountIdentifier);
            var businessEnrollmentRequest = new BusinessEnrollment()
            {
                BusinessInfo = businessInfo.Item1,
                BusinessContactInfo = businessInfo.Item2,
                OwnersInfo = new List<OwnerProfileData>()
            };
            if (businessInfo.Item3 != null)
            {
                foreach (var items in businessInfo.Item3)
                    businessEnrollmentRequest.OwnersInfo.Add(items);
            }
            var OwnerProfile = new OwnerProfileData()
            {
                OwnerIdentifier = Guid.NewGuid().ToString(),
                IsVerified = addOwnerProfileRequest.OwnerProfileData.IsVerified,
                IsConfirmedIndividual = addOwnerProfileRequest.OwnerProfileData.IsConfirmedIndividual,
                FirstName = addOwnerProfileRequest.OwnerProfileData.FirstName,
                MiddleName = addOwnerProfileRequest.OwnerProfileData.MiddleName,
                LastName = addOwnerProfileRequest.OwnerProfileData.LastName,
                AddressLineOne = addOwnerProfileRequest.OwnerProfileData.AddressLineOne,
                AddressLineTwo = addOwnerProfileRequest.OwnerProfileData.AddressLineTwo,
                City = addOwnerProfileRequest.OwnerProfileData.City,
                State = addOwnerProfileRequest.OwnerProfileData.State,
                Zip = addOwnerProfileRequest.OwnerProfileData.Zip,
                SSN = addOwnerProfileRequest.OwnerProfileData.SSN,
                DOB = addOwnerProfileRequest.OwnerProfileData.DOB,
            };
            businessEnrollmentRequest.OwnersInfo.Add(OwnerProfile);
            var json = JsonConvert.SerializeObject(businessEnrollmentRequest);
            return new Tuple<string, Guid, string>(json, businessInfo.Item4, OwnerProfile.OwnerIdentifier);

        }
        public BusinessEnrollment GetBusinessMetadata(string accountIdentifier)
        {
            var businessMetadata = new BusinessEnrollment();
            try
            {
                if (OptionsContext.Current.IsDefined("X-GD-Bos-RequestHandler-Cassandra"))
                    throw new ArgumentException("Cassandra failed.");

                _logger.Info($"AccounIdentifier: {accountIdentifier}");

                //const string returnEnrollRequest =
                //        "select event_data from enrollment.event_info where account_identifier=? and event_name='EnrollBusinessAccount' allow filtering;";
                const string returnEnrollRequest =
                        "select event_data, event_name from enrollment.event_info_by_account_identifier where account_identifier=?;";
                var parms = new object[] { Guid.Parse(accountIdentifier) };
                var rowset = CosmosUtils.UseCosmos(_configurationProvider) ? _cosmosAccess.ExecuteStatement(returnEnrollRequest, parms) : _cassandraAccess.ExecuteStatement(returnEnrollRequest, parms);
                var result = rowset.FirstOrDefault(x => x.GetValue<string>("event_name") == "EnrollBusinessAccount");
                if (result != null)
                {
                    var existingJsonData = result.GetValue<string>("event_data");
                    businessMetadata = JsonConvert.DeserializeObject<BusinessEnrollment>(existingJsonData);
                }
                if (businessMetadata == null)
                    _logger.Info("Business information is null");

                return businessMetadata;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"Error:{ex.Message}");

                // TODO : throw error when we are ready to implement idempotency for enrollment
                //throw new RequestHandlerException(503, 0, "Connection has been timed out, pls retry");
            }
            return businessMetadata;
        }
        public virtual Guid GetVerificationIdentifier(Guid request_id)
        {

            const string returnEnrollRequest =
                @"SELECT * FROM enrollment.event_info
                where request_id = ?;";
            var parms = new object[] { request_id };
            var rowset = _cosmosAccess.ExecuteStatement(returnEnrollRequest, parms);
            var result = rowset.FirstOrDefault(x => x.GetValue<Guid?>("verification_identifier") != null);
            if (result != null)
            {
                return result.GetValue<Guid>("verification_identifier");
            }
            else
            {
                return Guid.Empty;
            }
        }
        public virtual Guid GetVerificationIdentifier_in_verificationidentifer(Guid? verificationidentifer)
        {

            const string returnEnrollRequest =
                @"SELECT * FROM enrollment.event_info_by_verification_identifier
                where verification_identifier = ?;";
            var parms = new object[] { verificationidentifer };
            var rowset = _cosmosAccess.ExecuteStatement(returnEnrollRequest, parms);
            var result = rowset.FirstOrDefault(x => x.GetValue<Guid?>("verification_identifier") != null);
            if (result != null)
            {
                return result.GetValue<Guid>("verification_identifier");
            }
            else
            {
                return Guid.Empty;
            }
        }
        public virtual Guid GetAccountIdentifier(Guid request_id)
        {

            const string returnEnrollRequest =
                @"SELECT * FROM enrollment.event_info
                where request_id = ?;";
            var parms = new object[] { request_id };
            var rowset = _cosmosAccess.ExecuteStatement(returnEnrollRequest, parms);
            var result = rowset.FirstOrDefault(x => x.GetValue<Guid?>("account_identifier") != null);
            if (result != null)
            {
                return result.GetValue<Guid>("account_identifier");
            }
            else
            {
                return Guid.Empty;
            }
        }
    }
}

