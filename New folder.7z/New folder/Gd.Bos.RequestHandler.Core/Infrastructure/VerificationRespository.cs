﻿using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Utils;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Linq;
using NLog;
using System.Diagnostics.CodeAnalysis;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using PaymentInstrument = Gd.Bos.RequestHandler.Core.Domain.Model.Payment.PaymentInstrument;
using CustomCardImage = Gd.Bos.RequestHandler.Core.Domain.Model.Payment.CustomCardImage;
using Gd.Bos.Shared.Common;
using Microsoft.Data.SqlClient.Server;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using System.Data;
using Gd.Bos.Shared.Common.Core.Common.Enum;
using AccountHolderCure = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolderCure;
using VerificationActivityType = Gd.Bos.RequestHandler.Core.Domain.Model.Account.VerificationActivityType;
using VerificationStatus = Gd.Bos.RequestHandler.Core.Domain.Model.Account.VerificationStatus;
using VerificationStatusReason = Gd.Bos.RequestHandler.Core.Domain.Model.Account.VerificationStatusReason;
using Gd.Bos.RequestHandler.Core.Domain.Services.AtmLocator;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public partial class VerificationRepository : IVerificationRepository
    {

        private string userName = IdentityHelper.GetIdentityName();
        private static readonly Logger _logger = LogManager.GetCurrentClassLogger();
        public VerificationRepository(IDataAccess dataAccess)
        {
            _dataAccess = dataAccess;
        }

        public long CreateVerificationRequest(VerificationRequestIdentifier verificationRequestidentifier, TriggerType triggerType, VerificationStatus verificationStatus, int productKey,
            long? consumerProfileKey, long? accountHolderKey, long? paymentIdentifierKey)
        {
            try
            {
                var parameters = new[]
                {
                    new SqlParameter() {ParameterName = "ChangeBy", Value = userName},
                    new SqlParameter() {ParameterName = "VerificationRequestIdentifier", Value = verificationRequestidentifier.ToString()},
                    new SqlParameter() {ParameterName = "VerificationTriggerTypeKey", Value = triggerType},
                    new SqlParameter() {ParameterName = "VerificationStatusKey", Value = verificationStatus},
                    new SqlParameter() {ParameterName = "ProductKey", Value = productKey},
                    new SqlParameter() {ParameterName = "ConsumerProfileKey", Value = consumerProfileKey},
                    new SqlParameter() {ParameterName = "AccountHolderKey", Value = accountHolderKey},
                    new SqlParameter() {ParameterName = "PaymentIdentifierKey", Value = paymentIdentifierKey},
                    new SqlParameter() {ParameterName = "PreEnrollmentAccountHolderCureKey", Value = AccountHolderCure.None},
                    new SqlParameter() {ParameterName = "PreEnrollmentExpirationDate", Value = DateTime.Now},
                };

                object verificationKey = _dataAccess.ExecuteScalar("[dbo].[InsVerificationRequest]", _dataAccess.CreateConnection(), parameters);
                return Convert.ToInt64(verificationKey);
            }
            catch (SqlException ex)
            {
                _logger.Error(ex, $"VerificationRespository.Add, error occurred when adding account. Error: {ex.Message}");
                throw ex;
            }
        }

        public void InsertVerificationRequestDetail(long verificationRequestKey, string identityType, string identityToken, string identityCountryCode)
        {
            try
            {
                var parameter = new[]
                {
                    new SqlParameter()
                    {
                        ParameterName = "ptypeVerificationRequestDetail",
                        Value = CreateTypeVerificationRequestDetailRecord(verificationRequestKey, identityType, identityToken, identityCountryCode).Convert(),
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.typeVerificationRequestDetail"
                    }
                };

                _dataAccess.ExecuteNonQuery("InsertVerificationRequestDetail", _dataAccess.CreateConnection(), parameter);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"Error occurred while calling SP:InsertVerificationRequestDetail. VerificationRequestKey:{verificationRequestKey}");
                throw;
            }
        }

        private List<SqlDataRecord> CreateTypeVerificationRequestDetailRecord(long verificationRequestKey, string identityType, string identityToken, string identityCountryCode)
        {
            List<SqlDataRecord> returnValue = new List<SqlDataRecord>();

            if (!string.IsNullOrWhiteSpace(identityToken))
            {
                Enum.TryParse(identityType, true, out VerificationRequestAttribute outIdentityType);
                returnValue.Add(AddNewRecord(verificationRequestKey, (short)outIdentityType, identityToken));
            }

            if (!string.IsNullOrWhiteSpace(identityCountryCode))
            {
                Enum.TryParse(identityType, true, out VerificationRequestAttribute outIdentityType);
                returnValue.Add(AddNewRecord(verificationRequestKey, (short)VerificationRequestAttribute.IdentityCountryCode, identityCountryCode));
            }

            return returnValue;
        }

        public static SqlDataRecord AddNewRecord(long verificationRequestKey, short verificationRequestAttributeKey, string verificationRequestAttributeValue)
        {
            SqlDataRecord record = new SqlDataRecord(CreateTypeVerificationRequestDetailMetadata());
            record.SetInt64(0, verificationRequestKey);
            record.SetInt16(1, verificationRequestAttributeKey);
            record.SetString(2, verificationRequestAttributeValue);

            return record;
        }

        private static SqlMetaData[] CreateTypeVerificationRequestDetailMetadata()
        {
            SqlMetaData[] metadata = new SqlMetaData[3];

            metadata[0] = new SqlMetaData("VerificationRequestKey", SqlDbType.BigInt);
            metadata[1] = new SqlMetaData("VerificationRequestAttributeKey", SqlDbType.SmallInt);
            metadata[2] = new SqlMetaData("VerificationRequestAttributeValue", SqlDbType.NVarChar, 100);

            return metadata;
        }

        public VerificationRequest GetByVerificationRequestIdentifier(Guid verificationRequestIdentifier)
        {

            var verificationRequest = new VerificationRequest();
            using (var cnn = _dataAccess.CreateConnection())
            {
                var cmd = cnn.CreateCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandText = "[dbo].[GetVerificationRequestandActivityByIdentifier]";
                cmd.Parameters.AddWithValue("VerificationRequestIdentifier", verificationRequestIdentifier);
                cnn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        // read VerificationRequest
                        var accountHolder = new AccountHolder();

                        verificationRequest.VerificationRequestKey = reader.GetInt64(0);

                        verificationRequest.TriggerTypeKey = reader.GetInt16(1);

                        verificationRequest.StatusKey = reader.GetInt16(2);

                        if (!reader.IsDBNull(3))
                            verificationRequest.ConsumerProfileKey = reader.GetInt64(3);

                        if (!reader.IsDBNull(4))
                            verificationRequest.AccountHolderKey = reader.GetInt64(4);

                        verificationRequest.ProductKey = reader.GetInt32(5);

                        if (!reader.IsDBNull(6))
                            verificationRequest.PaymentIdentifierKey = reader.GetInt64(6);

                        verificationRequest.ChangeDate = reader.GetDateTime(7);

                    }
                    var activities = new List<VerificationActivity>();
                    if (reader.NextResult())
                    {
                        while (reader.Read())
                        {
                            var activity = new VerificationActivity();

                            if (reader.GetInt16(6) == 2)
                            {

                                activity.ActivityKey = reader.GetInt64(0);
                                activity.ChannelKey = reader.GetInt16(1);
                                activity.ActivityTypeKey = reader.GetInt16(2);
                                activity.StatusKey = reader.GetInt16(3);
                                activity.StartDate = reader.GetDateTime(4).ToLocalTime();
                                if (!reader.IsDBNull(5))
                                {
                                    activity.EndDate = reader.GetDateTime(5).ToString();
                                }

                                if (activity.EndDate != null)
                                    _logger.Warn("Verification Activity has ended.");

                                activities.Add(activity);
                            }
                        }
                    }
                    verificationRequest.Activities = activities;
                }
                cnn.Close();
                return verificationRequest;
            }
        }

        public VerificationRequest GetVerificationRequest(Guid verificationRequestIdentifier)
        {

            var verificationRequest = new VerificationRequest();
            using (var cnn = _dataAccess.CreateConnection())
            {
                var cmd = cnn.CreateCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandText = "[dbo].[GetVerificationRequestandActivityByIdentifier]";
                cmd.Parameters.AddWithValue("VerificationRequestIdentifier", verificationRequestIdentifier);
                cnn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        // read VerificationRequest
                        var accountHolder = new AccountHolder();

                        verificationRequest.VerificationRequestKey = reader.GetInt64(0);

                        verificationRequest.TriggerTypeKey = reader.GetInt16(1);

                        verificationRequest.StatusKey = reader.GetInt16(2);

                        if (!reader.IsDBNull(3))
                            verificationRequest.ConsumerProfileKey = reader.GetInt64(3);

                        if (!reader.IsDBNull(4))
                            verificationRequest.AccountHolderKey = reader.GetInt64(4);

                        verificationRequest.ProductKey = reader.GetInt32(5);

                        if (!reader.IsDBNull(6))
                            verificationRequest.PaymentIdentifierKey = reader.GetInt64(6);

                        verificationRequest.ChangeDate = reader.GetDateTime(7);

                    }
                    var activities = new List<VerificationActivity>();
                    if (reader.NextResult())
                    {
                        while (reader.Read())
                        {
                            var activity = new VerificationActivity();
                            activity.ActivityKey = reader.GetInt64(0);
                            activity.ChannelKey = reader.GetInt16(1);
                            activity.ActivityTypeKey = reader.GetInt16(2);
                            activity.StatusKey = reader.GetInt16(3);
                            activity.StartDate = reader.GetDateTime(4).ToLocalTime();
                            if (!reader.IsDBNull(5))
                            {
                                activity.EndDate = reader.GetDateTime(5).ToString();
                            }

                            activities.Add(activity);
                        }
                    }
                    verificationRequest.Activities = activities;
                }
                cnn.Close();
                return verificationRequest;
            }
        }
        public void UpdateVerificationActivityStatus(VerificationRequest request, VerificationActivity activity, VerificationStatusReason[] reasons)
        {
            if (reasons.Length == 0)
            {
                throw new ArgumentException("No Verification Status Reasons specified", nameof(reasons));
            }
            var reasonTable = ToVerificationStatusReasonsTable(reasons);

            var verificationActivityParams = new[] {
                         new SqlParameter() { ParameterName = "verificationRequestKey",Value = request.VerificationRequestKey},
                         new SqlParameter() {ParameterName = "ChangeBy", Value = userName},
                         new SqlParameter() {ParameterName = "VerificationActivityTypeKey",  Value = activity.ActivityTypeKey},
                         new SqlParameter() {ParameterName = "VerificationStatusKey", Value = activity.StatusKey},
                         new SqlParameter() {ParameterName = "VerificationActivityEndDate", Value = activity.EndDate},
                         new SqlParameter() {ParameterName = "VerificationStatusReason", Value = reasonTable.Convert(), TypeName = "typeVerificationStatusReason", SqlDbType=System.Data.SqlDbType.Structured}
                    };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdVerificationActivityStatus]", _dataAccess.CreateConnection(), verificationActivityParams);
        }


        public void UpdateVerificationRequestStatus(long verificationRequestKey, VerificationStatus status)
        {
            var verificationParams = new[] {
                        new SqlParameter() {ParameterName = "ChangeBy", Value = userName},
                        new SqlParameter() {ParameterName = "VerificationStatusKey",  Value = (short)status},
                        new SqlParameter() {ParameterName = "VerificationRequestKey",  Value = verificationRequestKey}
                    };
            _dataAccess.ExecuteNonQuery("[dbo].[UpdVerificationRequestStatus]", _dataAccess.CreateConnection(), verificationParams);

        }

        public void UpdateVerificationRequestStatusPreEnroll(long verificationRequestKey, AccountHolderCure status)
        {
            var verificationParams = new[] {
                        new SqlParameter() {ParameterName = "ChangeBy", Value = userName},
                        new SqlParameter() {ParameterName = "PreEnrollmentAccountHolderCurekey",  Value = (short)status},
                        new SqlParameter() {ParameterName = "VerificationRequestKey",  Value = verificationRequestKey}
                    };
            _dataAccess.ExecuteNonQuery("[dbo].[UpdVerificationRequestPreEnrollmentAccountHolderCure]", _dataAccess.CreateConnection(), verificationParams);

        }

        public VerificationRequestIdentifiers GetAccountAndAccountHolderInfoFromVerificationRequest(KeyIdentifierPair verificationRequestId)
        {
            using
            (
                var reader = _dataAccess.ExecuteReader
                (
                    "[dbo].[GetAccountByVerificationRequestIdentifier]",
                    _dataAccess.CreateConnection(),
                    new SqlParameter("VerificationRequestIdentifier", verificationRequestId.Identifier)
                )
            )
            {
                if (reader.Read())
                {
                    var account = new KeyIdentifierPair(reader.GetInt64(0), reader.GetGuid(1));
                    var accountHolder = new KeyIdentifierPair(reader.GetInt64(2), reader.GetGuid(3));

                    return new VerificationRequestIdentifiers(
                        verificationRequestId,
                        account,
                        accountHolder
                        );
                }
            }

            return new VerificationRequestIdentifiers();

        }


        public AccountIdentifier GetAccountByVerificationIdentifier(VerificationRequestIdentifier identifier)
        {
            using
            (
                var reader = _dataAccess.ExecuteReader
                (
                    "[dbo].[GetAccountByVerificationRequestIdentifier]",
                    _dataAccess.CreateConnection(),
                    new SqlParameter("VerificationRequestIdentifier", Guid.Parse(identifier.ToString()))
                )
            )
            {
                if (reader.Read())
                {
                    var account = reader.GetGuid(1);
                    return account;
                }
            }

            return null;

        }
        SqlDataRecord[] ToVerificationStatusReasonsTable(IEnumerable<VerificationStatusReason> values)
        {
            var meta = new SqlMetaData("value", System.Data.SqlDbType.SmallInt);
            return values.Select(v =>
            {
                var r = new SqlDataRecord(meta);
                r.SetInt16(0, (short)v);
                return r;
            })
            .ToArray();
        }

        public VerificationRequest GetStatusByVerificationRequestIdentifier(Guid verificationRequestIdentifier)
        {

            var verificationRequest = new VerificationRequest();
            using (var cnn = _dataAccess.CreateConnection())
            {
                var cmd = cnn.CreateCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandText = "[dbo].[GetVerificationRequestandActivityByIdentifier]";
                cmd.Parameters.AddWithValue("VerificationRequestIdentifier", verificationRequestIdentifier);
                cnn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        // read VerificationRequest
                        var accountHolder = new AccountHolder();

                        verificationRequest.VerificationRequestKey = reader.GetInt64(0);

                        verificationRequest.TriggerTypeKey = reader.GetInt16(1);

                        verificationRequest.StatusKey = reader.GetInt16(8);

                        if (!reader.IsDBNull(3))
                            verificationRequest.ConsumerProfileKey = reader.GetInt64(3);

                        if (!reader.IsDBNull(4))
                            verificationRequest.AccountHolderKey = reader.GetInt64(4);

                        verificationRequest.ProductKey = reader.GetInt32(5);

                        if (!reader.IsDBNull(6))
                            verificationRequest.PaymentIdentifierKey = reader.GetInt64(6);
                        //Get pre enroll expiration date
                        verificationRequest.ChangeDate = reader.GetDateTime(9);

                    }

                }
                cnn.Close();
                return verificationRequest;
            }
        }

        public void CreateVerificationActivity(long verificationRequestKey,Dictionary<VerificationActivityType, VerificationStatus> verifyList)
        {
            foreach (var type in verifyList)
            {
                var verificationActivityParams = new[]
                {
                    new SqlParameter
                    {
                        ParameterName = "verificationRequestKey",
                        Value = verificationRequestKey
                    },
                    new SqlParameter {ParameterName = "VerificationChannelKey", Value = 1},
                    new SqlParameter {ParameterName = "ChangeBy", Value = userName},
                    new SqlParameter {ParameterName = "VerificationActivityTypeKey", Value = type.Key},
                    new SqlParameter {ParameterName = "VerificationStatusKey", Value = type.Value},
                    new SqlParameter {ParameterName = "VerificationActivityStartDate", Value = DateTime.Now}
                };

                _dataAccess.ExecuteScalar("[dbo].[InsVerificationActivity]",
                    _dataAccess.CreateConnection(), verificationActivityParams);
            }

        }
        private readonly IDataAccess _dataAccess;
    }


}
