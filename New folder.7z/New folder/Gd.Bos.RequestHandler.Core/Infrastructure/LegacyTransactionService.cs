﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Services.Crypto;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using NLog;
using RequestHandler.Core.Domain.Services.Legacy;
using RequestHandler.Core.Domain.Services.RetailCard.Model;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using GetTransactionsRequest = RequestHandler.Core.Domain.Services.RetailCard.Model.GetTransactionsRequest;
using GetTransactionsResponse = RequestHandler.Core.Domain.Services.RetailCard.Model.GetTransactionsResponse;
using TransactionStatus = RequestHandler.Core.Domain.Services.RetailCard.Model.TransactionStatus;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class LegacyTransactionService : ILegacyTransactionService
    {
        private readonly IServiceInvokeProvider _serviceInvokeProvider;
        private readonly IAccountRepository _accountRepository;
        private readonly string _gssAccountUtilityBaseUrl;

        public LegacyTransactionService(IServiceInvokeProvider serviceInvokeProvider, IProductService productService,
            ICryptoService cryptoService, IAccountRepository accountRepository, IPaymentIdentifierRepository paymentIdentifierRepository, ITokenizerService tokenizerService)
        {
            _serviceInvokeProvider = serviceInvokeProvider;
            _accountRepository = accountRepository;
            _gssAccountUtilityBaseUrl = Configuration.Configuration.Current.GSSLegacyAccountUtilityBaseUrl;
        }

        public GetLegacyTransactionResponse GetLegacyTransactions(GetLegacyTransactionRequest request)
        {
            Stopwatch totalTime = Stopwatch.StartNew();
            GetLegacyTransactionResponse legacyTransactionResponse = null;

            var account = _accountRepository.GetByAccountIdentifier(request.AccountIdentifier);

            if (account == null)
            {
                throw new ValidationException(10, 0, "Account Not Found.");
            }

            _logger.Debug($"LegacyTransactionService - GetLegacyTransactions Call to GSS to pull legacy card transactions from NEC. requestId:{request.RequestHeader.RequestId},accountIdentifier:{request.AccountIdentifier}, programCode:{account?.Product?.ProgramCode}, productCode:{account?.Product?.ProductCode}");


            GetTimeout("X-GD-Bos-GSSLegacyAccountUtility-GetLegacyTransactions", out var requestTimeout);

            GetTransactionsRequest getTransactionsRequest = new GetTransactionsRequest()
            {
                RequestId = request.RequestHeader.RequestId,
                ProgramCode = request.ProgramCode,
                AccountIdentifier = Guid.Parse(request.AccountIdentifier),
                Count = request.Count,
                ByPassElasticSearch = request.ByPassElasticSearch,
                IncludeDeclined = request.IncludeDeclined,
                EndDate = request.EndDate.GetValueOrDefault()
            };

            // _gssAccountUtilityBaseUrl = "https://gssactutl.qa.nextestate.com/legacyaccountutility/V1";

            var url1 = _gssAccountUtilityBaseUrl + $"/programs/{request.ProgramCode}/legacytransaction/accounts/{getTransactionsRequest.AccountIdentifier}/transactions";

            try
            {
                var response = _serviceInvokeProvider.GetWebResponse<GetTransactionsRequest, GetTransactionsResponse>(url1
                    , "POST", getTransactionsRequest, requestTimeout);

                legacyTransactionResponse = PopulateTransactionResponse(response, request.AccountIdentifier, request.ProgramCode, request.RequestHeader.RequestId, string.Empty);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"LegacyTransactionService - GetLegacyTransaction method failed for ProgramCode:{request.ProgramCode}, requestId:{request.RequestHeader.RequestId},AccountIdentifier:{request.AccountIdentifier},EndDate:{request.EndDate},ByPassElasticSearch:{request.ByPassElasticSearch},IncludeDeclined:{request.IncludeDeclined}");

                legacyTransactionResponse = new GetLegacyTransactionResponse()
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 500,
                        Message = "Error occurred while fetching Legacy Transaction."
                    }
                };
            }

            return legacyTransactionResponse;
        }

        public GetLegacyTransactionResponse GetLegacyTransactionsBySearchTerm(GetLegacyTransactionBySearchTermRequest request)
        {
            Stopwatch totalTime = Stopwatch.StartNew();
            GetLegacyTransactionResponse legacyTransactionResponse = null;

            var account = _accountRepository.GetByAccountIdentifier(request.AccountIdentifier);

            if (account == null)
            {
                throw new ValidationException(10, 0, "Account Not Found.");
            }

            _logger.Debug($"LegacyTransactionService - GetLegacyTransactionsBySearchTerm Call to GSS to pull legacy card transactions from NEC NRT. requestId:{request.RequestHeader.RequestId},accountIdentifier:{request.AccountIdentifier}, programCode:{account?.Product?.ProgramCode}, productCode:{account?.Product?.ProductCode}");


            GetTimeout("X-GD-Bos-GSSLegacyAccountUtility-GetLegacyTransactionsBySearchTerm", out var requestTimeout);


            if (string.Equals(request.Term, "Pending", StringComparison.OrdinalIgnoreCase))
            {
                request.Term = "Pending";
            }
            else if (string.Equals(request.Term, "posted", StringComparison.OrdinalIgnoreCase))
            {
                request.Term = "Posted";
            }
            else if (string.Equals(request.Term, "declined", StringComparison.OrdinalIgnoreCase))
            {
                request.Term = "Declined";
            }

            SearchTermTransactionsRequest getTransactionsRequest = new SearchTermTransactionsRequest()
            {
                RequestId = request.RequestHeader.RequestId,
                ProgramCode = request.ProgramCode,
                AccountIdentifier = Guid.Parse(request.AccountIdentifier),
                PageCount = request.PageCount,
                Term = request.Term,
                StartIndex = request.StartIndex
            };

            // _gssAccountUtilityBaseUrl = "https://gssactutl.qa.nextestate.com/legacyaccountutility/V1";

            var url1 = _gssAccountUtilityBaseUrl + $"/programs/{request.ProgramCode}/legacytransaction/accounts/{getTransactionsRequest.AccountIdentifier}/transactions/search";
            try
            {
                var response = _serviceInvokeProvider.GetWebResponse<SearchTermTransactionsRequest, GetTransactionsResponse>(url1
                    , "POST", getTransactionsRequest, requestTimeout);

                legacyTransactionResponse = PopulateTransactionResponse(response, request.AccountIdentifier, request.ProgramCode, request.RequestHeader.RequestId, request.Term);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"LegacyTransactionService - GetLegacyTransactionBySearchTerm method failed for ProgramCode:{request.ProgramCode}, requestId:{request.RequestHeader.RequestId},AccountIdentifier:{request.AccountIdentifier},SearchTerm:{request.Term},PageCount:{request.PageCount},StartIndex:{request.StartIndex}");

                legacyTransactionResponse = new GetLegacyTransactionResponse()
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 500,
                        Message = "Error occurred while fetching Legacy Transaction by search Term."
                    }
                };
            }
            return legacyTransactionResponse;
        }

        private GetLegacyTransactionResponse PopulateTransactionResponse(GetTransactionsResponse response, string accountIdentifier, string programCode, Guid requestId, string searchTerm)
        {
            GetLegacyTransactionResponse legacyTransactionResponse = null;

            legacyTransactionResponse = new GetLegacyTransactionResponse();
            if (response?.StatusCode == 0)
            {
                var account = _accountRepository.GetByAccountIdentifier(accountIdentifier);

                if (account == null)
                {
                    throw new ValidationException(10, 0, "Account Not Found.");
                }


                if (response.Transactions.Count > 0)
                {
                    _logger.Debug(
                        $"LegacyTransactionService - GetLegacyTransaction. Found {response.Transactions.Count} transactions. GSSResponseCode:{response.StatusCode}, requestId:{requestId},AccountIdentifier:{accountIdentifier},ProgramCode:{programCode},SearchTerm:{searchTerm}");


                    legacyTransactionResponse.Transactions = new List<ESTransaction>();
                    foreach (var legacyTransaction in response.Transactions)
                    {
                        ESTransaction gbosTransaction = new ESTransaction();

                        gbosTransaction.ProgramCode = programCode;
                        gbosTransaction.TransactionIdentifier = legacyTransaction.TransactionId;
                        gbosTransaction.AccountIdentifier = accountIdentifier;
                        gbosTransaction.TransactionType = legacyTransaction.GdcTransactionType ?? legacyTransaction.TransactionType;
                        gbosTransaction.ProductCode = account.Product.ProductCode.ToString();

                        if (int.TryParse(gbosTransaction.TransactionType?.Trim(), out _))
                        {
                            gbosTransaction.TransactionType = null;
                        }

                        switch (legacyTransaction.TransactionStatus)
                        {
                            case TransactionStatus.Pending:

                                #region Legacy NEC Pending Transaction Mappings

                                if (legacyTransaction.AuthorizationAmount.HasValue)
                                {
                                    gbosTransaction.TransactionAmount = Math.Abs(legacyTransaction.AuthorizationAmount.Value);

                                    if (legacyTransaction.AuthorizationAmount.Value < 0)
                                    {
                                        gbosTransaction.CreditDebit = false;
                                    }

                                    if (legacyTransaction.AuthorizationAmount.Value >= 0)
                                    {
                                        gbosTransaction.CreditDebit = true;
                                    }
                                }

                                gbosTransaction.AuthProcessorTransactionDate =
                                    legacyTransaction.AuthorizationDate.GetValueOrDefault(); // or AuthorizationDate ??

                                #endregion

                                break;
                            case TransactionStatus.Posted:

                                #region Legacy NEC Posted/Internal Transaction Mappings

                                gbosTransaction.ProcessorTransactionDate =
                                    legacyTransaction.PostedDate.GetValueOrDefault(); //confirm and fix format
                                if (legacyTransaction.CreditPosted.HasValue)
                                {
                                    gbosTransaction.TransactionAmount = legacyTransaction.CreditPosted.Value;
                                    gbosTransaction.CreditDebit = true;
                                }
                                else if (legacyTransaction.DebitPosted.HasValue)
                                {
                                    gbosTransaction.TransactionAmount = legacyTransaction.DebitPosted.Value;
                                    gbosTransaction.CreditDebit = false;
                                }

                                #endregion

                                break;
                        }

                        gbosTransaction.CurrencyCode = "USD";

                        gbosTransaction.CardAcceptorName = legacyTransaction.MerchantName;
                        gbosTransaction.CardAcceptorCity = legacyTransaction.MerchantCity;
                        gbosTransaction.CardAcceptorStateProvReg = legacyTransaction.MerchantState;
                        gbosTransaction.CardAcceptorPostal = legacyTransaction.MerchantZipCode;

                        if (legacyTransaction.RunningBalance.HasValue)
                        {
                            gbosTransaction.LedgerBalance = legacyTransaction.RunningBalance.Value;
                        }

                        // gbosTransaction.AvailableBalance = legacyTransaction.RunningBalance
                        //gbosTransaction.MessageHashId = legacyTransaction.
                        gbosTransaction.MerchantCategoryCode = legacyTransaction.MccCode;

                        gbosTransaction.MerchantId = legacyTransaction.MerchantId;

                        gbosTransaction.TransactionDescription = legacyTransaction.MerchantName;
                        gbosTransaction.TransClass = legacyTransaction.GdcTransactionClass;

                        if (!string.IsNullOrWhiteSpace(legacyTransaction.TransactionStatus.ToString()))
                        {
                            //First letter lower case for BUX to handle transaction status properly
                            var transactionStatusStr = legacyTransaction.TransactionStatus.ToString();
                            gbosTransaction.Status = char.ToLowerInvariant(transactionStatusStr[0]) +
                                                     transactionStatusStr.Substring(1);
                        }

                        gbosTransaction.MerchantCategory = legacyTransaction.MerchantCategory;

                        legacyTransactionResponse.Transactions.Add(gbosTransaction);
                    }

                    legacyTransactionResponse.ResponseHeader = new ResponseHeader()
                    {
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success",
                        ResponseId = requestId
                    };
                }
                else
                {
                    legacyTransactionResponse.ResponseHeader = new ResponseHeader()
                    {
                        StatusCode = 10,
                        SubStatusCode = 0,
                        Message = "No more Legacy Transactions found",
                        ResponseId = requestId
                    };
                }

                _logger.Debug(
                    $"LegacyTransactionService - GetLegacyTransactionBySearchTerm method - fetched legacy transactions from GSS NEC. ResponseCode:{response.StatusCode}, NoMoreTransactionsAvailable:{response.NoMoreTransactionsAvailable},requestId:{requestId},AccountIdentifier:{accountIdentifier}");

            }
            else
            {
                legacyTransactionResponse = new GetLegacyTransactionResponse();
                legacyTransactionResponse.ResponseHeader = new ResponseHeader()
                {
                    StatusCode = 10,
                    SubStatusCode = 0,
                    Message = response?.Message,
                    ResponseId = requestId
                };
                _logger.Warn(
                    $"LegacyTransactionService - GetLegacyTransactionBySearchTerm method - error returned from GSS NEC. ResponseCode:{response?.StatusCode},Message:{response?.Message}, NoMoreTransactionsAvailable:{response?.NoMoreTransactionsAvailable}, requestId:{requestId},AccountIdentifier:{accountIdentifier}");

            }

            return legacyTransactionResponse;
        }

        private void GetTimeout(string headerName, out int? requestTimeout)
        {
            requestTimeout = null;
            if (OptionsContext.Current.IsDefined(headerName))
            {
                requestTimeout = 1;
                if (int.TryParse(OptionsContext.Current.GetString(headerName), out var rt))
                    requestTimeout = rt;
            }
        }

        private static readonly ILogger _logger = LogManager.GetCurrentClassLogger();

        //trigger build 5/10
    }
}