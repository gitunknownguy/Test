﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Utils;
using Gd.Bos.Shared.Common.Core.Data;
using Microsoft.Data.SqlClient;
using RequestHandler.Core.Domain.Model.Inventory;

namespace RequestHandler.Core.Infrastructure
{
    [ExcludeFromCodeCoverage(Justification = "Not tested previously and currently can't be easily mocked and will be taken care of on GBOS-116633")]
    public class AsyncInstantIssueCardInventoryRepository : IAsyncInstantIssueCardInventoryRepository
    {
        private readonly IDataAccess _dataAccess;
        private readonly string _userName = IdentityHelper.GetIdentityName();

        public AsyncInstantIssueCardInventoryRepository(IDataAccess dataAccess)
        {
            _dataAccess = dataAccess;
        }

        public async Task<string> GetInstantIssueCardInventoryByAccountIdentifier(Guid accountIdentifier)
        {
            string returnValue = "";
            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "AccountIdentifier", SqlDbType = SqlDbType.UniqueIdentifier, Value = accountIdentifier },
            };

            using var connection = _dataAccess.CreateConnection();
            using (var reader = await _dataAccess.ExecuteReaderAsync("[dbo].[GetInstantIssueCardInventoryByAccountIdentifier]", CommandType.StoredProcedure, connection, default, parameters))
            {
                if (await reader.ReadAsync())
                {
                    returnValue = reader["MappingIdentifier"].ToString();
                }
            }
            return returnValue;
        }

        public Guid? GetInstantIssueCardInventoryByMappingIdentifier(string mappingIdentifier)
        {
            throw new NotImplementedException();
        }

        public string InsertInstantIssueCardInventory(Guid accountIdentifier, string mappingIdentifier)
        {
            throw new NotImplementedException();
        }
    }
}
