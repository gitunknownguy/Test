﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Text;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.RequestHandler.Core.Domain;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using NLog;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using RequestHandler.Core.Domain.Services.PaperCheck;
using Microsoft.IdentityModel.Tokens;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class PaperCheckService : IPaperCheckService
    {
        private readonly IServiceInvokeProvider _serviceInvokerProvider;
        private readonly string _paperCheckUrl;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        private readonly IRequestHandlerSettings _configuration;

        public PaperCheckService(IServiceInvokeProvider serviceInvokeProvider, IRequestHandlerSettings settings)
        {
            _serviceInvokerProvider = serviceInvokeProvider;
            _configuration = settings;
            _paperCheckUrl = _configuration.PaperCheckBaseUrl;
        }


        private void GetTimeout(string headerName, out int? requestTimeout)
        {
            requestTimeout = null;
            if (OptionsContext.Current.IsDefined(headerName))
            {
                requestTimeout = 1;
                if (int.TryParse(OptionsContext.Current.GetString(headerName), out var rt))
                    requestTimeout = rt;
            }
        }

        public CheckInventoryResponse StopPaperCheckPayment(CheckInventoryRequest request)
        {
            GetTimeout("X-GD-Bos-Papercheck-stoppaymentTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            var response = _serviceInvokerProvider.GetWebResponse<CheckInventoryRequest, CheckInventoryResponse>(
                        StopPaperCheckPaymentUrl(request), "PUT", request, requestTimeout);

            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for {StopPaperCheckPaymentUrl(request)}.");

            return response;
        }

        public CheckBookResponse CheckBookOrder(CheckBookRequest request)
        {
            GetTimeout("X-GD-Bos-Papercheck-CheckBookOrderTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            var response = _serviceInvokerProvider.GetWebResponse<CheckBookRequest, CheckBookResponse>(
                        CheckBookOrderUrl(request), "PUT", request, requestTimeout);

            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for {CheckBookOrderUrl(request)}.");

            return response;
        }

        public GetCheckBookOrdersResponseModel GetCheckBookOrders(GetCheckBookOrdersRequest request)
        {
            GetTimeout("X-GD-Bos-Papercheck-GetCheckBookOrdersTimeOut", out var requestTimeout);

            var response = _serviceInvokerProvider.GetWebResponse<GetCheckBookOrdersResponseModel>(
                GetCheckBooksOrderUrl(request), "GET", null, requestTimeout);

            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for {GetCheckBooksOrderUrl(request)}.");

            return response;
        }

        public GetCheckBookImageResponseModel GetCheckBookImages(GetCheckBookImageRequest request)
        {
            GetTimeout("X-GD-Bos-Papercheck-CheckBookImageTimeOut", out var requestTimeout);

            var response = _serviceInvokerProvider.GetWebResponse<GetCheckBookImageResponseModel>
                (GetCheckBookImageUrl(request), "GET", null, requestTimeout);

            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for {GetCheckBookImages(request)}.");

            return response;
        }

        public CreateCheckBookOrderDoResponse CreateCheckBookOrders(CreateCheckBookOrderDoRequest request)
        {
            GetTimeout("X-GD-Bos-Papercheck-CreateCheckBookOrdersTimeOut", out var requestTimeout);
            string reqId = OptionsContext.Current.GetString("requestId");
            var header = new Dictionary<string, string>
                {
                    { "X-GD-RequestId", reqId }
                };
            var response = _serviceInvokerProvider.GetResponse<CreateCheckBookOrderDoRequest, CreateCheckBookOrderDoResponse>(
                CreateCheckBookOrdersUrl(request), "POST", request, header,requestTimeout);
       
            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for {CreateCheckBookOrdersUrl(request)}.");

            return response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="programCode"></param>
        /// <param name="accountIdentifier"></param>
        /// <param name="accountTransactionToken">GSS db calls it transactionIdentifier</param>
        /// <returns></returns>
        public GetCheckInfoByTransactionIdentifierResponse GetCheckInfoByTransactionIdentifier(string programCode, AccountIdentifier accountIdentifier,
            Guid accountTransactionToken)
        {
            GetTimeout("X-GD-Bos-GetCheckInfoByTransactionIdentifier", out var requestTimeout);

            var url = GetCheckInfoByTransactionIdentifierUrl(programCode, accountIdentifier, accountTransactionToken);
            var response = _serviceInvokerProvider.GetWebResponse<GetCheckInfoByTransactionIdentifierResponse>(
                url, "GET", null, requestTimeout);

            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for {url}.");

            return response;
        }

        private string StopPaperCheckPaymentUrl(CheckInventoryRequest request)
        {
            return _paperCheckUrl + $"/programs/{request.ProgramCode}/accounts/{request.AccountIdentifier}/check";
        }

        private string CheckBookOrderUrl(CheckBookRequest request)
        {
            return _paperCheckUrl + $"/programs/{request.ProgramCode}/accounts/{request.AccountIdentifier}/checkBookOrder";
        }

        private string CreateCheckBookOrdersUrl(CreateCheckBookOrderDoRequest request)
        {
            return _paperCheckUrl + $"/programs/{request.ProgramCode}/checkBookOrders";
        }

        private string GetCheckBooksOrderUrl(GetCheckBookOrdersRequest request)
        {
            var queryString = "";
            if (!string.IsNullOrWhiteSpace(request.OrderConfirmationToken))
                queryString = $"?orderConfirmationToken={request.OrderConfirmationToken}";

            return _paperCheckUrl + $"/programs/{request.ProgramCode}/accounts/{request.AccountIdentifier}/checkBookOrders{queryString}";
        }

        private string GetCheckBookImageUrl(GetCheckBookImageRequest request)
        {
            return _paperCheckUrl + $"/programs/{request.ProgramCode}/accounts/{request.AccountIdentifier}/checkImages?checkNumber={request.CheckNumber}&imageFaceType={request.imageFaces}";
        }

        private string GetCheckInfoByTransactionIdentifierUrl(string programCode, AccountIdentifier accountIdentifier, Guid accountTransactionToken)
        {
            return _paperCheckUrl + $"/programs/{programCode}/accounts/{accountIdentifier}/checkInfo?transactionIdentifier={accountTransactionToken}";
        }
       
    }

}
