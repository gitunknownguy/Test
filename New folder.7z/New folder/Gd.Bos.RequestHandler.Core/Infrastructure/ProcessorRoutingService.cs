﻿using Gd.Bos.Dcpp.Contract.Message;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Business;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Services.Dcpp;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Logic.ProcessorSelector.Contract;
using Gd.Bos.Shared.Common.Logic.ProcessorSelector.Model;
using Newtonsoft.Json;
using NLog;
using RequestHandler.Core.Domain.Services.CPM;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using Gd.Bos.Shared.Common.CBSProcessorManager.Contract.Message.Request;
using Gd.Bos.Shared.Common.CBSProcessorManager.Contract.Message.Response;
using AdjustAccountBalanceResponse = Gd.Bos.Dcpp.Contract.Message.AdjustAccountBalanceResponse;
using ChangeAccountStatusResponse = Gd.Bos.Dcpp.Contract.Message.ChangeAccountStatusResponse;
using ChangeCardStatusResponse = Gd.Bos.Dcpp.Contract.Message.ChangeCardStatusResponse;
using ChangePurseStatusResponse = Gd.Bos.Dcpp.Contract.Message.ChangePurseStatusResponse;
using GetAccountBalanceResponse = Gd.Bos.Dcpp.Contract.Message.GetAccountBalanceResponse;
using LogManager = NLog.LogManager;
using OrderCardResponse = Gd.Bos.Dcpp.Contract.Message.OrderCardResponse;
using OverrideProductResponse = Gd.Bos.Dcpp.Contract.Message.OverrideProductResponse;
using ProductFeatureGroupOverride = Gd.Bos.Shared.Common.Dcpp.Contract.Data.ProductFeatureGroupOverride;
using ReportLostStolenV2Response = Gd.Bos.Dcpp.Contract.Message.ReportLostStolenV2Response;
using UpdateAccountRequest = Gd.Bos.Dcpp.Contract.Message.UpdateAccountRequest;
using UpdateAccountResponse = Gd.Bos.Dcpp.Contract.Message.UpdateAccountResponse;
using UpdateCreditLimitHistoryRequest = Gd.Bos.Dcpp.Contract.Message.UpdateCreditLimitHistoryRequest;
using UpdateCreditLimitHistoryResponse = Gd.Bos.Dcpp.Contract.Message.UpdateCreditLimitHistoryResponse;
using UpdateProductResponse = Gd.Bos.Dcpp.Contract.Message.UpdateProductResponse;
using ValidateCvvByPanRequest = RequestHandler.Core.Domain.Services.Dcpp.ValidateCvvByPanRequest;
using ValidateCvvByPanResponse = RequestHandler.Core.Domain.Services.Dcpp.ValidateCvvByPanResponse;
using AccountStatusReason = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountStatusReason;
using CPMAccountStatusReason = Gd.Bos.Shared.Common.CBSProcessorManager.Contract.Enums.CPMAccountStatusReason;


namespace RequestHandler.Core.Infrastructure
{
    public class ProcessorRoutingService : IDcppService
    {
        private readonly ICpmService _cpmService;
        private readonly IProcessorSelectorService _processorSelectorService;
        private readonly IDcppService _dcppService;
        private readonly Logger _logger = LogManager.GetCurrentClassLogger();

        public ProcessorRoutingService(ICpmService cpmService, IProcessorSelectorService processorSelectorService, IDcppService dcppService)
        {
            _cpmService = cpmService;
            _processorSelectorService = processorSelectorService;
            _dcppService = dcppService;
        }

        #region interface implementation
        public void ActivateCard(AccountIdentifier accountIdentifier, string paymentInstrumentIdentifier, string source = null)
        {
            if (IsRoutingToCPM(accountIdentifier))
            {
                _logger.Info($"ActivateCard call route to CPM, AccountIdentifier: {accountIdentifier}");
                _cpmService.ActivateCard(accountIdentifier, paymentInstrumentIdentifier, source);
                return;
            }
            _dcppService.ActivateCard(accountIdentifier, paymentInstrumentIdentifier, source);
        }

        public ActivateOrSuspendTokenResponse ActivateOrSuspendToken(AccountIdentifier accountIdentifier, string tokenId, Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TokenAction action, string comment)
        {
            return _dcppService.ActivateOrSuspendToken(accountIdentifier, tokenId, action, comment);
        }

        public ActivateSampleCardResponse ActivateSamplesCard(AccountIdentifier accountIdentifier, string cardProxy, bool? isEmv, string cardStockCode, string embossedName, string accountNumber, string productCode)
        {
            if (IsRoutingToCPM(accountIdentifier))
            {
                _logger.Info($"AdjustBalance call route to CPM, AccountIdentifier: {accountIdentifier}");
                return _cpmService.ActivateSamplesCard(accountIdentifier, cardProxy, isEmv, cardStockCode, embossedName, accountNumber, productCode);
            }

            return _dcppService.ActivateSamplesCard(accountIdentifier, cardProxy, isEmv, cardStockCode, embossedName, accountNumber, productCode);
        }

        public Gd.Bos.RequestHandler.Core.Domain.Services.Dcpp.CreateAccountResponse AddAccountHolder(string accountIdentifier, string userIdentifier, string accountHolderIdentifier, string productMaterialType, UserName cardholderName, string embossName, DateTime dateOfBirth, string productCode, bool isVirtualTierAllowed, IEnumerable<Address> addresses, IEnumerable<Gd.Bos.RequestHandler.Core.Domain.Model.User.PhoneNumber> phoneNumbers)
        {
            if (IsRoutingToCPM(accountIdentifier))
            {
                throw new NotImplementedException();
            }
            return _dcppService.AddAccountHolder(accountIdentifier, userIdentifier, accountHolderIdentifier, productMaterialType, cardholderName, embossName, dateOfBirth, productCode, isVirtualTierAllowed, addresses, phoneNumbers);
        }

        public AddPurseResponse AddPurseToAccount(string programCode, AccountIdentifier accountIdentifier, Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.PurseType purseType, string userDescription = null, decimal? goalAmount = null, string goalDate = null, string iconName = null, string purseSubType = null)
        {
            if (IsRoutingToCPM(accountIdentifier))
            {
                _logger.Info($"AddPurseToAccount call route to CPM, AccountIdentifier: {accountIdentifier}");
                return _cpmService.AddPurseToAccount(programCode, accountIdentifier, purseType, userDescription, goalAmount, goalDate, iconName, purseSubType);
            }

            return _dcppService.AddPurseToAccount(programCode, accountIdentifier, purseType, userDescription, goalAmount, goalDate, iconName, purseSubType);
        }

        public AddSegmentResponse AddSegment(string paymentIdentifier, string segmentName, DateTime startDate, DateTime endDate, string accountIdentifier)
        {
            return _dcppService.AddSegment(paymentIdentifier, segmentName, startDate, endDate, accountIdentifier);
        }

        public AdjustBalanceResponse AdjustBalance(AccountIdentifier accountIdentifier, decimal amount, bool allowNegativeBalance, string currencyCode, string transClass, string transactionReferenceId, string description, string comment, string commentPostfix = ",FT", int? requestTimeout = null, string originalTransactionId = null)
        {
            if (IsRoutingToCPM(accountIdentifier))
            {
                _logger.Info($"AdjustBalance call route to CPM, AccountIdentifier: {accountIdentifier}");
                return _cpmService.AdjustBalance(accountIdentifier, amount, allowNegativeBalance, currencyCode, transClass, transactionReferenceId, description, comment, commentPostfix, requestTimeout, originalTransactionId);
            }
            return _dcppService.AdjustBalance(accountIdentifier, amount, allowNegativeBalance, currencyCode, transClass, transactionReferenceId, description, comment, commentPostfix, requestTimeout);
        }

        public AdjustAccountBalanceResponse AdjustBalanceForAccountTransaction(AccountIdentifier accountIdentifier, decimal amount, bool allowNegativeBalance, string currencyCode, string transClass, string transactionReferenceId, string description, string comment, string commentPostfix = ",FT", int? requestTimeout = null)
        {
            if (IsRoutingToCPM(accountIdentifier))
            {
                _logger.Info($"AdjustBalanceForAccountTransaction call route to CPM, AccountIdentifier: {accountIdentifier}");
                return _cpmService.AdjustBalanceForAccountTransaction(accountIdentifier, amount, allowNegativeBalance, currencyCode, transClass, transactionReferenceId, description, comment, commentPostfix, requestTimeout);
            }
            return _dcppService.AdjustBalanceForAccountTransaction(accountIdentifier, amount, allowNegativeBalance, currencyCode, transClass, transactionReferenceId, description, comment, commentPostfix, requestTimeout);
        }

        public AdjustBalanceResponse AdjustPurseBalance(AccountIdentifier accountIdentifier, AccountBalanceIdentifier accountBalanceIdentifier, decimal amount, bool allowNegativeBalance, string currencyCode, string transClass, string transactionReferenceId, string description, string comment, string commentPostfix = ",FT")
        {
            if (IsRoutingToCPM(accountIdentifier))
            {
                _logger.Info($"AdjustPurseBalance call route to CPM, AccountIdentifier: {accountIdentifier}");
                return _cpmService.AdjustPurseBalance(accountIdentifier, accountBalanceIdentifier, amount, allowNegativeBalance, currencyCode, transClass, transactionReferenceId, description, comment, commentPostfix);
            }
            return _dcppService.AdjustPurseBalance(accountIdentifier, accountBalanceIdentifier, amount, allowNegativeBalance, currencyCode, transClass, transactionReferenceId, description, comment, commentPostfix);
        }

        public ChangeAccountStatusResponse ChangeAccountStatus(string accountId, string accountStatus, string gdAccountStatus = null, List<AccountStatusReason> accountStatusReasonsToAdd = null, List<AccountStatusReason> accountStatusReasonsToRemove = null, Guid? userIdentifier = null)
        {
            if (IsRoutingToCPM(AccountIdentifier.FromString(accountId)))
            {
                _logger.Info($"ChangeAccountStatus call route to CPM, AccountIdentifier: {accountId}, {accountStatus}, {gdAccountStatus}");
                try
                {
                    List<CPMAccountStatusReason> toAdd = new List<CPMAccountStatusReason>();
                    List<CPMAccountStatusReason> toRemove = new List<CPMAccountStatusReason>();
                    if (accountStatusReasonsToAdd != null)
                    {
                        foreach (AccountStatusReason reason in accountStatusReasonsToAdd)
                        {
                            int enumValue = (int)reason;
                            toAdd.Add((CPMAccountStatusReason)enumValue);
                        }
                    }
                    if (accountStatusReasonsToRemove != null)
                    {
                        foreach (AccountStatusReason reason in accountStatusReasonsToRemove)
                        {
                            int enumValue = (int)reason;
                            toRemove.Add((CPMAccountStatusReason)enumValue);
                        }
                    }

                    return _cpmService.ChangeAccountStatus(accountId, gdAccountStatus, toAdd, toRemove, userIdentifier);
                }
                catch (Exception ex)
                {
                    _logger.Error(ex, "ChangeAccountStatus call rout to CPM failed");
                    throw;
                }
            }

            if (!string.IsNullOrEmpty(gdAccountStatus) && gdAccountStatus.ToLower() == "closed")
            {
                _logger.Info($"PTS ChangeAccountStatus not allowed update to closed, AccountIdentifier: {accountId}, {accountStatus}, {gdAccountStatus}");
                return new ChangeAccountStatusResponse();
            }

            return _dcppService.ChangeAccountStatus(accountId, accountStatus, gdAccountStatus);


        }

        public ChangeCardStatusResponse ChangeCardStatus(string accountId, string cardStatus, Guid? paymentIdentifier = null, string lifeTimeEventType = null)
        {
            if (Guid.TryParse(accountId, out var guidAccountId) && IsRoutingToCPM(guidAccountId))
            {
                _logger.Info($"ChangeCardStatus call route to CPM, AccountIdentifier: {guidAccountId}");
                return _cpmService.ChangeCardStatus(guidAccountId, cardStatus, paymentIdentifier, lifeTimeEventType);
            }

            return _dcppService.ChangeCardStatus(accountId, cardStatus, paymentIdentifier, lifeTimeEventType);
        }

        public ChangePurseStatusResponse ChangePurseStatus(string accountIdentifier, string purseIdentifier, string accountStatus)
        {
            if (IsRoutingToCPM(accountIdentifier))
            {
                _logger.Info($"ChangePurseStatus call route to CPM, AccountIdentifier: {accountIdentifier}");
                return _cpmService.ChangePurseStatus(accountIdentifier, purseIdentifier, accountStatus);
            }

            return _dcppService.ChangePurseStatus(accountIdentifier, purseIdentifier, accountStatus);
        }

        public Gd.Bos.RequestHandler.Core.Domain.Services.Dcpp.CreateAccountResponse CreateAccount(AccountIdentifier accountIdentifier, UserIdentifier userIdentifier, IEnumerable<string> userIdentifiers, UserName name, IEnumerable<Address> addresses, IEnumerable<Gd.Bos.RequestHandler.Core.Domain.Model.User.PhoneNumber> phoneNumbers, string programCode, string productCode, PhysicalCardType physicalCardType, bool personalized, string productMaterialType, int productTierKey, bool isVirtualTierAllowed, string embossName, string businessName, string accountNumber, int expirationMonths,
            int expirationRandomMonths, BusinessAddress businessAddress = null, string productType = null, int billCycleDay = 1, string routingNumber = null, bool needEmbossing = true, string storeId = null, string businessEmbossName = null)
        {
            accountNumber = (accountNumber == string.Empty ? null : accountNumber);
            routingNumber = (routingNumber == string.Empty ? null : routingNumber);
            if (IsRoutingToCPM(accountIdentifier))
            {
                _logger.Info($"CreateAccount call route to CPM, AccountIdentifier: {accountIdentifier}");
                _logger.Info($"CreateAccount call route to CPM, UserIdentifier: {userIdentifier}");
                _logger.Info($"CreateAccount call route to CPM, UserIdentifiers: {JsonConvert.SerializeObject(userIdentifiers)}");
                _logger.Info($"CreateAccount call route to CPM, addresses: {JsonConvert.SerializeObject(addresses)}");
                _logger.Info($"CreateAccount call route to CPM, PhoneNumbers: {JsonConvert.SerializeObject(phoneNumbers)}");
                _logger.Info($"CreateAccount call route to CPM, programCode: {programCode},productCode:{productCode}, physicalCardType:{physicalCardType},personalized:{personalized},productMaterialType:{productMaterialType}");
                _logger.Info($"CreateAccount call route to CPM, productTierKey: {productTierKey},isVirtualTierAllowed:{isVirtualTierAllowed}, embossName:{embossName},businessName:{businessName},accountNumber:{accountNumber}");
                _logger.Info($"CreateAccount call route to CPM, expirationMonths: {expirationMonths},expirationRandomMonths:{expirationRandomMonths}, productType:{productType}, businessAddress:{businessAddress}");
                return _cpmService.CreateAccount(accountIdentifier,
                    userIdentifier,
                    userIdentifiers,
                    name,
                    addresses,
                    phoneNumbers,
                    programCode,
                    productCode,
                    physicalCardType,
                    personalized,
                    productMaterialType,
                    productTierKey,
                    isVirtualTierAllowed,
                    embossName,
                    businessName,
                    accountNumber,
                    expirationMonths,
                    expirationRandomMonths,
                    businessAddress,
                    productType,
                    billCycleDay,
                    //GBOS-78089 ypc
                    routingNumber,
                    needEmbossing,
                    storeId,
                    businessEmbossName
                    );
            }

            return _dcppService.CreateAccount(accountIdentifier,
                userIdentifier,
                userIdentifiers,
                name,
                addresses,
                phoneNumbers,
                programCode,
                productCode,
                physicalCardType,
                personalized,
                productMaterialType,
                productTierKey,
                isVirtualTierAllowed,
                embossName,
                businessName,
                accountNumber,
                expirationMonths,
                expirationRandomMonths,
                businessAddress,
                null,
                billCycleDay,
                //GBOS-78089 ypc
                routingNumber);
        }

        public DeleteSegmentResponse DeleteSegment(string paymentIdentifier, string segmentName, string accountIdentifier)
        {
            return _dcppService.DeleteSegment(paymentIdentifier, segmentName, accountIdentifier);
        }

        public CardDetails GetCardDetails(AccountIdentifier accountIdentifier, CardExpirationDate expirationDate, Guid? paymentIdentifier = null, Guid? paymentInstrumentIdentifier = null)
        {
            if (IsRoutingToCPM(accountIdentifier))
            {
                _logger.Info($"Get card detail rount to CPM for account {accountIdentifier}");
                return _cpmService.GetCardDetails(accountIdentifier, expirationDate, paymentIdentifier, paymentInstrumentIdentifier);
            }
            return _dcppService.GetCardDetails(accountIdentifier, expirationDate, paymentIdentifier);
        }

        public OrderCardResponse OrderPhysicalCard(AccountIdentifier accountIdentifier, PaymentIdentifierIdentifier paymentIdentifier, PaymentInstrumentIdentifier paymentInstrumentIdentifier, string programCode, string productMaterialType = null, string customCardImageIdentifier = null, Gd.Bos.Dcpp.Contract.Enum.ReplacementReason replacementReason = Gd.Bos.Dcpp.Contract.Enum.ReplacementReason.NewCard, bool override10DayLimit = false, DeliveryMethod deliveryMethod = DeliveryMethod.Regular, string retryId = null, string source = null, bool? waiveFee = null,
            bool? waiveOvernightFee = null, bool needEmbossing = true, string storeId = null)
        {
            if (IsRoutingToCPM(accountIdentifier))
            {
                _logger.Info($"OrderPhysicalCard call route to CPM, AccountIdentifier: {accountIdentifier}, PaymentInstrumentIdentifier{paymentInstrumentIdentifier}, waiveFee:{waiveFee}");
                return _cpmService.OrderPhysicalCard(accountIdentifier, paymentIdentifier, paymentInstrumentIdentifier, programCode, productMaterialType, customCardImageIdentifier, replacementReason, override10DayLimit, deliveryMethod, retryId, source, waiveFee, waiveOvernightFee, needEmbossing, storeId);
            }
            return _dcppService.OrderPhysicalCard(accountIdentifier, paymentIdentifier, paymentInstrumentIdentifier, programCode, productMaterialType, customCardImageIdentifier, replacementReason, override10DayLimit, deliveryMethod, retryId, source);
        }

        public OverrideProductResponse OverrideProduct(string accountIdentifier, string programCode, bool isRevert, List<ProductFeatureGroupOverride> productFeatureGroups)
        {
            if (IsRoutingToCPM(accountIdentifier))
            {
                _logger.Info($"OverrideProduct call route to CPM, AccountIdentifier: {accountIdentifier}, isRevert{isRevert}");
                return _cpmService.OverrideProduct(accountIdentifier, programCode, isRevert, productFeatureGroups);
            }
            return _dcppService.OverrideProduct(accountIdentifier, programCode, isRevert, productFeatureGroups);
        }

        public ReportLostStolenV2Response ReportLostStolen(AccountIdentifier accountIdentifier,
            PaymentInstrumentIdentifier paymentInstrumentIdentifier, LossType lossType, DeliveryMethod deliveryMethod,
            DateTime? dateLastUsed, DateTime? dateDiscoveredMissing, bool? policeNotified, string notes,
            string productMaterialType, bool createVirtualCard, string customCardImageIdentifier = null,
            bool isProductEligibleForDigitalWallet = false, string source = null, bool? waiveFee = null,
            bool? waiveOvernightFee = null, int PhysicalProductTierKey = 0, bool needEmbossing = true,
            bool override10DayLimit = false, string storeId = null)
        {
            if (IsRoutingToCPM(accountIdentifier))
            {
                _logger.Info($"ReportLostStolen call route to CPM, AccountIdentifier: {accountIdentifier}, PaymentInstrumentIdentifier{paymentInstrumentIdentifier}");
                return _cpmService.ReportLostStolenv2(accountIdentifier, paymentInstrumentIdentifier, lossType, deliveryMethod, dateLastUsed, dateDiscoveredMissing, policeNotified, notes, productMaterialType, createVirtualCard, customCardImageIdentifier, isProductEligibleForDigitalWallet, source, waiveFee, waiveOvernightFee,
                    0, needEmbossing, override10DayLimit, storeId: storeId);
            }
            return _dcppService.ReportLostStolen(accountIdentifier, paymentInstrumentIdentifier, lossType, deliveryMethod, dateLastUsed, dateDiscoveredMissing, policeNotified, notes, productMaterialType, createVirtualCard, customCardImageIdentifier, isProductEligibleForDigitalWallet, source, null, null, PhysicalProductTierKey);
        }

        public ReportLostStolenV2Response ReportLostStolenRetry(AccountIdentifier accountIdentifier, PaymentInstrumentIdentifier paymentInstrumentIdentifier, Guid requestId, LossType lossType, DeliveryMethod deliveryMethod, DateTime? dateLastUsed, DateTime? dateDiscoveredMissing, bool? policeNotified, string notes, string productMaterialType, string programCode, string customCardImageIdentifier = null, bool isProductEligibleForDigitalWallet = false, string source = null, bool? waiveFee = null, bool? waiveOvernightFee = null, bool createVirtualCard = false,
            int PhysicalProductTierKey = 0, bool needEmbossing = true, bool override10DayLimit = false, string storeId = null)
        {
            if (IsRoutingToCPM(accountIdentifier))
            {
                _logger.Info($"ReportLostStolenRetry call route to CPM, AccountIdentifier: {accountIdentifier}, PaymentInstrumentIdentifier{paymentInstrumentIdentifier}");
                return _cpmService.ReportLostStolenv2(accountIdentifier, paymentInstrumentIdentifier, lossType,
                    deliveryMethod, dateLastUsed, dateDiscoveredMissing, policeNotified, notes, productMaterialType,
                    createVirtualCard, customCardImageIdentifier, isProductEligibleForDigitalWallet, source, waiveFee,
                    waiveOvernightFee,
                    0, needEmbossing, override10DayLimit, requestId, programCode, storeId);
            }
            return _dcppService.ReportLostStolenRetry(accountIdentifier, paymentInstrumentIdentifier, requestId, lossType, deliveryMethod, dateLastUsed, dateDiscoveredMissing, policeNotified, notes, productMaterialType, programCode, customCardImageIdentifier, isProductEligibleForDigitalWallet, source, null, null, createVirtualCard, PhysicalProductTierKey);
        }

        public SetCycleResponse SetCycle(AccountIdentifier accountIdentifier)
        {
            if (IsRoutingToCPM(accountIdentifier))
            {
                _logger.Info($"SetCycle call route to CPM, AccountIdentifier: {accountIdentifier}");
                return _cpmService.SetCycle(accountIdentifier);
            }

            return _dcppService.SetCycle(accountIdentifier);
        }

        public void SetPin(AccountIdentifier accountIdentifier, string paymentInstrumentIdentifier, string pin)
        {
            if (IsRoutingToCPM(accountIdentifier))
            {
                _logger.Info($"SetPin call route to CPM, AccountIdentifier: {accountIdentifier}");
                _cpmService.SetPin(accountIdentifier, paymentInstrumentIdentifier, pin);
            }
            else
            {
                _dcppService.SetPin(accountIdentifier, paymentInstrumentIdentifier, pin);
            }
        }

        public UpdateAccountResponse UpdateAccount(UpdateAccountRequest request, string middleName = null)
        {
            if (IsRoutingToCPM(request.AccountIdentifier))
            {
                _logger.Info($"UpdateAccount call route to CPM, AccountIdentifier: {request.AccountIdentifier}");
                return _cpmService.UpdateAccount(request, middleName);
            }
            return _dcppService.UpdateAccount(request);
        }

        public UpdateProductResponse UpdateProduct(string accountIdentifier, string programCode, int productTierKey, string productMaterialType, string cardStock = null)
        {
            if (IsRoutingToCPM(accountIdentifier))
            {
                _logger.Info($"UpdateProduct call route to CPM, AccountIdentifier: {accountIdentifier}");
                return _cpmService.UpdateProduct(accountIdentifier, programCode, productTierKey, productMaterialType, cardStock);
            }
            return _dcppService.UpdateProduct(accountIdentifier, programCode, productTierKey, productMaterialType, cardStock);
        }

        public ValidateCVVResponse ValidateCvv(string pan, string cvv, string accountIdentifier, CardExpirationDate cardExpirationDate, bool usePan)
        {
            if (IsRoutingToCPM(accountIdentifier))
            {
                _logger.Info($"ValidateCvv call route to CPM, AccountIdentifier: {accountIdentifier}");
                return _cpmService.ValidateCvv(pan, cvv, accountIdentifier, cardExpirationDate, usePan);
            }

            return _dcppService.ValidateCvv(pan, cvv, accountIdentifier, cardExpirationDate, usePan);
        }

        public ValidateCvvByPanResponse ValidateCvvByPan(ValidateCvvByPanRequest request)
        {
            var processor = _processorSelectorService.Select(request.Pan);
            if (IsUsingCBSProcessor(processor))
            {
                _logger.Info($"ValidateCvvByPan call routed to CPM using pan processor selector");
                return _cpmService.ValidateCvvByPan(request);
            }
            return _dcppService.ValidateCvvByPan(request);
        }

        public bool VerifyPin(AccountIdentifier accountIdentifier, string paymentInstrumentIdentifier, string pin)
        {
            return _dcppService.VerifyPin(accountIdentifier, paymentInstrumentIdentifier, pin);
        }

        public decimal GetYearToDateAccountFees(Guid requestId, string programCode, string accountIdentifier)
        {
            if (IsRoutingToCPM(accountIdentifier))
            {
                _logger.Info($"ValidateCvv call route to CPM, AccountIdentifier: {accountIdentifier}");
                return _cpmService.GetYearToDateAccountFees(requestId, programCode, accountIdentifier).YtdFees;
            }
            return _dcppService.GetYearToDateAccountFees(requestId, programCode, accountIdentifier);
        }

        public GetAccountBalanceResponse GetAccountBalance(string programCode, string accountIdentifier)
        {
            if (IsRoutingToCPM(accountIdentifier))
            {
                _logger.Info($"GetAccountBalance call route to CPM, AccountIdentifier: {accountIdentifier}");
                return _cpmService.GetAccountBalance(programCode, accountIdentifier);
            }
            return _dcppService.GetAccountBalance(programCode, accountIdentifier);
        }

        public UpdateCreditLimitHistoryResponse UpdateCreditLimitHistory(UpdateCreditLimitHistoryRequest request)
        {
            return _cpmService.UpdateCreditLimitHistory(request);
        }
        public LinkCardResponse LinkCard(LinkCardRequest request)
        {
            if (IsRoutingToCPM(request.AccountIdentifier))
            {
                _logger.Info($"LinkCard call route to CPM, AccountIdentifier: {request.AccountIdentifier}");
                return _cpmService.LinkCard(request);
            }
            else
            {
                throw new NotImplementedException("Not support for PTS dcppService");
            }
        }

        #endregion
        public bool IsRoutingToCPM(AccountIdentifier accountIdentifier)
        {
            var processor = _processorSelectorService.Select(accountIdentifier.ToGuid());
            return IsUsingCBSProcessor(processor);
        }

        // ReSharper disable once InconsistentNaming
        private static bool IsUsingCBSProcessor(ProcessorSelectedInfo processor) =>
            processor.Processor switch
            {
                SupportedProcessor.CBS => true,
                SupportedProcessor.ACI => true,
                _ => false
            };
    }
}
