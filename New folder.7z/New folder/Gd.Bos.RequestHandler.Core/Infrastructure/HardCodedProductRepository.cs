﻿using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.Shared.Common.UtilityCoreApi.Contract.Data;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;


namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    [ExcludeFromCodeCoverage(Justification = "Data Access")]
    public class HardCodedProductRepository : IProductRepository
    {
        public Product GetByProductCode(ProductCode productCode)
        {
            if (productCode == ProductCode.FromString("001"))
            {
                return new Product(productCode, ProgramCode.FromString("12345"), 1, "1010", "124303120");
            }

            throw new Exception("No Product exists for the specified ProgramCode and ProductCode.");
        }

        public Product GetByProductCode(ProductCode productCode, ProgramCode programCode)
        {
            if (programCode == ProgramCode.FromString("12345") && productCode == ProductCode.FromString("001"))
            {
                return new Product(productCode, programCode, 1, null, "1010", "124303120");
            }

            throw new Exception("No Product exists for the specified ProgramCode and ProductCode.");
        }

        public string GetNameByProductCode(ProductCode productCode, ProgramCode programCode)
        {
            if (programCode == ProgramCode.FromString("12345") && productCode == ProductCode.FromString("001"))
            {
                return "Hard Coded Product Name";
            }

            throw new Exception("No Product exists for the specified ProgramCode and ProductCode.");
        }

        public Product GetProductByBin(int binProductKey)
        {
            if (binProductKey == 12345)
            {
                return new Product(ProductCode.FromString("12345"), ProgramCode.FromString("001"), 1, null, "1010", "124303120");
            }
            throw new Exception("No Product exists for the specified Bin.");
        }

        public IEnumerable<string> GetProductBinsByProgramCode(ProgramCode programCode)
        {
            return new[] { "424067" };
        }

        public ProductTierData GetProductTierByProductCodeMaterialType(string productCode, bool requestPhysicalCard, string productMaterialType)
        {
            if (productCode == "50600")
            {
                ProductTierData pt = new ProductTierData()
                {
                    ProductKey = 26,
                    IsDefault = false,
                    ProductClassKey = 2,
                    ProductCode = "50600",
                    ProductTier = "Intuit Money Visa Debit Card Perso EMV",
                    ProductTierAttributeKey = 5,
                    ProductTierClassKey = 3,
                    ProductTierKey = 82,
                    CardStockValue = "A1X"
                };

                return pt;
            }

            return null;
        }

        public ProductTypeInfo GetProductTypeByProductKey(int productKey)
        {
            if (productKey == 1)
            {
                return new ProductTypeInfo
                {
                    ProductKey = 12345,
                    ProductType = "Test"
                };
            }
            throw new NotImplementedException();
        }

        public Product GetProductByKey(int productKey)
        {
            throw new NotImplementedException();
        }

        public List<ProductInfoModel> GetAllCachedProducts()
        {
            throw new NotImplementedException();
        }

        public List<ProductTierData> GetAllCachedProductTiers()
        {
            throw new NotImplementedException();
        }

        public (bool result, ProductTierData npnrProduct, ProductTierData emvProduct) IsGbosRetailProductTier(int productTierKey)
        {
            throw new NotImplementedException();
        }

        public ProductTierData GetProductTierByProductTierKey(int productTierKey, short processorKey)
        {
            throw new NotImplementedException();
        }
    }
}
