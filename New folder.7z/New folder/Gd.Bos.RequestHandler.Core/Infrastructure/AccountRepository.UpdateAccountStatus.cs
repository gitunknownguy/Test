﻿using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Linq;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using SourceSystem = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.SourceSystem;
using Gd.Bos.Shared.Common;
using SqlDataRecord = Microsoft.Data.SqlClient.Server.SqlDataRecord;
using SqlMetaData = Microsoft.Data.SqlClient.Server.SqlMetaData;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    partial class AccountRepository
    {
        /// <summary>
        /// Update Account Status and StatusReason 
        /// </summary>
        /// <param name="account"></param>
        /// <param name="status"></param>
        /// <param name="reasonsToAdd">list of status reasons to add to the account</param>
        /// <param name="reasonsToRemove">list of status reasons to remove from the account</param>
        public void UpdateAccountStatus(Account account, AccountStatus status, IList<AccountStatusReason> reasonsToAdd,
            IList<AccountStatusReason> reasonsToRemove, SourceSystem? source)
        {
            if (account == null)
            {
                throw new ArgumentNullException(nameof(account));
            }
            if (account.AccountKey == 0)
            {
                throw new ArgumentException("AccountKey not specified", nameof(account));
            }
            if (account.AccountIdentifier == null || account.AccountIdentifier == Guid.Empty)
            {
                throw new ArgumentException("AccountIdentifier not specified", nameof(account));
            }

            try
            {
                using (var cnn = _dataAccess.CreateConnection())
                {
                    if (status != AccountStatus.Unknown)
                    {
                        // only update status if specified.
                        _dataAccess.ExecuteNonQuery(
                            "[dbo].[UpdAccountStatusByAccountKey]", cnn,
                            new SqlParameter() { ParameterName = "AccountKey", Value = account.AccountKey },
                            new SqlParameter() { ParameterName = "ChangeBy", Value = _userName },
                            new SqlParameter() { ParameterName = "AccountStatusKey", Value = (Int16)status },
                            new SqlParameter() { ParameterName = "SystemKey", Value = source }
                        );
                    }

                    if (reasonsToRemove?.Count > 0)
                    {
                        _dataAccess.ExecuteNonQuery(
                            "[dbo].[UpdAccountStatusReasonHistoryV2]",
                            cnn,
                            new SqlParameter("ChangeBy", _userName),
                            new SqlParameter("AccountIdentifier", (Guid)account.AccountIdentifier),
                            new SqlParameter() { ParameterName = "AccountStatusReasonKey", Value = ToAccountStatusReasonTable(reasonsToRemove).Convert(), TypeName = "typeAccountStatusReason", SqlDbType = System.Data.SqlDbType.Structured }
                            //new SqlParameter("IsActive", false)

                        );
                    }

                    if (reasonsToAdd != null)
                        reasonsToAdd.ToList().ForEach(
                            reason =>
                                _dataAccess.ExecuteNonQuery(
                                    "[dbo].[InsAccountStatusReasonHistory]",
                                    cnn,
                                    new SqlParameter("ChangeBy", _userName),
                                    new SqlParameter("AccountIdentifier", (Guid)account.AccountIdentifier),
                                    new SqlParameter("AccountStatusReasonKey", (long)reason),
                                    new SqlParameter("IsActive", true),
                                    new SqlParameter("AccountStatusReasonHistoryKey", System.Data.SqlDbType.BigInt)
                                    {
                                        Direction = System.Data.ParameterDirection.Output
                                    }

                                )
                        );
                }

            }
            catch (Exception ex)
            {
                Logger.Error(ex, "Exception occured while updating account status");
                throw;
            }
        }

        public void InsertAccountStatusReason(AccountIdentifier accountIdentifier, IList<AccountStatusReason> reasonsToAdd)
        {
            if (accountIdentifier == null || accountIdentifier == Guid.Empty)
                throw new ArgumentException("AccountIdentifier not specified", nameof(accountIdentifier));

            try
            {
                using (var cnn = _dataAccess.CreateConnection())
                {
                    if (reasonsToAdd != null)
                        reasonsToAdd.ToList().ForEach(
                            reason => _dataAccess.ExecuteNonQuery("[dbo].[InsAccountStatusReasonHistory]",
                                    cnn,
                                    new SqlParameter("ChangeBy", _userName),
                                    new SqlParameter("AccountIdentifier", (Guid)accountIdentifier),
                                    new SqlParameter("AccountStatusReasonKey", (long)reason),
                                    new SqlParameter("IsActive", true)
                                )
                        );
                }

            }
            catch (Exception ex)
            {
                Logger.Error(ex, "Exception occured while Inserting account status");
                throw;
            }
        }
        public void RemoveAccountStatusReason(AccountIdentifier accountIdentifier, IList<AccountStatusReason> reasonsToRemove)
        {
            if (accountIdentifier == null || accountIdentifier == Guid.Empty)
                throw new ArgumentException("AccountIdentifier not specified", nameof(accountIdentifier));

            try
            {
                using (var cnn = _dataAccess.CreateConnection())
                {
                    if (reasonsToRemove?.Count > 0)
                    {
                        _dataAccess.ExecuteNonQuery("[dbo].[UpdAccountStatusReasonHistoryV2]",
                            cnn,
                            new SqlParameter("ChangeBy", _userName),
                            new SqlParameter("AccountIdentifier", (Guid)accountIdentifier),
                            new SqlParameter()
                            {
                                ParameterName = "AccountStatusReasonKey",
                                Value = ToAccountStatusReasonTable(reasonsToRemove).Convert(),
                                TypeName = "typeAccountStatusReason",
                                SqlDbType = System.Data.SqlDbType.Structured
                            }
                        );
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex, "Exception occured while updating account status");
                throw;
            }
        }

        /// <summary>
        /// Update Account Status and StatusReason 
        /// </summary>
        /// <param name="account"></param>
        /// <param name="status"></param>
        /// <param name="reasonsToAdd">list of status reasons to add to the account</param>
        /// <param name="reasonsToRemove">list of status reasons to remove from the account</param>
        public void OverrideAccountStatus(Account account, VerificationActivity verificationActivity, List<VerificationStatusReason> verificationStatusReasons,
            AccountStatus status, IList<AccountStatusReason> reasonsToAdd, IList<AccountStatusReason> reasonsToRemove, SourceSystem? source = null, bool isJoint = false)
        {
            if (account == null)
            {
                throw new ArgumentNullException(nameof(account));
            }
            if (account.AccountKey == 0)
            {
                throw new ArgumentException("AccountKey not specified", nameof(account));
            }
            if (account.AccountIdentifier == null || account.AccountIdentifier == Guid.Empty)
            {
                throw new ArgumentException("AccountIdentifier not specified", nameof(account));
            }

            try
            {
                using (var cnn = _dataAccess.CreateConnection())
                {
                    if (!isJoint)
                    {
                        if (status != AccountStatus.Unknown)
                        {// only update status if specified.
                            _dataAccess.ExecuteNonQuery(
                                "[dbo].[UpdAccountStatusByAccountKey]", cnn,
                                new SqlParameter() { ParameterName = "AccountKey", Value = account.AccountKey },
                                new SqlParameter() { ParameterName = "ChangeBy", Value = _userName },
                                new SqlParameter() { ParameterName = "AccountStatusKey", Value = (Int16)status },
                                new SqlParameter() { ParameterName = "SystemKey", Value = source }
                                );
                        }

                        if (reasonsToRemove != null)
                            reasonsToRemove.ToList().ForEach(
                                reason =>
                                    _dataAccess.ExecuteNonQuery(
                                        "[dbo].[UpdAccountStatusReasonHistory]",
                                        cnn,
                                        new SqlParameter("ChangeBy", _userName),
                                        new SqlParameter("AccountIdentifier", (Guid)account.AccountIdentifier),
                                        new SqlParameter("AccountStatusReasonKey", (long)reason),
                                        new SqlParameter("IsActive", false)

                                    )
                                );


                        if (reasonsToAdd != null)
                            reasonsToAdd.ToList().ForEach(
                                reason =>
                                    _dataAccess.ExecuteNonQuery(
                                        "[dbo].[InsAccountStatusReasonHistory]",
                                        cnn,
                                        new SqlParameter("ChangeBy", _userName),
                                        new SqlParameter("AccountIdentifier", (Guid)account.AccountIdentifier),
                                        new SqlParameter("AccountStatusReasonKey", (long)reason),
                                        new SqlParameter("IsActive", true),
                                        new SqlParameter("AccountStatusReasonHistoryKey", System.Data.SqlDbType.BigInt)
                                        {
                                            Direction = System.Data.ParameterDirection.Output
                                        }
                                    )
                            );
                    }

                    var reasonTable = ToVerificationStatusReasonsTable(verificationStatusReasons);

                    var verificationActivityParams = new[] {
                        new SqlParameter() { ParameterName = "VerificationActivityKey",Value = verificationActivity.ActivityKey},
                        new SqlParameter() {ParameterName = "ChangeBy", Value = _userName},
                        //new SqlParameter() {ParameterName = "VerificationActivityTypeKey",  Value = verificationActivity.ActivityTypeKey},
                        new SqlParameter() {ParameterName = "VerificationStatusKey", Value = verificationActivity.StatusKey},
                        new SqlParameter() {ParameterName = "VerificationActivityEndDate", Value = verificationActivity.EndDate},
                        new SqlParameter() {ParameterName = "VerificationStatusReason", Value = reasonTable.Convert(), TypeName = "typeVerificationStatusReason", SqlDbType=System.Data.SqlDbType.Structured}
                    };

                    _dataAccess.ExecuteNonQuery("[dbo].[UpdVerificationActivityStatusV2]", _dataAccess.CreateConnection(), verificationActivityParams);

                    if (!verificationStatusReasons.Contains(VerificationStatusReason.OVRIDV) && verificationActivity.ActivityTypeKey != 5)
                    {
                        var verificationRequest = new[]
                        {
                            new SqlParameter()
                            {
                                ParameterName = "@VerificationRequestKey",
                                Value = account.VerificationRequestKey
                            },
                            new SqlParameter() {ParameterName = "ChangeBy", Value = _userName},
                            new SqlParameter()
                            {
                                ParameterName = "VerificationStatusKey",
                                Value = verificationActivity.StatusKey
                            }
                        };

                        _dataAccess.ExecuteNonQuery("[dbo].[UpdVerificationRequestStatus]",
                            _dataAccess.CreateConnection(), verificationRequest);
                    }
                }

            }
            catch (Exception ex)
            {
                Logger.Error(ex, "Exception occured while updating account status");
                throw;
            }
        }
        private static SqlMetaData[] _typeStatusReasonMetatData = CreateAccountReasonMetaData();

        SqlDataRecord[] ToVerificationStatusReasonsTable(IEnumerable<VerificationStatusReason> values)
        {
            var meta = new SqlMetaData("value", System.Data.SqlDbType.SmallInt);
            return values.Select(v =>
                {
                    var r = new SqlDataRecord(meta);
                    r.SetInt16(0, (short)v);
                    return r;
                })
                .ToArray();
        }

        private List<SqlDataRecord> ToAccountStatusReasonTable(IEnumerable<AccountStatusReason> values)
        {
            List<SqlDataRecord> returnValue = new List<SqlDataRecord>();

            foreach (AccountStatusReason val in values)
            {
                returnValue.Add(CreateStatusReasonDetailRecord(val, false));
            }

            return returnValue;
        }

        private SqlDataRecord CreateStatusReasonDetailRecord(AccountStatusReason accountStatusReason, bool isActive)
        {
            SqlDataRecord record = new SqlDataRecord(_typeStatusReasonMetatData);

            record.SetInt16(0, (short)accountStatusReason);
            record.SetBoolean(1, isActive);

            return record;
        }
        private static SqlMetaData[] CreateAccountReasonMetaData()
        {
            SqlMetaData[] metadata = new SqlMetaData[2];
            metadata[0] = new SqlMetaData("AccountStatusReasonKey", System.Data.SqlDbType.SmallInt);
            metadata[1] = new SqlMetaData("IsActive", System.Data.SqlDbType.Bit);

            return metadata;
        }



        private SqlParameter[] UpdateAccountStatusReasonHistoryParameters(Account account, IList<AccountStatusReason> reasons)
        {
            return new SqlParameter[]
            {
                new SqlParameter("ChangeBy",_userName),
                new SqlParameter("AccountIdentifier", account.AccountIdentifier.ToGuid()),
                new SqlParameter(){
                    ParameterName ="AccountStatusReasonKeys",
                    TypeName = "typeListOfSmallInt_dev",
                    SqlDbType=System.Data.SqlDbType.Structured,
                    Value=ToListOfSmallIntTableValues(reasons.Select(e=>(short)e))
                }
            };
        }

        SqlDataRecord[] ToListOfSmallIntTableValues(IEnumerable<short> values)
        {
            var meta = new SqlMetaData("value", System.Data.SqlDbType.SmallInt);
            return values.Select(v =>
            {
                var r = new SqlDataRecord(meta);
                r.SetInt16(0, v);
                return r;
            })
            .ToArray();
        }
    }
}
