﻿using System;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.RequestHandler.Core.Domain;
using NLog;
using Gd.Bos.RequestHandler.Core.Domain.Services.EGift;
using System.Collections.Generic;
using System.Linq;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.EGift;
using Gd.Bos.Shared.Common.Core.Common.Data;
using Gd.Bos.Shared.Common.Core.Common.Enum;
using Gd.Bos.Shared.Common.CoreApi.Contract.Message.Request;
using Newtonsoft.Json;
using EGiftDeleteRequest = Gd.Bos.RequestHandler.Core.Domain.Services.EGift.EGiftDeleteRequest;
using EGiftDeleteResponse = Gd.Bos.RequestHandler.Core.Domain.Services.EGift.EGiftDeleteResponse;
using EGiftGetWalletRequest = Gd.Bos.RequestHandler.Core.Domain.Services.EGift.EGiftGetWalletRequest;
using EGiftGetWalletResponse = Gd.Bos.RequestHandler.Core.Domain.Services.EGift.EGiftGetWalletResponse;
using EGiftGetPurchaseHistoryRequest = Gd.Bos.RequestHandler.Core.Domain.Services.EGift.EGiftGetPurchaseHistoryRequest;
using EGiftGetPurchaseHistoryResponse = Gd.Bos.RequestHandler.Core.Domain.Services.EGift.EGiftGetPurchaseHistoryResponse;
using EGiftPurchaseRequest = Gd.Bos.RequestHandler.Core.Domain.Services.EGift.EGiftPurchaseRequest;
using EGiftPurchaseResponse = Gd.Bos.RequestHandler.Core.Domain.Services.EGift.EGiftPurchaseResponse;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class EGiftService : IEGiftService
    {
        private readonly IServiceInvokeProvider _serviceInvokerProvider;
        private readonly string _egiftUrl;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        //private readonly IConfiguration _configuration;
        private readonly IEGiftRepository _egiftRepository;
        private readonly IAccountRepository _accountRepository;
        private readonly IPriorityNotificationService _priorityNotificationService;
        public EGiftService(IServiceInvokeProvider serviceInvokeProvider, IRequestHandlerSettings settings, IEGiftRepository egiftRepository,
            IAccountRepository accountRepository, IPriorityNotificationService priorityNotificationService)
        {
            _serviceInvokerProvider = serviceInvokeProvider;
            //_configuration = configuration;
            _egiftRepository = egiftRepository;
            _egiftUrl = settings.EGiftBaseUrl;
            _accountRepository = accountRepository;
            _priorityNotificationService = priorityNotificationService;
        }
        public EGiftProductResponse GetEGiftCatalog(EGiftProductRequest request)
        {
            var catalogResponse = GetProducts(request);
            return catalogResponse;
        }

        public EGiftSingleProductResponse GetEGiftCatalogItem(EGiftSingleProductRequest request)
        {
            var catalogResponse = GetProduct(request);
            return catalogResponse;
        }

        public EGiftDeleteResponse DeleteEGift(EGiftDeleteRequest request)
        {

            var url = $"{_egiftUrl}/egiftmanagement/programs/{request.ProgramCode}/account/{request.AccountIdentifier}/egift/{request.EGiftId}";

            var response = _serviceInvokerProvider.GetWebResponse<EGiftDeleteResponse>(url, "DELETE", null);
            if (response.EGift != null && response.ResponseHeader.StatusCode == 0)
            {
                #region Publish Notification

                string programCode = request.ProgramCode;
                CnNotificationType notificationType = CnNotificationType.RewardsMarketPlaceToSenderDelete;

                string balance = "-1";
                if (response.EGift?.MaxBalanceCheckAllowed > 0)
                {
                    balance = response.EGift?.Balance.ToString("0.00");
                }
                var notifyAccount = _accountRepository.GetAccountPrimaryConsumerProfile(
                    AccountIdentifier.FromString(request.AccountIdentifier));
                var attributes = new MessageAttribute[]
                {
                    new MessageAttribute {Name = "FirstName", Value = notifyAccount?.FirstName},
                    new MessageAttribute {Name = "LastName", Value = notifyAccount?.LastName},
                    new MessageAttribute {Name = "Amount", Value = response.EGift?.CardAmount.ToString("0.00")},
                    new MessageAttribute {Name = "Date", Value = DateTime.Today.ToString()},
                    new MessageAttribute {Name = "Note", Value = null},
                    new MessageAttribute {Name = "Type", Value = response.EGift?.BrandName},
                    new MessageAttribute {Name = "Merchant", Value = response.EGift?.BrandName},
                    new MessageAttribute {Name = "CardNumber", Value = response.EGift?.AccountNumber},
                    new MessageAttribute {Name = "Date2", Value = response.EGift?.CreateDate.ToString()},
                    new MessageAttribute {Name = "PIN", Value = response.EGift?.Pin},
                    new MessageAttribute {Name = "Balance", Value = balance},
                };
                SendCnMessageRequest cnRequest = new SendCnMessageRequest
                {
                    RequestHeader = new Shared.Common.Contract.Message.Request.RequestHeader() { RequestId = Guid.NewGuid() },
                    AccountIdentifier = request.AccountIdentifier,
                    NotificationType = (int)notificationType,
                    ProgramCode = programCode,
                    ProductCode = notifyAccount.ProductCode,
                    Attributes = attributes,
                    Contacts = new MessageContact[]
                    {
                        new MessageContact {ChannelType = "1", ContactValue = notifyAccount?.PhoneNumber},
                        new MessageContact {ChannelType = "2", ContactValue = notifyAccount?.Email},
                        new MessageContact {ChannelType = "3", ContactValue = ""},
                    }
                };
                // remove contacts with null or empty values to prevent validation 
                // errors from CN API.
                cnRequest.Contacts = cnRequest.Contacts.Where(x => !string.IsNullOrEmpty(x.ContactValue)).ToArray();

                _priorityNotificationService.PublishPriorityNotification(programCode, cnRequest);

                #endregion
            }

            return response;
        }


        public EGiftGetBalanceResponse GetEGiftBalance(EGiftGetBalanceRequest request)
        {
            var url = $"{_egiftUrl}/egiftmanagement/programs/{request.ProgramCode}/account/{request.AccountIdentifier}/egift/{request.EGiftId}";

            if (request.IncludeDeleted)
                url = $"{url}?includedeleted=true";

            var response = _serviceInvokerProvider.GetWebResponse<EGiftGetBalanceResponse>(url, "GET", null);

            return response;
        }

        public EGiftGetBalanceRefreshResponse GetEGiftBalanceRefresh(EGiftGetBalanceRefreshRequest request)
        {
            var url = $"{_egiftUrl}/egiftmanagement/programs/{request.ProgramCode}/account/{request.AccountIdentifier}/egift/{request.EGiftId}?balancerefresh=true";

            if (request.IncludeDeleted)
                url = $"{url}&includedeleted=true";

            var response = _serviceInvokerProvider.GetWebResponse<EGiftGetBalanceRefreshResponse>(url, "GET", null);

            return response;
        }

        public EGiftUpdateGiftCardBalanceResponse UpdateEGiftBalance(EGiftUpdateGiftCardBalanceRequest request)
        {
            var url = $"{_egiftUrl}/egiftmanagement/programs/{request.ProgramCode}/account/{request.AccountIdentifier}/egift/{request.EGiftId}";

            var response = _serviceInvokerProvider.GetWebResponse<EGiftUpdateGiftCardBalanceRequest, EGiftUpdateGiftCardBalanceResponse>(url, "PATCH", request);

            return response;
        }

        public EGiftGetWalletResponse GetWallet(EGiftGetWalletRequest request)
        {
            var url = $"{_egiftUrl}/egiftmanagement/programs/{request.ProgramCode}/account/{request.AccountIdentifier}/wallet";

            if (request.IncludeDeleted)
                url = $"{url}?includedeleted=true";

            var response = _serviceInvokerProvider.GetWebResponse<EGiftGetWalletResponse>(url, "GET", null);

            return response;
        }

        public EGiftGetPurchaseHistoryResponse GetEGiftPurchaseHistory(EGiftGetPurchaseHistoryRequest request)
        {
            var url = $"{_egiftUrl}/egiftmanagement/programs/{request.ProgramCode}/account/{request.AccountIdentifier}/purchases";

            var response = _serviceInvokerProvider.GetWebResponse<EGiftGetPurchaseHistoryResponse>(url, "GET", null);

            return response;
        }

        private EGiftProductResponse GetProducts(EGiftProductRequest request)
        {
            var url = _egiftUrl + $"/egiftmanagement/catalog";
            var res = GetResponse<EGiftProductRequest, EGiftProductResponse>(request, url, "GET");
            return res;
        }

        private EGiftSingleProductResponse GetProduct(EGiftSingleProductRequest request)
        {
            var url = _egiftUrl + $"/egiftmanagement/product/{request.ProductId}";
            var res = GetResponse<EGiftSingleProductRequest, EGiftSingleProductResponse>
                (request, url, "GET");

            return res;
        }

        private Tout GetResponse<Tin, Tout>(Tin req, string url, string method)
            where Tout : BaseResponse where Tin : BaseRequest
        {
            var res = _serviceInvokerProvider.GetWebResponse<Tout>
                (url, method, null);

            if (res.ResponseHeader == null)
                res.ResponseHeader = new ResponseHeader
                {
                    ResponseId = req.RequestHeader.RequestId,
                    StatusCode = 500,
                    SubStatusCode = 0,
                    Message = "Unknown System Error, EGiftAPI did not return a response header code"
                };
            else
            {
                res.ResponseHeader.ResponseId = req.RequestHeader.RequestId;
            }

            return res;
        }

        public EGiftInitiatePurchaseResponse InitiatePurchaseEGiftRequest(EGiftInitiatePurchaseRequest request)
        {
            if (request.ProgramCode == null)
            {
                _logger.Error($"EGiftInitiatePurchaseRequest programcode is NULL. RequestId:{request.EgiftPurchaseRequest?.RequestHeader?.RequestId} setting it to gbr");
                request.ProgramCode = "gbr";
            }

            var url = $"{_egiftUrl}/egiftmanagement/programs/{request.ProgramCode}/egift/initiateegiftrequest";
            var response = _serviceInvokerProvider.GetWebResponse<EGiftInitiatePurchaseRequest, EGiftInitiatePurchaseResponse>
                (url, "POST", request);

            return response;
        }

        public EGiftPurchaseResponse PurchaseEGift(EGiftPurchaseRequest request)
        {
            GetTimeout("X-GD-Bos-EGift-PurchaseTimeOut", out var requestTimeout);

            var uri = $"{_egiftUrl}/egiftmanagement/programs/{request.ProgramCode}/account/{request.AccountIdentifier}/egift";

            var response = _serviceInvokerProvider.GetWebResponse<EGiftPurchaseRequest, EGiftPurchaseResponse>
                (uri, "POST", request, requestTimeout);

            if (OptionsContext.Current.IsDefined("X-GD-Bos-EGift-PurchaseSuccessTimeOut"))
            {
                if (OptionsContext.Current.GetBoolean("X-GD-Bos-EGift-PurchaseSuccessTimeOut"))
                    throw new TimeoutException();
            }


            return response;
        }

        public EGiftReverseResponse ReverseEGift(EGiftReverseRequest request)
        {
            var url = $"{_egiftUrl}/egiftmanagement/programs/{request.ProgramCode}/account/{request.AccountIdentifier}/egift/{request.RequestId}/reversePurchase";
            var response = _serviceInvokerProvider.GetWebResponse<EGiftReverseRequest, EGiftReverseResponse>
                (url, "POST", request);

            return response;
        }


        EGiftGetLifeTimeRewardsResponse IEGiftService.GetLifeTimeRewards(EGiftGetLifeTimeRewardsRequest request)
        {
            var result = new EGiftGetLifeTimeRewardsResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId
                }
            };


            try
            {
                DateTime startDate = DateTime.MinValue;
                DateTime endDate = DateTime.Now;

                result.TotalRewardsEarned =
                    _egiftRepository.GetTotalRewardsEarnedByAccountIdentifier(request.AccountIdentifier);

                result.ResponseHeader.StatusCode = 0;
                result.ResponseHeader.Message = "Success";
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"Exception thrown while calling GetLifeTimeRewards. RequestId={request.RequestHeader.RequestId}");
                result.ResponseHeader.StatusCode = 5003;
                result.ResponseHeader.Message = $"Exception thrown while calling GetLifeTimeRewards. Message={ex.Message}";
            }

            return result;
        }

        public static decimal GetPercentage(SortedDictionary<DateTime, decimal> percentages, decimal percentage)
        {
            if (percentages == null || !percentages.Any())
                return percentage;

            var ratePair = percentages.LastOrDefault(r => r.Key <= DateTime.Now);

            if (ratePair.Value == 0 && ratePair.Key == DateTime.MinValue)
                return percentage;

            return ratePair.Value;
        }

        private void GetTimeout(string headerName, out int? requestTimeout)
        {
            requestTimeout = null;
            if (OptionsContext.Current.IsDefined(headerName))
            {
                requestTimeout = 1;
                if (int.TryParse(OptionsContext.Current.GetString(headerName), out var rt))
                    requestTimeout = rt;
            }
        }

    }
}
