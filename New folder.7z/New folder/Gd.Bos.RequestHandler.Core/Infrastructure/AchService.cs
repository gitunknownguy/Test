﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.RequestHandler.Core.Domain.Services.Ach;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using NLog;
using RequestHandler.Core.Domain.Services.Ach;
using AchLinkExternalAccountRequest = Gd.Bos.RequestHandler.Core.Domain.Services.Ach.AchLinkExternalAccountRequest;
using GetAchDeliveryDateRequest = Gd.Bos.RequestHandler.Core.Domain.Services.Ach.GetAchDeliveryDateRequest;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class AchService : IAchService
    {
        public AchService(IServiceInvokeProvider serviceInvokeProvider)
        {
            _serviceInvokeProvider = serviceInvokeProvider;
            _baseUrl = Configuration.Configuration.Current.AchBaseUrl;
            _baseExternalAccountManagementUrl = Configuration.Configuration.Current.ExternalAccountManagementBaseUrl;

        }

        public AchTransferResponse Transfer(AchTransferRequest request)
        {
            int? requestTimeout = null;
            GetTimeout("X-GD-Bos-ACH-TransferExecuteTimeOut", out requestTimeout);
            _logger.Info($"calling achService.Transfer. Timeout is {requestTimeout} ms");
            return _serviceInvokeProvider.GetResponseAsync<AchTransferRequest, AchTransferResponse>($"{_baseUrl}{_transferUrl}", "PUT", 
                request, null, requestTimeout).Result;
        }

        public List<GSSTranfer> GetAchTransfers(GetAchTransfersRequest request)
        {
            int? requestTimeout = null;
            GetTimeout("X-GD-Bos-ACH-TransferGetTimeOut", out requestTimeout);

            var queryString = new StringBuilder();
            queryString.AppendFormat("{0}?PartnerID={1}&HostAccountRefID={2}&StartDate={3}&EndDate={4}",
                _getTransfersUrl,
                request.PartnerID,
                request.HostAccountRefID,
                request.StartDate,
                request.EndDate);
            _logger.Info($"calling achService.GetAchTransfers. Timeout is {requestTimeout} ms");
            return _serviceInvokeProvider.GetWebResponseAsync<GetAchTransfersResponse>(_baseUrl + queryString.ToString(), "GET", null, requestTimeout).Result.transfers;
        }

        public CancelACHTransferResponse CancelAchTransfer(CancelAchTransferRequest request)
        {
            int? requestTimeout = null;
            GetTimeout("X-GD-Bos-ACH-TransferCancelTimeOut", out requestTimeout);

            _logger.Info($"calling achService.CancelAchTransfer. Timeout is {requestTimeout} ms");
            return _serviceInvokeProvider.GetResponseAsync<CancelAchTransferRequest, CancelACHTransferResponse>(_baseUrl + _cancelTransfersUrl, "POST", request, null, requestTimeout).Result;
        }

        public AchLinkExternalAccountResponse AchLinkExternalAccount(AchLinkExternalAccountRequest achLinkExternalAccountRequest)
        {
            var isFinicity = achLinkExternalAccountRequest.SelectedBankAccounts.Any(b=>b.ExternalAccountProvider == ExternalAccountProviderType.Finicity);
            var url = _baseExternalAccountManagementUrl;
            if (isFinicity)
                url += GetFinicityAchLinkUrl(achLinkExternalAccountRequest.ProgramCode, achLinkExternalAccountRequest.AccountReferenceId);
            else
                url += GetAchLinkUrl(achLinkExternalAccountRequest.ProgramCode,achLinkExternalAccountRequest.AccountReferenceId);

            return _serviceInvokeProvider.GetResponseAsync<AchLinkExternalAccountRequest, AchLinkExternalAccountResponse>(url ,"POST", 
                achLinkExternalAccountRequest, null).Result;
        }


        public GetExternalBankAccountDetailResponse GetExternalBankAccountDetailAsync(string partnerReferenceId, string accountReferenceId, string externalAccountReferenceId, DeviceType? deviceType, bool externalCheck = true)
        {
            int? requestTimeout = null;
            GetTimeout("X-GD-Bos-ACH-GetExternalAccountDetailAsyncTimeOut", out requestTimeout);

            _logger.Info($"calling achService.GetExternalAccountDetail. Timeout is {requestTimeout} ms");
            return _serviceInvokeProvider.GetWebResponseAsync<GetExternalBankAccountDetailResponse>(
                _baseExternalAccountManagementUrl + GetExternalAccountDetailUrl(partnerReferenceId, accountReferenceId, 
                externalAccountReferenceId, deviceType, externalCheck), "GET", null, requestTimeout).Result;
        }

        /// <summary>
        /// Fix GBOS-62060
        /// </summary>
        /// <param name="partnerReferenceId"></param>
        /// <param name="accountReferenceId"></param>
        /// <returns>AccountList from EAM</returns>
        public GetExternalBankAccountsResponse GetExternalBankAccounts(string partnerReferenceId, string accountReferenceId)
        {
            int? requestTimeout = null;
            GetTimeout("X-GD-Bos-ACH-GetExternalAccountsTimeOut", out requestTimeout);

            _logger.Info($"calling achService.GetExternalBankAccounts. Timeout is {requestTimeout} ms");
            return _serviceInvokeProvider.GetWebResponseAsync<GetExternalBankAccountsResponse>(
                _baseExternalAccountManagementUrl + GetExternalBankAccountsUrl(partnerReferenceId, accountReferenceId), "GET", null, requestTimeout).Result;
        }

        public GSSGetBankResponse GetBankName(string routingNumber)
        {
            GetTimeout("X-GD-Bos-ACH-GetBankByRoutingNumberTimeOut", out var requestTimeout);

            StringBuilder queryString = new StringBuilder();
            queryString.AppendFormat("{0}?routingNumber={1}", _getBankNameUrl, routingNumber);
            _logger.Info($"calling achService.GetBankByRoutingNumber. Timeout is {requestTimeout} ms");
            return _serviceInvokeProvider.GetWebResponseAsync<GSSGetBankResponse>(_baseUrl + queryString, "GET", null, requestTimeout).Result;
        }

        public GetAchDeliveryDateResponse GetAchDeliveryDate(GetAchDeliveryDateRequest request)
        {
            int? requestTimeout = null;
            GetTimeout("X-GD-Bos-ACH-GetDeliveryDateTimeOut", out requestTimeout);

            StringBuilder queryString = new StringBuilder();
            queryString.AppendFormat("{0}?PartnerID={1}&TransferType={2}&ScheduleDate={3}&DeliveryType={4}",
                _getDeliveryDateUrl,
                request.PartnerID,
                request.TransferType,
                HttpUtility.UrlDecode(request.ScheduleDate),
                request.ACHDeliveryType);
            _logger.Info($"calling achService.GetDeliveryDate. Timeout is {requestTimeout} ms");
            return _serviceInvokeProvider.GetWebResponseAsync<GetAchDeliveryDateResponse>(_baseUrl + queryString.ToString(), "GET", null, requestTimeout).Result;
        }

        private string GetAchLinkUrl(string partnerreferenceid, string accountReferenceId) => $"/partner/{partnerreferenceid}/account/{accountReferenceId}/externalbankaccount";
        private string GetFinicityAchLinkUrl(string partnerreferenceid, string accountReferenceId) => $"/partner/{partnerreferenceid}/account/{accountReferenceId}/linkfinicityexternalbankaccount";

        private string GetExternalAccountDetailUrl(string partnerReferenceId, string accountReferenceId,
            string externalAccountReferenceId, DeviceType? deviceType, bool externalCheck = true)
        {
            string url =
                $"/partner/{partnerReferenceId}/account/{accountReferenceId}/externalaccount/{externalAccountReferenceId}/externalbankaccountdetail";

            if (null != deviceType)
            {
                url += $"?deviceType={deviceType.ToString()}";
                url += (externalCheck ? "" : "&externalCheck=false");
            }
            else
            {
                url += (externalCheck ? "" : "?externalCheck=false");

            }
            return url;
        }

        /// <summary>
        /// Fix GBOS-62060
        /// </summary>
        /// <param name="partnerReferenceId"></param>
        /// <param name="accountReferenceId"></param>
        /// <returns></returns>
        private string GetExternalBankAccountsUrl(string partnerReferenceId, string accountReferenceId) => $"/partner/{partnerReferenceId}/account/{accountReferenceId}/externalbankaccounts";

        private void GetTimeout(string headerName, out int? requestTimeout)
        {
            requestTimeout = null;
            if (OptionsContext.Current.IsDefined(headerName))
            {
                requestTimeout = 1;
                if (int.TryParse(OptionsContext.Current.GetString(headerName), out var rt))
                    requestTimeout = rt;
            }
        }
        CreateACHLinkTokenResponse IAchService.CreateExternalBankAccountLinkToken(string PartnerId, string AccountId, CreateACHLinkTokenRequest createACHLinkTokenRequest)
        {
            //https://gssmmssvc.dev.nextestate.com/externalaccountmanagement/v1/partner/asdfasdf/account/78dd4335-74cb-40d7-8b84-e9901c225662/token/create
            int? requestTimeout = null;
            GetTimeout("X-GD-Bos-NewExternalAccountLinkTokenTimeOut", out requestTimeout);

            _logger.Info($"calling achService.CreateExternalBankAccountLinkTokenTimeOut. Timeout is {requestTimeout} ms");
            StringBuilder queryString = new StringBuilder();
            queryString.AppendFormat(_createLinkTokenUrl, PartnerId, AccountId);

            return _serviceInvokeProvider.GetResponseAsync<CreateACHLinkTokenRequest, CreateACHLinkTokenResponse>(
                _baseExternalAccountManagementUrl + queryString, "POST", createACHLinkTokenRequest, null, requestTimeout).Result;
        }

        public CreateACHLinkTokenResponse GenerateConnectUrl(string PartnerId, string AccountId,
            GenerateConnectUrlRequest generateConnectUrlRequest)
        {
            int? requestTimeout = null;
            GetTimeout("X-GD-Bos-NewExternalAccountLinkTokenTimeOut", out requestTimeout);

            _logger.Info($"calling achService.GenerateConnectUrl. Timeout is {requestTimeout} ms");
            StringBuilder queryString = new StringBuilder();
            queryString.AppendFormat(_generateConnectUrlTokenUrl, PartnerId, AccountId);

            return _serviceInvokeProvider.GetResponseAsync<GenerateConnectUrlRequest, CreateACHLinkTokenResponse>(
                _baseExternalAccountManagementUrl + queryString, "POST", generateConnectUrlRequest, null, requestTimeout).Result;

        }

        private readonly IServiceInvokeProvider _serviceInvokeProvider;
        private readonly string _baseUrl;
        private readonly string _baseExternalAccountManagementUrl;
        private const string _transferUrl = "/transfer";
        private const string _getTransfersUrl = "/TransferByAccountIdentifier";
        private const string _getBankNameUrl = "/Wire";
        private const string _cancelTransfersUrl = "/CancelACHTransfer";
        private const string _getDeliveryDateUrl = "/DeliveryDate";
        private const string _createLinkTokenUrl = "/partner/{0}/account/{1}/token/create";
        private const string _generateConnectUrlTokenUrl = "/partner/{0}/account/{1}/connect/generate";
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();
    }
}
