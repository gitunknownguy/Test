﻿using System;
using System.Linq;
using Gd.Bos.RequestHandler.Core.Domain.Services.LoanManagement;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.LoanManagement;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.LoanManagement;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using NLog;
using RequestHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.RequestHeader;

namespace RequestHandler.Core.Infrastructure
{
    public class LoanManagementService : ILoanManagementService
    {
        public LoanManagementService(IServiceInvokeProvider serviceInvokeProvider, ITokenizerService tokenizerService, IRequestHandlerSettings settings)
        {
            _serviceInvokeProvider = serviceInvokeProvider;
            _tokenizerService = tokenizerService;
            _loanManagementBaseUrl = Gd.Bos.RequestHandler.Core.Infrastructure.Configuration.Configuration.Current.LoanManagementUrl;
        }

        private readonly IServiceInvokeProvider _serviceInvokeProvider;
        private readonly ITokenizerService _tokenizerService;
        private readonly string _loanManagementBaseUrl;
        private const string _updateAccountUrl = "programs/{0}/accounts/{1}";
        private const string _createAccountUrl = "programs/{0}/accounts/{1}";
        private const string _updateCreditLimitUrl = "programs/{0}/accounts/{1}/creditlimit";
        private const string _updateAccountStatusUrl = "programs/{0}/accounts/{1}/accountStatus";
        private const string _getStatementHistoryUrl = "programs/{0}/accounts/{1}/startyears/{2}/startmonths/{3}/endyears/{4}/endmonths/{5}/statementHistory";

        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();

        public void UpdateCreditLimit(string accountIdentifier, string programCode, decimal amount)
        {
            GetTimeout("X-GD-Bos-Alchemy-UpdateCreditLimit-TimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            if (OptionsContext.Current.IsDefined("X-GD-Bos-Alchemy-UpdateCreditLimit"))
                throw new LoanManagementRetryableException(4, 809, "LMS did not return success for UpdateCreditLimit");

            if (OptionsContext.Current.IsDefined("X-GD-Bos-Alchemy-UpdateCreditLimit-Ignore"))
                return;


            string url = String.Format(_updateCreditLimitUrl, programCode, accountIdentifier);
            UpdateCreditLimitRequest request =
                new UpdateCreditLimitRequest
                {
                    ProgramCode = programCode,
                    //CreditLimit is int while amount is decimal so dropping cents part.
                    CreditLimit = decimal.ToInt32(amount),
                    RequestHeader = new RequestHeader { RequestId = reqId }
                };

            var response = GetWebResponseTrapLMSException<UpdateCreditLimitRequest, UpdateCreditLimitResponse>(
                        _loanManagementBaseUrl + url, "PUT", request, requestTimeout);

            if (response == null)
                throw new LoanManagementRetryableException(4, 809, $"A downstream provider did not return a recognizable response for {url}.");

            if (response.ResponseHeader.StatusCode != 0)
                throw new LoanManagementRetryableException(4, 809,
                    $"A downstream provider did not return success for UpdateCreditLimit: StatusCode:{response.ResponseHeader.StatusCode} ," +
                    $"SubStatusCode:{response.ResponseHeader.SubStatusCode}, " +
                    $"Message: {response.ResponseHeader.Message};");
        }

        public UpdateLoanManagementAccountResponse UpdateAccount(string accountIdentifier, string programCode,
                                                                UpdateLoanManagementAccountRequest loanManagementAccountRequest)
        {
            GetTimeout("X-GD-Bos-LoanManagement-UpdateAccount", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            loanManagementAccountRequest.RequestHeader = new RequestHeader()
            {
                RequestId = reqId
            };

            if (OptionsContext.Current.IsDefined("X-GD-Bos-LoanManagement-UpdateAccount"))
            {
                throw new LoanManagementException(OptionsContext.Current.GetInt("X-GD-Bos-LoanManagement-UpdateAccount", 0), 0,
                                                    "LoanManagement did not return success for UpdateAccount");
            }

            string url = string.Format(_updateAccountUrl, programCode, accountIdentifier);

            var response = _serviceInvokeProvider.GetWebResponse<UpdateLoanManagementAccountRequest, UpdateLoanManagementAccountResponse>(
                                                        _loanManagementBaseUrl + url, "PUT", loanManagementAccountRequest, requestTimeout);

            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for {url}.");

            if (!new[] { 0, 5200 }.Contains(response.ResponseHeader.StatusCode))
                throw new LoanManagementException(response.ResponseHeader.StatusCode,
                                                    response.ResponseHeader.SubStatusCode,
                                                    $"A downstream provider did not return success for UpdateAccount: Message: {response.ResponseHeader.Message};");

            return response;
        }

        public CreateLoanManagementAccountResponse CreateAccount(string accountIdentifier, string programCode,
                                                                CreateLoanManagementAccountRequest loanManagementAccountRequest)
        {
            GetTimeout("X-GD-Bos-LoanManagement-CreateAccount-Timeout", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            if (OptionsContext.Current.IsDefined("X-GD-Bos-LoanManagement-CreateAccount"))
                throw new LoanManagementRetryableException(4, 809, "LoanManagement did not return success for CreateAccount");

            string url = string.Format(_createAccountUrl, programCode, accountIdentifier);

            loanManagementAccountRequest.RequestHeader = new RequestHeader()
            {
                RequestId = reqId
            };

            var response = GetWebResponseTrapLMSException<CreateLoanManagementAccountRequest, CreateLoanManagementAccountResponse>(
                _loanManagementBaseUrl + url, "POST", loanManagementAccountRequest, requestTimeout);

            if (response == null)
                throw new LoanManagementRetryableException(4, 809, $"A downstream provider did not return a recognizable response for {url}.");

            if (!new[] { 0, 5200 }.Contains(response.ResponseHeader.StatusCode))
                throw new LoanManagementRetryableException(4, 809,
                    $"A downstream provider did not return success for CreateAccount: StatusCode:{response.ResponseHeader.StatusCode}, " +
                    $"SubStatusCode:{response.ResponseHeader.SubStatusCode} " +
                    $"Message: {response.ResponseHeader.Message};");

            return response;
        }

        public UpdateAccountStatusResponse UpdateAccountStatus(string accountIdentifier, string programCode,
                                                               UpdateAccountStatusRequest loanManagementAccountRequest)
        {
            GetTimeout("X-GD-Bos-LoanManagement-UpdateAccountStatusTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var requestId);
            if (requestId == Guid.Empty) requestId = loanManagementAccountRequest?.RequestHeader?.RequestId ?? Guid.NewGuid();
            if (requestId == Guid.Empty) requestId = Guid.NewGuid();

            loanManagementAccountRequest.RequestHeader = new RequestHeader()
            {
                RequestId = requestId
            };

            if (OptionsContext.Current.IsDefined("X-GD-Bos-LoanManagement-UpdateAccountStatusTimeOut"))
            {
                throw new LoanManagementException(OptionsContext.Current.GetInt("X-GD-Bos-LoanManagement-UpdateAccountStatusTimeOut", 0), 0,
                                                    "LoanManagement did not return success for UpdateAccountStatus");
            }

            string url = string.Format(_updateAccountStatusUrl, programCode, accountIdentifier);

            var response = _serviceInvokeProvider.GetWebResponse<UpdateAccountStatusRequest, UpdateAccountStatusResponse>(
                                                        _loanManagementBaseUrl + url, "PUT", loanManagementAccountRequest, requestTimeout);

            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for {url}.");

            if (!new[] { 0, 5200 }.Contains(response.ResponseHeader.StatusCode))
                throw new LoanManagementException(response.ResponseHeader.StatusCode,
                                                    response.ResponseHeader.SubStatusCode,
                                                    $"A downstream provider did not return success for UpdateAccountStatus: Message: {response.ResponseHeader.Message};");

            return response;
        }

        public GetStatementHistoryResponse GetStatementHistory(string accountIdentifier, string programCode,
            GetStatementHistoryRequest getStatementHistoryRequest)
        {
            GetTimeout("X-GD-Bos-LoanManagement-GetStatementHistoryTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var requestId);

            getStatementHistoryRequest.RequestHeader = new RequestHeader()
            {
                RequestId = requestId
            };

            if (OptionsContext.Current.IsDefined("X-GD-Bos-LoanManagement-GetStatementHistoryTimeOut"))
            {
                throw new LoanManagementException(OptionsContext.Current.GetInt("X-GD-Bos-LoanManagement-GetStatementHistoryTimeOut", 0), 0,
                    "LoanManagement did not return success for GetStatementHistory");
            }

            string url = string.Format(_getStatementHistoryUrl, programCode, accountIdentifier,
                getStatementHistoryRequest.StartYear, getStatementHistoryRequest.StartMonth,
                getStatementHistoryRequest.EndYear, getStatementHistoryRequest.EndMonth);

            var response = _serviceInvokeProvider.GetWebResponse<GetStatementHistoryResponse>(
                _loanManagementBaseUrl + url, "GET", null, requestTimeout);

            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for {url}.");

            if (!new[] { 0, 5200 }.Contains(response.ResponseHeader.StatusCode))
                throw new LoanManagementException(response.ResponseHeader.StatusCode,
                    response.ResponseHeader.SubStatusCode,
                    $"A downstream provider did not return success for GetStatementHistory: Message: {response.ResponseHeader.Message};");

            return response;

        }

        private TOut GetWebResponseTrapLMSException<TIn, TOut>(
            string serviceUri,
            string method,
            TIn request,
            int? requestTimeout = null)
        {
            try
            {
                return _serviceInvokeProvider.GetWebResponse<TIn, TOut>(serviceUri, method, request, requestTimeout);
            }
            catch (System.TimeoutException te)
            {
                throw new LoanManagementRetryableException(4, 809, $"Timeout calling external service url: {serviceUri} , method: {method} " +
                                                                   $"Transaction retry processor will pick it up to make it eventual success. " +
                                                                   $"Exception: {te} ");
            }
            catch (System.Exception te)
            {
                throw new LoanManagementRetryableException(4, 809, $"Exception calling external service url: {serviceUri} , method: {method} " +
                                                                   $"Transaction retry processor will pick it up to make it eventual success. " +
                                                                   $"Exception: {te} ");
            }
        }


        private void GetTimeout(string headerName, out int? requestTimeout)
        {
            requestTimeout = null;
            if (OptionsContext.Current.IsDefined(headerName))
            {
                requestTimeout = 1;
                if (int.TryParse(OptionsContext.Current.GetString(headerName), out var rt))
                    requestTimeout = rt;
            }
        }
    }
}
