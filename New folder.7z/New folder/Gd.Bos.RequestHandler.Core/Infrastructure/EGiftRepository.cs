﻿using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.EGift;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers;
using Gd.Bos.Shared.Common;
using Gd.Bos.Shared.Common.Core.Data;
using Microsoft.Data.SqlClient;
using NLog;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using SqlDataRecord = Microsoft.Data.SqlClient.Server.SqlDataRecord;
using SqlMetaData = Microsoft.Data.SqlClient.Server.SqlMetaData;


namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class EGiftRepository : IEGiftRepository
    {
        private readonly IDataAccess _dataAccess;
        private readonly ITransferRepository _transferRepository;
        private readonly IAccountRepository _accountRepository;

        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();

        private static readonly string[] EGiftRewardsTransClassCodes = { "1-028", "2-028", "11-005", "12-005" };
        private readonly ConcurrentDictionary<string, int> _transClassCodeMapping = new ConcurrentDictionary<string, int>();
        private readonly ConcurrentDictionary<int, string> _transClassKeyMapping = new ConcurrentDictionary<int, string>();

        public EGiftRepository(IDataAccess dataAccess, ITransferRepository transferRepository, IAccountRepository accountRepository)
        {
            _dataAccess = dataAccess;
            _transferRepository = transferRepository;
            _accountRepository = accountRepository;
        }

        decimal IEGiftRepository.GetTotalRewardsEarnedByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            var accountInfo = _accountRepository.GetAccountPrimaryConsumerProfile(accountIdentifier);

            return GetTotalMoneySpentOnEGiftPurchase(accountIdentifier, accountInfo.AccountCreateDate, DateTime.Now);
        }

        decimal IEGiftRepository.GetTotalEGiftPurchaseAmountForToday(AccountIdentifier accountIdentifier)
        {
            DateTime start = DateTime.Today;
            DateTime end = start.AddDays(1);
            return GetTotalMoneySpentOnEGiftPurchase(accountIdentifier, start, end, false);
        }


        decimal IEGiftRepository.GetTotalEGiftRecipientAmountReceivedForToday(AccountIdentifier accountIdentifier)
        {
            DateTime start = DateTime.Today;
            DateTime end = start.AddDays(1);

            return GetFundTransferDetailByTransClassAndTargetAccount(accountIdentifier, start, end);
        }

        decimal GetFundTransferDetailByTransClassAndTargetAccount(AccountIdentifier accountIdentifier,
            DateTime startDate, DateTime endDate)
        {
            _logger.Debug($"Calling SP GetFundTransferDetailByTransClassAndTargetAccount with accountIdentifier: {accountIdentifier} startDate: {startDate} endDate: {endDate}");

            var parameters = new[]
            {
                new SqlParameter {ParameterName = "AccountIdentifier", Value = accountIdentifier.ToGuid(), SqlDbType = SqlDbType.UniqueIdentifier},
                new SqlParameter {ParameterName = "StartDate", Value = startDate, SqlDbType = SqlDbType.DateTime},
                new SqlParameter {ParameterName = "EndDate", Value = endDate, SqlDbType = SqlDbType.DateTime },
                new SqlParameter {ParameterName = "TransClassValue", Value = GetEGiftTransClassRows().Convert(), SqlDbType = SqlDbType.Structured, TypeName = "dbo.typeTransClassFundTransferStatus" }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetFundTransferDetailByTransClassAndTargetAccount]", _dataAccess.CreateConnection(), parameters))
            {
                decimal amount = 0;
                while (reader.Read())
                {
                    // "Rewards earned calculation" as defined by https://pd/browse/GBOS-8838
                    // (1-028 + 12-005) - (2-028 + 11-005) 
                    // 1-028 rewards credit from egift purchase
                    // 2-028 refund incase of transaction failure
                    // 11-005 rewards debit (e.g. 10% of 1-028 cashback)
                    // 12-005 rewards debit reversal in case of failure                    
                    var transClassKey = Convert.ToInt32(reader["TransClassKey"]);
                    var transClass = _transClassKeyMapping[transClassKey];
                    var transactionAmount = Convert.ToDecimal(reader["TransactionAmount"]);
                    if (transClass.Equals("1-028"))
                    {
                        amount += transactionAmount;
                    }
                }

                return amount;
            }
        }

        decimal GetTotalMoneySpentOnEGiftPurchase(AccountIdentifier accountIdentifier,
            DateTime startDate, DateTime endDate, bool includeRewardAmount = true)
        {
            _logger.Debug($"Calling SP GetFundTransferDetailByTransClass with accountIdentifier: {accountIdentifier} startDate: {startDate} endDate: {endDate}");

            var parameters = new[]
            {
                new SqlParameter {ParameterName = "AccountIdentifier", Value = accountIdentifier.ToGuid(), SqlDbType = SqlDbType.UniqueIdentifier},
                new SqlParameter {ParameterName = "StartDate", Value = startDate, SqlDbType = SqlDbType.DateTime},
                new SqlParameter {ParameterName = "EndDate", Value = endDate, SqlDbType = SqlDbType.DateTime },
                new SqlParameter {ParameterName = "TransClassValue", Value = GetEGiftTransClassRows().Convert(), SqlDbType = SqlDbType.Structured, TypeName = "dbo.typeTransClassFundTransferStatus" }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetFundTransferDetailByTransClass]", _dataAccess.CreateConnection(), parameters))
            {
                var amount = includeRewardAmount ? AggregatePurchaseAndRewardAmount(reader) : AggregatePurchaseAmount(reader);
                return amount;
            }
        }

        private decimal AggregatePurchaseAndRewardAmount(IDataReader reader)
        {
            decimal amount = 0;
            while (reader.Read())
            {
                //10/16/2019 "Rewards earned calculation" as redefined by https://pd/browse/GBOS-15552 New Version
                //(11-005-12-005)
                // "Rewards earned calculation" as defined by https://pd/browse/GBOS-8838 Older version
                // 1-028 rewards credit from egift purchase
                // 2-028 refund incase of transaction failure
                // 11-005 rewards debit (e.g. 10% of 1-028 cashback)
                // 12-005 rewards debit reversal in case of failure                    
                var transClassKey = Convert.ToInt32(reader["TransClassKey"]);
                var transClass = _transClassKeyMapping[transClassKey];
                var isSourceFlag = Convert.ToBoolean(reader["IsSource"]);
                var transactionAmount = Convert.ToDecimal(reader["TransactionAmount"]);

                switch (transClass)
                {
                    case "12-005": // 96 in dev/qa
                        amount -= transactionAmount;
                        break;
                    case "11-005": // 95 in dev/qa
                        amount += transactionAmount;
                        break;

                    default:
                        break;
                }
            }

            return amount;
        }

        private decimal AggregatePurchaseAmount(IDataReader reader)
        {
            decimal amount = 0;
            while (reader.Read())
            {
                // "Rewards earned calculation" as defined by https://pd/browse/GBOS-8838
                // (1-028 + 12-005) - (2-028 + 11-005) 
                // 1-028 rewards credit from egift purchase
                // 2-028 refund incase of transaction failure
                // 11-005 rewards debit (e.g. 10% of 1-028 cashback)
                // 12-005 rewards debit reversal in case of failure                    
                var transClassKey = Convert.ToInt32(reader["TransClassKey"]);
                var transClass = _transClassKeyMapping[transClassKey];
                var isSourceFlag = Convert.ToBoolean(reader["IsSource"]);
                var transactionAmount = Convert.ToDecimal(reader["TransactionAmount"]);
                switch (transClass)
                {
                    case "1-028": // 93 in dev/qa
                        // note: the egift leg leaves a fund transfer detail with transclass 1-028, but IsSource == 0.
                        // Ignore those records or you'll double the amount earned.
                        if (isSourceFlag)
                            amount += transactionAmount;
                        break;

                    case "2-028": // 94 in dev/qa
                        amount -= transactionAmount;
                        break;

                    default:
                        break;
                }
            }

            return amount;
        }

        /// <summary>
        /// This must run at least once before trying to use _transClassKeyMapping as it will populate it
        /// </summary>
        /// <returns></returns>
        private List<SqlDataRecord> GetEGiftTransClassRows()
        {
            var result = new List<SqlDataRecord>();

            foreach (var transClassCode in EGiftRewardsTransClassCodes)
            {
                int transClassKey;

                if (!_transClassCodeMapping.ContainsKey(transClassCode))
                {
                    // more or less should happen on the first call to populate the mappings
                    transClassKey = _transferRepository.GetTransClassByTransClassCode(transClassCode).TransClassKey;
                    _transClassCodeMapping.TryAdd(transClassCode, transClassKey);
                }
                else
                    transClassKey = _transClassCodeMapping[transClassCode];

                // populate the reverse mapping
                if (!_transClassKeyMapping.ContainsKey(transClassKey))
                    _transClassKeyMapping.TryAdd(transClassKey, transClassCode);

                result.AddRange(GetTransClassRowsByTransClassKey(transClassKey));
            }

            return result;
        }

        private static List<SqlDataRecord> GetTransClassRowsByTransClassKey(int transClassKey)
        {
            var metadata = new SqlMetaData[2];

            metadata[0] = new SqlMetaData("TransClassKey", SqlDbType.Int);
            metadata[1] = new SqlMetaData("FundTransferStatusKey", SqlDbType.SmallInt);

            var records = new List<SqlDataRecord>();

            var rcd = new SqlDataRecord(metadata);
            rcd.SetInt32(0, transClassKey);
            rcd.SetInt16(1, (short)TransferStatus.Completed);
            records.Add(rcd);

            rcd = new SqlDataRecord(metadata);
            rcd.SetInt32(0, transClassKey);
            rcd.SetInt16(1, (short)TransferStatus.Reversed);
            records.Add(rcd);

            return records;
        }
    }
}
