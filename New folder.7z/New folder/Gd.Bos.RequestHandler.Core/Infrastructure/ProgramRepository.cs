﻿using Gd.Bos.Shared.Common.Core.Common.Data;
using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.Shared.Common.Caching;
using Gd.Bos.Shared.Common.Caching.Contract;
using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using Program = Gd.Bos.RequestHandler.Core.Domain.Model.Program;
using RequestHandler.Core.Domain.Model.Product;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class ProgramRepository : IProgramRepository
    {
        public ProgramRepository(IDataAccess dataAccess, ILazyCache lazyCache)
        {
            _dataAccess = dataAccess;
            _lazyCache = lazyCache;
        }
        public Program GetByProgramIdentifier(ProgramCode programCode)
        {
            Func<string, List<Tuple<int, int, string, string, string, string>>> getAllPrograms = key
                => _lazyCache.Get(key, new TimeSpan(0, 2, 0, 0), () => GetAllPrograms());

            var programs = getAllPrograms("PROGRAM_NAMES");
            var program = programs.Find(p => ProgramCode.FromString(p.Item5).Equals(programCode));
            if (program == null)
                throw new ValidationException(1000, 0, $"The program code {programCode} in the API path is unknown.");

            return new Program(programCode, program.Item1, program.Item6);
        }

        public ProgramInfo GetProgramTierInfo(int programKey)
        {
            return _lazyCache.Get("PROGRAM_TIER_" + programKey, new TimeSpan(0, 2, 0, 0), () => GetProgramInfo(programKey));
        }

        private List<Tuple<int, int, string, string, string, string>> GetAllPrograms()
        {
            var returnValue = new List<Tuple<int, int, string, string, string, string>>();
            using (var reader = _dataAccess.ExecuteReader("GetAllProgram", _dataAccess.CreateConnection(), null))
            {
                while (reader.Read())
                {
                    var programKey = reader.GetInt32(0);
                    var brandKey = reader.GetInt32(1);
                    var programName = reader.IsDBNull(reader.GetOrdinal("ProgramName")) ? null : reader.GetString(reader.GetOrdinal("ProgramName"));
                    var programDescription = reader.IsDBNull(reader.GetOrdinal("ProgramDescription")) ? null : reader.GetString(reader.GetOrdinal("ProgramDescription"));
                    var programCode = reader.IsDBNull(reader.GetOrdinal("ProgramCode")) ? null : reader.GetString(reader.GetOrdinal("ProgramCode"));
                    var achPrefix = reader.IsDBNull(reader.GetOrdinal("ACHPrefix")) ? null : reader.GetString(reader.GetOrdinal("ACHPrefix"));

                    returnValue.Add(new Tuple<int, int, string, string, string, string>(programKey, brandKey, programName, programDescription, programCode, achPrefix));
                }
            }

            return returnValue;
        }

        public ProgramInfo GetProgramInfo(int programKey)
        {
            var rs = new ProgramInfo()
            {
                ProductTiers = new List<ProductTierInfo>(),
                ProductmaterialTypes = new List<ProductmaterialType>()
            };
            var parameters = new[] { new SqlParameter() { ParameterName = "ProgramKey", Value = programKey, SqlDbType = SqlDbType.Int } };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetProgramInfo]", _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    if (!reader.IsDBNull((reader.GetOrdinal("productTierclasskey"))))
                    {
                        var item = new ProductTierInfo();
                        item.ProductKey = reader.GetInt32(reader.GetOrdinal("ProductKey"));
                        item.ProductCode = reader.GetString(reader.GetOrdinal("ProductCode"));
                        item.ProductClassKey = reader.GetInt16(reader.GetOrdinal("ProductClassKey"));
                        item.ProductTierKey = reader.GetInt32(reader.GetOrdinal("ProductTierKey"));
                        item.ProductTier = reader.GetString(reader.GetOrdinal("ProductTier"));
                        item.ProductTierClasskey = reader.GetInt16(reader.GetOrdinal("productTierclasskey"));
                        item.IsDefault = reader.GetBoolean(reader.GetOrdinal("IsDefault"));
                        item.ProductTierAttributeKey = reader.GetInt16(reader.GetOrdinal("ProductTierAttributeKey"));
                        item.ProductTierAttribute = reader.GetString(reader.GetOrdinal("ProductTierAttribute"));
                        item.Value = reader.GetString(reader.GetOrdinal("Value"));
                        item.ProcessorKey = reader.GetInt16(reader.GetOrdinal("ProcessorKey"));
                        rs.ProductTiers.Add(item);
                    }
                }

                reader.NextResult();
                while (reader.Read())
                {
                    var item = new ProductmaterialType();

                    item.ProcessorKey = reader.GetInt16(reader.GetOrdinal("ProcessorKey"));
                    item.ProductMaterialType = reader.GetString((reader.GetOrdinal("ProductmaterialType")));
                    item.ProcessorValue = reader.GetString(reader.GetOrdinal("Value"));
                    item.IsDefault = reader["IsDefault"] != DBNull.Value && (bool)reader["IsDefault"];
                    rs.ProductmaterialTypes.Add(item);
                }
            }
            return rs;
        }

        public ProductProgramPartner GetProductProgramPartner(ProgramCode programCode)
        {
            var allProductProgramPartners = _lazyCache.Get("Product_Program_Partner", new TimeSpan(0, 2, 0, 0), GetAllProductProgramPartner);
            return allProductProgramPartners.FirstOrDefault(p => p.ProgramCode.ToLower() == programCode.ToString().ToLower());
        }

        private List<ProductProgramPartner> GetAllProductProgramPartner()
        {
            var returnValue = new List<ProductProgramPartner>();
            using (var reader = _dataAccess.ExecuteReader("GetAllProductProgramBrandPartner", _dataAccess.CreateConnection(), null))
            {
                while (reader.Read())
                {
                    var productKey = (int)reader["ProductKey"];
                    var productName = reader["ProductName"].ToString().ToLower();
                    var productCode = reader["ProductCode"].ToString().ToLower();
                    var programKey = (int)reader["ProgramKey"];
                    var programCode = reader["ProgramCode"].ToString().ToLower();
                    var partnerKey = (short)reader["PartnerKey"];
                    var partnerName = reader["PartnerName"].ToString();

                    returnValue.Add(new ProductProgramPartner()
                    {
                        ProductKey = productKey,
                        ProgramKey = programKey,
                        ProductName = productName,
                        ProgramCode = programCode,
                        PartnerName = partnerName,
                        PartnerKey = partnerKey,
                        ProductCode = productCode,
                    });
                }
            }
            return returnValue;
        }

        public ProductTypeInfo GetProductTypeByProductKey(int productKey)
        {
            var key = $"{nameof(GetProductTypeByProductKey)}_{productKey}";
            return _lazyCache.Get(key, new TimeSpan(0, 1, 0, 0), () => GetProductTypeInfo(productKey));

            ProductTypeInfo GetProductTypeInfo(int productKey)
            {
                var productTypeInfo = new ProductTypeInfo();
                var parameters = new[]
                {
                    new SqlParameter { ParameterName = "ProductKey", Value = productKey }
                };
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetProductTypeByProductKey]",
                           _dataAccess.CreateConnection(), parameters))
                {
                    if (reader.Read())
                    {
                        productTypeInfo.ProductKey = Convert.ToInt32(reader["ProductKey"] == DBNull.Value ? 0 : reader["ProductKey"]);
                        productTypeInfo.ProductTypeKey = reader["ProductTypeKey"] == DBNull.Value ? null : Convert.ToInt16(reader["ProductTypeKey"]);
                        productTypeInfo.ProductType = reader["ProductType"]?.ToString(); 
                    }
                }

                return productTypeInfo;
            }
        }

        private readonly IDataAccess _dataAccess;
        private readonly ILazyCache _lazyCache;
    }
}
