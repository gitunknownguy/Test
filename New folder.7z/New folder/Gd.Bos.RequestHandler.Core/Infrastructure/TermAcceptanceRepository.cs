﻿using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Utils;
using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.Shared.Common.Core.Logic;
using Microsoft.Data.SqlClient;
using NLog;
using RequestHandler.Core.Domain.Model.Account;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    [ExcludeFromCodeCoverage(Justification = "Performance improvement")]
    public class TermAcceptanceRepository : ITermsAcceptanceRepository
    {
        private readonly IDataAccess _dataAccess;
        private readonly string _userName = IdentityHelper.GetIdentityName();
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();
        public TermAcceptanceRepository(IDataAccess dataAccess)
        {
            _dataAccess = dataAccess;
        }

        public async Task<bool> UpdateTermAcceptance(TermAcceptance termAcceptance)
        {
            // TODO: maybe make it so that it accepts a List and do a batch command?
            var termAcceptanceParams = new[] {
                            new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                            new SqlParameter {ParameterName = "AccountHolderAgreementKey", Value = termAcceptance.AccountHolderAgreementKey },
                            new SqlParameter {ParameterName = "AcceptanceDate", Value = termAcceptance.AcceptanceDate},
                            new SqlParameter {ParameterName = "HasAccepted", Value = termAcceptance.OptoutDate == null},
                            new SqlParameter {ParameterName = "OptOutDate", Value = termAcceptance.OptoutDate}
                        };

            await _dataAccess.ExecuteScalarAsync(
                "[dbo].[UpdAccountHolderAgreement]",
                CommandType.StoredProcedure,
                _dataAccess.CreateConnection(),
                CancellationToken.None,
                termAcceptanceParams);

            return true;
        }

        public async Task<bool> InsertTermAcceptance(TermAcceptance termAcceptance)
        {
            var termsParams = new[]
                          {
                            new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                            new SqlParameter
                            {
                                ParameterName = "AccountHolderKey",
                                Value = termAcceptance.AccountHolderKey
                            },
                            new SqlParameter
                            {
                                ParameterName = "ProductAgreementTypeKey",
                                Value = termAcceptance.ProductAgreementTypeKey
                            },
                            new SqlParameter {ParameterName = "AcceptanceDate", Value = termAcceptance.AcceptanceDate},
                            new SqlParameter {ParameterName = "HasAccepted", Value = termAcceptance.OptoutDate == null},
                            new SqlParameter {ParameterName = "OptOutDate", Value = termAcceptance.OptoutDate}

                        };
            await _dataAccess.ExecuteNonQueryAsync("[dbo].[InsAccountHolderAgreement]",
                CommandType.StoredProcedure,
                _dataAccess.CreateConnection(),
                CancellationToken.None,
                termsParams);
            return true;
        }

        /// <summary>
        /// Ge TermAcceptance history item list
        /// </summary>
        /// <param name="accountHolderIdentifier"></param>
        /// <param name="brandAgreementTypeKey"></param>
        /// <returns></returns>
        public IEnumerable<TermAcceptanceHistoryItem> GetTermAcceptanceHistoryList(string accountHolderIdentifier, int brandAgreementTypeKey)
        {
            var dataTable = _dataAccess.GetRecords("[dbo].[GetTermAcceptanceHistoryList]", CommandType.StoredProcedure,
                   _dataAccess.CreateConnection(),
                   new SqlParameter("@accountHolderIdentifier", accountHolderIdentifier),
                   new SqlParameter("@brandAgreementTypeKey", brandAgreementTypeKey)
                   );
            foreach (DataRow dtRow in dataTable.Rows)
            {
                yield return new TermAcceptanceHistoryItem
                {
                    AccountHolderIdentifier = dtRow["AccountHolderIdentifier"].ToString(),
                    AcceptanceDate = dtRow["AcceptanceDate"].ConvertTo<DateTime>(),
                    OptOutDate = dtRow["OptOutDate"]?.ConvertTo<DateTime?>(),
                };
            }
        }
    }
}
