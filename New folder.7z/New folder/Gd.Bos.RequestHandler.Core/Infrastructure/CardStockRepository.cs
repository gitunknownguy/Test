﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using NLog;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;
using Gd.Bos.Shared.Common.Core.Logic;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Caching;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class CardStockRepository : ICardStockRepository
    {
        private readonly IDataAccess _dataAccess;
        private readonly ILazyCache _lazyCache;

        public CardStockRepository(IDataAccess dataAccess, ILazyCache lazyCache)
        {
            _dataAccess = dataAccess;
            _lazyCache = lazyCache;
        }

        public List<CardStockDefinitionInfo> GetAllCardStocks()
        {
            Func<string, List<CardStockDefinitionInfo>> getAllCardStockDefinitions = key =>
                _lazyCache.Get(key, new TimeSpan(0, 2, 0, 0, 0), () => GetAllCardStockDefinitions());
            List<CardStockDefinitionInfo> allCardStocks = getAllCardStockDefinitions("ALL_CARD_STOCK");
            return allCardStocks;
        }

        private List<CardStockDefinitionInfo> GetAllCardStockDefinitions()
        {
            List<CardStockDefinitionInfo> allCardStocks = new List<CardStockDefinitionInfo>();

            using (var reader = _dataAccess.ExecuteReader("[dbo].GetAllCardStockDefinition", _dataAccess.CreateConnection()))
            {
                while (reader.Read())
                {
                    CardStockDefinitionInfo cardStockDefinition = new CardStockDefinitionInfo();

                    cardStockDefinition.CardStockDefinitionKey = reader["CardStockDefinitionKey"].Cast<int>();
                    cardStockDefinition.Value = reader["Value"].Cast<string>();
                    cardStockDefinition.ProcessorKey = reader["ProcessorKey"].Cast<short>();
                    cardStockDefinition.ProductMaterialTypeKey = reader["ProductmaterialTypeKey"].Cast<short>();
                    cardStockDefinition.PackId = reader["PackID"].Cast<string>();
                    cardStockDefinition.ProductMaterialType = reader["ProductmaterialType"].Cast<string>();
                    cardStockDefinition.ProductKey = reader["ProductKey"].Cast<int>();
                    cardStockDefinition.ProductName = reader["ProductName"].Cast<string>();
                    cardStockDefinition.ProductCode = reader["ProductCode"].Cast<string>();
                    cardStockDefinition.BinProductKey = reader["BINProductKey"].Cast<int>();
                    cardStockDefinition.BinKey = reader["BINKey"].Cast<short>();
                    cardStockDefinition.Bin = reader["BIN"].Cast<string>();

                    allCardStocks.Add(cardStockDefinition);
                }
            }

            return allCardStocks;
        }
    }
}
