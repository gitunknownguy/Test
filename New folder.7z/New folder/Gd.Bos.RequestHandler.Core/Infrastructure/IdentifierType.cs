﻿namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public enum IdentifierType
    {
        AccountIdentifier = 1,
        AccountBalanceIdentifier = 2,
        ExternalAccountNumberRoutingNumber = 3,
        RetailSale = 4,
        Adjustment = 5,
        AccountExternalPaymentIdentifier = 6,
        ExternalPaymentIdentifier = 7,
        EGiftAccountIdentifier = 8,
        FeatureTxnIdentifier = 9,
        AccountHolderIdentifier = 10
    }
}
