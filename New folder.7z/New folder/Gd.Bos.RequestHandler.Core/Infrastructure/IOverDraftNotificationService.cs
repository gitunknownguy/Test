﻿using Gd.Bos.RequestHandler.Core.Domain.Model.OverDraft;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public interface IOverDraftNotificationService
    {
        Task PublishNotification(OverDraftMessageRequest request);
    }
}
