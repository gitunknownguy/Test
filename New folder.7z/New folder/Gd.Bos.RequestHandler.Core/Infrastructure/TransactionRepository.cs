﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.AccountTransaction;
using Gd.Bos.RequestHandler.Core.Domain.Model.OverDraft;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transactions;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers;
using Gd.Bos.Shared.Common;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.Shared.Common.Core.Logic;
using Gd.Bos.Shared.Common.Core.Logic.AdjustedBalance.Contract;
using Gd.Bos.Shared.Common.Messaging.ProcessorEventSchema.Translation.Model;
using Gd.Bos.Shared.Common.Overdraft.Enum;
using Microsoft.Data.SqlClient;
using Microsoft.Data.SqlClient.Server;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using NLog;
using RequestHandler.Core.Domain.Model.CurrecyCode;
using RequestHandler.Core.Domain.Model.Interest;
using RequestHandler.Core.Domain.Model.MerchantCategoryCode;
using RequestHandler.Core.Domain.Model.PublishNotification;
using RequestHandler.Core.Domain.Model.Transactions;
using RequestHandler.Core.Infrastructure.Configuration;
using RequestHandler.Core.Utils;
using BankAccount = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.BankAccount;
using Fee = RequestHandler.Core.Domain.Model.PublishNotification.Fee;
using FundTransferType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.FundTransferType;
using Purse = RequestHandler.Core.Domain.Model.PublishNotification.Purse;
using RetailSaleData = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.RetailSaleData;
using TransClass = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.TransClass;

namespace RequestHandler.Core.Infrastructure
{
    [ExcludeFromCodeCoverage(Justification = "Will cover with GBOS-116633")]
    public class TransactionsRepository : ITransactionsRepository
    {
        private const string ATM_WITHDRAWAL = "13-002";
        private static readonly Logger _logger = LogManager.GetCurrentClassLogger();

        private readonly IMemoryCache _cache;
        private const string CacheKey = "TransClassesCacheKey";
        private const string GetTransClassMappingForAllProcessorSP = "[dbo].[GetTransClassMappingForAllProcessor]";
        private readonly TransactionRepositorySettings _settings;

        public TransactionsRepository(
            IDataAccess dataAccess, 
            ITransClassMappingProvider transClassMappingProvider, 
            IAccountRepository accountRepository,
            ICurrencyCodeProvider currencyCodeProvider, 
            IMerchantCategoryCodeProvider merchantCategoryCodeProvider, 
            IBalanceProvider balanceProvider,
            IAccountBalanceRepository accountBalanceRepository,
            IAccountTransactionRepository accountTransactionRepository,
            IMemoryCache cache,
            IOptions<TransactionRepositorySettings> settings)
        {
            _dataAccess = dataAccess;
            _currencyCodeProvider = currencyCodeProvider;
            _merchantCategoryCodeProvider = merchantCategoryCodeProvider;
            _balanceProvider = balanceProvider;
            _accountRepository = accountRepository;
            _transClassMappingProvider = transClassMappingProvider;
            _accountBalanceRepository = accountBalanceRepository;
            _accountTransactionRepository = accountTransactionRepository;
            _cache = cache;
            _settings = settings.Value;
        }
        public void InsertPostInternalTransactionDetail(TransactionReferenceId transactionReferenceId, string description, string achCategoryCode = null)
        {
            _logger.Info("Executing SP InsPostInternalTransactionDetail with transactionReferenceId {0}, description {1} and achCategoryCode {2}",
                transactionReferenceId,
                description,
                achCategoryCode);

            var connection = _dataAccess.CreateConnection();
            var parameters = new[]
            {
                new SqlParameter() {ParameterName = "tablePostInternalTransactionDetail" ,
                    Value = CreatePostInternalTransactionDetailRecord(transactionReferenceId, description, achCategoryCode).Convert(),
                    SqlDbType = SqlDbType.Structured , TypeName = "dbo.typePostInternalTransactionDetail"}, 
            };
            try
            {
                _dataAccess.ExecuteNonQuery("InsPostInternalTransactionDetail", connection, parameters);
            }
            finally
            {
                connection.Close();
            }
        }

        public void InsertPostInternalTransactionDetailV3(TransactionReferenceId transactionReferenceId, string description, string achCategoryCode = null, Guid linkedTransactionIdentifier = default, string transactionIdentifierSource = null)
        {
            var connection = _dataAccess.CreateConnection();
            var paramaters = new[]
            {
                new SqlParameter() {ParameterName = "tablePostInternalTransactionDetail" ,
                    Value = CreatePostInternalPurseTransactionDetailRecord(transactionReferenceId, description, achCategoryCode, null, Identifier.FromGuid(linkedTransactionIdentifier), transactionIdentifierSource).Convert(),
                    SqlDbType = SqlDbType.Structured , TypeName = "dbo.typePostInternalTransactionDetailV3"},
            };
            try
            {
                _dataAccess.ExecuteNonQuery("InsPostInternalTransactionDetailV3", connection, paramaters);
            }
            finally
            {
                connection.Close();
            }
        }

        public List<decimal> GetPostInternalTransactionsAmount(Guid accountIdentifier, int transClassKey, DateTime startDate, DateTime endDate, Guid? accountBalanceIdentifier = null, List<string> achCategoryCodes = null)
        {
            var result = new List<decimal>();
            var parameters = new[]
                {
                new SqlParameter() { ParameterName = "AccountIdentifier", SqlDbType = SqlDbType.UniqueIdentifier, Value = accountIdentifier },
                new SqlParameter() { ParameterName = "TransClassKey", SqlDbType = SqlDbType.Int, Value = transClassKey },
                new SqlParameter() { ParameterName = "StartDate", SqlDbType = SqlDbType.DateTime2, Value = LocalToCentralStandardTime(startDate) },
                new SqlParameter() { ParameterName = "EndDate", SqlDbType = SqlDbType.DateTime2, Value = LocalToCentralStandardTime(endDate)},
                new SqlParameter() { ParameterName = "AccountBalanceIdentifier", SqlDbType = SqlDbType.UniqueIdentifier, Value = accountBalanceIdentifier }
            };


            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetPostInternalTransactionByAccountIdentifier]",
                _dataAccess.CreateConnection(), parameters))
            {
                if (achCategoryCodes == null)
                {
                    while (reader.Read())
                    {
                        result.Add(Cast<decimal>(reader["TransactionAmount"]));
                    }
                }
                else
                {
                    while (reader.Read())
                    {
                        if (achCategoryCodes.Where(ach => ach.ToUpper().Trim().Equals(reader["AchCategoryCode"]?.ToString().ToUpper().Trim())).FirstOrDefault() != null)
                            result.Add(Cast<decimal>(reader["TransactionAmount"]));
                    }
                }
            }

            return result;
        }

        public List<PostedInterestFee> GetPostInterestFees(Guid accountIdentifier, Guid accountBalanceIdentifier, int transClassKey, DateTime start, DateTime end)
        {
            var dt = new DataTable();
            dt.Columns.Add("StatusKey", typeof(short));
            dt.Rows.Add((short)PurseStatus.Active);
            dt.Rows.Add((short)PurseStatus.Closed);

            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "AccountIdentifier", SqlDbType = SqlDbType.UniqueIdentifier, Value = accountIdentifier },
                new SqlParameter() { ParameterName = "TransClassKey", SqlDbType = SqlDbType.Int, Value = transClassKey },
                new SqlParameter() { ParameterName = "StartDate", SqlDbType = SqlDbType.DateTime2, Value = start },
                new SqlParameter() { ParameterName = "EndDate", SqlDbType = SqlDbType.DateTime2, Value = end },
                new SqlParameter() { ParameterName = "AccountBalanceIdentifier", SqlDbType = SqlDbType.UniqueIdentifier, Value = accountBalanceIdentifier },
                new SqlParameter() { ParameterName = "AccountBalanceStatusKeys", SqlDbType = SqlDbType.Structured, Value = dt, TypeName = "[dbo].[typeStatusKey]" }
            };


            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountTransactionByAccountIdentifierDateRangeStatusKeys]",
                _dataAccess.CreateConnection(), parameters))
            {
                var result = ReadPostedInterestFees(reader);

                Logger.Info(
                    $"Call GetAccountTransactionByAccountIdentifierDateRangeStatusKeys with parameters: {accountIdentifier}, {accountBalanceIdentifier}, {transClassKey}, {start}, {end}, return {result.Count} rows");
                return result;
            }


        }

        private List<PostedInterestFee> ReadPostedInterestFees(IDataReader reader)
        {
            var result = new List<PostedInterestFee>();
            while (reader.Read())
            {
                var interest = new PostedInterestFee
                {
                    AccountTransactionKey = Cast<long>(reader["AccountTransactionKey"]),
                    AccountBalanceIdentifier = Cast<Guid>(reader["AccountBalanceIdentifier"]),
                    AccountBalanceKey = Cast<long>(reader["AccountBalanceKey"]),
                    AccountBalanceTypeKey = Cast<short>(reader["AccountBalanceTypeKey"]),
                    AccountKey = Cast<long>(reader["AccountKey"]),
                    Amount = Cast<decimal>(reader["Amount"]),
                    TransactionDate = Cast<DateTime>(reader["TransactionDate"]),
                    TransClassKey = Cast<int>(reader["TransClassKey"])
                };

                result.Add(interest);


            }
            return result;
        }


        public List<SccStatementSummary> GetSccStatementSummary(Guid accountIdentifier)
        {
            var statementSummaries = new List<SccStatementSummary>();
            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "AccountIdentifier", SqlDbType = SqlDbType.UniqueIdentifier, Value = accountIdentifier },
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetStatementSummaryByAccountIdentifier]",
               _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    var postRow = new SccStatementSummary();
                    postRow.AccountIdentifier = accountIdentifier;
                    postRow.AccountKey = reader.GetInt64(reader.GetOrdinal("AccountKey"));
                    postRow.StatementBalance = reader.GetDecimal(reader.GetOrdinal("StatementBalance"));
                    postRow.StatementMinimumPayment = reader.GetDecimal(reader.GetOrdinal("StatementMinimumPayment"));
                    postRow.CalculatedMinimumPayment = reader["CalculatedMinimumPayment"] == DBNull.Value ? default(decimal?) : reader.GetDecimal(reader.GetOrdinal("CalculatedMinimumPayment"));
                    postRow.StatementDate = reader.GetDateTime(reader.GetOrdinal("StatementDate"));
                    postRow.PaymentDueDate = reader.GetDateTime(reader.GetOrdinal("PaymentDueDate"));
                    postRow.ProductCode = reader.GetString(reader.GetOrdinal("ProductCode"));
                    postRow.DaysDelinquent = reader["DaysDelinquent"] == DBNull.Value ? 0 : reader.GetInt16(reader.GetOrdinal("DaysDelinquent"));
                    if (reader["TotalPastDue"] != DBNull.Value)
                        postRow.TotalPastDue = reader.GetDecimal(reader.GetOrdinal("TotalPastDue"));
                    statementSummaries.Add(postRow);
                }
            }

            return statementSummaries.OrderByDescending(a => a.StatementDate).ToList();
        }

        public List<SccStatementSummary> GetSccStatementSummariesByAccountIdentifier(Guid accountIdentifier)
        {
            var statementSummaries = new List<SccStatementSummary>();
            DateTime endDate = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Now, "Central Standard Time");
            DateTime startDate = endDate.AddYears(-1);

            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "AccountIdentifier", SqlDbType = SqlDbType.UniqueIdentifier, Value = accountIdentifier },
                new SqlParameter() { ParameterName = "StartDate", SqlDbType = SqlDbType.DateTime2, Value = startDate },
                new SqlParameter() { ParameterName = "EndDate", SqlDbType = SqlDbType.DateTime2, Value = endDate },
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetStatementSummariesByAccountIdentifier]",
               _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    var postRow = new SccStatementSummary();
                    postRow.AccountIdentifier = accountIdentifier;
                    postRow.AccountKey = reader.GetInt64(reader.GetOrdinal("AccountKey"));
                    postRow.StatementBalance = reader.GetDecimal(reader.GetOrdinal("StatementBalance"));
                    postRow.StatementMinimumPayment = reader.GetDecimal(reader.GetOrdinal("StatementMinimumPayment"));
                    postRow.CalculatedMinimumPayment = reader["CalculatedMinimumPayment"] == DBNull.Value ? default(decimal?) : reader.GetDecimal(reader.GetOrdinal("CalculatedMinimumPayment"));
                    postRow.StatementDate = reader.GetDateTime(reader.GetOrdinal("StatementDate"));
                    postRow.PaymentDueDate = reader.GetDateTime(reader.GetOrdinal("PaymentDueDate"));
                    postRow.ProductCode = reader.GetString(reader.GetOrdinal("ProductCode"));
                    postRow.DaysDelinquent = reader["DaysDelinquent"] == DBNull.Value ? 0 : reader.GetInt16(reader.GetOrdinal("DaysDelinquent"));
                    if (reader["TotalPastDue"] != DBNull.Value)
                        postRow.TotalPastDue = reader.GetDecimal(reader.GetOrdinal("TotalPastDue"));
                    statementSummaries.Add(postRow);
                }
            }

            return statementSummaries.OrderByDescending(a => a.StatementDate).ToList();
        }

        public List<ODFeeEligibleTransactionModel> GetOverdraftFeeAuthorizeTransactionsByAccountIdentifier
                                                        (string accountIdentifier, DateTime startDate, DateTime endDateTime)
        {
            List<ODFeeEligibleTransactionModel> list = new List<ODFeeEligibleTransactionModel>();

            SqlParameter[] parameters = new[]
            {
                new SqlParameter() {ParameterName = "AccountIdentifier", Value = Guid.Parse(accountIdentifier)},
                new SqlParameter() {ParameterName = "StartDate", Value = startDate, SqlDbType = SqlDbType.DateTime2},
                new SqlParameter() {ParameterName = "EndDate", Value = endDateTime, SqlDbType = SqlDbType.DateTime2},
                new SqlParameter()
                    {
                        ParameterName = "OverdraftFeeAuthStatuses",
                        Value = CreateOverdraftFeeAuthStatusKey().Convert(),
                        SqlDbType = SqlDbType.Structured, TypeName = "dbo.typeStatusKey"
                    }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetOverdraftFeeAuthorizeTransactionsByAccountIdentifier]",
                                                            _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {

                    var postRow = new ODFeeEligibleTransactionModel()
                    {
                        TransactionIdentifier = reader.GetGuid(reader.GetOrdinal("TransactionIdentifier")),
                        TransactionDate = reader.GetDateTime(reader.GetOrdinal("ProcessorTransactionDate")),
                        GracePeriodStartDate = reader.GetDateTime(reader.GetOrdinal("GracePeriodDate")),
                        ProductKey = reader.GetInt32(reader.GetOrdinal("ProductKey")),
                        ProductTierKey = reader.GetInt32(reader.GetOrdinal("ProductTierKey")),
                        OverDraftTier = reader["ODTier"] == DBNull.Value ? OverDraftTier.None
                                        : (OverDraftTier)Enum.Parse(typeof(OverDraftTier), reader["ODTier"].ToString())
                    };

                    list.Add(postRow);
                }
            }
            return list;
        }


        /// <summary>
        /// Get accountTransaction.AccountTransactionToken based on PostInternalTransactionIdentifier.
        /// </summary>
        /// <param name="transactionIdentifier">Post internal transaction identifier</param>
        /// <returns></returns>
        public Guid? GetAccountTransactionToken(Guid transactionIdentifier)
        {
            Guid? accountTransactionToken = null;

            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "TransactionIdentifier",Value = transactionIdentifier }
            };
            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountTransactionByTransactionIdentifier]", _dataAccess.CreateConnection(), parameters))
            {
                if (reader.Read())
                {
                    if (reader["AccountTransactionToken"] != DBNull.Value)
                        accountTransactionToken = (Guid)reader["AccountTransactionToken"];
                }
                return accountTransactionToken;
            }
        }

        private static T Cast<T>(object value)
        {
            if (value == DBNull.Value || value == null)
                return default(T);

            return (T)value;
        }

        private DateTime LocalToCentralStandardTime(DateTime time)
        {
            return TimeZoneInfo.ConvertTime(time, _cst);
        }

        private readonly TimeZoneInfo _cst = TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time");

        private List<SqlDataRecord> CreatePostInternalTransactionDetailRecord(TransactionReferenceId transactionReferenceId, string description, string achCategoryCode = null)
        {
            List<SqlDataRecord> returnValue = new List<SqlDataRecord>();

            SqlDataRecord record = new SqlDataRecord(CreateTypePostInternalTransactionDetailMetadata());

            record.SetGuid(0, transactionReferenceId.ToGuid());
            record.SetString(1, description);
            if (achCategoryCode != null)
                record.SetString(2, achCategoryCode);

            returnValue.Add(record);
            return returnValue;
        }

        private List<SqlDataRecord> CreatePostInternalPurseTransactionDetailRecord(TransactionReferenceId transactionReferenceId, string description,
            string achCategoryCode = null, string CoID = null, Identifier TransactionIdentifier = null, string transactionIdentifierSource = null)
        {
            List<SqlDataRecord> returnValue = new List<SqlDataRecord>();

            SqlDataRecord record = new SqlDataRecord(CreateTypePostInternalPurseTransactionDetailMetadata());

            record.SetGuid(0, transactionReferenceId.ToGuid());

            if(description != null)
                record.SetString(1, description);

            if (achCategoryCode != null)
                record.SetString(2, achCategoryCode);

            if (CoID != null)
                record.SetString(3, CoID);

            if (TransactionIdentifier != null)
                record.SetGuid(4, TransactionIdentifier.ToGuid());

            if (transactionIdentifierSource != null)
                record.SetString(5, transactionIdentifierSource);

            returnValue.Add(record);
            return returnValue;
        }

        private static SqlMetaData[] CreateTypePostInternalTransactionDetailMetadata()
        {
            SqlMetaData[] metadata = new SqlMetaData[3];

            metadata[0] = new SqlMetaData("TransactionReferenceID", SqlDbType.UniqueIdentifier);
            metadata[1] = new SqlMetaData("TransactionDescription", SqlDbType.NVarChar, 120);
            metadata[2] = new SqlMetaData("AchCategoryCode", SqlDbType.VarChar, 5);

            return metadata;
        }

        private static SqlMetaData[] CreateTypePostInternalPurseTransactionDetailMetadata()
        {
            SqlMetaData[] metadata = new SqlMetaData[6];

            metadata[0] = new SqlMetaData("TransactionReferenceID", SqlDbType.UniqueIdentifier);
            metadata[1] = new SqlMetaData("TransactionDescription", SqlDbType.NVarChar, 120);
            metadata[2] = new SqlMetaData("AchCategoryCode", SqlDbType.VarChar, 5);
            metadata[3] = new SqlMetaData("CoID", SqlDbType.VarChar, 10);
            metadata[4] = new SqlMetaData("TransactionIdentifier", SqlDbType.UniqueIdentifier);
            metadata[5] = new SqlMetaData("TransactionIdentifierSource", SqlDbType.NChar, 2);

            return metadata;
        }

        private List<SqlDataRecord> CreateOverdraftFeeAuthStatusKey()
        {
            List<SqlDataRecord> returnValue = new List<SqlDataRecord>();
            SqlMetaData[] metadata = new SqlMetaData[1];

            metadata[0] = new SqlMetaData("StatusKey", SqlDbType.SmallInt);

            SqlDataRecord record = new SqlDataRecord(metadata);
            record.SetInt16(0, (short)OverdraftFeeAuthStatus.ODEligible);
            returnValue.Add(record);

            SqlDataRecord record1 = new SqlDataRecord(metadata);
            record1.SetInt16(0, (short)OverdraftFeeAuthStatus.ODImmediate);
            returnValue.Add(record1);

            return returnValue;
        }

        private DateTimeOffset ParseDateTimeForTimeZone(string dateTime)
        {
            DateTimeOffset dateTimeOffset = DateTimeOffset.Parse(dateTime, CultureInfo.InvariantCulture);
            TimeSpan utcOffset = TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time").GetUtcOffset(dateTimeOffset.DateTime);
            return new DateTimeOffset(dateTimeOffset.DateTime, utcOffset);
        }

        private Domain.Model.PublishNotification.Transaction ReadPostTransaction(IDataReader reader)
        {
            var bin = reader["BIN"].ToString();
            var last4Pan = reader["Last4PAN"].ToString();
            var paymentIdentifier = reader["PaymentIdentifier"].ToString();
            var transactionIdentifier = reader["TransactionIdentifier"].ToString();

            var transactionAmount = GetTransactionAmount(reader);

            var creditDebit = IsCredit(reader);

            var currencyCode = _currencyCodeProvider.GetCurrencyCodeByNumericCode(reader["CurrencyCode"].ToString())?.CountryCode ?? "";

            var transactionDate = string.IsNullOrEmpty(reader["TransactionDate"].ToString()) ? DateTime.MinValue : ParseDateTimeForTimeZone(reader["TransactionDate"].ToString());

            var processorTransactionDate = string.IsNullOrEmpty(reader["ProcessorTransactionDate"].ToString()) ? DateTime.MinValue : ParseDateTimeForTimeZone(reader["ProcessorTransactionDate"].ToString());
            DateTimeOffset? authProcessorTransactionDate = string.IsNullOrEmpty(reader["AuthProcessorTransactionDate"].ToString()) ? DateTime.MinValue : ParseDateTimeForTimeZone(reader["AuthProcessorTransactionDate"].ToString());
            var cardAcceptorMerchantName = reader["CardAcceptorMerchantName"].ToString();

            var cardAcceptorCity = GetCardAcceptorCity(reader);
            var cardAcceptorState = GetCardAcceptorState(reader);
            

            var mccCategoryCode = reader["MerchantCategoryCode"].ToString();

            var cashBackAmount = GetCashBackAmount(reader);

            var authMessageHashId = reader["AuthorizeMessageHashID"].ConvertTo<byte[]>();

            var parentTransactionIdentifier = GetParentTransactionIdentifier(authMessageHashId);

            var transClassKey = string.IsNullOrEmpty(reader["TransClassKey"].ToString()) ? (short)0 : Convert.ToInt16(reader["TransClassKey"]);
            var processorKey = string.IsNullOrEmpty(reader["ProcessorKey"].ToString()) ? (short)0 : Convert.ToInt16(reader["ProcessorKey"]);
            
            var transClass = GetTransClass(processorKey, transClassKey);

            var accountIdentifier = reader["AccountIdentifier"].ToString();
            transClass = FilterTransClass(transClass, accountIdentifier);
            var transactionTypeDescription = string.IsNullOrEmpty(transClass.FriendlyDescription) ? transClass.TransClassDescription : transClass.FriendlyDescription;
            
            if (transClass.TransactionCategory.Contains("adjustment")) 
            { 
                transactionTypeDescription = "Adjustment"; 
            }
                
            else if (transClass.TransactionCategory.Contains("fee")) 
            { 
                transactionTypeDescription = "Fee";  
            }
                
            var merchantCategory = _merchantCategoryCodeProvider.GetMerchantCategoryCode(mccCategoryCode);
            
            if (authProcessorTransactionDate == DateTime.MinValue) 
            { 
                authProcessorTransactionDate = null; 
            }
                
            var approvalCode = reader["ApprovalCode"].ToString();
            var accountBalanceIdentifier = reader["AccountBalanceIdentifier"].ToString();

            var multiClearingCount = Convert.ToInt32(reader["MultiClearingCount"].ToString());
            var multiClearingSeqNum = Convert.ToInt32(reader["MultiClearingSeqNumber"].ToString());

            var transaction = new Domain.Model.PublishNotification.Transaction
            {
                TransactionIdentifier = transactionIdentifier,
                ParentTransactionIdentifier = parentTransactionIdentifier,
                TransactionType = transClass.TransactionCategory,
                TransactionTypeDescription = transactionTypeDescription,
                TransactionStatus = transClass.IsReversal ? TransactionStatus.reversed.ToString() : TransactionStatus.completed.ToString(),
                AccountIdentifier = accountIdentifier,
                PaymentIdentifier = paymentIdentifier,
                Bin = bin?.Trim(),
                Last4Pan = last4Pan,
                AccountCurrency = currencyCode,
                PostedDateTime = processorTransactionDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
                TransactionAmount = transactionAmount,
                Fee = null,
                IsCredit = creditDebit,
                IsMultiClearing = multiClearingCount != multiClearingSeqNum,
                Purses = GetPursesRequest(accountBalanceIdentifier),
                NetworkTransactionData = new NetworkTransactionData
                {
                    AuthorizationDateTime = authProcessorTransactionDate?.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
                    CashBackAmount = cashBackAmount,
                    CardAcceptor = new Domain.Model.PublishNotification.CardAcceptor
                    {
                        MerchantName = cardAcceptorMerchantName,
                        MerchantIndustryCode = merchantCategory.MerchantCode,
                        MerchantIndustryCategory = merchantCategory.MerchantCategory,
                        City = cardAcceptorCity,
                        StateProvReg = cardAcceptorState,
                        MerchantIndustryDescription = merchantCategory.MccDescription
                    },
                    PostTransactionData = new PostTransactionData
                    {
                        ApprovalCode = approvalCode,
                        LocalDateTime = transactionDate.ToString("yyyy-MM-ddTHH:mm:ss.fff"),
                        PostingDateTime = processorTransactionDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
                    }
                }
            };

            SetTransactionFields(transClass.TransClassName, transaction);

            return transaction;
        }

        private static decimal GetTransactionAmount(IDataReader reader) =>
            string.IsNullOrEmpty(reader["TransactionAmount"].ToString()) ? 0 : Convert.ToDecimal(reader["TransactionAmount"]);

        private static bool IsCredit(IDataReader reader) =>
            !string.IsNullOrEmpty(reader["CreditDebit"].ToString()) && Convert.ToInt32(reader["CreditDebit"]) == 1;

        private static string GetCardAcceptorCity(IDataReader reader)
        {
            var cardAcceptorCity = reader["CardAcceptorCity"].ToString().Trim();
            return string.IsNullOrEmpty(cardAcceptorCity) ? null : cardAcceptorCity;
        }

        private static string GetCardAcceptorState(IDataReader reader)
        {
            var cardAcceptorState = reader["CardAcceptorStateProvReg"].ToString().Trim();
            return string.IsNullOrEmpty(cardAcceptorState) ? null : cardAcceptorState;
        }

        private static decimal? GetCashBackAmount(IDataReader reader) =>
            string.IsNullOrEmpty(reader["CashBackAmount"].ToString()) ? 0 : Convert.ToDecimal(reader["CashBackAmount"].ToString());

        private static string GetParentTransactionIdentifier(byte[] authMessageHashId) =>
            string.IsNullOrEmpty(authMessageHashId?.ToString()) ? null : Convert.ToString(ByteArrayConverter.GenerateGuidFromMessageHash(authMessageHashId));

        private Domain.Model.PublishNotification.Transaction ReadPostInternalTransaction(IDataReader reader)
        {
            var isFullDescription = true;
            string feeDescription;
            var transactionIdentifier = reader["TransactionIdentifier"].ToString();
            var processorKey = string.IsNullOrEmpty(reader["ProcessorKey"].ToString()) ? (short)0 : Convert.ToInt16(reader["ProcessorKey"]);
            var accountIdentifier = reader["AccountIdentifier"].ToString();
            var accountBalanceIdentifier = reader["AccountBalanceIdentifier"].ToString();
            var transactionDescription = feeDescription = reader["FullDescription"] is DBNull || string.IsNullOrEmpty(reader["FullDescription"].ToString()) ? "" : reader["FullDescription"].ToString();

            if (string.IsNullOrEmpty(transactionDescription))
            {
                transactionDescription = reader["TransactionDescription"].ToString();
                isFullDescription = false;
            }

            var description = string.IsNullOrEmpty(reader["TransactionDescription"].ToString()) ? null : reader["TransactionDescription"].ToString();
            if (!string.IsNullOrEmpty(description) && description.Contains(","))
                description = description.Substring(description.IndexOf(",", StringComparison.Ordinal) + 1);

            var transactionAmount = string.IsNullOrEmpty(reader["TransactionAmount"].ToString()) ? 0 : Convert.ToDecimal(reader["TransactionAmount"]);
            var creditDebit = !string.IsNullOrEmpty(reader["CreditDebit"].ToString()) && Convert.ToInt32(reader["CreditDebit"]) == 1;
            var currencyCode = _currencyCodeProvider.GetCurrencyCodeByNumericCode(reader["CurrencyCode"].ToString())?.CountryCode ?? "";
            var transClassKey = string.IsNullOrEmpty(reader["TransClassKey"].ToString()) ? (short)0 : Convert.ToInt16(reader["TransClassKey"]);
            var processorTransactionDate = string.IsNullOrEmpty(reader["ProcessorTransactionDate"].ToString()) ? DateTime.MinValue : ParseDateTimeForTimeZone(reader["ProcessorTransactionDate"].ToString());
            var fundTransferToken = reader["FundTransferToken"] is DBNull ? null : reader["FundTransferToken"].ToString();
            var fundTransferKey = reader["FundTransferKey"] is DBNull ? 0 : Convert.ToInt64(reader["FundTransferKey"]);
            var achCategoryCode = reader["AchCategoryCode"].ToString();

            var transactionClass = GetTransClass(processorKey, transClassKey);
            transactionClass = FilterTransClass(transactionClass, accountIdentifier);

            if (transactionClass.TransactionCategory.Contains("achIn") && string.IsNullOrEmpty(achCategoryCode))
                achCategoryCode = "uk";

            var fundTransferType = (FundTransferType)(reader["FundTransferTypeKey"] is DBNull ? 0 : Convert.ToInt32(reader["FundTransferTypeKey"]));

            BankAccount bankAccount = null;
            RetailSaleData retailSaleData = null;

            var authMessageHashId = reader["MessageHashID"].ConvertTo<byte[]>();
            var parentTransactionIdentifier = string.IsNullOrEmpty(authMessageHashId?.ToString()) ? null : Convert.ToString(ByteArrayConverter.GenerateGuidFromMessageHash(authMessageHashId));

            var transactionTypeDescription = string.IsNullOrEmpty(transactionClass.FriendlyDescription) ? transactionClass.TransClassDescription : transactionClass.FriendlyDescription;

            if (transactionClass.TransactionCategory.Contains("adjustment"))
            {
                transactionTypeDescription = "Adjustment";

            }
            else if (transactionClass.TransactionCategory.Contains("fee")) 
            {
                transactionTypeDescription = "Fee";
            }

            if (fundTransferType == FundTransferType.ECashLoad) 
            {
                transactionTypeDescription = FundTransferType.ECashLoad.GetDescription();
            }

            if (!string.IsNullOrEmpty(transactionDescription) && !isFullDescription && transactionDescription.Contains(",")) 
            { 
                transactionDescription = transactionDescription.Substring(transactionDescription.IndexOf(",", StringComparison.Ordinal) + 1); 
            }

            if (transactionClass.TransactionCategory.Contains("achOut") || fundTransferType == FundTransferType.AchPull)
            {
                var bankDetails = GetFundTransferDetail(fundTransferKey);

                if (!string.IsNullOrEmpty(bankDetails))
                {
                    try
                    {
                        bankAccount = JsonConvert.DeserializeObject<BankAccount>(bankDetails);
                        bankAccount.AccountNumber = Mask(bankAccount.AccountNumber);

                        if (!transactionDescription.EndsWith(_customTransactionDescriptionSuffix))
                        {
                            if (!string.IsNullOrEmpty(bankAccount.BusinessName))
                            {
                                transactionDescription = bankAccount.BusinessName + ", " + transactionDescription;
                            }
                            else
                            {
                                transactionDescription = bankAccount.FirstName + " " + bankAccount.LastName + ", " + transactionDescription;
                            }
                        }
                    }
                    catch (Exception)
                    {
                        //probably old record that cannot be json serialized, ignore  
                    }
                }
            }

            if (transactionClass.TransactionCategory.Contains("cashReload") || fundTransferType == FundTransferType.ECashLoad)
            {
                var retailDetails = GetFundTransferDetail(fundTransferKey);

                if (!string.IsNullOrEmpty(retailDetails))
                {
                    try
                    {
                        retailSaleData = JsonConvert.DeserializeObject<RetailSaleData>(retailDetails);
                        if (!transactionDescription.EndsWith(_customTransactionDescriptionSuffix))
                        {
                            transactionDescription = $"{retailSaleData.MerchantName} {retailSaleData.StoreNumber}";
                            if (!string.IsNullOrEmpty(retailSaleData.City) || !string.IsNullOrEmpty(retailSaleData.State))
                                transactionDescription = $"{transactionDescription}, {retailSaleData.City} {retailSaleData.State}";
                        }
                    }
                    catch (Exception)
                    {
                        //probably old record that cannot be json serialized, ignore  
                    }
                }
            }

            var transactionIdentifierCode = reader["TransactionIdentifierCode"] is DBNull
                ? string.Empty
                : reader["TransactionIdentifierCode"].ToString().Trim().ToUpper();

            var isFeeOrAdjustmentCategory =
                (transactionClass.TransactionCategory.Contains("fee") ||
                 transactionClass.TransactionCategory.Contains("adjustment")) && transactionIdentifierCode != "AT";

            var isAdjustmentWithoutDescription = transactionIdentifierCode == "AT" && !isFullDescription;
            if (!transactionDescription.EndsWith(_customTransactionDescriptionSuffix))
            {
                if (isFeeOrAdjustmentCategory || isAdjustmentWithoutDescription)
                {
                    transactionDescription = !string.IsNullOrEmpty(transactionClass.FriendlyDescription) ? transactionClass.FriendlyDescription : transactionClass.TransClassDescription;
                }
            }

            var partnerAdjustmentType = reader["AccountTransactionTypeKey"] == DBNull.Value ? null : (AdjustmentType?)Convert.ToInt32(reader["AccountTransactionTypeKey"]);

            if (transactionDescription.EndsWith(_customTransactionDescriptionSuffix))
            {
                var lastIndexOf = transactionDescription.LastIndexOf(_customTransactionDescriptionSuffix, StringComparison.Ordinal);
                transactionDescription = transactionDescription.Substring(0, lastIndexOf);
            }

            var transaction = new Domain.Model.PublishNotification.Transaction
            {
                TransactionIdentifier = transactionIdentifier,
                ParentTransactionIdentifier = parentTransactionIdentifier,
                TransactionType = transactionClass.TransactionCategory,
                TransactionTypeDescription = transactionTypeDescription,
                Description = description,
                TransactionStatus = transactionClass.IsReversal ? TransactionStatus.reversed.ToString() : TransactionStatus.completed.ToString(),
                AccountIdentifier = accountIdentifier,
                AccountCurrency = currencyCode,
                PostedDateTime = processorTransactionDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
                TransactionAmount = transactionAmount,
                Fee = null,
                IsCredit = creditDebit,
                Purses = GetPursesRequest(accountBalanceIdentifier),
                PostedInternalTransactionData = new PostedInternalTransactionData
                {
                    TransferIdentifier = transactionIdentifierCode == "FT" ? fundTransferToken : null,
                    AdjustmentIdentifier = transactionIdentifierCode == "AT" ? fundTransferToken : null,
                    AdjustmentType = transactionClass.TransactionCategory == "adjustment" ? transactionClass.TransactionSubCategory : null,
                    AchCategoryCode = string.IsNullOrEmpty(achCategoryCode) ? null : achCategoryCode.ToLower().Trim(),
                    Description = transactionDescription,
                    BankData = bankAccount == null
                        ? null
                        : new Domain.Model.PublishNotification.BankData
                        {
                            BankName = bankAccount.BankName,
                            BusinessName = bankAccount.BusinessName,
                            AccountNumber = bankAccount.AccountNumber,
                            RoutingNumber = bankAccount.RoutingNumber,
                            FirstName = bankAccount.FirstName,
                            LastName = bankAccount.LastName,
                            AccountType = bankAccount.AccountType
                        },
                    RetailSaleData = retailSaleData == null
                        ? null
                        : new Domain.Model.PublishNotification.RetailSaleData
                        {
                            City = retailSaleData.City,
                            State = retailSaleData.State,
                            MerchantName = retailSaleData.MerchantName,
                            StoreNumber = retailSaleData.StoreNumber
                        },
                    TransferType = transactionTypeDescription.FirstCharToLowerCase(),
                    PartnerAdjustmentType = string.IsNullOrWhiteSpace(partnerAdjustmentType.ToString()) ? null : partnerAdjustmentType.ToString()
                }
            };
            if (transactionClass.TransactionCategory == "fee")
            {
                transaction.Fee = new List<Fee>
                {
                    new Fee
                    {
                        Amount = transactionAmount,
                        Currency = currencyCode,
                        FeeType = string.IsNullOrEmpty(transactionClass.TransactionSubCategory) ? "otherFee" : transactionClass.TransactionSubCategory,
                        Description = string.IsNullOrEmpty(feeDescription)
                            ? string.IsNullOrEmpty(transactionClass?.FriendlyDescription)
                                ? transactionClass?.TransClassDescription
                                : transactionClass?.FriendlyDescription
                            : feeDescription
                    }
                };
            }

            SetTransactionFields(transactionClass.TransClassName, transaction);
            return transaction;
        }

        public TransClass GetTransClass(short processorKey, short transClassKey)
        {
            var transactionClasses = GetAllTransClasses();
            var transClass = transactionClasses.Find(t => t.TransClassKey == transClassKey && t.ProcessorKey == processorKey);
            
            if (transClass != null)
            {
                return transClass;
            }

            transClass = new TransClass
            {
                ProcessorTranCode = "",
                TransactionCategory = "",
                TransactionSubCategory = "",
                TransClassDescription = "",
                TransClassName = "",
                FriendlyDescription = "",
                TransactionCategoryKey = 0

            };
            Logger.Info($"TransClass for {transClassKey} could not be found in db; Returning empty");
            return transClass;
        }

        public List<TransClass> GetAllTransClasses()
        {
            return _cache.GetOrCreate(CacheKey, entry =>
            {
                _logger.Info("GetAllTransClasses - The cache is empty, getting data from db");

                entry.SetAbsoluteExpiration(TimeSpan.FromMinutes(_settings.TransClassesCacheExpirationInMinutes));

                entry.RegisterPostEvictionCallback((key, value, reason, state) =>
                {
                    _logger.Info($"GetAllTransClasses - Cache entry with key '{key}' was removed. Reason: {reason}");
                });

                var transClasses = new List<TransClass>();

                using (var reader = _dataAccess.ExecuteReader(GetTransClassMappingForAllProcessorSP, _dataAccess.CreateConnection()))
                {
                    while (reader.Read())
                    {

                        transClasses.Add( new TransClass
                        {
                            ProcessorKey = Convert.ToInt16(reader["ProcessorKey"]),
                            TransClassKey = Convert.ToInt16(reader["TransClassKey"]),
                            TransClassName = reader["TransClass"].ToString().Trim(),
                            TransClassDescription = reader["TransClassDescription"].ToString().Trim(),
                            TransactionCategory = reader["TransactionCategory"].ToString().Trim(),
                            TransactionSubCategory = reader["TransactionSubCategory"].ToString().Trim(),
                            ProcessorTranCode = reader["ProcessorTranCode"].ToString().Trim(),
                            IsAdjustable = Convert.ToBoolean(reader["IsAdjustable"]),
                            IsCredit = Convert.ToBoolean(reader["IsCredit"]),
                            IsReversal = Convert.ToBoolean(reader["IsReversal"]),
                            FriendlyDescription = reader["FriendlyDescription"].ToString().Trim(),
                            TransactionCategoryKey = Convert.ToInt16(reader["TransactionCategoryKey"])
                        });
                    }
                }

                _logger.Info("GetAllTransClasses - Cache loaded successfully.");

                return transClasses;
            });
        }

        private void SetTransactionFields(string transClassName, Domain.Model.PublishNotification.Transaction transaction)
        {
            var array = transClassName.Split('-');
            var accountHolderInfos = _accountRepository.GetJointAccountHolderListByAccountIdentifier(new Guid(transaction.AccountIdentifier));
            var isJoinAccount = accountHolderInfos.Count > 1;

            if (array.Length <= 0) 
            {
                return;
            }

            if (!isJoinAccount) 
            {
                return;
            } 

            if (_networkTransClassList.Any(a => a == array[0])) 
            {
                transaction.UserIdentifier = accountHolderInfos.First(a => a.PaymentIdentifier == transaction.PaymentIdentifier).UserIdentifier;
            }
            else
            {
                transaction.UserIdentifier = null;
                transaction.Last4Pan = null;
                transaction.PaymentIdentifier = null;
            }
        }

        public Dictionary<string, List<Domain.Model.PublishNotification.Transaction>> GetFullTransactionByTransactionIdentifier(Guid transactionIdentifier)
        {
            var transactions = new Dictionary<string, List<Domain.Model.PublishNotification.Transaction>>();
            var dtTokens = new DataTable();
            dtTokens.Columns.Add("UniqueID");
            var dr = dtTokens.NewRow();
            dr["UniqueID"] = transactionIdentifier;
            dtTokens.Rows.Add(dr);

            var parameters = new[]
            {
                new SqlParameter
                {
                    ParameterName = "@TransactionIdentifiers", Value = dtTokens, TypeName = "[dbo].[typeUniqueIdentifiers]"
                },
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].GetFullTransactionByTransactionIdentifier", _dataAccess.CreateConnection(), parameters))
            {
                transactions["PostTransaction"] = new List<Domain.Model.PublishNotification.Transaction>();
                while (reader.Read())
                {
                    transactions["PostTransaction"].Add(ReadPostTransaction(reader));
                }

                reader.NextResult();
                transactions["PostInternalTransaction"] = new List<Domain.Model.PublishNotification.Transaction>();
                while (reader.Read())
                {
                    var item = ReadPostInternalTransaction(reader);
                    transactions["PostInternalTransaction"].Add(item);
                }
            }

            return transactions;
        }

        public Domain.Model.PublishNotification.Transaction GetAuthorizeTransactionByTransactionIdentifier(
            AccountIdentifier accountIdentifier,
            Guid transactionIdentifier)
        {
            var parameters = new[]
            {
                new SqlParameter
                {
                    ParameterName = "@AccountIdentifier", Value = accountIdentifier.ToString()
                }
            };

            var authorizeTransaction = new Domain.Model.PublishNotification.Transaction();

            using (var reader = _dataAccess.ExecuteReader("[dbo].GetAuthorizeTransactionByAccountIdentifier", _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    var identifier = reader["TransactionIdentifier"].ToString();

                    if (!string.Equals(identifier, transactionIdentifier.ToString(), StringComparison.CurrentCultureIgnoreCase))
                        continue;

                    authorizeTransaction = ReadAuthTransaction(reader);
                    var processorKey = string.IsNullOrEmpty(reader["ProcessorKey"].ToString())
                        ? (short)0
                        : Convert.ToInt16(reader["ProcessorKey"]);

                    reader.NextResult();

                    while (reader.Read())
                    {
                        ReadFees(reader, authorizeTransaction, processorKey);
                    }
                }
            }

            return authorizeTransaction;
        }
        
        public List<NetworkTransactionDetail> GetNetworkTransactionsByRRNPaymentInstrumentIdentifier(
            string paymentInstrumentIdentifier, string retrievalReferenceNumber, bool isPost = true)
        {
            var parameters = new[]
            {
                new SqlParameter
                {
                    ParameterName = "@PaymentInstrumentIdentifier", Value = paymentInstrumentIdentifier
                },
                new SqlParameter { ParameterName = "@RetrievalReferenceNumber", Value = retrievalReferenceNumber }
            };

            string commentText = isPost ? "[dbo].[GetPostTransactionByPaymentInstrumentIDRetrievalReferenceNum]" : "[dbo].[GetAuthorizeTransactionByPaymentInstrumentIDRetrievalReferenceNum]";

            var networkTransactionDetailList = new List<NetworkTransactionDetail>();

            using var reader = _dataAccess.ExecuteReader(commentText, _dataAccess.CreateConnection(), parameters);
            while (reader.Read())
            {
                var networkTransactionDetail = new NetworkTransactionDetail();
                networkTransactionDetail.PaymentInstrumentIdentifier =
                    Guid.Parse(reader["PaymentInstrumentIdentifier"].ToString() ?? string.Empty);
                networkTransactionDetail.TransactionReferenceNumber = reader["TransactionReferenceNumber"].ToString();
                networkTransactionDetail.RetrievalReferenceNumber = reader["RetrievalReferenceNumber"].ToString();
                networkTransactionDetail.TransactionAmount =
                    string.IsNullOrEmpty(reader["TransactionAmount"].ToString())
                        ? 0
                        : Convert.ToDecimal(reader["TransactionAmount"]);
                networkTransactionDetail.ApprovalCode = reader["ApprovalCode"].ToString()!.TrimEnd();
                networkTransactionDetail.CurrencyCode = reader["CurrencyCode"].ToString();
                networkTransactionDetail.AvailableBalance = string.IsNullOrEmpty(reader["AvailableBalance"].ToString())
                    ? 0
                    : Convert.ToDecimal(reader["AvailableBalance"]);
                networkTransactionDetail.LedgerBalance = string.IsNullOrEmpty(reader["LedgerBalance"].ToString())
                    ? 0
                    : Convert.ToDecimal(reader["LedgerBalance"]);
                networkTransactionDetail.MessageType = reader["MessageType"].ToString()?.TrimEnd().TrimStart();
                networkTransactionDetail.Arn = isPost
                    ? reader["ARN"] == DBNull.Value
                        ? ""
                        : reader["ARN"].ToString()![Math.Max(0, reader["ARN"].ToString()!.Length - 6)..]
                    : "";
                networkTransactionDetail.FalconLastRuleCode = isPost
                    ? "000"
                    : reader["FalconLastRuleCode"] == DBNull.Value
                        ? ""
                        : reader["FalconLastRuleCode"].ToString()!.TrimEnd()[Math.Max(0, reader["FalconLastRuleCode"].ToString()!.TrimEnd().Length - 3)..];
                networkTransactionDetail.CreditDebit = !string.IsNullOrEmpty(reader["CreditDebit"].ToString()) &&
                                                       Convert.ToInt32(reader["CreditDebit"]) == 1;
                networkTransactionDetail.TransactionIdentifier =
                    Guid.Parse(reader["TransactionIdentifier"].ToString() ?? string.Empty);
                networkTransactionDetailList.Add(networkTransactionDetail);
            }

            return networkTransactionDetailList;
        }

        public Dictionary<string, string> GetAuthResponseCodes()
        {
            var actionCodeReasonDic = new Dictionary<string, string>();
            using var reader = _dataAccess.ExecuteReader("[dbo].[GetAuthResponseCode]", _dataAccess.CreateConnection());
            while (reader.Read())
            {
                var authCode = new AuthResponseCode
                {
                    IsoCode = Convert.ToString(reader["AuthResponseISOCode"]),
                    PnResponseCode = Convert.ToString(reader["PNResponseCode"]),
                };

                if (authCode.IsoCode != null && !actionCodeReasonDic.ContainsKey(authCode.IsoCode))
                    actionCodeReasonDic.Add(authCode.IsoCode, authCode.PnResponseCode);
            }
            return actionCodeReasonDic;
        }

        private void ReadFees(IDataRecord reader, Domain.Model.PublishNotification.Transaction transaction, short processorKey)
        {
            var feeAmount = string.IsNullOrEmpty(reader["TransactionAmount"].ToString()) ? 0 : Convert.ToDecimal(reader["TransactionAmount"]);
            var transClassKey = string.IsNullOrEmpty(reader["TransClassKey"].ToString()) ? (short)0 : Convert.ToInt16(reader["TransClassKey"]);
            var transactionClass = _transClassMappingProvider.GetTransClass(processorKey, transClassKey);

            var authFee = new Fee
            {
                FeeType = string.IsNullOrEmpty(transactionClass.TransactionSubCategory) ? "otherFee" : transactionClass.TransactionSubCategory,
                Description = transactionClass.TransClassDescription,
                Amount = feeAmount,
                Currency = transaction.AccountCurrency
            };

            transaction.Fee.Add(authFee);
        }

        private Domain.Model.PublishNotification.Transaction ReadAuthTransaction(IDataReader reader)
        {
            var bin = reader["BIN"].ToString();
            var last4Pan = reader["Last4PAN"].ToString();
            var transactionIdentifier = reader["TransactionIdentifier"].ToString();
            var paymentIdentifier = reader["PaymentIdentifier"].ToString();
            var processorKey = string.IsNullOrEmpty(reader["ProcessorKey"].ToString())
                ? (short)0
                : Convert.ToInt16(reader["ProcessorKey"]);
            var accountIdentifier = reader["AccountIdentifier"].ToString();
            var accountBalanceIdentifier = reader["AccountBalanceIdentifier"].ToString(); //same as purse Id
            var messageHashId = reader["MessageHashID"].ConvertTo<byte[]>();

            var transactionAmount = string.IsNullOrEmpty(reader["TransactionAmount"].ToString())
                ? 0
                : Convert.ToDecimal(reader["TransactionAmount"]);

            transactionAmount = _balanceProvider.GetMultiClearingOutstandingBalance(messageHashId, transactionAmount);

            var creditDebit = !string.IsNullOrEmpty(reader["CreditDebit"].ToString()) &&
                              Convert.ToInt32(reader["CreditDebit"]) == 1;

            var currencyCode = _currencyCodeProvider.GetCurrencyCodeByNumericCode(reader["CurrencyCode"].ToString())
                ?.CountryCode ?? "";

            var transClassKey = string.IsNullOrEmpty(reader["TransClassKey"].ToString())
                ? (short)0
                : Convert.ToInt16(reader["TransClassKey"]);

            var processorTransactionDate = string.IsNullOrEmpty(reader["ProcessorTransactionDate"].ToString())
                ? DateTime.MinValue
                : ParseDateTimeForTimeZone(reader["ProcessorTransactionDate"].ToString());

            var cardAcceptorMerchantName = reader["CardAcceptorName"].ToString();
            var cardAcceptorCity = reader["CardAcceptorCity"].ToString().Trim();

            string description = null;
            if (!string.IsNullOrEmpty(reader["TransactionDescription"].ToString()))
            {
                description = reader["TransactionDescription"].ToString();
            }

            if (string.IsNullOrEmpty(cardAcceptorCity)) cardAcceptorCity = null;

            var cardAcceptorState = reader["CardAcceptorStateProvReg"].ToString().Trim();

            if (string.IsNullOrEmpty(cardAcceptorState)) cardAcceptorState = null;

            var mccCategoryCode = reader["MerchantCategoryCode"].ToString();

            var localTransactionAmount = string.IsNullOrEmpty(reader["LocalTransactionAmount"].ToString())
                ? 0
                : Convert.ToDecimal(reader["LocalTransactionAmount"]);

            var localTransactionAmountCurrency = _currencyCodeProvider.GetCurrencyCodeByNumericCode(
                                                         reader["LocalTransactionAmountCurrencyCode"].ToString())
                                                     ?.CountryCode ??
                                                 "";
            decimal? cashBackAmount = string.IsNullOrEmpty(reader["CashBackAmount"].ToString())
                ? 0
                : Convert.ToDecimal(reader["CashBackAmount"].ToString());

            if (cashBackAmount == 0) cashBackAmount = null;

            var holdExpiryDate = string.IsNullOrEmpty(reader["HoldExpireDate"].ToString())
                ? DateTime.MinValue
                : Convert.ToDateTime(reader["HoldExpireDate"]);

            var authorizationRequestAmount = string.IsNullOrEmpty(reader["AuthorizationRequestAmount"].ToString())
                ? 0
                : Convert.ToDecimal(reader["AuthorizationRequestAmount"]);

            var approvalCode = reader["ApprovalCode"].ToString();

            string authStatusInd = reader["AuthStatusIndicator"].ToString();
            var eciEnum = GetEciEnum(authStatusInd);

            var authMessageHashId = reader["MessageHashID"].ConvertTo<byte[]>();

            var parentTransactionIdentifier = string.IsNullOrEmpty(authMessageHashId?.ToString())
                ? null
                : Convert.ToString(ByteArrayConverter.GenerateGuidFromMessageHash(authMessageHashId));

            var merchantCategory = _merchantCategoryCodeProvider.GetMerchantCategoryCode(mccCategoryCode);
            var transClass = GetTransClass(processorKey, transClassKey);
            transClass = FilterTransClass(transClass, accountIdentifier);

            var transactionTypeDescription = string.IsNullOrEmpty(transClass.FriendlyDescription)
                ? transClass.TransClassDescription
                : transClass.FriendlyDescription;

            if (transClass.TransactionCategory.Contains("adjustment"))
                transactionTypeDescription = "Adjustment";
            else if (transClass.TransactionCategory.Contains("fee"))
                transactionTypeDescription = "Fee";

            var authResponseCodeKey = string.IsNullOrEmpty(reader["AuthResponseCodeKey"].ToString())
                ? 0
                : Convert.ToInt32(reader["AuthResponseCodeKey"].ToString());

            var transaction = new Domain.Model.PublishNotification.Transaction
            {
                ParentTransactionIdentifier = parentTransactionIdentifier,
                PaymentIdentifier = paymentIdentifier,
                TransactionIdentifier = transactionIdentifier,
                TransactionType = transClass.TransactionCategory,
                TransactionStatus = TransactionStatus.pending.ToString(),
                TransactionTypeDescription = transactionTypeDescription,
                Description = description,
                AccountIdentifier = accountIdentifier,
                Bin = bin,
                Last4Pan = last4Pan,
                AccountCurrency = currencyCode,
                PostedDateTime = processorTransactionDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
                StatusChangedTimestamp = processorTransactionDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
                TransactionAmount = transactionAmount,
                IsCredit = creditDebit,
                IsMultiClearing = null,
                Purses = GetPursesRequest(accountBalanceIdentifier),
                Fee = new List<Fee>(),
                NetworkTransactionData = new NetworkTransactionData
                {
                    AuthorizationDateTime = processorTransactionDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
                    CashBackAmount = cashBackAmount,
                    CardAcceptor = new Domain.Model.PublishNotification.CardAcceptor
                    {
                        MerchantName = cardAcceptorMerchantName,
                        MerchantIndustryCode = merchantCategory.MerchantCode,
                        MerchantIndustryCategory = merchantCategory.MerchantCategory,
                        MerchantIndustryDescription = merchantCategory.MccDescription,
                        City = cardAcceptorCity,
                        StateProvReg = cardAcceptorState
                    },
                    LocalTransactionData = null,
                    AuthorizedTransactionData = new AuthorizedTransactionData
                    {
                        HoldExpirationDate = holdExpiryDate.Date.ToString("yyyy-MM-dd"),
                        RequestAuthorizationAmount = authorizationRequestAmount,
                        ApprovalCode = approvalCode,
                        Eci = eciEnum,
                        IsPartialAuth = authResponseCodeKey != 1
                    }
                }
            };

            if (localTransactionAmountCurrency != currencyCode)
            {
                transaction.NetworkTransactionData.LocalTransactionData =
                    new LocalTransactionData
                    {
                        Amount = localTransactionAmount,
                        Currency = localTransactionAmountCurrency
                    };
            }

            return transaction;
        }

        protected static string GetEciEnum(string eCommerceInd)
        {
            var eci = eCommerceInd;
            string eciEnum;
            switch (eci)
            {
                case "1":
                case "01":
                case "4":
                case "04":
                case "5":
                case "05":
                case "6":
                case "06":
                case "7":
                case "07":
                case "8":
                case "08":
                case "9":
                case "09":
                case "A":
                case "B":
                case "C":
                case "D":
                case "E":
                    eciEnum = "eCommerce";
                    break;
                case "2":
                case "02":
                    eciEnum = "recurring";
                    break;
                case "3":
                case "03":
                    eciEnum = "installment";
                    break;
                case "F":
                    eciEnum = "multiClearing";
                    break;
                default:
                    eciEnum = "none";
                    break;
            }
            return eciEnum;
        }

        private List<Purse> GetPursesRequest(string accountBalanceIdentifier)
        {
            var purse = _accountBalanceRepository.GetAccountBalanceByAccountBalanceIdentifier(
                AccountBalanceIdentifier.FromString(accountBalanceIdentifier));

            return purse == null
                ? null
                : new List<Purse>
                {
                    new Purse
                    {
                        PurseIdentifier = purse.AccountBalanceIdentifier.ToString(),
                        PurseType = purse.PurseType.ToString().FirstCharToLowerCase(),
                        AvailableBalance = purse.AvailableBalance,
                        LedgerBalance = purse.CurrentBalance,
                        AvailableBalanceAsOfDateTime = purse.AvailableBalanceAsOfDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
                        LedgerBalanceAsOfDateTime = purse.CurrentBalanceAsOfDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
                    }
                };
        }

        public TransClass FilterTransClass(TransClass transClass, string accountIdentifier)
        {
            if (transClass.TransClassName == ATM_WITHDRAWAL)
            {
                var binType = _accountRepository.GetAccountBinType(accountIdentifier);

                if (binType == Gd.Bos.RequestHandler.Core.Domain.Enums.BinType.Credit)
                {
                    return new TransClass
                    {
                        ProcessorKey = transClass.ProcessorKey,
                        TransClassKey = transClass.TransClassKey,
                        TransClassName = transClass.TransClassName,
                        TransClassDescription = transClass.TransClassDescription,
                        TransactionCategory = transClass.TransactionCategory,
                        TransactionSubCategory = transClass.TransactionSubCategory,
                        ProcessorTranCode = transClass.ProcessorTranCode,
                        IsAdjustable = transClass.IsAdjustable,
                        IsCredit = transClass.IsCredit,
                        IsReversal = transClass.IsReversal,
                        FriendlyDescription = _sccTransactionWithdrawDescription,
                        TransactionCategoryKey = transClass.TransactionCategoryKey
                    };
                }
            }
            return transClass;
        }

        private string GetFundTransferDetail(long fundTransferKey)
        {
            var parameters = new[]
            {
                new SqlParameter {ParameterName = "@FundTransferKey", Value = fundTransferKey}

            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].GetFundTransferDetailByFundTransferKey", _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    if (!(reader["ExternalIdentifier"] is DBNull || string.IsNullOrEmpty(reader["ExternalIdentifier"].ToString())))
                        return reader["ExternalIdentifier"].ToString();
                }
            }

            return string.Empty;
        }

        private string Mask(string baAccountNumber)
        {
            if (string.IsNullOrEmpty(baAccountNumber))
                return string.Empty;
            baAccountNumber = baAccountNumber.Trim();
            var maskedAccount = string.Empty;
            for (var i = 0; i < baAccountNumber.Length - 4; i++)
            {
                maskedAccount += "*";
            }

            return maskedAccount + baAccountNumber.Substring(baAccountNumber.Length - 4);
        }

        FeeValue ITransactionsRepository.GetAccountPreviousMonthFees(Guid accountIdentifier)
        {
            var transactions = new List<Domain.Model.PublishNotification.Transaction>();

            var connection = _dataAccess.CreateConnection();
            var command = connection.CreateCommand();

            DateTime today = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Now, "Central Standard Time");
            DateTime prevMonth = today.AddMonths(-1);
            DateTime startDate = new DateTime(prevMonth.Year, prevMonth.Month, 1);
            DateTime endDate = new DateTime(today.Year, today.Month, 1);

            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.CommandText = "GetFullPostTransactionByAccountIdentifier";

            command.Parameters.Add("@AccountIdentifier", SqlDbType.UniqueIdentifier).Value = accountIdentifier;
            command.Parameters.Add("@BeginProcessorTransactionDate", SqlDbType.DateTime2).Value = startDate;
            command.Parameters.Add("@EndProcessorTransactionDate", SqlDbType.DateTime2).Value = endDate;
            connection.Open();

            try
            {
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        transactions.Add(ReadPostTransaction(reader));
                    }

                    reader.NextResult();

                    while (reader.Read())
                    {
                        transactions.Add(ReadPostInternalTransaction(reader));
                    }
                }
            }
            finally
            {
                connection.Close();
            }

            var fees = transactions.FindAll(t => t.TransactionType == "fee");
            decimal sum = 0;
            foreach (var fee in fees)
            {
                if (fee.IsCredit)
                    sum -= fee.TransactionAmount;
                else
                    sum += fee.TransactionAmount;
            }

            var returnValue = new FeeValue { Amount = sum, StartDate = startDate, EndDate = endDate.AddSeconds(-1) };

            return returnValue;
        }

        public PostInternalTransactionInfo GetPostInternalTransactionByTransactionReferenceID(Guid transactionReferenceID)
        {
            PostInternalTransactionInfo pit = null; 
            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "TransactionReferenceID",Value = transactionReferenceID }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetPostInternalTransactionByTransactionReferenceID]", _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    pit = new PostInternalTransactionInfo()
                    {
                         TransactionIdentifier = (Guid)reader["TransactionIdentifier"],
                         TransactionReferenceID = reader["TransactionReferenceID"] == DBNull.Value? null:(Guid)reader["TransactionReferenceID"]
                    };
                }
                return pit;
            }
        }

        public List<AccountTransaction> GetAccountTransactionListByTransactionToken(Guid transactionReferenceId)
        { 
            return _accountTransactionRepository.GetAccountTransactionListByTransactionToken(transactionReferenceId);
        }

        public void InsertAccountTransaction(AccountTransaction accountTransaction)
        {
            _accountTransactionRepository.InsertAccountTransaction(accountTransaction);
        }

        public bool UpdateAccountTransactionStatus(AccountTransaction accountTransaction)
        {
            return _accountTransactionRepository.UpdateAccountTransactionStatus(accountTransaction);
        }

        private readonly IDataAccess _dataAccess;
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();
        private readonly ITransClassMappingProvider _transClassMappingProvider;
        private readonly ICurrencyCodeProvider _currencyCodeProvider;
        private readonly IMerchantCategoryCodeProvider _merchantCategoryCodeProvider;
        private readonly IAccountRepository _accountRepository;
        private readonly string _customTransactionDescriptionSuffix = "#";
        private readonly string _sccTransactionWithdrawDescription = "ATM Cash Advance Fee";
        private readonly IReadOnlyList<string> _networkTransClassList = new List<string> { "13", "14" };
        private readonly IBalanceProvider _balanceProvider;
        private readonly IAccountBalanceRepository _accountBalanceRepository;
        private readonly IAccountTransactionRepository _accountTransactionRepository;
    }
}
