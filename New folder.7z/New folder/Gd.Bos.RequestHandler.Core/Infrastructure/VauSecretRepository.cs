﻿using System;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Core.Utils;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RequestHandler.Core.Domain.Model.Vau;

namespace RequestHandler.Core.Infrastructure
{
    
    public interface IVauSecretRepository
    {
        VauVault GetVauSecret();
        bool UpdateVauSecret(VauVault vauSecret);
    }
    [ExcludeFromCodeCoverage(Justification = "Covered with functional tests")]
    public class VauSecretRepository(IRequestHandlerSettings requestHandlerSettings) : IVauSecretRepository
    {
        private const string AppName = "RequestHandler";
        private const string AppKey = "VauSecret";
        private readonly string userName = IdentityHelper.GetIdentityName();

        public VauVault GetVauSecret()
        {
            using var dbCommand = new SqlCommand ();
            using (dbCommand.Connection = new SqlConnection(requestHandlerSettings.ConnectionStringsGbosAE))
            {
                dbCommand.CommandText = "[dbo].[GetAppCredential]";
                dbCommand.Connection.Open();
                dbCommand.CommandType = CommandType.StoredProcedure;
                dbCommand.Parameters.AddRange([
                    new SqlParameter
                    {
                        ParameterName = "AppName",
                        SqlDbType = SqlDbType.VarChar,
                        Value = AppName
                    }
                ]);
                using (var reader = dbCommand.ExecuteReader())
                {
                    if (!reader.HasRows) return null;
                    while (reader.Read())
                    {
                        var secretString = reader["AppValue"].ToString();
                        return JsonConvert.DeserializeObject<VauVault>(secretString!);
                    }
                }
            }
            return null;
        }

        public bool UpdateVauSecret(VauVault vauSecret)
        {
            if (vauSecret == null)
            {
                return false;
            }

            using var dbCommand = new SqlCommand();
            using (dbCommand.Connection = new SqlConnection(requestHandlerSettings.ConnectionStringsGbosAE))
            {
                dbCommand.CommandText = "[dbo].[UpdAppCredential]";
                dbCommand.Connection.Open();
                dbCommand.CommandType = CommandType.StoredProcedure;
                dbCommand.Parameters.AddRange([
                new SqlParameter
                {
                    ParameterName = "@pChangeBy",
                    SqlDbType = SqlDbType.NVarChar,
                    Value = userName
                },
                new SqlParameter
                {
                    ParameterName = "@pAppName",
                    SqlDbType = SqlDbType.VarChar,
                    Value = AppName
                },
                new SqlParameter
                {
                    ParameterName = "@pAppKey",
                    SqlDbType = SqlDbType.NVarChar,
                    Value = AppKey // Using AppKey as the key based on SP definition
                },
                new SqlParameter
                {
                    ParameterName = "@pAppValue",
                    SqlDbType = SqlDbType.NVarChar,
                    Value = JsonConvert.SerializeObject(vauSecret)
                },
                new SqlParameter
                {
                    ParameterName = "@pEffectiveDate",
                    SqlDbType = SqlDbType.DateTime,
                    Value = DateTime.Now
                },
                new SqlParameter
                {
                    ParameterName = "@pExpirationDate",
                    SqlDbType = SqlDbType.DateTime,
                    Value = DateTime.Now.AddYears(10) // Setting expiration to 1 year from now
                }
                ]);

                var rowsAffected = dbCommand.ExecuteNonQuery();
                return rowsAffected > 0;
            }
        }
    }
}
