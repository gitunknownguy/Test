﻿using Gd.Bos.RequestHandler.Core.Domain.Services.FinancialDataApi.Enums;
using Gd.Bos.RequestHandler.Core.Domain.Services.FinancialDataApi.Requests;
using Gd.Bos.RequestHandler.Core.Domain.Services.FinancialDataApi.Responses;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Newtonsoft.Json;
using NLog;
using RequestHandler.Core.Domain.Services.Experian;
using System;
using System.Collections.Generic;
using System.Linq;
using RequestHandler.Core.Domain.Services.FinancialDataApi.Responses;
using LogManager = NLog.LogManager;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class FinancialDataService : IFinancialDataService
    {
        private readonly IServiceInvokeProvider _serviceInvokerProvider;
        private readonly string _gssFinancialDataBaseUrl;

        private const string OptInUrl = "/internal/brands/{0}/accounts/{1}/optIn";
        private const string PutPartnerCustomerIdUrl = "/internal/brands/{0}/accounts/{1}/{2}/partnerCustomerId";
        private const string GetPartnerCustomerIdUrl = "/internal/brands/{0}/accounts/{1}/partnerCustomerId";
        private const string FdAccountUrl = "/internal/brands/{0}/accounts/{1}/fdAccount";
        private const string GetCustomerUrl = "/internal/brands/{0}/identityToken/{1}/customer";

        private static readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        private Dictionary<string, string> _options = new Dictionary<string, string>();

        public FinancialDataService(IServiceInvokeProvider serviceInvokeProvider)
        {
            _serviceInvokerProvider = serviceInvokeProvider;
            _gssFinancialDataBaseUrl = Configuration.Configuration.Current.GssFinancialDataApiBaseUrl;
        }

        public UpdateOptInResponse AddUpdateOptIn(UpdateOptInRequest request)
        {
            try
            {
                _options.Clear();
                _options.Add("X-GD-RequestId", request.Header.RequestId);
                _options.Add("Scopes", "GssInternal");

                string serviceUri = string.Format(_gssFinancialDataBaseUrl + OptInUrl, request.BrandId, request.BrandAccountId);

                var response = _serviceInvokerProvider.GetResponse<UpdateOptInRequest, UpdateOptInResponse>
                                                            (serviceUri, "PUT", request, _options);

                ValidateResponse(response, "AddUpdateOptIn");

                return response;
            }
            catch (Exception e)
            {
                _logger.Error(e);
                throw;
            }
        }

        public GetOptInResponse GetOptIn(string requestId, string brandId, string accountIdentifier)
        {
            try
            {
                _options.Clear();
                _options.Add("X-GD-RequestId", requestId);
                _options.Add("Scopes", "GssInternal");

                string serviceUri = string.Format(_gssFinancialDataBaseUrl + OptInUrl, brandId, accountIdentifier);

                var response = _serviceInvokerProvider.GetResponse<GetOptInResponse>(serviceUri, "GET", null, _options);

                if (response == null)
                    throw new Exception($"FinancialDataService did not return a recognizable response for GetOptIn.");

                return response;
            }
            catch (Exception e)
            {
                throw;
            }
        }

        public UpdatePartnerCustomerIdResponse AddUpdatePartnerCustomerId(UpdatePartnerCustomerIdRequest request)
        {
            try
            {
                _options.Clear();
                _options.Add("X-GD-RequestId", request.Header.RequestId);
                _options.Add("Scopes", "GssInternal");

                string serviceUri = string.Format(_gssFinancialDataBaseUrl + PutPartnerCustomerIdUrl, request.BrandId, request.BrandAccountId, request.IsNewExperian);

                var response = _serviceInvokerProvider.GetResponse<UpdatePartnerCustomerIdRequest, UpdatePartnerCustomerIdResponse>
                                                            (serviceUri, "PUT", request, _options);

                ValidateResponse(response, "AddUpdatePartnerCustomerId");

                return response;
            }
            catch (Exception e)
            {
                _logger.Error(e);
                throw;
            }
        }

        public GetPartnerCustomerIdResponse GetPartnerCustomerId(string requestId, string brandId, string accountIdentifier)
        {
            try
            {
                _options.Clear();
                _options.Add("X-GD-RequestId", requestId);
                _options.Add("Scopes", "GssInternal");

                string serviceUri = string.Format(_gssFinancialDataBaseUrl + GetPartnerCustomerIdUrl, brandId, accountIdentifier);

                var response = _serviceInvokerProvider.GetResponse<GetPartnerCustomerIdResponse>
                                                            (serviceUri, "GET", null, _options);

                ValidateResponse(response, "GetPartnerCustomerId");

                return response;
            }
            catch (Exception e)
            {
                _logger.Error(e);
                throw;
            }
        }

        public GetFdAccountResponse GetFdAccount(string requestId, string brandId, string accountIdentifier)
        {
            try
            {
                _options.Clear();
                _options.Add("X-GD-RequestId", requestId);
                _options.Add("Scopes", "GssInternal");

                string serviceUri = string.Format(_gssFinancialDataBaseUrl + FdAccountUrl, brandId, accountIdentifier);

                var response = _serviceInvokerProvider.GetResponse<GetFdAccountResponse>(serviceUri, "GET", null, _options);

                ValidateResponse(response, "GetFdAccount");

                return response;
            }
            catch (Exception e)
            {
                _logger.Error(e);
                throw;
            }
        }

        public GetCustomerResponse GetCustomer(string requestId, string brandId, string identityToken)
        {
            try
            {
                _options.Clear();
                _options.Add("X-GD-RequestId", requestId);
                _options.Add("Scopes", "GssInternal");

                string serviceUri = string.Format(_gssFinancialDataBaseUrl + GetCustomerUrl, brandId, identityToken);

                var response = _serviceInvokerProvider.GetResponse<GetCustomerResponse>(serviceUri, "GET", null, _options);

                if (response == null)
                    throw new Exception($"FinancialDataService did not return a recognizable response for GetCustomer.");

                return response;
            }
            catch (Exception e)
            {
                _logger.Error(e);
                throw;
            }
        }

        private void ValidateResponse<T>(T response, string methodName) where T : ResponseBase
        {
            if (response == null)
                throw new Exception($"FinancialDataService did not return a recognizable response for {methodName}.");

            if (response.ResponseDetails.Any(c => c.Code != StatusCode.Success))
                throw new Exception($"FinancialDataService did not return a recognizable response for {methodName}. Exception: {JsonConvert.SerializeObject(response.ResponseDetails)}");
        }
    }
}
