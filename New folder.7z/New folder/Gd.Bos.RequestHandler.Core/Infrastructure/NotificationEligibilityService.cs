﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using RequestHandler.Core.Application;

namespace RequestHandler.Core.Infrastructure
{
    public class NotificationEligibilityService : INotificationEligibilityService
    {
        private readonly IAccountRepository _accountRepository;
        public NotificationEligibilityService(IAccountRepository accountRepository)
        {
            _accountRepository = accountRepository;
        }

        public bool IsNotificationEligible(Account account)
        {
            bool isEligible = true;
            if (account.AccountStatus == AccountStatus.Locked || account.AccountStatus == AccountStatus.Restricted)
            {
                var accountStatusReasons = _accountRepository.GetActiveAccountStatusReasons(account.AccountIdentifier);
                if (accountStatusReasons.Contains(AccountStatusReason.confirmedIdentityTheft) ||
                    accountStatusReasons.Contains(AccountStatusReason.potentialIdentityTheft))
                {
                    isEligible = false;
                }
            }

            return isEligible;
        }

        public bool IsNotificationEligible(string accountIdentifier)
        {
            Account account =
                _accountRepository.GetAccountInfoByAccountIdentifier(AccountIdentifier.FromString(accountIdentifier));
            return IsNotificationEligible(account);
        }

        public bool IsNotificationEligible(AccountIdentifier accountIdentifier)
        {
            Account account =
                _accountRepository.GetAccountInfoByAccountIdentifier(accountIdentifier);
            return IsNotificationEligible(account);
        }
    }
}
