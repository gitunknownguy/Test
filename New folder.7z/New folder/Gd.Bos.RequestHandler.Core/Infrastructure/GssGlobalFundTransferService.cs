﻿using Gd.Bos.Shared.Common.Core.Contract.Interface;
using NLog;
using RequestHandler.Core.Domain.Services.GlobalFundTransfer;
using RequestHandler.Core.Domain.Services.GlobalFundTransfer.Contracts;
using RequestHandler.Core.Domain.Services.GlobalFundTransfer.Exceptions;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using LogManager = NLog.LogManager;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class GlobalFundTransferService : IGlobalFundTransferService
    {
        private readonly IServiceInvokeProvider _serviceInvokerProvider;
        private readonly string _gssGlobalFundsTransferBaseUrl;

        private const string CreateCustomerProfileUrl = "{0}/programs/{1}/customers";
        private const string UpdateCustomerProfileUrl = "{0}/programs/{1}/customers/{2}";
        private const string GetCustomerProfileUrl = "{0}/programs/{1}/customers/{2}";
        private const string GetCustomerProfileExternalUrl = "{0}/programs/{1}/customers/{2}/links/external";
        private const string LinkCustomerProfileBankUrl = "{0}/programs/{1}/customers/{2}/bankAccounts";
        private const string LinkCustomerProfileCardUrl = "{0}/programs/{1}/customers/{2}/links";
        private const string CreateFundTransferUrl = "{0}/programs/{1}/transfers";
        private const string DeleteBankLinkUrl = "{0}/programs/{1}/customers/{2}/bankAccounts/{3}";
        private const string DeleteCardLinkUrl = "{0}/programs/{1}/customers/{2}/links/{3}";

        private static readonly ILogger _logger = LogManager.GetCurrentClassLogger();

        public GlobalFundTransferService(IServiceInvokeProvider serviceInvokeProvider)
        {
            _serviceInvokerProvider = serviceInvokeProvider;
            _gssGlobalFundsTransferBaseUrl = Configuration.Configuration.Current.GssGlobalFundsTransferBaseUrl;
        }

        public CreateCustomerProfileResponse CreateCustomerProfile(CreateCustomerProfileRequest request)
        {
            try
            {
                var options = new Dictionary<string, string>()
                { 
                    { "requestid",request.RequestId}
                };

                string serviceUri = string.Format(CreateCustomerProfileUrl, _gssGlobalFundsTransferBaseUrl, request.ProgramCode);

                var response = _serviceInvokerProvider.GetResponse<CreateCustomerProfileRequest, CreateCustomerProfileResponse>(serviceUri, "POST", request, options);

                if (response == null || response.ResponseDetails.Count == 0)
                    throw new GlobalFundTransferException("Response is null or details are empty");

                return response;
            }
            catch (Exception e)
            {
                _logger.Error(e);
                throw;
            }
        }

        public UpdateCustomerProfileResponse UpdateCustomerProfile(UpdateCustomerProfileRequest request, string customerToken)
        {
            try
            {
                var options = new Dictionary<string, string>()
                {
                    { "requestid",request.RequestId}
                };

                string serviceUri = string.Format(UpdateCustomerProfileUrl, _gssGlobalFundsTransferBaseUrl, request.ProgramCode, customerToken);

                var response = _serviceInvokerProvider.GetResponse<UpdateCustomerProfileRequest, UpdateCustomerProfileResponse>(serviceUri, "PUT", request, options);

                if (response == null || response.ResponseDetails.Count == 0)
                    throw new GlobalFundTransferException("Response is null or details are empty");

                return response;
            }
            catch (Exception e)
            {
                _logger.Error(e);
                throw;
            }
        }

        public GetCustomerProfileResponse GetCustomerProfile(GetCustomerProfileRequest request, string customerToken)
        {
            try
            {
                var options = new Dictionary<string, string>()
                {
                    { "requestid",request.RequestId}
                };

                string serviceUri = string.Format(GetCustomerProfileUrl, _gssGlobalFundsTransferBaseUrl, request.ProgramCode, customerToken);

                var response = _serviceInvokerProvider.GetResponse<GetCustomerProfileResponse>(serviceUri, "GET", null, options);

                if (response == null || response.ResponseDetails.Count == 0)
                    throw new GlobalFundTransferException("Response is null or details are empty");

                return response;
            }
            catch (Exception e)
            {
                _logger.Error(e);
                throw;
            }
        }

        public LinkCustomerProfileResponse LinkCustomerProfileBank(LinkCustomerProfileBankRequest request)
        {
            try
            {
                var options = new Dictionary<string, string>()
                {
                    { "requestid",request.RequestId}
                };

                string serviceUri = string.Format(LinkCustomerProfileBankUrl, _gssGlobalFundsTransferBaseUrl, request.ProgramCode, request.CustomerToken);

                var response = _serviceInvokerProvider.GetResponse<LinkCustomerProfileBankRequest, LinkCustomerProfileResponse>(serviceUri, "POST", request, options);

                if (response == null || response.ResponseDetails.Count == 0)
                    throw new GlobalFundTransferException("Response is null or details are empty");

                return response;
            }
            catch (Exception e)
            {
                _logger.Error(e);
                throw;
            }
        }

        public LinkCustomerProfileResponse LinkCustomerProfileCard(LinkCustomerProfileCardRequest request)
        {
            try
            {
                var options = new Dictionary<string, string>()
                {
                    { "requestid",request.RequestId}
                };

                string serviceUri = string.Format(LinkCustomerProfileCardUrl, _gssGlobalFundsTransferBaseUrl, request.ProgramCode, request.CustomerToken);

                var response = _serviceInvokerProvider.GetResponse<LinkCustomerProfileCardRequest, LinkCustomerProfileResponse>(serviceUri, "POST", request, options);

                if (response == null || response.ResponseDetails.Count == 0)
                    throw new GlobalFundTransferException("Response is null or details are empty");

                return response;
            }
            catch (Exception e)
            {
                _logger.Error(e);
                throw;
            }
        }

        public FundTransferResponse CreateFundTransfer(CreateFundTransferRequest request)
        {
            try
            {
                var options = new Dictionary<string, string>()
                {
                    { "requestid",request.RequestId}
                };

                string serviceUri = string.Format(CreateFundTransferUrl, _gssGlobalFundsTransferBaseUrl,
                    request.ProgramCode);

                var response = _serviceInvokerProvider
                    .GetResponse<CreateFundTransferRequest, FundTransferResponse>(serviceUri, "POST", request, options);

                if (response == null || response.ResponseDetails.Count == 0)
                    throw new GlobalFundTransferException
                        ($"{nameof(CreateFundTransfer)}, Response is null or details are empty from down stream service");

                return response;
            }
            catch (Exception e)
            {
                _logger.Error(e);
                throw;
            }
        }

        public DeleteLinkResponse DeleteBankLink(DeleteLinkRequest request)
        {
            try
            {
                var options = new Dictionary<string, string>()
                {
                    { "requestid",request.RequestId}
                };

                string serviceUri = string.Format(DeleteBankLinkUrl, _gssGlobalFundsTransferBaseUrl,
                    request.ProgramCode,
                    request.CustomerToken,
                    request.LinkId
                );

                var response = _serviceInvokerProvider
                    .GetResponse<DeleteLinkRequest, DeleteLinkResponse>(serviceUri, "DELETE", request, options);

                if (response == null || response.ResponseDetails.Count == 0)
                    throw new GlobalFundTransferException
                        ($"{nameof(CreateFundTransfer)}, Response is null or details are empty from down stream service");

                return response;
            }
            catch (Exception e)
            {
                _logger.Error(e);
                throw;
            }
        }

        public DeleteLinkResponse DeleteCardLink(DeleteLinkRequest request)
        {
            try
            {
                var options = new Dictionary<string, string>()
                {
                    { "requestid",request.RequestId}
                };

                string serviceUri = string.Format(DeleteCardLinkUrl, _gssGlobalFundsTransferBaseUrl,
                    request.ProgramCode,
                    request.CustomerToken,
                    request.LinkId
                );

                var response = _serviceInvokerProvider
                    .GetResponse<DeleteLinkRequest, DeleteLinkResponse>(serviceUri, "DELETE", request, options);

                if (response == null || response.ResponseDetails.Count == 0)
                    throw new GlobalFundTransferException
                        ($"{nameof(CreateFundTransfer)}, Response is null or details are empty from down stream service");

                return response;
            }
            catch (Exception e)
            {
                _logger.Error(e);
                throw;
            }
        }

        public GetExternalCardProfileResponse GetExternalCardProfile(GetExternalCardProfileRequest request)
        {
            try
            {
                var options = new Dictionary<string, string>()
                {
                    { "requestid",request.RequestId}
                };

                string serviceUri = string.Format(GetCustomerProfileExternalUrl,
                    _gssGlobalFundsTransferBaseUrl,
                    request.ProgramCode,
                    request.CustomerToken);

                var response = _serviceInvokerProvider.GetResponse<GetExternalCardProfileResponse>(serviceUri, "GET", null, options);

                if (response == null || response.ResponseDetails.Count == 0)
                    throw new GlobalFundTransferException
                        ($"{nameof(GetExternalCardProfile)}, Response is null or details are empty from down stream service");

                return response;
            }
            catch (Exception e)
            {
                _logger.Error(e);
                throw;
            }
        }
    }
}
