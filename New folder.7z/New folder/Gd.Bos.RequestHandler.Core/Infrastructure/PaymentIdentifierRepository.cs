﻿using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.RequestHandler.Core.Utils;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using NLog;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.Logic;
using Gd.Bos.Shared.Common.UtilityCoreApi.Contract.Enum;
using AccountHolderCure = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolderCure;
using AccountStatus = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountStatus;
using AccountStatusReason = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountStatusReason;
using PaymentInstrument = Gd.Bos.RequestHandler.Core.Domain.Model.Payment.PaymentInstrument;
using CustomCardImage = Gd.Bos.RequestHandler.Core.Domain.Model.Payment.CustomCardImage;
using Gd.Bos.Shared.Common;
using Microsoft.Data.SqlClient.Server;
using RequestHandler.Core.Domain.Model.Payment;
using AccountHolder = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolder;
using PaymentIdentifierAttribute = Gd.Bos.Shared.Common.Core.Common.Enum.PaymentIdentifierAttribute;
using Gd.Bos.Shared.Common.Messaging.ProcessorEventSchema.MsgTypes;
using EmailType = Gd.Bos.RequestHandler.Core.Domain.Model.User.EmailType;
using PaymentInstrumentAttribute = Gd.Bos.Shared.Common.Core.Common.Enum.PaymentInstrumentAttributes;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers;
using RequestHandler.Core.Domain.Model.PublishNotification;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using System.Diagnostics;
using Gd.Bos.Shared.Common.Core.Logic.Options;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    [ExcludeFromCodeCoverage(Justification = "Repository class wrapper around SQLClient, hard to mock")]
    public class PaymentIdentifierRepository : IPaymentIdentifierRepository
    {
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();
        private static readonly SqlMetaData[] TypeStatusReasonMetaData = CreateAccountReasonMetaData();
        private readonly IDataAccess _dataAccess;
        private readonly IAccountRepository _accountRepository;
        private readonly IRequestHandlerSettings _requestHandlerSettings;
        private readonly string _userName = IdentityHelper.GetIdentityName();

        public PaymentIdentifierRepository(IDataAccess dataAccess, IAccountRepository accountRepository, IRequestHandlerSettings requestHandlerSettings)
        {
            _dataAccess = dataAccess;
            _accountRepository = accountRepository;
            _requestHandlerSettings = requestHandlerSettings;
        }

        public PaymentIdentifier GetPaymentIdentifierByPaymentIdentifierIdentifier(
            PaymentIdentifierIdentifier paymentIdentifierIdentifier)
        {
            var paymentIdentifier = new[]
            {
                new SqlParameter()
                {
                    ParameterName = "PaymentIdentifier",
                    Value = Guid.Parse(paymentIdentifierIdentifier.ToString())
                }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetPaymentIdentifierInfoByPaymentIdentifier]",
                _dataAccess.CreateConnection(), paymentIdentifier))
            {
                if (reader.Read())
                {
                    var paymentIdentifierKey = reader.GetInt64(reader.GetOrdinal("PaymentIdentifierKey")).ToString();
                    var paymentInstrumentIdentifier =
                        Guid.Parse(reader.GetGuid(reader.GetOrdinal("PaymentInstrumentIdentifier")).ToString());
                    var atmPinSetDate = reader.IsDBNull(reader.GetOrdinal("ATMPinSetDate"))
                        ? (DateTime?)null
                        : reader.GetDateTime(reader.GetOrdinal("ATMPinSetDate"));
                    var last4Pan = reader.GetString(reader.GetOrdinal("Last4PAN"));
                    var activationDate = reader.IsDBNull(reader.GetOrdinal("ActivationDate"))
                        ? (DateTime?)null
                        : reader.GetDateTime(reader.GetOrdinal("ActivationDate"));
                    var issuedDateTime = reader.IsDBNull(reader.GetOrdinal("IssuedDateTime"))
                        ? (DateTime?)null
                        : reader.GetDateTime(reader.GetOrdinal("IssuedDateTime"));
                    var paymentInstrumentType = (PaymentInstrumentType)Enum.ToObject(typeof(PaymentInstrumentType), reader["PaymentInstrumentTypeKey"]);
                    var paymentInstrumentStatus = (PaymentInstrumentStatus)Enum.ToObject(typeof(PaymentInstrumentStatus), reader["PaymentInstrumentStatusKey"]);
                    var paymentIdentifierStatus = reader["PaymentIdentifierStatusKey"] == DBNull.Value
                        ? default(PaymentIdentifierStatus)
                        : (PaymentIdentifierStatus)Enum.ToObject(typeof(PaymentIdentifierStatus),
                            reader["PaymentIdentifierStatusKey"]);
                    var tokenizedPAN = reader.IsDBNull(reader.GetOrdinal("TokenizedPAN"))
                        ? string.Empty
                        : reader.GetString(reader.GetOrdinal("TokenizedPAN"));
                    return new PaymentIdentifier(paymentIdentifierIdentifier)
                    {
                        PaymentIdentifierKey = Convert.ToInt64(paymentIdentifierKey),
                        BINProductKey = 1,
                        PaymentIdentifierStatusKey = 1,
                        PaymentIdentifierStatus = paymentIdentifierStatus,
                        PaymentIdentifierStatusReasonKey = 1,
                        TokenizedPAN = tokenizedPAN,
                        PaymentInstrument = new PaymentInstrument
                        {
                            PaymentIdentifierKey = paymentIdentifierKey,
                            ActivatedDateTime = activationDate,
                            EncryptedExpirationDate = DateTime.Now.ToExprDate(),
                            HasmbossedName = false,
                            IssuedDateTime = issuedDateTime,
                            Last4Pan = last4Pan,
                            PaymentInstrumentType = paymentInstrumentType,
                            PaymentInstrumentIdentifier =
                                PaymentInstrumentIdentifier.FromString(paymentInstrumentIdentifier.ToString()),
                            PinSetDate = atmPinSetDate,
                            Status = paymentInstrumentStatus.ToString()
                        }
                    };
                }
            }

            return null;
        }

        public PaymentIdentifier GetPaymentIdentifierByPaymentInstrumentIdentifier(
            PaymentInstrumentIdentifier paymentInstrumentIdentifier, out string last4Ssn)
        {
            last4Ssn = null;
            PaymentIdentifier result = new PaymentIdentifier(PaymentIdentifierIdentifier.FromString(Guid.Empty.ToString()));
            var paymentIdentifier = new[]
            {
                new SqlParameter()
                {
                    ParameterName = "PaymentInstrumentIdentifier",
                    Value = Guid.Parse(paymentInstrumentIdentifier.ToString())
                }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetPaymentIdentifierInfoByPaymentInstrumentIdentifier]",
                _dataAccess.CreateConnectionWithColumnEncryption(), paymentIdentifier))
            {
                if (reader.Read())
                {
                    var paymentIdentifierKey = reader.GetInt64(reader.GetOrdinal("PaymentIdentifierKey")).ToString();
                    var paymentIdentifierIdentifier = reader.GetGuid(reader.GetOrdinal("PaymentIdentifier")).ToString();
                    var atmPinSetDate = reader.IsDBNull(reader.GetOrdinal("ATMPinSetDate"))
                        ? (DateTime?)null
                        : reader.GetDateTime(reader.GetOrdinal("ATMPinSetDate"));
                    var last4Pan = reader.GetString(reader.GetOrdinal("Last4PAN"));
                    var accountIdentifier = reader.GetGuid(reader.GetOrdinal("AccountIdentifier"));
                    var accountHolderIdentifier = reader["AccountHolderIdentifier"].ToString();

                    var activationDate = reader.IsDBNull(reader.GetOrdinal("ActivationDate"))
                        ? (DateTime?)null
                        : reader.GetDateTime(reader.GetOrdinal("ActivationDate"));
                    var issuedDateTime = reader.IsDBNull(reader.GetOrdinal("IssuedDateTime"))
                        ? (DateTime?)null
                        : reader.GetDateTime(reader.GetOrdinal("IssuedDateTime"));
                    var paymentIdentifierProxy =
                        reader.IsDBNull(reader.GetOrdinal("PaymentIdentifierProxy")) ? "" : reader.GetString(reader.GetOrdinal("PaymentIdentifierProxy"));
                    var encryptedExpirationDate = reader.GetString(reader.GetOrdinal("EncryptedExpirationDate"));
                    var expirationMonth = encryptedExpirationDate?.Substring(0, 2);
                    var expirationYear = encryptedExpirationDate?.Substring(2, 4);
                    var cardExpirationDate = new CardExpirationDate
                    {
                        CardExpirationMonth = expirationMonth,
                        CardExpirationyear = expirationYear
                    };
                    var paymentInstrumentStatusReason = reader["PaymentIdentifierStatusReasonKey"] != DBNull.Value
                    ? (PaymentIdentifierStatusReason)Enum.Parse(typeof(PaymentIdentifierStatusReason), reader["PaymentIdentifierStatusReasonKey"].ToString())
                    : (PaymentIdentifierStatusReason?)null;
                    var embossedName = reader["EmbossedName"] == DBNull.Value ? "" : reader["EmbossedName"].ToString();
                    var productCode = reader["ProductCode"] == DBNull.Value ? "" : reader["ProductCode"].ToString();
                    var customCardImageIdentifier = reader["CustomCardImageIdentifier"] == DBNull.Value
                        ? null : reader["CustomCardImageIdentifier"].ToString();
                    bool isTemp = reader["IsTemp"] == DBNull.Value ? false
                        : reader.GetBoolean(reader.GetOrdinal("IsTemp"));

                    result = new PaymentIdentifier(PaymentIdentifierIdentifier.FromString(paymentIdentifierIdentifier))
                    {
                        PaymentIdentifierKey = Convert.ToInt64(paymentIdentifierKey),
                        AccountIdentifier = AccountIdentifier.FromGuid(accountIdentifier),
                        AccountHolderIdentifier = AccountHolderIdentifier.FromString(accountHolderIdentifier),
                        BINProductKey = 1,
                        PaymentIdentifierStatusKey = (short)reader["PaymentIdentifierStatusKey"],
                        PaymentIdentifierStatusReasonKey = reader.IsDBNull(reader.GetOrdinal("PaymentIdentifierStatusReasonKey"))
                            ? 1
                            : (short)reader["PaymentIdentifierStatusReasonKey"],
                        TokenizedPAN = reader["TokenizedPAN"]?.ToString(),
                        PaymentIdentifierProxy = paymentIdentifierProxy,
                        PaymentIdentifierStatus = (PaymentIdentifierStatus)Enum.Parse(typeof(PaymentIdentifierStatus),
                                reader["PaymentIdentifierStatusKey"].ToString()),

                        PaymentIdentifierStatusReason = paymentInstrumentStatusReason,
                        AccountStatus = (AccountStatus)Enum.Parse(typeof(AccountStatus),
                            reader["AccountStatusKey"].ToString()),
                        ProductCode = productCode,
                        CardStock = reader.IsDBNull(reader.GetOrdinal("CardStock")) ? null : reader.GetString(reader.GetOrdinal("CardStock")),
                        IsDOBMatched = reader["IsDOBMatched"] != DBNull.Value && reader.GetBoolean(reader.GetOrdinal("IsDOBMatched")),
                        IsDOBVerified = reader["IsDOBVerified"] != DBNull.Value && reader.GetBoolean(reader.GetOrdinal("IsDOBVerified")),
                        IsTemp = isTemp,
                        PaymentInstrument = new PaymentInstrument
                        {
                            PaymentIntrumentKey = (long)reader["PaymentInstrumentKey"],
                            ChangeDataTime = reader.IsDBNull(reader.GetOrdinal("ChangeDate")) ||
                                         (paymentInstrumentStatusReason != PaymentIdentifierStatusReason.CustomerInitiatedHold &&
                                        (short)reader["PaymentInstrumentStatusKey"] == 3)
                                        ? (DateTime?)null
                                        : reader.GetDateTime(reader.GetOrdinal("ChangeDate")),
                            PaymentIdentifierKey = paymentIdentifierKey,
                            ActivatedDateTime = activationDate,
                            EncryptedExpirationDate = cardExpirationDate,
                            HasmbossedName = false,
                            IssuedDateTime = issuedDateTime,
                            Last4Pan = last4Pan,
                            PaymentInstrumentType = (PaymentInstrumentType)Convert.ToInt32(reader["PaymentInstrumentTypeKey"]),
                            Status = ((PaymentInstrumentStatus)(short)reader["PaymentInstrumentStatusKey"]).ToString(),
                            PaymentInstrumentIdentifier =
                                PaymentInstrumentIdentifier.FromString(paymentInstrumentIdentifier.ToString()),
                            PinSetDate = atmPinSetDate,
                            PaymentInstrumentIdentifierString = paymentInstrumentIdentifier.ToString(),
                            IsPinSet = atmPinSetDate.HasValue,
                            UserIdentifier = reader.GetGuid(reader.GetOrdinal("ConsumerProfileIdentifier")).ToString(),
                            PaymentInstrumentStatusReason = reader.IsDBNull(reader.GetOrdinal("PaymentInstrumentStatusReasonKey")) ? (PaymentInstrumentStatusReason?)null : (PaymentInstrumentStatusReason)(short)reader["PaymentInstrumentStatusReasonKey"],
                            EmbossedName = embossedName,
                            CustomCardImageIdentifier = customCardImageIdentifier

                        }
                    };

                    //Get latest Identity from consumerProfileIdentity table
                    reader.NextResult();
                    last4Ssn = _accountRepository.ReadUserProfileIdentity(reader)?.Last4Identity;
                    result.Last4SSN = last4Ssn;

                    Logger.Info($"Got last4Identity {last4Ssn} for paymentInstrumentIdentifier {paymentInstrumentIdentifier.ToString()}");
                }
            }


            return result;
        }
        public PaymentIdentifier GetPaymentIdentifierByPaymentInstrumentIdentifierForMigration(
          PaymentInstrumentIdentifier paymentInstrumentIdentifier, out string last4Ssn)
        {
            last4Ssn = null;
            PaymentIdentifier result = new PaymentIdentifier(PaymentIdentifierIdentifier.FromString(Guid.Empty.ToString()));
            var paymentIdentifier = new[]
            {
                new SqlParameter()
                {
                    ParameterName = "PaymentInstrumentIdentifier",
                    Value = Guid.Parse(paymentInstrumentIdentifier.ToString())
                }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetPaymentIdentifierInfoByPaymentInstrumentIdentifierForMigration]",
                _dataAccess.CreateConnectionWithColumnEncryption(), paymentIdentifier))
            {
                if (reader.Read())
                {
                    var paymentIdentifierKey = reader.GetInt64(reader.GetOrdinal("PaymentIdentifierKey")).ToString();
                    var paymentIdentifierIdentifier = reader.GetGuid(reader.GetOrdinal("PaymentIdentifier")).ToString();
                    var atmPinSetDate = reader.IsDBNull(reader.GetOrdinal("ATMPinSetDate"))
                        ? (DateTime?)null
                        : reader.GetDateTime(reader.GetOrdinal("ATMPinSetDate"));
                    var last4Pan = reader.GetString(reader.GetOrdinal("Last4PAN"));
                    var accountIdentifier = reader.GetGuid(reader.GetOrdinal("AccountIdentifier"));
                    var accountHolderIdentifier = reader["AccountHolderIdentifier"].ToString();
                    var activationDate = reader.IsDBNull(reader.GetOrdinal("ActivationDate"))
                        ? (DateTime?)null
                        : reader.GetDateTime(reader.GetOrdinal("ActivationDate"));
                    var issuedDateTime = reader.IsDBNull(reader.GetOrdinal("IssuedDateTime"))
                        ? (DateTime?)null
                        : reader.GetDateTime(reader.GetOrdinal("IssuedDateTime"));
                    var paymentIdentifierProxy =
                        reader.IsDBNull(reader.GetOrdinal("PaymentIdentifierProxy")) ? "" : reader.GetString(reader.GetOrdinal("PaymentIdentifierProxy"));
                    var encryptedExpirationDate = reader.GetString(reader.GetOrdinal("EncryptedExpirationDate"));
                    var expirationMonth = encryptedExpirationDate?.Substring(0, 2);
                    var expirationYear = encryptedExpirationDate?.Substring(2, 4);
                    var cardExpirationDate = new CardExpirationDate
                    {
                        CardExpirationMonth = expirationMonth,
                        CardExpirationyear = expirationYear
                    };
                    var paymentInstrumentStatusReason = reader["PaymentIdentifierStatusReasonKey"] != DBNull.Value
                    ? (PaymentIdentifierStatusReason)Enum.Parse(typeof(PaymentIdentifierStatusReason), reader["PaymentIdentifierStatusReasonKey"].ToString())
                    : (PaymentIdentifierStatusReason?)null;
                    var embossedName = reader["EmbossedName"] == DBNull.Value ? "" : reader["EmbossedName"].ToString();
                    var productCode = reader["ProductCode"] == DBNull.Value ? "" : reader["ProductCode"].ToString();
                    int? productTypeKey = reader["ProductTypeKey"] == DBNull.Value ? (int?)null : (short)reader["ProductTypeKey"];
                    var customCardImageIdentifier = reader["CustomCardImageIdentifier"] == DBNull.Value
                        ? null : reader["CustomCardImageIdentifier"].ToString();
                    bool isTemp = reader["IsTemp"] == DBNull.Value ? false
                        : reader.GetBoolean(reader.GetOrdinal("IsTemp"));
                    string consumerProfileExtensionAttributeValue = null;
                    if (reader["ConsumerProfileExtensionAttributeValue"] != DBNull.Value)
                    {
                        consumerProfileExtensionAttributeValue = reader["ConsumerProfileExtensionAttributeValue"].ToString();
                    }

                    result = new PaymentIdentifier(PaymentIdentifierIdentifier.FromString(paymentIdentifierIdentifier))
                    {
                        PaymentIdentifierKey = Convert.ToInt64(paymentIdentifierKey),
                        AccountIdentifier = AccountIdentifier.FromGuid(accountIdentifier),
                        AccountHolderIdentifier = AccountHolderIdentifier.FromString(accountHolderIdentifier),
                        BINProductKey = 1,
                        PaymentIdentifierStatusKey = (short)reader["PaymentIdentifierStatusKey"],
                        PaymentIdentifierStatusReasonKey = reader.IsDBNull(reader.GetOrdinal("PaymentIdentifierStatusReasonKey"))
                            ? 1
                            : (short)reader["PaymentIdentifierStatusReasonKey"],
                        TokenizedPAN = reader["TokenizedPAN"]?.ToString(),
                        PaymentIdentifierProxy = paymentIdentifierProxy,
                        PaymentIdentifierStatus = (PaymentIdentifierStatus)Enum.Parse(typeof(PaymentIdentifierStatus),
                                reader["PaymentIdentifierStatusKey"].ToString()),

                        PaymentIdentifierStatusReason = paymentInstrumentStatusReason,
                        AccountStatus = (AccountStatus)Enum.Parse(typeof(AccountStatus),
                            reader["AccountStatusKey"].ToString()),
                        ProductCode = productCode,
                        ProductTypeKey = productTypeKey,
                        CardStock = reader.IsDBNull(reader.GetOrdinal("CardStock")) ? null : reader.GetString(reader.GetOrdinal("CardStock")),
                        IsDOBMatched = reader["IsDOBMatched"] != DBNull.Value && reader.GetBoolean(reader.GetOrdinal("IsDOBMatched")),
                        IsDOBVerified = reader["IsDOBVerified"] != DBNull.Value && reader.GetBoolean(reader.GetOrdinal("IsDOBVerified")),
                        IsTemp = isTemp,
                        ProspectIdentifier = consumerProfileExtensionAttributeValue,
                        PaymentInstrument = new PaymentInstrument
                        {
                            PaymentIntrumentKey = (long)reader["PaymentInstrumentKey"],
                            ChangeDataTime = reader.IsDBNull(reader.GetOrdinal("ChangeDate")) ||
                                         (paymentInstrumentStatusReason != PaymentIdentifierStatusReason.CustomerInitiatedHold &&
                                        (short)reader["PaymentInstrumentStatusKey"] == 3)
                                        ? (DateTime?)null
                                        : reader.GetDateTime(reader.GetOrdinal("ChangeDate")),
                            PaymentIdentifierKey = paymentIdentifierKey,
                            ActivatedDateTime = activationDate,
                            EncryptedExpirationDate = cardExpirationDate,
                            HasmbossedName = false,
                            IssuedDateTime = issuedDateTime,
                            Last4Pan = last4Pan,
                            PaymentInstrumentType = (PaymentInstrumentType)Convert.ToInt32(reader["PaymentInstrumentTypeKey"]),
                            Status = ((PaymentInstrumentStatus)(short)reader["PaymentInstrumentStatusKey"]).ToString(),
                            PaymentInstrumentIdentifier =
                                PaymentInstrumentIdentifier.FromString(paymentInstrumentIdentifier.ToString()),
                            PinSetDate = atmPinSetDate,
                            PaymentInstrumentIdentifierString = paymentInstrumentIdentifier.ToString(),
                            IsPinSet = atmPinSetDate.HasValue,
                            UserIdentifier = reader.GetGuid(reader.GetOrdinal("ConsumerProfileIdentifier")).ToString(),
                            PaymentInstrumentStatusReason = reader.IsDBNull(reader.GetOrdinal("PaymentInstrumentStatusReasonKey")) ? (PaymentInstrumentStatusReason?)null : (PaymentInstrumentStatusReason)(short)reader["PaymentInstrumentStatusReasonKey"],
                            EmbossedName = embossedName,
                            CustomCardImageIdentifier = customCardImageIdentifier

                        }
                    };

                    //Get latest Identity from consumerProfileIdentity table
                    reader.NextResult();
                    last4Ssn = _accountRepository.ReadUserProfileIdentity(reader)?.Last4Identity;
                    result.Last4SSN = last4Ssn;

                    Logger.Info($"Got last4Identity {last4Ssn} for paymentInstrumentIdentifier {paymentInstrumentIdentifier.ToString()}");
                }
            }


            return result;
        }

        public PaymentInstrumentPN GetPaymentIdentifierByPaymentInstrumentIdentifierPN(
            PaymentInstrumentIdentifier paymentInstrumentIdentifier, out string last4Ssn)
        {
            last4Ssn = null;
            var paymentIdentifier = new[]
            {
                new SqlParameter()
                {
                    ParameterName = "PaymentInstrumentIdentifier",
                    Value = Guid.Parse(paymentInstrumentIdentifier.ToString())
                }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetPaymentIdentifierInfoByPaymentInstrumentIdentifier]",
                _dataAccess.CreateConnectionWithColumnEncryption(), paymentIdentifier))
            {
                if (reader.Read())
                {

                    var paymentIdentifierKey = reader.GetInt64(reader.GetOrdinal("PaymentIdentifierKey")).ToString();
                    var atmPinSetDate = reader.IsDBNull(reader.GetOrdinal("ATMPinSetDate"))
                        ? (DateTime?)null
                        : reader.GetDateTime(reader.GetOrdinal("ATMPinSetDate"));
                    var last4Pan = reader.GetString(reader.GetOrdinal("Last4PAN"));
                    var paymentIdentifierIdentifier = reader.GetGuid(reader.GetOrdinal("PaymentIdentifier")).ToString();
                    var activationDate = reader.IsDBNull(reader.GetOrdinal("ActivationDate"))
                        ? (DateTime?)null
                        : reader.GetDateTime(reader.GetOrdinal("ActivationDate"));
                    var issuedDateTime = reader.IsDBNull(reader.GetOrdinal("IssuedDateTime"))
                        ? (DateTime?)null
                        : reader.GetDateTime(reader.GetOrdinal("IssuedDateTime"));
                    var encryptedExpirationDate = reader.GetString(reader.GetOrdinal("EncryptedExpirationDate"));
                    var expirationMonth = encryptedExpirationDate?.Substring(0, 2);
                    var expirationYear = encryptedExpirationDate?.Substring(2, 4);
                    var cardExpirationDate = new CardExpirationDate
                    {
                        CardExpirationMonth = expirationMonth,
                        CardExpirationyear = expirationYear
                    };
                    var embossedName = reader["EmbossedName"] == DBNull.Value ? "" : reader["EmbossedName"].ToString();

                    return new PaymentInstrumentPN
                    {
                        PaymentIdentifierKey = paymentIdentifierKey,
                        ActivatedDateTime = activationDate,
                        EncryptedExpirationDate = cardExpirationDate,
                        EmbossedName = embossedName,
                        IssuedDateTime = issuedDateTime,
                        Last4Pan = last4Pan,
                        PaymentInstrumentType = (PaymentInstrumentType)Convert.ToInt32(reader["PaymentInstrumentTypeKey"]),
                        Status = ((PaymentInstrumentStatus)(short)reader["PaymentInstrumentStatusKey"]),
                        PaymentInstrumentIdentifier =
                            PaymentInstrumentIdentifier.FromString(paymentInstrumentIdentifier.ToString()),
                        PinSetDate = atmPinSetDate,
                        PaymentInstrumentIdentifierString = paymentInstrumentIdentifier.ToString(),
                        IsPinSet = atmPinSetDate.HasValue,
                        UserIdentifier = reader.GetGuid(reader.GetOrdinal("ConsumerProfileIdentifier")).ToString(),
                        PaymentIdentifierStatus = (PaymentIdentifierStatus)Enum.Parse(typeof(PaymentIdentifierStatus),
                            reader["PaymentIdentifierStatusKey"].ToString()),

                        PaymentInstrumentStatusReason = reader.IsDBNull(reader.GetOrdinal("PaymentInstrumentStatusReasonKey")) ? (PaymentInstrumentStatusReason?)null : (PaymentInstrumentStatusReason)(short)reader["PaymentInstrumentStatusReasonKey"],
                        PaymentIdentifierStatusReason = reader.IsDBNull(reader.GetOrdinal("PaymentIdentifierStatusReasonKey")) ? (PaymentIdentifierStatusReason?)null : (PaymentIdentifierStatusReason)(short)reader["PaymentIdentifierStatusReasonKey"],
                        PaymentIdentifier = paymentIdentifierIdentifier
                    };
                }
            }

            return null;
        }

        public List<SegmentInfo> GetPaymentIdentifierSegmentByPaymentIdentifier(
           string paymentIdentifier)
        {
            var result = new List<SegmentInfo>();
            var paymentIdentifierParam = new[]
            {
                new SqlParameter()
                {
                    ParameterName = "PaymentIdentifier",
                    Value = Guid.Parse(paymentIdentifier)
                }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetPaymentIdentifierSegmentByPaymentIdentifier]",
                _dataAccess.CreateConnection(), paymentIdentifierParam))
            {
                while (reader.Read())
                {
                    var item = new SegmentInfo
                    {

                        SegmentStatus = (SegmentStatus)reader.GetInt16(reader.GetOrdinal("PaymentIdentifierSegmentStatusKey")),
                        StartDate = reader["SegmentStartDate"] == DBNull.Value
                            ? DateTime.Today
                            : reader.GetDateTime(reader.GetOrdinal("SegmentStartDate")),
                        EndDate = reader["SegmentEndDate"] == DBNull.Value
                            ? DateTime.Today
                            : reader.GetDateTime(reader.GetOrdinal("SegmentEndDate")),
                        SegmentName = (SegmentType)reader.GetInt16(reader.GetOrdinal("ProcessorSegmentKey")),
                        SegmentDescription = ((SegmentType)reader.GetInt16(reader.GetOrdinal("ProcessorSegmentKey"))).GetDescription()

                    };
                    result.Add(item);
                }
            }

            return result;
        }

        public PaymentIdentifierInfo GetPaymentInstrumentSiblingByPaymentInstrumentIdentifier(Guid paymentInstrumentIdentifier)
        {
            var paymentInstrumentIdentifierParam = new[]
            {
                new SqlParameter()
                {
                    ParameterName = "PaymentInstrumentIdentifier",
                    Value = Guid.Parse(paymentInstrumentIdentifier.ToString())
                }
            };

            var result = new PaymentIdentifierInfo
            {
                PaymentInstrument = new List<PaymentInstrumentInfo>()
            };
            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetPaymentInstrumentsByPaymentInstrumentIdentifier]",
                _dataAccess.CreateConnection(), paymentInstrumentIdentifierParam))
            {
                while (reader.Read())
                {
                    result.PaymentIdentifierProxy = reader.GetString(reader.GetOrdinal("PaymentIdentifierProxy"));
                    result.PaymentIdentifierKey = reader.GetInt64(reader.GetOrdinal("PaymentIdentifierKey"));
                    result.AtmPinSetDate = reader["ATMPinSetDate"] == DBNull.Value
                        ? (DateTime?)null
                        : reader.GetDateTime(reader.GetOrdinal("ATMPinSetDate"));
                    result.PaymentIdentifierStatus = (PaymentIdentifierStatus)Enum.Parse(typeof(PaymentIdentifierStatus),
                        reader["PaymentIdentifierStatusKey"].ToString());
                    result.PaymentIdentifierStatusReason = reader["PaymentIdentifierStatusReasonKey"] != DBNull.Value
                        ? (PaymentIdentifierStatusReason)Enum.Parse(typeof(PaymentIdentifierStatusReason), reader["PaymentIdentifierStatusReasonKey"].ToString())
                        : (PaymentIdentifierStatusReason?)null;
                    result.PaymentIdentifierChangeDate = reader.GetDateTime(reader.GetOrdinal("PaymentIdentifierChangeDate"));
                    result.TokenizedPan = reader["TokenizedPAN"].ToString();
                    result.PaymentIdentifierIdentifier =
                        reader.GetGuid(reader.GetOrdinal("PaymentIdentifier"));
                    var pi = new PaymentInstrumentInfo
                    {
                        PaymentIdentifierKey = reader.GetInt64(reader.GetOrdinal("PaymentIdentifierKey")),
                        PaymentInstrumentIdentifier = reader.GetGuid(reader.GetOrdinal("PaymentInstrumentIdentifier")),
                        ActivatedDateTime = reader["ActivationDate"] != DBNull.Value
                            ? reader.GetDateTime(reader.GetOrdinal("ActivationDate"))
                            : (DateTime?)null,
                        PaymentInstrumentStatus = reader["PaymentInstrumentStatusKey"] != DBNull.Value
                            ? (PaymentInstrumentStatus)Enum.Parse(typeof(PaymentInstrumentStatus), reader["PaymentInstrumentStatusKey"].ToString())
                            : default(PaymentInstrumentStatus),
                        PaymentInstrumentType = reader["PaymentInstrumentTypeKey"] != DBNull.Value
                            ? (PaymentInstrumentType)Enum.Parse(typeof(PaymentInstrumentType), reader["PaymentInstrumentTypeKey"].ToString())
                            : default(PaymentInstrumentType),
                        PaymentInstrumentStatusReason = reader["PaymentInstrumentStatusReasonKey"] != DBNull.Value
                            ? (PaymentInstrumentStatusReason)Enum.Parse(typeof(PaymentInstrumentStatusReason), reader["PaymentInstrumentStatusReasonKey"].ToString())
                            : (PaymentInstrumentStatusReason?)null,
                        EncryptedExpirationDate = reader["EncryptedExpirationDate"].ToString(),
                        CardStock = reader["CardStock"] == DBNull.Value ? string.Empty : reader.GetString(reader.GetOrdinal("CardStock")),
                        IssuedDateTime = reader["IssuedDateTime"] == DBNull.Value ? (DateTime?)null : reader.GetDateTime(reader.GetOrdinal("IssuedDateTime")),
                        PaymentInstrumentChangeDate = reader.GetDateTime(reader.GetOrdinal("PaymentInstrumentChangeDate")),
                        PaymentInstrumentKey = reader.GetInt64(reader.GetOrdinal("PaymentInstrumentKey"))
                    };
                    result.PaymentInstrument.Add(pi);
                }
            }

            return result;
        }

        public List<PaymentInstrumentLite> GetTokenizedPanExpirationDateByAccountIdentifiers(
            List<string> accountIdentifiers)
        {
            var accountIdsParam = new DataTable();

            accountIdsParam.Columns.Add("AccountIdentifier");
            accountIdentifiers.ForEach(b =>
            {
                var row = accountIdsParam.NewRow();
                row["AccountIdentifier"] = b;
                accountIdsParam.Rows.Add(row);
            });

            var queryParams = new[]
           {
               new SqlParameter
               {
                   ParameterName = "@AccountIdentifiers", Value = accountIdsParam,
                   SqlDbType = SqlDbType.Structured,
                   TypeName = "typeAccountIdentifiers"
               }
            };

            var result = new List<PaymentInstrumentLite>();

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetTokenizedPANExpirationDateByAccountIdentifiers]",
                _dataAccess.CreateConnectionWithColumnEncryption(), queryParams))
            {
                while (reader.Read())
                {
                    var item = new PaymentInstrumentLite
                    {
                        AccountIdentifier = reader["AccountIdentifier"].ToString(),
                        TokenizedPan = reader["TokenizedPAN"].ToString(),
                        ExpirationDate = reader["EncryptedExpirationDate"].ToString()
                    };
                    result.Add(item);
                }
            }

            return result;
        }

        [ExcludeFromCodeCoverage(Justification = "Data access layer")]
        public List<PaymentIdentifier> GetPaymentIdentifierByTokenizedPAN(string tokenizedPan)
        {
            var result = new List<PaymentIdentifier>();
            string last4Ssn = null;
            var paymentIdentifier = new[]
            {
                new SqlParameter()
                {
                    ParameterName = "TokenizedPAN",
                    Value = tokenizedPan
                }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetPaymentIdentifierInfoByTokenizedPAN]",
                _dataAccess.CreateConnectionWithColumnEncryption(), paymentIdentifier))
            {
                if (reader.Read())
                {
                    var accountIdentifier = AccountIdentifier.FromString(reader["AccountIdentifier"].ToString());
                    var productCode = reader["ProductCode"].ToString();
                    int? productTypeKey = reader["ProductTypeKey"] == DBNull.Value ? (int?)null : (short)reader["ProductTypeKey"];
                    var programCode = reader["ProgramCode"].ToString();
                    var isDOBMatched = reader["IsDOBMatched"] != DBNull.Value && reader.GetBoolean(reader.GetOrdinal("IsDOBMatched"));
                    var isDOBVerified = reader["IsDOBVerified"] != DBNull.Value && reader.GetBoolean(reader.GetOrdinal("IsDOBVerified"));
                    string consumerProfileExtensionAttributeValue = null;
                    if (reader["ConsumerProfileExtensionAttributeValue"] != DBNull.Value)
                    {
                        consumerProfileExtensionAttributeValue = reader["ConsumerProfileExtensionAttributeValue"].ToString();
                    }
                    reader.NextResult();

                    while (reader.Read())
                    {
                        var paymentInstrumentKey = reader["PaymentInstrumentKey"].ToString();
                        var paymentIdentifierIdentifier = PaymentIdentifierIdentifier.FromString(reader["PaymentIdentifier"].ToString());
                        var paymentInstrumentIdentifier = Guid.Parse(reader.GetGuid(reader.GetOrdinal("PaymentInstrumentIdentifier")).ToString());
                        var paymentInstrumentStatusKey = (short)reader["PaymentInstrumentStatusKey"];
                        var paymentIdentifierStatusReasonKey = reader.IsDBNull(reader.GetOrdinal("PaymentIdentifierStatusReasonKey"))
                                ? 1
                                : (short)reader["PaymentIdentifierStatusReasonKey"];
                        var paymentIdentifierStatusKey = (short)reader["PaymentIdentifierStatusKey"];

                        var cardExpirationMonth = reader["EncryptedExpirationDate"] == DBNull.Value ? null : reader["EncryptedExpirationDate"].ToString().Substring(0, 2);
                        var cardExpirationYear = reader["EncryptedExpirationDate"] == DBNull.Value ? null : reader["EncryptedExpirationDate"].ToString().Substring(2, 4);

                        var cardStock = reader.IsDBNull(reader.GetOrdinal("CardStock")) ? null : reader.GetString(reader.GetOrdinal("CardStock"));

                        PaymentIdentifier paymentData = new PaymentIdentifier(paymentIdentifierIdentifier)
                        {
                            PaymentIdentifierStatusKey = paymentIdentifierStatusKey,
                            PaymentIdentifierStatusReasonKey = paymentIdentifierStatusReasonKey,
                            IsDOBMatched = isDOBMatched,
                            IsDOBVerified = isDOBVerified,
                            AccountIdentifier = accountIdentifier,
                            ProductCode = productCode,
                            ProductTypeKey = productTypeKey,
                            ProgramCode = programCode,
                            TokenizedPAN = tokenizedPan,
                            ProspectIdentifier = consumerProfileExtensionAttributeValue,
                            CardStock = cardStock,
                            PaymentInstrument = new PaymentInstrument
                            {
                                PaymentIntrumentKey = Convert.ToInt64(paymentInstrumentKey),
                                Status = ((PaymentInstrumentStatus)paymentInstrumentStatusKey).ToString(),
                                EncryptedExpirationDate = new CardExpirationDate()
                                {
                                    CardExpirationMonth = cardExpirationMonth,
                                    CardExpirationyear = cardExpirationYear,
                                },
                                PaymentInstrumentIdentifier = PaymentInstrumentIdentifier.FromString(paymentInstrumentIdentifier.ToString())
                            }

                        };

                        Logger.Debug("GetPaymentIdentifierByTokenizedPAN --> PaymentIdentifier : " + paymentData?.PaymentIdentifierIdentifier);

                        result.Add(paymentData);
                    }

                    reader.NextResult();
                    var last4Identity = _accountRepository.ReadUserProfileIdentity(reader)?.Last4Identity;
                    result.ForEach(l => l.Last4SSN = last4Identity);

                }

                return result;
            }

        }

        public List<string> GetAllBins()
        {
            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAllBINs]",
                       _dataAccess.CreateConnection(), null))
            {
                List<string> allBins = new List<string>();
                while (reader.Read())
                {
                    allBins.Add(reader.GetString(reader.GetOrdinal("Bin")).Trim());
                }
                return allBins;
            }
        }

        public string GetBinByPaymentIdentifier(PaymentIdentifierIdentifier paymentIdentifierIdentifier)
        {
            List<string> allBins = new List<string>();
            var tableParam = new DataTable();
            tableParam.Columns.Add("UniqueID");
            var dr = tableParam.NewRow();
            dr["UniqueID"] = paymentIdentifierIdentifier.ToGuid();
            tableParam.Rows.Add(dr);

            var parameters = new[]
            {
                new SqlParameter
                {
                    ParameterName = "@pPaymentIdentifierList", Value = tableParam, TypeName = "[dbo].[typeUniqueIdentifiers]"
                },
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetBinByPaymentIdentifier]",
                       _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    allBins.Add(reader.GetString(reader.GetOrdinal("Bin")).Trim());
                }
            }

            return allBins.Any() ? allBins.First() : string.Empty;
        }

        public string GetBinByTokenizedPan(string tokenizedPan)
        {
            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetPaymentIdentifierBinByTokenizedPAN]",
                _dataAccess.CreateConnection(), new SqlParameter()
                {
                    ParameterName = "TokenizedPAN",
                    Value = tokenizedPan
                }))
            {
                List<string> allBins = new List<string>();
                while (reader.Read())
                {
                    allBins.Add(reader.GetString(reader.GetOrdinal("Bin")));
                }
                return allBins.FirstOrDefault();
            }
        }

        public List<PaymentIdentifierData> GetPaymentIdentifierByAccountIdentifier(string accountIdentifier)
        {
            var isParsable = Guid.TryParse(accountIdentifier, out var accountIdentifierGuid);
            if (isParsable)
                return GetPaymentIdentifierByAccountIdentifier(accountIdentifierGuid);
            return new List<PaymentIdentifierData>();
        }

        public List<PaymentIdentifierData> GetPaymentIdentifierByAccountIdentifier(Guid accountIdentifier)
        {
            var paymentIdentifierList = new List<PaymentIdentifierData>();
            SqlParameter[] parameters = {
                new SqlParameter() { ParameterName = "@accountIdentifier", SqlDbType = SqlDbType.UniqueIdentifier, Value = accountIdentifier}
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].GetPaymentIdentifierInfoByAccountIdentifier", _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    var paymentIdentifier = new PaymentIdentifierData()
                    {
                        PaymentIdentifier = reader["PaymentIdentifier"].ToString(),
                        PaymentIdentifierStatusKey = Convert.ToInt32(reader["PaymentIdentifierStatusKey"]),
                        TokenizedPan = reader["TokenizedPAN"].ToString(),
                        Last4Pan = reader["Last4PAN"].ToString(),
                        CardStock = Convert.ToString(reader["CardStock"]),
                        PaymentIdentifierKey = Convert.ToInt64(reader["PaymentIdentifierKey"]),
                        PaymentInstrumentTypeKey = Convert.ToInt32(reader["PaymentInstrumentTypeKey"]),
                        PaymentInstrumentStatus = Convert.ToInt32(reader["PaymentInstrumentStatusKey"]),
                        IssuedDateTime = Convert.ToDateTime(reader["IssuedDateTime"]),
                        PaymentInstrumentIdentifier = reader.GetGuid(reader.GetOrdinal("PaymentInstrumentIdentifier")),
                        PaymentIdentifierProxy = reader["PaymentIdentifierProxy"].ToString(),
                        CreateDate = Convert.ToDateTime(reader["PaymentInstrumentCreateDate"]),
                        BinProductKey = Convert.ToInt32(reader["BINProductKey"]),
                        IsTemp = reader["IsTemp"] == DBNull.Value ? false : Convert.ToBoolean(reader["IsTemp"]),
                        PaymentIdentifierStatusReasonKey = reader["PaymentIdentifierStatusReasonKey"] == DBNull.Value ? null : Convert.ToInt32(reader["PaymentIdentifierStatusReasonKey"]),
                    };
                    paymentIdentifierList.Add(paymentIdentifier);
                }
            }
            return paymentIdentifierList;
        }

        public void UpdateAccountStatus(Domain.Model.Account.Account account, AccountStatus accountStatus = AccountStatus.Normal)
        {
            var accountParams = new[] {
              new SqlParameter() {  ParameterName = "AccountKey",Value = account.AccountKey},
              new SqlParameter() {ParameterName = "ChangeBy", Value = _userName},
              new SqlParameter() {ParameterName = "AccountStatusKey", Value = accountStatus }};

            _dataAccess.ExecuteNonQuery("[dbo].[UpdAccountStatusByAccountKey]", _dataAccess.CreateConnectionWithColumnEncryption(), accountParams);
            account.AccountStatus = accountStatus;
        }

        public void UpdateAccountStatusAndStatusReason(Domain.Model.Account.Account account, AccountStatus accountStatus = AccountStatus.Normal,
            AccountStatusReason accountStatusReason = AccountStatusReason.healthy)
        {
            var accountParams = new[] {
              new SqlParameter() {  ParameterName = "AccountKey",Value = account.AccountKey},
              new SqlParameter() {ParameterName = "ChangeBy", Value = _userName},
              new SqlParameter() {ParameterName = "AccountStatusKey", Value = accountStatus }};

            _dataAccess.ExecuteNonQuery("[dbo].[UpdAccountStatusByAccountKey]", _dataAccess.CreateConnectionWithColumnEncryption(), accountParams);
            account.AccountStatus = accountStatus;

            if (account.AccountStatusReasons != null && account.AccountStatusReasons.Contains(accountStatusReason))
                return;

            if (account.AccountStatusReasons == null)
                account.AccountStatusReasons = new List<AccountStatusReason> { accountStatusReason };
            else
                account.AccountStatusReasons.Add(accountStatusReason);

            if (account.AccountStatusReasons?.Count > 0)
            {
                var accountStatusReasonsToRemove = new List<AccountStatusReason>() {
                    AccountStatusReason.registrationFailed,
                    AccountStatusReason.registrationNotComplete,
                    AccountStatusReason.potentialFraud,
                    AccountStatusReason.verificationNeeded,
                    AccountStatusReason.confirmedFraud
                };

                var accountReasonsToUpdate = ToAccountStatusReasonTable(accountStatusReasonsToRemove);
                accountStatusReasonsToRemove.ForEach(s => account.AccountStatusReasons.Remove(s));

                _dataAccess.ExecuteNonQuery(
                    "[dbo].[UpdAccountStatusReasonHistoryV2]", _dataAccess.CreateConnection(),
                    new SqlParameter("ChangeBy", _userName),
                    new SqlParameter("AccountIdentifier", (Guid)account.AccountIdentifier),
                    new SqlParameter() { ParameterName = "AccountStatusReasonKey", Value = accountReasonsToUpdate.Convert(), TypeName = "typeAccountStatusReason", SqlDbType = System.Data.SqlDbType.Structured }
                );
            }

            var accountStatusReasonParams = new[] {
               new SqlParameter() { ParameterName = "AccountIdentifier", Value = Guid.Parse(account.AccountIdentifier.ToString()) },
               new SqlParameter() {ParameterName = "ChangeBy", Value = _userName},
               new SqlParameter() {ParameterName = "AccountStatusReasonKey", Value = accountStatusReason },
               new SqlParameter("IsActive", true)  };


            _dataAccess.ExecuteNonQuery("[dbo].[InsAccountStatusReasonHistory]", _dataAccess.CreateConnectionWithColumnEncryption(), accountStatusReasonParams);

        }

        public void UpdateAccountStatusAndStatusReason(Domain.Model.Account.Account account, AccountStatus accountStatus = AccountStatus.Normal,
            params AccountStatusReason[] accountStatusReasonToAdd)
        {
            var accountParams = new[] {
              new SqlParameter() {  ParameterName = "AccountKey",Value = account.AccountKey},
              new SqlParameter() {ParameterName = "ChangeBy", Value = _userName},
              new SqlParameter() {ParameterName = "AccountStatusKey", Value = accountStatus }};

            _dataAccess.ExecuteNonQuery("[dbo].[UpdAccountStatusByAccountKey]", _dataAccess.CreateConnectionWithColumnEncryption(), accountParams);
            account.AccountStatus = accountStatus;

            accountStatusReasonToAdd = accountStatusReasonToAdd.Distinct().ToArray();
            if (account.AccountStatusReasons != null && !accountStatusReasonToAdd.Except(account.AccountStatusReasons).Any()) //reasons already present in db
                return;

            if (accountStatusReasonToAdd.Length > 0)
            {
                var accountStatusReasonsToRemove = new List<AccountStatusReason>() {
                    AccountStatusReason.registrationFailed,
                    AccountStatusReason.registrationNotComplete,
                    AccountStatusReason.potentialFraud,
                    AccountStatusReason.verificationNeeded,
                    AccountStatusReason.confirmedFraud
                };

                var reasonsAlreadyPresent = accountStatusReasonToAdd.Intersect(account.AccountStatusReasons);
                accountStatusReasonsToRemove.AddRange(reasonsAlreadyPresent);
                accountStatusReasonsToRemove.ForEach(s => account.AccountStatusReasons.Remove(s));
                account.AccountStatusReasons.AddRange(accountStatusReasonToAdd);

                var accountReasonsToUpdate = ToAccountStatusReasonTable(accountStatusReasonsToRemove);

                _dataAccess.ExecuteNonQuery(
                    "[dbo].[UpdAccountStatusReasonHistoryV2]", _dataAccess.CreateConnection(),
                    new SqlParameter("ChangeBy", _userName),
                    new SqlParameter("AccountIdentifier", (Guid)account.AccountIdentifier),
                    new SqlParameter() { ParameterName = "AccountStatusReasonKey", Value = accountReasonsToUpdate.Convert(), TypeName = "typeAccountStatusReason", SqlDbType = System.Data.SqlDbType.Structured }
                );
            }

            foreach (var statusReason in accountStatusReasonToAdd)
            {
                var accountStatusReasonParams = new[] {
                    new SqlParameter() { ParameterName = "AccountIdentifier", Value = Guid.Parse(account.AccountIdentifier.ToString()) },
                    new SqlParameter() {ParameterName = "ChangeBy", Value = _userName},
                    new SqlParameter() {ParameterName = "AccountStatusReasonKey", Value = statusReason },
                    new SqlParameter("IsActive", true)  };

                _dataAccess.ExecuteNonQuery("[dbo].[InsAccountStatusReasonHistory]", _dataAccess.CreateConnectionWithColumnEncryption(), accountStatusReasonParams);
            }
        }

        private List<SqlDataRecord> ToAccountStatusReasonTable(IEnumerable<AccountStatusReason> values)
        {
            List<SqlDataRecord> returnValue = new List<SqlDataRecord>();

            foreach (AccountStatusReason val in values)
            {
                returnValue.Add(CreateStatusReasonDetailRecord(val, false));
            }

            return returnValue;
        }


        private SqlDataRecord CreateStatusReasonDetailRecord(AccountStatusReason accountStatusReason, bool isActive)
        {
            SqlDataRecord record = new SqlDataRecord(TypeStatusReasonMetaData);

            record.SetInt16(0, (short)accountStatusReason);
            record.SetBoolean(1, isActive);

            return record;
        }
        private static SqlMetaData[] CreateAccountReasonMetaData()
        {
            SqlMetaData[] metadata = new SqlMetaData[2];
            metadata[0] = new SqlMetaData("AccountStatusReasonKey", System.Data.SqlDbType.SmallInt);
            metadata[1] = new SqlMetaData("IsActive", System.Data.SqlDbType.Bit);

            return metadata;
        }


        public Tuple<UserName, List<Domain.Model.User.Address>, List<Domain.Model.User.PhoneNumber>, PaymentInstrumentUpdateInfo, Domain.Model.Account.Account, AccountPrimaryConsumerProfile, Domain.Model.User.Email> GetByAccountIdentifierUserIdentifier(
            AccountIdentifier accountIdentifier, UserIdentifier userIdentifier, string programCode = "")
        {

            List<Domain.Model.User.Address> addresses = new List<Domain.Model.User.Address>();
            List<Domain.Model.User.PhoneNumber> phoneNumbers = new List<Domain.Model.User.PhoneNumber>();
            PaymentInstrumentUpdateInfo paymentInstrumentUpdateInfo = new PaymentInstrumentUpdateInfo();

            Domain.Model.User.Address address = new Domain.Model.User.Address();
            Domain.Model.User.PhoneNumber phoneNumber = new Domain.Model.User.PhoneNumber();
            Domain.Model.Account.Account account = new Domain.Model.Account.Account(accountIdentifier);

            AccountPrimaryConsumerProfile primaryAccount = null;

            try
            {
                if ("toast".Equals(programCode, StringComparison.InvariantCultureIgnoreCase))
                    primaryAccount = _accountRepository.GetAccountPrimaryConsumerProfileWithDefaultAddress(accountIdentifier, Guid.Parse(userIdentifier.ToString()));
                else
                    primaryAccount = _accountRepository.GetAccountPrimaryConsumerProfileAnyTokenWithMultipleAddresses(accountIdentifier, Guid.Parse(userIdentifier.ToString()));

                if (primaryAccount == null)
                    throw new AccountHolderNotFoundException();
            }
            catch (Exception ex)
            {
                throw new AccountHolderNotFoundException();
            }

            address.Type = primaryAccount.AddressType.ToString().ToLower();
            string firstName = primaryAccount.FirstName;
            string middleName = primaryAccount.MiddleName;
            string lastName = primaryAccount.LastName;
            address.AddressLine1 = primaryAccount.Address1;
            address.AddressLine2 = primaryAccount.Address2;
            address.City = primaryAccount.City;
            address.State = primaryAccount.State;
            address.ZipCode = primaryAccount.ZipCode;
            address.Country = primaryAccount.Country;
            phoneNumber.Number = primaryAccount.PhoneNumber;
            account.AccountKey = primaryAccount.AccountKey;
            account.AccountStatus = primaryAccount.AccountStatus;
            account.AccountNumber = primaryAccount.AccountNumber;
            account.Product = new Domain.Model.Product(ProductCode.FromString(primaryAccount.ProductCode), ProgramCode.FromString(primaryAccount.ProgramCode), primaryAccount.ProductKey, null, null, null);

            paymentInstrumentUpdateInfo.AccountHolderCure = primaryAccount.AccountHolderCure;
            paymentInstrumentUpdateInfo.ProductCode = primaryAccount.ProductCode;
            paymentInstrumentUpdateInfo.ProgramCode = primaryAccount.ProgramCode;
            var email = new Domain.Model.User.Email(primaryAccount.Email, primaryAccount.IsEmailVerified);

            UserName name = new UserName(firstName, middleName, lastName);

            primaryAccount.Addresses.ForEach(x =>
            {
                addresses.Add(new Domain.Model.User.Address
                {
                    AddressLine1 = x.Address1,
                    AddressLine2 = x.Address2,
                    City = x.City,
                    State = x.State,
                    ZipCode = x.ZipCode,
                    Country = x.Country,
                    Type = x.AddressType.ToString().ToLower()
                });
            });
            //addresses.Add(address);
            phoneNumbers.Add(phoneNumber);

            paymentInstrumentUpdateInfo.PaymentIdentifierIdentifier = primaryAccount.PaymentIdentifier;
            paymentInstrumentUpdateInfo.IsVirtualCardExist = primaryAccount.IsVirtualCardExist;
            paymentInstrumentUpdateInfo.PaymentInstrumentIdentifier = primaryAccount.PaymentInstrumentIdentifier;

            return new Tuple<UserName, List<Domain.Model.User.Address>, List<Domain.Model.User.PhoneNumber>,
                PaymentInstrumentUpdateInfo, Domain.Model.Account.Account, AccountPrimaryConsumerProfile, Domain.Model.User.Email>(name, addresses, phoneNumbers,
                paymentInstrumentUpdateInfo, account, primaryAccount, email);
        }

        public List<PaymentIdentifier> GetPaymentInstrumentInfoByPan(string token)
        {
            var result = new List<PaymentIdentifier>();

            var paymentIdentifier = new[]
            {
                new SqlParameter()
                {
                    ParameterName = "TokenizedPAN",
                    Value = token
                }
            };

            using (var rdr = _dataAccess.ExecuteReader("[dbo].[GetPaymentInstrumentByTokenizedPan]",
                _dataAccess.CreateConnectionWithColumnEncryption(), paymentIdentifier))
            {
                while (rdr.Read())
                {
                    var item = new PaymentIdentifier(PaymentIdentifierIdentifier.FromString(rdr["PaymentIdentifier"].ToString()))
                    {
                        PaymentIdentifierProxy = rdr["PaymentIdentifierProxy"].ToString(),
                        PaymentIdentifierKey = (long)rdr["PaymentIdentifierKey"],
                        AtmPinSetDate = rdr.IsDBNull(rdr.GetOrdinal("ATMPinSetDate"))
                            ? (DateTime?)null
                            : rdr.GetDateTime(rdr.GetOrdinal("ATMPinSetDate")),
                        PaymentInstrument = new PaymentInstrument()
                        {
                            PaymentInstrumentIdentifier = PaymentInstrumentIdentifier.FromString(rdr["PaymentInstrumentIdentifier"].ToString()),
                            EncryptedExpirationDate = new CardExpirationDate() { CardExpirationMonth = rdr["EncryptedExpirationDate"].ToString().Substring(0, 2), CardExpirationyear = rdr["EncryptedExpirationDate"].ToString().Substring(2, 4), },
                            Status = ((PaymentInstrumentStatus)(short)rdr["PaymentInstrumentStatusKey"]).ToString(),
                            PaymentIntrumentKey = (long)rdr["PaymentInstrumentKey"],
                            PaymentInstrumentType = (PaymentInstrumentType)(short)rdr["PaymentInstrumentTypeKey"],
                        },
                        AccountIdentifier = AccountIdentifier.FromString(rdr["AccountIdentifier"].ToString())
                    };

                    result.Add(item);
                }

                return result;
            }
        }

        public List<PaymentInstrumentAllInfo> GetAllPaymentInstrumentListInfoByAccountIdentifier(string accountIdentifier)
        {
            var stopwatch = Stopwatch.StartNew();
            var result = new List<PaymentInstrumentAllInfo>();
            var accountInfo = new[]
            {
                new SqlParameter()
                {
                    ParameterName = "AccountIdentifier",
                    Value = Guid.Parse(accountIdentifier)
                }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetPaymentInstrumentInfoCustomerInfoByAccountIdentifier]",
                _dataAccess.CreateConnection(), accountInfo))
            {
                while (reader.Read())
                {
                    var paymentInstrument = new PaymentInstrumentLight
                    {
                        PaymentIdentifier = Cast<Guid>(reader["PaymentIdentifier"]).ToString(),
                        UserIdentifier = Cast<Guid>(reader["ConsumerProfileIdentifier"]).ToString(),
                        PaymentInstrumentIdentifier = Cast<Guid>(reader["PaymentInstrumentIdentifier"]).ToString(),
                        PaymentInstrumentType = (PaymentInstrumentType)Cast<short>(reader["PaymentInstrumentTypeKey"]),
                        IsPrimaryAccountHolder = Cast<bool>(reader["IsPrimaryAccountHolder"]),
                        CustomCardImageIdentifier = Cast<string>(reader["CustomCardImageIdentifier"])
                    };
                    var atmPinSetDate = Cast<DateTime?>(reader["ATMPinSetDate"]);
                    paymentInstrument.IsPinSet = atmPinSetDate.HasValue;
                    paymentInstrument.Last4Pan = Cast<string>(reader["Last4PAN"]);
                    paymentInstrument.IssuedDateTime = Cast<DateTime?>(reader["IssuedDateTime"]);
                    paymentInstrument.ActivatedDateTime = Cast<DateTime?>(reader["ActivationDate"]);

                    var item = new PaymentInstrumentAllInfo
                    {
                        PaymentInstrument = paymentInstrument,
                        PaymentIdentifierStatus = (PaymentIdentifierStatus)Cast<short>(reader["PaymentIdentifierStatusKey"]),
                        PaymentIdentifierStatusReason = (PaymentIdentifierStatusReason?)Cast<short?>(reader["PaymentIdentifierStatusReasonKey"]),
                        PaymentInstrumentStatus = (PaymentInstrumentStatus)Cast<short>(reader["PaymentInstrumentStatusKey"]),
                        PaymentInstrumentStatusReason = (PaymentInstrumentStatusReason?)Cast<short?>(reader["PaymentInstrumentStatusReasonKey"]),
                        PaymentIdentifierIsTemp = reader["IsTemp"] != DBNull.Value && reader.GetBoolean(reader.GetOrdinal("IsTemp"))
                    };

                    result.Add(item);
                }

                // optional log stopwatch
                stopwatch.Stop();
                if (_requestHandlerSettings.LogStopwatch || OptionsContext.Current.ContainsKey("X-GD-LogStopwatch"))
                {
                    Logger.Info(
                        "[{Class}.{Method}] retrieved by identifier {identifier} in {elapsedMs:F3} ms",
                        nameof(PaymentIdentifierRepository),
                        nameof(GetAllPaymentInstrumentListInfoByAccountIdentifier),
                        accountIdentifier,
                        stopwatch.Elapsed.TotalMilliseconds);
                }

                return result;
            }
        }

        public List<CustomCardImage> GetCustomCardImagesByAccountIdentifier(string accountIdentifier)
        {
            var result = new List<CustomCardImage>();
            var accountInfo = new[]
            {
                new SqlParameter()
                {
                    ParameterName = "AccountIdentifier",
                    Value = Guid.Parse(accountIdentifier)
                }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetCustomCardImagesByAccountIdentifier]",
                _dataAccess.CreateConnection(), accountInfo))
            {
                while (reader.Read())
                {
                    var item = new CustomCardImage
                    {
                        CustomCardImageKey = Cast<long>(reader["CustomCardImageKey"]),
                        CustomCardImageStatus = (CustomCardImageStatus)Cast<short>(reader["CustomCardImageStatusKey"]),
                        CreateDate = Cast<DateTime>(reader["CreateDate"]),
                        Path = Cast<string>(reader["Path"]),
                        CustomCardImageStatusReasonKey = Cast<int?>(reader["CustomCardImageStatusReasonKey"]),
                        ImageIdentifier = Cast<string>(reader["CustomCardImageIdentifier"]),
                        CustomCardRequestKey = Cast<long>(reader["CustomCardRequestKey"]),
                    };

                    result.Add(item);
                }

                return result;
            }
        }

        public PaymentIdentifier GetPaymentIdentifierByProxy(string paymentIdentifierProxy)
        {
            string trimmedProxy = paymentIdentifierProxy?.Trim();
            if (string.IsNullOrEmpty(trimmedProxy))
                throw new Exception("Proxy cannot be null nor empty");

            PaymentIdentifier paymentIdentifierInfo = null;
            var parameters = new[]
            {
                new SqlParameter {ParameterName = "PaymentIdentifierProxy", Value = trimmedProxy}
            };
            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountByPaymentIdentifierProxy]",
                _dataAccess.CreateConnection(), parameters))
            {
                if (reader.Read())
                {
                    var paymentIdentifier = reader["PaymentIdentifier"].Cast<Guid>().ToString();
                    paymentIdentifierInfo = new PaymentIdentifier(PaymentIdentifierIdentifier.FromString(paymentIdentifier));
                    paymentIdentifierInfo.AccountIdentifier = reader["accountIdentifier"].Cast<Guid>();
                    paymentIdentifierInfo.Last4SSN = reader["Last4PAN"].Cast<string>();
                    paymentIdentifierInfo.BINProductKey = reader["BINProductKey"].Cast<int>();
                }

                if (paymentIdentifierInfo == null)
                    throw new Exception($"No account was found for payment identifier proxy {paymentIdentifierProxy}.");

                return paymentIdentifierInfo;
            }
        }

        public IList<PaymentIdentifier> GetPaymentIdentifiersByPaymentIdentifierProxy(string paymentIdentifierProxy, bool isThrowException = true)
        {
            if (string.IsNullOrWhiteSpace(paymentIdentifierProxy))
                throw new Exception($"{nameof(paymentIdentifierProxy)} must be provided.");

            var paymentIdentifiers = new List<PaymentIdentifier>();

            var parameters = new[]
            {
                new SqlParameter {ParameterName = "PaymentIdentifierProxy", Value = paymentIdentifierProxy.Trim()}
            };

            using var reader = _dataAccess.ExecuteReader("[dbo].[GetPaymentInstrumentByPaymentIdentifierProxy]",
                _dataAccess.CreateConnection(), parameters);

            while (reader.Read())
            {
                var paymentIdentifierId = reader["PaymentIdentifier"].Cast<Guid>().ToString();

                var paymentIdentifier = new PaymentIdentifier(PaymentIdentifierIdentifier.FromString(paymentIdentifierId))
                {
                    PaymentIdentifierKey = reader["PaymentIdentifierKey"].Cast<long>(),
                    AtmPinSetDate = reader["ATMPinSetDate"].Cast<DateTime?>(),
                    PaymentIdentifierStatusKey = reader["PaymentIdentifierStatusKey"].Cast<short>(),
                    PaymentIdentifierStatusReasonKey = reader["PaymentIdentifierStatusReasonKey"].Cast<short>(),
                    CreateDate = reader["ChangeDate"].Cast<DateTime>(),
                    ChangeDate = reader["ChangeDate"].Cast<DateTime>()
                };

                paymentIdentifier.PaymentIdentifierStatus = (PaymentIdentifierStatus)paymentIdentifier.PaymentIdentifierStatusKey;
                paymentIdentifier.PaymentIdentifierStatusReason = (PaymentIdentifierStatusReason)paymentIdentifier.PaymentIdentifierStatusReasonKey;

                paymentIdentifiers.Add(paymentIdentifier);
            }

            if (!paymentIdentifiers.Any() && isThrowException)
                throw new Exception($"No payment identifiers found for payment identifier proxy {paymentIdentifierProxy}.");

            return paymentIdentifiers;
        }

        public List<PaymentInstrumentInfo_V2> GetPaymentInstrumentByUserIdentifier(Guid userIdentifier)
        {
            var paymentInstrumentList = new List<PaymentInstrumentInfo_V2>();
            SqlParameter[] parameters = {
                new SqlParameter() { ParameterName = "@ConsumerProfileIdentifier",  Value = userIdentifier}
            };
            using (var reader = _dataAccess.ExecuteReader("[dbo].GetPaymentInfoByConsumerProfileIdentifierV2", _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    var paymentInstrument = new PaymentInstrumentInfo_V2();
                    paymentInstrument.AccountIdentifier = reader.GetGuid(reader.GetOrdinal("AccountIdentifier")).ToString();
                    paymentInstrument.PaymentIdentifier = reader.GetGuid(reader.GetOrdinal("PaymentIdentifier")).ToString();
                    paymentInstrument.TokenizedPan = reader.GetString(reader.GetOrdinal("TokenizedPAN"));
                    paymentInstrument.Last4Pan = reader.GetString(reader.GetOrdinal("Last4PAN"));
                    if (reader["PaymentIdentifier_CreateDate"] == DBNull.Value)
                    {
                        paymentInstrument.PaymentIdentifierCreateDate = null;
                    }
                    else
                    {
                        paymentInstrument.PaymentIdentifierCreateDate = reader.GetDateTime(reader.GetOrdinal("PaymentIdentifier_CreateDate"));
                    }

                    paymentInstrument.BinProductKey = reader.GetInt32(reader.GetOrdinal("BINProductKey"));
                    paymentInstrument.PaymentInstrumentIdentifier = reader.GetGuid(reader.GetOrdinal("PaymentInstrumentIdentifier")).ToString();
                    if (reader["ActivationDate"] == DBNull.Value)
                    {
                        paymentInstrument.ActivationDate = null;
                    }
                    else
                    {
                        paymentInstrument.ActivationDate = reader.GetDateTime(reader.GetOrdinal("ActivationDate"));
                    }

                    if (reader["IssuedDateTime"] == DBNull.Value)
                    {
                        paymentInstrument.IssuedDateTime = null;
                    }
                    else
                    {
                        paymentInstrument.IssuedDateTime = reader.GetDateTime(reader.GetOrdinal("IssuedDateTime"));
                    }
                    if (reader["PaymentInstrument_Createdate"] == DBNull.Value)
                    {
                        paymentInstrument.PaymentInstrumentCreateDate = null;
                    }
                    else
                    {
                        paymentInstrument.PaymentInstrumentCreateDate = reader.GetDateTime(reader.GetOrdinal("PaymentInstrument_Createdate"));
                    }
                    paymentInstrument.PaymentInstrumentStatusKey = reader.GetInt16(reader.GetOrdinal("PaymentInstrumentStatusKey"));
                    paymentInstrument.IsTemp = reader["IsTemp"] == DBNull.Value ? false : Convert.ToBoolean(reader["IsTemp"]);
                    var paymentInstrumentType = (PaymentInstrumentType)Enum.ToObject(typeof(PaymentInstrumentType), reader["PaymentInstrumentTypeKey"]);
                    paymentInstrument.PaymentInstrumentType = paymentInstrumentType;

                    paymentInstrumentList.Add(paymentInstrument);
                }
            }

            return paymentInstrumentList;
        }

        public long InsertPaymentIdentifier(Guid paymentIdentifierIdentifier, string tokenizedPan, string paymentIdentifierProxy, int binProductKey, short paymentIdentifierStatusKey, short? paymentIdentifierStatusReasonKey, string last4Pan, DateTime? atmPinSetDate, bool isTemp)
        {
            long paymentIdentifier;
            try
            {
                var parameters = new[]
                {
                    new SqlParameter
                    {
                        ParameterName = "ChangeBy", Value = IdentityHelper.GetIdentityName()
                    },
                    new SqlParameter {ParameterName = "PaymentIdentifier", Value = paymentIdentifierIdentifier},
                    new SqlParameter {ParameterName = "TokenizedPan", Value = tokenizedPan},
                    new SqlParameter {ParameterName = "PaymentIdentifierProxy", Value = paymentIdentifierProxy},
                    new SqlParameter {ParameterName = "BinProductKey", Value = binProductKey},
                    new SqlParameter {ParameterName = "PaymentIdentifierStatusKey", Value = paymentIdentifierStatusKey},
                    new SqlParameter {ParameterName = "PaymentIdentifierStatusReasonKey", Value = paymentIdentifierStatusReasonKey},
                    new SqlParameter {ParameterName = "Last4Pan", Value = last4Pan},
                    new SqlParameter {ParameterName = "AtmPinSetDate", Value = atmPinSetDate},
                    new SqlParameter {ParameterName = "IsTemp", Value = isTemp},
                };

                var accountTransactionKey = _dataAccess.ExecuteScalar("[dbo].[InsPaymentIdentifierV2]",
                    _dataAccess.CreateConnection(),
                    parameters);

                paymentIdentifier = Convert.ToInt64(accountTransactionKey);
            }
            catch (Exception ex)
            {
                Logger.Error(ex, $"Error occurred while calling SP:InsertPaymentIdentifier. PaymentIdentifier:{paymentIdentifierIdentifier},binProductKey:{binProductKey},isTemp:{isTemp}");
                throw;
            }
            return paymentIdentifier;
        }

        public long InsertPaymentInstrument(Guid paymentInstrumentIdentifier,
            long paymentIdentifierKey,
            short paymentInstrumentTypeKey,
            short paymentInstrumentStatusKey,
            short? paymentInstrumentStatusReasonKey,
            string encryptedExpirationDate,
            DateTime? activationDate,
            bool hasEmbossedName,
            DateTime? issuedDateTime,
            string cardStock,
            long? customCardImageKey,
            short? deliveryMethod = null)
        {
            long paymentInstrumentKey = 0;
            try
            {
                using (var cnn = _dataAccess.CreateConnectionWithColumnEncryption())
                {
                    var cmd = cnn.CreateCommand();
                    cmd.CommandText = "[dbo].[InsPaymentInstrument]";
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "ChangeBy", Value = IdentityHelper.GetIdentityName() });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "PaymentInstrumentIdentifier", Value = paymentInstrumentIdentifier });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "PaymentIdentifierKey", Value = paymentIdentifierKey });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "PaymentInstrumentTypeKey", Value = paymentInstrumentTypeKey });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "PaymentInstrumentStatusKey", Value = paymentInstrumentStatusKey });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "PaymentInstrumentStatusReasonKey", Value = paymentInstrumentStatusReasonKey });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "EncryptedExpirationDate", Value = encryptedExpirationDate, SqlDbType = SqlDbType.NVarChar, Size = 100 });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "ActivationDate", Value = activationDate });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "HasEmbossedName", Value = hasEmbossedName });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "IssuedDateTime", Value = issuedDateTime });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "CardStock", Value = cardStock });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "CustomCardImageKey", Value = customCardImageKey });

                    cnn.Open();
                    paymentInstrumentKey = Convert.ToInt64(cmd.ExecuteScalar());
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex, $"Error occurred while calling SP:InsPaymentInstrument. PaymentInstrumentIdentifier:{paymentInstrumentIdentifier},PaymentIdentifierKey:{paymentIdentifierKey}");
                throw;
            }

            return paymentInstrumentKey;
        }

        public void UpdatePaymentInstrument(PaymentInstrumentInfo paymentInstrumentInfo)
        {
            try
            {
                var piParams = new[]
                {
                    new SqlParameter()
                    {
                        ParameterName = "@PaymentInstrumentIdentifier",
                        Value = paymentInstrumentInfo.PaymentInstrumentIdentifier
                    },
                    new SqlParameter() {ParameterName = "ChangeBy", Value = _userName},
                    new SqlParameter()
                        {ParameterName = "@ActivationDate", Value = paymentInstrumentInfo.ActivatedDateTime},
                    new SqlParameter
                        { ParameterName = "EncryptedExpirationDate",
                            Value = paymentInstrumentInfo.EncryptedExpirationDate,
                            SqlDbType = SqlDbType.NVarChar,
                            Size = 100
                        }
                };

                _dataAccess.ExecuteNonQuery("[dbo].[UpdPaymentInstrumentActivationAndExpirationDate]",
                    _dataAccess.CreateConnectionWithColumnEncryption(), piParams);
            }
            catch (Exception ex)
            {
                Logger.Error(ex, $"Error occurred while calling SP:UpdatePaymentInstrument. PaymentInstrumentIdentifier:{paymentInstrumentInfo.PaymentInstrumentIdentifier},PaymentIdentifierKey:{paymentInstrumentInfo.PaymentIdentifierKey}");
                throw;
            }
        }

        public void UpdatePinChangeDate(long paymentIdentifierKey, SetPinChannel? channel, DateTime pinChangeDateTime)
        {
            try
            {
                var piParams = new[]
                {
                    new SqlParameter { ParameterName = "@PaymentIdentifierKey", Value = paymentIdentifierKey },
                    new SqlParameter { ParameterName = "@SourceKey", Value = channel },
                    new SqlParameter { ParameterName = "@ATMPinSetDate", Value = pinChangeDateTime}
                };

                _dataAccess.ExecuteNonQuery("[dbo].[InsATMPinSetDateHistory]",
                    _dataAccess.CreateConnectionWithColumnEncryption(), piParams);
            }
            catch (Exception ex)
            {
                Logger.Error(ex, $"Error occurred while calling SP:InsATMPinSetDateHistory. PaymentInstrument:{paymentIdentifierKey}");
                throw;
            }
        }

        public void UpdatePaymentIdentifierKey(long verificationRequestKey, long paymentIdentifierKey, long accountHolderKey, long consumerProfileKey)
        {
            try
            {
                var piParams = new[]
                {
                    new SqlParameter()
                    {
                        ParameterName = "@VerificationRequestKey",
                        Value = verificationRequestKey
                    },new SqlParameter()
                    {
                        ParameterName = "@PaymentIdentifierKey",
                        Value = paymentIdentifierKey
                    },new SqlParameter()
                    {
                        ParameterName = "@AcountHolderKey",
                        Value = accountHolderKey
                    },new SqlParameter()
                    {
                        ParameterName = "@ConsumerProfileKey",
                        Value = consumerProfileKey
                    },
                    new SqlParameter() {ParameterName = "ChangeBy", Value = _userName}
                };

                _dataAccess.ExecuteNonQuery("[dbo].[UpdVerificationRequestPaymentIdentifierKey]",
                    _dataAccess.CreateConnectionWithColumnEncryption(), piParams);
            }
            catch (Exception ex)
            {
                Logger.Error(ex, $"Error occurred while calling SP:UpdVerificationRequestPaymentIdentifierKey. PaymentIdentifierKey:{paymentIdentifierKey}");
                throw;
            }
        }

        public List<PaymentIdentifierDetail> GetPaymentIdentifierDetails(long paymentIdentifierKey)
        {
            var result = new List<PaymentIdentifierDetail>();
            var parameters = new[]
            {
                new SqlParameter()
                {
                    ParameterName = "PaymentIdentifierKey",
                    Value = paymentIdentifierKey
                }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetPaymentIdentifierDetailByPaymentIdentifierKey]",
                _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    PaymentIdentifierDetail detail = new PaymentIdentifierDetail();
                    detail.PaymentIdentifierDetailKey = Cast<long>(reader["PaymentIdentifierDetailKey"]);
                    detail.PaymentIdentifierKey = Cast<long>(reader["PaymentIdentifierKey"]);
                    detail.PaymentIdentifierAttribute = (PaymentIdentifierAttribute)Cast<short>(reader["PaymentIdentifierAttributeKey"]);
                    detail.PaymentIdentifierAttributeValue = reader["PaymentIdentifierAttributeValue"];

                    result.Add(detail);
                }

                return result;
            }
        }

        public void InsertOrUpdatePaymentIdentifierDetail(long paymentIdentifierKey, PaymentIdentifierAttribute paymentIdentifierAttribute, bool isDelinquent)
        {
            try
            {
                using (var cnn = _dataAccess.CreateConnectionWithColumnEncryption())
                {
                    var cmd = cnn.CreateCommand();
                    cmd.CommandText = "[dbo].[InsUpdPaymentIdentifierDetail]";
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "ChangeBy", Value = IdentityHelper.GetIdentityName() });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "PaymentIdentifierKey", Value = paymentIdentifierKey });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "PaymentIdentifierAttributeKey", Value = (short)paymentIdentifierAttribute });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "PaymentIdentifierAttributeValue", Value = isDelinquent, SqlDbType = SqlDbType.Variant });
                    cnn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex, $"Error occurred while calling SP:InsOrUpdPaymentIdentifierDetail. PaymentIdentifierKey:{paymentIdentifierKey},PaymentIdentifierAttribute:{(short)paymentIdentifierAttribute},IsDelinquent:{isDelinquent}");
                throw;
            }
        }

        public void InsertOrUpdatePaymentIdentifierDetail(long paymentIdentifierKey, PaymentIdentifierAttribute paymentIdentifierAttribute, string paymentIdentifierAttributeValue)
        {
            try
            {
                using (var cnn = _dataAccess.CreateConnectionWithColumnEncryption())
                {
                    var cmd = cnn.CreateCommand();
                    cmd.CommandText = "[dbo].[InsUpdPaymentIdentifierDetail]";
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "ChangeBy", Value = IdentityHelper.GetIdentityName() });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "PaymentIdentifierKey", Value = paymentIdentifierKey });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "PaymentIdentifierAttributeKey", Value = (short)paymentIdentifierAttribute });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "PaymentIdentifierAttributeValue", Value = paymentIdentifierAttributeValue, SqlDbType = SqlDbType.Variant });
                    cnn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex, $"Error occurred while calling SP:InsOrUpdPaymentIdentifierDetail. PaymentIdentifierKey:{paymentIdentifierKey},PaymentIdentifierAttribute:{(short)paymentIdentifierAttribute},paymentIdentifierAttributeValue:{paymentIdentifierAttributeValue}");
                throw;
            }
        }
        public void UpdAccountProductTier(Guid accountIdentifier, int productTierKey)
        {
            try
            {
                using (var cnn = _dataAccess.CreateConnection())
                {
                    var cmd = cnn.CreateCommand();
                    cmd.CommandText = "[dbo].[UpdAccountProductTier]";
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "ChangeBy", Value = IdentityHelper.GetIdentityName() });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "AccountIdentifier", Value = accountIdentifier });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "ProductTierKey", Value = productTierKey });
                    cnn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex, $"UpdAccountProductTier failed, AccountIdentifier:{accountIdentifier}, ProductTierKey:{productTierKey}");
                throw;
            }
        }

        public void UpdatePaymentIdentifierStatusAndReason(long paymentIdentifierKey, PaymentIdentifierStatus status,
            PaymentIdentifierStatusReason? reason, string tokenizedPan, string paymentIdentifierProxy, string last4pan)
        {
            try
            {
                using var cnn = _dataAccess.CreateConnection();

                var cmd = cnn.CreateCommand();

                cmd.CommandText = "[dbo].[UpdPaymentIdentifierStatusAndReason]";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter { ParameterName = "ChangeBy", Value = IdentityHelper.GetIdentityName() });
                cmd.Parameters.Add(new SqlParameter { ParameterName = "PaymentIdentifierKey", Value = paymentIdentifierKey });
                cmd.Parameters.Add(new SqlParameter { ParameterName = "PaymentIdentifierStatusKey", Value = (int)status });
                cmd.Parameters.Add(new SqlParameter { ParameterName = "PaymentIdentifierStatusReasonKey", Value = (int?)reason });
                cmd.Parameters.Add(new SqlParameter { ParameterName = "TokenizedPAN", Value = string.IsNullOrWhiteSpace(tokenizedPan) ? null : tokenizedPan });
                cmd.Parameters.Add(new SqlParameter { ParameterName = "PaymentIdentifierProxy", Value = string.IsNullOrWhiteSpace(paymentIdentifierProxy) ? null : paymentIdentifierProxy });
                cmd.Parameters.Add(new SqlParameter { ParameterName = "Last4PAN", Value = string.IsNullOrWhiteSpace(last4pan) ? null : last4pan });

                cnn.Open();

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Logger.Error(ex, $"UpdPaymentIdentifierStatusAndReason failed, PaymentIdentifierKey:{paymentIdentifierKey}, StatusKey:{status}");
                throw;
            }
        }

        public void InsertPaymentInstrumentDetail(long paymentInstrumentKey, int paymentInstrumentAttributeKey, string paymentInstrumentAttributeValue)
        {
            try
            {
                var parameters = new[]
                {
                    new SqlParameter {ParameterName = "@IP_PaymentInstrumentKey", Value = paymentInstrumentKey},
                    new SqlParameter {ParameterName = "@IP_PaymentInstrumentAttributeKey", Value = paymentInstrumentAttributeKey},
                    new SqlParameter {ParameterName = "@IP_PaymentInstrumentAttributeValue", Value = paymentInstrumentAttributeValue},
                };

                var accountTransactionKey = _dataAccess.ExecuteScalar("[dbo].[InsPaymentInstrumentDetail]",
                    _dataAccess.CreateConnection(),
                    parameters);

            }
            catch (Exception ex)
            {
                Logger.Error(ex, $"Error occurred while calling SP:InsertPaymentInstrumentDetail. PaymentInstrumentKey:{paymentInstrumentKey}");
                throw;
            }
        }

        public void InsPaymentInstrumentDetailByBatch(long paymentInstrumentKey, string issuedStatus, DateTime issuedDateTime, string locationId, string printerId, string userId)
        {
            try
            {
                var parameter = new[]
                {
                    new SqlParameter()
                    {
                        ParameterName = "ptypePaymentInstrumentDetail",
                        Value = CreateTypePaymentInstrumentDetailRecord(paymentInstrumentKey, issuedStatus, issuedDateTime, locationId, printerId, userId).Convert(),
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.typePaymentInstrumentDetail"
                    }
                };

                _dataAccess.ExecuteNonQuery("InsPaymentInstrumentDetailByBatch", _dataAccess.CreateConnection(), parameter);
            }
            catch (Exception ex)
            {
                Logger.Error(ex, $"Error occurred while calling SP:InsPaymentInstrumentDetailByBatch. PaymentInstrumentKey:{paymentInstrumentKey}");
                throw;
            }
        }

        private List<SqlDataRecord> CreateTypePaymentInstrumentDetailRecord(long paymentInstrumentKey,
            string issuedStatus, DateTime issuedDateTime, string locationId, string printerId, string userId)
        {
            List<SqlDataRecord> returnValue = new List<SqlDataRecord>();

            if (!string.IsNullOrWhiteSpace(issuedStatus))
            {
                var isPrinted = "printSuccess".Equals(issuedStatus, StringComparison.InvariantCultureIgnoreCase)
                    ? "true"
                    : "false";

                returnValue.Add(AddNewRecord(paymentInstrumentKey, (short)PaymentInstrumentAttribute.Printed, isPrinted));

                if (isPrinted == "true")
                    returnValue.Add(AddNewRecord(paymentInstrumentKey, (short)PaymentInstrumentAttribute.PrintedDateTime,
                        issuedDateTime.ToString("yyyy-MM-dd HH:mm:ss")));
            }

            if (!string.IsNullOrWhiteSpace(locationId))
                returnValue.Add(AddNewRecord(paymentInstrumentKey, (short)PaymentInstrumentAttribute.PrintedStoreId, locationId));

            if (!string.IsNullOrWhiteSpace(printerId))
                returnValue.Add(AddNewRecord(paymentInstrumentKey, (short)PaymentInstrumentAttribute.PrinterId, printerId));

            if (!string.IsNullOrWhiteSpace(userId))
                returnValue.Add(AddNewRecord(paymentInstrumentKey, (short)PaymentInstrumentAttribute.UserId, userId));

            return returnValue;
        }

        private static SqlMetaData[] CreateTypePaymentInstrumentDetailMetadata()
        {
            SqlMetaData[] metadata = new SqlMetaData[3];

            metadata[0] = new SqlMetaData("PaymentInstrumentKey", SqlDbType.BigInt);
            metadata[1] = new SqlMetaData("PaymentInstrumentAttributeKey", SqlDbType.SmallInt);
            metadata[2] = new SqlMetaData("PaymentInstrumentAttributeValue", SqlDbType.NVarChar, 100);

            return metadata;
        }

        public static SqlDataRecord AddNewRecord(long paymentInstrumentKey, short paymentInstrumentAttributeKey, string paymentInstrumentAttributeValue)
        {
            SqlDataRecord record = new SqlDataRecord(CreateTypePaymentInstrumentDetailMetadata());
            record.SetInt64(0, paymentInstrumentKey);
            record.SetInt16(1, paymentInstrumentAttributeKey);
            record.SetString(2, paymentInstrumentAttributeValue);

            return record;
        }

        public void UpdatePaymentInstrumentDetail(long paymentInstrumentDetailKey,
            string paymentInstrumentAttributeValue)
        {
            try
            {
                var piParams = new[]
                {
                    new SqlParameter()
                    {
                        ParameterName = "@IP_PaymentInstrumentDetailKey",
                        Value = paymentInstrumentDetailKey
                    },
                    new SqlParameter()
                    {
                        ParameterName = "@IP_PaymentInstrumentAttributeValue",
                        Value = paymentInstrumentAttributeValue
                    }
                };

                _dataAccess.ExecuteNonQuery("[dbo].[UpdPaymentInstrumentDetail]",
                    _dataAccess.CreateConnectionWithColumnEncryption(), piParams);
            }
            catch (Exception ex)
            {
                Logger.Error(ex,
                    $"Error occurred while calling SP:UpdatePaymentInStrumentDetail. PaymentInstrumentDetailKey:{paymentInstrumentDetailKey}");
                throw;
            }
        }

        public List<PaymentInstrumentDetail> GetPaymentInstrumentDetails(Guid paymentInstrumentIdentifier)
        {
            var result = new List<PaymentInstrumentDetail>();
            var parameters = new[]
            {
                new SqlParameter()
                {
                    ParameterName = "@IP_PaymentInstrumentIdentifier",
                    Value = paymentInstrumentIdentifier
                }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetPaymentInstrumentDetailByPaymentInstrumentIdentifier]",
                       _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    PaymentInstrumentDetail detail = new PaymentInstrumentDetail();
                    detail.PaymentInstrumentKey = Cast<long>(reader["PaymentInstrumentKey"]);
                    detail.PaymentInstrumentDetailKey = Cast<long>(reader["PaymentInstrumentDetailKey"]);
                    detail.PaymentInstrumentAttribute = (PaymentInstrumentAttribute)Cast<short>(reader["PaymentInstrumentAttributeKey"]);
                    detail.PaymentInstrumentAttributeValue = Cast<string>(reader["PaymentInstrumentAttributeValue"]);

                    result.Add(detail);
                }

                return result;
            }
        }


        /// <summary>
        /// Cast can provide better performance than ConvertTo if you are sure about the data type.
        /// </summary>
        /// <typeparam name="T">Type to cast to</typeparam>
        /// <param name="value">Value to be casted</param>
        /// <returns></returns>
        private static T Cast<T>(object value)
        {
            if (value == DBNull.Value || value == null)
                return default(T);

            return (T)value;
        }

        public short GetAssociationKeyByPaymentInstrumentIdentifier(string PaymentInstrumentIdentifier)
        {
            try
            {
                var identifier = Guid.Parse(PaymentInstrumentIdentifier);
                var parameters = new[]
                {
                     new SqlParameter()
                     {
                         ParameterName = "@pPaymentInstrumentIdentifier",
                         Value = identifier
                     }
                 };

                using var connection = _dataAccess.CreateConnection();
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAssociationKeyByPaymentInstrumentIdentifier]",
                    connection, parameters))
                {
                    if (reader.Read())
                    {
                        return Cast<short>(reader["AssociationKey"]);
                    }
                    return 0;
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex,
                    $"Error occurred while calling SP:GetAssociationKeyByPaymentInstrumentIdentifier. " +
                    $"PaymentInstrumentIdentifier:{PaymentInstrumentIdentifier}");
                throw;
            }
        }

        public void UpdatePaymentIdentifierIsTemp(Guid paymentIdentifier, bool isTemp)
        {
            try
            {
                using var cnn = _dataAccess.CreateConnection();

                var cmd = cnn.CreateCommand();

                cmd.CommandText = "[dbo].[UpdPaymentIdentifierIsTemp]";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter { ParameterName = "ChangeBy", Value = IdentityHelper.GetIdentityName() });
                cmd.Parameters.Add(new SqlParameter { ParameterName = "PaymentIdentifier", Value = paymentIdentifier });
                cmd.Parameters.Add(new SqlParameter { ParameterName = "IsTemp", Value = isTemp });

                cnn.Open();

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Logger.Error(ex, $"UpdatePaymentIdentifierIsTemp failed, PaymentIdentifier:{paymentIdentifier}");
                throw;
            }
        }
    }
}
