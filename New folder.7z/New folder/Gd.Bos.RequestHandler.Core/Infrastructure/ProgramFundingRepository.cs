﻿using System;
using Microsoft.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;
using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.ProgramFunding;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class ProgramFundingRepository : IProgramFundingRepository
    {
        public ProgramFundingRepository(IDataAccess dataAccess)
        {
            _dataAccess = dataAccess;
        }

        public ProgramFundingSource GetProgramInfoByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            var verificationParams = new[]
            {
                new SqlParameter() { ParameterName = "AccountIdentifier", Value = accountIdentifier.ToGuid(), SqlDbType = System.Data.SqlDbType.UniqueIdentifier }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetProductInfoByAccountIdentifier]", _dataAccess.CreateConnection(), verificationParams))
            {
                if (reader.Read())
                {
                    var programCode = (string)reader["ProgramCode"];
                    var programName = (string)reader["ProgramName"];
                    var productCode = (string)reader["ProductCode"];
                    var productName = (string)reader["ProductName"];
                    var accountStatus = (AccountStatus)reader.GetInt16(reader.GetOrdinal("AccountStatusKey"));
                    var productTierKey = (reader["ProductTierKey"] == DBNull.Value || reader["ProductTierKey"] == null) ? 0 : (int)reader["ProductTierKey"];
                    var productKey = (reader["ProductKey"] == DBNull.Value || reader["ProductKey"] == null) ? 0 : (int)reader["ProductKey"];
                    var partnerKey = (short)reader["PartnerKey"];

                    var result = new ProgramFundingSource(accountIdentifier, programCode, programName, productCode, productName, accountStatus, productTierKey, productKey);
                    result.PartnerKey = partnerKey;
                    return result;
                }

                //throw new Exception($"Could not get data for AccountIdentifier {accountIdentifier}");
                throw new Domain.Model.Transfers.Exceptions.AccountNotFoundException(10, 0, "Account Not Found.");
            }
        }

        public Partner GetPartnerInfoByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            var verificationParams = new[]
            {
                new SqlParameter() { ParameterName = "AccountIdentifier", Value = accountIdentifier.ToGuid(), SqlDbType = System.Data.SqlDbType.UniqueIdentifier }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetPartnerInfoByAccountIdentifier]", _dataAccess.CreateConnection(), verificationParams))
            {
                if (reader.Read())
                {
                    //var accountKey = (long)reader["AccountKey"];
                    var productKey = (int)reader["ProductKey"];
                    var partnerKey = (Int16)reader["PartnerKey"];
                    var partnerRoleType = (PartnerRoleType)Enum.Parse(typeof(PartnerRoleType), reader["PartnerRoleTypeKey"].ToString());
                    var partnerRoleKey = (Int16)reader["PartnerRoleKey"];

                    var partnerInfo = new Partner(partnerKey, "", partnerRoleType);
                    partnerInfo.PartnerRoleKey = partnerRoleKey;
                    partnerInfo.ProductKey = productKey;
                    partnerInfo.ProgramCode = reader["ProgramCode"].ToString();

                    return partnerInfo;
                }

                return null;
            }
        }



        private readonly IDataAccess _dataAccess;
    }
}
