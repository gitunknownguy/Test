﻿using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Utils;
using NLog;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using AccountHolder = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolder;
using System.Data;
using Amazon.Runtime.Internal;
using Gd.Bos.Shared.Common.Core.Logic;
using Gd.Bos.RequestHandler.Core.Domain.Enums;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class AccountHolderRepository : IAccountHolderRepository
    {
        private static readonly Logger _logger = LogManager.GetCurrentClassLogger();
        private string _userName = IdentityHelper.GetIdentityName();

        private IDataAccess _dataAccess;

        public AccountHolderRepository(IDataAccess dataAccess)
        {
            _dataAccess = dataAccess;
        }

        public long InsertAccountHolder(
            Guid accountHolderIdentifier,
            long accountKey,
            long consumerProfileKey,
            bool isPrimaryAccountHolder,
            bool isTransferAutoAccept,
            List<TermAcceptance> termAcceptances)
        {
            var accountHolderParams = new[]
            {
                new SqlParameter {ParameterName = "ConsumerProfileKey", Value = consumerProfileKey},
                new SqlParameter {ParameterName = "IsTransferAutoAccept", Value = isTransferAutoAccept},
                new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                new SqlParameter {ParameterName = "AccountKey", Value = accountKey},
                new SqlParameter
                {
                    ParameterName = "AccountHolderIdentifier",
                    Value = accountHolderIdentifier
                },
                new SqlParameter {ParameterName = "IsPrimaryAccountHolder", Value = isPrimaryAccountHolder}
            };

            object accountHolderKey = _dataAccess.ExecuteScalar("[dbo].[InsAccountHolder]",
                _dataAccess.CreateConnection(), accountHolderParams);

            if (termAcceptances != null)
            {

                foreach (var ta in termAcceptances)
                {
                    var termsParams = new[]
                    {
                            new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                            new SqlParameter
                            {
                                ParameterName = "AccountHolderKey",
                                Value = accountHolderKey
                            },
                            new SqlParameter {ParameterName = "AcceptanceDate", Value = ta.AcceptanceDate},
                            new SqlParameter {ParameterName = "ProductAgreementTypeKey", Value = ta.ProductAgreementTypeKey},
                            new SqlParameter {ParameterName = "OptoutDate", Value = ta.OptoutDate},
                            new SqlParameter {ParameterName = "HasAccepted", Value = ta.OptoutDate == null}
                        };
                    _dataAccess.ExecuteNonQuery("[dbo].[InsAccountHolderAgreement]", _dataAccess.CreateConnection(),
                        termsParams);
                }
            }

            return Convert.ToInt64(accountHolderKey);
        }

        /// <summary>
        /// Get AccountHolder instances related to user identified by userIdentifier (aka consumerProfileIdentifier)
        /// </summary>
        /// <param name="userIdentifier"></param>
        /// <returns>AccountHolders but only AccountHolderKey and AccountIdentifier populated</returns>
        public IList<AccountHolder> GetAccountHolder(Guid userIdentifier)
        {
            using (var cnn = _dataAccess.CreateConnectionWithColumnEncryption())
            {
                var cmd = cnn.CreateCommand();
                cmd.CommandText = "[dbo].[GetAccountHolderByConsumerProfileIdentifier]";
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ConsumerProfileIdentifier", userIdentifier);

                cnn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    return ReadAccountHolders(reader).ToList();
                }

            }
        }

        /// <summary>
        /// paymentInstrumentIdentifier
        /// </summary>
        /// <param name="paymentInstrumentIdentifier"></param>
        /// <returns></returns>
        public AccountHolderData GetAccountHolderByPaymentInstrumentIdentifier(Guid paymentInstrumentIdentifier)
        {
            var accountHolderParams = new[] {
                new SqlParameter() {  ParameterName = "@PaymentInstrumentIdentifier",Value = paymentInstrumentIdentifier}
            };
            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountHolderByPaymentInstrumentIdentifier]",
                _dataAccess.CreateConnection(),
                accountHolderParams))
            {
                return ReadAccountHolderData(reader);
            }
        }

        /// <summary>
        /// Get all account holders(Include individual or business account holder)
        /// </summary>
        /// <param name="paymentInstrumentIdentifier"></param>
        /// <returns></returns>
        public List<AccountHolderData> GetAccountHoldersByPaymentInstrumentIdentifier(Guid paymentInstrumentIdentifier)
        {
            List<AccountHolderData> accountHolders = new AutoConstructedList<AccountHolderData>();
            var accountHolderParams = new[] {
                new SqlParameter() {  ParameterName = "@PaymentInstrumentIdentifier",Value = paymentInstrumentIdentifier}
            };
            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountHolderByPaymentInstrumentIdentifier]",
                _dataAccess.CreateConnection(),
                accountHolderParams))
            {
                while (reader.Read())
                {
                    AccountHolderData accountHolder = new AccountHolderData()
                    {

                        CardHolderProxy = reader["CardHolderProxy"] != DBNull.Value ? reader["CardHolderProxy"].ToString() : null,
                        IsPrimaryAccountHolder = (bool)reader["IsPrimaryAccountHolder"],
                        AccountHolderIdentifier = (Guid)reader["AccountHolderIdentifier"],
                        IsTransferAutoAccept = (bool)reader["IsTransferAutoAccept"],
                        ConsumerProfileIdentifier = (Guid)reader["ConsumerProfileIdentifier"],
                        FirstName = reader["FirstName"] != DBNull.Value ? reader["FirstName"].ToString() : null,
                        MiddleName = reader["MiddleName"] != DBNull.Value ? reader["MiddleName"].ToString() : null,
                        LastName = reader["LastName"] != DBNull.Value ? reader["LastName"].ToString() : null,
                        ConsumerProfileType = (ConsumerProfileType?)reader["ConsumerProfileTypeKey"].Cast<short?>()
                    };
                    accountHolders.Add(accountHolder);
                }
            }

            return accountHolders;
        }

        public void UpdateAccountHolderCure(long accountHolderKey, short accountHolderCureKey)
        {
            _dataAccess.ExecuteNonQuery(
                "[UpdAccountHolderCureByAccountHolderKey]",
                _dataAccess.CreateConnection(),
                new SqlParameter("ChangeBy", _userName),
                new SqlParameter("AccountHolderKey", accountHolderKey),
                new SqlParameter("AccountHolderCureKey", accountHolderCureKey)
                );
        }
        private IEnumerable<AccountHolder> ReadAccountHolders(SqlDataReader reader)
        {
            while (reader.Read())
            {
                yield return ReadAccountHolder(reader);
            }
        }


        public void UpdatePaymentIdentifierStatusAndReason(long paymentIdentifierKey, PaymentIdentifierStatus identifierStatus, short? reason)
        {
            var accountParams = new[] {
                new SqlParameter() {  ParameterName = "@PaymentIdentifierKey",Value = paymentIdentifierKey},
                new SqlParameter() {ParameterName = "ChangeBy", Value = _userName},
                new SqlParameter() {ParameterName = "PaymentIdentifierStatusKey", Value = identifierStatus},
                new SqlParameter() {ParameterName = "PaymentIdentifierStatusReasonKey", Value = reason}
            };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdPaymentIdentifierStatusAndReason]", _dataAccess.CreateConnection(), accountParams);
        }
        public void UpdatePaymentIdentifier(long paymentIdentifierKey, PaymentIdentifierStatus identifierStatus, short? reason, string tokenizedPan, string last4Pan, string paymentIdentifierProxy)
        {
            var accountParams = new[] {
                new SqlParameter() {  ParameterName = "@PaymentIdentifierKey",Value = paymentIdentifierKey},
                new SqlParameter() {ParameterName = "ChangeBy", Value = _userName},
                new SqlParameter() {ParameterName = "PaymentIdentifierStatusKey", Value = identifierStatus},
                new SqlParameter() {ParameterName = "PaymentIdentifierStatusReasonKey", Value = reason},
                new SqlParameter() {ParameterName = "TokenizedPAN", Value = tokenizedPan},
                new SqlParameter() {ParameterName = "PaymentIdentifierProxy", Value = paymentIdentifierProxy},
                new SqlParameter() {ParameterName = "Last4PAN", Value = last4Pan}
            };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdPaymentIdentifierStatusAndReason]", _dataAccess.CreateConnection(), accountParams);
        }

        public void UpdateAccountHolderPaymentIdentifier(long paymentIdentifierKey, bool isActive)
        {
            var accountParams = new[] {
                new SqlParameter() {  ParameterName = "@PaymentIdentifierKey",Value = paymentIdentifierKey},
                new SqlParameter() {ParameterName = "ChangeBy", Value = _userName},
                new SqlParameter() {ParameterName = "IsActive", Value = isActive}
            };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdateAccountHolder_PaymentIdentifierByPaymentIdentifier]", _dataAccess.CreateConnection(), accountParams);
        }

        public void UpdPaymentInstrumentStatuses(List<PaymentInstrumentInfo> paymentInstruments, string source = null)
        {
            var cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "[dbo].[UpdPaymentInstrumentStatuses]";

            var dt = new DataTable();
            dt.Columns.Add("PaymentInstrumentIdentifier", typeof(Guid));
            dt.Columns.Add("PaymentInstrumentStatusKey", typeof(byte));
            dt.Columns.Add("PaymentInstrumentStatusReasonKey", typeof(byte));
            dt.Columns.Add("ActivationDate", typeof(DateTime));

            foreach (var pi in paymentInstruments)
            {
                var row = dt.NewRow();
                row["PaymentInstrumentIdentifier"] = pi.PaymentInstrumentIdentifier;
                row["PaymentInstrumentStatusKey"] = (int)pi.PaymentInstrumentStatus;
                row["PaymentInstrumentStatusReasonKey"] = pi.PaymentInstrumentStatusReason.HasValue
                    ? (object)(int)pi.PaymentInstrumentStatusReason
                    : DBNull.Value;
                row["ActivationDate"] = pi.ActivatedDateTime ?? (object)DBNull.Value;
                dt.Rows.Add(row);
            }

            cmd.Parameters.AddRange(
                new[]
                {
                    new SqlParameter() { ParameterName = "ChangeBy", Value = _userName },
                    new SqlParameter() { ParameterName = "PaymentInstrumentValue", Value=dt, SqlDbType= SqlDbType.Structured, TypeName = "[dbo].[typePaymentInstrument]" },
                    new SqlParameter() { ParameterName = "Source", Value=source, SqlDbType=SqlDbType.NVarChar, Size=100}
                });

            using (var conn = new SqlConnection(_dataAccess.ConnectionString))
            {
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteScalar();
            }
        }




        public void InsAccountHolderPaymentIdentifier(long accountHolderKey, long paymentIdentifierKey, bool isActive, string embossedName)
        {
            var cmd = new SqlCommand();

            cmd.CommandType = CommandType.StoredProcedure;

            cmd.CommandText = "[dbo].[InsAccountHolder_PaymentIdentifier]";

            cmd.Parameters.AddRange(
                new[]
                {
                    new SqlParameter("ChangeBy", _userName),
                    new SqlParameter() { ParameterName = "AccountHolderKey", SqlDbType = SqlDbType.BigInt, Value = accountHolderKey },
                    new SqlParameter() { ParameterName = "PaymentIdentifierKey", SqlDbType = SqlDbType.BigInt, Value = paymentIdentifierKey },
                    new SqlParameter() { ParameterName = "IsActive", SqlDbType = SqlDbType.Bit, Value = isActive },
                    new SqlParameter() { ParameterName = "EmbossedName", SqlDbType = SqlDbType.NVarChar, Value = embossedName,Size = 100},
                });

            using (var conn = new SqlConnection(_dataAccess.ConnectionString))
            {
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void SetPrimary(long accountHolderKey, bool isPrimary)
        {
            _dataAccess.ExecuteNonQuery(
                "[UpdAccountHolderPrimaryByAccountHolderKey]",
                _dataAccess.CreateConnection(),
                new SqlParameter("ChangeBy", _userName),
                new SqlParameter() { ParameterName = "AccountHolderKey", SqlDbType = SqlDbType.BigInt, Value = accountHolderKey },
                new SqlParameter() { ParameterName = "IsPrimary", SqlDbType = SqlDbType.Bit, Value = isPrimary }
            );
        }

        private AccountHolder ReadAccountHolder(SqlDataReader reader)
        {
            return new AccountHolder()
            {
                AccountHolderKey = reader.GetInt64(0),
                //AccountKey=reader.GetInt64(1),
                AccountIdentifier = reader.GetGuid(2)
            };
        }

        private AccountHolderData ReadAccountHolderData(IDataReader reader)
        {
            if (reader.Read())
            {
                return new AccountHolderData()
                {

                    CardHolderProxy = reader["CardHolderProxy"] != DBNull.Value ? reader["CardHolderProxy"].ToString() : null,
                    IsPrimaryAccountHolder = (bool)reader["IsPrimaryAccountHolder"],
                    AccountHolderIdentifier = (Guid)reader["AccountHolderIdentifier"],
                    IsTransferAutoAccept = (bool)reader["IsTransferAutoAccept"],
                    ConsumerProfileIdentifier = (Guid)reader["ConsumerProfileIdentifier"],
                    FirstName = reader["FirstName"] != DBNull.Value ? reader["FirstName"].ToString() : null,
                    MiddleName = reader["MiddleName"] != DBNull.Value ? reader["MiddleName"].ToString() : null,
                    LastName = reader["LastName"] != DBNull.Value ? reader["LastName"].ToString() : null
                };
            }

            return null;
        }

        public List<AccountHolder> GetAccountHolderCountByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            var accountHolders = new List<AccountHolder>();
            var accountHolderParams = new[] {
                new SqlParameter() {  ParameterName = "@AccountIdentifier",Value = accountIdentifier.ToString()}
            };
            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountHoldersByAccountIdentifier]",
                _dataAccess.CreateConnection(),
                accountHolderParams))
            {
                while (reader.Read())
                {
                    AccountHolder accountHolder = new AccountHolder()
                    {
                        AccountHolderKey = (long)reader["AccountHolderKey"],
                        IsPrimary = reader["IsPrimaryAccountHolder"] == DBNull.Value ? false : (bool)reader["IsPrimaryAccountHolder"],
                        AccountHolderCure = reader["AccountHolderCureKey"] == DBNull.Value
                        ? default(AccountHolderCure)
                        : (AccountHolderCure)Enum.Parse(typeof(AccountHolderCure),
                        reader["AccountHolderCureKey"].ToString()),
                        AccountHolderIdentifier = AccountHolderIdentifier.FromString(reader["AccountHolderIdentifier"].ToString())
                    };
                    accountHolders.Add(accountHolder);
                }
            }

            return accountHolders;
        }

        public List<AccountHolder> GetAccountHoldersByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            var accountHolders = new List<AccountHolder>();
            var accountHolderParams = new[] {
                new SqlParameter() {  ParameterName = "@AccountIdentifier",Value = accountIdentifier.ToString()}
            };
            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountHoldersByAccountIdentifierV2]",
                _dataAccess.CreateConnection(),
                accountHolderParams))
            {
                while (reader.Read())
                {
                    AccountHolder accountHolder = new AccountHolder()
                    {
                        AccountHolderKey = (long)reader["AccountHolderKey"],
                        IsPrimary = reader["IsPrimaryAccountHolder"] == DBNull.Value ? false : (bool)reader["IsPrimaryAccountHolder"],
                        AccountHolderCure = reader["AccountHolderCureKey"] == DBNull.Value
                            ? default(AccountHolderCure)
                            : (AccountHolderCure)Enum.Parse(typeof(AccountHolderCure),
                                reader["AccountHolderCureKey"].ToString()),
                        AccountHolderIdentifier = AccountHolderIdentifier.FromString(reader["AccountHolderIdentifier"].ToString()),
                        ConsumerProfileType = (ConsumerProfileType?)reader["ConsumerProfileTypeKey"].Cast<short?>()
                    };
                    accountHolders.Add(accountHolder);
                }
            }

            return accountHolders;
        }


        public void UpdateAccountHolderByAccountHolderIdentifier(AccountHolderIdentifier accountHolderIdentifier, bool isPrimaryAccountHolder)
        {
            try
            {
                var parameters = new[]
                {
                    new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                    new SqlParameter {ParameterName = "AccountHolderIdentifier",Value = accountHolderIdentifier.ToString()},
                    new SqlParameter {ParameterName = "IsPrimaryAccountHolder",Value = isPrimaryAccountHolder},
                };

                _dataAccess.ExecuteNonQuery("[dbo].[UpdAccountHolder]", _dataAccess.CreateConnection(), parameters);
            }
            catch (Exception ex)
            {
                throw new AccountHolderNotFoundException("Error updating account holders", ex);
            }
        }
    }
}
