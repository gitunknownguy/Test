﻿using System;
using System.Collections.Generic;
using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.Shared.Common.Messaging.ProcessorEventSchema.Translation.Model;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using NLog;
using RequestHandler.Core.Domain.Model.CurrecyCode;
using RequestHandler.Core.Infrastructure.Configuration;

namespace RequestHandler.Core.Infrastructure
{
    public class CurrencyCodeRepository : ICurrencyCodeRepository
    {
        private readonly IDataAccess _dataAccess;
        private readonly IMemoryCache _cache;
        private const string CacheKey = "CurrencyCodeCacheKey";
        private const string GetCurrencySP = "[dbo].[GetCurrency]";
        private static readonly Logger _logger = LogManager.GetCurrentClassLogger();
        private readonly CurrencyCodeRepositorySettings _settings;

        public CurrencyCodeRepository(
            IDataAccess dataAccess,
            IMemoryCache cache,
            IOptions<CurrencyCodeRepositorySettings> settings)
        {
            _dataAccess = dataAccess;
            _cache = cache;
            _settings = settings.Value;


        }

        public List<CurrencyCode> GetAllCurrencyCodes()
        {
            return _cache.GetOrCreate(CacheKey, entry =>
            {
                _logger.Info("GetAllCurrencyCodes -  The cache is empty, getting data from db");

                entry.SetAbsoluteExpiration(TimeSpan.FromMinutes(_settings.CurrencyCodeCacheExpirationInMinutes));

                entry.RegisterPostEvictionCallback((key, value, reason, state) =>
                {
                    _logger.Info($"GetAllCurrencyCodes - Cache entry with key '{key}' was removed. Reason: {reason}");
                });

                var currencyCodes = new List<CurrencyCode>();

                using (var reader = _dataAccess.ExecuteReader(GetCurrencySP, _dataAccess.CreateConnection()))
                {
                    while (reader.Read())
                    {
                        var currencyCode = new CurrencyCode
                        {
                            CurrencyKey = int.Parse(reader["CurrencyKey"].ToString()),
                            CountryCode = reader["CurrencyCode"].ToString(),
                            NumericCode = Convert.ToInt32(reader["NumericCode"]),
                            DecimalPlaces = reader["MinorUnit"] == DBNull.Value ? 0 : Convert.ToInt32(reader["MinorUnit"])
                        };
                        currencyCodes.Add(currencyCode);
                    }
                }

                _logger.Info("GetAllCurrencyCodes - Cache loaded successfully.");
                return currencyCodes;
            });
        }
    }
}
