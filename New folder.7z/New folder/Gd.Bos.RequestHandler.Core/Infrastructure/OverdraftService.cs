﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transactions;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Overdraft;
using RequestHandler.Core.Domain.Model.OverDraft;
using RequestHandler.Core.Domain.Services.Overdraft;
using Account = Gd.Bos.RequestHandler.Core.Domain.Model.Account.Account;

namespace RequestHandler.Core.Infrastructure
{
    public class OverdraftService : IOverdraftService
    {
        private ITermsAcceptanceRepository _termsAcceptanceRepository;
        protected readonly IRequestHandlerSettings _configuration;
        private int OdTermBrandAgreementTypeKey = 57;
        private string overdraftTerm = "overdraft";
        private readonly IOverdraftRepository _overdraftRepository;
        private readonly IOverDraftRORepository _overDraftRORepository;
        private readonly ITransactionsRORepository _transactionsRORepository;
        public OverdraftService(
            ITermsAcceptanceRepository termsAcceptanceRepository, 
            IRequestHandlerSettings settings,
            IOverdraftRepository overdraftRepository,
            IOverDraftRORepository overDraftRORepository,
            ITransactionsRORepository transactionsRORepository
                )
        {
            _termsAcceptanceRepository = termsAcceptanceRepository;
            _configuration = settings;
            _overdraftRepository = overdraftRepository;
            _overDraftRORepository = overDraftRORepository;
            _transactionsRORepository = transactionsRORepository;
        }

        public async Task<List<TermAcceptanceHistory>> GetOverdraftTermAcceptanceHistoryList(
           IEnumerable<string> accountHolderIdentifiers, string programCode)
        {
            var historyList = new List<TermAcceptanceHistory>();
            foreach (var accountHolderIdentifier in accountHolderIdentifiers)
            {
                var data = await GetOverdraftTermAcceptanceHistoryList(accountHolderIdentifier, programCode);
                historyList.AddRange(data);
            }

            return historyList;
        }

        public async Task<GetOverdraftTransactionsResponse> GetOverdraftTransactions(string accountIdentifier, string startDate, string endDate)
        {
            var result = new GetOverdraftTransactionsResponse();
            if (!string.IsNullOrEmpty(accountIdentifier))
            {
               result = _overdraftRepository.GetOverdraftTransactions(accountIdentifier, startDate, endDate);
            }

            return result;
        }

        public async Task<GetOverdraftTransactionsResponse> GetOverdraftFeeAuthTransactions(string accountIdentifier, string startDate, string endDate)
        {
            var result = new GetOverdraftTransactionsResponse();
            if(!string.IsNullOrEmpty(accountIdentifier))
            {
                result = _transactionsRORepository.GetOverdraftFeeAuthTransactions(accountIdentifier, startDate, endDate);
            }

            return result;
        }

        public async Task<List<GetAccountReinstatementInfoResponse>> GetAccountSubscriptionReinstatementInfo(long accountKey, DateTime startDate, DateTime endDate,
            int reinstatementReasonType)
        {
            var result = new List<GetAccountReinstatementInfoResponse>();

            result = _overdraftRepository.GetAccountSubscriptionReinstatementInfo(accountKey, startDate, endDate,
                reinstatementReasonType);

            return result;
        }

        public async Task<IEnumerable<TermAcceptanceHistory>> GetOverdraftTermAcceptanceHistoryList(string accountHolderIdentifier, string programCode)
        {

            Domain.Model.Brand.BrandAgreementType brandAgreementType = _overdraftRepository.GetOverdraftBrandAgreementTypeByIdentifier(overdraftTerm, programCode);
            if (brandAgreementType != null)
            {
                OdTermBrandAgreementTypeKey = brandAgreementType.BrandAgreementTypeKey;
            }
            var items = _termsAcceptanceRepository.GetTermAcceptanceHistoryList(accountHolderIdentifier, OdTermBrandAgreementTypeKey);
            var transformedHistoryList = items.OrderByDescending(p => p.AcceptanceDate).ThenByDescending(p => p.OptOutDate).Select(p => new TermAcceptanceHistory()
            {
                AccountHolderIdentifier = p.AccountHolderIdentifier,
                Date = p.OptOutDate ?? p.AcceptanceDate,
                Activity = p.OptOutDate == null ? "Opt-in" : "Opt-out"
            });
            return await Task.FromResult(transformedHistoryList);
        }
    }
}
