﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Utils;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.Data;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using NLog;
using RequestHandler.Core.Infrastructure.Configuration;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    [ExcludeFromCodeCoverage(Justification= "mainly handles infrastructure operations and external dependencies")]
    public class AsyncAccountBalanceRepository : IAsyncAccountBalanceRepository
    {
        private readonly IDataAccess _dataAccess;

        private readonly IMemoryCache _cache;
        private readonly AccountBalanceRepositorySettings _settings;
        private static readonly Logger _logger = LogManager.GetCurrentClassLogger();

        private const string GetAccountBalanceByAccountBalanceIdentifierSP = "[dbo].[GetAccountBalanceByAccountBalanceIdentifier]";


        public AsyncAccountBalanceRepository(
            IDataAccess dataAccess,
            IOptions<AccountBalanceRepositorySettings> settings,
            IMemoryCache cache)
        {
            _dataAccess = dataAccess;
            _settings = settings.Value;
            _cache = cache;
        }

        private readonly string _userName = IdentityHelper.GetIdentityName();

        public AccountBalance GetAccountBalanceByAccountBalanceIdentifier(AccountBalanceIdentifier accountBalanceIdentifier)
        {
            throw new NotImplementedException();
        }

        public AccountBalance GetPrimaryAccountBalanceByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public List<AccountBalance> GetAccountBalanceByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public List<AccountBalance> GetAccountBalancesByAciExternalAccountIdentifier(string aciAccountIdentifier)
        {
            throw new NotImplementedException();
        }

        public void Update(AccountBalance accountBalance)
        {
            throw new NotImplementedException();
        }

        public async Task UpdateForAci(AccountBalance accountBalance, DateTime availableBalanceAsOfDate, DateTime ledgerBalanceAsOfDate)
        {
            var parameters = new[]
{
                new SqlParameter() { ParameterName = "AccountBalanceIdentifier", SqlDbType = SqlDbType.UniqueIdentifier, Value = accountBalance.AccountBalanceIdentifier.ToGuid() },
                new SqlParameter() { ParameterName = "AvailableBalance", SqlDbType = SqlDbType.Money, Value = accountBalance.AvailableBalance },
                new SqlParameter() { ParameterName = "AvailableBalanceAsOfDate", SqlDbType = SqlDbType.DateTime2, Value = availableBalanceAsOfDate },
                new SqlParameter() { ParameterName = "LedgerBalance", SqlDbType = SqlDbType.Money, Value = accountBalance.CurrentBalance },
                new SqlParameter() { ParameterName = "LedgerBalanceAsOfDate", SqlDbType = SqlDbType.DateTime2, Value = ledgerBalanceAsOfDate }
            };

            using(var connection = _dataAccess.CreateConnection())
            {
                await _dataAccess.ExecuteNonQueryAsync("[dbo].[UpdAccountBalanceByAccountBalanceIdentifierForACI]", CommandType.StoredProcedure, connection, default, parameters);
            }
        }

        public int UpdateForAci(Guid accountBalanceIdentifier, decimal availableBalance, DateTime availableBalanceAsOfDate, decimal ledgerBalance, DateTime ledgerBalanceAsOfDate)
        {
            throw new NotImplementedException();
        }

        public void UpdateAccountBalanceStatus(string accountBalanceIdentifier, AccountBalanceStatus accountBalanceStatus, bool? isHidden = null)
        {
            throw new NotImplementedException();
        }
    }
}
