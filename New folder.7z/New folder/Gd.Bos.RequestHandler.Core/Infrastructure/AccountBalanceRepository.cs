﻿using System;
using System.Collections.Generic;
using System.Data;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Utils;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.Data;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using NLog;
using RequestHandler.Core.Infrastructure.Configuration;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class AccountBalanceRepository : IAccountBalanceRepository
    {
        private readonly IDataAccess _dataAccess;

        private readonly IMemoryCache _cache;
        private readonly AccountBalanceRepositorySettings _settings;
        private static readonly Logger _logger = LogManager.GetCurrentClassLogger();

        private const string GetAccountBalanceByAccountBalanceIdentifierSP = "[dbo].[GetAccountBalanceByAccountBalanceIdentifier]";


        public AccountBalanceRepository(
            IDataAccess dataAccess,
            IOptions<AccountBalanceRepositorySettings> settings,
            IMemoryCache cache)
        {
            _dataAccess = dataAccess;
            _settings = settings.Value;
            _cache = cache;
        }

        public AccountBalance GetAccountBalanceByAccountBalanceIdentifier( 
            AccountBalanceIdentifier accountBalanceIdentifier )
        {
            return _cache.GetOrCreate(accountBalanceIdentifier.ToGuid(), entry =>
            {
                _logger.Info("GetAccountBalanceByAccountBalanceIdentifier - " +
                    "The cache is empty, getting data from db. " +
                    $"AccountBalanceIdentifier: {accountBalanceIdentifier}");

                entry.SetAbsoluteExpiration(TimeSpan.FromMilliseconds(_settings.AccountBalanceCacheExpirationInMilliseconds));

                entry.RegisterPostEvictionCallback((key, value, reason, state) =>
                {
                    _logger.Info($"GetAccountBalanceByAccountBalanceIdentifier - Cache entry with key '{key}' was removed. Reason: {reason}");
                });

                var parameters = new[]
                {
                    new SqlParameter()
                    {
                        ParameterName = "AccountBalanceIdentifier",
                        Value = Guid.Parse(accountBalanceIdentifier.ToString())
                    }
                };

                AccountBalance accountBalance = null;

                using (var reader = _dataAccess.ExecuteReader(
                    GetAccountBalanceByAccountBalanceIdentifierSP, 
                    _dataAccess.CreateConnection(),
                    parameters))
                {
                    if (!reader.Read()) 
                    {
                        return null;
                    }

                    var currentBalance = reader.GetDecimal(reader.GetOrdinal("LedgerBalance"));
                    var currentBalanceAsOfDate = reader.GetDateTime(reader.GetOrdinal("LedgerBalanceAsOfDate"));
                    var availableBalance = reader.GetDecimal(reader.GetOrdinal("AvailableBalance"));
                    var availableBalanceAsOfDate = reader.GetDateTime(reader.GetOrdinal("AvailableBalanceAsOfDate"));
                    var isPrimary = reader.GetInt16(reader.GetOrdinal("CurrencyKey")) == 1;
                    var isHolding = reader.GetInt16(reader.GetOrdinal("CurrencyKey")) == 3;
                    var purseStatus = (PurseStatus)reader.GetInt16(reader.GetOrdinal("AccountBalanceStatusKey"));
                    var createDate = reader.GetDateTime(reader.GetOrdinal("CreateDate"));
                    var changeDate = reader.GetDateTime(reader.GetOrdinal("ChangeDate"));
                    var productKey = (int)reader.GetInt64(reader.GetOrdinal("ProductKey"));
                    var accountBalanceTypeKey = (PurseType)reader.GetInt16(reader.GetOrdinal("AccountBalanceTypeKey"));
                    var accountBalanceKey = reader.GetInt64(reader.GetOrdinal("AccountBalanceKey"));

                    accountBalance = new AccountBalance(accountBalanceIdentifier, isPrimary, isHolding, status: purseStatus);

                    accountBalance.SetAvailableBalance(availableBalance, availableBalanceAsOfDate);
                    accountBalance.SetCurrentBalance(currentBalance, currentBalanceAsOfDate);
                    accountBalance.ProductKey = productKey;
                    accountBalance.PurseType = accountBalanceTypeKey;
                    accountBalance.AccountBalanceKey = accountBalanceKey;
                    accountBalance.CreateDate = createDate;
                    accountBalance.ChangeDate = changeDate;
                }

                _logger.Info("GetAccountBalanceByAccountBalanceIdentifier - " +
                    "Cache loaded successfully. " +
                    $"AccountBalanceIdentifier: {accountBalanceIdentifier}");

                return accountBalance;
            });
        }

        public AccountBalance GetPrimaryAccountBalanceByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            var parameters = new[]
            {
                new SqlParameter()
                {
                    ParameterName = "AccountIdentifier",
                    Value = Guid.Parse(accountIdentifier.ToString())
                }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetPrimaryAccountBalanceByAccountIdentifier]",
                _dataAccess.CreateConnection(), parameters))
            {
                if (reader.Read())
                {
                    if (!reader.IsDBNull(0))
                    {
                        return GetAccountBalanceByAccountBalanceIdentifier(AccountBalanceIdentifier.FromGuid(reader.GetGuid(0)));
                    }
                }
            }

            return null;
        }

        public List<AccountBalance> GetAccountBalancesByAciExternalAccountIdentifier(string aciAccountIdentifier)
        {
            var result = new List<AccountBalance>();
            var parameters = new[]
            {
                new SqlParameter
                {
                    ParameterName = "ACIAccountExternalID",
                    Value = aciAccountIdentifier
                }
            };

            using var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountBalanceByACIAccountExternalID]",
                _dataAccess.CreateConnection(), parameters);

            while (reader.Read())
            {
                var accountBalanceIdentifier = reader.GetGuid(3);
                var currentBalance = reader.GetDecimal(6);
                var currentBalanceAsOfDate = reader.GetDateTime(7);
                var availableBalance = reader.GetDecimal(8);
                var availableBalanceAsOfDate = reader.GetDateTime(9);
                var isPrimary = reader.GetInt16(4) == 1;
                var isHolding = reader.GetInt16(4) == 3;
                var purseStatus = (PurseStatus)reader.GetInt16(10);
                var createDate = reader.GetDateTime(1);
                var changeDate = reader.GetDateTime(2);

                var accountBalance = new AccountBalance(
                    AccountBalanceIdentifier.FromGuid(accountBalanceIdentifier),
                    isPrimary,
                    isHolding,
                    status: purseStatus);

                accountBalance.SetAvailableBalance(availableBalance, availableBalanceAsOfDate);
                accountBalance.SetCurrentBalance(currentBalance, currentBalanceAsOfDate);
                accountBalance.ProductKey = (int)reader.GetInt32(13);
                accountBalance.PurseType = (PurseType)reader.GetInt16(4);
                accountBalance.AccountBalanceKey = reader.GetInt64(0);
                accountBalance.CreateDate = createDate;
                accountBalance.ChangeDate = changeDate;

                result.Add(accountBalance);
            }

            return result;
        }

        public void Update(AccountBalance accountBalance)
        {
            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "ChangeBy", SqlDbType = SqlDbType.NVarChar, Size = 100, Value = _userName },
                new SqlParameter() { ParameterName = "AccountBalanceIdentifier", SqlDbType = SqlDbType.UniqueIdentifier, Value = accountBalance.AccountBalanceIdentifier.ToGuid() },
                new SqlParameter() { ParameterName = "AvailableBalance", SqlDbType = SqlDbType.Money, Value = accountBalance.AvailableBalance },
                new SqlParameter() { ParameterName = "LedgerBalance", SqlDbType = SqlDbType.Money, Value = accountBalance.CurrentBalance }
            };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdAccountBalanceByAccountBalanceIdentifier]", _dataAccess.CreateConnection(), parameters);
        }

        public void UpdateForAci(AccountBalance accountBalance, DateTime availableBalanceAsOfDate, DateTime ledgerBalanceAsOfDate)
        {
            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "AccountBalanceIdentifier", SqlDbType = SqlDbType.UniqueIdentifier, Value = accountBalance.AccountBalanceIdentifier.ToGuid() },
                new SqlParameter() { ParameterName = "AvailableBalance", SqlDbType = SqlDbType.Money, Value = accountBalance.AvailableBalance },
                new SqlParameter() { ParameterName = "AvailableBalanceAsOfDate", SqlDbType = SqlDbType.DateTime2, Value = availableBalanceAsOfDate },
                new SqlParameter() { ParameterName = "LedgerBalance", SqlDbType = SqlDbType.Money, Value = accountBalance.CurrentBalance },
                new SqlParameter() { ParameterName = "LedgerBalanceAsOfDate", SqlDbType = SqlDbType.DateTime2, Value = ledgerBalanceAsOfDate }
            };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdAccountBalanceByAccountBalanceIdentifierForACI]", _dataAccess.CreateConnection(), parameters);
        }

        public int UpdateForAci(Guid accountBalanceIdentifier, decimal availableBalance, DateTime availableBalanceAsOfDate,
            decimal ledgerBalance, DateTime ledgerBalanceAsOfDate)
        {
            var parameters = new[]
            {
                new SqlParameter { ParameterName = "AccountBalanceIdentifier", SqlDbType = SqlDbType.UniqueIdentifier, Value = accountBalanceIdentifier },
                new SqlParameter { ParameterName = "AvailableBalance", SqlDbType = SqlDbType.Money, Value = availableBalance },
                new SqlParameter { ParameterName = "AvailableBalanceAsOfDate", SqlDbType = SqlDbType.DateTime2, Value = availableBalanceAsOfDate },
                new SqlParameter { ParameterName = "LedgerBalance", SqlDbType = SqlDbType.Money, Value = ledgerBalance },
                new SqlParameter { ParameterName = "LedgerBalanceAsOfDate", SqlDbType = SqlDbType.DateTime2, Value = ledgerBalanceAsOfDate }
            };

            return _dataAccess.ExecuteNonQuery("[dbo].[UpdAccountBalanceByAccountBalanceIdentifierForACI]", _dataAccess.CreateConnection(), parameters);
        }


        public List<AccountBalance> GetAccountBalanceByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            var response = new List<AccountBalance>();
            var parameters = new[]
            {
                new SqlParameter() {ParameterName = "AccountIdentifier", Value = (Guid) accountIdentifier}
            };
            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountBalanceByAccountIdentifier]",
                _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    var accountBalanceKey = reader.GetInt64(0);
                    var accountBalanceIdentifier = reader.GetGuid(1);
                    var currentBalance = reader.GetDecimal(5);
                    var currentBalanceAsOfDate = reader.GetDateTime(6);
                    var availableBalance = reader.GetDecimal(7);
                    var availableBalanceAsOfDate = reader.GetDateTime(8);
                    var isPrimary = reader.GetInt16(2) == 1;
                    var isHolding = reader.GetInt16(2) == 3;
                    var userDescription = reader["UserDescription"] == DBNull.Value ? null : reader["UserDescription"].ToString();
                    bool isHidden = reader["IsHidden"] == DBNull.Value ? false : ((bool)reader["IsHidden"]);
                    PurseStatus status = (PurseStatus)(short)reader["AccountBalanceStatusKey"];
                    decimal? goalAmount = reader["GoalAmount"] == DBNull.Value ? null : (decimal?)reader["GoalAmount"];
                    string iconName = reader["IconName"] == DBNull.Value ? null : reader["IconName"].ToString();
                    int productKey = reader["ProductKey"] == DBNull.Value ? 0 : (int)reader["ProductKey"];
                    DateTime? createDate = reader["CreateDate"] == DBNull.Value ? null : (DateTime?)reader["CreateDate"];
                    DateTime? changeDate = reader["ChangeDate"] == DBNull.Value ? null : (DateTime?)reader["ChangeDate"];
                    string purseNumber = reader["AccountBalanceNumber"] == DBNull.Value ? null : reader["AccountBalanceNumber"].ToString();
                    PurseType purseType = (PurseType)(short)reader["AccountBalanceTypeKey"];
                    var accountBalance = new AccountBalance(AccountBalanceIdentifier.FromGuid(accountBalanceIdentifier), isPrimary, isHolding, userDescription, isHidden, status, goalAmount, iconName, productKey, createDate, changeDate, purseNumber, purseType);

                    accountBalance.Currency = ((Domain.Model.Transfers.Currency)(reader["CurrencyKey"] == DBNull.Value ? 1 : (Int16)reader["CurrencyKey"])).ToString();
                    accountBalance.SetAvailableBalance(availableBalance, availableBalanceAsOfDate);
                    accountBalance.SetCurrentBalance(currentBalance, currentBalanceAsOfDate);
                    accountBalance.AccountBalanceKey = accountBalanceKey;

                    response.Add(accountBalance);
                }
            }

            return response;
        }

        public void UpdateAccountBalanceStatus(string accountBalanceIdentifier, AccountBalanceStatus accountBalanceStatus, bool? isHidden = null)
        {
            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "ChangeBy", SqlDbType = SqlDbType.NVarChar, Size = 100, Value = _userName },
                new SqlParameter() { ParameterName = "AccountBalanceIdentifier", SqlDbType = SqlDbType.UniqueIdentifier, Value = Guid.Parse(accountBalanceIdentifier) },
                new SqlParameter() { ParameterName = "AccountBalanceStatusKey", SqlDbType = SqlDbType.SmallInt, Value = accountBalanceStatus },
                new SqlParameter() { ParameterName = "IsHidden", SqlDbType = SqlDbType.Bit, Value = isHidden }
            };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdAccountBalanceStatus]", _dataAccess.CreateConnection(), parameters);
        }

        private readonly string _userName = IdentityHelper.GetIdentityName();
    }
}
