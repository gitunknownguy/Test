﻿//using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using RequestHandler.Core.Domain.Model.Account;
using Account = Gd.Bos.RequestHandler.Core.Domain.Model.Account.Account;
using AccountHolder = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolder;
using AccountHolderCure = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolderCure;
using AccountStatus = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountStatus;
using AccountStatusReason = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountStatusReason;
using SourceSystem = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.SourceSystem;
using VerificationActivityType = Gd.Bos.RequestHandler.Core.Domain.Model.Account.VerificationActivityType;
using VerificationStatus = Gd.Bos.RequestHandler.Core.Domain.Model.Account.VerificationStatus;
using BinType = Gd.Bos.RequestHandler.Core.Domain.Enums.BinType;
using User = Gd.Bos.RequestHandler.Core.Domain.Model.User.User;
using RequestHandler.Core.Domain.Model.Upgrade;
using FeeType = Gd.Bos.Shared.Common.Logic.FeatureLimitsFees.Contract.Enum.FeeType;
using RequestHandler.Core.Domain.Model.Product;
using GetEnrollmentResponse = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.GetEnrollmentResponse;
using RequestHandler.Core.Domain.Model.CollectionAccount;
using RequestHandler.Core.Domain.Model.Showcase;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class MockAccountRepository : IAccountRepository
    {
        public MockAccountRepository()
        {
            _storage = new ConcurrentDictionary<string, Account>();
        }

        public AccountIdentifier NextAccountIdentifier()
        {
            return AccountIdentifier.FromGuid(Guid.NewGuid());
        }

        public void Add(Account account)
        {
            if (!_storage.TryAdd(account.AccountIdentifier.ToString(), account))
                throw new Exception("AccountIdentifier already exists.");
        }

        public Account GetByAccountIdentifier(AccountIdentifier accountIdentifier,Boolean replaceByChildAccountHolder = false)
        {
            if (!_storage.TryGetValue(accountIdentifier.ToString(), out var account))
                throw new Exception("No Account exists with the specified AccountIdentifier.");

            return account;
        }

        public Tuple<Account, List<PaymentIdentifierInfo>, List<PaymentInstrumentInfo>> GetPaymentIdentifierInfoByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            return new Tuple<Account, List<PaymentIdentifierInfo>, List<PaymentInstrumentInfo>>(
                new Account()
                {
                    AccountKey = 123,
                    Product = new Product(ProductCode.FromString("30007"), ProgramCode.FromString("gbr"), 11, null, null, null)

                },
                new List<PaymentIdentifierInfo>(){new PaymentIdentifierInfo()
                {
                    PaymentIdentifierIdentifier = Guid.NewGuid(),
                    PaymentIdentifierStatus = PaymentIdentifierStatus.Activated
                }},
                new List<PaymentInstrumentInfo>()
                { new PaymentInstrumentInfo()
                {
                    PaymentInstrumentIdentifier = Guid.NewGuid(),
                    PaymentInstrumentStatus = PaymentInstrumentStatus.NotActivated
                }}
            );
        }

        public Account GetByAccountIdentifierWithPrimaryUser(AccountIdentifier accountIdentifier, ref string firstName,
            ref string lastName)
        {
            firstName = "Mock";
            lastName = "Implementation";
            if (!_storage.TryGetValue(accountIdentifier.ToString(), out var account))
                throw new Exception("No Account exists with the specified AccountIdentifier.");

            return account;
        }

        public int GetProcessorKeyByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public AccountBalanceIdentifier NextAccountBalanceIdentifier()
        {
            return AccountBalanceIdentifier.FromString(Guid.NewGuid().ToString());
        }

        public AccountHolderIdentifier NextAccountHolderIdentifier()
        {
            return AccountHolderIdentifier.FromString(Guid.NewGuid().ToString());
        }

        public VerificationRequestIdentifier NextVerificationRequestIdentifier()
        {
            return VerificationRequestIdentifier.FromString(Guid.NewGuid().ToString());
        }

        public void CreateVerificationRequest(Account account, Dictionary<VerificationActivityType, VerificationStatus> type)
        {
            throw new NotImplementedException();
        }

        public AccountStatusAndBalances GetAccountStatusAndBalancesByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public void UpdateVerificationRequest(Account account, AccountHolder ah, Dictionary<VerificationActivityType, VerificationStatus> verifyList, VerificationStatus verificationStatus, List<AccountStatusReason> statusReasons, Dictionary<int, Tuple<VerificationActivityType, VerificationStatus, List<VerificationStatusReason>>> resultData, bool isJointAccount = false, bool isHardDeclined = false, bool isNeededToUpdateAccountStatus = true)
        {
            throw new NotImplementedException();
        }

        public void UpdateVerificationRequest(Account account, AccountHolder ah,
            Dictionary<VerificationActivityType, VerificationStatus> verifyList,
            VerificationStatus verificationStatus, Dictionary<int, Tuple<VerificationActivityType, VerificationStatus, List<VerificationStatusReason>>>
                resultData, bool updateAccountHolderCure, AccountHolderCure upgradeCure)
        {
            throw new NotImplementedException();
        }


        public CreateVerifyRequest GetIdvInfoByAccountIdentifierUserIdentifier(CreateVerifyRequest createVerifyRequest)
        {
            throw new NotImplementedException();
        }

        public void SetBillingCycleDate(string accountIdentifier, int billingCycleDate, DateTime activationDate, DateTime firstBillingCycleDate)
        {

        }

        public Tuple<Account, User> GetAccountInfoForFraud(AccountIdentifier accountIdentifier, string programCode = null)
        {
            throw new NotImplementedException();
        }

        public void OverrideAccountStatus(Account account, VerificationActivity verificationActivity,
            List<VerificationStatusReason> verificationStatusReason, AccountStatus status, IList<AccountStatusReason> reasonsToAdd,
            IList<AccountStatusReason> reasonsToRemove, SourceSystem? source = null)
        {
            throw new NotImplementedException();
        }

        public void CreateVerificationActivity(Account account, Dictionary<VerificationActivityType, VerificationStatus> verifyList, TriggerType triggerType)
        {
            throw new NotImplementedException();
        }


        public void UpdateAccountStatus(Account account, AccountStatus status, IList<AccountStatusReason> reasons)
        {
            throw new NotImplementedException();
        }

        public void UpdateAccountStatus(Account account, AccountStatus status, IList<AccountStatusReason> reasonsToAdd, IList<AccountStatusReason> reasonsToRemove, SourceSystem? source = null)
        {
            throw new NotImplementedException();
        }

        public Account GetAccountInfoByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public void CreateVerificationRequest(Account account, Dictionary<VerificationActivityType, VerificationStatus> type, TriggerType triggerType)
        {
            throw new NotImplementedException();
        }

        public Tuple<List<VerificationActivity>, long> ReturnVerificationActivities(AccountHolderIdentifier accountHolderIdentifier)
        {
            throw new NotImplementedException();
        }

        public VerificationActivity ReturnVerificationActivity(AccountHolderIdentifier accountHolderIdentifier, VerificationActivityType activityType)
        {
            throw new NotImplementedException();
        }

        public Tuple<Account, string> GetAccountByPaymentIdentifierProxy(string piProxy)
        {
            throw new NotImplementedException();
        }

        public Dictionary<string, List<Account>> GetAccountByPaymentIdentifierProxyList(List<string> proxyList)
        {
            throw new NotImplementedException();
        }

        public CreateVerifyRequest GetIdvInfoByAccountIdentifierUserIdentifier(CreateVerifyRequest createVerifyRequest, VerificationActivityType activityType, bool isSecondCip)
        {
            throw new NotImplementedException();
        }

        public AccountPrimaryConsumerProfile GetAccountPrimaryConsumerProfile(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public AccountPrimaryConsumerProfile GetAccountPrimaryConsumerProfile(AccountIdentifier accountIdentifier, Guid userIdentifier)
        {
            throw new NotImplementedException();
        }

        public AccountPrimaryConsumerProfile GetAccountPrimaryConsumerProfileAnyToken(AccountIdentifier accountIdentifier, string programCode = null)
        {
            throw new NotImplementedException();
        }

        public string GetAccountPrimaryPhoneNumber(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public AccountPrimaryConsumerProfile GetAccountPrimaryConsumerProfileAnyToken(AccountIdentifier accountIdentifier, Guid userIdentifier)
        {
            throw new NotImplementedException();
        }

        public AccountPrimaryConsumerProfile GetAccountConsumerProfile(string deviceTokenId)
        {
            throw new NotImplementedException();
        }

        public void UpdateDeviceProvisioningMessage(string deviceIdentifier, string DPAN, string FPAN)
        {
            throw new NotImplementedException();
        }

        public AccountPrimaryConsumerProfile GetAccountConsumerProfile(Guid? accountIdentifier, Guid? consumerProfileIdentifier,
          Guid? accountHolderIdentifier)
        {
            throw new NotImplementedException();
        }

        public AccountLimit VerifyAccountLimitByProduct(string ssnToken, string productCode, string accountCure)
        {
            throw new NotImplementedException();
        }

        public void UpdateAdhocVerificationReason(Account account, AccountHolder ah, Dictionary<int, Tuple<VerificationActivityType, VerificationStatus, List<VerificationStatusReason>>> resultData)
        {
            throw new NotImplementedException();
        }

        public void CreateAdHocVerificationRequest(AccountHolder ah, long prodKey, Dictionary<VerificationActivityType, VerificationStatus> verifyList, TriggerType triggerType, short verificationStatusKey = 1)
        {
            throw new NotImplementedException();
        }
        public List<Tuple<Account, User>> GetAccountInfoByPhoneNumber(string phone)
        {
            throw new NotImplementedException();
        }

        public Account GetAccountInfoByAccountIdentifierWithNoPaymentIdentifier(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public void UpdateAccountToken(string accountIdentifier, string partnerAccountIdentifier)
        {
            throw new NotImplementedException();
        }

        UserProfileIdentity IAccountRepository.ReadUserProfileIdentity(IDataReader reader, IdentityType identityType)
        {
            return ReadUserProfileIdentity(reader, identityType);
        }

        private UserProfileIdentity ReadUserProfileIdentity(IDataReader reader, IdentityType identityType)
        {
            throw new NotImplementedException();
        }

        public (AccountStatus, List<AccountStatusReason>, AccountHolderCure) GetStatus(Guid accountIdentifier)
        {
            return (AccountStatus.Normal, null, AccountHolderCure.Unknown);
        }

        public List<Tuple<short, long, DateTime?>> GetAccountDetails(AccountIdentifier accountIdentifier, ProgramCode programCode)
        {
            throw new NotImplementedException();
        }

        public AdditionalAccountLimit GetAccountStatusByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public Tuple<User, List<UserProfileIdentity>> GetUserByAccountHolderIdentifier(string accountHolderIdentifier)
        {
            throw new NotImplementedException();
        }

        public void UpdateIsPrimaryAccountHolder(string accountHolderIdentifier)
        {
            throw new NotImplementedException();
        }

        public void CreateVerificationRequestFromSetStatus(Account account, AccountHolder ah, Dictionary<VerificationActivityType, VerificationStatus> verifyList, TriggerType triggerType)
        {
            throw new NotImplementedException();
        }

        public void OverrideAccountStatus(Account account, VerificationActivity verificationActivity, List<VerificationStatusReason> verificationStatusReasons, AccountStatus status, IList<AccountStatusReason> reasonsToAdd, IList<AccountStatusReason> reasonsToRemove, SourceSystem? source = null, bool isJoint = false)
        {
            throw new NotImplementedException();
        }

        public Account GetKeysByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public Account GetAdditionalHolderAccountByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public void Link(AccountLink accountLink)
        {
            throw new NotImplementedException();
        }

        public List<AccountLink> GetLinkedAccounts(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }
        public List<AccountLink> GetLinkedAccountsCached(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public List<AccountLinkDetail> GetLinkedAccountDetails(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public List<Tuple<long, DateTime?>> GetAccountDetailsByLinkedAccountIdentifier(AccountIdentifier accountIdentifier, ProgramCode programCode)
        {
            throw new NotImplementedException();
        }
       

        public Tuple<AccountHolder, int, int> GetAdditionalHolderAccountByAccountHolderIdentifier(string accountHolderIdentifier)
        {
            throw new NotImplementedException();
        }

        public void UpdateVerificationRequestAdditionalHolder(Account account, AccountHolder ah, VerificationStatus verificationStatus, Dictionary<int, Tuple<VerificationActivityType, VerificationStatus, List<VerificationStatusReason>>> resultData)
        {
            throw new NotImplementedException();
        }

        public List<Account> GetAccountsBySccAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public List<Account> GetAccountInfoByConsumerIdentifierProductCodes(string consumerIdentifier, List<string> productCodes)
        {
            throw new NotImplementedException();
        }

        public List<AccountIdentity> GetAccountStatusAndIdentity(string consumerIdentifier, string accountIdentifier, List<string> productCodes)
        {
            throw new NotImplementedException();
        }

        public List<Account> GetAccountBalanceBySccAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }
        public void UpdateLinkAccount(long accountLinkKey)
        {
            throw new NotImplementedException();
        }

        public short GetProductTierClassByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public List<AccountStatusReason> GetActiveAccountStatusReasons(AccountIdentifier account)
        {
            throw new NotImplementedException();
        }

        public Shared.Common.Core.CoreApi.Contract.Message.Response.GetPursesResponse GetPurses(string accountIdentifier, string programCode)
        {
            throw new NotImplementedException();
        }

        public void DeCache(List<string> cacheKey)
        {
            throw new NotImplementedException();
        }

        public List<Account> GetAccountsBySsnToken(string ssnToken)
        {
            throw new NotImplementedException();
        }

        public Guid GetAccountIdentifierByTokenizedPan(string tokenizedPan)
        {
            throw new NotImplementedException();
        }

        public List<AccountCardStatus> GetAccountCardStatus(List<Guid> accountIdentifiers)
        {
            throw new NotImplementedException();
        }

        public List<AccountHolderInfo> GetJointAccountHolderListByAccountIdentifier(Guid accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public void VerifyEmailLimitByProgram(string programCode, string email, int responseCodeWhenThrowException, long? accountKey = null)
        {
            throw new NotImplementedException();
        }

        public void InsertAccountStatusReason(AccountIdentifier accountIdentifier, IList<AccountStatusReason> reasonsToAdd)
        {
            throw new NotImplementedException();
        }

        public void RemoveAccountStatusReason(AccountIdentifier accountIdentifier, IList<AccountStatusReason> reasonsToRemove)
        {
            throw new NotImplementedException();
        }

        public AccountForCBS GetAccountByAccountIdentifierForCBS(string AccountIdentifier)
        {
            throw new NotImplementedException();
        }

        public AccountForShowcase GetAccountByAccountIdentifierForShowcase(string accountIdentifier)
        {
            if (!_storage.TryGetValue(accountIdentifier.ToString(), out var account))
                throw new Exception("No Account exists with the specified AccountIdentifier.");

            return new AccountForShowcase
            {
                AccountIdentifier = account.AccountIdentifier.ToString()
            };
        }

        public void CreateVerificationRequestForBenificialOwner(Account account, AccountHolder accountHolder, Dictionary<VerificationActivityType, VerificationStatus> verifyList, TriggerType triggerType)
        {
            throw new NotImplementedException();
        }

        Tuple<Guid, string> IAccountRepository.GetAccountIdentifierByTokenizedPan(string tokenizedPan)
        {
            throw new NotImplementedException();
        }

        public void UpdateAccountNumber(Guid accountIdentifier, string accountNumber)
        {
            throw new NotImplementedException();
        }

        public List<ConsumerProfile> GetConsumerProfiles(Guid accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public void UpdateCardEmbossName(Guid paymentIdentifier, string embossedName)
        {
            throw new NotImplementedException();
        }

        public AccountBillCycleInfo GetAccountBillCycle(string accountIdentifier, long accountKey = 0)
        {
            throw new NotImplementedException();
        }

        public AccountPrimaryConsumerProfile GetAccountConsumerProfileByTokenizedPan(string tokenizedPan)
        {
            throw new NotImplementedException();
        }

        public AccountPrimaryConsumerProfile GetAccountPrimaryConsumerProfileAnyTokenWithMultipleAddresses(AccountIdentifier accountIdentifier, Guid userIdentifier)
        {
            throw new NotImplementedException();
        }

        public List<Tuple<int, string>> GetIdentityTokenByAccountIdentity(string accountIdentifier, string programCode)
        {
            throw new NotImplementedException();
        }

        public List<Guid> GetAccountIdentitisByIdentityToken(List<Tuple<int, string>> identityTokens)
        {
            throw new NotImplementedException();
        }

        public void InsAccountFeeTypeOverRide(AccountFeeTypeOverRide accountFeeTypeOverRide)
        {
            throw new NotImplementedException();
        }

        public List<AccountFeeTypeOverRide> GetAccountFeeTypeOverRideByAccountKeys(List<long> accountKey, FeeType feeType)
        {
            throw new NotImplementedException();
        }

        public void UpdAccountFeeTypeOverRide(long AccountFeeTypeOverRideKey, DateTime OverRideEndDate)
        {
            throw new NotImplementedException();
        }

        public ProductInfoDetail GetProductInfoByAccountIdentifier(Guid accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public List<(long AccountKey, string IdentityCountryCode)> GetConsumerProfileCountryInfoByAccountKeys(List<long> accountKeys)
        {
            throw new NotImplementedException();
        }

        public GetEnrollmentResponse GetEnrollmentByAccountIdentifier(string accountIdentifier, string programCode,
            bool includeCardData)
        {
            throw new NotImplementedException();
        }

        public BinType GetAccountBinType(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public (string accountIdentifier, int productKey) GetAccountProductByAccountHolderKey(long accountHolderKey)
        {
            throw new NotImplementedException();
        }

        public Account GetAccountByAccountNumber(string accountNumber)
        {
            throw new NotImplementedException();
        }

        public bool IsJointAccount(string accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public void UpdAccountProductTier(Guid accountIdentifier, int productTierKey)
        {
            throw new NotImplementedException();
        }

        public CreateVerifyRequest GetVerficationRequestInfoByAccountIdentifierUserIdentifier(CreateVerifyRequest createVerifyRequest, VerificationActivityType activityType)
        {
            throw new NotImplementedException();
        }

        public AccountPrimaryConsumerProfile GetAccountPrimaryConsumerProfileWithDefaultAddress(Guid? accountIdentifier, Guid? userIdentifier, IdentityType identityType = 0)
        {
            throw new NotImplementedException();
        }

        public CollectionAccount GetCollectionAccountByAccountIdentifier(Guid accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public List<VerificationActivity> GetVerificationActivities(Guid? accountHolderIdentifier, Guid? accountIdentifier, Guid? consumerProfileIdentifier, VerificationActivityType verificationActivityType)
        {
            throw new NotImplementedException();
        }

        public AccountStatusInfo GetAccountInfoByAccountKeys(List<long> accountKeyList)
        {
            throw new NotImplementedException();
        }

        //public List<AccountStatusReasonFisCodeMapping> GetAccountStatusReasonFISCodeMapping()
        //{
        //    throw new NotImplementedException();
        //}

        private readonly ConcurrentDictionary<string, Account> _storage;
    }
}
