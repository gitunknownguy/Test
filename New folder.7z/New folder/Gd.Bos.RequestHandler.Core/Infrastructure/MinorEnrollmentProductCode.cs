﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace RequestHandler.Core.Infrastructure
{
    public class MinorEnrollmentProductCode
    {
        public string ProductCode { get; set; }
        public bool AcceptsMinorEnrollment { get; set; }
    }
}
