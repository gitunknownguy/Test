﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.RequestHandler.Core.Domain.Services.PointsSystem;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain.Model.PointsSystem;
using Gd.Bos.RequestHandler.Core.Utils;
using System.Collections.Generic;
using System.ServiceModel.Channels;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    [ExcludeFromCodeCoverage(Justification = "No need to test mocked responses of an archived service")]
    public class PointsSystemService : IPointsSystemService
    {
        private readonly IServiceInvokeProvider _serviceInvokeProvider;
        private const string _source = "RequestHandler";
        private readonly string _pointsSystemAPIBaseUrl;
        private readonly string _calculateTotalPointsUrl = "/points/calculatePoints";
        private readonly string _SendPointsEventUrl = "/points/sendPointsEvent";
        private readonly string _getChallengesWithStatusUrl = "/points/getChallengesWithStatus";
        private readonly string _getPointsConversionRateUrl = "/{0}/conversion-rate";
        private readonly string _pointsRedemptionUrl = "/Redemption/PointsRedemption";
        private readonly string _reversalPointsRedemptionUrl = "/Redemption/ReversalPointsRedemption";


        public PointsSystemService(IServiceInvokeProvider serviceInvokeProvider)
        {
            _serviceInvokeProvider = serviceInvokeProvider;
            _pointsSystemAPIBaseUrl = Configuration.Configuration.Current.PointsSystemBaseUrl;
        }

        //https://greendot.atlassian.net/browse/GBOS-130204 - PointsSystemAPI is deprecated
        public CalculatePointsResponse CalculateTotalPoints(CalculatePointsRequest request)
        {
            int? requestTimeout = null;
            GetTimeout("X-GD-Bos-PointsSystemAPI-CalculateTotalPointsTimeOut", out requestTimeout);

            //var response = _serviceInvokeProvider
            //    .GetWebResponse<Shared.Common.PointsSystem.Message.Request.CalculatePointsRequest,
            //        Shared.Common.PointsSystem.Message.Response.CalculatePointsResponse>(
            //        _pointsSystemAPIBaseUrl + _calculateTotalPointsUrl, "POST",
            //        PointsSystemContractMapper.SetCalculatePointsRequest(request), requestTimeout);

            //var responseCore = PointsSystemContractMapper.GetCalculatePointsResponse(response);
            var response = new CalculatePointsResponse
            {
                AvailablePoints = 0,
                CumulativePoints = 0,
                AccountIdentifier = Guid.NewGuid(),
                EffectiveDate = DateTime.Now,
                ResponseHeader = new ResponseHeader()
                {
                    ResponseId = Guid.NewGuid(),
                    StatusCode = 0,
                    Message = "Success",
                    Details = null,
                    SubStatusCode = 0
                },
                CurrentLevel = null,
                NextLevel = null,
                Milestones = null
            };





            if (response == null)
                throw new Exception($"PointsSystemAPI did not return a recognizable response for CalculateTotalPoints.");

            return response;
        }

        


        public PointsBehavioralEventResponse SendPointsEvent(PointsBehavioralEventRequest pointsEventRequest)
        {
            int? requestTimeout = null;
            GetTimeout("X-GD-Bos-PointsSystemAPI-SendPointsEventTimeOut", out requestTimeout);

            //reference ticket https://greendot.atlassian.net/browse/GBOS-127799
            var response = new PointsBehavioralEventResponse
            {
                ResponseHeader = new ResponseHeader()
                {
                    ResponseId = pointsEventRequest.RequestHeader.RequestId,
                    StatusCode = 0,
                    Message = "Success",
                    Details = null,
                    SubStatusCode = 0,
                },
                EventIdentifier = Guid.NewGuid()
            };

            if (response == null)
                throw new Exception($"PointsSystemAPI did not return a recognizable response for SendPointsEvent.");

            return response;
        }

        //https://greendot.atlassian.net/browse/GBOS-130204 - PointsSystemAPI is deprecated
        public ChallengesResponse GetChallengesWithStatus(ChallengesRequest request)
        {
            int? requestTimeout = null;
            GetTimeout("X-GD-Bos-PointsSystemAPI-GetChallengesWithStatusTimeOut", out requestTimeout);

            //var response = _serviceInvokeProvider
            //    .GetWebResponse<Shared.Common.PointsSystem.Message.Request.ChallengesRequest,
            //        Shared.Common.PointsSystem.Message.Response.ChallengesResponse>(
            //        _pointsSystemAPIBaseUrl + _getChallengesWithStatusUrl, "POST",
            //        PointsSystemContractMapper.SetGetChallengesWithStatusRequest(request), requestTimeout);

            //var responseCore = PointsSystemContractMapper.GetChallengesWithStatusResponse(response);

            var response = new ChallengesResponse()
            {
                ResponseHeader = new ResponseHeader()
                {
                    ResponseId = Guid.NewGuid(),
                    StatusCode = 0,
                    Message = "Success",
                    Details = null,
                    SubStatusCode = 0
                },
                ChallengeStatuses = null
            };

            

            if (response == null)
                throw new Exception($"PointsSystemAPI did not return a recognizable response for GetChallengesWithStatus.");

            return response;
        }

        //https://greendot.atlassian.net/browse/GBOS-130204 - PointsSystemAPI is deprecated
        public GetPointsConversionRateResponse GetPointsConversionRate(GetPointsConversionRateRequest request)
        {
            int? requestTimeout = null;
            GetTimeout("X-GD-Bos-PointsSystemAPI-GetPointsConversionRateTimeOut", out requestTimeout);

            //var response = _serviceInvokeProvider
            //    .GetWebResponse<GetPointsConversionRateRequest, GetPointsConversionRateResponse>(
            //        _pointsSystemAPIBaseUrl + string.Format(_getPointsConversionRateUrl, request.ProgramCode), "POST", request, requestTimeout);

            var response = new GetPointsConversionRateResponse
            {
                ResponseHeader = new ResponseHeader()
                {
                    ResponseId = Guid.NewGuid(),
                    StatusCode = 0,
                    Message = "Success",
                    Details = null,
                    SubStatusCode = 0
                },
                Currency = "0",
                CurrencyAmount=0,
                Points = 0
            };

            if (response == null)
                throw new Exception($"PointsSystemAPI did not return a recognizable response for GetPointsConversionRate.");

            return response;
        }

        //https://greendot.atlassian.net/browse/GBOS-130204 - PointsSystemAPI is deprecated
        public PointsRedemptionResponse PointsRedemption(PointsRedemptionRequest request)
        {
            int? requestTimeout = null;
            GetTimeout("X-GD-Bos-PointsSystemAPI-PointsRedemptionTimeOut", out requestTimeout);

            //var response = _serviceInvokeProvider.GetWebResponse<PointsRedemptionRequest, PointsRedemptionResponse>(
            //    _pointsSystemAPIBaseUrl + _pointsRedemptionUrl, "POST", request, requestTimeout);

            var response = new PointsRedemptionResponse
            {
                ResponseHeader = new ResponseHeader()
                {
                    ResponseId = Guid.NewGuid(),
                    StatusCode = 0,
                    Message = "Success",
                    Details = null,
                    SubStatusCode = 0
                },
                FeatureTxnIdentifier = Guid.NewGuid(),
                PointsRedeemed = 0,
                AvailableBalance = 0,
                CumulativeBalance = 0,
                Currency="0",
                ConversionRate = 0,
                AmountRedeemed=0,
                TransactionIdentifier = Guid.NewGuid()

            };

            if (response == null)
                throw new Exception($"PointsSystemAPI did not return a recognizable response for PointsRedemption.");

            return response;
        }

        //https://greendot.atlassian.net/browse/GBOS-130204 - PointsSystemAPI is deprecated
        public ReversalPointsRedemptionResponse ReversalPointsRedemption(ReversalPointsRedemptionRequest request)
        {
            int? requestTimeout = null;
            GetTimeout("X-GD-Bos-PointsSystemAPI-ReversalPointsRedemptionTimeOut", out requestTimeout);

            //var response = _serviceInvokeProvider.GetWebResponse<ReversalPointsRedemptionRequest, ReversalPointsRedemptionResponse>(
            //    _pointsSystemAPIBaseUrl + _reversalPointsRedemptionUrl, "POST", request, requestTimeout);


            var response = new ReversalPointsRedemptionResponse
            {
                ResponseHeader = new ResponseHeader()
                {
                    ResponseId = Guid.NewGuid(),
                    StatusCode = 0,
                    Message = "Success",
                    Details = null,
                    SubStatusCode = 0
                },
                FeatureTxnIdentifier = Guid.NewGuid(),
                ReversalPoints = 0,
                AvailableBalance = 0,
                CumulativeBalance = 0,
                Currency = "0",
                ConversionRate = 0,
                ReversalAmount = 0,
                TransactionIdentifier = Guid.NewGuid()

            };


            if (response == null)
                throw new Exception($"PointsSystemAPI did not return a recognizable response for ReversalPointsRedemption.");

            return response;
        }

        private void GetTimeout(string headerName, out int? requestTimeout)
        {
            requestTimeout = null;
            if (OptionsContext.Current.IsDefined(headerName))
            {
                requestTimeout = 1;
                if (int.TryParse(OptionsContext.Current.GetString(headerName), out var rt))
                    requestTimeout = rt;
            }
        }
    }
}
