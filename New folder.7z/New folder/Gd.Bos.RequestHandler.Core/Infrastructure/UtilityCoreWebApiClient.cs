﻿using System.Diagnostics.CodeAnalysis;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain;
using Gd.Bos.RequestHandler.Core.Domain.Services.Core;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.Logic;
using Gd.Bos.Shared.Common.UtilityCoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.UtilityCoreApi.Contract.Message.Request;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class UtilityCoreWebApiClient : IUtilityCoreWebApiClient
    {
        private readonly IServiceInvokeProvider _serviceInvokerProvider;
        private readonly string _baseUrl;

        public UtilityCoreWebApiClient(IServiceInvokeProvider serviceInvokerProvider, IRequestHandlerSettings settings)
        {
            _serviceInvokerProvider = serviceInvokerProvider;
            _baseUrl = settings.UtilityCoreApiBaseUrl;
        }

        public GetExternalBankAccountsResponse GetExternalBankAccounts(GetExternalBankAccountsRequest request)
        {
            var getResponse = _serviceInvokerProvider.GetWebResponse<GetExternalBankAccountsRequest, GetExternalBankAccountsResponse>(GenerateExternalBankAccountsUrl(request.ProgramCode, request.AccountReferenceId), "POST", request, null);

            return getResponse;
        }

        public GetAMMRuleResponse GetActiveAmmRules(GetAMMRuleRequest request)
        {
            var getResponse = _serviceInvokerProvider.GetWebResponse<GetAMMRuleResponse>(
                GenerateGetAmmRuleByTargetAccountUrl(request), "GET",
                null, null);

            return getResponse;
        }

        public GetFeatureEligibilityResponse GetFeatureEligibility(GetFeatureEligibilityRequest request)
        {
            var getResponse = _serviceInvokerProvider.GetWebResponse<GetFeatureEligibilityRequest, GetFeatureEligibilityResponse>(
                GenerateGetFeatureEligibilityUrl(request.ProgramCode, request.AccountIdentifier), "POST",
                request, null);

            return getResponse;
        }

        public async Task<UpdateFeatureResponse> UpdateFeature(UpdateFeatureRequest request)
        {
            var requestJson = request.SerializeToJson<UpdateFeatureRequest>();

            var updateResponse = await _serviceInvokerProvider.GetWebResponseAsync<UpdateFeatureResponse>(GenerateUpdateFeatureUrl(request.ProgramCode, request.AccountIdentifier, request.FeatureId.ToString()), "POST", requestJson, null);
            return updateResponse;
        }

        private string GenerateExternalBankAccountsUrl(string programCode, string accountIdentifier)
        {
            return _baseUrl + $"/programs/{programCode}/accounts/{accountIdentifier}/externalBankAccounts";
        }

        private string GenerateGetAmmRuleByTargetAccountUrl(GetAMMRuleRequest request)
        {
            return _baseUrl + $"/programs/{request.ProgramCode}/accounts/{request.TargetAccountId}/ammRuleByTargetAccount/active?includeTransactions={request.IncludeTransactions}&transferType={request.TransferType}";
        }

        private string GenerateGetFeatureEligibilityUrl(string programCode, string accountIdentifier)
        {
            return $"{_baseUrl}/programs/{programCode}/accounts/{accountIdentifier}/featureeligibility";
        }

        private string GenerateUpdateFeatureUrl(string programCode, string accountIdentifier, string featureId)
        {
            return $"{_baseUrl}/programs/{programCode}/accounts/{accountIdentifier}/features/{featureId}";
        }

        public async Task<SetFeatureEligibilityResponse> SetFeatureEligibility(SetFeatureEligibilityRequest request)
        {
            var requestJson = request.SerializeToJson();

            var url = $"{_baseUrl}/programs/{request.ProgramCode}/accounts/{request.AccountIdentifier}/featureeligibility/{request.FeatureId}";
            var response = await _serviceInvokerProvider.GetWebResponseAsync<SetFeatureEligibilityResponse>(url, "PUT", requestJson, null);
            return response;
        }
    }
}
