﻿using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.Shared.Common.Messaging.Model;
using RequestHandler.Core.Domain.Model.MerchantCategoryCode;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace RequestHandler.Core.Infrastructure
{
    public class MerchantCategoryCodeRepository : IMerchantCategoryCodeRepository
    {
        private readonly IDataAccess _dataAccess;

        public MerchantCategoryCodeRepository(IDataAccess dataAccess)
        {
            _dataAccess = dataAccess;
        }

        public List<MerchantCategoryCode> GetAllMerchantCategoryCodes()
        {
            var merchantCategoryCodes = new List<MerchantCategoryCode>();

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAllMCC]", _dataAccess.CreateConnection()))
            {
                while (reader.Read())
                {
                    var merchantCategoryCode = new MerchantCategoryCode
                    {
                        MerchantCode = reader["MerchantCategoryCode"].ToString(),
                        MerchantCategory = reader["MerchantCategory"].ToString(),
                        MccDescription = reader["MCCDescription"].ToString()
                    };
                    merchantCategoryCodes.Add(merchantCategoryCode);
                }
            }

            return merchantCategoryCodes;
        }
    }
}
