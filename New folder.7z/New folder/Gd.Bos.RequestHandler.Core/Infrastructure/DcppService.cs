﻿using System;
using System.Collections.Generic;
using System.Linq;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.Logic;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.Dcpp.Contract.Enum;
using Gd.Bos.Dcpp.Contract.Message;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Services.Dcpp;
using AddPurseToAccountResponse = Gd.Bos.Dcpp.Contract.Message.AddPurseToAccountResponse;
using Address = Gd.Bos.RequestHandler.Core.Domain.Model.User.Address;
using CardExpirationDate = Gd.Bos.RequestHandler.Core.Domain.Services.Dcpp.CardExpirationDate;
using DeliveryMethod = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.DeliveryMethod;
using ExpirationDate = Gd.Bos.Dcpp.Contract.Data.ExpirationDate;
using LossType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.LossType;
using PaymentInstrument = Gd.Bos.RequestHandler.Core.Domain.Model.Payment.PaymentInstrument;
using PhoneNumber = Gd.Bos.RequestHandler.Core.Domain.Model.User.PhoneNumber;
using PhoneType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.PhoneType;
using TokenAction = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TokenAction;
using PurseStatus = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.PurseStatus;
using System.Configuration;
using System.Diagnostics.CodeAnalysis;
using ReplacementReason = Gd.Bos.Dcpp.Contract.Enum.ReplacementReason;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Contract.Exceptions;
using ActivateCardRequest = Gd.Bos.Dcpp.Contract.Message.ActivateCardRequest;
using AddPurseToAccountRequest = Gd.Bos.Dcpp.Contract.Message.AddPurseToAccountRequest;
using AdjustAccountBalanceRequest = Gd.Bos.Dcpp.Contract.Message.AdjustAccountBalanceRequest;
using AdjustAccountBalanceResponse = Gd.Bos.Dcpp.Contract.Message.AdjustAccountBalanceResponse;
using ChangeAccountStatusRequest = Gd.Bos.Dcpp.Contract.Message.ChangeAccountStatusRequest;
using ChangeAccountStatusResponse = Gd.Bos.Dcpp.Contract.Message.ChangeAccountStatusResponse;
using CreateAccountRequest = Gd.Bos.Dcpp.Contract.Message.CreateAccountRequest;
using CurrencyAmount = Gd.Bos.Shared.Common.Core.Contract.CurrencyAmount;
using GetCardDetailsRequest = Gd.Bos.Dcpp.Contract.Message.GetCardDetailsRequest;
using GetCardDetailsResponse = Gd.Bos.Dcpp.Contract.Message.GetCardDetailsResponse;
using OrderCardRequest = Gd.Bos.Dcpp.Contract.Message.OrderCardRequest;
using OrderCardResponse = Gd.Bos.Dcpp.Contract.Message.OrderCardResponse;
using OverrideProductResponse = Gd.Bos.Dcpp.Contract.Message.OverrideProductResponse;
using RequestHeader = Gd.Bos.Dcpp.Contract.Message.RequestHeader;
using SetPinRequest = Gd.Bos.Dcpp.Contract.Message.SetPinRequest;
using VerifyPinRequest = Gd.Bos.Dcpp.Contract.Message.VerifyPinRequest;
using UpdateAccountRequest = Gd.Bos.Dcpp.Contract.Message.UpdateAccountRequest;
using UpdateAccountResponse = Gd.Bos.Dcpp.Contract.Message.UpdateAccountResponse;
using UpdateProductRequest = Gd.Bos.Dcpp.Contract.Message.UpdateProductRequest;
using UpdateProductResponse = Gd.Bos.Dcpp.Contract.Message.UpdateProductResponse;
using ValidateCVVRequest = Gd.Bos.Dcpp.Contract.Message.ValidateCVVRequest;
using ValidateCVVResponse = Gd.Bos.Dcpp.Contract.Message.ValidateCVVResponse;
using Gd.Bos.RequestHandler.Core.Domain.Model.Business;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request;
using Gd.Bos.Shared.Common.CBSProcessorManager.Contract.Message.Request;
using Gd.Bos.Shared.Common.CBSProcessorManager.Contract.Message.Response;
using AdjustPurseBalanceRequest = Gd.Bos.Dcpp.Contract.Message.AdjustPurseBalanceRequest;
using AdjustPurseBalanceResponse = Gd.Bos.Dcpp.Contract.Message.AdjustPurseBalanceResponse;
using ChangeCardStatusRequest = Gd.Bos.Dcpp.Contract.Message.ChangeCardStatusRequest;
using ChangeCardStatusResponse = Gd.Bos.Dcpp.Contract.Message.ChangeCardStatusResponse;
using ChangePurseStatusRequest = Gd.Bos.Dcpp.Contract.Message.ChangePurseStatusRequest;
using ChangePurseStatusResponse = Gd.Bos.Dcpp.Contract.Message.ChangePurseStatusResponse;
using GetAccountBalanceResponse = Gd.Bos.Dcpp.Contract.Message.GetAccountBalanceResponse;
using GetAccountBalanceRequest = Gd.Bos.Dcpp.Contract.Message.GetAccountBalanceRequest;
using OverrideProductRequest = Gd.Bos.Shared.Common.Dcpp.Contract.Message.OverrideProductRequest;
using ProductFeatureGroupOverride = Gd.Bos.Shared.Common.Dcpp.Contract.Data.ProductFeatureGroupOverride;
using ReportLostStolenV2Request = Gd.Bos.Dcpp.Contract.Message.ReportLostStolenV2Request;
using ReportLostStolenV2Response = Gd.Bos.Dcpp.Contract.Message.ReportLostStolenV2Response;
using UpdateCreditLimitHistoryRequest = Gd.Bos.Dcpp.Contract.Message.UpdateCreditLimitHistoryRequest;
using UpdateCreditLimitHistoryResponse = Gd.Bos.Dcpp.Contract.Message.UpdateCreditLimitHistoryResponse;
using ValidateCvvByPanRequest = RequestHandler.Core.Domain.Services.Dcpp.ValidateCvvByPanRequest;
using ValidateCvvByPanResponse = RequestHandler.Core.Domain.Services.Dcpp.ValidateCvvByPanResponse;
using AddAccountHolderRequest = Gd.Bos.Dcpp.Contract.Message.AddAccountHolderRequest;
using AddAccountHolderResponse = Gd.Bos.Dcpp.Contract.Message.AddAccountHolderResponse;
using AccountStatusReason = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountStatusReason;
using System.Net;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class DcppService : IDcppService
    {
        private readonly IRequestHandlerSettings _settings;

        public DcppService(IServiceInvokeProvider serviceInvokeProvider, IRequestHandlerSettings settings)
        {
            _serviceInvokeProvider = serviceInvokeProvider;
            _dcppBaseUrl = Configuration.Configuration.Current.DcppBaseUrl;
            _settings = settings;
        }

        private CredentialCache BuildNTLMCredentialCache()
        {
            var domain = Environment.GetEnvironmentVariable("RequestHandler__Ldap__NetBiosDomain");
            var username = Environment.GetEnvironmentVariable("RequestHandler__Kerberos__Username");
            var password = Environment.GetEnvironmentVariable("RequestHandler__Kerberos__Password");
            var credentialsCache = new CredentialCache
                {{new Uri(_dcppBaseUrl), "NTLM", new NetworkCredential(
                    username,
                    password,
                    domain
                )}};
            return credentialsCache;
        }

        public Domain.Services.Dcpp.CreateAccountResponse CreateAccount(AccountIdentifier accountIdentifier, UserIdentifier userIdentifier,
            IEnumerable<string> additionalUserIdentifiers, UserName name, IEnumerable<Address> addresses, IEnumerable<PhoneNumber> phoneNumbers, string programCode,
            string productCode, PhysicalCardType physicalCardType, bool personalized, string productMaterialType,
            int productTierKey, bool isVirtualTierAllowed, string embossName, string businessName, string accountNumber,
            int expirationMonths, int expirationRandomMonths, BusinessAddress businessAddress, string productType = null, int billCycleDay = 1,
            string routingNumber = null, bool needEmbossing = true,string storeId=null,string businessEmbossName = null)
        {
            GetTimeout("X-GD-Bos-Dcpp-CreateAccountTimeOut", out var requestTimeout);

            #region QA testing timeout from DCPP
            if (_settings.RetryMaxTimeoutEnable)
            {
                throw new TimeoutException($"RetryMaxTimeoutEnable is set to {_settings.RetryMaxTimeoutEnable} CreateAccount - so " +
                                           $"forcing timeout from QA for accountIdentifier: {accountIdentifier}");
            }
            #endregion

            Address address = addresses?.FirstOrDefault(item => string.Compare(item.Type, AddressType.Home.ToString(),
                StringComparison.InvariantCultureIgnoreCase) > -1);
            if (programCode.Equals("credibly", StringComparison.OrdinalIgnoreCase))
            {
                address = addresses?.FirstOrDefault(item => string.Compare(item.Type, "1",
                StringComparison.InvariantCultureIgnoreCase) > -1);
            }

            Dcpp.Contract.Data.PostalAddress postalAddress;
            if (businessAddress != null && businessAddress.IsBusinessAddressForPostal)
            {
                postalAddress = new Dcpp.Contract.Data.PostalAddress()
                {
                    AddressLines = new string[]
                    {
                        businessAddress.BusinessAddressLine1,
                        businessAddress.BusinessAddressLine2
                    },
                    City = businessAddress.BusinessCity,
                    PostalCode = businessAddress.BusinessZipCode,
                    CountrySubdivision = businessAddress.BusinessState
                };
            }
            else
            {
                postalAddress = new Dcpp.Contract.Data.PostalAddress()
                {
                    AddressLines = new string[]
                    {
                        address.AddressLine1,
                        address.AddressLine2
                    },
                    City = address.City,
                    PostalCode = address.ZipCode,
                    CountrySubdivision = address.State
                };
            }

            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            CreateAccountRequest request = new CreateAccountRequest
            {
                BusinessName = businessName,
                Header = new RequestHeader() { RequestId = reqId, Source = _source },
                AccountIdentifier = accountIdentifier.ToString(),
                UserIdentifier = userIdentifier.ToString(),
                AdditionalUserIdentifiers = additionalUserIdentifiers?.ToList(),
                ProgramCode = programCode,
                ProductCode = productCode,
                PhysicalCardType = physicalCardType.ToString(),
                Personalized = false,
                EmbossName = embossName,
                CardholderName = new Dcpp.Contract.Data.CardholderName()
                {
                    FirstName = name.FirstName,
                    LastName = name.LastName
                },
                PostalAddress = postalAddress,
                ProductMaterialType = productMaterialType,
                ProductTierKey = productTierKey,
                IsVirtualTierAllowed = isVirtualTierAllowed,
                AccountNumber = (accountNumber == string.Empty ? null : accountNumber),
                ExpirationMonths = expirationMonths,
                ExpirationRandomMonths = expirationRandomMonths,
                RoutingNumber = (routingNumber == string.Empty ? null : routingNumber)
            };

            request.PhoneNumbers = new List<Dcpp.Contract.Data.PhoneNumber>();
            foreach (var ph in phoneNumbers)
            {
                request.PhoneNumbers.Add(new Dcpp.Contract.Data.PhoneNumber
                {
                    Number = ph.Number,
                    Type = GetPhoneType(ph.Type)
                });
            }

            var response = _serviceInvokeProvider
                .GetWebResponseWithCredentialCache<CreateAccountRequest, Dcpp.Contract.Message.CreateAccountResponse>(
                    _dcppBaseUrl + _createAccountUrl, 
                    "POST", 
                    request, 
                    BuildNTLMCredentialCache(),
                    requestTimeout
            );

            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for CreateAccount.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                        $"A downstream provider did not return success for CreateAccount: Message: {response.Header.ErrorInfo.Message};");

            return new Domain.Services.Dcpp.CreateAccountResponse
            {
                PaymentIdentifierIdentifier = response.PaymentIdentifierIdentifier,
                AccountBalanceIdentifier = response.AccountBalanceIdentifier,
                PaymentInstrumentIdentifier = response.PaymentInstrumentIdentifier,
                CardDetails = new CardDetails
                {
                    Pan = response.CardNumber,
                    Cvv = response.Cvv,
                    ExpirationMonth = int.Parse(response.Expiration.Month),
                    ExpirationYear = int.Parse(response.Expiration.Year)
                },
                RoutingNumber = routingNumber,
                AccountNumber = accountNumber
            };
        }

        private Gd.Bos.Dcpp.Contract.Data.PhoneType GetPhoneType(PhoneType type)
        {
            switch (type)
            {
                case PhoneType.Work: return Gd.Bos.Dcpp.Contract.Data.PhoneType.Work;
                case PhoneType.Mobile: return Gd.Bos.Dcpp.Contract.Data.PhoneType.Mobile;
                default: return Gd.Bos.Dcpp.Contract.Data.PhoneType.Home;
            }
        }

        [ExcludeFromCodeCoverage(Justification = "Will be tested later.")]
        public Domain.Services.Dcpp.CreateAccountResponse AddAccountHolder(
            string accountIdentifier,
            string userIdentifier,
            string accountHolderIdentifier,
            string productMaterialType,
            UserName cardholderName,
            string embossName,
            DateTime dateOfBirth,
            string productCode,
            bool isVirtualTierAllowed,
            IEnumerable<Address> addresses,
            IEnumerable<PhoneNumber> phoneNumbers)
        {
            GetTimeout("X-GD-Bos-Dcpp-CreateAccountTimeOut", out var requestTimeout);

            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            Address address = addresses?.FirstOrDefault(item =>
            string.Compare(item.Type, AddressType.Home.ToString(), StringComparison.InvariantCultureIgnoreCase) > -1);


            AddAccountHolderRequest request = new AddAccountHolderRequest
            {
                Header = new RequestHeader() { RequestId = reqId, Source = _source },
                ProgramCode = DomainContext.Current?.ProgramCode?.ToString(),
                ProductCode = productCode,

                ProductMaterialType = productMaterialType,
                AccountIdentifier = accountIdentifier,
                UserIdentifier = userIdentifier,
                AccountHolderIdentifier = accountHolderIdentifier,
                CardholderName = new Dcpp.Contract.Data.CardholderName()
                {
                    FirstName = cardholderName.FirstName,
                    LastName = cardholderName.LastName
                },
                PostalAddress = new Dcpp.Contract.Data.PostalAddress()
                {
                    AddressLines = new string[]
                    {
                        address.AddressLine1,
                        address.AddressLine2
                    },
                    City = address.City,
                    PostalCode = address.ZipCode,
                    CountrySubdivision = address.State
                },

                EmbossName = embossName,
                DateOfBirth = new Dcpp.Contract.Data.DateOfBirth()
                {
                    Month = dateOfBirth.Month,
                    Day = dateOfBirth.Day,
                    Year = dateOfBirth.Year
                },
                IsVirtualTierAllowed = isVirtualTierAllowed
            };

            request.PhoneNumbers = new List<Dcpp.Contract.Data.PhoneNumber>();
            foreach (var ph in phoneNumbers)
            {
                request.PhoneNumbers.Add(new Dcpp.Contract.Data.PhoneNumber
                {
                    Number = ph.Number,
                    Type = GetPhoneType(ph.Type)
                });
            }


            var response = _serviceInvokeProvider
                .GetWebResponseWithCredentialCache<AddAccountHolderRequest, AddAccountHolderResponse>(
                _dcppBaseUrl + _addAccountHolderUrl, 
                "POST", 
                request, 
                BuildNTLMCredentialCache(),
                requestTimeout
            );

            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for AddAccountHolder.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for AddAccountHolder: Message: {response.Header.ErrorInfo.Message};");

            return new Domain.Services.Dcpp.CreateAccountResponse()
            {
                PaymentIdentifierIdentifier = response.PaymentIdentifierIdentifier,
                AccountBalanceIdentifier = response.AccountBalanceIdentifier,
                PaymentInstrumentIdentifier = response.PaymentInstrumentIdentifier,
                CardDetails = new CardDetails()
                {
                    Pan = response.CardNumber,
                    ExpirationMonth = int.Parse(response.Expiration.Month),
                    ExpirationYear = int.Parse(response.Expiration.Year),
                    Cvv = response.Cvv
                }
            };
        }

        public ValidateCvvByPanResponse ValidateCvvByPan(ValidateCvvByPanRequest request)
        {
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            GetTimeout("X-GD-Bos-Dcpp-ValidateCvvByPanTimeout", out var requestTimeout);

            var response = _serviceInvokeProvider
                .GetWebResponseWithCredentialCache<ValidateCvvByPanRequest, ValidateCvvByPanResponse>(
                _dcppBaseUrl + _validateCvvByPanUrl, 
                "POST", 
                request, 
                BuildNTLMCredentialCache(),
                requestTimeout
            );

            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for ValidateCvvByPan.");

            //if (response.Header.StatusCode != "200")
            //    throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
            //        $"A downstream provider did not return success for ValidateCvvByPan: Message: {response.Header.ErrorInfo.Message};");
            return response;
        }

        public CardDetails GetCardDetails(AccountIdentifier accountIdentifier, CardExpirationDate expirationDate, Guid? paymentIdentifier = null, Guid? paymentInstrumentIdentifier = null)
        {
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            GetTimeout("X-GD-Bos-Dcpp-GetCardDetailsTimeOut", out var requestTimeout);

            GetCardDetailsRequest request = new GetCardDetailsRequest
            {
                Header = new RequestHeader() { RequestId = reqId, Source = _source },
                ProgramCode = DomainContext.Current?.ProgramCode?.ToString(),
                AccountId = accountIdentifier.ToString(),
                Expiration = new ExpirationDate
                {
                    Month = expirationDate.CardExpirationMonth,
                    Year = expirationDate.CardExpirationYear
                },
                PaymentIdentifierIdentifier = paymentIdentifier
            };

            var response = _serviceInvokeProvider
                .GetWebResponseWithCredentialCache<GetCardDetailsRequest, GetCardDetailsResponse>(
                    _dcppBaseUrl + _getCardDetailsUrl, 
                    "POST", 
                    request, 
                    BuildNTLMCredentialCache(),
                    requestTimeout
            );

            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for GetCardDetails.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                        $"A downstream provider did not return success for GetCardDetails: Message: {response.Header.ErrorInfo.Message};");

            return new CardDetails
            {
                Pan = response.CardNumber,
                Cvv = response.Cvv,
                ExpirationMonth = int.Parse(response.Expiration.Month),
                ExpirationYear = int.Parse(response.Expiration.Year)
            };
        }

        public OrderCardResponse OrderPhysicalCard(AccountIdentifier accountIdentifier,
           PaymentIdentifierIdentifier paymentIdentifier,
           PaymentInstrumentIdentifier paymentInstrumentIdentifier,
           string programCode, string productMaterialType = null,
           string customCardImageIdentifier = null,
           ReplacementReason replacementReason = ReplacementReason.NewCard, bool override10DayLimit = false,
           DeliveryMethod deliveryMethod = DeliveryMethod.Regular,
           string retryId = null, string source = null, bool? waiveFee = null, bool? waiveOvernightFee = null, bool needEmbossing = true, string storeId = null)
        {
            GetTimeout("X-GD-Bos-Dcpp-OrderPhysicalCardTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);
            if (!string.IsNullOrEmpty(retryId))
            {
                reqId = Guid.Parse(retryId);
            }

            #region QA testing timeout from DCPP
            if (_settings.RetryMaxTimeoutEnable)
            {
                throw new TimeoutException($"RetryMaxTimeoutEnable is set to {_settings.RetryMaxTimeoutEnable} OrderPhysicalCard - so " +
                                           $"forcing timeout from QA for accountIdentifier: {accountIdentifier}");
            }
            #endregion

            Gd.Bos.Dcpp.Contract.Enum.DeliveryMethod dcppDeliveryMethod = GetDeliveryMethod(deliveryMethod);
            OrderCardRequest request = new OrderCardRequest
            {
                AccountIdentifier = accountIdentifier.ToString(),
                PaymentIdentifierIdentifier = paymentIdentifier.ToString(),
                Header = new RequestHeader() { RequestId = reqId, Source = _source },
                ReplacementReason = replacementReason.ToString(),
                PaymentInstrumentIdentifier = paymentInstrumentIdentifier?.ToString(),
                Override10DayLimit = override10DayLimit,
                DeliveryMethod = dcppDeliveryMethod.ToString(),
                ProgramCode = programCode,
                ProductMaterialType = productMaterialType,
                CustomCardImageIdentifier = customCardImageIdentifier,
                Source = source
            };

            var response = _serviceInvokeProvider
                .GetWebResponseWithCredentialCache<OrderCardRequest, Dcpp.Contract.Message.OrderCardResponse>(
                    _dcppBaseUrl + _orderCardUrl,
                    "POST", 
                    request, 
                    BuildNTLMCredentialCache(),
                    requestTimeout
            );

            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for OrderPhysicalCard.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0),
                    response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for OrderPhysicalCard: Message: {response.Header.ErrorInfo.Message};");

            return response;
        }

        [ExcludeFromCodeCoverage(Justification = "Will be tested later.")]
        public ReportLostStolenV2Response ReportLostStolenRetry(AccountIdentifier accountIdentifier, PaymentInstrumentIdentifier paymentInstrumentIdentifier,
            Guid requestId, LossType lossType, DeliveryMethod deliveryMethod, DateTime? dateLastUsed, DateTime? dateDiscoveredMissing,
            bool? policeNotified, string notes, string productMaterialType, string programCode, string customCardImageIdentifier = null,
            bool isProductEligibleForDigitalWallet = false, string source = null, bool? waiveFee = null, bool? waiveOvernightFee = null, 
            bool createVirtualCard = false, int PhysicalProductTierKey = 0, bool needEmbossing = true, bool override10DayLimit = false,string storeId=null)
        {
            GetTimeout("X-GD-Bos-Dcpp-ReportLostStolenTimeOut", out var requestTimeout);

            Gd.Bos.Dcpp.Contract.Enum.LossType dcppLossType;
            switch (lossType)
            {
                case LossType.Stolen:
                    dcppLossType = Gd.Bos.Dcpp.Contract.Enum.LossType.Stolen;
                    break;
                case LossType.Compromised:
                    dcppLossType = Gd.Bos.Dcpp.Contract.Enum.LossType.Compromised;
                    break;
                case LossType.UnauthorizedUse:
                    dcppLossType = Gd.Bos.Dcpp.Contract.Enum.LossType.UnauthorizedUse;
                    break;
                default:
                    dcppLossType = Gd.Bos.Dcpp.Contract.Enum.LossType.Lost;
                    break;
            }

            Gd.Bos.Dcpp.Contract.Enum.DeliveryMethod dcppDeliveryMethod = GetDeliveryMethod(deliveryMethod);

            var request = new ReportLostStolenV2Request
            {
                Header = new RequestHeader() { RequestId = requestId, Source = _source },
                ProgramCode = programCode,
                AccountIdentifier = accountIdentifier.ToString(),
                PaymentInstrumentIdentifier = paymentInstrumentIdentifier.ToString(),
                LossType = dcppLossType.ToString(),
                DeliveryMethod = dcppDeliveryMethod.ToString(),
                DateLastUsed = dateLastUsed?.ToString(),
                DateDiscoveredMissing = dateDiscoveredMissing?.ToString(),
                PoliceNotified = policeNotified,
                Notes = notes,
                ProductMaterialType = productMaterialType,
                CustomCardImageIdentifier = customCardImageIdentifier,
                IsProductEligibleForDigitalWallet = isProductEligibleForDigitalWallet,
                source = source,
                CreateVirtualCard = createVirtualCard,
                ProductTierKey = PhysicalProductTierKey
            };

            var response = _serviceInvokeProvider
                .GetWebResponseWithCredentialCache<ReportLostStolenV2Request, ReportLostStolenV2Response>(
                    _dcppBaseUrl + _reportLostStolenUrlV2, 
                    "POST",
                    request, 
                    BuildNTLMCredentialCache(),
                    requestTimeout);

            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for ReportLostStolen.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for ReportLostStolen: Message: {response.Header.ErrorInfo.Message};");

            return response;
        }

        public ReportLostStolenV2Response ReportLostStolen(AccountIdentifier accountIdentifier,
            PaymentInstrumentIdentifier paymentInstrumentIdentifier,
            LossType lossType, DeliveryMethod deliveryMethod, DateTime? dateLastUsed, DateTime? dateDiscoveredMissing,
            bool? policeNotified, string notes,
            string productMaterialType, bool createVirtualCard, string customCardImageIdentifier = null,
            bool isProductEligibleForDigitalWallet = false, string source = null,
            bool? waiveFee = null, bool? waiveOvernightFee = null, int PhysicalProductTierKey = 0,
            bool needEmbossing = true, bool override10DayLimit = false, string storeId = null)
        {
            GetTimeout("X-GD-Bos-Dcpp-ReportLostStolenTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            Gd.Bos.Dcpp.Contract.Enum.LossType dcppLossType;
            switch (lossType)
            {
                case LossType.Stolen:
                    dcppLossType = Gd.Bos.Dcpp.Contract.Enum.LossType.Stolen;
                    break;
                case LossType.Compromised:
                    dcppLossType = Gd.Bos.Dcpp.Contract.Enum.LossType.Compromised;
                    break;
                case LossType.UnauthorizedUse:
                    dcppLossType = Gd.Bos.Dcpp.Contract.Enum.LossType.UnauthorizedUse;
                    break;
                default:
                    dcppLossType = Gd.Bos.Dcpp.Contract.Enum.LossType.Lost;
                    break;
            }

            Gd.Bos.Dcpp.Contract.Enum.DeliveryMethod dcppDeliveryMethod = GetDeliveryMethod(deliveryMethod);

            var request = new ReportLostStolenV2Request
            {
                Header = new RequestHeader() { RequestId = reqId, Source = _source },
                ProgramCode = DomainContext.Current?.ProgramCode?.ToString(),
                AccountIdentifier = accountIdentifier.ToString(),
                PaymentInstrumentIdentifier = paymentInstrumentIdentifier.ToString(),
                LossType = dcppLossType.ToString(),
                DeliveryMethod = dcppDeliveryMethod.ToString(),
                DateLastUsed = dateLastUsed?.ToString(),
                DateDiscoveredMissing = dateDiscoveredMissing?.ToString(),
                PoliceNotified = policeNotified,
                Notes = notes,
                ProductMaterialType = productMaterialType,
                CustomCardImageIdentifier = customCardImageIdentifier,
                IsProductEligibleForDigitalWallet = isProductEligibleForDigitalWallet,
                source = source,
                CreateVirtualCard = createVirtualCard,
                ProductTierKey = PhysicalProductTierKey
            };

            var response = _serviceInvokeProvider.GetWebResponseWithCredentialCache<ReportLostStolenV2Request, ReportLostStolenV2Response>(
                    _dcppBaseUrl + _reportLostStolenUrlV2, 
                    "POST", 
                    request, 
                    BuildNTLMCredentialCache(),
                    requestTimeout);

            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for ReportLostStolen.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for ReportLostStolen: Message: {response.Header.ErrorInfo.Message};");

            return response;
            //return new PaymentIdentifier(PaymentIdentifierIdentifier.FromString(response.PaymentIdentifierIdentifier))
            //{
            //    AccountIdentifier = AccountIdentifier.FromString(response.AccountIdentifier),
            //    PaymentInstrument = new PaymentInstrument()
            //    {
            //        PaymentInstrumentIdentifier = PaymentInstrumentIdentifier.FromString(response.PaymentInstrumentIdentifier)
            //    }
            //};
        }

        private Dcpp.Contract.Enum.DeliveryMethod GetDeliveryMethod(DeliveryMethod deliveryMethod)
        {
            switch (deliveryMethod)
            {
                case DeliveryMethod.Rush:
                    return Dcpp.Contract.Enum.DeliveryMethod.Rush;
                case DeliveryMethod.Overnight:
                    return Dcpp.Contract.Enum.DeliveryMethod.Overnight;
                case DeliveryMethod.USPSExpeditedOvernight:
                    return Dcpp.Contract.Enum.DeliveryMethod.USPSExpeditedOvernight;
                default:
                    return Dcpp.Contract.Enum.DeliveryMethod.Regular;
            }
        }

        public void SetPin(AccountIdentifier accountIdentifier, string paymentInstrumentIdentifier, string pin)
        {
            GetTimeout("X-GD-Bos-Dcpp-SetPinTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            var request = new SetPinRequest
            {
                Header = new RequestHeader() { RequestId = reqId, Source = _source },
                ProgramCode = DomainContext.Current?.ProgramCode?.ToString(),
                AccountIdentifier = accountIdentifier.ToString(),
                PaymentInstrumentIdentifier = paymentInstrumentIdentifier,
                Pin = pin
            };

            var response = _serviceInvokeProvider.GetWebResponseWithCredentialCache<SetPinRequest, Dcpp.Contract.Message.SetPinResponse>(
                    _dcppBaseUrl + _setPinUrl, 
                    "POST", 
                    request,
                    BuildNTLMCredentialCache(),
                    requestTimeout);

            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for SetPin.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                        $"A downstream provider did not return success for SetPin: Message: {response.Header.ErrorInfo.Message};");
        }

        [ExcludeFromCodeCoverage(Justification = "Will be tested later.")]
        public bool VerifyPin(AccountIdentifier accountIdentifier, string paymentInstrumentIdentifier, string pin)
        {
            GetTimeout("X-GD-Bos-Dcpp-VerifyPinTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            var request = new VerifyPinRequest
            {
                Header = new RequestHeader() { RequestId = reqId, Source = _source },
                ProgramCode = DomainContext.Current?.ProgramCode?.ToString(),
                AccountIdentifier = accountIdentifier.ToString(),
                PaymentInstrumentIdentifier = paymentInstrumentIdentifier,
                Pin = pin
            };

            var response = _serviceInvokeProvider.GetWebResponseWithCredentialCache<VerifyPinRequest, Dcpp.Contract.Message.VerifyPinResponse>(
                _dcppBaseUrl + _verifyPinUrl, 
                "POST", 
                request,
                BuildNTLMCredentialCache(),
                requestTimeout);

            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for VerifyPin.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for VerifyPin: Message: {response.Header.ErrorInfo.Message};");

            return response.IsPinValid;

        }

        public void ActivateCard(AccountIdentifier accountIdentifier, string paymentInstrumentIdentifier, string source = null)
        {
            GetTimeout("X-GD-Bos-Dcpp-ActivateCardTimeOut", out var requestTimeout);
            if (requestTimeout != null && requestTimeout <= 1) throw new TimeoutException("Timeout calling external service."); //for QA test
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);
            var request = new ActivateCardRequest
            {
                Header = new RequestHeader() { RequestId = reqId, Source = _source },
                ProgramCode = DomainContext.Current?.ProgramCode?.ToString(),
                AccountIdentifier = accountIdentifier.ToString(),
                PaymentInstrumentIdentifier = paymentInstrumentIdentifier,
                Source = source
            };

            var response = _serviceInvokeProvider.GetWebResponseWithCredentialCache<ActivateCardRequest, Dcpp.Contract.Message.ActivateCardResponse>(
                _dcppBaseUrl + _activateCardUrl, "POST", request, BuildNTLMCredentialCache(), requestTimeout);

            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for ActivateCard.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for ActivateCard: Message: {response.Header.ErrorInfo.Message};");
        }

        public ValidateCVVResponse ValidateCvv(string pan, string cvv, string accountIdentifier, CardExpirationDate cardExpirationDate, bool usePan)
        {
            GetTimeout("X-GD-Bos-Dcpp-ValidateCvvTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            var request = new ValidateCVVRequest
            {
                Header = new RequestHeader() { RequestId = reqId, Source = _source },
                ProgramCode = DomainContext.Current?.ProgramCode?.ToString(),
                AccountIdentifier = accountIdentifier,
                CVV = cvv,
                Pan = pan,
                ExpirationDate = new Dcpp.Contract.Data.ExpirationDate
                {
                    Month = cardExpirationDate?.CardExpirationMonth,
                    Year = cardExpirationDate?.CardExpirationYear
                },
                UsePan = usePan
            };

            var response = _serviceInvokeProvider.GetWebResponseWithCredentialCache<ValidateCVVRequest, Dcpp.Contract.Message.ValidateCVVResponse>(
                _dcppBaseUrl + _validateCardUrl, "POST", request, BuildNTLMCredentialCache(), requestTimeout);

            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for ValidateCvv.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for ValidateCvv: Message: {response.Header.ErrorInfo.Message};");

            return response;
        }

        public AdjustBalanceResponse AdjustBalance(
            AccountIdentifier accountIdentifier,
            decimal amount,
            bool allowNegativeBalance,
            string currencyCode,
            string transClass,
            string transactionReferenceId,
            string description,
            string comment,
            string commentPostfix = ",FT",
            int? requestTimeout = null,
            string originalTransactionId = null)
        {
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            if (requestTimeout == null)
                GetTimeout("X-GD-Bos-Dcpp-AdjustBalanceTimeOut", out requestTimeout, accountIdentifier);

            if (OptionsContext.Current.IsDefined("X-GD-Bos-Dcpp-AdjustBalanceFailure"))
            {
                throw new DcppException(OptionsContext.Current.GetInt("X-GD-Bos-Dcpp-AdjustBalanceFailure", 0), 0, "DCPP did not return success for AdjustAccountBalance");
            }

            AdjustAccountBalanceRequest request = new AdjustAccountBalanceRequest
            {
                AccountId = accountIdentifier.ToString(),
                Adjustment = new Dcpp.Contract.Data.CurrencyAmount
                {
                    Amount = amount,
                    CurrencyCode = currencyCode
                },
                TransClass = transClass,
                TransactionReferenceId = transactionReferenceId,
                Description = description,
                Comment = comment + commentPostfix,
                AllowNegativeBalance = allowNegativeBalance,
                Header = new RequestHeader() { RequestId = reqId, Source = _source },
                ProgramCode = DomainContext.Current?.ProgramCode?.ToString()
            };

            var response = _serviceInvokeProvider.GetWebResponseWithCredentialCache<AdjustAccountBalanceRequest, Dcpp.Contract.Message.AdjustAccountBalanceResponse>(
                        _dcppBaseUrl + _adjustAccountBalanceUrl, "POST", request, BuildNTLMCredentialCache(), requestTimeout);

            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for AdjustAccountBalance.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                        $"A downstream provider did not return success for AdjustAccountBlanace: Message: {response.Header.ErrorInfo.Message};");

            return new AdjustBalanceResponse
            {
                AvailableBalance = response.AvailableBalance.Amount,
                CurrentBalance = response.CurrentBalance.Amount,
                CurrencyCode = response.AvailableBalance.CurrencyCode
            };
        }

        [ExcludeFromCodeCoverage(Justification = "Will be tested later.")]
        public AdjustAccountBalanceResponse AdjustBalanceForAccountTransaction(
            AccountIdentifier accountIdentifier,
            decimal amount,
            bool allowNegativeBalance,
            string currencyCode,
            string transClass,
            string transactionReferenceId,
            string description,
            string comment,
            string commentPostfix = ",FT",
            int? requestTimeout = null)
        {
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            AdjustAccountBalanceRequest request = new AdjustAccountBalanceRequest
            {
                AccountId = accountIdentifier.ToString(),
                Adjustment = new Dcpp.Contract.Data.CurrencyAmount
                {
                    Amount = amount,
                    CurrencyCode = currencyCode
                },
                TransClass = transClass,
                TransactionReferenceId = transactionReferenceId,
                Description = description,
                Comment = comment + commentPostfix,
                AllowNegativeBalance = allowNegativeBalance,
                Header = new RequestHeader() { RequestId = reqId, Source = _source },
                ProgramCode = DomainContext.Current?.ProgramCode?.ToString()
            };

            var response = _serviceInvokeProvider.GetWebResponseWithCredentialCache<AdjustAccountBalanceRequest, Dcpp.Contract.Message.AdjustAccountBalanceResponse>(
                        _dcppBaseUrl + _adjustAccountBalanceUrl, "POST", request, BuildNTLMCredentialCache(), requestTimeout);

            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for AdjustAccountBalance.");

            return response;
        }

        public AdjustBalanceResponse AdjustPurseBalance(
            AccountIdentifier accountIdentifier,
            AccountBalanceIdentifier accountBalanceIdentifier,
            decimal amount,
            bool allowNegativeBalance,
            string currencyCode,
            string transClass,
            string transactionReferenceId,
            string description,
            string comment,
            string commentPostfix = ",FT")
        {
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);
            GetTimeout("X-GD-Bos-Dcpp-AdjustPurseBalanceTimeOut", out var requestTimeout, accountBalanceIdentifier);

            AdjustPurseBalanceRequest request = new AdjustPurseBalanceRequest
            {
                AccountIdentifier = accountIdentifier.ToString(),
                PurseIdentifier = accountBalanceIdentifier.ToString(),
                Adjustment = new Dcpp.Contract.Data.CurrencyAmount
                {
                    Amount = amount,
                    CurrencyCode = currencyCode
                },
                TransClass = transClass,
                TransactionReferenceId = transactionReferenceId,
                Description = description,
                Comment = comment + commentPostfix,
                AllowNegativeBalance = allowNegativeBalance,
                Header = new RequestHeader() { RequestId = reqId, Source = _source },
                ProgramCode = DomainContext.Current?.ProgramCode?.ToString()
            };

            var response = _serviceInvokeProvider.GetWebResponseWithCredentialCache<AdjustPurseBalanceRequest, AdjustPurseBalanceResponse>(
                _dcppBaseUrl + _adjustPurseBalanceUrl, "POST", request, BuildNTLMCredentialCache(), requestTimeout);

            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for AdjustPurseBalance.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0),
                    response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for AdjustPurseBalance: Message: {response.Header.ErrorInfo.Message};");

            return new AdjustBalanceResponse
            {
                AvailableBalance = response.AvailableBalance.Amount,
                CurrentBalance = response.CurrentBalance.Amount,
                CurrencyCode = response.AvailableBalance.CurrencyCode
            };
        }

        public ChangeAccountStatusResponse ChangeAccountStatus(string accountId, string accountStatus, string gdAccountStatus = null, List<AccountStatusReason> accountStatusReasonsToAdd = null, List<AccountStatusReason> accountStatusReasonsToRemove = null, Guid? userIdentifier = null)
        {
            GetTimeout("X-GD-Bos-Dcpp-ChangeAccountStatusTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            if (_settings.RetryMaxTimeoutEnable)
                requestTimeout = 0;

            var response = _serviceInvokeProvider.GetWebResponseWithCredentialCache<ChangeAccountStatusRequest, ChangeAccountStatusResponse>(
                _dcppBaseUrl + _changeAccountStatus,
                "POST",
                new ChangeAccountStatusRequest()
                {
                    AccountId = accountId,
                    Status = accountStatus,
                    GdAccountStatus = gdAccountStatus,
                    Header = new RequestHeader() { RequestId = reqId, Source = _source },
                    ProgramCode = DomainContext.Current?.ProgramCode?.ToString()
                }, BuildNTLMCredentialCache(), requestTimeout);
            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for {_changeAccountStatus}.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                        $"A downstream provider did not return success for {_changeAccountStatus}: Message: {response.Header.ErrorInfo.Message};");

            return response;

        }

        public ChangePurseStatusResponse ChangePurseStatus(string accountIdentifier, string purseIdentifier, string accountStatus)
        {
            GetTimeout("X-GD-Bos-Dcpp-ChangePurseStatusTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);
            if (reqId == Guid.Empty) reqId = Guid.NewGuid();
            if (requestTimeout <= 1) throw new TimeoutException("Timeout error.");

            var response = _serviceInvokeProvider.GetWebResponseWithCredentialCache<ChangePurseStatusRequest, ChangePurseStatusResponse>(
                _dcppBaseUrl + _changePurseStatus,
                "POST",
                new ChangePurseStatusRequest()
                {
                    AccountIdentifier = accountIdentifier,
                    PurseIdentifier = purseIdentifier,
                    Status = accountStatus,
                    Header = new RequestHeader() { RequestId = reqId, Source = _source },
                    ProgramCode = DomainContext.Current?.ProgramCode?.ToString()
                }, BuildNTLMCredentialCache(), requestTimeout);
            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for {_changePurseStatus}.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for {_changePurseStatus}: Message: {response.Header.ErrorInfo.Message};");

            return response;

        }

        public ChangeCardStatusResponse ChangeCardStatus(string accountId, string cardStatus, Guid? paymentIdentifier = null, string lifeTimeEventType = null)
        {
            GetTimeout("X-GD-Bos-Dcpp-ChangeCardStatusTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            var response = _serviceInvokeProvider.GetWebResponseWithCredentialCache<ChangeCardStatusRequest, ChangeCardStatusResponse>(
                _dcppBaseUrl + _changeCardStatus,
                "POST",
                new ChangeCardStatusRequest()
                {
                    AccountId = accountId,
                    Status = cardStatus,
                    Header = new RequestHeader() { RequestId = reqId, Source = _source },
                    ProgramCode = DomainContext.Current?.ProgramCode?.ToString(),
                    PaymentIdentifier = paymentIdentifier,
                    LifeTimeEventType = lifeTimeEventType
                }, BuildNTLMCredentialCache(), requestTimeout);
            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for {_changeCardStatus}.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for {_changeCardStatus}: Message: {response.Header.ErrorInfo.Message};");

            return response;

        }

        public DeleteSegmentResponse DeleteSegment(string paymentIdentifier, string segmentName, string accountIdentifier)
        {
            GetTimeout("X-GD-Bos-Dcpp-ChangeCardStatusTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            var response = _serviceInvokeProvider.GetWebResponseWithCredentialCache<DeleteSegmentRequest, DeleteSegmentResponse>(
                _dcppBaseUrl + _deleteSegment,
                "POST",
                new DeleteSegmentRequest()
                {
                    PaymentIdentifier = paymentIdentifier,
                    SegmentName = segmentName,
                    AccountIdentifier = accountIdentifier,
                    Header = new RequestHeader() { RequestId = reqId, Source = _source },
                    ProgramCode = DomainContext.Current?.ProgramCode?.ToString()
                }, BuildNTLMCredentialCache(), requestTimeout);
            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for {_deleteSegment}.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for {_deleteSegment}: Message: {response.Header.ErrorInfo.Message};");
            return response;

        }
        public AddSegmentResponse AddSegment(string paymentIdentifier, string segmentName, DateTime startDate, DateTime endDate, string accountIdentifier)
        {
            GetTimeout("X-GD-Bos-Dcpp-ChangeCardStatusTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            var response = _serviceInvokeProvider.GetWebResponseWithCredentialCache<AddSegmentRequest, AddSegmentResponse>(
                _dcppBaseUrl + _addSegment,
                "POST",
                new AddSegmentRequest()
                {
                    PaymentIdentifier = paymentIdentifier,
                    SegmentName = segmentName,
                    StartDate = startDate.ToString(),
                    EndDate = endDate.ToString(),
                    AccountIdentifier = accountIdentifier,
                    Header = new RequestHeader() { RequestId = reqId, Source = _source },
                    ProgramCode = DomainContext.Current?.ProgramCode?.ToString()
                }, BuildNTLMCredentialCache(), requestTimeout);
            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for {_addSegment}.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for {_addSegment}: Message: {response.Header.ErrorInfo.Message};");
            return response;
        }

        public UpdateAccountResponse UpdateAccount(UpdateAccountRequest request, string middleName = null)
        {
            GetTimeout("X-GD-Bos-Dcpp-UpdateAddressTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            var response = _serviceInvokeProvider.GetWebResponseWithCredentialCache<UpdateAccountRequest, UpdateAccountResponse>(
                _dcppBaseUrl + _updateAddress,
                "POST",
                new UpdateAccountRequest()
                {
                    Header = new RequestHeader() { RequestId = reqId, Source = _source },
                    ProgramCode = DomainContext.Current?.ProgramCode?.ToString(),
                    AccountIdentifier = request.AccountIdentifier,
                    PostalAddress = request.PostalAddress,
                    PhoneNumbers = request.PhoneNumbers,
                    Name = request.Name,
                    BusinessName = request.BusinessName,
                    PaymentIdentifierIdentifier = request.PaymentIdentifierIdentifier,
                    HomeAddressUpdateUsers = request.HomeAddressUpdateUsers,
                    EmailAddress = request.EmailAddress,
                }, BuildNTLMCredentialCache(), requestTimeout);
            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for {_updateAddress}.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                        $"A downstream provider did not return success for {_updateAddress}: Message: {response.Header.ErrorInfo.Message};");

            return response;
        }


        public OverrideProductResponse OverrideProduct(string accountIdentifier, string programCode, bool isRevert, List<ProductFeatureGroupOverride> productFeatureGroups)
        {
            int? requestTimeout = null;
            GetTimeout("X-GD-Bos-URH-Dcpp-OverrideProductTimeOut", out requestTimeout);

            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            var productFeatureGroupOverrides = new List<Gd.Bos.Shared.Common.Dcpp.Contract.Data.ProductFeatureGroupOverride>();
            if (!isRevert)
            {
                foreach (var productFeature in productFeatureGroups)
                {
                    var productFeatureGroupOverride = new Gd.Bos.Shared.Common.Dcpp.Contract.Data.ProductFeatureGroupOverride()
                    {
                        ProductTierAttribute = productFeature.ProductTierAttribute,
                        Value = productFeature.Value
                    };
                    productFeatureGroupOverrides.Add(productFeatureGroupOverride);
                }
            }

            var _overrideProduct = "/Account/OverrideProduct";
            var response = _serviceInvokeProvider.GetWebResponseWithCredentialCache<OverrideProductRequest, OverrideProductResponse>(
                _dcppBaseUrl + "/" + _overrideProduct,
                "POST",
                new OverrideProductRequest()
                {
                    Header = new Gd.Bos.Shared.Common.Dcpp.Contract.Message.RequestHeader() { RequestId = reqId, Source = _source },
                    AccountIdentifier = accountIdentifier,
                    ProgramCode = programCode,
                    IsRevert = isRevert,
                    productFeatureGroupOverrides = productFeatureGroupOverrides
                }, BuildNTLMCredentialCache(), requestTimeout);

            if (response == null)
                throw new Exception($"DCPP did not return a recognizable response for {_overrideProduct}.");

            if (response.Header.StatusCode != "200")
                throw new BaseException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"DCPP did not return success for {_updateProduct}: Message: {response.Header.ErrorInfo.Message}");

            return response;
        }

        public UpdateProductResponse UpdateProduct(string accountIdentifier, string programCode, int productTierKey, string productMaterialType, string cardStock = null)
        {
            GetTimeout("X-GD-Bos-Dcpp-UpdateProductTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            UpdateProductRequest request = new UpdateProductRequest()
            {
                Header = new RequestHeader() { RequestId = reqId, Source = _source },
                AccountIdentifier = accountIdentifier,
                ProgramCode = programCode,
                ProductTierKey = productTierKey,
                ProductMaterialType = productMaterialType
            };

            if (!String.IsNullOrEmpty(cardStock))
            {
                request.CardStock = cardStock;
            }

            var response = _serviceInvokeProvider.GetWebResponseWithCredentialCache<UpdateProductRequest, UpdateProductResponse>(
                _dcppBaseUrl + _updateProduct, "POST", request, BuildNTLMCredentialCache(), requestTimeout);
            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for {_updateProduct}.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for {_updateProduct}: Message: {response.Header.ErrorInfo.Message};");

            return response;
        }

        public ActivateOrSuspendTokenResponse ActivateOrSuspendToken(AccountIdentifier accountIdentifier, string tokenId,
            TokenAction action, string comment)
        {
            GetTimeout("X-GD-Bos-Dcpp-ActivateOrSuspendTokenTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            Gd.Bos.Dcpp.Contract.Enum.TokenAction tokenAction;
            switch (action)
            {
                case TokenAction.Activate:
                    tokenAction = Dcpp.Contract.Enum.TokenAction.Activate;
                    break;
                case TokenAction.Delete:
                    tokenAction = Dcpp.Contract.Enum.TokenAction.Delete;
                    break;
                case TokenAction.Suspend:
                    tokenAction = Dcpp.Contract.Enum.TokenAction.Suspend;
                    break;
                case TokenAction.UnSuspend:
                    tokenAction = Dcpp.Contract.Enum.TokenAction.UnSuspend;
                    break;
                default:
                    tokenAction = Dcpp.Contract.Enum.TokenAction.Activate;
                    break;
            }

            var response = _serviceInvokeProvider.GetWebResponseWithCredentialCache<ActivateOrSuspendTokenRequest, ActivateOrSuspendTokenResponse>(
                _dcppBaseUrl + _activateOrSuspendToken,
                "POST",
                new ActivateOrSuspendTokenRequest()
                {
                    Header = new RequestHeader() { RequestId = reqId, Source = _source },
                    ProgramCode = DomainContext.Current?.ProgramCode?.ToString(),
                    AccountIdentifier = accountIdentifier.ToString(),
                    TokenAction = tokenAction.ToString(),
                    TokenId = tokenId,
                    Comment = comment
                },
                BuildNTLMCredentialCache(), requestTimeout);
            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for {_activateOrSuspendToken}.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for {_activateOrSuspendToken}: Message: {response.Header.ErrorInfo.Message};");

            return response;
        }

        public AddPurseResponse AddPurseToAccount(string programCode, AccountIdentifier accountIdentifier, Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.PurseType purseType, string userDescription, decimal? goalAmount, string goalDate, string iconName, string purseSubType)
        {
            GetTimeout("X-GD-Bos-Dcpp-AddPurseToAccountTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            var response = _serviceInvokeProvider.GetWebResponseWithCredentialCache<AddPurseToAccountRequest, AddPurseToAccountResponse>(
                _dcppBaseUrl + _addPurse,
                "POST",
                new AddPurseToAccountRequest()
                {
                    Header = new RequestHeader() { RequestId = reqId, Source = _source },
                    ProgramCode = programCode,
                    AccountIdentifier = accountIdentifier.ToString(),
                    UserDescription = userDescription,
                    PurseType = purseType.ToPurseType().ToString(),
                    GoalAmount = goalAmount,
                    GoalDate = goalDate,
                    IconName = iconName,
                    PurseSubType = purseSubType
                },
                BuildNTLMCredentialCache(), requestTimeout);
            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for {_addPurse}.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for {_addPurse}: Message: {response.Header.ErrorInfo.Message};");

            return new Domain.Services.Dcpp.AddPurseResponse
            {
                AccountIdentifier = response.AccountIdentifier,
                PurseType = response.PurseType.ToPurseType(),
                AccountBalanceIdentifier = response.AccountBalanceIdentifier,
                AccountBalanceKey = response.AccountBalanceKey,
                AvailableBalance = new CurrencyAmount { Amount = response.AvailableBalance.Amount, CurrencyCode = response.AvailableBalance.CurrencyCode },
                AvailableBalanceAsOfDate = response.AvailableBalanceAsOfDate,
                CurrentBalance = new CurrencyAmount { Amount = response.CurrentBalance.Amount, CurrencyCode = response.CurrentBalance.CurrencyCode },
                CurrentBalanceAsOfDate = response.CurrentBalanceAsOfDate,
                UserDescription = response.UserDescription,
                IsHidden = response.IsHidden,
                Status = (PurseStatus)((int)response.Status),
                GoalAmount = response.GoalAmount,
                IconName = response.IconName,
                CreateDate = response.CreateDate,
                ChangeDate = response.ChangeDate,
                PurseNumber = response.PurseNumber,
                PurseSubType = response.PurseSubType
            };
        }


        public SetCycleResponse SetCycle(AccountIdentifier accountIdentifier)
        {
            GetTimeout("X-GD-Bos-Dcpp-SetCycleTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            var response = _serviceInvokeProvider.GetWebResponseWithCredentialCache<SetCycleRequest, SetCycleResponse>(
                _dcppBaseUrl + _setCycle,
                "POST",
                new SetCycleRequest()
                {
                    Header = new RequestHeader() { RequestId = reqId, Source = _source },
                    AccountIdentifier = accountIdentifier.ToString()
                },
                BuildNTLMCredentialCache(), requestTimeout);
            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for {_setCycle}.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for {_setCycle}: Message: {response.Header.ErrorInfo.Message};");

            return response;
        }

        public ActivateSampleCardResponse ActivateSamplesCard(AccountIdentifier accountIdentifier,
            string cardProxy,
            bool? isEmv,
            string cardStockCode,
            string embossedName,
            string accountNumber,
            string productCode)
        {
            GetTimeout("X-GD-Bos-Dcpp-ActivateSamplesCardTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            var response = _serviceInvokeProvider.GetWebResponseWithCredentialCache<ActivateSampleCardRequest, ActivateSampleCardResponse>(
                _dcppBaseUrl + _activateSamplesCard,
                "POST",
                new ActivateSampleCardRequest()
                {
                    Header = new RequestHeader() { RequestId = reqId, Source = _source },
                    AccountIdentifier = accountIdentifier.ToString(),
                    CardProxy = cardProxy,
                    IsEmv = isEmv,
                    CardStockCode = cardStockCode,
                    EmbossedName = embossedName,
                },
                BuildNTLMCredentialCache(), requestTimeout);
            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for {_activateSamplesCard}.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for {_activateSamplesCard}: Message: {response.Header.ErrorInfo.Message};");

            return response;
        }

        public GetAccountBalanceResponse GetAccountBalance(string programCode, string accountIdentifier)
        {
            GetTimeout("X-GD-Bos-Dcpp-GetAccountBalance", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            var response = _serviceInvokeProvider.GetWebResponseWithCredentialCache<GetAccountBalanceRequest, GetAccountBalanceResponse>(
                _dcppBaseUrl + _getAccountBalance,
                "POST",
                new GetAccountBalanceRequest()
                {
                    Header = new RequestHeader() { RequestId = reqId, Source = _source },
                    AccountId = accountIdentifier.ToString(),
                    ProgramCode = programCode
                },
                BuildNTLMCredentialCache(),
                requestTimeout);
            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for {_getAccountBalance}.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for {_setCycle}: Message: {response.Header.ErrorInfo.Message};");

            return response;
        }

        public UpdateCreditLimitHistoryResponse UpdateCreditLimitHistory(UpdateCreditLimitHistoryRequest request)
        {
            GetTimeout("X-GD-Bos-Dcpp-UpdateCreditLimitHistory", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);
            if (request!.Header == null)
            {
                request.Header = new RequestHeader
                {
                    RequestId = Guid.NewGuid()
                };
            }

            var response = _serviceInvokeProvider.GetWebResponseWithCredentialCache<UpdateCreditLimitHistoryRequest, UpdateCreditLimitHistoryResponse>(
                _dcppBaseUrl + _updateCreditLimitHistory,
                "POST",
                request,
                BuildNTLMCredentialCache(),
                requestTimeout
            );
            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for {_updateCreditLimitHistory}.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for {_updateCreditLimitHistory}: Message: {response.Header.ErrorInfo.Message};");

            return response;
        }

        public LinkCardResponse LinkCard(LinkCardRequest linkCardRequest)
        {
            throw new NotImplementedException();
        }

        private void GetTimeout(string headerName, out int? requestTimeout)
        {
            GetTimeout(headerName, out requestTimeout, "");
        }
        private void GetTimeout(string headerName, out int? requestTimeout, AccountIdentifier accountIdentifier)
        {
            GetTimeout(headerName, out requestTimeout, accountIdentifier?.ToString());
        }
        private void GetTimeout(string headerName, out int? requestTimeout, AccountBalanceIdentifier accountBalanceIdentifier)
        {
            GetTimeout(headerName, out requestTimeout, accountBalanceIdentifier?.ToString());
        }
        private void GetTimeout(string headerName, out int? requestTimeout, string id)
        {
            requestTimeout = null;
            if (OptionsContext.Current.IsDefined(headerName))
            {
                requestTimeout = 1;
                if (int.TryParse(OptionsContext.Current.GetString(headerName), out var rt))
                    requestTimeout = rt;
                else if (OptionsContext.Current.GetString(headerName).Equals(id, StringComparison.CurrentCultureIgnoreCase))
                    requestTimeout = 1;
                else
                    requestTimeout = null;

                // 0 throws ArgumentOutOfRangeException in web client
                if (requestTimeout == 0)
                    requestTimeout = 1;
            }
        }
        public decimal GetYearToDateAccountFees(Guid requestId, string programCode, string accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public bool IsRoutingToCPM(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        private readonly IServiceInvokeProvider _serviceInvokeProvider;
        private const string _source = "RequestHandler";
        private readonly string _dcppBaseUrl;
        private const string _createAccountUrl = "/Account/Create";
        private const string _addAccountHolderUrl = "/Account/AddAccountHolder";
        private const string _orderCardUrl = "/Account/OrderCard";
        private const string _adjustAccountBalanceUrl = "/Account/Balance/Adjust";
        private const string _adjustPurseBalanceUrl = "/Account/Purse/Balance/Adjust";
        private const string _changeAccountStatus = "/Account/Status/Change";
        private const string _changePurseStatus = "/Purse/Status/Change";
        private const string _changeCardStatus = "/Card/Status/Change";

        private const string _addSegment = "/Segment/AddSegment";
        private const string _deleteSegment = "/Segment/DeleteSegment";

        private const string _getCardDetailsUrl = "/Card";
        private const string _validateCvvByPanUrl = "/Card/ValidateCVVByPan";
        private const string _setPinUrl = "/Card/SetPin";
        private const string _verifyPinUrl = "/Card/VerifyPin";
        private const string _activateCardUrl = "/Card/ActivateCard";
        private const string _validateCardUrl = "/Card/ValidateCVV";
        //private const string _reportLostStolenUrl = "/Card/ReportLostStolen"; //please use _reportLostStolenUrlV2
        private const string _reportLostStolenUrlV2 = "/Card/ReportLostStolenV2";
        private const string _updateAddress = "/Account/Update ";
        private const string _addPurse = "/Account/AddPurse";
        private const string _updateProduct = "/Account/UpdateProduct";
        private const string _activateOrSuspendToken = "/Account/ActivateSuspendToken";
        private const string _setCycle = "/Account/SetCycle";
        private const string _activateSamplesCard = "/Card/ActivateSampleCard";
        private const string _getAccountBalance = "/Account/Balance";
        private const string _updateCreditLimitHistory = "/Account/UpdateCreditLimitHistory";
    }
}
