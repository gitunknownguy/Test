﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Services.Crypto;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Logic;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Newtonsoft.Json;
using NLog;
using RequestHandler.Core.Domain.Services.RetailCard;
using RequestHandler.Core.Domain.Services.RetailCard.Enum;
using RequestHandler.Core.Domain.Services.RetailCard.Model;
using GetRetailCardBalanceTransferStatusResponse = RequestHandler.Core.Domain.Services.RetailCard.Model.GetRetailCardBalanceTransferStatusResponse;
using GetTransactionsRequest = RequestHandler.Core.Domain.Services.RetailCard.Model.GetTransactionsRequest;
using GetTransactionsResponse = RequestHandler.Core.Domain.Services.RetailCard.Model.GetTransactionsResponse;
using ReportLostStolenRequest = RequestHandler.Core.Domain.Services.RetailCard.Model.ReportLostStolenRequest;
using ReportLostStolenResponse = RequestHandler.Core.Domain.Services.RetailCard.Model.ReportLostStolenResponse;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using SetAtmPinRequest = RequestHandler.Core.Domain.Services.RetailCard.Model.SetAtmPinRequest;
using SetAtmPinResponse = RequestHandler.Core.Domain.Services.RetailCard.Model.SetAtmPinResponse;
using TransactionStatus = RequestHandler.Core.Domain.Services.RetailCard.Model.TransactionStatus;
using VerificationActivityType = Gd.Bos.RequestHandler.Core.Domain.Model.Account.VerificationActivityType;
using VerificationStatus = Gd.Bos.RequestHandler.Core.Domain.Model.Account.VerificationStatus;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class RetailCardService : IRetailCardService
    {
        private readonly IServiceInvokeProvider _serviceInvokeProvider;
        private readonly IProductService _productService;
        private readonly ICryptoService _cryptoService;
        private readonly IAccountRepository _accountRepository;
        private readonly string _gssAccountUtilityBaseUrl;
        private readonly IPaymentIdentifierRepository _paymentIdentifierRepository;
        private readonly ITokenizerService _tokenizerService;

        public RetailCardService(IServiceInvokeProvider serviceInvokeProvider, IProductService productService,
            ICryptoService cryptoService, IAccountRepository accountRepository, IPaymentIdentifierRepository paymentIdentifierRepository, ITokenizerService tokenizerService)
        {
            _serviceInvokeProvider = serviceInvokeProvider;
            _productService = productService;
            _cryptoService = cryptoService;
            _accountRepository = accountRepository;
            _paymentIdentifierRepository = paymentIdentifierRepository;
            _tokenizerService = tokenizerService;
            _gssAccountUtilityBaseUrl = Configuration.Configuration.Current.GSSLegacyAccountUtilityBaseUrl;
        }

        public ValidateCvvResponse ValidateCard(ValidateCvvRequest request)
        {

            _logger.Info("Going into RetailCardService ValidateCard before call ValidateCvv");

            ValidateCvvResponse validateCvvResponse = null;
            GetTimeout("X-GD-Bos-GSSLegacyAccountUtility-ValidateCard", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            try
            {
                //build Encrypt data for pan
                var privatePaymentInstrumentData = new PrivatePaymentInstrumentData
                {
                    Pan = request.Pan,
                    Cvv = request.Cvv,
                    IsExpirationDateOptional = request.IsExpirationDateOptional,
                    Expiration = new Expiration()
                    {
                        Month = request?.Expiration?.CardExpirationMonth,
                        Year = request?.Expiration?.CardExpirationyear
                    }
                };

                var encryptRequest = new EncryptRequest
                {
                    RequestHeader = new Domain.Services.Crypto.RequestHeader
                    {
                        RequestId = request.RequestHeader.RequestId,
                        Options = request.RequestHeader.Options
                    },
                    Version = "EC_v1",
                    ProgramCode = request.ProgramCode,
                    Data = JsonConvert.SerializeObject(privatePaymentInstrumentData),
                    Salt = request.RequestHeader.RequestId.ToString()
                };
                var encryptResponse = _cryptoService.Encrypt(encryptRequest);

                ValidateCardCvvRequest validateCardCvvRequest = new ValidateCardCvvRequest
                {
                    RequestId = request.RequestHeader.RequestId,
                    EncryptedCardData = new EncryptedDataRetail
                    {
                        Data = encryptResponse.EncryptedData.Data,
                        Version = encryptResponse.EncryptedData.Version,
                        EphemeralPublicKey = encryptResponse.EncryptedData.EphemeralPublicKey,
                        PublicKeyHash = encryptResponse.EncryptedData.PublicKeyHash
                    }
                };

                var output = JsonConvert.SerializeObject(validateCardCvvRequest);
                _logger.Debug($"RetailCardService - validatecard Call to GSS. Input:{output},requestId:{request.RequestHeader.RequestId}");

                //var url1 = "https://localhost:44316/programs/gbr/retailcard/validatecard";

                var url1 = _gssAccountUtilityBaseUrl + $"/programs/{request.ProgramCode}/retailcard/validatecard";

                var validateCardCvvResponse = _serviceInvokeProvider.GetWebResponse<ValidateCardCvvRequest, ValidateCardCvvResponse>(url1
                    , "POST", validateCardCvvRequest, requestTimeout);

                _logger.Debug($"RetailCardService - validatecard Response from GSS LegacyAccountUtility. RetailCardIdentifier:{validateCardCvvResponse.RetailCardIdentifier}, StatusCode:{validateCardCvvResponse.StatusCode}" +
                              $"SubStatusCode:{validateCardCvvResponse.SubStatusCode},Message:{validateCardCvvResponse.Message},RequestId:{request.RequestHeader.RequestId},ResponseId:{validateCardCvvResponse.ResponseId}");

                validateCvvResponse = new ValidateCvvResponse()
                {
                    IsExpired = validateCardCvvResponse.IsExpired,
                    IsRetailCard = true,
                    ResponseHeader = new ResponseHeader()
                    {
                        ResponseId = validateCardCvvResponse.ResponseId,
                        Message = validateCardCvvResponse.Message
                    }
                };

                //Check for OFAC case. If we have RetailCardIdentifier and PaymentIdentifierStatus.NotActivated, it's OFAC
                if (validateCardCvvResponse.RetailCardIdentifier.HasValue)
                {
                    validateCvvResponse.RetailCardIdentifier = validateCardCvvResponse.RetailCardIdentifier.ToString();

                    var piData = _paymentIdentifierRepository.GetPaymentIdentifierByPaymentIdentifierIdentifier(
                        PaymentIdentifierIdentifier.FromString(validateCvvResponse.RetailCardIdentifier));

                    if (piData?.PaymentIdentifierStatus == PaymentIdentifierStatus.NotActivated)
                    {
                        //PiData doesn't have AccountIdentifier, so need to call another SP for it.
                        var tempPiData =
                            _paymentIdentifierRepository.GetPaymentIdentifierByPaymentInstrumentIdentifier(
                                piData.PaymentInstrument.PaymentInstrumentIdentifier, out _);

                        VerificationActivity activityOFAC = _accountRepository.ReturnVerificationActivity(tempPiData.AccountHolderIdentifier, VerificationActivityType.OFAC);

                        //If the OFAC activity is null, or not failed(Passed, started), it's likely because of an enrollment failure, and we need to tell the FrontEnd to try to recover the enrollment
                        if (activityOFAC == null || activityOFAC.StatusKey != (short)VerificationStatus.Failed)
                        {
                            validateCvvResponse.RetailCardStatus = (int)RetailCardStatus.CardActivatedEnrollmentPending;
                            validateCvvResponse.AccountIdentifier = tempPiData.AccountIdentifier?.ToString();
                            validateCvvResponse.ResponseHeader.StatusCode = 4;
                            validateCvvResponse.ResponseHeader.SubStatusCode = 350;
                            validateCvvResponse.ResponseHeader.Message = "Card is in a state that indicates an enrollment error";
                            return validateCvvResponse;
                        }

                        validateCvvResponse.RetailCardStatus = (int)RetailCardStatus.CardPendingActivation;
                        validateCvvResponse.AccountIdentifier = tempPiData.AccountIdentifier?.ToString();
                        validateCvvResponse.ResponseHeader.StatusCode = 4;
                        validateCvvResponse.ResponseHeader.SubStatusCode = 348;
                        validateCvvResponse.ResponseHeader.Message = "Card already used but not active yet.";
                        return validateCvvResponse;
                    }

                }


                if (validateCardCvvResponse.StatusCode == 0)
                {
                    switch (validateCardCvvResponse.SubStatusCode)
                    {
                        case 0:
                            validateCvvResponse.RetailCardStatus = (int)RetailCardStatus.CardReadyForActivation;
                            validateCvvResponse.ResponseHeader.StatusCode = 0;
                            validateCvvResponse.ResponseHeader.SubStatusCode = 0;
                            validateCvvResponse.ResponseHeader.Message = "Success";
                            break;
                    }
                }
                else
                {
                    switch (validateCardCvvResponse.StatusCode)
                    {
                        case 100:
                            switch (validateCardCvvResponse.SubStatusCode)
                            {
                                case 100:
                                case 101:
                                case 106:
                                    validateCvvResponse.RetailCardStatus = (int)RetailCardStatus.InvalidCard;
                                    validateCvvResponse.ResponseHeader.StatusCode = 4;
                                    validateCvvResponse.ResponseHeader.SubStatusCode = 302; // Identification Failed with 100 - 106
                                    validateCvvResponse.ResponseHeader.Message = "Identification Failed";
                                    validateCvvResponse.ResponseHeader.Details = "Identification Failed with 100 - 106";
                                    break;
                                case 102:
                                case 103:
                                case 104:
                                case 105:
                                    validateCvvResponse.AccountIdentifier = validateCardCvvResponse.AccountIdentifier?.ToString();

                                    validateCvvResponse.RetailCardStatus = (int)RetailCardStatus.CardAlreadyActivated;
                                    validateCvvResponse.ResponseHeader.StatusCode = 0;
                                    validateCvvResponse.ResponseHeader.SubStatusCode = 0;
                                    validateCvvResponse.ResponseHeader.Message = "Success";

                                    if (validateCardCvvResponse.AccountIdentifier.HasValue)
                                    {
                                        #region Get PaymentIdentifier from Gbos DB
                                        var tuple = _accountRepository.GetPaymentIdentifierInfoByAccountIdentifier(validateCardCvvResponse.AccountIdentifier?.ToString());
                                        //note its pulling active AccountHolder_PaymentIdentifier. need to check

                                        List<PaymentInstrumentInfo> paymentInstrumentInfoList = tuple.Item3;

                                        PaymentInstrumentInfo paymentInstrumentInfo = paymentInstrumentInfoList.FirstOrDefault(a => a.PaymentInstrumentStatus == PaymentInstrumentStatus.Activated);

                                        validateCvvResponse.PaymentInstrumentIdentifier = paymentInstrumentInfo?.PaymentInstrumentIdentifier.ToString();
                                        #endregion
                                    }
                                    break;
                                case 400:
                                    validateCvvResponse.RetailCardStatus = (int)RetailCardStatus.InvalidCard;
                                    validateCvvResponse.ResponseHeader.StatusCode = 4;
                                    validateCvvResponse.ResponseHeader.SubStatusCode = 302; // Card not found 100 - 400
                                    validateCvvResponse.ResponseHeader.Message = "Card Not found";
                                    validateCvvResponse.ResponseHeader.Details = "Card not found 100 - 400";
                                    break;
                                case 401:
                                    validateCvvResponse.RetailCardStatus = (int)RetailCardStatus.InvalidCard;
                                    validateCvvResponse.ResponseHeader.StatusCode = 4;
                                    validateCvvResponse.ResponseHeader.SubStatusCode = 302; //Card Still In Inventory 100 - 401
                                    validateCvvResponse.ResponseHeader.Message = "Card Still In Inventory";
                                    validateCvvResponse.ResponseHeader.Details = "Card Still In Inventory 100 - 401";
                                    break;
                                default:
                                    validateCvvResponse.RetailCardStatus = (int)RetailCardStatus.InvalidCard;
                                    validateCvvResponse.ResponseHeader.StatusCode = 4;
                                    validateCvvResponse.ResponseHeader.SubStatusCode = 302; //Identification failed with 100 - xxx
                                    validateCvvResponse.ResponseHeader.Message = "Identification Failed";
                                    validateCvvResponse.ResponseHeader.Details = $"Identification failed with 100 - {validateCardCvvResponse.SubStatusCode}";
                                    break;
                            }

                            break;
                        case 113:
                            //This is the case where another NEC product has the Same BIN as Go2Bank. We need to remove the RetailCardIdentifier, and set the IsRetail Flag
                            validateCvvResponse.RetailCardIdentifier = null;
                            validateCvvResponse.IsRetailCard = false;
                            validateCvvResponse.RetailCardStatus = (int)RetailCardStatus.InvalidCard;
                            validateCvvResponse.ResponseHeader.StatusCode = 4;
                            validateCvvResponse.ResponseHeader.SubStatusCode = 302; // card not found
                            validateCvvResponse.ResponseHeader.Message = "Card Not found";
                            validateCvvResponse.ResponseHeader.Details = "Card Not found 113";
                            break;
                        case 200:
                            validateCvvResponse.RetailCardStatus = (int)RetailCardStatus.InvalidCard;
                            validateCvvResponse.ResponseHeader.StatusCode = 4;
                            validateCvvResponse.ResponseHeader.SubStatusCode = 302; //Identification Failed with 200
                            validateCvvResponse.ResponseHeader.Message = "Identification Failed";
                            validateCvvResponse.ResponseHeader.Details = "Identification Failed with 200";
                            break;
                        case 500:
                            validateCvvResponse.ResponseHeader.StatusCode = 500;
                            validateCvvResponse.ResponseHeader.Message = "Exception occurred in GSS Account Util Service";
                            _logger.Error("", $"RetailCardService - Exception occurred in GSS Account Util Service.Message:{validateCvvResponse.ResponseHeader.Message}, for ProgramCode:{request.ProgramCode}, requestId:{reqId}");
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"RetailCardService - ValidateCard method failed for ProgramCode:{request.ProgramCode}, requestId:{reqId}");

                validateCvvResponse = new ValidateCvvResponse()
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 500,
                        Message = "Error occurred while validating Retail card."
                    }
                };
            }
            return validateCvvResponse;
        }

        public bool VerifyPin(string programCode, string pan, CardExpirationDate expDate, string atmPin)
        {

            GetTimeout("X-GD-Bos-GSSLegacyAccountUtility-VerifyRetailAtmPin", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var requestId);
            if (OptionsContext.Current.ContainsKey("X-GD-Bos-Crypto-Recipient-Trusted-Public-Key-Hex"))
            {
                OptionsContext.Current =
                    OptionsContext.Current.Remove("X-GD-Bos-Crypto-Recipient-Trusted-Public-Key-Hex");
            }

            var data = new PrivateAtmPinData
            {
                Pan = pan,
                AtmPin = atmPin,
                Expiration = new Expiration()
                {
                    Month = expDate?.CardExpirationMonth,
                    Year = expDate?.CardExpirationyear
                }
            };

            var encryptRequest = new EncryptRequest
            {
                RequestHeader = new Domain.Services.Crypto.RequestHeader
                {
                    RequestId = requestId
                },
                Version = "EC_v1",
                ProgramCode = programCode,
                Data = JsonConvert.SerializeObject(data),
                Salt = requestId.ToString()
            };
            var encryptResponse = _cryptoService.Encrypt(encryptRequest);

            VerifyRetailAtmPinRequest verifyRetailAtmPinRequest = new VerifyRetailAtmPinRequest
            {
                RequestId = requestId,
                EncryptedCardData = new EncryptedDataRetail
                {
                    Data = encryptResponse.EncryptedData.Data,
                    Version = encryptResponse.EncryptedData.Version,
                    EphemeralPublicKey = encryptResponse.EncryptedData.EphemeralPublicKey,
                    PublicKeyHash = encryptResponse.EncryptedData.PublicKeyHash
                }
            };

            var input = JsonConvert.SerializeObject(verifyRetailAtmPinRequest);
            _logger.Debug($"RetailCardService - VerifyRetailAtmPin Call to GSS. input:{input},requestId:{requestId}");


            var url1 = _gssAccountUtilityBaseUrl + $"/programs/{programCode}/retailcard/validateatmpin";

            var verifyRetailAtmPinResponse = _serviceInvokeProvider.GetWebResponse<VerifyRetailAtmPinRequest, VerifyRetailAtmPinResponse>(url1
                , "POST", verifyRetailAtmPinRequest, requestTimeout);

            _logger.Debug(
                $"RetailCardService - verifyRetailAtmPin Response from GSS LegacyAccountUtility. isAtmPinValid:{verifyRetailAtmPinResponse.IsAtmPinValid},ResponseId:{verifyRetailAtmPinResponse.ResponseId}");

            return verifyRetailAtmPinResponse.IsAtmPinValid;
        }

        public ActivateRetailTempCardResponse ActivateRetailTempCard(string programCode, ActivateRetailTempCardRequest request)
        {
            //enable for testing
            //request = JsonConvert.DeserializeObject<ActivateRetailTempCardRequest>("{  \"requestId\": \"78916c93-a404-47ec-912a-06c0133fe0b3\",  \"programCode\": \"gbr\",  \"userData\": {    \"name\": {      \"firstName\": \"Gorwebozg\",      \"middleName\": \"\",      \"lastName\": \"McOAabc\"    },    \"address\": {      \"addressLine1\": \"3470 E Foothill blvd\",      \"addressLine2\": \"Ste 5256\",      \"city\": \"Pasadena\",      \"state\": \"CA\",      \"zipCode\": \"91107\",          \"type\": 2    },    \"email\": {      \"emailAddress\": \"gaozqn+87990@gmail.com\"    },    \"phone\": {      \"number\": \"2236571259\",      \"type\": 0    },    \"ssn\": \"110562389\",    \"dateOfBirth\": \"1990-12-31\"  },  \"retailCardIdentifier\": \"e690b26a-0f56-eb11-8128-0050569c7c95\",  \"destinationAccountIdentifier\": \"5BCB9D72-372E-4944-BB6C-D9CF7AAD2AE8\",  \"isPersoCardEligible\": true}");

            request.ProgramCode = programCode;
            var output = JsonConvert.SerializeObject(request);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);
            request.RequestId = reqId;

            _logger.Debug($"RetailCardService - ActivateRetailTempCard Call to GSS. requestId:{request.RequestId}");

            GetTimeout("X-GD-Bos-GSSLegacyAccountUtility-ActivateRetailTempCard", out var requestTimeout);

            //var url1 = "https://localhost:44316/programs/gbr/retailcard/activatetempcard";

            var url1 = _gssAccountUtilityBaseUrl + $"/programs/{programCode}/retailcard/activatetempcard";

            var response = _serviceInvokeProvider.GetWebResponse<ActivateRetailTempCardRequest, ActivateRetailTempCardResponse>(url1
                , "POST", request, requestTimeout);

            //enable for testing
            //response=JsonConvert.DeserializeObject<ActivateRetailTempCardResponse>("{	\"encryptedPan\": \"Da4ikRQZicROpnphhWPRMt2TaKsYmVl8IZDiTLwBDek=\",	\"last4Pan\": \"2310\",	\"expirationDate\": \"2024-09-30T00:00:00\",	\"activationDate\": \"0001-01-01T00:00:00\",	\"responseId\": \"7f6395cc-2a80-43f1-a994-ed65f63418bf\",	\"statusCode\": 0,	\"subStatusCode\": 0,	\"message\": \"success\",	\"encryptedCardData\": {   \"version\": \"EC_v1\",        \"ephemeralPublicKey\": \"MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEs/W+ZvJULkp7cJDN/Sqzh2XfFFIs3bD4p/Xdr2NltQ/tduLOwjBjQoxpQ3ZrmBf2bU8dIUokNtnn6KtC80oe/w==\",        \"publicKeyHash\": \"PiRV5ko8JYGxAtcNb9WV4aVg7aXIp8EsstmeUqqWzT8=\",        \"data\": \"Da4ikRQZicROpnphhWPRMt2TaKsYmVl8IZDiTLwBDek=\"  }}");
            return response;
        }

        public MigrateAccountResponse TransferRetailTempCardBalance(string programCode, string accountIdentifier, MigrateAccountRequest request)
        {
            request.ProgramCode = programCode;

            //Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);
            //request.RequestId = reqId;

            _logger.Debug($"RetailCardService - ActivateRetailTempCard Call to GSS. requestId:{request.RequestId}");

            GetTimeout("X-GD-Bos-GSSLegacyAccountUtility-ActivateRetailTempCard", out var requestTimeout);

            //var url1 = "https://localhost:44316/programs/{programCode}/retailcard/accounts/{accountIdentifier}/accountmigration";

            var url1 = _gssAccountUtilityBaseUrl + $"/programs/{programCode}/retailcard/accounts/{accountIdentifier}/accountmigration";

            var response = _serviceInvokeProvider.GetWebResponse<MigrateAccountRequest, MigrateAccountResponse>(url1
                , "POST", request, requestTimeout);

            return response;
        }

        public GetPursesResponse GetBalance(GetPursesRequest request)
        {
            GetPursesResponse getPursesResponse = null;

            _logger.Debug($"RetailCardService - GetBalance Call to GSS to pull balance from NEC. requestId:{request.RequestHeader.RequestId},accountIdentifier:{request.AccountIdentifier}");

            GetTimeout("X-GD-Bos-GSSLegacyAccountUtility-GetBalance", out var requestTimeout);

            GetBalanceRequest getBalanceRequest = new GetBalanceRequest()
            {
                RequestId = request.RequestHeader.RequestId.ToString(),
                ProgramCode = request.ProgramCode,
                AccountIdentifier = request.AccountIdentifier
            };

            //_gssAccountUtilityBaseUrl = "https://gssactutl.qa.nextestate.com/legacyaccountutility/V1";

            var url1 = _gssAccountUtilityBaseUrl + $"/programs/{request.ProgramCode}/retailcard/getbalance";

            try
            {
                var response = _serviceInvokeProvider.GetWebResponse<GetBalanceRequest, GetBalanceResponse>(url1
                    , "POST", getBalanceRequest, requestTimeout);


                if (response.StatusCode == 0)
                {
                    //var dtAvailableBalanceAsOfUtc = TimeZoneInfo.ConvertTimeToUtc(response.AvailableBalance.AsOf, TimeZoneInfo.Local);
                    //var dtLedgerBalanceAsOfUtc = TimeZoneInfo.ConvertTimeToUtc(response.LedgerBalance.AsOf, TimeZoneInfo.Local);

                    getPursesResponse = new GetPursesResponse()
                    {
                        Purses = new Purse[]
                        {
                            new Purse()
                            {
                                AvailableBalance = response.AvailableBalance.Amount,
                                AvailableBalanceAsOfDateTime = response.AvailableBalance.AsOf,
                                LedgerBalance = response.LedgerBalance.Amount,
                                LedgerBalanceAsOfDateTime = response.LedgerBalance.AsOf,
                                PurseType = PurseType.Primary,
                                Status = PurseStatus.Active
                            }
                        }

                    };
                    getPursesResponse.ResponseHeader = new ResponseHeader()
                    {
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success",
                        ResponseId = request.RequestHeader.RequestId
                    };
                }
                else
                {
                    getPursesResponse = new GetPursesResponse();
                    getPursesResponse.ResponseHeader = new ResponseHeader()
                    {
                        StatusCode = 10,
                        SubStatusCode = 0,
                        Message = response.Message,
                        ResponseId = request.RequestHeader.RequestId
                    };
                }

            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"RetailCardService - GetBalance method failed for ProgramCode:{request.ProgramCode}, requestId:{request.RequestHeader.RequestId},AccountIdentifier:{request.AccountIdentifier}");

                getPursesResponse = new GetPursesResponse()
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 500,
                        Message = "Error occurred while fetching Retail card GetBalance."
                    }
                };
            }

            return getPursesResponse;
        }

        public GetRetailSaleInfoResponse GetRetailSaleInfo(GetRetailSaleInfoRequest request)
        {
            GetRetailSaleInfoResponse response;
            try
            {
                var uri = $"{_gssAccountUtilityBaseUrl}/retailsales/{request.CardReferenceId}";
                response = _serviceInvokeProvider.GetWebResponse<GetRetailSaleInfoResponse>(uri, "GET", null);

            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"RetailCardService - GetRetailSaleInfo method failed for requestId:{request.RequestId},CardReferenceId:{request.CardReferenceId}");

                response = new GetRetailSaleInfoResponse()
                {
                    ResponseId = request.RequestId,
                    StatusCode = 500,
                    Message = "Error occurred while fetching Retail card GetRetailSaleInfo."
                };
            }
            return response;
        }

        public GetRetailSaleInfoResponse GetRetailSaleInfo(int pinKey)
        {
            GetRetailSaleInfoResponse response;

            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            try
            {
                var uri = $"{_gssAccountUtilityBaseUrl}/retailsales/pinkey/{pinKey}";
                response = _serviceInvokeProvider.GetWebResponse<GetRetailSaleInfoResponse>(uri, "GET", null);

            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"RetailCardService - GetRetailSaleInfo method failed for requestId:{reqId},pinKey:{pinKey}");

                response = new GetRetailSaleInfoResponse()
                {
                    ResponseId = reqId,
                    StatusCode = 500,
                    Message = "Error occurred while fetching Retail card GetRetailSaleInfo."
                };
            }
            return response;
        }

        public Shared.Common.Core.CoreApi.Contract.Message.Response.SetAtmPinResponse SetAtmPin(Shared.Common.Core.CoreApi.Contract.Message.Request.SetAtmPinRequest request)
        {
            var result = new Shared.Common.Core.CoreApi.Contract.Message.Response.SetAtmPinResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId
                }
            };
            GetTimeout("X-GD-Bos-GSSLegacyAccountUtility-SetAtmPin", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            try
            {
                var encryptRequest = new EncryptRequest
                {
                    RequestHeader = new Domain.Services.Crypto.RequestHeader
                    {
                        RequestId = request.RequestHeader.RequestId,
                        Options = request.RequestHeader.Options
                    },
                    Version = "EC_v1",
                    ProgramCode = request.ProgramCode,
                    Data = JsonConvert.SerializeObject(request.AtmPin),
                    Salt = request.RequestHeader.RequestId.ToString()
                };
                var encryptResponse = _cryptoService.Encrypt(encryptRequest);



                var setAtmPinRequest = new SetAtmPinRequest
                {
                    RequestId = request.RequestHeader.RequestId,
                    EncryptedPinData = new EncryptedDataRetail
                    {
                        Data = encryptResponse.EncryptedData.Data,
                        Version = encryptResponse.EncryptedData.Version,
                        EphemeralPublicKey = encryptResponse.EncryptedData.EphemeralPublicKey,
                        PublicKeyHash = encryptResponse.EncryptedData.PublicKeyHash
                    }
                };

                var output = JsonConvert.SerializeObject(setAtmPinRequest);
                _logger.Debug(
                    $"RetailCardService - setatmpin Call to GSS. Input:{output}, requestId:{request.RequestHeader.RequestId}");

                //var url = $"https://localhost:44316/programs/{request.ProgramCode}/retailcard/{request.AccountIdentifier}/setatmpin";

                var url = _gssAccountUtilityBaseUrl +
                          $"/programs/{request.ProgramCode}/retailcard/{request.AccountIdentifier}/setatmpin";

                var gssResponse = _serviceInvokeProvider.GetWebResponse<SetAtmPinRequest, SetAtmPinResponse>(url
                    , "POST", setAtmPinRequest, requestTimeout);

                _logger.Debug(
                    $"RetailCardService - setatmpin Response from GSS LegacyAccountUtility. Response:{JsonConvert.SerializeObject(gssResponse)}");

                if (gssResponse.StatusCode == 0)
                {

                    result.ResponseHeader.StatusCode = 0;
                    result.ResponseHeader.SubStatusCode = 0;
                    result.ResponseHeader.Message = "Success";
                }
                else
                {
                    switch (gssResponse.StatusCode)
                    {
                        case 103:
                            result.ResponseHeader.StatusCode = 400;
                            result.ResponseHeader.SubStatusCode = gssResponse.SubStatusCode;
                            result.ResponseHeader.Message = gssResponse.Message;
                            break;
                        case 200: // invalid input
                            result.ResponseHeader.StatusCode = 400;
                            result.ResponseHeader.SubStatusCode = gssResponse.SubStatusCode;
                            result.ResponseHeader.Message = gssResponse.Message;
                            break;
                        case 500:
                            result.ResponseHeader.StatusCode = 500;
                            result.ResponseHeader.Message =
                                $"Exception occurred in GSS Account Util Service SetAtmPin. ResponseMessage:{gssResponse.Message}";
                            _logger.Error("",
                                $"RetailCardService - Exception occurred in GSS Account Util Service. Response:{JsonConvert.SerializeObject(gssResponse)}, for ProgramCode:{request.ProgramCode}, requestId:{reqId}");
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex,
                    $"RetailCardService - SetAtmPin method failed for ProgramCode:{request.ProgramCode}, requestId:{reqId}");

                result.ResponseHeader.StatusCode = 500;
                result.ResponseHeader.Message = "Error occurred while trying to SetAtmPin.";
            }
            return result;
        }

        public GetLegacyTransactionResponse GetLegacyTransactions(GetLegacyTransactionRequest request)
        {
            Stopwatch totalTime = Stopwatch.StartNew();
            GetLegacyTransactionResponse legacyTransactionResponse = null;

            _logger.Debug($"RetailCardService - GetLegacyTransactions Call to GSS to pull temp card transactions from NEC. requestId:{request.RequestHeader.RequestId},accountIdentifier:{request.AccountIdentifier}");

            var account = _accountRepository.GetByAccountIdentifier(request.AccountIdentifier);

            if (account == null)
            {
                throw new ValidationException(10, 0, "Account Not Found.");
            }

            GetTimeout("X-GD-Bos-GSSLegacyAccountUtility-GetLegacyTransactions", out var requestTimeout);

            GetTransactionsRequest getTransactionsRequest = new GetTransactionsRequest()
            {
                RequestId = request.RequestHeader.RequestId,
                ProgramCode = request.ProgramCode,
                AccountIdentifier = Guid.Parse(request.AccountIdentifier),
                Count = request.Count,
                ByPassElasticSearch = request.ByPassElasticSearch,
                IncludeDeclined = request.IncludeDeclined,
                EndDate = request.EndDate.GetValueOrDefault()
            };

            // _gssAccountUtilityBaseUrl = "https://gssactutl.qa.nextestate.com/legacyaccountutility/V1";

            var url1 = _gssAccountUtilityBaseUrl + $"/programs/{request.ProgramCode}/retailcard/accounts/{getTransactionsRequest.AccountIdentifier}/transactions";

            try
            {
                var response = _serviceInvokeProvider.GetWebResponse<GetTransactionsRequest, GetTransactionsResponse>(url1
                    , "POST", getTransactionsRequest, requestTimeout);

                legacyTransactionResponse = PopulateTransactionResponse(response, request.AccountIdentifier, request.ProgramCode, request.RequestHeader.RequestId, string.Empty);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"RetailCardService - GetLegacyTransaction method failed for ProgramCode:{request.ProgramCode}, requestId:{request.RequestHeader.RequestId},AccountIdentifier:{request.AccountIdentifier},EndDate:{request.EndDate},ByPassElasticSearch:{request.ByPassElasticSearch},IncludeDeclined:{request.IncludeDeclined}");

                legacyTransactionResponse = new GetLegacyTransactionResponse()
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 500,
                        Message = "Error occurred while fetching Legacy Transaction."
                    }
                };
            }

            return legacyTransactionResponse;
        }

        public GetLegacyTransactionResponse GetLegacyTransactionsBySearchTerm(GetLegacyTransactionBySearchTermRequest request)
        {
            Stopwatch totalTime = Stopwatch.StartNew();
            GetLegacyTransactionResponse legacyTransactionResponse = null;

            _logger.Debug($"RetailCardService - GetLegacyTransactionsBySearchTerm Call to GSS to pull temp card transactions from NEC. requestId:{request.RequestHeader.RequestId},accountIdentifier:{request.AccountIdentifier}");

            GetTimeout("X-GD-Bos-GSSLegacyAccountUtility-GetLegacyTransactionsBySearchTerm", out var requestTimeout);


            if (string.Equals(request.Term, "Pending", StringComparison.OrdinalIgnoreCase))
            {
                request.Term = "Pending";
            }
            else if (string.Equals(request.Term, "posted", StringComparison.OrdinalIgnoreCase))
            {
                request.Term = "Posted";
            }
            else if (string.Equals(request.Term, "declined", StringComparison.OrdinalIgnoreCase))
            {
                request.Term = "Declined";
            }

            SearchTermTransactionsRequest getTransactionsRequest = new SearchTermTransactionsRequest()
            {
                RequestId = request.RequestHeader.RequestId,
                ProgramCode = request.ProgramCode,
                AccountIdentifier = Guid.Parse(request.AccountIdentifier),
                PageCount = request.PageCount,
                Term = request.Term,
                StartIndex = request.StartIndex
            };

            // _gssAccountUtilityBaseUrl = "https://gssactutl.qa.nextestate.com/legacyaccountutility/V1";

            var url1 = _gssAccountUtilityBaseUrl + $"/programs/{request.ProgramCode}/retailcard/accounts/{getTransactionsRequest.AccountIdentifier}/transactions/search";
            try
            {
                var response = _serviceInvokeProvider.GetWebResponse<SearchTermTransactionsRequest, GetTransactionsResponse>(url1
                    , "POST", getTransactionsRequest, requestTimeout);

                legacyTransactionResponse = PopulateTransactionResponse(response, request.AccountIdentifier, request.ProgramCode, request.RequestHeader.RequestId, request.Term);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"RetailCardService - GetLegacyTransactionBySearchTerm method failed for ProgramCode:{request.ProgramCode}, requestId:{request.RequestHeader.RequestId},AccountIdentifier:{request.AccountIdentifier},SearchTerm:{request.Term},PageCount:{request.PageCount},StartIndex:{request.StartIndex}");

                legacyTransactionResponse = new GetLegacyTransactionResponse()
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 500,
                        Message = "Error occurred while fetching Legacy Transaction by search Term."
                    }
                };
            }
            return legacyTransactionResponse;
        }

        private GetLegacyTransactionResponse PopulateTransactionResponse(GetTransactionsResponse response, string accountIdentifier, string programCode, Guid requestId, string searchTerm)
        {
            GetLegacyTransactionResponse legacyTransactionResponse = null;

            legacyTransactionResponse = new GetLegacyTransactionResponse();
            if (response?.StatusCode == 0)
            {
                var account = _accountRepository.GetByAccountIdentifier(accountIdentifier);

                if (account == null)
                {
                    throw new ValidationException(10, 0, "Account Not Found.");
                }


                if (response.Transactions.Count > 0)
                {
                    _logger.Debug(
                        $"RetailCardService - GetLegacyTransaction. Found {response.Transactions.Count} transactions. GSSResponseCode:{response.StatusCode}, requestId:{requestId},AccountIdentifier:{accountIdentifier},ProgramCode:{programCode},SearchTerm:{searchTerm}");


                    legacyTransactionResponse.Transactions = new List<ESTransaction>();
                    foreach (var legacyTransaction in response.Transactions)
                    {
                        ESTransaction gbosTransaction = new ESTransaction();

                        gbosTransaction.ProgramCode = programCode;
                        gbosTransaction.TransactionIdentifier = legacyTransaction.TransactionId;
                        gbosTransaction.AccountIdentifier = accountIdentifier;
                        gbosTransaction.TransactionType = legacyTransaction.GdcTransactionType ?? legacyTransaction.TransactionType;
                        gbosTransaction.ProductCode = account.Product.ProductCode.ToString();

                        if (int.TryParse(gbosTransaction.TransactionType?.Trim(), out _))
                        {
                            gbosTransaction.TransactionType = null;
                        }

                        switch (legacyTransaction.TransactionStatus)
                        {
                            case TransactionStatus.Pending:

                                #region Legacy NEC Pending Transaction Mappings

                                if (legacyTransaction.AuthorizationAmount.HasValue)
                                {
                                    gbosTransaction.TransactionAmount = Math.Abs(legacyTransaction.AuthorizationAmount.Value);

                                    if (legacyTransaction.AuthorizationAmount.Value < 0)
                                    {
                                        gbosTransaction.CreditDebit = false;
                                    }

                                    if (legacyTransaction.AuthorizationAmount.Value >= 0)
                                    {
                                        gbosTransaction.CreditDebit = true;
                                    }
                                }

                                gbosTransaction.AuthProcessorTransactionDate =
                                    legacyTransaction.AuthorizationDate.GetValueOrDefault(); // or AuthorizationDate ??

                                #endregion

                                break;
                            case TransactionStatus.Posted:

                                #region Legacy NEC Posted/Internal Transaction Mappings

                                gbosTransaction.ProcessorTransactionDate =
                                    legacyTransaction.PostedDate.GetValueOrDefault(); //confirm and fix format
                                if (legacyTransaction.CreditPosted.HasValue)
                                {
                                    gbosTransaction.TransactionAmount = legacyTransaction.CreditPosted.Value;
                                    gbosTransaction.CreditDebit = true;
                                }
                                else if (legacyTransaction.DebitPosted.HasValue)
                                {
                                    gbosTransaction.TransactionAmount = legacyTransaction.DebitPosted.Value;
                                    gbosTransaction.CreditDebit = false;
                                }

                                #endregion

                                break;
                        }

                        gbosTransaction.CurrencyCode = "USD";

                        gbosTransaction.CardAcceptorName = legacyTransaction.MerchantName;
                        gbosTransaction.CardAcceptorCity = legacyTransaction.MerchantCity;
                        gbosTransaction.CardAcceptorStateProvReg = legacyTransaction.MerchantState;
                        gbosTransaction.CardAcceptorPostal = legacyTransaction.MerchantZipCode;

                        if (legacyTransaction.RunningBalance.HasValue)
                        {
                            gbosTransaction.LedgerBalance = legacyTransaction.RunningBalance.Value;
                        }

                        // gbosTransaction.AvailableBalance = legacyTransaction.RunningBalance
                        //gbosTransaction.MessageHashId = legacyTransaction.
                        gbosTransaction.MerchantCategoryCode = legacyTransaction.MccCode;

                        gbosTransaction.MerchantId = legacyTransaction.MerchantId;

                        gbosTransaction.TransactionDescription = legacyTransaction.MerchantName;
                        gbosTransaction.TransClass = legacyTransaction.GdcTransactionClass;

                        if (!string.IsNullOrWhiteSpace(legacyTransaction.TransactionStatus.ToString()))
                        {
                            //First letter lower case for BUX to handle transaction status properly
                            var transactionStatusStr = legacyTransaction.TransactionStatus.ToString();
                            gbosTransaction.Status = char.ToLowerInvariant(transactionStatusStr[0]) +
                                                     transactionStatusStr.Substring(1);
                        }

                        gbosTransaction.MerchantCategory = legacyTransaction.MerchantCategory;

                        legacyTransactionResponse.Transactions.Add(gbosTransaction);
                    }

                    legacyTransactionResponse.ResponseHeader = new ResponseHeader()
                    {
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success",
                        ResponseId = requestId
                    };
                }
                else
                {
                    legacyTransactionResponse.ResponseHeader = new ResponseHeader()
                    {
                        StatusCode = 10,
                        SubStatusCode = 0,
                        Message = "No more Legacy Transactions found",
                        ResponseId = requestId
                    };
                }

                _logger.Debug(
                    $"RetailCardService - GetLegacyTransactionBySearchTerm method - fetched legacy transactions from GSS NEC. ResponseCode:{response.StatusCode}, NoMoreTransactionsAvailable:{response.NoMoreTransactionsAvailable},requestId:{requestId},AccountIdentifier:{accountIdentifier}");

            }
            else
            {
                legacyTransactionResponse = new GetLegacyTransactionResponse();
                legacyTransactionResponse.ResponseHeader = new ResponseHeader()
                {
                    StatusCode = 10,
                    SubStatusCode = 0,
                    Message = response?.Message,
                    ResponseId = requestId
                };
                _logger.Warn(
                    $"RetailCardService - GetLegacyTransactionBySearchTerm method - error returned from GSS NEC. ResponseCode:{response?.StatusCode},Message:{response?.Message}, NoMoreTransactionsAvailable:{response?.NoMoreTransactionsAvailable}, requestId:{requestId},AccountIdentifier:{accountIdentifier}");

            }

            return legacyTransactionResponse;
        }

        public UpgradeRetailTempToPersoResponse UpgradTempToPerso(UpgradeRetailTempToPersoRequest request)
        {
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);
            request.RequestId = reqId;
            request.ProgramCode = OptionsContext.Current.GetString("ProgramCode");

            _logger.Debug($"RetailCardService - UpgradTempToPerso Call to GSS. requestId:{request.RequestId}");

            GetTimeout("X-GD-Bos-GSSLegacyAccountUtility-UpgradeRetailTempToPerso", out var requestTimeout);

            var url1 = _gssAccountUtilityBaseUrl + $"/programs/{request.ProgramCode}/retailcard/accounts/{request.AccountIdentifier}/upgrade";

            var response = _serviceInvokeProvider.GetWebResponse<UpgradeRetailTempToPersoRequest, UpgradeRetailTempToPersoResponse>(url1
                , "POST", request, requestTimeout);

            return response;


        }

        public GetRetailCardBalanceTransferStatusResponse GetRetailCardBalanceTransferStatus(string accountIdentifier, string programCode)
        {
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);
            _logger.Debug($"RetailCardService - GetRetailCardBalanceTransferStatus Call to GSS. requestId:{reqId}");
            GetTimeout("X-GD-Bos-GSSLegacyAccountUtility-GetRetailCardBalanceTransferStatus", out var requestTimeout);

            var url1 = _gssAccountUtilityBaseUrl + $"/programs/{programCode}/retailcard/{accountIdentifier}/balanceTransferStatus";

            var response = _serviceInvokeProvider.GetWebResponse<GetRetailCardBalanceTransferStatusResponse>(url1, "GET", null, requestTimeout);

            return response;
        }

        public ReportLostStolenResponse ReportLostStolen(string accountIdentifier, string programCode,
            Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.LossType lossType, DateTime? dateLastUsed, bool? policeNotified, string notes)
        {
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);
            _logger.Debug($"RetailCardService - ReportLostStolen Call to GSS. requestId:{reqId}");
            GetTimeout("X-GD-Bos-GSSLegacyAccountUtility-GetRetailCardBalanceTransferStatus", out var requestTimeout);

            var url1 = _gssAccountUtilityBaseUrl + $"/programs/{programCode}/retailcard/accounts/{accountIdentifier}/LostStolen";
            var lossT = global::RequestHandler.Core.Domain.Services.RetailCard.Enum.LossType.Lost;
            switch (lossType)
            {
                case Shared.Common.Core.CoreApi.Contract.Data.Enum.LossType.Stolen:
                    lossT = global::RequestHandler.Core.Domain.Services.RetailCard.Enum.LossType.Stolen;
                    break;
                case Shared.Common.Core.CoreApi.Contract.Data.Enum.LossType.Compromised:
                    lossT = global::RequestHandler.Core.Domain.Services.RetailCard.Enum.LossType.Compromised;
                    break;
                case Shared.Common.Core.CoreApi.Contract.Data.Enum.LossType.UnauthorizedUse:
                    lossT = global::RequestHandler.Core.Domain.Services.RetailCard.Enum.LossType.UnauthorizedUse;
                    break;
                default:
                    lossT = global::RequestHandler.Core.Domain.Services.RetailCard.Enum.LossType.Lost;
                    break;
            }

            var request = new ReportLostStolenRequest
            {
                ProgramCode = programCode,
                DateLastUsed = dateLastUsed.HasValue ? dateLastUsed.ToString() : DateTime.MinValue.ToString(),
                PoliceNotified = policeNotified ?? false,
                LossType = lossT,
                Notes = notes,
                RequestId = reqId
            };

            var response = _serviceInvokeProvider.GetWebResponse<ReportLostStolenRequest, ReportLostStolenResponse>(url1, "POST", request, requestTimeout);

            if (response.StatusCode == 201 && response.Message.Contains("24 hours"))
                throw new ValidationException(4, 700, ReplacementEligibilityCode.After24Hours.GetDescription());
            if (response.StatusCode != 0)
                throw new Exception(response.Message);
            return response;
        }

        public void DeactivateLegacyTempCard(DeactivateRetailTempCardRequest request)
        {
            GetTimeout("X-GD-Bos-GSSLegacyAccountUtility-DeactivateLegacyTempCard", out var requestTimeout);

            var paymentInstrumentIdentifierInfo =
                _paymentIdentifierRepository.GetPaymentIdentifierByPaymentInstrumentIdentifier(
                    PaymentInstrumentIdentifier.FromString(request.PaymentInstrumentIdentifier.ToString()),
                    out _);

            var privatePaymentInstrumentData = new PrivatePaymentInstrumentData
            {
                Pan = _tokenizerService.DeTokenizePan(paymentInstrumentIdentifierInfo.TokenizedPAN)
            };


            var encryptRequest = new EncryptRequest
            {
                RequestHeader = new Domain.Services.Crypto.RequestHeader
                {
                    RequestId = request.RequestId,
                    Options = request.RequestHeader.Options
                },
                Version = "EC_v1",
                ProgramCode = request.ProgramCode,
                Data = JsonConvert.SerializeObject(privatePaymentInstrumentData),
                Salt = request.RequestHeader.RequestId.ToString()
            };
            var encryptResponse = _cryptoService.Encrypt(encryptRequest);

            request.EncryptedCardData = new EncryptedDataRetail
            {
                Data = encryptResponse.EncryptedData.Data,
                Version = encryptResponse.EncryptedData.Version,
                EphemeralPublicKey = encryptResponse.EncryptedData.EphemeralPublicKey,
                PublicKeyHash = encryptResponse.EncryptedData.PublicKeyHash
            };

            var output = JsonConvert.SerializeObject(request);
            _logger.Debug(
                $"RetailCardService - DeactivateLegacyTempCard Call to GSS. Input:{output},requestId:{request.RequestHeader.RequestId}");

            //var url1 = "https://localhost:44316/programs/gbr/retailcard/deactivatetempcard";

            var url1 = _gssAccountUtilityBaseUrl +
                       $"/programs/{request.ProgramCode}/retailcard/accounts/{request.DestinationAccountIdentifier}/deactivatetempcard";

            var responseCardResponse = _serviceInvokeProvider
                .GetWebResponse<DeactivateRetailTempCardRequest, DeactivateRetailTempCardResponse>(url1
                    , "POST", request, requestTimeout);

            _logger.Info($"RetailCardService - DeactivateLegacyTempCard Response from GSS LegacyAccountUtility.  StatusCode:{responseCardResponse?.StatusCode}" +
                         $"SubStatusCode:{responseCardResponse?.SubStatusCode},Message:{responseCardResponse?.Message},RequestId:{request.RequestHeader.RequestId}, AccountIdentifier{request.DestinationAccountIdentifier},ResponseId:{responseCardResponse?.ResponseId}");
        }

        public GetPinKeyByExternIdResponse GetPinKeyByExternId(GetPinKeyByExternIdRequest request)
        {
            GetTimeout("X-GD-Bos-GSSLegacyAccountUtility-GetPinKeyByExternId", out var requestTimeout);

            var url = _gssAccountUtilityBaseUrl + $"/legacypinservice/getPinKeyByExternId";
            var response = _serviceInvokeProvider.GetWebResponse<GetPinKeyByExternIdRequest, GetPinKeyByExternIdResponse>(url, "POST", request, requestTimeout);

            _logger.Info($"RetailCardService - GetPinKeyByExternId Response from GSS LegacyAccountUtility.  StatusCode:{response?.StatusCode}, SubStatusCode:{response?.SubStatusCode}, Message:{response?.Message}, RequestId:{request.RequestId}, ExternalId: {request.ExternId}, ResponseId:{response?.ResponseId}");

            return response;
        }

        public ConsumePinResponse ConsumerPin(ConsumePinRequest request)
        {
            GetTimeout("X-GD-Bos-GSSLegacyAccountUtility-ConsumerPinRequest", out var requestTimeout);

            var url = _gssAccountUtilityBaseUrl + $"/legacypinservice/consumerpin";
                                                    
            var response = _serviceInvokeProvider.GetWebResponse<ConsumePinRequest, ConsumePinResponse>(url, "POST", request, requestTimeout);

            _logger.Info($"RetailCardService - ConsumerPinRequest Response from GSS LegacyAccountUtility.  StatusCode:{response?.StatusCode}, SubStatusCode:{response?.SubStatusCode}, Message:{response?.Message}, RequestId:{request.RequestId}, PinKey: {request.PinKey}, ResponseId:{response?.ResponseId}");

            return response;
        }

        public SyncRegisterCardResponse SyncRegisterCard(SyncRegisterCardRequest request)
        {
            GetTimeout("X-GD-Bos-GSSLegacyAccountUtility-SyncRegisterCard", out var requestTimeout);

            var url = _gssAccountUtilityBaseUrl + $"/programs/{request.ProgramCode}/retailcard/accounts/{request.AccountIdentifier}/syncregistercard";
            var response = _serviceInvokeProvider.GetWebResponse<SyncRegisterCardRequest, SyncRegisterCardResponse>(url, "POST", request, requestTimeout);

            _logger.Info($"RetailCardService - SyncRegisterCard Response from GSS LegacyAccountUtility.  StatusCode:{response?.StatusCode}, SubStatusCode:{response?.SubStatusCode}, Message:{response?.Message}, RequestId:{request.RequestId}, AccountIdentifier: {request.AccountIdentifier}, ResponseId:{response?.ResponseId}");

            return response;
        }

        public GetBalanceResponse UpdateBalance(GetBalanceRequest request)
        {
            GetTimeout("X-GD-Bos-GSSLegacyAccountUtility-UpdateBalance", out var requestTimeout);

            var url = _gssAccountUtilityBaseUrl + $"/programs/{request.ProgramCode}/retailcard/updateBalance";
            var response = _serviceInvokeProvider.GetWebResponse<GetBalanceRequest, GetBalanceResponse>(url, "POST", request, requestTimeout);

            _logger.Info($"RetailCardService - UpdateBalance Response from GSS LegacyAccountUtility.  StatusCode:{response?.StatusCode}, SubStatusCode:{response?.SubStatusCode}, Message:{response?.Message}, RequestId:{request.RequestId}, AccountIdentifier: {request.AccountIdentifier}, ResponseId:{response?.ResponseId}");

            return response;
        }

        private void GetTimeout(string headerName, out int? requestTimeout)
        {
            requestTimeout = null;
            if (OptionsContext.Current.IsDefined(headerName))
            {
                requestTimeout = 1;
                if (int.TryParse(OptionsContext.Current.GetString(headerName), out var rt))
                    requestTimeout = rt;
            }
        }

        private static readonly ILogger _logger = LogManager.GetCurrentClassLogger();

        //trigger build 5/10
    }
}
