﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Newtonsoft.Json;
using NLog;
using RequestHandler.Core.Application;
using RequestHandler.Core.Domain.Services.Twilio;
using Twilio;
using Twilio.Rest.Lookups.V1;
using PhoneNumber = Gd.Bos.RequestHandler.Core.Domain.Model.User.PhoneNumber;
using PhoneType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.PhoneType;
using Task = System.Threading.Tasks.Task;

namespace RequestHandler.Core.Infrastructure
{
    public class TwilioService : ITwilioService
    {
        private IGatewayService _gatewayService;
        private IRequestHandlerSettings _configuration;
        private IBaasConfiguration _bassConfiguration;
        public TwilioService(IGatewayService gatewayService, IRequestHandlerSettings configuration, IBaasConfiguration baasConfiguration)
        {
            _gatewayService=gatewayService;
            _configuration = configuration;
            _bassConfiguration = baasConfiguration;
        }

        private static readonly ILogger Logger = LogManager.GetCurrentClassLogger();

        public async Task<GetPhoneInformationResponse> GetPhoneInformation(string programCode, List<PhoneNumber> phones)
        {
            GetPhoneInformationResponse response = new GetPhoneInformationResponse()
            {
                Carrier = new Carrier() { Type = PhoneType.Mobile.ToString() }
            };
            try
            {
                if (OptionsContext.Current.ContainsKey("X-Gd-Bos-Twilio-TimeOut"))
                {
                    await Task.Delay(TimeSpan.FromSeconds(_bassConfiguration.GetTwilioExpireSeconds(programCode)));
                }

                var verifyNumber = SelectPhoneNumber(phones)?.Number;
                if (verifyNumber == null || IsPhoneNumberExcluded(verifyNumber))
                {
                    return response;
                }

                var requestId = OptionsContext.Current.GetGuid("requestId", Guid.NewGuid());
                var appCredential = _gatewayService.GetAppCredentials(requestId, programCode);
                TwilioClient.Init(appCredential.apiKey, appCredential.secret);
                var type = new List<string> { "carrier" };

                var phoneNumber = await PhoneNumberResource.FetchAsync(
                    type: type,
                    pathPhoneNumber: new Twilio.Types.PhoneNumber(verifyNumber));

                if (phoneNumber != null)
                {
                    Logger.Info($"Twilio response:{phoneNumber.Carrier}");
                    var carrier = JsonConvert.DeserializeObject<Carrier>(phoneNumber.Carrier.ToString());
                    response.Carrier.Type = carrier.Type ?? String.Empty;
                }
            }
            catch (Twilio.Exceptions.ApiException tex)
            {
                Logger.Error($"{nameof(TwilioService)} twilio function execute failed, expecation:{tex}");
                /***Twilio clear return unknown phone, decline this phone number
                 * Other exceptions by pass it to unblock sale card *
                 */
                switch (tex.Status)
                {
                    //case 400:
                    //    response.ErrorCodes.Add(ErrorCode.ContactVerification_TwilioBadRequest);
                    //    response.ResponseCode = ResponseCode.Conflict;
                    //    break;
                    case 404:
                        response.Carrier.Type = "NotFound";
                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                Logger.Error(
                    $"{nameof(TwilioService)} failed verify type of phone number, skip phone validate, expecation:{ex}");
            }

            return response;
        }

        private static PhoneNumber SelectPhoneNumber(List<PhoneNumber> phoneNumbers)
        {
            var phoneMobile = phoneNumbers?.FirstOrDefault(item => item.Type == PhoneType.Mobile);
            var phoneUnspecified = phoneNumbers?.FirstOrDefault(item => item.Type == PhoneType.Unspecified);
            return phoneMobile ?? phoneUnspecified;
        }

        private bool IsPhoneNumberExcluded(string phoneNumber)
        {
            if (OptionsContext.Current.ContainsKey("X-Gd-Bos-IgnorePhoneValidate"))
            {
                return true;
            }

            if (!string.IsNullOrWhiteSpace(phoneNumber) && phoneNumber.Length == 10)
            {
                var phoneAreaCode = phoneNumber.Substring(0, 3);
                if (_configuration.ExcludedAreaCodes.Contains(phoneAreaCode))
                {
                    return true;
                }
            }

            return false;
        }
    }
}
