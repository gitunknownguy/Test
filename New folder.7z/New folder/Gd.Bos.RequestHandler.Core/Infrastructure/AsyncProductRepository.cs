﻿using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.Shared.Common.Caching;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.Shared.Common.UtilityCoreApi.Contract.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using Microsoft.Data.SqlClient;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Utils;
using Microsoft.IdentityModel.Tokens;
using RequestHandler.Core.Utils;
using Microsoft.Extensions.Caching.Memory;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    [ExcludeFromCodeCoverage(Justification = "Not tested previously and currently can't be easily mocked and will be taken care of on GBOS-116633")]
    public class AsyncProductRepository : IAsyncProductRepository
    {
        private readonly IDataAccess _dataAccess;
        private readonly ILazyCache _lazyCache;

        public AsyncProductRepository(IDataAccess dataAccess, ILazyCache lazyCache)
        {
            _dataAccess = dataAccess;
            _lazyCache = lazyCache;
        }

        public List<ProductInfoModel> GetAllCachedProducts()
        {
            throw new NotImplementedException();
        }

        public List<ProductTierData> GetAllCachedProductTiers()
        {
            throw new NotImplementedException();
        }

        public async Task<Product> GetByProductCode(ProductCode productCode)
        {
            var products = await _lazyCache.GetAsync(
                    "PRODUCT_CODES", 
                    new TimeSpan(0, 2, 0, 0),
                    () => GetAllProducts()
                );

            var product = products.Find(p => ProductCode.FromString(p.Item3).Equals(productCode));
            if (product == null)
                throw new Exception("No Product exists for specified ProductCode.");

            return new Product(productCode, ProgramCode.FromString(product.Item4), product.Item1, product.Item2, product.Item5, product.Item6,
                product.Rest.Item2, product.Rest.Item3);
        }

        public Product GetByProductCode(ProductCode productCode, ProgramCode programCode)
        {
            throw new NotImplementedException();
        }

        public string GetNameByProductCode(ProductCode productCode, ProgramCode programCode)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<string> GetProductBinsByProgramCode(ProgramCode programCode)
        {
            throw new NotImplementedException();
        }

        public Product GetProductByBin(int binProductKey)
        {
            throw new NotImplementedException();
        }

        public Product GetProductByKey(int productKey)
        {
            throw new NotImplementedException();
        }

        public ProductTierData GetProductTierByProductCodeMaterialType(string productCode, bool requestPhysicalCard, string productMaterialType)
        {
            throw new NotImplementedException();
        }

        public ProductTypeInfo GetProductTypeByProductKey(int productKey)
        {
            throw new NotImplementedException();
        }

        public (bool result, ProductTierData npnrProduct, ProductTierData emvProduct) IsGbosRetailProductTier(int productTierKey)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns>productKey, produdctName, productCode, programCode, achPrefix, abaRoutingNumber, binProductKey, bin,bankName</returns>
        private async Task<List<Tuple<int, string, string, string, string, string, int, Tuple<string, string, int>>>> GetAllProducts(bool lowerCaseName = true)
        {
            var returnValue = new List<Tuple<int, string, string, string, string, string, int, Tuple<string, string, int>>>();

            using var connection = _dataAccess.CreateConnection();
            using (var reader = await _dataAccess.ExecuteReaderAsync("GetAllProduct", CommandType.StoredProcedure, connection, default, null))
            {
                while (await reader.ReadAsync())
                {
                    var productKey = reader.GetInt32(0);
                    var productName = lowerCaseName ? reader.GetString(1).ToLower() : reader.GetString(1);
                    var productCode = reader.GetString(2);
                    var programCode = reader.GetString(3);
                    var achPrefix = reader.IsDBNull(4) ? null : reader.GetString(4);
                    var bin = reader.IsDBNull(5) ? null : reader.GetString(5);
                    var bankName = reader.IsDBNull(6) ? string.Empty : reader.GetString(6);
                    var abaRoutingNumber = reader.IsDBNull(7) ? null : reader.GetString(7);
                    int binProductKey = reader["BINProductKey"] == DBNull.Value ? 0 : Convert.ToInt32(reader["BINProductKey"]);
                    int binProcessorKey = reader["ProcessorKey"] == DBNull.Value ? 1 : Convert.ToInt32(reader["ProcessorKey"]);

                    returnValue.Add(new Tuple<int, string, string, string, string, string, int, Tuple<string, string, int>>(productKey, productName,
                        productCode,
                        programCode,
                        achPrefix,
                        abaRoutingNumber,
                        binProductKey,
                        new Tuple<string, string, int>(bin, bankName, binProcessorKey)));
                }
            }

            return returnValue;
        }
    }
}
