﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Cassandra;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Caching;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.IdentityModel.Tokens;
using Org.BouncyCastle.Asn1.Cms;
using RequestHandler.Core.Utils;
using Configuration = Gd.Bos.RequestHandler.Core.Infrastructure.Configuration.Configuration;


namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    partial class AsyncAccountRepository
    {
        public void DeCache(List<string> cacheKeys)
        {
            cacheKeys.ForEach(key => _lazyCache.ValueAsync.RemoveAsync(key));
        }

        public async Task<List<AccountLink>> GetLinkedAccountsCached(AccountIdentifier accountIdentifier)
        {
            var cacheKey = "getLinkedAccounts_" + accountIdentifier;
            var cacheTtl = new TimeSpan(0, 0, Configuration.Configuration.Current.RepositoryCacheTtlMs / 1000, 0);
            var result = new List<AccountLink>();

            var cacheConfig = OptionsContext.Current.GetString("X-GD-Cache-Control");
            var programCode = OptionsContext.Current.GetString("programCode");

            if (_baasConfiguration.IsRepositoryCacheAllowed(programCode))
            {
                if (string.IsNullOrEmpty(cacheConfig) || !cacheConfig.Equals("no-cache", StringComparison.InvariantCultureIgnoreCase))
                {
                    return await _lazyCache.GetAsync(cacheKey, cacheTtl,
                        () => GetLinkedAccountsMiddleware(accountIdentifier));
                }
            }

            result = await GetLinkedAccounts(accountIdentifier);

            if (_baasConfiguration.IsRepositoryCacheAllowed(programCode))
            {
                Logger.Info("Starting caching on no-cache headers");
                await _lazyCache.ValueAsync.SetAsync(cacheKey, result, cacheTtl);
                Logger.Info("Finished caching on no-cache headers");
            }

            return result;
        }

        private async Task<List<AccountLink>> GetLinkedAccountsMiddleware(AccountIdentifier accountIdentifier)
        {
            Logger.Info("Cache missed now calling db");
            return await GetLinkedAccounts(accountIdentifier);
        }
    }
}
