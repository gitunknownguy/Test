﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    partial class AsyncAccountRepository
    {
        private static T Cast<T>(object value)
        {
            if (value == DBNull.Value || value == null)
                return default(T);

            return (T)value;
        }
    }
}
