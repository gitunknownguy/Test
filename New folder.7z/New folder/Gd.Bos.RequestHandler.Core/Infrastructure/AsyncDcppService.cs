﻿using System;
using System.Collections.Generic;
using System.Linq;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.Logic;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.Dcpp.Contract.Enum;
using Gd.Bos.Dcpp.Contract.Message;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Services.Dcpp;
using AddPurseToAccountResponse = Gd.Bos.Dcpp.Contract.Message.AddPurseToAccountResponse;
using Address = Gd.Bos.RequestHandler.Core.Domain.Model.User.Address;
using CardExpirationDate = Gd.Bos.RequestHandler.Core.Domain.Services.Dcpp.CardExpirationDate;
using DeliveryMethod = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.DeliveryMethod;
using ExpirationDate = Gd.Bos.Dcpp.Contract.Data.ExpirationDate;
using LossType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.LossType;
using PaymentInstrument = Gd.Bos.RequestHandler.Core.Domain.Model.Payment.PaymentInstrument;
using PhoneNumber = Gd.Bos.RequestHandler.Core.Domain.Model.User.PhoneNumber;
using PhoneType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.PhoneType;
using TokenAction = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TokenAction;
using PurseStatus = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.PurseStatus;
using System.Configuration;
using ReplacementReason = Gd.Bos.Dcpp.Contract.Enum.ReplacementReason;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Contract.Exceptions;
using ActivateCardRequest = Gd.Bos.Dcpp.Contract.Message.ActivateCardRequest;
using AddPurseToAccountRequest = Gd.Bos.Dcpp.Contract.Message.AddPurseToAccountRequest;
using AdjustAccountBalanceRequest = Gd.Bos.Dcpp.Contract.Message.AdjustAccountBalanceRequest;
using AdjustAccountBalanceResponse = Gd.Bos.Dcpp.Contract.Message.AdjustAccountBalanceResponse;
using ChangeAccountStatusRequest = Gd.Bos.Dcpp.Contract.Message.ChangeAccountStatusRequest;
using ChangeAccountStatusResponse = Gd.Bos.Dcpp.Contract.Message.ChangeAccountStatusResponse;
using CreateAccountRequest = Gd.Bos.Dcpp.Contract.Message.CreateAccountRequest;
using CurrencyAmount = Gd.Bos.Shared.Common.Core.Contract.CurrencyAmount;
using GetCardDetailsRequest = Gd.Bos.Dcpp.Contract.Message.GetCardDetailsRequest;
using GetCardDetailsResponse = Gd.Bos.Dcpp.Contract.Message.GetCardDetailsResponse;
using OrderCardRequest = Gd.Bos.Dcpp.Contract.Message.OrderCardRequest;
using OrderCardResponse = Gd.Bos.Dcpp.Contract.Message.OrderCardResponse;
using OverrideProductResponse = Gd.Bos.Dcpp.Contract.Message.OverrideProductResponse;
using RequestHeader = Gd.Bos.Dcpp.Contract.Message.RequestHeader;
using SetPinRequest = Gd.Bos.Dcpp.Contract.Message.SetPinRequest;
using VerifyPinRequest = Gd.Bos.Dcpp.Contract.Message.VerifyPinRequest;
using UpdateAccountRequest = Gd.Bos.Dcpp.Contract.Message.UpdateAccountRequest;
using UpdateAccountResponse = Gd.Bos.Dcpp.Contract.Message.UpdateAccountResponse;
using UpdateProductRequest = Gd.Bos.Dcpp.Contract.Message.UpdateProductRequest;
using UpdateProductResponse = Gd.Bos.Dcpp.Contract.Message.UpdateProductResponse;
using ValidateCVVRequest = Gd.Bos.Dcpp.Contract.Message.ValidateCVVRequest;
using ValidateCVVResponse = Gd.Bos.Dcpp.Contract.Message.ValidateCVVResponse;
using Gd.Bos.RequestHandler.Core.Domain.Model.Business;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request;
using Gd.Bos.Shared.Common.CBSProcessorManager.Contract.Message.Request;
using Gd.Bos.Shared.Common.CBSProcessorManager.Contract.Message.Response;
using AdjustPurseBalanceRequest = Gd.Bos.Dcpp.Contract.Message.AdjustPurseBalanceRequest;
using AdjustPurseBalanceResponse = Gd.Bos.Dcpp.Contract.Message.AdjustPurseBalanceResponse;
using ChangeCardStatusRequest = Gd.Bos.Dcpp.Contract.Message.ChangeCardStatusRequest;
using ChangeCardStatusResponse = Gd.Bos.Dcpp.Contract.Message.ChangeCardStatusResponse;
using ChangePurseStatusRequest = Gd.Bos.Dcpp.Contract.Message.ChangePurseStatusRequest;
using ChangePurseStatusResponse = Gd.Bos.Dcpp.Contract.Message.ChangePurseStatusResponse;
using GetAccountBalanceResponse = Gd.Bos.Dcpp.Contract.Message.GetAccountBalanceResponse;
using GetAccountBalanceRequest = Gd.Bos.Dcpp.Contract.Message.GetAccountBalanceRequest;
using OverrideProductRequest = Gd.Bos.Shared.Common.Dcpp.Contract.Message.OverrideProductRequest;
using ProductFeatureGroupOverride = Gd.Bos.Shared.Common.Dcpp.Contract.Data.ProductFeatureGroupOverride;
using ReportLostStolenV2Request = Gd.Bos.Dcpp.Contract.Message.ReportLostStolenV2Request;
using ReportLostStolenV2Response = Gd.Bos.Dcpp.Contract.Message.ReportLostStolenV2Response;
using UpdateCreditLimitHistoryRequest = Gd.Bos.Dcpp.Contract.Message.UpdateCreditLimitHistoryRequest;
using UpdateCreditLimitHistoryResponse = Gd.Bos.Dcpp.Contract.Message.UpdateCreditLimitHistoryResponse;
using ValidateCvvByPanRequest = RequestHandler.Core.Domain.Services.Dcpp.ValidateCvvByPanRequest;
using ValidateCvvByPanResponse = RequestHandler.Core.Domain.Services.Dcpp.ValidateCvvByPanResponse;
using AddAccountHolderRequest = Gd.Bos.Dcpp.Contract.Message.AddAccountHolderRequest;
using AddAccountHolderResponse = Gd.Bos.Dcpp.Contract.Message.AddAccountHolderResponse;
using AccountStatusReason = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountStatusReason;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Diagnostics.CodeAnalysis;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    [ExcludeFromCodeCoverage(Justification = "Not tested previously and currently can't be easily mocked and will be taken care of on GBOS-116633")]
    public class AsyncDcppService : IAsyncDcppService
    {
        private readonly IRequestHandlerSettings _settings;
        private readonly IServiceInvokeProvider _serviceInvokeProvider;
        private const string _source = "RequestHandler";
        private readonly string _dcppBaseUrl;
        private const string _createAccountUrl = "/Account/Create";
        private const string _addAccountHolderUrl = "/Account/AddAccountHolder";
        private const string _orderCardUrl = "/Account/OrderCard";
        private const string _adjustAccountBalanceUrl = "/Account/Balance/Adjust";
        private const string _adjustPurseBalanceUrl = "/Account/Purse/Balance/Adjust";
        private const string _changeAccountStatus = "/Account/Status/Change";
        private const string _changePurseStatus = "/Purse/Status/Change";
        private const string _changeCardStatus = "/Card/Status/Change";

        private const string _addSegment = "/Segment/AddSegment";
        private const string _deleteSegment = "/Segment/DeleteSegment";

        private const string _getCardDetailsUrl = "/Card";
        private const string _validateCvvByPanUrl = "/Card/ValidateCVVByPan";
        private const string _setPinUrl = "/Card/SetPin";
        private const string _verifyPinUrl = "/Card/VerifyPin";
        private const string _activateCardUrl = "/Card/ActivateCard";
        private const string _validateCardUrl = "/Card/ValidateCVV";
        //private const string _reportLostStolenUrl = "/Card/ReportLostStolen"; //please use _reportLostStolenUrlV2
        private const string _reportLostStolenUrlV2 = "/Card/ReportLostStolenV2";
        private const string _updateAddress = "/Account/Update ";
        private const string _addPurse = "/Account/AddPurse";
        private const string _updateProduct = "/Account/UpdateProduct";
        private const string _activateOrSuspendToken = "/Account/ActivateSuspendToken";
        private const string _setCycle = "/Account/SetCycle";
        private const string _activateSamplesCard = "/Card/ActivateSampleCard";
        private const string _getAccountBalance = "/Account/Balance";
        private const string _updateCreditLimitHistory = "/Account/UpdateCreditLimitHistory";

        public AsyncDcppService(IServiceInvokeProvider serviceInvokeProvider, IRequestHandlerSettings settings)
        {
            _serviceInvokeProvider = serviceInvokeProvider;
            _dcppBaseUrl = Configuration.Configuration.Current.DcppBaseUrl;
            _settings = settings;
        }

        public void ActivateCard(AccountIdentifier accountIdentifier, string paymentInstrumentIdentifier, string source = null)
        {
            throw new NotImplementedException();
        }

        public ActivateOrSuspendTokenResponse ActivateOrSuspendToken(AccountIdentifier accountIdentifier, string tokenId, TokenAction action, string comment)
        {
            throw new NotImplementedException();
        }

        public ActivateSampleCardResponse ActivateSamplesCard(AccountIdentifier accountIdentifier, string cardProxy, bool? isEmv, string cardStockCode, string embossedName, string accountNumber, string productCode)
        {
            throw new NotImplementedException();
        }

        public Domain.Services.Dcpp.CreateAccountResponse AddAccountHolder(string accountIdentifier, string userIdentifier, string accountHolderIdentifier, string productMaterialType, UserName cardholderName, string embossName, DateTime dateOfBirth, string productCode, bool isVirtualTierAllowed, IEnumerable<Address> addresses, IEnumerable<PhoneNumber> phoneNumbers)
        {
            throw new NotImplementedException();
        }

        public AddPurseResponse AddPurseToAccount(string programCode, AccountIdentifier accountIdentifier, Shared.Common.Core.CoreApi.Contract.Data.Enum.PurseType purseType, string userDescription = null, decimal? goalAmount = null, string goalDate = null, string iconName = null, string purseSubType = null)
        {
            throw new NotImplementedException();
        }

        public AddSegmentResponse AddSegment(string paymentIdentifier, string segmentName, DateTime startDate, DateTime endDate, string accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public AdjustBalanceResponse AdjustBalance(AccountIdentifier accountIdentifier, decimal amount, bool allowNegativeBalance, string currencyCode, string transClass, string transactionReferenceId, string description, string comment, string commentPostfix = ",FT", int? requestTimeout = null, string originalTransactionId = null)
        {
            throw new NotImplementedException();
        }

        public AdjustAccountBalanceResponse AdjustBalanceForAccountTransaction(AccountIdentifier accountIdentifier, decimal amount, bool allowNegativeBalance, string currencyCode, string transClass, string transactionReferenceId, string description, string comment, string commentPostfix = ",FT", int? requestTimeout = null)
        {
            throw new NotImplementedException();
        }

        public AdjustBalanceResponse AdjustPurseBalance(AccountIdentifier accountIdentifier, AccountBalanceIdentifier accountBalanceIdentifier, decimal amount, bool allowNegativeBalance, string currencyCode, string transClass, string transactionReferenceId, string description, string comment, string commentPostfix = ",FT")
        {
            throw new NotImplementedException();
        }

        public ChangeAccountStatusResponse ChangeAccountStatus(string accountId, string accountStatus, string gdAccountStatus = null, List<AccountStatusReason> accountStatusReasonsToAdd = null, List<AccountStatusReason> accountStatusReasonsToRemove = null, Guid? userIdentifier = null)
        {
            throw new NotImplementedException();
        }

        public ChangeCardStatusResponse ChangeCardStatus(string accountId, string cardStatus, Guid? paymentIdentifier = null, string lifeTimeEventType = null)
        {
            throw new NotImplementedException();
        }

        public ChangePurseStatusResponse ChangePurseStatus(string accountIdentifier, string purseIdentifier, string accountStatus)
        {
            throw new NotImplementedException();
        }

        public Domain.Services.Dcpp.CreateAccountResponse CreateAccount(AccountIdentifier accountIdentifier, UserIdentifier userIdentifier, IEnumerable<string> userIdentifiers, UserName name, IEnumerable<Address> addresses, IEnumerable<PhoneNumber> phoneNumbers, string programCode, string productCode, PhysicalCardType physicalCardType, bool personalized, string productMaterialType, int productTierKey, bool isVirtualTierAllowed, string embossName, string businessName, string accountNumber, int expirationMonths, int expirationRandomMonths, BusinessAddress businessAddress = null, string productType = null, int billCycleDay = 1, string routingNumber = null, bool needEmbossing = true, string storeId = null, string businessEmbossName = null)
        {
            throw new NotImplementedException();
        }

        public DeleteSegmentResponse DeleteSegment(string paymentIdentifier, string segmentName, string accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public async Task<GetAccountBalanceResponse> GetAccountBalance(string programCode, string accountIdentifier)
        {
            GetTimeout("X-GD-Bos-Dcpp-GetAccountBalance", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            var request = new GetAccountBalanceRequest()
            {
                Header = new RequestHeader() { RequestId = reqId, Source = _source },
                AccountId = accountIdentifier.ToString(),
                ProgramCode = programCode
            };

            var jsonRequest = JsonConvert.SerializeObject(request);

            var response = await _serviceInvokeProvider.GetWebResponseAsync<GetAccountBalanceResponse>(
                _dcppBaseUrl + _getAccountBalance,
                "POST", jsonRequest, requestTimeout);
            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for {_getAccountBalance}.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for {_setCycle}: Message: {response.Header.ErrorInfo.Message};");

            return response;
        }

        public CardDetails GetCardDetails(AccountIdentifier accountIdentifier, CardExpirationDate expirationDate, Guid? paymentIdentifier = null, Guid? paymentInstrumentIdentifier = null)
        {
            throw new NotImplementedException();
        }

        public decimal GetYearToDateAccountFees(Guid requestId, string programCode, string accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public bool IsRoutingToCPM(AccountIdentifier accountIdentifier)
        {
            // It is not implemented in the non ASYNC class either
            throw new NotImplementedException();
        }

        public LinkCardResponse LinkCard(LinkCardRequest linkCardRequest)
        {
            throw new NotImplementedException();
        }

        public OrderCardResponse OrderPhysicalCard(AccountIdentifier accountIdentifier, PaymentIdentifierIdentifier paymentIdentifier, PaymentInstrumentIdentifier paymentInstrumentIdentifier, string programCode, string productMaterialType = null, string customCardImageIdentifier = null, ReplacementReason replacementReason = ReplacementReason.NewCard, bool override10DayLimit = false, DeliveryMethod deliveryMethod = DeliveryMethod.Regular, string retryId = null, string source = null, bool? waiveFee = null, bool? waiveOvernightFee = null, bool needEmbossing = true, string storeId = null)
        {
            throw new NotImplementedException();
        }

        public OverrideProductResponse OverrideProduct(string accountIdentifier, string programCode, bool isRevert, List<ProductFeatureGroupOverride> productFeatureGroups)
        {
            throw new NotImplementedException();
        }

        public ReportLostStolenV2Response ReportLostStolen(AccountIdentifier accountIdentifier, PaymentInstrumentIdentifier paymentInstrumentIdentifier, LossType lossType, DeliveryMethod deliveryMethod, DateTime? dateLastUsed, DateTime? dateDiscoveredMissing, bool? policeNotified, string notes, string productMaterialType, bool createVirtualCard, string customCardImageIdentifier = null, bool isProductEligibleForDigitalWallet = false, string source = null, bool? waiveFee = null, bool? waiveOvernightFee = null, int PhysicalProductTierKey = 0, bool needEmbossing = true, bool override10DayLimit = false, string storeId = null)
        {
            throw new NotImplementedException();
        }

        public ReportLostStolenV2Response ReportLostStolenRetry(AccountIdentifier accountIdentifier, PaymentInstrumentIdentifier paymentInstrumentIdentifier, Guid requestId, LossType lossType, DeliveryMethod deliveryMethod, DateTime? dateLastUsed, DateTime? dateDiscoveredMissing, bool? policeNotified, string notes, string productMaterialType, string programCode, string customCardImageIdentifier = null, bool isProductEligibleForDigitalWallet = false, string source = null, bool? waiveFee = null, bool? waiveOvernightFee = null, bool createVirtualCard = false, int PhysicalProductTierKey = 0, bool needEmbossing = true, bool override10DayLimit = false, string storeId = null)
        {
            throw new NotImplementedException();
        }

        public SetCycleResponse SetCycle(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public void SetPin(AccountIdentifier accountIdentifier, string paymentInstrumentIdentifier, string pin)
        {
            throw new NotImplementedException();
        }

        public UpdateAccountResponse UpdateAccount(UpdateAccountRequest request, string middleName = null)
        {
            throw new NotImplementedException();
        }

        public UpdateCreditLimitHistoryResponse UpdateCreditLimitHistory(UpdateCreditLimitHistoryRequest request)
        {
            throw new NotImplementedException();
        }

        public UpdateProductResponse UpdateProduct(string accountIdentifier, string programCode, int productTierKey, string productMaterialType, string cardStock = null)
        {
            throw new NotImplementedException();
        }

        public ValidateCVVResponse ValidateCvv(string pan, string cvv, string accountIdentifier, CardExpirationDate cardExpirationDate, bool usePan)
        {
            throw new NotImplementedException();
        }

        public ValidateCvvByPanResponse ValidateCvvByPan(ValidateCvvByPanRequest request)
        {
            throw new NotImplementedException();
        }

        public bool VerifyPin(AccountIdentifier accountIdentifier, string paymentInstrumentIdentifier, string pin)
        {
            throw new NotImplementedException();
        }

        private void GetTimeout(string headerName, out int? requestTimeout)
        {
            GetTimeout(headerName, out requestTimeout, "");
        }
        private void GetTimeout(string headerName, out int? requestTimeout, AccountIdentifier accountIdentifier)
        {
            GetTimeout(headerName, out requestTimeout, accountIdentifier?.ToString());
        }
        private void GetTimeout(string headerName, out int? requestTimeout, AccountBalanceIdentifier accountBalanceIdentifier)
        {
            GetTimeout(headerName, out requestTimeout, accountBalanceIdentifier?.ToString());
        }
        private void GetTimeout(string headerName, out int? requestTimeout, string id)
        {
            requestTimeout = null;
            if (OptionsContext.Current.IsDefined(headerName))
            {
                requestTimeout = 1;
                if (int.TryParse(OptionsContext.Current.GetString(headerName), out var rt))
                    requestTimeout = rt;
                else if (OptionsContext.Current.GetString(headerName).Equals(id, StringComparison.CurrentCultureIgnoreCase))
                    requestTimeout = 1;
                else
                    requestTimeout = null;

                // 0 throws ArgumentOutOfRangeException in web client
                if (requestTimeout == 0)
                    requestTimeout = 1;
            }
        }
    }
}
