﻿using System.Diagnostics.CodeAnalysis;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Domain;
using Gd.Bos.RequestHandler.Core.Domain.Services.Core;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class CoreWebApiClient : ICoreWebApiClient
    {
        private readonly IServiceInvokeProvider _serviceInvokerProvider;
        private readonly string _coreApiUrl;

        public CoreWebApiClient(IServiceInvokeProvider serviceInvokerProvider, IRequestHandlerSettings settings)
        {
            _serviceInvokerProvider = serviceInvokerProvider;
            //_configuration = configuration;
            _coreApiUrl = settings.CoreApiBaseUrl;
        }

        public AssessTransferResponse AssessTransfer(AssessTransferRequest request)
        {
            var getAssessTransferResponse = _serviceInvokerProvider.GetWebResponse<AssessTransferRequest, AssessTransferResponse>(GenerateAssessTransferUrl(request.ProgramCode), "POST", request, null);

            return getAssessTransferResponse;
        }

        private string GenerateAssessTransferUrl(string programCode)
        {
            return _coreApiUrl + $"/programs/{programCode}/transfers/assess";
        }
    }
}
