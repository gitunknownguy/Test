﻿using Gd.Bos.Shared.Common.Core.Contract.Interface;
using RequestHandler.Core.Domain.Services.Risk;
using RequestHandler.Core.Domain.Services.Risk.Messages.Request;
using RequestHandler.Core.Domain.Services.Risk.Messages.Response;

namespace RequestHandler.Core.Infrastructure
{
    public class SuperTokenService : ISuperTokenService
    {
        private readonly IServiceInvokeProvider _serviceInvokerProvider;
        public SuperTokenService(IServiceInvokeProvider serviceInvokeProvider)
        {
            _serviceInvokerProvider = serviceInvokeProvider;
        }
        public SuperTokenResponse SuperTokenize(SuperTokenRequest request)
        {
            SuperTokenResponse response;
            try
            {
                response = _serviceInvokerProvider.GetWebResponse<SuperTokenRequest, SuperTokenResponse>($"{Gd.Bos.RequestHandler.Core.Infrastructure.Configuration.Configuration.Current.GssSuperTokenApiUrl}/Identity/SuperTokenizeRT", "POST", request);
                return response;
            }
            catch
            {
                throw;
            }
        }
    }
}
