﻿using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.RequestHandler.Core.Domain.Model.Systems;
using Gd.Bos.Shared.Common.Caching;
using Gd.Bos.Shared.Common.Caching.Contract;


namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class ActivationSystemRepository : IActivationSystemRepository
    {
        private IDataAccess _dataAccess;
        private ILazyCache _lazyCache;

        public ActivationSystemRepository(IDataAccess dataAccess, ILazyCache lazyCache)
        {
            _lazyCache = lazyCache;
            _dataAccess = dataAccess;
        }

        public List<ActivationSystem> GetSystems()
        {
            return _lazyCache.Get("GetAllSystem", new TimeSpan(1, 0, 0, 0), () => GetAllSystems());
        }

        private List<ActivationSystem> GetAllSystems()
        {
            List<ActivationSystem> list = new List<ActivationSystem>();

            try
            {
                using (var reader = _dataAccess.ExecuteReader("GetAllSystem", _dataAccess.CreateConnection(), null))
                {
                    while (reader.Read())
                    {
                        ActivationSystem system = new ActivationSystem();
                        system.SystemKey = reader.GetInt16(reader.GetOrdinal("SystemKey"));
                        system.System = reader.GetString(reader.GetOrdinal("System"));
                        list.Add(system);
                    }
                }
            }
            finally
            {

            }

            return list;
        }
    }
}
