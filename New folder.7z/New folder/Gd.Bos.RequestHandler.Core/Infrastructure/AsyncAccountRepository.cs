﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Core.Utils;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.Shared.Common.Core.Data;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using NLog;
using RequestHandler.Core.Domain.Model.Account;
using RequestHandler.Core.Domain.Model.CollectionAccount;
using RequestHandler.Core.Domain.Model.Product;
using RequestHandler.Core.Domain.Model.Upgrade;
using RequestHandler.Core.Infrastructure.Configuration;
using Account = Gd.Bos.RequestHandler.Core.Domain.Model.Account.Account;
using AccountHolder = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolder;
using AccountHolderCure = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolderCure;
using AccountStatus = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountStatus;
using AccountStatusReason = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountStatusReason;
using GetEnrollmentResponse = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.GetEnrollmentResponse;
using PaymentIdentifierInfo = Gd.Bos.RequestHandler.Core.Domain.Model.Payment.PaymentIdentifierInfo;
using PaymentInstrumentInfo = Gd.Bos.RequestHandler.Core.Domain.Model.Payment.PaymentInstrumentInfo;
using ProgramCode = Gd.Bos.RequestHandler.Core.Domain.Model.ProgramCode;
using User = Gd.Bos.RequestHandler.Core.Domain.Model.User.User;
using VerificationStatusReason = Gd.Bos.RequestHandler.Core.Domain.Model.Account.VerificationStatusReason;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    [ExcludeFromCodeCoverage(Justification = "Not tested previously and currently can't be easily mocked and will be taken care of on GBOS-116633")]
    public partial class AsyncAccountRepository : IAsyncAccountRepository
    {
        private readonly IDataAccess _dataAccess;
        private readonly IBaasConfiguration _baasConfiguration;
        private readonly string _userName = IdentityHelper.GetIdentityName();
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();
        private readonly ILazyCache _lazyCache;
        private readonly IProgramRepository _programRepository;
        private readonly IRequestHandlerSettings _requestHandlerSettings;
        private readonly ITokenizerService _tokenizerService;

        private readonly IMemoryCache _cache;
        private readonly AccountRepositorySettings _settings;
        private const string GetIndividualAccountHolderSP =
            "[dbo].[GetIndividualAccountHolderByAccountIdentifier]";

        public AsyncAccountRepository(
            IDataAccess dataAccess,
            IBaasConfiguration baasConfiguration,
            ILazyCache lazyCache,
            IProgramRepository programRepository,
            IRequestHandlerSettings requestHandlerSettings,
            ITokenizerService tokenizerService,
            IOptions<AccountRepositorySettings> settings,
            IMemoryCache cache)
        {
            _dataAccess = dataAccess;
            _baasConfiguration = baasConfiguration;
            _lazyCache = lazyCache;
            _programRepository = programRepository;
            _requestHandlerSettings = requestHandlerSettings;
            _tokenizerService = tokenizerService;
            _settings = settings.Value;
            _cache = cache;
        }

        public void Add(Account account)
        {
            throw new NotImplementedException();
        }

        public void CreateAdHocVerificationRequest(AccountHolder ah, long prodKey, Dictionary<Domain.Model.Account.VerificationActivityType, Domain.Model.Account.VerificationStatus> verifyList, TriggerType triggerType, short verificationStatusKey = 1)
        {
            throw new NotImplementedException();
        }

        public void CreateVerificationActivity(Account account, Dictionary<Domain.Model.Account.VerificationActivityType, Domain.Model.Account.VerificationStatus> verifyList, TriggerType triggerType)
        {
            throw new NotImplementedException();
        }

        public void CreateVerificationRequest(Account account, Dictionary<Domain.Model.Account.VerificationActivityType, Domain.Model.Account.VerificationStatus> type, TriggerType triggerType)
        {
            throw new NotImplementedException();
        }

        public void CreateVerificationRequestForBenificialOwner(Account account, AccountHolder accountHolder, Dictionary<Domain.Model.Account.VerificationActivityType, Domain.Model.Account.VerificationStatus> verifyList, TriggerType triggerType)
        {
            throw new NotImplementedException();
        }

        public void CreateVerificationRequestFromSetStatus(Account account, AccountHolder ah, Dictionary<Domain.Model.Account.VerificationActivityType, Domain.Model.Account.VerificationStatus> verifyList, TriggerType triggerType)
        {
            throw new NotImplementedException();
        }

        public List<Account> GetAccountBalanceBySccAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public AccountBillCycleInfo GetAccountBillCycle(string accountIdentifier, long accountKey = 0)
        {
            throw new NotImplementedException();
        }

        public Domain.Enums.BinType GetAccountBinType(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public AccountForCBS GetAccountByAccountIdentifierForCBS(string AccountIdentifier)
        {
            throw new NotImplementedException();
        }

        public Account GetAccountByAccountNumber(string accountNumber)
        {
            throw new NotImplementedException();
        }

        public Tuple<Account, string> GetAccountByPaymentIdentifierProxy(string piProxy)
        {
            throw new NotImplementedException();
        }

        public Dictionary<string, List<Account>> GetAccountByPaymentIdentifierProxyList(List<string> proxyList)
        {
            throw new NotImplementedException();
        }

        public List<AccountCardStatus> GetAccountCardStatus(List<Guid> accountIdentifiers)
        {
            throw new NotImplementedException();
        }

        public AccountPrimaryConsumerProfile GetAccountConsumerProfile(Guid? accountIdentifier, Guid? consumerProfileIdentifier, Guid? accountHolderIdentifier)
        {
            throw new NotImplementedException();
        }

        public AccountPrimaryConsumerProfile GetAccountConsumerProfile(string deviceTokenId)
        {
            throw new NotImplementedException();
        }

        public AccountPrimaryConsumerProfile GetAccountConsumerProfileByTokenizedPan(string tokenizedPan)
        {
            throw new NotImplementedException();
        }

        public List<Tuple<short, long, DateTime?>> GetAccountDetails(AccountIdentifier accountIdentifier, ProgramCode programCode)
        {
            throw new NotImplementedException();
        }

        public List<Tuple<long, DateTime?>> GetAccountDetailsByLinkedAccountIdentifier(AccountIdentifier accountIdentifier, ProgramCode programCode)
        {
            throw new NotImplementedException();
        }

        public List<AccountFeeTypeOverRide> GetAccountFeeTypeOverRideByAccountKeys(List<long> accountKey, Shared.Common.Logic.FeatureLimitsFees.Contract.Enum.FeeType feeType)
        {
            throw new NotImplementedException();
        }

        public Tuple<Guid, string> GetAccountIdentifierByTokenizedPan(string tokenizedPan)
        {
            throw new NotImplementedException();
        }

        public List<Guid> GetAccountIdentitisByIdentityToken(List<Tuple<int, string>> identityTokens)
        {
            throw new NotImplementedException();
        }

        public Account GetAccountInfoByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public Account GetAccountInfoByAccountIdentifierWithNoPaymentIdentifier(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public List<Account> GetAccountInfoByConsumerIdentifierProductCodes(string consumerIdentifier, List<string> productCodes)
        {
            throw new NotImplementedException();
        }

        public List<Tuple<Account, User>> GetAccountInfoByPhoneNumber(string phone)
        {
            throw new NotImplementedException();
        }

        public Tuple<Account, User> GetAccountInfoForFraud(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public AccountPrimaryConsumerProfile GetAccountPrimaryConsumerProfile(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public AccountPrimaryConsumerProfile GetAccountPrimaryConsumerProfile(AccountIdentifier accountIdentifier, Guid userIdentifier)
        {
            throw new NotImplementedException();
        }

        public AccountPrimaryConsumerProfile GetAccountPrimaryConsumerProfileAnyToken(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public AccountPrimaryConsumerProfile GetAccountPrimaryConsumerProfileAnyToken(AccountIdentifier accountIdentifier, Guid userIdentifier)
        {
            throw new NotImplementedException();
        }

        public AccountPrimaryConsumerProfile GetAccountPrimaryConsumerProfileAnyTokenWithMultipleAddresses(AccountIdentifier accountIdentifier, Guid userIdentifier)
        {
            throw new NotImplementedException();
        }

        public AccountPrimaryConsumerProfile GetAccountPrimaryConsumerProfileWithDefaultAddress(Guid? accountIdentifier, Guid? userIdentifier, IdentityType identityType = 0)
        {
            throw new NotImplementedException();
        }

        public string GetAccountPrimaryPhoneNumber(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public (string accountIdentifier, int productKey) GetAccountProductByAccountHolderKey(long accountHolderKey)
        {
            throw new NotImplementedException();
        }

        public List<Account> GetAccountsBySccAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public List<Account> GetAccountsBySsnToken(string ssnToken)
        {
            throw new NotImplementedException();
        }

        public AccountStatusAndBalances GetAccountStatusAndBalancesByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public List<AccountIdentity> GetAccountStatusAndIdentity(string consumerIdentifier, string accountIdentifier, List<string> productCodes)
        {
            throw new NotImplementedException();
        }

        public AdditionalAccountLimit GetAccountStatusByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public List<Domain.Model.Account.AccountStatusReason> GetActiveAccountStatusReasons(AccountIdentifier account)
        {
            throw new NotImplementedException();
        }

        public Tuple<AccountHolder, int, int> GetAdditionalHolderAccountByAccountHolderIdentifier(string accountHolderIdentifier)
        {
            throw new NotImplementedException();
        }

        public Account GetAdditionalHolderAccountByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public async Task<Account> GetByAccountIdentifier(AccountIdentifier accountIdentifier, Boolean replaceByChildAccountHolder = false)
        {
            try
            {
                var stopwatch = Stopwatch.StartNew();

                using var connection = _dataAccess.CreateConnection();
                using (var reader = await _dataAccess.ExecuteReaderAsync("[dbo].[GetAccountInfoByAccountIdentifier]", CommandType.StoredProcedure,
                    connection, default, new SqlParameter
                    {
                        ParameterName = "AccountIdentifier",
                        Value = accountIdentifier.ToString()
                    }))
                {
                    Account account = null;
                    while (await reader.ReadAsync())
                    {
                        var routingNumber = reader["RoutingNumber"] != DBNull.Value ? reader["RoutingNumber"].ToString() : string.Empty;
                        var productCode = reader["ProductCode"].ToString();
                        var productName = reader["ProductName"] != DBNull.Value ? reader["ProductName"].ToString() : string.Empty;
                        var productKey = Convert.ToInt32(reader["ProductKey"]);
                        var product = new Product(ProductCode.FromString(productCode), null, productKey, productName, null, routingNumber);
                        var consumerProfileIdentifier = reader["ConsumerProfileIdentifier"] != DBNull.Value ? reader["ConsumerProfileIdentifier"].ToString() : string.Empty;
                        if (account == null)
                        {
                            account = new Account(accountIdentifier, product, null)
                            {
                                AccountKey = (long)reader["AccountKey"],
                                AccountStatus = (AccountStatus)(short)reader["AccountStatusKey"],
                                ProductTierKey = (int)reader["ProductTierKey"],
                                UserIdentifier = consumerProfileIdentifier,
                                AccountStatusChangedDateTime = (DateTime)reader["StatusChangeDate"],
                                AccountNumber = reader["AccountNumber"] != DBNull.Value ? reader["AccountNumber"].ToString() : string.Empty,
                                AccountReferenceNumber = reader["AccountReferenceNumber"] != DBNull.Value ? reader["AccountReferenceNumber"].ToString() : string.Empty,
                                Language = reader["AccountLanguage"] != DBNull.Value ? reader["AccountLanguage"].ToString() : string.Empty,
                                FirstName = reader["FirstName"] != DBNull.Value ? reader["FirstName"].ToString() : string.Empty,
                                LastName = reader["LastName"] != DBNull.Value ? reader["LastName"].ToString() : string.Empty
                            };
                        }

                        bool IsPrimaryAccountHolder = false;
                        bool.TryParse(reader["IsPrimaryAccountHolder"].ToString(), out IsPrimaryAccountHolder);
                        if (replaceByChildAccountHolder && !IsPrimaryAccountHolder)
                        {
                            account.AccountKey = (long)reader["AccountKey"];
                            account.AccountStatus = (AccountStatus)(short)reader["AccountStatusKey"];
                            account.ProductTierKey = (int)reader["ProductTierKey"];
                            account.UserIdentifier = consumerProfileIdentifier;
                            account.AccountStatusChangedDateTime = (DateTime)reader["StatusChangeDate"];
                            account.AccountNumber = reader["AccountNumber"] != DBNull.Value ? reader["AccountNumber"].ToString() : string.Empty;
                            account.AccountReferenceNumber = reader["AccountReferenceNumber"] != DBNull.Value ? reader["AccountReferenceNumber"].ToString() : string.Empty;
                            account.Language = reader["AccountLanguage"] != DBNull.Value ? reader["AccountLanguage"].ToString() : string.Empty;
                            account.FirstName = reader["FirstName"] != DBNull.Value ? reader["FirstName"].ToString() : string.Empty;
                            account.LastName = reader["LastName"] != DBNull.Value ? reader["LastName"].ToString() : string.Empty;
                        }

                        int consumerProfileTypeKey = reader.IsDBNull(reader.GetOrdinal("ConsumerProfileTypeKey")) ? 0 : reader.GetInt16(reader.GetOrdinal("ConsumerProfileTypeKey"));
                        var consumerProfileKey = Convert.ToInt32(reader["ConsumerProfileKey"]);
                        var accountHolderIdentifier = reader["AccountHolderIdentifier"] != DBNull.Value ? reader["AccountHolderIdentifier"].ToString() : string.Empty;
                        var isPrimaryAccountHolder = reader["IsPrimaryAccountHolder"] != DBNull.Value && reader.GetBoolean(reader.GetOrdinal("IsPrimaryAccountHolder"));
                        var accountHolderCure = reader["AccountHolderCureKey"] == DBNull.Value ? AccountHolderCure.Unknown : (AccountHolderCure)(Convert.ToInt32(reader["AccountHolderCureKey"]));

                        AccountHolder ah = new AccountHolder(null, AccountHolderIdentifier.FromString(accountHolderIdentifier), null, isPrimaryAccountHolder);
                        ah.AccountHolderKey = (long)reader["AccountHolderKey"];
                        ah.AccountIdentifier = AccountIdentifier.FromGuid(Guid.Parse(reader["AccountIdentifier"].ToString()));
                        ah.AccountHolderCure = accountHolderCure;
                        ah.ConsumerProfileKey = consumerProfileKey;
                        ah.ConsumerProfileTypeKey = consumerProfileTypeKey;
                        ah.UserIdentifier = UserIdentifier.FromString(consumerProfileIdentifier);

                        account.AddAccountHolder(ah);
                    }

                    reader.NextResult();

                    if (account != null)
                    {
                        account.AccountStatusReasons = new List<AccountStatusReason>();
                        while (reader.Read())
                        {
                            AccountStatusReason reason = (AccountStatusReason)reader.GetInt16(1);
                            account.AccountStatusReasons.Add(reason);
                        }
                    }

                    // optional log stopwatch
                    stopwatch.Stop();
                    if (_requestHandlerSettings.LogStopwatch || OptionsContext.Current.ContainsKey("X-GD-LogStopwatch"))
                    {
                        Logger.Info(
                            "[{Class}.{Method}] retrieved by identifier {identifier} in {elapsedMs:F3} ms",
                            nameof(AsyncAccountRepository),
                            nameof(GetByAccountIdentifier),
                            accountIdentifier,
                            stopwatch.Elapsed.TotalMilliseconds);
                    }

                    if (account != null)
                    {
                        return account;
                    }

                    throw new AccountNotFoundException();
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(
                    $"AsyncAccountRepository.GetByAccountIdentifier, error occurred when retrieving account identifier {accountIdentifier} : {ex}");
                throw;
            }
        }

        public Account GetByAccountIdentifierWithPrimaryUser(AccountIdentifier accountIdentifier, ref string firstName, ref string lastName)
        {
            throw new NotImplementedException();
        }

        public CollectionAccount GetCollectionAccountByAccountIdentifier(Guid accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public List<(long AccountKey, string IdentityCountryCode)> GetConsumerProfileCountryInfoByAccountKeys(List<long> accountKeys)
        {
            throw new NotImplementedException();
        }

        public List<ConsumerProfile> GetConsumerProfiles(Guid accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public GetEnrollmentResponse GetEnrollmentByAccountIdentifier(string accountIdentifier, string programCode, bool includeCardData)
        {
            throw new NotImplementedException();
        }

        public List<Tuple<int, string>> GetIdentityTokenByAccountIdentity(string accountIdentifier, string programCode)
        {
            throw new NotImplementedException();
        }

        public CreateVerifyRequest GetIdvInfoByAccountIdentifierUserIdentifier(CreateVerifyRequest createVerifyRequest, Domain.Model.Account.VerificationActivityType activityType, bool isSecondCip = false)
        {
            throw new NotImplementedException();
        }

        public List<AccountHolderInfo> GetJointAccountHolderListByAccountIdentifier(Guid accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public Account GetKeysByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public List<AccountLinkDetail> GetLinkedAccountDetails(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public async Task<List<AccountLink>> GetLinkedAccounts(AccountIdentifier accountIdentifier)
        {
            var stopwatch = Stopwatch.StartNew();
            List<AccountLink> accounts = new List<AccountLink>();
            var input = new[]
            {
                new SqlParameter {ParameterName = "AccountIdentifier", Value = accountIdentifier.ToGuid()},
            };

            using var connection = _dataAccess.CreateConnection();
            using (var reader = await _dataAccess.ExecuteReaderAsync("[dbo].[GetLinkedAccounts]", CommandType.StoredProcedure, connection, default, input))
            {
                while (await reader.ReadAsync())
                {
                    var acc = new AccountLink();
                    acc.AccountLinkKey = long.Parse(reader["AccountLinkKey"].ToString());
                    acc.PrimaryAccountIdentifier = reader["PrimaryAccountIdentifier"].ToString();
                    acc.LinkAccountIdentifier = reader["LinkedAccountIdentifier"].ToString();
                    acc.StartDate = reader["StartDate"] == DBNull.Value ? (DateTime?)null : (DateTime)reader["StartDate"];
                    acc.EndDate = reader["EndDate"] == DBNull.Value ? (DateTime?)null : (DateTime)reader["EndDate"];
                    acc.AccountLinkType = (AccountLinkType)Enum.Parse(typeof(AccountLinkType), reader["AccountLinkTypeKey"].ToString());
                    acc.PrimaryAccountStatus = reader["PrimaryAccountStatusKey"] == null ? AccountStatus.Unknown : (AccountStatus)Cast<short>(reader["PrimaryAccountStatusKey"]);
                    acc.LinkAccountStatus = reader["LinkedAccountStatusKey"] == null ? AccountStatus.Unknown : (AccountStatus)Cast<short>(reader["LinkedAccountStatusKey"]);
                    accounts.Add(acc);
                }
            }
            // optional log stopwatch
            stopwatch.Stop();
            if (_requestHandlerSettings.LogStopwatch || OptionsContext.Current.ContainsKey("X-GD-LogStopwatch"))
            {
                Logger.Info(
                        "[{Class}.{Method}] retrieved by identifier {identifier} in {elapsedMs:F3} ms",
                        nameof(AsyncAccountRepository),
                        nameof(GetLinkedAccounts),
                        accountIdentifier,
                        stopwatch.Elapsed.TotalMilliseconds);
            }
            return accounts;
        }

        public Tuple<Account, List<PaymentIdentifierInfo>, List<PaymentInstrumentInfo>> GetPaymentIdentifierInfoByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public int GetProcessorKeyByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public ProductInfoDetail GetProductInfoByAccountIdentifier(Guid accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public short GetProductTierClassByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public Shared.Common.Core.CoreApi.Contract.Message.Response.GetPursesResponse GetPurses(string accountIdentifier, string programCode)
        {
            throw new NotImplementedException();
        }

        public (Domain.Model.Account.AccountStatus accountStatus, List<Domain.Model.Account.AccountStatusReason> accountStatusReasons, Domain.Model.Account.AccountHolderCure accountHolderCure) GetStatus(Guid accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public Tuple<User, List<UserProfileIdentity>> GetUserByAccountHolderIdentifier(string accountHolderIdentifier)
        {
            throw new NotImplementedException();
        }

        public CreateVerifyRequest GetVerficationRequestInfoByAccountIdentifierUserIdentifier(CreateVerifyRequest createVerifyRequest, Domain.Model.Account.VerificationActivityType activityType)
        {
            throw new NotImplementedException();
        }

        public void InsAccountFeeTypeOverRide(AccountFeeTypeOverRide accountFeeTypeOverRide)
        {
            throw new NotImplementedException();
        }

        public void InsertAccountStatusReason(AccountIdentifier accountIdentifier, IList<Domain.Model.Account.AccountStatusReason> reasonsToAdd)
        {
            throw new NotImplementedException();
        }

        public bool IsJointAccount(string accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public void Link(Domain.Model.Account.AccountLink accountLink)
        {
            throw new NotImplementedException();
        }

        public AccountBalanceIdentifier NextAccountBalanceIdentifier()
        {
            throw new NotImplementedException();
        }

        public AccountHolderIdentifier NextAccountHolderIdentifier()
        {
            throw new NotImplementedException();
        }

        public AccountIdentifier NextAccountIdentifier()
        {
            throw new NotImplementedException();
        }

        public VerificationRequestIdentifier NextVerificationRequestIdentifier()
        {
            throw new NotImplementedException();
        }

        public void OverrideAccountStatus(Account account, VerificationActivity verificationActivity, List<VerificationStatusReason> verificationStatusReasons, Domain.Model.Account.AccountStatus status, IList<Domain.Model.Account.AccountStatusReason> reasonsToAdd, IList<Domain.Model.Account.AccountStatusReason> reasonsToRemove, SourceSystem? source = null, bool isJoint = false)
        {
            throw new NotImplementedException();
        }

        public UserProfileIdentity ReadUserProfileIdentity(IDataReader reader, IdentityType identityType = IdentityType.SSN)
        {
            throw new NotImplementedException();
        }

        public void RemoveAccountStatusReason(AccountIdentifier accountIdentifier, IList<Domain.Model.Account.AccountStatusReason> reasonsToRemove)
        {
            throw new NotImplementedException();
        }

        public Tuple<List<VerificationActivity>, long> ReturnVerificationActivities(AccountHolderIdentifier accountHolderIdentifier)
        {
            throw new NotImplementedException();
        }

        public VerificationActivity ReturnVerificationActivity(AccountHolderIdentifier accountHolderIdentifier, Domain.Model.Account.VerificationActivityType activityType)
        {
            throw new NotImplementedException();
        }

        public void SetBillingCycleDate(string accountIdentifier, int billingCycleDate, DateTime activationDate, DateTime firstBillCycleDate)
        {
            throw new NotImplementedException();
        }

        public void UpdAccountFeeTypeOverRide(long AccountFeeTypeOverRideKey, DateTime OverRideEndDate)
        {
            throw new NotImplementedException();
        }

        public void UpdAccountProductTier(Guid accountIdentifier, int productTierKey)
        {
            throw new NotImplementedException();
        }

        public void UpdateAccountNumber(Guid accountIdentifier, string accountNumber)
        {
            throw new NotImplementedException();
        }

        public void UpdateAccountStatus(Account account, Domain.Model.Account.AccountStatus status, IList<Domain.Model.Account.AccountStatusReason> reasonsToAdd, IList<Domain.Model.Account.AccountStatusReason> reasonsToRemove, SourceSystem? source = null)
        {
            throw new NotImplementedException();
        }

        public void UpdateAccountToken(string accountIdentifier, string partnerAccountIdentifier)
        {
            throw new NotImplementedException();
        }

        public void UpdateAdhocVerificationReason(Account account, AccountHolder ah, Dictionary<int, Tuple<Domain.Model.Account.VerificationActivityType, Domain.Model.Account.VerificationStatus, List<VerificationStatusReason>>> resultData)
        {
            throw new NotImplementedException();
        }

        public void UpdateCardEmbossName(Guid paymentIdentifier, string embossedName)
        {
            throw new NotImplementedException();
        }

        public void UpdateDeviceProvisioningMessage(string deviceIdentifier, string dPanId, string fPanId)
        {
            throw new NotImplementedException();
        }

        public void UpdateIsPrimaryAccountHolder(string accountHolderIdentifier)
        {
            throw new NotImplementedException();
        }

        public void UpdateLinkAccount(long accountLinkKey)
        {
            throw new NotImplementedException();
        }

        public void UpdateVerificationRequest(Account account, AccountHolder ah, Dictionary<Domain.Model.Account.VerificationActivityType, Domain.Model.Account.VerificationStatus> verifyList, Domain.Model.Account.VerificationStatus verificationStatus, List<Domain.Model.Account.AccountStatusReason> statusReasons, Dictionary<int, Tuple<Domain.Model.Account.VerificationActivityType, Domain.Model.Account.VerificationStatus, List<VerificationStatusReason>>> resultData, bool isJointAccount = false, bool isHardDeclined = false)
        {
            throw new NotImplementedException();
        }

        public void UpdateVerificationRequest(Account account, AccountHolder ah, Dictionary<Domain.Model.Account.VerificationActivityType, Domain.Model.Account.VerificationStatus> verifyList, Domain.Model.Account.VerificationStatus verificationStatus, Dictionary<int, Tuple<Domain.Model.Account.VerificationActivityType, Domain.Model.Account.VerificationStatus, List<VerificationStatusReason>>> resultData, bool updateAccountHolderCure, Domain.Model.Account.AccountHolderCure upgradeCure)
        {
            throw new NotImplementedException();
        }

        public void UpdateVerificationRequestAdditionalHolder(Account account, AccountHolder ah, Domain.Model.Account.VerificationStatus verificationStatus, Dictionary<int, Tuple<Domain.Model.Account.VerificationActivityType, Domain.Model.Account.VerificationStatus, List<VerificationStatusReason>>> resultData)
        {
            throw new NotImplementedException();
        }

        public AccountLimit VerifyAccountLimitByProduct(string ssnToken, string productCode, string accountCure)
        {
            throw new NotImplementedException();
        }

        public void VerifyEmailLimitByProgram(string programCode, string email, int responseCodeWhenThrowException, long? accountKey = null)
        {
            throw new NotImplementedException();
        }
    }
}
