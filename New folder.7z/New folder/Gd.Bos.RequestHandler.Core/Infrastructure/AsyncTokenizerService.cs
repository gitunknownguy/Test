﻿using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using System.Threading;
using Newtonsoft.Json;
using Gd.Bos.Shared.Common.Core.Logic;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    [ExcludeFromCodeCoverage(Justification = "mainly handles infrastructure operations and external dependencies")]
    public class AsyncTokenizerService : IAsyncTokenizerService
    {
        private readonly string _tokenizeUrl;
        private readonly IServiceInvokeProvider _serviceInvokerProvider;
        private const string _tokenizeServiceUrl = "/ssn/tokenize";
        private const string _detokenizeServiceUrl = "/Ssn/deTokenize";
        private const string _deTokenizePanServiceUrl = "/pan/detokenize";
        private const string _tokenizePanServiceUrl = "/pan/tokenize";
        private const string _tokenizeEinUrl = "/ein/tokenize";
        private const string _detokenizeEinUrl = "/ein/deTokenize";
        private const string _tokenizeIdentityUrl = "/Identity/tokenize";
        private const string _detokenizeIdentityUrl = "/Identity/detokenize";

        public AsyncTokenizerService(IServiceInvokeProvider serviceInvokeProvider)
        {
            _serviceInvokerProvider = serviceInvokeProvider;
            _tokenizeUrl = Configuration.Configuration.Current.TokenizerUrl;
        }

        public string DeTokenizeEin(string token, string programCode)
        {
            throw new NotImplementedException();
        }

        public DetokenizeIdentityResponse DeTokenizeIdentity(string value)
        {
            throw new NotImplementedException();
        }

        public async Task<string> DeTokenizePan(string token)
        {
            if (!string.IsNullOrEmpty(token))
            {
                var pan = OptionsContext.Current.GetString($"DeTokenizePan-{token}");
                if (!string.IsNullOrEmpty(pan)) return pan;
                DetokenizePanRequest request = new DetokenizePanRequest
                {
                    RequestHeader = new RequestHeader
                    {
                        RequestId = OptionsContext.Current.GetGuid("requestId", Guid.NewGuid())
                    },
                    Token = token
                };

                var jsonRequest = JsonConvert.SerializeObject(request);

                DetokenizePanResponse tokenResponse = await _serviceInvokerProvider.GetWebResponseAsync<DetokenizePanResponse>(_tokenizeUrl + _deTokenizePanServiceUrl, "POST", jsonRequest);

                if (tokenResponse == null)
                    throw new Exception($"Tokenizer pan service did not return a successful response.");

                if (tokenResponse.ResponseHeader.StatusCode != 200)
                    throw new Exception($"Tokenizer pan service did not return success: Message: {tokenResponse.ResponseHeader.Message}; Details: {tokenResponse.ResponseHeader.Details}");

                OptionsContext.Current = OptionsContext.Current.Add($"DeTokenizePan-{token}", tokenResponse.Pan);
                return tokenResponse.Pan;
            }
            return string.Empty;
        }

        public string DeTokenizeSsn(string token, string programCode)
        {
            throw new NotImplementedException();
        }

        public string TokenizeEin(string ein, string programCode)
        {
            throw new NotImplementedException();
        }

        public string TokenizeIdentity(string value, IdentityType type, string country, string programCode)
        {
            throw new NotImplementedException();
        }

        public string TokenizePan(string pan)
        {
            throw new NotImplementedException();
        }

        public string TokenizeSsn(string ssn, string programCode)
        {
            throw new NotImplementedException();
        }
    }
}
