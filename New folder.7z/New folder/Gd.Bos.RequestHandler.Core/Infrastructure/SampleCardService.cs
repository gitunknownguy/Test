﻿using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Services.Dcpp;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.Shared.Common.Caching;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Application;
using RequestHandler.Core.Domain.Services.Dcpp;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Gd.Bos.Logging.Common.Managers;
using Gd.Bos.RequestHandler.Core.Domain;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Core.Common.Data;
using Gd.Bos.Shared.Common.Core.Common.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.Shared.Common.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.UtilityCoreApi.Contract.Enum;
using NLog;
using Address = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Address;
using Email = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Email;
using ExpirationDate = RequestHandler.Core.Domain.Services.Dcpp.ExpirationDate;
using GetProspectDetailsByIdRequest = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.GetProspectDetailsByIdRequest;
using GetProspectDetailsResponse = RequestHandler.Core.Domain.Services.ProspectApi.GetProspectDetailsResponse;
using LogManager = NLog.LogManager;
using RequestHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.RequestHeader;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using User = Gd.Bos.RequestHandler.Core.Domain.Model.User.User;
using RequestHandler.Core.Domain.Model.User;
using Newtonsoft.Json;
using RequestHandler.Core.Domain.Enums;
using Gd.Bos.Shared.Common.Logic.ProcessorSelector.Model;

namespace RequestHandler.Core.Infrastructure
{
    public class SampleCardService : ISampleCardService
    {
        private readonly ILazyCache _lazyCache;
        private const string ProspectDetailRedisKeyPrefix = "RH_ProspectDetails_";
        private const string ProspectCardProxyKeyPrefix = "RH_ProspectDetails_CardProxy_";
        private readonly IProspectService _prospectService;
        private readonly IAccountMigrationService _accountMigrationService;
        private readonly IAccountService _accountService;
        private readonly IDcppService _dcppService;
        private readonly ITokenizerService _tokenizerService;
        private readonly IPaymentIdentifierRepository _paymentIdentifierRepository;
        private readonly IProductService _productService;
        private readonly IProgramRepository _programRepository;

        private readonly ICardStockRepository _cardStockRepository;
        private readonly IRequestHandlerSettings _configuration;
        private readonly IPriorityNotificationService _priorityNotificationService;
        private readonly IUserRepository _userRepository;
        private const string GDBankABARoutingNumber = "124303120";
        private const string SourceSystem = "nec";
        private const string DefaultMigrationType = "tsystogo2bank";

        private readonly IAccountRepository _accountRepository;


        /// private readonly IPaymentInstrumentService _paymentInstrumentService;

        private static readonly Logger _logger = LogManager.GetCurrentClassLogger();
        public SampleCardService(IProspectService prospectService,
            IAccountMigrationService accountMigrationService, IAccountService accountService, IDcppService dcppService,
            ILazyCache lazyCache, ITokenizerService tokenizerService,
            IPaymentIdentifierRepository paymentIdentifierRepository,
            IProductService productService, IProgramRepository programRepository,
            ICardStockRepository cardStockRepository,
            IRequestHandlerSettings requestHandlerSettings,
            IPriorityNotificationService priorityNotificationService,
            IAccountRepository accountRepository,
             IUserRepository userRepository
            )
        {
            _prospectService = prospectService;
            _accountMigrationService = accountMigrationService;
            _accountService = accountService;
            _dcppService = dcppService;
            _lazyCache = lazyCache;
            _tokenizerService = tokenizerService;
            _paymentIdentifierRepository = paymentIdentifierRepository;
            _productService = productService;
            _programRepository = programRepository;
            _cardStockRepository = cardStockRepository;
            _configuration = requestHandlerSettings;
            _priorityNotificationService = priorityNotificationService;
            _accountRepository = accountRepository;
            _userRepository = userRepository;
            // _paymentInstrumentService = paymentInstrumentService;
        }

        private string GetBinByPan(string pan)
        {
            var requestId = OptionsContext.Current.GetGuid("requestId", Guid.NewGuid());
            _logger.Info($"Start->GetBinByPan->RequestId->{requestId}");
            var tokenizedPan = _tokenizerService.TokenizePan(pan);
            var bin = _paymentIdentifierRepository.GetBinByTokenizedPan(tokenizedPan);
            _logger.Info($"End->GetBinByPan->RequestId->{requestId}->Bin->{bin}");
            return bin;
        }

        [ExcludeFromCodeCoverage(Justification ="it doesn't have references")]
        private void SendUpgradeNotification(
            AccountIdentifier accountIdentifier,
            string programCode, string email = null)
        {
            var userData = _accountRepository.GetAccountPrimaryConsumerProfileAnyToken(accountIdentifier);
            if (userData == null)
            {
                _logger.Info($"call GetByAccountIdentifierUserIdentifier is null in upgradatetoemve method accountIdentifier:{accountIdentifier}");
                return;
            }

            var contacts = new[] { new MessageContact { ChannelType = "2", ContactValue = string.IsNullOrWhiteSpace(email) ? userData.Email : email } };
            var attributes = new List<MessageAttribute>
                    {
                        new MessageAttribute {Name = "FirstName", Value = userData.FirstName},
                        new MessageAttribute {Name = "LastName", Value = userData.LastName},
                        new MessageAttribute {Name = "Address1", Value =userData.Address1},
                        new MessageAttribute {Name = "Address2", Value =userData.Address2},
                        new MessageAttribute {Name = "City", Value = userData.City},
                        new MessageAttribute {Name = "State", Value = userData.State},
                        new MessageAttribute {Name = "Zip", Value = userData.ZipCode}
                    };

            var sendCnMsgRequest = new SendCnMessageRequest
            {
                RequestHeader = new Gd.Bos.Shared.Common.Contract.Message.Request.RequestHeader()
                { RequestId = OptionsContext.Current.GetGuid("requestId", Guid.NewGuid()) },
                ProductCode = userData.ProductCode,
                Contacts = contacts,
                ProgramCode = programCode,
                Attributes = attributes.ToArray(),
                AccountIdentifier = accountIdentifier.ToString(),
                NotificationType = (int)CnNotificationType.CardUpgradeMagstripeToEMV
            };
            try
            {
                _priorityNotificationService.PublishPriorityNotification(programCode, sendCnMsgRequest);
                _logger.Info(
                    $"Upgrade to Emv Notification has publish successfuly. sendCnMsgRequest:{MaskEngine.MaskMessage(Newtonsoft.Json.JsonConvert.SerializeObject(sendCnMsgRequest))}");
            }
            catch (Exception e)
            {
                _logger.Warn(e, 
                    $"Upgrade to Emv Notification has publish faild. sendCnMsgRequest::{MaskEngine.MaskMessage(Newtonsoft.Json.JsonConvert.SerializeObject(sendCnMsgRequest))}");
            }
        }

        public void UpgradeToEmv(AccountIdentifier accountIdentifier,
        PaymentIdentifierIdentifier paymentIdentifierIdentifier,
        PaymentInstrumentIdentifier paymentInstrumentIdentifier,
   string programCode, string email = null)
        {
            var targetProductMaterialType = UpgradeEmvProduct(accountIdentifier,
    paymentInstrumentIdentifier,
    programCode, email);
            if (targetProductMaterialType != string.Empty)
            {
                _dcppService.OrderPhysicalCard(accountIdentifier,
                    paymentIdentifierIdentifier,
                    paymentInstrumentIdentifier,
                    programCode,
                    targetProductMaterialType,
                    null,
                    Gd.Bos.Dcpp.Contract.Enum.ReplacementReason.Upgrade,
                    false, DeliveryMethod.Regular, null, null, true, true);
            }
            //
            //SendUpgradeNotification(accountIdentifier, programCode, email);
        }
        public string UpgradeEmvProduct(AccountIdentifier accountIdentifier,
        PaymentInstrumentIdentifier paymentInstrumentIdentifier,
        string programCode, string email = null)
        {
            var paymentIdentifier =
                _paymentIdentifierRepository.GetPaymentIdentifierByPaymentInstrumentIdentifier(
                    paymentInstrumentIdentifier, out _);

            if (paymentIdentifier == null)
            {
                //when the current card is EMV, do not upgrade. #GBOS-60976 Error Replacing DirectMail cards with ProductTierKey 77 (Hotfix)
                _logger.Info($"no paymentIdentifier is found, EMV upgrade was skipped.paymentInstrumentIdentifier={paymentInstrumentIdentifier},AccountIdentifier ={accountIdentifier}");
                return string.Empty;
            }

            if (paymentIdentifier?.PaymentInstrument?.PaymentInstrumentType == Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PaymentInstrumentType.Emv ||
                paymentIdentifier?.PaymentInstrument?.PaymentInstrumentType == Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PaymentInstrumentType.ContactlessEmv)
            {
                _logger.Info($"PaymentInstrument is already EMV, EMV upgrade was skipped. paymentInstrumentIdentifier=paymentInstrumentIdentifier={paymentInstrumentIdentifier},AccountIdentifier ={accountIdentifier}");
                return string.Empty;
            }

            //Convert to CBS cardStock if ACI Live
            paymentIdentifier.CardStock = GetCBSCardStockIfACILive(paymentIdentifier.ProductCode, paymentIdentifier.CardStock, false);
            _logger.Info($"PaymentIdentifier.Cardstock={paymentIdentifier.CardStock},PaymentIdentifier.ProductCode ={paymentIdentifier.ProductCode}.paymentInstrumentIdentifier={paymentInstrumentIdentifier},AccountIdentifier ={accountIdentifier} ");

            var prg = _programRepository.GetByProgramIdentifier(ProgramCode.FromString(programCode));
            var prgInfo = _programRepository.GetProgramTierInfo(prg.ProgramKey);
            var productEmvTierInfo = prgInfo.ProductTiers?.FirstOrDefault(x =>
                x.ProductCode.Equals(paymentIdentifier.ProductCode, StringComparison.InvariantCultureIgnoreCase)
                && x.ProductTierClasskey == (short)ProducttierClass.MagStripe
                && x.ProductTierAttribute == "CardStock"
                && x.Value == paymentIdentifier.CardStock);

            _logger.Info($"productEmvTierInfo.ProductTierClasskey={productEmvTierInfo?.ProductTierClasskey}, productEmvTierInfo.ProductTierAttribute={productEmvTierInfo?.ProductTierAttribute},productEmvTierInfo.ProductCode={productEmvTierInfo?.ProductCode},productEmvTierInfo.value ={productEmvTierInfo?.Value}.AccountIdentifier ={accountIdentifier}");

            if (productEmvTierInfo == null)
            {
                _logger.Info($"Cannot find ProductEmvTierInfo where ProductTierClasskey is EMV.,AccountIdentifier ={accountIdentifier}");
                return string.Empty;
            }

            var allCardStocks = _cardStockRepository.GetAllCardStocks();
            var cardStocks = allCardStocks.Where(c => c.ProductCode == paymentIdentifier.ProductCode && c.Value == productEmvTierInfo.Value);
            int targetProductTierKey = default(int);
            string targetProductMaterialType = string.Empty;
            bool isContainsKey = false;
            string mappingKey = string.Empty;

            foreach (var cs in cardStocks)
            {
                mappingKey =
                   $"{productEmvTierInfo.Value}-{cs.ProductMaterialType}-{productEmvTierInfo.ProductTierKey}";
                isContainsKey = _configuration.UpgradeEmvMapping.ContainsKey(mappingKey);
                if (!isContainsKey)
                    continue;

                var upgradeTarget = _configuration.UpgradeEmvMapping[mappingKey].Split('-');
                targetProductMaterialType = upgradeTarget[0];
                targetProductTierKey = Convert.ToInt32(upgradeTarget[1]);
                break;
            }

            _logger.Info($"mappingKey={mappingKey}.paymentInstrumentIdentifier={paymentInstrumentIdentifier},isContainsKey={isContainsKey},AccountIdentifier ={accountIdentifier}");

            _logger.Info($"upgradeTarget.targetProductMaterialType={targetProductMaterialType}.upgradeTarget.targetProductTierKey={targetProductTierKey},AccountIdentifier ={accountIdentifier}");

            if (!isContainsKey)
                throw new Exception($"Cannot find mappingkey:{mappingKey} in config . AccountIdentifier ={accountIdentifier}");

            _dcppService.UpdateProduct(accountIdentifier.ToString(),
                programCode,
               targetProductTierKey,
               targetProductMaterialType);
            return targetProductMaterialType;
        }

        public AcquisitionChannel GetAcquisitionChannelByAccountIdentifier(AccountIdentifier accountIdentifier, Guid requestId)
        {
            //get cuomserprofilekey
            var customerInfo = _userRepository.GetUser(accountIdentifier, null).FirstOrDefault();
            if (customerInfo == null)
                throw new ValidationException(10, 0, $"User Not Found AccountIdentifier={accountIdentifier}");

            var consumerProfileExtensions = _userRepository.GetConsumerProfileExtension(customerInfo.UserIdentifier.ToString());
            if (!consumerProfileExtensions.Any())
                return AcquisitionChannel.OS;

            var consumerExtensionInfo = consumerProfileExtensions
                .FirstOrDefault(c => c.ConsumerProfileExtensionAttributeKey == (int)ConsumerProfileExtensionAttribute.ProspectProfile);

            if (consumerExtensionInfo == null)
                return AcquisitionChannel.OS;

            var prospectProfile = JsonConvert.DeserializeObject<ProspectProfile>(consumerExtensionInfo.ConsumerProfileExtensionAttributeValue);
            _logger.Info($"GetAcquisitionChannelByAccountIdentifier->prospectProfile is {consumerExtensionInfo.ConsumerProfileExtensionAttributeValue},RequestId {requestId}");
            // callback updates the sampletype of consumerextension
            if (prospectProfile.SampleType == SampleType.Default)
            {
                var prospectDetail = GetProspectDetailsById(new GetProspectDetailsByIdRequest
                {
                    ProspectIdentifier = prospectProfile.ProspectIdentifier,
                    RequestHeader =
                        new RequestHeader
                        {
                            RequestId = requestId
                        }
                });
                _logger.Info($"GetAcquisitionChannelByAccountIdentifier -> GetProspectDetailsById is {prospectProfile.SampleType} ,RequestId {requestId}");
                prospectProfile.SampleType = (SampleType)prospectDetail.ProspectDetail.SampleType;

                _userRepository.UpdateConsumerProfileExtension(
                    customerInfo.ConsumerProfileKey,
                    ConsumerProfileExtensionAttribute.ProspectProfile,
                    JsonConvert.SerializeObject(prospectProfile));
            }

            return (AcquisitionChannel)prospectProfile.SampleType;
        }

        public ValidateSampleCardResponse ValidateSampleCard(ValidateSampleCardRequest request)
        {
            if (request == null)
            {
                throw new ArgumentNullException(nameof(request));
            }

            if (request.RequestHeader == null)
            {
                request.RequestHeader = new RequestHeader()
                {
                    RequestId = Guid.NewGuid()
                };
            }

            var prospectDetail = GetProspectDetailsFromCache(request);

            var response = new ValidateSampleCardResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = 0
                },
                ProspectIdentifier = prospectDetail.ProspectIdentifier,
                ProspectType = MapSampleTypeKeyToProspectType(prospectDetail.SampleType),
                ProspectStatus = prospectDetail.ProspectStatus,
                ProspectProductCode = prospectDetail.ProductCode,
            };

            return response;
        }

        public GetProspectDetailsByIdResponse GetProspectDetailsById(GetProspectDetailsByIdRequest request)
        {
            if (string.IsNullOrEmpty(request?.ProspectIdentifier))
            {
                throw new ValidationException(601, 0, $"Prospect record is not found for {request?.ProspectIdentifier}");
            }
            try
            {
                var details = _prospectService.GetProspectDetailsById(new GetProspectDetailsByIdRequest()
                {
                    ProspectIdentifier = request.ProspectIdentifier,
                    RequestHeader = new RequestHeader()
                    {
                        RequestId = request.RequestHeader.RequestId
                    }
                });

                if (details == null)
                    throw new ValidationException(601, 0, $"Prospect record is not found for {request?.ProspectIdentifier}");
                return details;
            }
            catch (ValidationException e)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new Exception($"GetProspectDetailsById failed.", e);
            }
        }

        public ProspectDetail GetProspectDetailsFromCache(ValidateSampleCardRequest request)
        {
            var cardProxy = GetCardProxy(request);

            var cardProxyKey = _prospectService.BuildProspectDetailsCardProxyCacheKey(cardProxy);
            var details = _lazyCache.Get(cardProxyKey, new TimeSpan(1, 0, 0, 0), () =>
            {
                var detailResponse = GetProspectDetailsByCardProxy(cardProxy, request.RequestHeader.RequestId);

                if (detailResponse != null && detailResponse.ResponseHeader.StatusCode == 0)
                {
                    return new ProspectDetail
                    {
                        SampleType = detailResponse.SampleType,
                        ProspectIdentifier = detailResponse.ProspectIdentifier,
                        ProspectStatus = detailResponse.ProspectStatus,
                        ProductCode = detailResponse.ProductCode,
                    };
                }
                return null;
            });
            _logger.Info($"GetProspectDetailsFromCache->CardProxyKey={cardProxy}");

            return details;
        }

        public string GetCardProxy(ValidateSampleCardRequest request)
        {
            if (string.IsNullOrEmpty(request?.Pan))
            {
                throw new ValidationException(4, 302, "Identification Failed. ValidateSampleCardRequest cannot be empty.");
            }

            if (request.IsExpirationDateOptional != true && (string.IsNullOrEmpty(request?.ExpirationDate?.Year) || string.IsNullOrEmpty(request?.ExpirationDate?.Month)))
            {
                throw new ValidationException(4, 302, "Identification Failed. ValidateSampleCardRequest cannot be empty.");
            }

            if (!IsValidBin(request.ProgramCode, request.Pan))
            {
                throw new ValidationException(4, 302, "Identification Failed. ProgramCode and bin not match.");
            }

            var cacheKey = BuildGetProspectDetailsCacheKey(request.Pan, request.Cvv, request.ExpirationDate.Year,
                request.ExpirationDate.Month);
            var cardProxy = _lazyCache.Get(cacheKey, new TimeSpan(1, 0, 0, 0), () => ValidateCvvByPanAndReturnCardProxy(request.Pan, request.Cvv,
                request.ExpirationDate.Year, request.ExpirationDate.Month, request.ProgramCode, request.IsExpirationDateOptional));
            return cardProxy;
        }

        public void CheckSsn(string ssnToken, string last4Ssn, int prospectTypeKey, string programCode)
        {
            //1-WB,2-DM,3-DDA
            if (prospectTypeKey == 1)
            {
                if (string.IsNullOrEmpty(last4Ssn) || last4Ssn.Length != 4)
                {
                    throw new ValidationException(4, 302, $"Identification Failed, invalid last4Ssn.");
                }

                if (string.IsNullOrEmpty(ssnToken))
                {
                    throw new ValidationException(4, 302, $"Identification Failed, invalid ssnToken.");
                }

                var ssn = _tokenizerService.DeTokenizeSsn(ssnToken, programCode);
                if (string.IsNullOrEmpty(ssn) || ssn.Length < 4)
                {
                    throw new ValidationException(4, 302, $"Identification Failed, invalid ssn.");
                }

                if (!ssn.EndsWith(last4Ssn))
                {
                    throw new ValidationException(4, 302, $"Identification Failed, last4Ssn not match.");
                }
            }
        }

        //public void UpgradeToEmv(AccountIdentifier accountIdentifier, PaymentIdentifierIdentifier paymentIdentifierIdentifier,
        //    PaymentInstrumentIdentifier paymentInstrumentIdentifier, string programCode, string productMaterialType)
        //{
        //    var paymentIdentifier =
        //        _paymentIdentifierRepository.GetPaymentIdentifierByPaymentInstrumentIdentifier(
        //            paymentInstrumentIdentifier, out _);

        //    if(paymentIdentifier == null)
        //    {
        //        // log "no paymentIdentifier is found, EMV upgrade was skipped.
        //        return;
        //    }

        //    var productTierInfo = _productService.GetDefaultProductTierByProgramCodeProductCodeProductTierClass(programCode, paymentIdentifier.ProductCode, ProducttierClass.EMV);
        //    _dcppService.UpdateProduct(accountIdentifier.ToString(), programCode, productTierInfo.ProductTierKey, productMaterialType);
        //    _dcppService.OrderPhysicalCard(accountIdentifier, paymentIdentifierIdentifier, paymentInstrumentIdentifier,
        //        programCode, productMaterialType, null, ReplacementReason.Upgrade);
        //}



        private static string BuildGetProspectDetailsCacheKey(string pan, string cvv, string year, string month)
        {
            var tmpKey = $"{pan}{cvv}{year}{month}";
            //Create a byte array from source data
            var tmpSource = Encoding.UTF8.GetBytes(tmpKey);

            //Compute hash based on source data
            using (var provider = new SHA256CryptoServiceProvider())
            {
                var tmpHash = provider.ComputeHash(tmpSource);

                var hash = ByteArrayToString(tmpHash);

                return $"{ProspectDetailRedisKeyPrefix}{hash}";
            }
        }

        private static string ByteArrayToString(byte[] data)
        {
            var sBuilder = new StringBuilder();

            // Loop through each byte of the hashed data
            // and format each one as a hexadecimal string.
            foreach (var b in data)
            {
                sBuilder.Append(b.ToString("x2"));
            }

            // Return the hexadecimal string.
            return sBuilder.ToString();
        }

        private string ValidateCvvByPanAndReturnCardProxy(string pan, string cvv, string year, string month, string programCode, bool? isExpirationDateOptional = null)
        {
            ValidateCvvByPanResponse validateCvvByPanResponse;
            try
            {
                validateCvvByPanResponse = _dcppService.ValidateCvvByPan(new ValidateCvvByPanRequest()
                {
                    CVV = cvv,
                    ExpirationDate = isExpirationDateOptional == true ? null : new ExpirationDate()
                    {
                        Month = month,
                        Year = year
                    },
                    Pan = pan,
                    IsExpirationDateOptional = isExpirationDateOptional,
                    ProgramCode = programCode
                });
            }
            catch (Exception e)
            {
                throw new Exception($"ValidateCvvByPan failed.", e);
            }

            if (validateCvvByPanResponse?.Header?.StatusCode != "200" || !validateCvvByPanResponse.ValidationStatus)
            {
                throw new ValidationException(4, 302, "Identification Failed. Pan,cvv,expiration date not match.");
            }

            if (string.IsNullOrEmpty(validateCvvByPanResponse.CardProxy))
            {
                throw new ValidationException(4, 302, "Identification Failed. CardProxy not found.");
            }

            return validateCvvByPanResponse.CardProxy;
        }

        private GetProspectDetailsResponse GetProspectDetailsByCardProxy(string cardProxy, Guid requestId)
        {
            var details = _prospectService.GetProspectDetails(new Domain.Services.GetProspectDetailsRequest()
            {
                CardProxy = cardProxy,
                Header = new Gd.Bos.Shared.Common.Dcpp.Contract.Message.RequestHeader
                {
                    RequestId = requestId
                }
            });

            if (details == null)
                throw new ValidationException(4, 302, $"Identification Failed. No prospect card found by cardProxy:{cardProxy}.");

            return details;
        }


        private bool MappingOptOutByStatus(int? prospectStatus, string prospectIdentifier)
        {

            string prospectInfoFromDB = _userRepository.GetAccountIdentifierByProspectId(prospectIdentifier);

            if (!string.IsNullOrWhiteSpace(prospectInfoFromDB))
            {
                string accountIdentifier = JsonConvert
                     .DeserializeObject<ProspectProfile>(prospectInfoFromDB)
                     .AccountIdentifier;

                if (!string.IsNullOrEmpty(accountIdentifier))
                {
                    return !_paymentIdentifierRepository.GetPaymentIdentifierByAccountIdentifier(accountIdentifier).Any();
                }
                else
                {
                    _logger.Info($"MappingIsForceOptOutByStatus -> Cannot get AccountIdentifier by deserializing prospectInfoFromDB={prospectInfoFromDB}");
                }
            }
            else
            {
                _logger.Info($"MappingIsForceOptOutByStatus -> can not found ProspectInfo by prospectIdentifier={prospectIdentifier}");
            }

            //1	Initial	IsForceOptOut=True
            //2	Enrolled Success	IsForceOptOut=False
            //3	Card Returned	IsForceOptOut=True
            //4	Opt Out	Should not do OptOut due to already Opt out
            //5	Enrolled - Opt Out	Should not do OptOut due to already Opt out

            return prospectStatus == 1 || prospectStatus == 3;
        }


        private void ResetCacheForGetProspectDetails(ProspectDetail detail)
        {
            var prospectCacheKey = _prospectService.BuildGetProspectDetailsByIdCacheKey(detail.ProspectIdentifier);
            var cardProxyCacheKey = _prospectService.BuildProspectDetailsCardProxyCacheKey(detail.CardProxy);

            bool isExistsProspectCacheKey = _lazyCache.Value.Exists(prospectCacheKey);
            bool isExistsCardProxyCacheKey = _lazyCache.Value.Exists(cardProxyCacheKey);

            _logger.Info($"OptOutByProspectId->ProspectCacheKey={prospectCacheKey}{isExistsProspectCacheKey},CardProxyCacheKey={cardProxyCacheKey}{isExistsCardProxyCacheKey}");

            if (isExistsProspectCacheKey)
            {
                _lazyCache.Value.Remove(prospectCacheKey);
                _logger.Info($"OptOutByProspectId -> RemoveProspectCacheKey Success");
            }

            if (isExistsCardProxyCacheKey)
            {
                _lazyCache.Value.Remove(cardProxyCacheKey);
                _logger.Info($"OptOutByProspectId -> RemoveCardProxyCacheKey Success");
            }
        }

        public AccountMigrationResponse AccountMigration(AccountMigrationRequest request)
        {
            var prospectResponse = GetProspectDetailsById(new GetProspectDetailsByIdRequest
            {
                ProgramCode = request.ProgramCode,
                ProspectIdentifier = request.ProspectIdentifier,
                RequestHeader = new RequestHeader { RequestId = request.RequestHeader.RequestId }
            });
            _logger.Info($"AccountMigration -> GetProspectDetailsById Response={MaskEngine.MaskMessage(Newtonsoft.Json.JsonConvert.SerializeObject(prospectResponse))}");

            if (prospectResponse.ResponseHeader.StatusCode != default(int))
            {
                return new AccountMigrationResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = prospectResponse.ResponseHeader.ResponseId,
                        StatusCode = prospectResponse.ResponseHeader.StatusCode,
                        Message = prospectResponse.ResponseHeader.Message
                    },
                };
            }
            var account = _accountService.GetAccount(request.AccountIdentifier);

            var result = _accountMigrationService.AccountMigration(new Gd.Bos.RequestHandler.Core.Domain.Services.AccountMigration.AccountMigrationRequestDTO
            {
                RequestHeader = new Gd.Bos.Shared.Common.Contract.Message.Request.RequestHeader()
                {
                    RequestId = request.RequestHeader.RequestId
                },
                ProgramCode = request.ProgramCode,
                MigrationType = string.IsNullOrEmpty(request.MigrationType) ? DefaultMigrationType : request.MigrationType,
                SourceAccountId = prospectResponse.ProspectDetail.OriginalAccountToken,
                SourceAchRoutingNumber = GDBankABARoutingNumber,
                SourceAchAccountReference = prospectResponse.ProspectDetail.OriginalACHReference,
                TargetAccountId = request.AccountIdentifier,
                TargetAchRoutingNumber = account.RoutingNumber,
                TargetAchAccountReference = account.AccountNumber,
                TargetAccountStack = request.ProgramCode
            });

            _logger.Info($"AccountMigration -> AccountMigration Response={MaskEngine.MaskMessage(JsonConvert.SerializeObject(result))}");

            var response = new AccountMigrationResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = result.ResponseHeader.StatusCode,
                    SubStatusCode = result.ResponseHeader.SubStatusCode,
                    Message = result.ResponseHeader.Details
                },
                AccountMigrationId = result.AccountMigrationId
            };

            return response;
        }

        public OptOutAccountResponse OptOutByProspectId(OptOutAccountRequest request)
        {
            //call get prospectdetail by id to get card proxy
            var prospectResponse = GetProspectDetailsById(new GetProspectDetailsByIdRequest
            {
                ProgramCode = request.ProgramCode,
                ProspectIdentifier = request.ProspectIdentifier,
                RequestHeader = new RequestHeader { RequestId = request.RequestHeader.RequestId }
            });
            _logger.Info($"OptOutByProspectId -> GetProspectDetailsById Response={MaskEngine.MaskMessage(Newtonsoft.Json.JsonConvert.SerializeObject(prospectResponse))}");

            if (prospectResponse.ResponseHeader.StatusCode != default(int))
            {
                return new OptOutAccountResponse
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = prospectResponse.ResponseHeader.ResponseId,
                        StatusCode = prospectResponse.ResponseHeader.StatusCode,
                        Message = prospectResponse.ResponseHeader.Message
                    },
                };
            }

            //to setup isforceoptou flag, whether exists in gbos           
            bool isForceOptout = MappingOptOutByStatus(prospectResponse.ProspectDetail.ProspectStatus, prospectResponse.ProspectDetail.ProspectIdentifier);

            //call optout with card proxy
            var result = _prospectService.OptOutAccountByCardProxy(new Domain.Services.ProspectApi.OptOutAccountByCardProxyRequest
            {
                CardProxy = prospectResponse.ProspectDetail.CardProxy,
                IsForceOptOut = isForceOptout
            });

            if (result.ResponseHeader.StatusCode == default(int))
            {
                if (_lazyCache.Value == null)
                {
                    _logger.Info($"OptOutByProspectId->LazyCache.Value is Null");
                    return new OptOutAccountResponse
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = request.RequestHeader.RequestId,
                            StatusCode = result.ResponseHeader.StatusCode,
                            Message = result.ResponseHeader.StatusMessage
                        }
                    };
                }

                ResetCacheForGetProspectDetails(prospectResponse.ProspectDetail);
            }
            _logger.Info($"OptOutByProspectId -> OptOutAccountByCardProxy Response={MaskEngine.MaskMessage(Newtonsoft.Json.JsonConvert.SerializeObject(result))}");

            var response = new OptOutAccountResponse
            {
                ResponseHeader = new ResponseHeader
                {
                    ResponseId = request.RequestHeader.RequestId,
                    StatusCode = result.ResponseHeader.StatusCode,
                    Message = result.ResponseHeader.StatusMessage
                },
            };

            return response;
        }

        public GetAccountMigrationItemConfirmationResponseDTO GetAccountMigrationItemConfirmation(GetAccountMigrationItemConfirmationRequestDTO request)
        {
            //call get prospectdetail by id to get legacy AccountKey
            var prospectResponse = GetProspectDetailsById(new GetProspectDetailsByIdRequest
            {
                ProgramCode = request.ProgramCode,
                ProspectIdentifier = request.ProspectId,
                RequestHeader = new RequestHeader { RequestId = request.RequestHeader.RequestId }
            });
            _logger.Info($"GetAccountMigrationItemConfirmation -> GetProspectDetailsById Response={MaskEngine.MaskMessage(Newtonsoft.Json.JsonConvert.SerializeObject(prospectResponse))}");

            if (prospectResponse.ResponseHeader.StatusCode != default(int))
            {
                return new GetAccountMigrationItemConfirmationResponseDTO
                {
                    ResponseHeader = new ResponseHeader
                    {
                        ResponseId = prospectResponse.ResponseHeader.ResponseId,
                        StatusCode = prospectResponse.ResponseHeader.StatusCode,
                        Message = prospectResponse.ResponseHeader.Message,
                        Details = prospectResponse.ResponseHeader.Details,
                    },
                };
            }

            //call gss GetAccountMigrationItemConfirmation
            try
            {
                //for uber2.0:SampleType.LegacyMigrateToGBOS
                var migrationType = DefaultMigrationType;
                if ((SampleType)prospectResponse.ProspectDetail.SampleType == SampleType.LegacyMigrateToGBOS)
                    migrationType = "LegacyToBaaS";

                var response = _accountMigrationService.GetAccountMigrationItemConfirmation(migrationType, prospectResponse.ProspectDetail.OriginalAccountToken);
                _logger.Info($"GetAccountMigrationItemConfirmation -> GetAccountMigrationItemConfirmation Response={MaskEngine.MaskMessage(Newtonsoft.Json.JsonConvert.SerializeObject(response))}");

                if (response == null)
                {
                    throw new ValidationException(601, 0, $"AccountMigrationItemConfirmation is not found for {prospectResponse.ProspectDetail.OriginalAccountToken}");
                }

                if (response.ResponseHeader.StatusCode != 200)
                {
                    return new GetAccountMigrationItemConfirmationResponseDTO
                    {
                        ResponseHeader = new ResponseHeader
                        {
                            ResponseId = response.ResponseHeader.ResponseId,
                            StatusCode = response.ResponseHeader.StatusCode,
                            Message = response.ResponseHeader.Message,
                            Details = prospectResponse.ResponseHeader.Details,
                        },
                    };
                }

                return response;
            }
            catch (Exception e)
            {
                throw new Exception($"GetAccountMigrationItemConfirmation for {prospectResponse.ProspectDetail.OriginalAccountToken} failed.", e);
            }
        }

        private static ProspectType MapSampleTypeKeyToProspectType(int? sampleTypeKey)
        {
            ProspectType result;
            switch (sampleTypeKey)
            {
                case 1:
                    result = ProspectType.WinBack;
                    break;
                case 2:
                    result = ProspectType.DirectMail;
                    break;
                case 3:
                    result = ProspectType.DDA;
                    break;
                case 4:
                    result = ProspectType.TsysMigrateToLegacy;
                    break;
                case 5:
                    result = ProspectType.TsysMigrateToGBOS;
                    break;
                case 6:
                    result = ProspectType.LegacyMigrateToGbos;
                    break;
                case 7:
                    result = ProspectType.AciWinback;
                    break;
                case 8:
                    result = ProspectType.AciDirectMail;
                    break;
                default:
                    throw new ValidationException(4, 302, $"Identification Failed. Invalid prospect type key:{sampleTypeKey} is returned from prospect api.");
            }
            return result;
        }

        private bool IsValidBin(string programCode, string pan)
        {
            var bins = _paymentIdentifierRepository.GetAllBins();

            var bin = bins.FirstOrDefault(s => pan.StartsWith(s, StringComparison.InvariantCultureIgnoreCase));
            return !string.IsNullOrEmpty(bin) && _productService.IsValidProductBin(programCode, bin);
            // var bin =  pan.Substring(0, 6);
        }

        private string GetCBSCardStockIfACILive(string productCode, string cardStock, bool isEmv)
        {
            if (string.IsNullOrWhiteSpace(productCode))
                return cardStock;

            var productInfo = _productService.GetByProductCode(productCode);
            _logger.Info($"Product information: originalcardStock: {cardStock}, Processor: {productInfo?.ProcessorKey}");
            var cbsCardStock = string.Empty;
            if (productInfo != null && cardStock != null && cardStock.Length == 3
                &&
                (productInfo.ProcessorKey == (int)SupportedProcessor.ACI || productInfo.ProcessorKey == (int)SupportedProcessor.CBS)
                )
            {
                _logger.Info($"Start to get cbs Card Stock: ProductCode {productInfo.ProductCode}, ProgramCode: {productInfo.ProgramCode.ToString()}, cardStock {cardStock}");
                cbsCardStock = _productService.GetCbsCardStockByCardStock(productInfo.ProductCode.ToString(), productInfo.ProgramCode.ToString(), cardStock, isEmv);
            }

            _logger.Info($"Run GetCBSCardStockIfACILive in SampleCardService, productCode: {productCode}, originalcardStock: {cardStock}, cbsCardStock: {cbsCardStock}");

            return string.IsNullOrWhiteSpace(cbsCardStock) ? cardStock : cbsCardStock;
        }

    }
}
