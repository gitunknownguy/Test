﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Cassandra;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Caching;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Org.BouncyCastle.Asn1.Cms;
using Configuration = Gd.Bos.RequestHandler.Core.Infrastructure.Configuration.Configuration;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    partial class AccountRepository
    {
        public void DeCache(List<string> cacheKeys)
        {
            cacheKeys.ForEach(key => _lazyCache.Value.RemoveAsync(key));
        }

        public List<AccountLink> GetLinkedAccountsCached(AccountIdentifier accountIdentifier)
        {
            var cacheKey = "getLinkedAccounts_" + accountIdentifier;
            var cacheTtl = new TimeSpan(0, 0, Configuration.Configuration.Current.RepositoryCacheTtlMs / 1000, 0);
            var result = new List<AccountLink>();

            var cacheConfig = OptionsContext.Current.GetString("X-GD-Cache-Control");
            var programCode = OptionsContext.Current.GetString("programCode");

            if (_baasConfiguration.IsRepositoryCacheAllowed(programCode))
            {
                if (string.IsNullOrEmpty(cacheConfig) || !cacheConfig.Equals("no-cache", StringComparison.InvariantCultureIgnoreCase))
                {
                    result = _lazyCache.Get(cacheKey, cacheTtl,
                        () => GetLinkedAccountsMiddleware(accountIdentifier));
                    return result;
                }
            }

            result = GetLinkedAccounts(accountIdentifier);

            if (_baasConfiguration.IsRepositoryCacheAllowed(programCode))
            {
                Logger.Info("Starting caching on no-cache headers");
                _lazyCache.Value.Set(cacheKey, result, cacheTtl);
                Logger.Info("Finished caching on no-cache headers");
            }

            return result;
        }

        private List<AccountLink> GetLinkedAccountsMiddleware(AccountIdentifier accountIdentifier)
        {
            Logger.Info("Cache missed now calling db");
            return GetLinkedAccounts(accountIdentifier);
        }
    }
}
