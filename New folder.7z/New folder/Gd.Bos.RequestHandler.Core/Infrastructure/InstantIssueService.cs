﻿using System;
using System.Collections.Generic;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Services.AsyncCommandService;
using Gd.Bos.RequestHandler.Core.Domain.Services.Dcpp;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.CBSProcessorManager.Contract.Enums;
using Gd.Bos.Shared.Common.CBSProcessorManager.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Common.Data;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using RequestHandler.Core.Application;
using RequestHandler.Core.Application.AsyncCommandHandlers;
using RequestHandler.Core.Domain.Model.Inventory;
using RequestHandler.Core.Domain.Services.AciRetailApi;
using RequestHandler.Core.Domain.Services.CPM;
using RequestHandler.Core.Domain.Services.Risk;
using AccountStatus = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountStatus;
using RequestHeader = Gd.Bos.Shared.Common.Contract.Message.Request.RequestHeader;

namespace RequestHandler.Core.Infrastructure
{
    public class InstantIssueService : IInstantIssueService
    {
        private readonly ICpmService _cpmService;
        private readonly IInstantIssueCardInventoryRepository _instantIssueCardInventoryRepository;
        private readonly IAccountService _accountService;
        private readonly IPaymentIdentifierRepository _paymentIdentifierRepository;
        private readonly IAccountBalanceRepository _accountBalanceRepository;
        private readonly IProductService _productService;
        private readonly IAciRetailService _aciRetailService;
        private readonly IBaasConfiguration _baasConfiguration;
        private readonly IAsyncCommandService _asyncCommandService;
        private readonly IRequestHandlerSettings _requestHandlerSettings;
        private readonly IDcppService _dcppService;
        private readonly IGssFraudEventTransferService _gssFraudEventTransferService;

        public InstantIssueService(
            ICpmService cpmService,
            IInstantIssueCardInventoryRepository instantIssueCardInventoryRepository,
            IAccountService accountService,
            IPaymentIdentifierRepository paymentIdentifierRepository,
            IAccountBalanceRepository accountBalanceRepository,
            IProductService productService,
            IAciRetailService aciRetailService,
            IBaasConfiguration baasConfiguration,
            IAsyncCommandService asyncCommandService,
            IRequestHandlerSettings requestHandlerSettings,
            IDcppService dcppService,
            IGssFraudEventTransferService gssFraudEventTransferService
            )
        {
            _cpmService = cpmService;
            _instantIssueCardInventoryRepository = instantIssueCardInventoryRepository;
            _accountService = accountService;
            _paymentIdentifierRepository = paymentIdentifierRepository;
            _accountBalanceRepository = accountBalanceRepository;
            _productService = productService;
            _aciRetailService = aciRetailService;
            _baasConfiguration = baasConfiguration;
            _asyncCommandService = asyncCommandService;
            _requestHandlerSettings = requestHandlerSettings;
            _dcppService = dcppService;
            _gssFraudEventTransferService = gssFraudEventTransferService;
        }

        public Tuple<PaymentIdentifier, AccountBalance, PrivateCardData, RegisterCardResponse> RegisterInstantIssueCard(Guid requestId, string programCode, string productCode, string accountIdentifier,
            string mappingIdentifier, string alternativePan, Account account, User user, ProductTierInfo productTier = null, string productMaterialType = null, bool isDelaySetBillCycle = false,string storeId=null,bool isEmployee =false)
        {
            PaymentIdentifier paymentIdentifier = null;
            AccountBalance accountBalance = null;
            PrivateCardData privateCardData = null;

            if (productTier == null)
                productTier = GetProductTierInfo(programCode, productCode);

            PaymentInstrumentType paymentInstrumentType = GetInstrumentType(productTier.ProductClassKey);
            var registerCardResponse = _cpmService.RegisterCard(
            requestId,
                    programCode,
                    productCode,
                    accountIdentifier,
                    alternativePan,
                    paymentInstrumentType,
                    productTier.Value,
                    account.AccountNumber,
                    account.RoutingNumber,
                    productMaterialType,storeId);
            account.AccountNumber = registerCardResponse.AccountNumber;
            account.RoutingNumber = registerCardResponse.RoutingNumber;

            _gssFraudEventTransferService.DemographicFeed(new DemographicFeedEventData(user,
                new DemographicFeedCardAccountDetail(
                    ProductCode: ProductCode.FromString(productCode), AccountIdentifier: accountIdentifier,
                    CurrentPan: registerCardResponse.Pan, RoutingNumber: registerCardResponse.RoutingNumber,
                    ActivatedDate: DateTime.UtcNow,
                    issuedDate: DateTime.UtcNow,
                    PaymentInstrumentIdentifier: PaymentInstrumentIdentifier.FromString(registerCardResponse.PaymentInstrumentIdentifier),
                    PaymentIdentifier: PaymentIdentifierIdentifier.FromString(registerCardResponse
                        .PaymentIdentifier))));

            if (isEmployee)
            {
                _cpmService.UpdateProduct(accountIdentifier, programCode, productTier.ProductTierKey, string.Empty);
            }

            // Update Package

            UpdatePackageStatusToSold(mappingIdentifier, requestId);

            AddInstantIssueCardToInventory(account.AccountIdentifier, mappingIdentifier);

            if (ThrowTestingException("X-GD-EXT-Throw-SetBillCycleException"))
            {
                throw new Exception($"Found header for Throwing an Exception when setting BillCycleDate");
            }

            //Set Bill Cycle
            if (!isDelaySetBillCycle)
            {
                if (_dcppService.IsRoutingToCPM(accountIdentifier))
                {
                    int billCycleDay = _accountService.SetBillCycleOnGbos(
                        OptionsContext.Current.GetGuid("requestId", Guid.NewGuid())
                        , accountIdentifier, programCode);
                    if (billCycleDay > 0)
                    {
                        _asyncCommandService.Send(new RetrySetBillCycle()
                        {
                            RequestHeader =
                                new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.RequestHeader()
                                {
                                    RequestId = OptionsContext.Current.GetGuid("requestId", Guid.NewGuid())
                                },
                            AccountIdentifier = accountIdentifier,
                            ProgramCode = programCode,
                            RetryId = Guid.NewGuid().ToString(),
                            WaitIntervalSeconds = _requestHandlerSettings.WaitIntervalSecondsForEnrollSetBcd,
                            RetryCount = 1, // odd why 1 ?
                            MaxRetryCount = _requestHandlerSettings.RetryEnrollMaxCount
                        });
                    }
                }
                else
                {
                    _accountService.SetBillCycle(
                        requestId: OptionsContext.Current.GetGuid("requestId", Guid.NewGuid()),
                        accountIdentifier: accountIdentifier,
                        programCode: programCode);
                }
            }

            if (programCode.Equals("credibly", StringComparison.OrdinalIgnoreCase))
                _paymentIdentifierRepository.UpdateAccountStatusAndStatusReason(account, AccountStatus.Pending, AccountStatusReason.businessProfileNotComplete, AccountStatusReason.ownerInfoNotComplete);
            else
                _paymentIdentifierRepository.UpdateAccountStatusAndStatusReason(account);

            //Return PaymentIdentifier Info

            paymentIdentifier =
                _paymentIdentifierRepository.GetPaymentIdentifierByPaymentIdentifierIdentifier(
                    PaymentIdentifierIdentifier.FromString(registerCardResponse.PaymentIdentifier));
            accountBalance =
                _accountBalanceRepository.GetAccountBalanceByAccountBalanceIdentifier(
                    AccountBalanceIdentifier.FromString(registerCardResponse.AccountBalanceIdentifier));

            return new Tuple<PaymentIdentifier, AccountBalance, PrivateCardData, RegisterCardResponse>(paymentIdentifier, accountBalance,
                privateCardData, registerCardResponse);
        }

        public ProductTierInfo GetProductTierInfo(string programCode, string productCode)
        {
            var productTierInfo = _productService.GetDefaultProductTierCardStockByProgramCodeProductCode(programCode, productCode);

            return productTierInfo;
        }

        public void UpdatePackageStatusToSold(string externalId, Guid requestId)
        {
            var updateStatus = _aciRetailService.UpdatePackageStatus(new UpdatePackageStatusRequest()
            {
                GdcExternalId = externalId,
                Status = AciStatusUpdatePackage,
                RequestHeader = new RequestHeader()
                {
                    RequestId = requestId
                }
            }).Result;
        }

        public string AddInstantIssueCardToInventory(Guid accountIdentifier, string mappingIdentifier)
        {
            return _instantIssueCardInventoryRepository.InsertInstantIssueCardInventory(accountIdentifier, mappingIdentifier);
        }

        public Guid? GetInstantIssueCardInventoryByMappingIdentifier(string mappingIdentifier)
        {
            return _instantIssueCardInventoryRepository.GetInstantIssueCardInventoryByMappingIdentifier(mappingIdentifier);
        }

        private PaymentInstrumentType GetInstrumentType(short productTierClassKey)
        {
            PaymentInstrumentType instrumentType;
            instrumentType = (PaymentInstrumentType)productTierClassKey;
            return instrumentType = (PaymentInstrumentType)productTierClassKey;
        }

        private bool ThrowTestingException(string headerName)
        {
            if (OptionsContext.Current.IsDefined(headerName))
            {
                return OptionsContext.Current.GetBoolean(headerName);
            }
            return false;
        }

        public const string AciStatusUpdatePackage = "Sold";
    }
}
