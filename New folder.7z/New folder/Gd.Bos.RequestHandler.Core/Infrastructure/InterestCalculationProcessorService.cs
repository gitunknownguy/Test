﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using NLog;
using RequestHandler.Core.Domain.Services.InterestCalculation;
using LogManager = NLog.LogManager;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class InterestCalculationProcessorService : IInterestCalculationProcessorService
    {
        private readonly IServiceInvokeProvider _serviceInvokeProvider;
        private readonly Logger _logger = LogManager.GetCurrentClassLogger();
        private readonly string _baseUrl;
        private const string _calculateInterestUrl = "/programs/{0}/accounts/{1}/purses/{2}/interest?startDate={3}&endDate={4}&tier={5}";

        public InterestCalculationProcessorService(IServiceInvokeProvider serviceInvokeProvider)
        {
            _serviceInvokeProvider = serviceInvokeProvider;
            _baseUrl = Configuration.Configuration.Current.InterestCalculationProcessorApiBaseUrl;
        }

        public async Task<GetInterestResult> CalculateInterestOnlineAsync(CalculateInterestRequest request)
        {
            _logger.Info("Calling Interest Calculation Processor service. Request: {Request}", request);

            var endpointUrl = _baseUrl +  string.Format(
                _calculateInterestUrl, 
                request.ProgramCode, 
                request.AccountIdentifier, 
                request.PurseIdentifier,
                request.StartDate,
                request.EndDate,
                request.Tier);

            try
            {
                var result = await _serviceInvokeProvider.GetResponseAsync<GetInterestResult>(endpointUrl, "GET", null, null);
                return result;
            }
            catch (System.Exception e)
            {
                _logger.Error(e, "Error calling Interest Calculation Processor service. Request: {Request} Error message: {ErrorMessage}", request, e.Message);
                throw;
            }

            
        }

    }
}
