﻿#nullable enable
using Gd.Bos.RequestHandler.Core.Domain.Model.Interest;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.Data;
using Microsoft.Data.SqlClient;
using NLog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Gd.Bos.Shared.Common.Caching;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.RequestHandler.Core.Utils;
using RequestHandler.Core.Domain.Model.Interest;
using PurseType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.PurseType;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    [ExcludeFromCodeCoverage(Justification = "mainly handles infrastructure operations and external dependencies")]
    public class AsyncInterestRateRepository : IAsyncInterestRateRepository
    {
        private readonly IDataAccess _dataAccess;
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();
        private readonly string _userName = IdentityHelper.GetIdentityName();
        private readonly ILazyCache _lazyCache;

        public AsyncInterestRateRepository(IDataAccess dataAccess, ILazyCache lazyCache)
        {
            _dataAccess = dataAccess;
            _lazyCache = lazyCache;
        }

        public void AddNewInterestTierForProduct(ProgramInterestTier productInterestTier)
        {
            throw new NotImplementedException();
        }

        public void AddNewProgramInterestTier(ProgramInterestTierV2 programInterestTier)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<AccountBalanceInterest>> GetAccountBalanceInterests(string accountIdentifier)
        {
            var accountBalanceInterests = new List<AccountBalanceInterest>();
            try
            {
                var parameters = new SqlParameter
                {
                    ParameterName = "AccountIdentifier",
                    Value = accountIdentifier
                };

                using var connection = _dataAccess.CreateConnection();
                using (var reader = await _dataAccess
                    .ExecuteReaderAsync("[dbo].[GetAccountBalanceInterestByAccountIdentifier]", CommandType.StoredProcedure, connection, default, parameters))
                {
                    while (await reader.ReadAsync())
                    {
                        accountBalanceInterests.Add(new AccountBalanceInterest()
                        {
                            AccountBalanceInterestKey = Cast<long>(reader["AccountBalanceInterestKey"]),
                            APY = Cast<decimal>(reader["APY"]),
                            InterestRate = Cast<decimal>(reader["InterestRate"]),
                            InterestRateTierKey = Cast<short>(reader["InterestTierKey"]),
                            AccountBalanceIdentifier = reader["AccountBalanceIdentifier"].ToString(),
                            InterestYieldStartDate = Cast<DateTime>(reader["InterestYieldStartDate"]),
                            InterestYieldEndDate = Cast<DateTime?>(reader["InterestYieldEndDate"]),
                            AccountBalanceInterestIdentifier = Cast<Guid>(reader["AccountBalanceInterestIdentifier"]),
                            ProductInterestTierKey = Cast<long>(reader["ProductInterestTierKey"]),
                            IsActive = Cast(reader["IsActive"], true)
                        });
                    }
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(
                    $"InterestRateRepository.GetAccountBalanceInterests, error occurred. ProductKey: {accountIdentifier} : {ex}");
                throw;
            }

            return accountBalanceInterests;
        }

        public List<AccountBalanceInterestSnapshot> GetAccountBalanceInterestSnapshots(long accountKey, DateTime? startDate, DateTime? endDate)
        {
            throw new NotImplementedException();
        }

        public AccountInterestConfig? GetAccountInterestConfig(long accountKey)
        {
            throw new NotImplementedException();
        }

        public AccountBalanceInterest GetActiveTier(IEnumerable<AccountBalanceInterest> accountBalanceInterests)
        {
            foreach (var accountBalanceInterest in accountBalanceInterests)
            {
                if (!accountBalanceInterest.IsActive)
                    continue;
                if (accountBalanceInterest.InterestYieldEndDate == null &&
                    accountBalanceInterest.InterestYieldStartDate <= DateTime.Now.Date)
                    return accountBalanceInterest;

                DateTime endDate = accountBalanceInterest.InterestYieldEndDate ?? DateTime.Now.Date;
                if (accountBalanceInterest.InterestYieldStartDate <= DateTime.Now.Date && DateTime.Now.Date <= endDate)
                    return accountBalanceInterest;
            }

            return null;
        }

        public ProductInterestTier GetProductInterestTierByProductKey(int productKey, short interestTierKey, AccountBalanceType accountBalanceType)
        {
            throw new NotImplementedException();
        }

        public List<ProductInterestTier> GetProductInterestTierByProductKey(int productKey)
        {
            throw new NotImplementedException();
        }

        public async Task<ProductInterestTierMetaData> GetProductInterestTierInfoByProgramCode(string programCode)
        {
            try
            {
                var productInterestInfo = new ProductInterestTierMetaData();
                productInterestInfo.Tiers = new List<Tier>();
                productInterestInfo.Frequencies = new List<TierFrequency>();
                productInterestInfo.PurseTypes = new List<global::RequestHandler.Core.Domain.Model.Interest.PurseType>();
                productInterestInfo.MaxAccountInterestTypes = new List<MaxAccountInterestType>();
                productInterestInfo.Products = new List<Product>();

                var parameters = new SqlParameter
                {
                    ParameterName = "programCode",
                    Value = programCode,
                    SqlDbType = SqlDbType.NVarChar,
                };

                using var connection = _dataAccess.CreateConnection();
                using (var reader = await _dataAccess
                    .ExecuteReaderAsync("[dbo].[GetProductInterestTierInfoByProgramCode]", CommandType.StoredProcedure, connection, default, parameters))
                {
                    while (await reader.ReadAsync())
                    {
                        productInterestInfo.Tiers.Add(new Tier
                        {
                            Key = Cast<short>(reader["InterestTierKey"]),
                            Name = Cast<string>(reader["InterestTierName"])
                        });
                    }
                    await reader.NextResultAsync();
                    while (await reader.ReadAsync())
                    {
                        productInterestInfo.PurseTypes.Add(new global::RequestHandler.Core.Domain.Model.Interest.PurseType
                        {
                            Key = Cast<short>(reader["AccountBalanceTypeKey"]),
                            Name = Cast<string>(reader["AccountBalanceTypeName"])
                        });
                    }
                    await reader.NextResultAsync();
                    while (await reader.ReadAsync())
                    {
                        productInterestInfo.Frequencies.Add(new TierFrequency()
                        {
                            Key = Cast<short>(reader["FrequencyKey"]),
                            Name = Cast<string>(reader["FrequencyName"])
                        });
                    }
                    await reader.NextResultAsync();
                    while (await reader.ReadAsync())
                    {
                        productInterestInfo.MaxAccountInterestTypes.Add(new MaxAccountInterestType
                        {
                            Key = Cast<short>(reader["MaxAccountInterestTypeKey"]),
                            Name = Cast<string>(reader["MaxAccountInterestTypeName"])
                        });
                    }
                    await reader.NextResultAsync();
                    while (await reader.ReadAsync())
                    {
                        productInterestInfo.Products.Add(new Product
                        {
                            Key = Cast<int>(reader["ProductKey"]),
                            Code = Cast<string>(reader["ProductCode"]),
                            Name = Cast<string>(reader["ProductName"])
                        });
                    }
                }

                return productInterestInfo;


            }
            catch (Exception ex)
            {
                Logger.Error(
                    $"InterestRateRepository.GetProductInterestTierInfoByProgramCode, error occurred. ProgramCode: {programCode} : {ex}");
                throw;
            }
        }

        public List<ProgramInterestTier> GetProgramInterestTiers(string programCode)
        {
            throw new NotImplementedException();
        }

        public ProgramInterestTierV2? GetProgramInterestTiersByProgramCode(string programCode)
        {
            throw new NotImplementedException();
        }

        public List<ProgramInterestTierHistory?> GetProgramInterestTiersHistoryByProgramCode(string programCode)
        {
            throw new NotImplementedException();
        }

        public void InsAccountBalanceInterest(Guid accountBalanceInterestIdentifier, long accountBalanceKey, long productInterestTierKey, DateTime interestYieldStartDate)
        {
            throw new NotImplementedException();
        }

        public void InsertAccountInterestConfig(AccountInterestConfig config)
        {
            throw new NotImplementedException();
        }

        public void UpdAccountBalanceInterest(AccountBalanceInterest accountBalanceInterest)
        {
            throw new NotImplementedException();
        }

        public void UpdateAccountInterestConfig(AccountInterestConfig config)
        {
            throw new NotImplementedException();
        }

        public void UpdateProductInterestTier(ProgramInterestTier productInterestTier)
        {
            throw new NotImplementedException();
        }

        public void UpdateProgramInterestTier(ProgramInterestTierV2 programInterestTier)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Cast can provide better performance than ConvertTo if you are sure about the data type.
        /// </summary>
        /// <typeparam name="T">Type to cast to</typeparam>
        /// <param name="value">Value to cast</param>
        /// <param name="defaultValue"></param>
        /// <returns></returns>
        private static T Cast<T>(object value, T defaultValue = default(T))
        {
            if (value == DBNull.Value || value == null)
                return defaultValue;

            return (T)value;
        }
    }
}
