﻿using Gd.Bos.Shared.Common.Core.Contract.Interface;
using RequestHandler.Core.Domain.Services.CNAPI;
using RequestHandler.Core.Domain.Services.CNAPI.Messages.Request;
using RequestHandler.Core.Domain.Services.CNAPI.Messages.Response;
using RequestHandler.Core.Application.Exception;
using Gd.Bos.Shared.Common.UtilityCoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.UtilityCoreApi.Contract.Message.Request;
using NLog;
using System;
using NLog.Fluent;

namespace RequestHandler.Core.Infrastructure
{
    public class CNAPIService : ICNAPIService
    {
        private readonly IServiceInvokeProvider _serviceInvokerProvider;
        private const string CNAPITransferUrl = "/Notification/Transfer";
        private const string CNAPIEnrollUrl = "/Notification/Enroll";
        private const string CNAPIContactUpdateUrl = "/Notification/UpdateCustomerContact";
        private readonly string _cnapiUrl;
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        public CNAPIService(IServiceInvokeProvider serviceInvokeProvider)
        {
            _serviceInvokerProvider = serviceInvokeProvider;
            _cnapiUrl = Gd.Bos.RequestHandler.Core.Infrastructure.Configuration.Configuration.Current.CNAPIUrl;

        }
        public CNAPITransferResponse Transfer(CNAPITransferRequest request)
        {
            var transferResponse = _serviceInvokerProvider.GetResponseAsync<CNAPITransferRequest, CNAPITransferResponse>(
                _cnapiUrl + CNAPITransferUrl, "POST", request, null).Result;

            if (transferResponse == null)
                throw new CNAPIServiceNoResponseException();

            return transferResponse;
        }

        public CreateNotificationEnrollmentResponse EnrollNotification(CreateNotificationEnrollmentRequest request)
        {
            var enrollResponse = _serviceInvokerProvider.GetResponseAsync<CreateNotificationEnrollmentRequest, 
                CreateNotificationEnrollmentResponse>(_cnapiUrl + CNAPIEnrollUrl, "POST", request, null).Result;

            if (enrollResponse == null)
                throw new CNAPIServiceNoResponseException();

            return enrollResponse;
        }

        public CNApiContactUpdateResponse UpdateContact(CNApiContactUpdateRequest request)
        {
            Logger.Info($"Request {request.Header.RequestId}: Start to call Update Contract- url:{_cnapiUrl + CNAPIContactUpdateUrl} ");
            var contactUpdateResponse = _serviceInvokerProvider.GetResponseAsync<CNApiContactUpdateRequest,
                CNApiContactUpdateResponse>(_cnapiUrl + CNAPIContactUpdateUrl, "POST", request, null).Result;

            if (contactUpdateResponse == null)
                throw new CNAPIServiceNoResponseException();
            Logger.Info($"Request {request.Header.RequestId}-CN Api contract update response: Status :{contactUpdateResponse.Header.StatusCode}, Message: {contactUpdateResponse.Header.StatusMessage}");
            return contactUpdateResponse;
        }
    }
}
