﻿using Gd.Bos.Shared.Common.Messaging.ProcessorEventSchema.Translation.Model;
using RequestHandler.Core.Domain.Model.CurrecyCode;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace RequestHandler.Core.Infrastructure
{
    public class CurrencyCodeProvider : ICurrencyCodeProvider
    {
        private readonly ICurrencyCodeRepository _currencyCodeRepository;

        public CurrencyCodeProvider(ICurrencyCodeRepository currencyCodeRepository)
        {
            _currencyCodeRepository = currencyCodeRepository;
        }

        public CurrencyCode GetCurrencyCodeByNumericCode(string numericCurrencyCode)
        {
            if (string.IsNullOrEmpty(numericCurrencyCode))
            {
                return null;
            }

            int numCode = Convert.ToInt32(numericCurrencyCode);
            var currencyCodes = GetAll();
            return currencyCodes.Find(t => t.NumericCode == numCode);
        }

        private List<CurrencyCode> GetAll()
        {
            var programs = _currencyCodeRepository.GetAllCurrencyCodes();
            return programs;
        }
    }
}
