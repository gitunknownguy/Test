﻿using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.Shared.Common.Core.Logic;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.EGift;
using Gd.Bos.RequestHandler.Core.Domain.Model.Ift;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Model.ProgramFunding;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transactions;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers.Events;
using Gd.Bos.RequestHandler.Core.Domain.Services.Ach;
using Gd.Bos.RequestHandler.Core.Domain.Services.Dcpp;
using Gd.Bos.RequestHandler.Core.Domain.Services.EGift;
using Gd.Bos.RequestHandler.Core.Domain.Services.IFT;
using Gd.Bos.RequestHandler.Core.Domain.Services.Mrdc;
using Gd.Bos.RequestHandler.Core.Domain.Services.PointsSystem;
using Gd.Bos.RequestHandler.Core.Utils;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Logic.FeatureLimitsFees.Contract;
using Newtonsoft.Json;
using NLog;
using TransClass = Gd.Bos.RequestHandler.Core.Domain.Model.Transfers.TransClass;
using Transfer = Gd.Bos.RequestHandler.Core.Domain.Model.Transfers.Transfer;
using EgiftPurchaseFeature = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.EgiftPurchaseFeature;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using SqlDataRecord = Microsoft.Data.SqlClient.Server.SqlDataRecord;
using SqlMetaData = Microsoft.Data.SqlClient.Server.SqlMetaData;
using Gd.Bos.Shared.Common;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using TransferType = Gd.Bos.RequestHandler.Core.Domain.Model.Transfers.TransferType;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Services.CareSharedApi;
using Gd.Bos.RequestHandler.Core.Domain.Services.LoanManagement;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.MRDC;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Org.BouncyCastle.Asn1.Crmf;
using RequestHandler.Core.Domain.Model.MrdcX9;
using RequestHandler.Core.Domain.Model.Transfers;
using BinType = Gd.Bos.RequestHandler.Core.Domain.Enums.BinType;
using Fee = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Fee;
using FundTransfer = Gd.Bos.RequestHandler.Core.Domain.Model.Transfers.FundTransfer;
using FundTransferType = Gd.Bos.RequestHandler.Core.Domain.Model.Transfers.FundTransferType;
using TransferRoute = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.MRDC.TransferRoute;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration.ConfigurationModel;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    [ExcludeFromCodeCoverage(Justification = "Covered with functional tests")]
    public class TransferRepository : ITransferRepository
    {
        private readonly IRequestHandlerSettings _settings;
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        public TransferRepository(
            IDataAccess dataAccess,
            ILazyCache cache,
            IDcppService dcppService,
            IAchService achService,
            IMrdcService mrdcService,
            IAccountBalanceRepository accountBalanceRepository,
            IAccountRepository accountRepository,
            IProgramFundingRepository programFundingRepository,
            IRulesEngine rulesEngine,
            IRequestHandlerSettings settings,
            IProductRepository productRepository,
            ITransactionsRepository transactionsRepository,
            ITransClassService transClassService,
            ITransferDescriptionProvider transferDescriptionProvider,
            IExternalPaymentRepository externalPaymentRepository,
            IInstantFundTransferService instantFundTransferService,
            IPointsSystemService pointsSystemService,
            IBaasConfiguration baasConfiguration,
            IUserService userService,
            ILoanManagementService loanManagementService,
            IUserRepository userRepository,
                ICareSharedApiService careSharedApiService)
        {
            _dataAccess = dataAccess;
            _cache = cache;
            _transClasses = null;
            _dcppService = dcppService;
            _achService = achService;
            _mrdcService = mrdcService;
            _accountBalanceRepository = accountBalanceRepository;
            _accountRepository = accountRepository;
            _programFundingRepository = programFundingRepository;
            _rulesEngine = rulesEngine;
            _configuration = settings;
            _settings = settings;
            _productRepository = productRepository;
            _transactionsRepository = transactionsRepository;
            _transClassService = transClassService;
            _transferDescriptionProvider = transferDescriptionProvider;
            _externalPaymentRepository = externalPaymentRepository;
            _instantFundTransferService = instantFundTransferService;
            _pointsSystemService = pointsSystemService;
            _baasConfiguration = baasConfiguration;
            _userService = userService;
            _loanManagementService = loanManagementService;
            _userRepository = userRepository;
            _careSharedApiService = careSharedApiService;
        }

        public void Add(Transfer transfer)
        {
            var parameters = new List<SqlParameter>{
                new SqlParameter() { ParameterName = "ChangeBy", Value = _userName, SqlDbType = SqlDbType.NVarChar, Size = 100 },
                new SqlParameter() { ParameterName = "InitiatorAccountIdentifier", Value = transfer.InitiatorAccountIdentifier.ToGuid(), SqlDbType = SqlDbType.UniqueIdentifier },
                new SqlParameter() { ParameterName = "FundTransferToken", Value = transfer.TransferIdentifier.ToGuid(), SqlDbType = SqlDbType.UniqueIdentifier },
                new SqlParameter() { ParameterName = "FundTransferTypeKey", Value = (short)transfer.TransferType, SqlDbType = SqlDbType.SmallInt },
                new SqlParameter() { ParameterName = "FundTransferStatusKey", Value = (short)transfer.TransferStatus, SqlDbType = SqlDbType.SmallInt },
                new SqlParameter() { ParameterName = "FundTransferStatusReasonKey", Value = transfer.TransferStatusReason == TransferStatusReason.None ? null : (short?)transfer.TransferStatusReason, SqlDbType = SqlDbType.SmallInt },
                new SqlParameter() { ParameterName = "CurrencyKey", Value = (short)transfer.Currency, SqlDbType = SqlDbType.SmallInt },
                new SqlParameter() { ParameterName = "FundTransferDelayTypeKey", Value = (short)transfer.FundTransferDelayType, SqlDbType = SqlDbType.SmallInt },
                new SqlParameter() { ParameterName = "TransactionAmount", Value = transfer.Amount, SqlDbType = SqlDbType.Money },
                new SqlParameter() { ParameterName = "TransactionDate", Value = DateTime.Now, SqlDbType = SqlDbType.DateTime },
                new SqlParameter() { ParameterName = "TransactionDetail", Value = transfer.Description, SqlDbType = SqlDbType.NVarChar, Size = 500 },
                new SqlParameter() { ParameterName = "TypeFundTransferDetail", Value = CreateDetailRows((dynamic)transfer), SqlDbType = SqlDbType.Structured, TypeName = "dbo.typeFundTransferDetailV2" },
                new SqlParameter() { ParameterName = "IsSystemInitiated", Value = transfer.IsSystemGenerated, SqlDbType = SqlDbType.Bit},
                new SqlParameter() { ParameterName = "InitiatedSystemKey", Value = transfer.SourceSystemType, SqlDbType = SqlDbType.SmallInt},
            };

            #region setup handle and memo
            if (transfer.Source is AccountTransferLeg sourceAccLeg && !string.IsNullOrEmpty(sourceAccLeg.AccountTransferEndpoint.ExternalHandle))
            {
                parameters.Add(new SqlParameter()
                { ParameterName = "SourceHandle", Value = sourceAccLeg.AccountTransferEndpoint.ExternalHandle, SqlDbType = SqlDbType.NVarChar, Size = 225 });
            }
            else if (transfer.Source is HandleTransferLeg sourceHndlLeg && !string.IsNullOrEmpty(sourceHndlLeg.HandleTransferEndpoint?.Handle))
            {
                parameters.Add(new SqlParameter()
                { ParameterName = "SourceHandle", Value = sourceHndlLeg.HandleTransferEndpoint.Handle, SqlDbType = SqlDbType.NVarChar, Size = 225 });
            }

            if (transfer.Target is AccountTransferLeg targetAccLeg && !string.IsNullOrEmpty(targetAccLeg.AccountTransferEndpoint.ExternalHandle))
            {
                parameters.Add(new SqlParameter()
                { ParameterName = "TargetHandle", Value = targetAccLeg.AccountTransferEndpoint.ExternalHandle, SqlDbType = SqlDbType.NVarChar, Size = 225 });
            }
            else if (transfer.Target is HandleTransferLeg targetHndlLeg && !string.IsNullOrEmpty(targetHndlLeg.HandleTransferEndpoint?.Handle))
            {
                parameters.Add(new SqlParameter()
                { ParameterName = "TargetHandle", Value = targetHndlLeg.HandleTransferEndpoint.Handle, SqlDbType = SqlDbType.NVarChar, Size = 225 });
            }

            if (!string.IsNullOrEmpty(transfer.Memo))
            {
                parameters.Add(new SqlParameter()
                { ParameterName = "Memo", Value = transfer.Memo, SqlDbType = SqlDbType.NVarChar, Size = 150 });
            }
            #endregion

            using (var reader = _dataAccess.ExecuteReader("[dbo].[InsFundTransferV2]", _dataAccess.CreateConnection(), parameters.ToArray()))
            {
                bool fundTransferKeySet = false;

                while (reader.Read())
                {
                    if (!fundTransferKeySet)
                    {
                        transfer.FundTransferKey = reader.GetInt64(0);

                        fundTransferKeySet = true;
                    }

                    var trid = TransactionReferenceId.FromGuid(reader.GetGuid(2));

                    if (transfer.Source.TransactionReferenceId == trid)
                    {
                        transfer.Source.FundTransferDetailKey = reader.GetInt64(1);
                    }
                    else if (transfer.Target?.TransactionReferenceId == trid)
                    {
                        transfer.Target.FundTransferDetailKey = reader.GetInt64(1);
                    }
                    else
                    {
                        if (transfer is SccBalanceSweepTransfer sccTransfer)
                        {
                            var otherSource = sccTransfer.OtherSources.FirstOrDefault(s => s.TransactionReferenceId == trid);
                            if (otherSource != null)
                            {
                                otherSource.FundTransferDetailKey = reader.GetInt64(1);
                            }

                            var otherTarget = sccTransfer.OtherTargets.FirstOrDefault(s => s.TransactionReferenceId == trid);
                            if (otherTarget != null)
                            {
                                otherTarget.FundTransferDetailKey = reader.GetInt64(1);
                            }
                        }

                        if (transfer is SccFundingTransfer sccFundingTransfer)
                        {
                            if (sccFundingTransfer.Target2.TransactionReferenceId == trid)
                            {
                                sccFundingTransfer.Target2.FundTransferDetailKey = reader.GetInt64(1);
                                ((SccFundingTransferEndpoint)(sccFundingTransfer.Target2.TransferEndpoint)).SetFundTransferKey(transfer.FundTransferKey);
                            }
                        }

                        if (transfer is SccWithdrawalTransfer sccWithdrawalTransfer)
                        {
                            if (sccWithdrawalTransfer.Source2?.TransactionReferenceId == trid)
                            {
                                sccWithdrawalTransfer.Source2.FundTransferDetailKey = reader.GetInt64(1);

                            }
                        }

                        if (transfer is WireOutTransfer wireOutTransfer)
                        {
                            if (wireOutTransfer.Fee != null && wireOutTransfer.Fee.TransactionReferenceId == trid)
                            {
                                wireOutTransfer.Fee.FundTransferDetailKey = reader.GetInt64(1);
                            }
                        }

                        if (transfer is IftTransfer iftTransfer)
                        {
                            if (iftTransfer.TargetFee != null && iftTransfer.TargetFee.TransactionReferenceId == trid)
                            {
                                iftTransfer.TargetFee.FundTransferDetailKey = reader.GetInt64(1);
                            }
                        }

                        if (transfer is MrdcPartialTransfer mrdcPartialTransfer)
                        {
                            var target =
                                mrdcPartialTransfer.SubTargets.FirstOrDefault(p => p.TransactionReferenceId == trid);
                            if (target != null)
                            {
                                target.FundTransferDetailKey = reader.GetInt64(1);
                            }
                        }
                    }

                    //TODO: separate this for egift transfers..
                    if (transfer is EGiftTransfer egiftTransfer)
                    {
                        var egiftPurchaseLeg = transfer.Target as EGiftPurchase;
                        egiftPurchaseLeg.CreateDate = reader.GetDateTime(3);

                        if (egiftTransfer.Source2?.TransactionReferenceId == trid)
                        {
                            egiftTransfer.Source2.FundTransferDetailKey = reader.GetInt64(1);
                        }
                        else if (egiftTransfer.Target2?.TransactionReferenceId == trid)
                        {
                            egiftTransfer.Target2.FundTransferDetailKey = reader.GetInt64(1);
                        }
                    }
                }
            }

            if (transfer.FundTransferKey > 0 && transfer.deviceDetails != null && (!string.IsNullOrWhiteSpace(transfer.deviceDetails.DeviceType) || !string.IsNullOrWhiteSpace(transfer.deviceDetails.IpAddress) || !string.IsNullOrWhiteSpace(transfer.deviceDetails.IovationDeviceToken)))
            {
                try
                {
                    object realIpStr = string.Empty;
                    if (transfer.FraudData != null)
                    {
                        transfer.FraudData.TryGetValue("RealIPAddress", out realIpStr);
                    }

                    var deviceDetailParams = new List<SqlParameter>{
                        new SqlParameter() { ParameterName = "ChangeBy", Value = _userName, SqlDbType = SqlDbType.NVarChar, Size = 100 },
                        new SqlParameter() { ParameterName = "FundTransferKey", Value = transfer.FundTransferKey, SqlDbType = SqlDbType.BigInt },
                        new SqlParameter() { ParameterName = "IovationDeviceToken", Value = transfer.deviceDetails.IovationDeviceToken, SqlDbType = SqlDbType.NVarChar, Size = 50 },
                        new SqlParameter() { ParameterName = "UMDeviceType", Value = transfer.deviceDetails.DeviceType, SqlDbType = SqlDbType.NVarChar, Size = 50 },
                        new SqlParameter() { ParameterName = "IPAddress", Value = transfer.deviceDetails.IpAddress, SqlDbType = SqlDbType.NVarChar, Size = 50 },
                        new SqlParameter() { ParameterName = "RealIPAddress", Value = realIpStr, SqlDbType = SqlDbType.NVarChar, Size = 50}
                    };
                    using (var reader = _dataAccess.ExecuteReader("[dbo].[InsFundTransferExtension]", _dataAccess.CreateConnection(), deviceDetailParams.ToArray()))
                    {
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error(ex, $"Error occured saving the device Details for Fund Transfer, Initiator account: {transfer.InitiatorAccountIdentifier}: Error {ex.Message}");
                }
            }
        }

        public Transfer GetByTransferIdentifier(TransferIdentifier transferIdentifier, bool allowNegativeBalance, string programCode)
        {
            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "FundTransferToken", Value = transferIdentifier.ToGuid(), SqlDbType = SqlDbType.UniqueIdentifier }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetFundTransferByFundTransferToken]", _dataAccess.CreateConnection(), parameters))
            {
                return ReadTransfer(reader, allowNegativeBalance, programCode);
            }
        }

        public List<FundTransferDetails> GetFundTransferDetailsByTransferIdentifier(TransferIdentifier transferIdentifier)
        {
            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "FundTransferToken", Value = transferIdentifier.ToGuid(), SqlDbType = SqlDbType.UniqueIdentifier }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetFundTransferByFundTransferToken]", _dataAccess.CreateConnection(), parameters))
            {
                return ReadFundTransferDetails(reader);
            }
        }

        public Transfer GetByTransactionReferenceId(TransactionReferenceId transactionReferenceId, string programCode)
        {
            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "TransactionReferenceId", Value = transactionReferenceId.ToGuid(), SqlDbType = SqlDbType.UniqueIdentifier }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetFundTransfer]", _dataAccess.CreateConnection(), parameters))
            {
                return ReadTransfer(reader, false, programCode);
            }
        }

        public Transfer GetByTransactionReferenceIdForMultiTargets(TransactionReferenceId transactionReferenceId, string partialTransactionReferenceId, string programCode, ref List<FundTransferDetail> fundTransferDetails)
        {
            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "FundTransferToken", Value = transactionReferenceId.ToGuid(), SqlDbType = SqlDbType.UniqueIdentifier }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetFundTransferByFundTransferToken]", _dataAccess.CreateConnection(), parameters))
            {
                return ReadTransfer(reader, false, programCode, fundTransferDetails, partialTransactionReferenceId);
            }
        }

        public bool TransferExists(TransferIdentifier transferIdentifier)
        {
            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "FundTransferToken", Value = transferIdentifier.ToGuid(), SqlDbType = SqlDbType.UniqueIdentifier }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetFundTransferByFundTransferToken]", _dataAccess.CreateConnection(), parameters))
            {
                if (reader.Read())
                {
                    return true;
                }

                return false;
            }
        }


        public void Update(Transfer transfer)
        {
            foreach (dynamic currEvent in transfer.Events)
            {
                Update((dynamic)transfer, currEvent);
            }

            transfer.Events.Clear();
        }

        public void UpdateMrdcX9(long fundTransferDetailKey, TransferStatus transferDetailStatus)
        {
            UpdateFundTransferDetailByFundTransferDetailKey(fundTransferDetailKey, transferDetailStatus);
        }

        private void Update(Transfer transfer, TransferDetailReversing @event)
        {
            if (@event.TransferLeg.ReversalFundTransferDetailKey == 0)
            {
                var fundTransferDetailKey = InsertFundTransferDetail(transfer.FundTransferKey, CreateFundTransferDetailReversalRecord(@event.TransferLeg));
                @event.TransferLeg.ReversalFundTransferDetailKey = fundTransferDetailKey;
            }
        }

        private Transfer ReadTransfer(IDataReader reader, bool allowNegativeBalance, string programCode, List<FundTransferDetail> fundTransferDetails = null, string partialTransactionReferenceId = null)
        {
            Transfer transfer = null;

            TransferType transferType = TransferType.Adjustment;
            DateTime createDate = DateTime.MinValue;

            AccountIdentifier initiatorAccountIdentifier = null;
            decimal transferAmount = 0;

            if (reader.Read())
            {
                long fundTransferKey = reader.GetInt64(reader.GetOrdinal("FundTransferKey"));
                TransferIdentifier transferIdentifier = TransferIdentifier.FromGuid(reader.GetGuid(reader.GetOrdinal("FundTransferToken")));
                initiatorAccountIdentifier = AccountIdentifier.FromGuid(reader.GetGuid(reader.GetOrdinal("InitiatorAccountIdentifier")));
                transferType = (TransferType)reader.GetInt16(reader.GetOrdinal("FundTransferTypeKey"));
                decimal amount = Math.Round(reader.GetDecimal(reader.GetOrdinal("TransactionAmount")), 2);
                transferAmount = amount;
                DateTimeOffset? transactionDate = reader.GetDateTime(reader.GetOrdinal("TransactionDate"));
                Currency currency = (Currency)reader.GetInt16(reader.GetOrdinal("CurrencyKey"));
                string description = reader["TransactionDetail"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("TransactionDetail"));
                string memo = reader["Memo"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Memo"));
                TransferStatus transferStatus = (TransferStatus)reader.GetInt16(reader.GetOrdinal("FundTransferStatusKey"));
                TransferDelayType transferDelayType = (TransferDelayType)reader.GetInt16(reader.GetOrdinal("FundTransferDelayTypeKey"));
                createDate = (DateTime)reader.GetDateTime(reader.GetOrdinal("CreateDate"));
                SourceSystem sourceSystemType = reader["TransactionDetail"] == DBNull.Value ? SourceSystem.Partner : (SourceSystem)reader.GetInt16(reader.GetOrdinal("InitiatedSystemKey"));
                TransferStatusReason reason = reader["FundTransferStatusReasonKey"] == DBNull.Value
                    ? TransferStatusReason.None
                    : (TransferStatusReason)reader.GetInt16(reader.GetOrdinal("FundTransferStatusReasonKey"));




                transfer = CreateTransfer(
                    transferIdentifier,
                    initiatorAccountIdentifier,
                    transferType,
                    amount,
                    currency,
                    description,
                    memo,
                    transferDelayType,
                    transferStatus,
                    programCode);

                transfer.FundTransferKey = fundTransferKey;
                transfer.SubmissionDateTime = transactionDate;
                transfer.SourceSystemType = sourceSystemType;
                transfer.TransferStatusReason = reason;
            }

            bool checkVelocityLimits =
                transferType == TransferType.PeerPayment || transferType == TransferType.ECashSend;
            if (reader.NextResult())
            {
                while (reader.Read())
                {
                    string transactionDescription = reader["TransactionDescription"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("TransactionDescription"));
                    IdentifierType identifierType =
                        (IdentifierType)reader.GetInt16(reader.GetOrdinal("IdentifierTypeKey"));
                    bool isSource = reader.GetBoolean(reader.GetOrdinal("IsSource"));
                    TransferEndpointType transferEndpointType = TransferEndpointType.Account;
                    if (identifierType == IdentifierType.ExternalAccountNumberRoutingNumber)
                    {
                        if (transfer != null && (transfer.TransferType == TransferType.Mrdc))
                            transferEndpointType = TransferEndpointType.MrdcTransfer;
                        else
                            transferEndpointType = TransferEndpointType.Ach;
                    }

                    if (transfer.TransferType == TransferType.InternalTransfer)
                        transferEndpointType = TransferEndpointType.Purse;
                    if (transfer.TransferType == TransferType.BillPay)
                        transferEndpointType = TransferEndpointType.BillPay;
                    if (identifierType == IdentifierType.AccountIdentifier)
                        transferEndpointType = TransferEndpointType.Account;
                    if (identifierType == IdentifierType.AccountHolderIdentifier && transfer.TransferType == TransferType.BillPay)
                        transferEndpointType = TransferEndpointType.Account;
                    if (transfer.TransferType == TransferType.DisbursementIn && isSource)
                        transferEndpointType = TransferEndpointType.ProgramFunding;
                    if (transfer.TransferType == TransferType.DisbursementOut && !isSource)
                        transferEndpointType = TransferEndpointType.ProgramFunding;

                    if (identifierType == IdentifierType.FeatureTxnIdentifier)
                        transferEndpointType = TransferEndpointType.EGiftPoints;
                    if (identifierType == IdentifierType.EGiftAccountIdentifier)
                        transferEndpointType = TransferEndpointType.EGiftPurchase;
                    if (identifierType == IdentifierType.RetailSale)
                        transferEndpointType = TransferEndpointType.RetailSale;
                    if (identifierType == IdentifierType.AccountExternalPaymentIdentifier)
                        transferEndpointType = TransferEndpointType.IFT;
                    if (identifierType == IdentifierType.AccountBalanceIdentifier)
                        transferEndpointType = TransferEndpointType.Purse;
                    if (identifierType == IdentifierType.AccountBalanceIdentifier &&
                        (transfer.TransferType == TransferType.SccFunding || transfer.TransferType == TransferType.CreditLineIncrease))
                        transferEndpointType = TransferEndpointType.SCCFunding;
                    if (((transfer.TransferType == TransferType.SccWriteOffFullBalance
                          || transfer.TransferType == TransferType.SccWriteOffPartialBalance) && identifierType == IdentifierType.Adjustment))
                        transferEndpointType = TransferEndpointType.Adjustment;

                    if (transfer.TransferType == TransferType.WireOut && identifierType == IdentifierType.ExternalAccountNumberRoutingNumber)
                    {
                        transferEndpointType = TransferEndpointType.Wire;
                    }


                    var sccCreditLimitInCrease =
                        (transferType == TransferType.SccFunding || transferType == TransferType.CreditLineIncrease) &&
                        !isSource && identifierType == IdentifierType.AccountIdentifier;
                    var sccCreditLimitDecrease = (transferType == TransferType.CreditLineDecrease
                                                  || transferType == TransferType.SccWriteOffNegativeBalance
                                                  || transferType == TransferType.SccWriteOffOverCreditLimit
                                                  || transferType == TransferType.SccWriteOffPartialBalance
                                                  || transferType == TransferType.SccWriteOffFullBalance) &&
                                                 isSource && identifierType == IdentifierType.AccountIdentifier;

                    if (sccCreditLimitInCrease || sccCreditLimitDecrease)
                    {
                        transferEndpointType = TransferEndpointType.Empty;
                    }
                    if (transfer.TransferType == TransferType.IFTLoad && identifierType == IdentifierType.Adjustment)
                    {
                        transferEndpointType = TransferEndpointType.Empty;
                    }
                    if (transfer.TransferType == TransferType.SCCWriteOffNegativeBalanceOnly && isSource)
                    {
                        transferEndpointType = TransferEndpointType.Empty;
                    }

                    var holdingTrans = _transClassService.Get2WayTransactionTransClasses(transferType, !isSource);
                    TransClass holdingTransClass = holdingTrans.Item1;
                    TransClass holdingReversalTransClass = holdingTrans.Item2;

                    decimal amount = Math.Round(reader.GetDecimal(reader.GetOrdinal("DetailTransactionAmount")), 2);
                    string externalHandle = reader["ExternalIdentifier"] == DBNull.Value
                        ? null
                        : reader["ExternalIdentifier"].ToString();
                    string currencyCode = transfer.Currency.ToString();
                    TransClass transClass = GetTransClassByTransClassKey(reader.GetInt32(reader.GetOrdinal("TransClassKey")));
                    TransactionReferenceId transactionReferenceId =
                        TransactionReferenceId.FromGuid(reader.GetGuid(reader.GetOrdinal("TransactionReferenceId")));
                    bool? isReversal = reader["IsReversal"] == DBNull.Value ? transClass.IsReversal
                        : (bool?)reader.GetBoolean(reader.GetOrdinal("IsReversal"));

                    if (isReversal == true)
                    {
                        if (transfer.TransferType != TransferType.InitialLoad && transfer.TransferType != TransferType.SwipeReload)
                        {
                            var reversalLeg = transfer.GetLeg(isSource, transClass, identifierType);
                            reversalLeg.ReversalFundTransferDetailKey = Convert.ToInt64(reader["FundTransferDetailKey"]);
                            reversalLeg.ReversalStatus = (TransferStatus)reader.GetInt16(reader.GetOrdinal("DetailFundTransferStatusKey"));
                            reversalLeg.ReversalTransactionReferenceId = transactionReferenceId;
                            continue;
                        }
                        //if (isSource)
                        //{
                        //    transfer.Source.ReversalFundTransferDetailKey = Convert.ToInt64(reader["FundTransferDetailKey"]);
                        //    transfer.Source.ReversalStatus = (TransferStatus) reader.GetInt16(reader.GetOrdinal("DetailFundTransferStatusKey"));
                        //    transfer.Source.ReversalTransactionReferenceId = transactionReferenceId;
                        //}
                        //else
                        //{
                        //    transfer.Target.ReversalFundTransferDetailKey = Convert.ToInt64(reader["FundTransferDetailKey"]);
                        //    transfer.Target.ReversalStatus = (TransferStatus)reader.GetInt16(reader.GetOrdinal("DetailFundTransferStatusKey"));
                        //    transfer.Target.ReversalTransactionReferenceId = transactionReferenceId;
                        //}
                        // if reversal don't create a new leg, use existing leg and continue with the while loop.
                    }

                    TransferLeg transferLeg = null;
                    if (transferEndpointType == TransferEndpointType.Account)
                    {
                        if (allowNegativeBalance)
                        {
                            allowNegativeBalance = transferType == TransferType.DisbursementIn || transferType == TransferType.DisbursementOut;

                            if (allowNegativeBalance)
                                allowNegativeBalance = _baasConfiguration.AllowNegativeBalanceForProgram(programCode);
                        }

                        if (transferType == TransferType.SccWriteOffFullBalance
                            || transferType == TransferType.SccWriteOffNegativeBalance
                            || transferType == TransferType.SccWriteOffPartialBalance
                            || transferType == TransferType.SccWriteOffOverCreditLimit
                            || transferType == TransferType.SCCWriteOffNegativeBalanceOnly)
                        {
                            allowNegativeBalance = true;
                        }

                        AccountTransferEndpoint accountTransferEndPoint = null;
                        if (reader["Identifier"] != DBNull.Value)
                        {
                            //For Mrdc X9
                            short statusKey = reader.GetInt16(reader.GetOrdinal("DetailFundTransferStatusKey"));

                            FundTransferDetail fundTransferDetail = new FundTransferDetail
                            {
                                DetailFundTransferStatusKey = statusKey,
                                DetailTransactionAmount = amount,
                                FundTransferDetailKey = Convert.ToInt64(reader["FundTransferDetailKey"]),
                                IsSource = false,
                                TransactionReferenceID = transactionReferenceId.ToString()
                            };

                            if (partialTransactionReferenceId != null && fundTransferDetails != null && !isSource)
                            {
                                fundTransferDetails.Add(fundTransferDetail);

                                if (!string.Equals(partialTransactionReferenceId, transactionReferenceId.ToString(), StringComparison.OrdinalIgnoreCase)) continue;
                            }

                            AccountIdentifier accountIdentifier = identifierType == IdentifierType.AccountHolderIdentifier ? DomainContext.Current.AccountIdentifier : AccountIdentifier.FromGuid(reader.GetGuid(reader.GetOrdinal("Identifier")));
                            accountTransferEndPoint = new AccountTransferEndpoint(accountIdentifier, externalHandle);
                            _eGiftRepository = new EGiftRepository(_dataAccess, this, _accountRepository);
                            transferLeg = new AccountTransferLeg(
                                programCode,
                                accountTransferEndPoint,
                                amount,
                                allowNegativeBalance,
                                currencyCode,
                                transClass,
                                GetReversalTransClass(transClass),
                                transactionReferenceId,
                                transfer.FundTransferDelayType == TransferDelayType.ApprovalRequired, //do2WayTransaction
                                holdingTransClass, //holdingTransClass
                                holdingReversalTransClass, //holdingReversalTransClass
                                transferType,
                                transactionDescription,
                                Base36Converter.GuidToBase36(transfer.TransferIdentifier.ToGuid()),
                                checkVelocityLimits,
                                false,
                                _dcppService,
                                _accountBalanceRepository,
                                _accountRepository,
                                _rulesEngine,
                                _programFundingRepository,
                                _productRepository,
                                _transactionsRepository,
                                this,
                                _eGiftRepository,
                                _userService,
                                _baasConfiguration,
                                isBillPay: transfer.TransferType == TransferType.BillPay);
                            if ((transfer.TransferType == TransferType.SwipeReload || transfer.TransferType == TransferType.InitialLoad) && isReversal == true)
                            {
                                transferLeg.IsCredit = transferLeg.ReversalTransClass.IsCredit;
                                transferLeg._allowNegativeBalance = true;
                                transferLeg.Description = transfer.Description;
                            }
                        }
                        else
                        {
                            HandleTransferEndpoint handleTransferEndpoint = new HandleTransferEndpoint(externalHandle);
                            transferLeg = new HandleTransferLeg(
                                handleTransferEndpoint,
                                amount,
                                currencyCode,
                                transClass,
                                GetReversalTransClass(transClass),
                                !isSource,
                                transactionReferenceId,
                                transfer.FundTransferDelayType ==
                                TransferDelayType.ApprovalRequired, //do2WayTransaction
                                holdingTransClass,
                                holdingReversalTransClass,
                                false, //allowNegativeBalance,
                                transactionDescription, //description,
                                Base36Converter.GuidToBase36(transfer.TransferIdentifier.ToGuid()), //comment,
                                _dcppService,
                                _accountBalanceRepository);
                        }

                        transferLeg.Status = (TransferStatus)reader.GetInt16(reader.GetOrdinal("DetailFundTransferStatusKey"));
                    }
                    else if (transferEndpointType == TransferEndpointType.ProgramFunding)
                    {
                        var identifier = reader.GetGuid(reader.GetOrdinal("Identifier"));
                        ProgramFundingIdentifier programFundingIdentifier = ProgramFundingIdentifier.FromGuid(identifier);

                        transferLeg = new ProgramFundingTransferLeg(
                            new ProgramFundingTransferEndpoint(programFundingIdentifier, identifier, identifier),
                            amount,
                            currencyCode,
                            !isSource,
                            transactionReferenceId,
                            _programFundingRepository,
                            transClass,
                            GetReversalTransClass(transClass),
                            transfer.FundTransferDelayType == TransferDelayType.ApprovalRequired,
                            holdingTransClass, holdingReversalTransClass,
                            false, transactionDescription,
                            Base36Converter.GuidToBase36(transfer.TransferIdentifier.ToGuid()),
                            _accountBalanceRepository,
                            _dcppService);

                        transferLeg.Status = (TransferStatus)reader.GetInt16(reader.GetOrdinal("DetailFundTransferStatusKey"));
                    }
                    else if (transferEndpointType == TransferEndpointType.Ach)
                    {
                        string externalIdentifier = reader.GetString(reader.GetOrdinal("ExternalIdentifier"));

                        JsonSerializer serializer = new JsonSerializer();

                        JsonReader jr = new JsonTextReader(new StringReader(externalIdentifier));

                        var bankAccount = serializer.Deserialize<Domain.Model.Account.BankAccount>(jr);

                        transferLeg = new AchTransferLeg(
                        new AchTransferEndpoint(
                            bankAccount?.AccountNumber,
                            bankAccount?.RoutingNumber,
                            bankAccount?.BankName,
                            bankAccount?.FirstName,
                            bankAccount?.LastName,
                            bankAccount?.BusinessName,
                            bankAccount?.AccountType,
                            transferType != TransferType.SccPaymentByAchPull && !String.IsNullOrEmpty(bankAccount?.BankAccountReferenceId),// SccPaymentByAchPull ignore BankAccountReferenceId check
                            null),
                        amount,
                        !isSource,
                        transactionReferenceId,
                        transfer?.InitiatorAccountIdentifier,
                        _achService,
                        transClass,
                        GetReversalTransClass(transClass),
                        transfer?.FundTransferDelayType == TransferDelayType.ApprovalRequired,
                        holdingTransClass, holdingReversalTransClass,
                        false, transactionDescription,
                        Base36Converter.GuidToBase36(transfer.TransferIdentifier.ToGuid()),
                        _dcppService,
                        _accountBalanceRepository,
                        _accountRepository,
                        null,
                        null,
                        null,
                        null,
                        null,
                        bankAccount?.BankAccountReferenceId,
                        null, null
                        );

                        transferLeg.Status = (TransferStatus)reader.GetInt16(reader.GetOrdinal("DetailFundTransferStatusKey"));
                    }
                    else if (transferEndpointType == TransferEndpointType.RetailSale)
                    {
                        string externalIdentifier = reader.GetString(reader.GetOrdinal("ExternalIdentifier"));

                        AccountIdentifier identifier = null;
                        if (reader["Identifier"] != DBNull.Value)
                        {
                            identifier = reader.GetGuid(reader.GetOrdinal("Identifier"));
                        }

                        JsonSerializer serializer = new JsonSerializer();

                        JsonReader jr = new JsonTextReader(new StringReader(externalIdentifier));

                        var retailSaleData = serializer.Deserialize<RetailSaleData>(jr);

                        transferLeg = new RetailSaleTransferLeg(
                            new RetailSaleTransferEndpoint(
                                retailSaleData.MerchantName,
                                retailSaleData.StoreNumber,
                                retailSaleData.City,
                                retailSaleData.State,
                                identifier),
                            programCode,
                            amount,
                            currencyCode,
                            !isSource,
                            transactionReferenceId,
                            transClass,
                            GetReversalTransClass(transClass),
                            transfer.FundTransferDelayType == TransferDelayType.ApprovalRequired,
                            holdingTransClass, holdingReversalTransClass,
                            false, transactionDescription,
                            Base36Converter.GuidToBase36(transfer.TransferIdentifier.ToGuid()),
                            transferType,
                            _dcppService,
                            _accountBalanceRepository,
                            _rulesEngine,
                            _accountRepository,
                            _programFundingRepository,
                            _productRepository,
                            this, _transactionsRepository);
                        transferLeg.Status =
                            (TransferStatus)reader.GetInt16(reader.GetOrdinal("DetailFundTransferStatusKey"));
                    }
                    else if (transferEndpointType == TransferEndpointType.MrdcTransfer)
                    {
                        string externalIdentifier = reader.GetString(reader.GetOrdinal("ExternalIdentifier"));

                        JsonSerializer serializer = new JsonSerializer();

                        JsonReader jr = new JsonTextReader(new StringReader(externalIdentifier));

                        var check = serializer.Deserialize<Check>(jr);

                        transferLeg = new MrdcTransferLeg(
                            new MrdcTransferEndpoint(check),
                            string.Empty, string.Empty, string.Empty, null,
                            programCode,
                            amount,
                            !isSource,
                            transactionReferenceId,
                            transfer.InitiatorAccountIdentifier,
                            _mrdcService,
                            transClass,
                            GetReversalTransClass(transClass),
                            transfer.FundTransferDelayType == TransferDelayType.ApprovalRequired,
                            holdingTransClass, holdingReversalTransClass,
                            false, transactionDescription,
                            Base36Converter.GuidToBase36(transfer.TransferIdentifier.ToGuid()),
                            _accountBalanceRepository,
                            _dcppService, null);
                        transferLeg.Status = (TransferStatus)reader.GetInt16(reader.GetOrdinal("DetailFundTransferStatusKey"));

                    }
                    else if (transferEndpointType == TransferEndpointType.BillPay)
                    {
                        //var abaRoutingNumber = reader.IsDBNull(7) ? null : reader.GetString(7);
                        string externalIdentifier = reader.IsDBNull(reader.GetOrdinal("ExternalIdentifier")) ?
                            null : reader.GetString(reader.GetOrdinal("ExternalIdentifier"));
                        transferLeg = new BillPayTransferLeg(new BillPayTransferEndpoint(TransferEndpointType.BillPay), amount,
                            currencyCode, !isSource, transactionReferenceId, externalIdentifier,
                            transClass, GetReversalTransClass(transClass),
                            transfer.FundTransferDelayType == TransferDelayType.ApprovalRequired,
                            holdingTransClass, holdingReversalTransClass,
                            false, transactionDescription,
                            Base36Converter.GuidToBase36(transfer.TransferIdentifier.ToGuid()),
                            _dcppService, _accountBalanceRepository);
                    }
                    else if (transferEndpointType == TransferEndpointType.IFT)
                    {
                        var cardIdentifier = reader.GetGuid(reader.GetOrdinal("Identifier"));

                        var cards = _externalPaymentRepository.GetAll(transfer.InitiatorAccountIdentifier.ToString());
                        var card = cards.Where(c => c.AccountExternalPaymentIdentifier == cardIdentifier).FirstOrDefault();

                        var programInfo = _programFundingRepository.GetProgramInfoByAccountIdentifier(transfer.InitiatorAccountIdentifier);
                        var consumer = _accountRepository.GetAccountPrimaryConsumerProfile(transfer.InitiatorAccountIdentifier);
                        var fees = _productRepository.GetAllFeesForProduct(programInfo.ProductKey, programInfo.ProductTierKey,
                            TransferTypeExt.ToSharedType(transferType));

                        decimal fee = 0;
                        decimal feeMinimum = 0;
                        decimal feePercentage = 0;
                        if (fees != null && fees.Count > 0)
                        {
                            fee = fees.First().FeeAmount;
                            feeMinimum = fees.First().FeeAmount;
                            feePercentage = fees.First().PercentageAmount;
                        }
                        else
                            _logger.Warn(
                                $"No fee found for ProductKey {programInfo.ProductKey}, ProductTierKey {programInfo.ProductTierKey}, transferType {transferType}");

                        transferLeg = new InstantFundTransferLeg(programCode,
                            new InstantFundTransferEndpoint(CardIdentifier.FromGuid(cardIdentifier),
                                card.FirstName, card.LastName, card.EncryptedPAN,
                                card.ExpirationDate, "", card.Address, "", card.City, card.State, card.ZipCode, card.Country, false,
                                TransferEndpointType.IFT, isSource ? transfer.InitiatorAccountIdentifier : null),
                            transferAmount,
                            fee,
                            feeMinimum,
                            feePercentage,
                            currencyCode,
                            !isSource,
                            transferType,
                            _transferDescriptionProvider.GetIFTMerchantName(transferType, programInfo.ProductName),
                            consumer.FirstName,
                            consumer.LastName,
                            consumer.Address1,
                            consumer.Address2,
                            consumer.City,
                            consumer.State,
                            consumer.Country,
                            consumer.ZipCode,
                            card.BankName,
                            card.Network,
                            card.Last4PAN,
                            card.BIN,
                            transactionReferenceId,
                            transClass,
                            GetReversalTransClass(transClass),
                            transfer.FundTransferDelayType == TransferDelayType.ApprovalRequired, //do2WayTransaction
                            holdingTransClass, holdingReversalTransClass,
                            false, transactionDescription,
                            Base36Converter.GuidToBase36(transfer.TransferIdentifier.ToGuid()),
                            _accountBalanceRepository, _programFundingRepository, _productRepository, _rulesEngine, _accountRepository, this, _dcppService, _instantFundTransferService);

                        transferLeg.Status = (TransferStatus)reader.GetInt16(reader.GetOrdinal("DetailFundTransferStatusKey"));
                    }
                    else if (transferEndpointType == TransferEndpointType.EGiftPurchase)
                    {
                        AccountIdentifier targetAccountIdentifier = AccountIdentifier.FromGuid(reader.GetGuid(reader.GetOrdinal("Identifier")));
                        var purchaserContactAddress = GetEmailAddressByAccountIdentifier(transfer.InitiatorAccountIdentifier.ToString());

                        var recipientContactAddress = string.Equals(transfer.InitiatorAccountIdentifier.ToString(), targetAccountIdentifier.ToString(), StringComparison.InvariantCultureIgnoreCase)
                            ? purchaserContactAddress
                            : GetEmailAddressByAccountIdentifier(targetAccountIdentifier.ToString());

                        _eGiftRepository = new EGiftRepository(_dataAccess, this, _accountRepository);
                        //TODO: only works for reverse, not retry
                        transferLeg = new EGiftPurchase(
                            new EGiftPurchaseEndpoint(null, transfer.InitiatorAccountIdentifier ?? (AccountIdentifier)null), //TODO: save productid here
                            targetAccountIdentifier,
                            amount,
                            transactionReferenceId,
                            _eGiftService,
                            transClass,
                            GetReversalTransClass(transClass),
                            false, //do2WayTransaction,
                            holdingTransClass,
                            holdingReversalTransClass,
                            false, //allowNegativeBalance,
                            externalHandle, //description,
                            transfer.Memo, //comment, 
                            "", //TODO: save contact name for retry
                            programCode,
                            transactionReferenceId.ToGuid(),
                            transfer.TransferIdentifier.ToGuid(),
                            EgiftPurchaseFeature.None, //TODO: save purchasefeature for retry
                            purchaserContactAddress,
                            recipientContactAddress,
                            _dcppService,
                            _accountBalanceRepository,
                            _accountRepository,
                            _programFundingRepository,
                            _rulesEngine,
                            _eGiftRepository,
                            _productRepository,
                            _settings)
                        {
                            //update additional fields calculated in preprocess
                            CreateDate = createDate
                        };

                        transferLeg.Status = (TransferStatus)reader.GetInt16(reader.GetOrdinal("DetailFundTransferStatusKey"));

                    }
                    else if (transferEndpointType == TransferEndpointType.EGiftPoints)
                    {
                        Guid giftcardid = reader.GetGuid(reader.GetOrdinal("Identifier"));

                        //only need brandname
                        string brandName = reader.GetString(reader.GetOrdinal("ExternalIdentifier"));

                        //TODO: save catalogitem in externalidentifier
                        //JsonSerializer serializer = new JsonSerializer();
                        //JsonReader jr = new JsonTextReader(new StringReader(externalIdentifier));
                        //var catalogItem = serializer.Deserialize<CatalogItem>(jr);



                        transferLeg = new PointsSystemTransferLeg(
                            new EGiftPointsEndpoint(transfer.InitiatorAccountIdentifier),
                            amount,
                            transactionReferenceId,
                            transClass,
                            GetReversalTransClass(transClass),
                            false, //do2WayTransaction,
                            holdingTransClass,
                            holdingReversalTransClass,
                            false, //allowNegativeBalance,
                            null, //description,
                            null, //comment, 
                            _dcppService,
                            _accountBalanceRepository,
                            _pointsSystemService,
                            programCode,
                            giftcardid,
                            transfer.TransferIdentifier.ToGuid(),
                            EgiftPurchaseFeature.DoubleCashBack,
                            amount) //TODO: save purchasefeature for retry
                        {
                            EGiftCatalogItem = new CatalogItem() { BrandName = brandName }
                        };

                        transferLeg.Status = (TransferStatus)reader.GetInt16(reader.GetOrdinal("DetailFundTransferStatusKey"));

                    }
                    else if (transferEndpointType == TransferEndpointType.Purse)
                    {
                        AccountBalanceIdentifier purseIdentifier = AccountBalanceIdentifier.FromGuid(reader.GetGuid(reader.GetOrdinal("Identifier")));
                        if (transfer.TransferType == TransferType.CblPaymentByAchPull)
                        {
                            transferLeg = new CblPaymentByAchPurseTransferLeg(programCode,
                                new PurseTransferEndpoint(purseIdentifier, transfer.InitiatorAccountIdentifier),
                                amount,
                                allowNegativeBalance,
                                "USD",
                                transClass,
                                GetReversalTransClass(transClass),
                                transferType,
                                transactionReferenceId,
                                transfer.Description,
                                Base36Converter.GuidToBase36(transfer.TransferIdentifier.ToGuid()),
                                _dcppService, // TODO: Fix this.  Should not be passing in.
                                _accountBalanceRepository, // TODO: Fix this.  Should not be passing in.
                                _accountRepository,
                                _rulesEngine,
                                _programFundingRepository,
                                _productRepository,
                                _transactionsRepository,
                                null, //accountStatusAndBalances,
                                false, //do2WayTransaction,
                                true, //skipValidation,
                                holdingTransClass,
                                holdingReversalTransClass, _careSharedApiService,
                                false);
                        }

                        else
                        {
                            var endPoint =
                                new PurseTransferEndpoint(purseIdentifier, transfer.InitiatorAccountIdentifier);
                            if (transferType == TransferType.SccWriteOffFullBalance
                                || transferType == TransferType.SccWriteOffPartialBalance
                                || transferType == TransferType.SccWriteOffNegativeBalance
                                || transferType == TransferType.SccWriteOffOverCreditLimit
                                || transferType == TransferType.CreditLineDecrease)
                            {
                                var accounts = _accountRepository.GetAccountsBySccAccountIdentifier(initiatorAccountIdentifier);
                                var sccAccount = accounts.FirstOrDefault(a => a.BinType == BinType.Credit);
                                endPoint = new PurseTransferEndpoint(purseIdentifier,
                                    sccAccount.AccountIdentifier);
                            }

                            transferLeg = new PurseTransferLeg(programCode,
                                endPoint,
                                amount,
                                allowNegativeBalance,
                                "USD",
                                transClass,
                                GetReversalTransClass(transClass),
                                transferType,
                                transactionReferenceId,
                                transfer.Description,
                                Base36Converter.GuidToBase36(transfer.TransferIdentifier.ToGuid()),
                                _dcppService, // TODO: Fix this.  Should not be passing in.
                                _accountBalanceRepository, // TODO: Fix this.  Should not be passing in.
                                _accountRepository,
                                _rulesEngine,
                                _programFundingRepository,
                                _productRepository,
                                _transactionsRepository,
                                null, //accountStatusAndBalances,
                                false, //do2WayTransaction,
                                true, //skipValidation,
                                holdingTransClass,
                                holdingReversalTransClass,
                                false);
                        }
                        transferLeg.Status = (TransferStatus)reader.GetInt16(reader.GetOrdinal("DetailFundTransferStatusKey"));
                    }
                    else if (transferEndpointType == TransferEndpointType.SCCFunding)
                    {
                        //AccountIdentifier accountIdentifier = AccountIdentifier.FromGuid(reader.GetGuid(reader.GetOrdinal("Identifier")));
                        AccountBalanceIdentifier accountBalanceIdentifier = AccountBalanceIdentifier.FromGuid(reader.GetGuid(reader.GetOrdinal("Identifier")));


                        var accounts = _accountRepository.GetAccountsBySccAccountIdentifier(initiatorAccountIdentifier);
                        var sccAccount = accounts.FirstOrDefault(a => a.BinType == BinType.Credit);

                        SccFundingTransferEndpoint sccFundingTransferEndPoint =
                            new SccFundingTransferEndpoint(sccAccount.AccountIdentifier, accountBalanceIdentifier, transfer.FundTransferKey);

                        transferLeg = new SccFundingTransferLeg(
                            programCode,
                            sccFundingTransferEndPoint,
                            amount,
                            allowNegativeBalance,
                            currencyCode,
                            transClass,
                            GetReversalTransClass(transClass),
                            transactionReferenceId,
                            false, //do2WayTransaction
                            holdingTransClass, //holdingTransClass
                            holdingReversalTransClass, //holdingReversalTransClass
                            transferType,
                            transactionDescription,
                            Base36Converter.GuidToBase36(transfer.TransferIdentifier.ToGuid()),
                            _dcppService,
                            _accountBalanceRepository,
                            _accountRepository,
                            _rulesEngine,
                            _userService,
                            _loanManagementService,
                            _userRepository,
                            this,
                            _transactionsRepository);
                        transferLeg.Status = (TransferStatus)reader.GetInt16(reader.GetOrdinal("DetailFundTransferStatusKey"));

                    }
                    else if (transferEndpointType == TransferEndpointType.Adjustment)
                    {
                        string adjustmentData = reader.GetString(reader.GetOrdinal("ExternalIdentifier")).ToString();
                        AdjustmentTransferEndpoint adjustmentTransferEndpoint = new AdjustmentTransferEndpoint(adjustmentData, null);

                        transferLeg = new AdjustmentTransferLeg(
                            adjustmentTransferEndpoint,
                            amount,
                            currencyCode,
                            transClass.IsCredit,
                            transactionReferenceId,
                            transClass,
                            GetReversalTransClass(transClass),
                            false,// do2WayTransaction,
                            holdingTransClass,
                            holdingReversalTransClass,
                            false, //allowNegativeBalance,
                            null, //description,
                            null, //comment,
                            _dcppService,
                            _accountBalanceRepository);
                    }
                    else if (transferEndpointType == TransferEndpointType.Wire)
                    {

                        transferLeg = new WireTransferLeg(
                            new WireTransferEndpoint(TransferEndpointType.Wire,
                                null, null), amount, currencyCode,
                            true, TransactionReferenceId.FromGuid(Guid.NewGuid()), transClass, GetReversalTransClass(transClass), false, null, null, false, null,
                            null, null, null, externalHandle);
                    }
                    else if (transferEndpointType == TransferEndpointType.Empty)
                    {
                        var endpoint = new EmptyTransferEndpoint();
                        if (identifierType == IdentifierType.AccountIdentifier)
                        {
                            endpoint = new EmptyTransferEndpoint(
                                AccountIdentifier.FromGuid(reader.GetGuid(reader.GetOrdinal("Identifier"))));
                        }
                        transferLeg = new EmptyTransferLeg(
                            endpoint,
                            amount,
                            currencyCode,
                            transClass,
                            GetReversalTransClass(transClass),
                            !isSource,
                            transactionReferenceId,
                            false,
                            holdingTransClass, //holdingTransClass
                            holdingReversalTransClass, //holdingReversalTransClass,
                            false,
                            "",
                            "",
                            _dcppService,
                            _accountBalanceRepository
                            );
                        transferLeg.Status = (TransferStatus)reader.GetInt16(reader.GetOrdinal("DetailFundTransferStatusKey"));
                    }

                    if (transferLeg != null)
                    {
                        if (reader["FundTransferDetailKey"] != DBNull.Value)
                            transferLeg.FundTransferDetailKey = Convert.ToInt64(reader["FundTransferDetailKey"]);

                        transfer.SetLeg(transferLeg, isSource, identifierType);
                    }
                }
            }

            //is needed to cross reference in hold and execute with 2Way Transaction
            if (transfer?.Source?.TransferEndpoint != null)
            {
                transfer.Source?.TransferEndpoint?.SetOtherLegAccountIdentifier(transfer.Target.TransferEndpoint?.AccountIdentifier);

                if (transfer.InitiatorAccountIdentifier.ToGuid() == transfer.Source.TransferEndpoint?.AccountIdentifier?.ToGuid()
                    && string.IsNullOrEmpty(transfer.Source.Description))
                    transfer.Source.Description = _transferDescriptionProvider.GetSourceDescription(
                        transfer.Target.TransferEndpoint?.AccountIdentifier?.ToString(), transfer.Description,
                        transfer.TransferType);
                else if (string.IsNullOrEmpty(transfer.Source.Description)) // set description only when empty. As PITD.Descr is not populated for hold transactions
                    transfer.Source.Description = _transferDescriptionProvider.GetSourceDescription(
                        transfer.Target.TransferEndpoint?.AccountIdentifier?.ToString(), null,
                        transfer.TransferType);
            }

            if (transfer?.Target?.TransferEndpoint != null)
            {
                transfer.Target.TransferEndpoint.SetOtherLegAccountIdentifier(transfer.Source.TransferEndpoint?.AccountIdentifier);

                if (transfer.InitiatorAccountIdentifier.ToGuid() == transfer.Target.TransferEndpoint?.AccountIdentifier?.ToGuid()
                    && string.IsNullOrEmpty(transfer.Target.Description))
                    transfer.Target.Description = _transferDescriptionProvider.GetTargetDescription(
                        transfer.Source.TransferEndpoint?.AccountIdentifier?.ToString(), transfer.Description,
                        transfer.TransferType);
                else if (string.IsNullOrEmpty(transfer.Target.Description)) // set description only when empty. As PITD.Descr is not populated for hold transactions
                    transfer.Target.Description = _transferDescriptionProvider.GetTargetDescription(
                        transfer.Source.TransferEndpoint?.AccountIdentifier?.ToString(), null,
                        transfer.TransferType);
            }

            switch (transfer?.TransferType)
            {
                case TransferType.SccWriteOffFullBalance:
                case TransferType.SccWriteOffPartialBalance:
                case TransferType.SccWriteOffOverCreditLimit:
                case TransferType.SccWriteOffNegativeBalance:
                    {
                        if (transfer is SccBalanceSweepTransfer)
                        {
                            ((SccBalanceSweepTransfer)transfer).SetDescription();
                        }
                        break;
                    }
                case TransferType.SccFunding:
                    {
                        var description = _transferDescriptionProvider.GetSccFundingDescription(programCode);
                        var sccFundingTransfer = (SccFundingTransfer)transfer;
                        sccFundingTransfer.Source.Description = description.Item1;
                        sccFundingTransfer.Target.Description = description.Item2;
                        ((SccFundingTransferLeg)sccFundingTransfer.Target2).SccFundingTransferEndpoint
                            .SetAccountIdentifier(sccFundingTransfer.Target.TransferEndpoint.AccountIdentifier);
                        break;
                    }
                case TransferType.CreditLineIncrease:
                    {
                        var description = _transferDescriptionProvider.GetSccCreditLineIncreaseDescription(programCode);
                        var sccFundingTransfer = (SccFundingTransfer)transfer;
                        sccFundingTransfer.Source.Description = description.Item1;
                        sccFundingTransfer.Target.Description = description.Item2;
                        ((SccFundingTransferLeg)sccFundingTransfer.Target2).SccFundingTransferEndpoint
                            .SetAccountIdentifier(sccFundingTransfer.Target.TransferEndpoint.AccountIdentifier);
                        break;
                    }
                case TransferType.SccPayment:
                    {
                        var description = _transferDescriptionProvider.GetSccPaymentDescription(programCode);
                        transfer.Source.Description = description.Item1;
                        transfer.Target.Description = description.Item2;
                        break;
                    }
            }

            return transfer;
        }

        private List<FundTransferDetails> ReadFundTransferDetails(IDataReader reader)
        {
            var fundTransferDetails = new List<FundTransferDetails>();

            long fundTransferKey = 0;
            Guid transferToken = Guid.Empty;

            if (reader.Read())
            {
                fundTransferKey = reader.GetInt64(reader.GetOrdinal("FundTransferKey"));
                transferToken = reader.GetGuid(reader.GetOrdinal("FundTransferToken"));
            }

            if (reader.NextResult())
            {
                while (reader.Read())
                {
                    FundTransferDetails fundTransferDetail = new FundTransferDetails()
                    {
                        FundTransferKey = fundTransferKey,
                        TransferToken = transferToken,
                        IsSource = reader.GetBoolean(reader.GetOrdinal("IsSource")),
                        IsReversal = reader["IsReversal"] == DBNull.Value ? null : reader.GetBoolean(reader.GetOrdinal("IsReversal")),
                        TransactionReferenceID = reader.GetGuid(reader.GetOrdinal("TransactionReferenceId")),
                        Identifier = reader["Identifier"] == DBNull.Value ? null : reader.GetGuid(reader.GetOrdinal("Identifier")),
                        FundTransferDetailKey = reader.GetInt64(reader.GetOrdinal("FundTransferDetailKey")),
                        TransferStatus = (TransferStatus)reader.GetInt16(reader.GetOrdinal("DetailFundTransferStatusKey")),
                        IdentifierType = (IdentifierType)reader.GetInt16(reader.GetOrdinal("IdentifierTypeKey")),
                    };

                    fundTransferDetails.Add(fundTransferDetail);
                }
            }

            return fundTransferDetails;
        }

        private string GetEmailAddressByAccountIdentifier(string accountIdentifier)
        {
            try
            {
                if (!string.IsNullOrEmpty(accountIdentifier))
                {
                    var notifyAccount = _accountRepository.GetAccountPrimaryConsumerProfile(
                        AccountIdentifier.FromString(accountIdentifier));
                    return notifyAccount?.Email;
                }
            }
            catch (System.Exception ex)
            {
                _logger.Error(ex, $"Exception caught while trying to retrieve Email Address by AccountIdentifier:{accountIdentifier}, RequestId:{OptionsContext.Current.GetGuid("requestId", Guid.NewGuid())}");
            }

            return null;
        }

        private Transfer CreateTransfer(TransferIdentifier transferIdentifier, AccountIdentifier initiatorAccountIdentifier, TransferType transferType, decimal amount,
            Currency currency, string description, string memo, TransferDelayType transferDelayType, TransferStatus transferStatus, string programCode)
        {
            Transfer transfer;
            switch (transferType)
            {
                case TransferType.EGiftPurchase:
                    transfer = new EGiftTransfer(transferIdentifier,
                    initiatorAccountIdentifier,
                    transferType,
                    amount,
                    currency,
                    description,
                    programCode,
                    memo,
                    transferDelayType,
                    transferStatus);
                    break;
                case TransferType.SccWriteOffFullBalance:
                case TransferType.SccWriteOffPartialBalance:
                case TransferType.SccWriteOffNegativeBalance:
                case TransferType.SccWriteOffOverCreditLimit:
                case TransferType.SCCWriteOffNegativeBalanceOnly:
                    transfer = new SccBalanceSweepTransfer(transferIdentifier,
                        initiatorAccountIdentifier,
                        transferType,
                        amount,
                        currency,
                        description);
                    break;
                case TransferType.SccFunding:
                case TransferType.CreditLineIncrease:
                    transfer = new SccFundingTransfer(transferIdentifier,
                        initiatorAccountIdentifier,
                        transferType,
                        amount,
                        currency,
                        description,
                        programCode,
                        transferStatus: transferStatus);
                    break;
                case TransferType.CreditLineDecrease:
                    transfer = new SccWithdrawalTransfer(transferIdentifier,
                        initiatorAccountIdentifier,
                        transferType,
                        amount,
                        currency,
                        description,
                        programCode,
                        transferStatus: transferStatus);
                    break;
                case TransferType.WireOut:
                    transfer = new WireOutTransfer(transferIdentifier,
                        initiatorAccountIdentifier,
                        transferType,
                        amount,
                        currency,
                        description,
                        programCode,
                        transferStatus: transferStatus);
                    break;
                case TransferType.IFTLoad:
                    transfer = new IftTransfer(transferIdentifier,
                        initiatorAccountIdentifier,
                        transferType,
                        amount,
                        currency,
                        description,
                        memo,
                        transferDelayType,
                        transferStatus);
                    break;
                default:
                    transfer = new Transfer(
                    transferIdentifier,
                    initiatorAccountIdentifier,
                    transferType,
                    amount,
                    currency,
                    description,
                    memo,
                    transferDelayType,
                    transferStatus);
                    break;
            }
            return transfer;
        }

        private TransClass GetReversalTransClass(TransClass transClass)
        {
            if (transClass.IsReversal) return transClass;
            if (transClass.Code == "0-001") return GetTransClassByTransClassCode("0-002");
            if (transClass.Code == "0-002") return GetTransClassByTransClassCode("0-001");
            if (transClass.Code == "2-018") return GetTransClassByTransClassCode("1-018");

            string[] transClassSplit = transClass.Code.Split('-');
            string reversalPrefix = (int.Parse(transClassSplit[0]) + 1).ToString();
            string reversalTransCode = $"{reversalPrefix}-{transClassSplit[1]}";

            return GetTransClassByTransClassCode(reversalTransCode);
        }

        private void Update(Transfer transfer, TransferUpdated transferUpdated)
        {
            if (transferUpdated.IsSource)
            {
                //string externalHandle = String.Empty;
                //if (transferUpdated.sourceTransferEndPoint is AccountTransferEndpoint accEndPoint)
                //    externalHandle = accEndPoint.ExternalHandle;
                //else if (transferUpdated.sourceTransferEndPoint is HandleTransferEndpoint handleEndpoint)
                //    externalHandle = handleEndpoint.Handle;

                UpdateFundTransferDetailByFundTransferDetailKey(transfer.Source.FundTransferDetailKey,
                    transferUpdated.sourceTransferEndPoint.TransferEndpointType,
                    transferUpdated.sourceTransferEndPoint.AccountIdentifier,
                    //externalHandle,
                    transferUpdated.IdentifierType);
            }
            else
            {
                //string externalHandle = String.Empty;
                //if (transferUpdated.targetTransferEndPoint is AccountTransferEndpoint accEndPoint)
                //    externalHandle = accEndPoint.ExternalHandle;
                //else if (transferUpdated.targetTransferEndPoint is HandleTransferEndpoint handleEndpoint)
                //    externalHandle = handleEndpoint.Handle;
                //else if (transferUpdated.targetTransferEndPoint is InstantFundTransferEndpoint iftEndpoint)
                //    externalHandle = iftEndpoint.Last4;  // decision not final yet for where to save last 4 in guest checkout

                UpdateFundTransferDetailByFundTransferDetailKey(transfer.Target.FundTransferDetailKey,
                    transferUpdated.targetTransferEndPoint.TransferEndpointType,
                    transferUpdated.targetTransferEndPoint.AccountIdentifier,
                    //externalHandle,
                    transferUpdated.IdentifierType);
            }
        }

        private void Update(Transfer transfer, TransferEGiftRewardsCredited transferCredited)
        {
            InsertFundTransferDetail(transfer.FundTransferKey, CreateRewardsCreditFundTransferDetailRecord((AccountTransferLeg)transfer.Target));
        }

        private void Update(Transfer transfer, TransferEGiftPurchased updateEvent)
        {
            UpdatePostInternalTransactionDetailByTransactionReferenceId(transfer.Source.TransactionReferenceId.ToGuid(), transfer.Source.Description);
        }

        private void UpdatePostInternalTransactionDetailByTransactionReferenceId(Guid transactionReferenceId, string transactionDescription)
        {
            var parameters = new[] {
                new SqlParameter { ParameterName = "ChangeBy", Value = _userName, SqlDbType = SqlDbType.NVarChar, Size = 100 },
                new SqlParameter { ParameterName = "TransactionReferenceID", Value = transactionReferenceId, SqlDbType = SqlDbType.UniqueIdentifier },
                new SqlParameter { ParameterName = "TransactionDescription", Value = transactionDescription, SqlDbType = SqlDbType.VarChar },
            };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdPostInternalTransactionDetail]", _dataAccess.CreateConnection(), parameters);
        }

        private void Update(Transfer transfer, TransferStatusChanged transferStatusChanged)
        {
            UpdateFundTransferByFundTransferKey(transfer.FundTransferKey, transferStatusChanged.TransferStatus, transferStatusChanged.TransferStatusReason);
        }

        private void Update(Transfer transfer, TransferDescriptionChanged transferDescriptionChanged)
        {
            UpdateFundTransferByFundTransferKey(transfer.FundTransferKey, transferDescriptionChanged.Description);

            // Update PostInternalTransaction TransctionDescription Value For AchOut Transfers Via Linked Plaid Account
            if (transfer.TransferType == TransferType.AchOut
                && transfer.Target.GetType() == typeof(AchTransferLeg)
                && !String.IsNullOrWhiteSpace(((AchTransferLeg)transfer.Target).BankAccountReferenceId))
            {
                UpdatePostInternalTransactionDetailByTransactionReferenceId(transfer.Source.TransactionReferenceId.ToGuid(), transferDescriptionChanged.Description);
            }
        }

        private void Update(Transfer transfer, TransferDetailStatusChanged transferDetailStatusChanged)
        {
            if (transfer.Source?.TransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId)
            {
                UpdateFundTransferDetailByFundTransferDetailKey(transfer.Source.FundTransferDetailKey, transferDetailStatusChanged.TransferDetailStatus);
            }
            else if (transfer.Source?.ReversalTransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId)
            {
                UpdateFundTransferDetailByFundTransferDetailKey(transfer.Source.ReversalFundTransferDetailKey, transferDetailStatusChanged.TransferDetailStatus);
            }
            else if (transfer.Target?.TransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId)
            {
                UpdateFundTransferDetailByFundTransferDetailKey(transfer.Target.FundTransferDetailKey, transferDetailStatusChanged.TransferDetailStatus);
            }
            else if (transfer.Target?.ReversalTransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId)
            {
                UpdateFundTransferDetailByFundTransferDetailKey(transfer.Target.ReversalFundTransferDetailKey, transferDetailStatusChanged.TransferDetailStatus);
            }


        }

        private void Update(WireOutTransfer transfer, TransferDetailStatusChanged transferDetailStatusChanged)
        {
            if (transfer.Source?.TransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId)
            {
                UpdateFundTransferDetailByFundTransferDetailKey(transfer.Source.FundTransferDetailKey, transferDetailStatusChanged.TransferDetailStatus);
            }
            else if (transfer.Source?.ReversalTransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId)
            {
                UpdateFundTransferDetailByFundTransferDetailKey(transfer.Source.ReversalFundTransferDetailKey, transferDetailStatusChanged.TransferDetailStatus);
            }
            else if (transfer.Target?.TransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId)
            {
                UpdateFundTransferDetailByFundTransferDetailKey(transfer.Target.FundTransferDetailKey, transferDetailStatusChanged.TransferDetailStatus);
            }
            else if (transfer.Target?.ReversalTransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId)
            {
                UpdateFundTransferDetailByFundTransferDetailKey(transfer.Target.ReversalFundTransferDetailKey, transferDetailStatusChanged.TransferDetailStatus);
            }
            else if (transfer.Fee?.TransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId)
            {
                UpdateFundTransferDetailByFundTransferDetailKey(transfer.Fee.FundTransferDetailKey, transferDetailStatusChanged.TransferDetailStatus);
            }
            else if (transfer.Fee?.ReversalTransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId)
            {
                UpdateFundTransferDetailByFundTransferDetailKey(transfer.Fee.ReversalFundTransferDetailKey, transferDetailStatusChanged.TransferDetailStatus);
            }


        }

        private void Update(EGiftTransfer transfer, TransferDetailStatusChanged transferDetailStatusChanged)
        {
            Update((Transfer)transfer, transferDetailStatusChanged);
            if (transfer.Source2?.TransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId)
            {
                UpdateFundTransferDetailByFundTransferDetailKey(transfer.Source2.FundTransferDetailKey, transferDetailStatusChanged.TransferDetailStatus);
            }
            else if (transfer.Source2?.ReversalTransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId)
            {
                UpdateFundTransferDetailByFundTransferDetailKey(transfer.Source2.ReversalFundTransferDetailKey, transferDetailStatusChanged.TransferDetailStatus);
            }
            else if (transfer.Target2?.TransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId)
            {
                UpdateFundTransferDetailByFundTransferDetailKey(transfer.Target2.FundTransferDetailKey, transferDetailStatusChanged.TransferDetailStatus);
            }
            else if (transfer.Target2?.ReversalTransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId)
            {
                UpdateFundTransferDetailByFundTransferDetailKey(transfer.Target2.ReversalFundTransferDetailKey, transferDetailStatusChanged.TransferDetailStatus);
            }
        }

        private void Update(SccBalanceSweepTransfer transfer, TransferDetailStatusChanged transferDetailStatusChanged)
        {
            Update((Transfer)transfer, transferDetailStatusChanged);
            var otherSource = transfer.OtherSources.FirstOrDefault(s =>
                s.TransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId || s.ReversalTransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId);
            if (otherSource != null)
            {
                UpdateFundTransferDetailByFundTransferDetailKey(otherSource.FundTransferDetailKey, transferDetailStatusChanged.TransferDetailStatus);
            }

            var otherTarget = transfer.OtherTargets.FirstOrDefault(s =>
                s.TransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId || s.ReversalTransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId);

            if (otherTarget != null)
            {
                UpdateFundTransferDetailByFundTransferDetailKey(otherTarget.FundTransferDetailKey, transferDetailStatusChanged.TransferDetailStatus);
            }
        }

        private void Update(SccFundingTransfer transfer, TransferDetailStatusChanged transferDetailStatusChanged)
        {
            Update((Transfer)transfer, transferDetailStatusChanged);
            if (transfer.Target2?.TransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId)
            {
                UpdateFundTransferDetailByFundTransferDetailKey(transfer.Target2.FundTransferDetailKey, transferDetailStatusChanged.TransferDetailStatus);
            }
            else if (transfer.Target2?.ReversalTransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId)
            {
                UpdateFundTransferDetailByFundTransferDetailKey(transfer.Target2.ReversalFundTransferDetailKey, transferDetailStatusChanged.TransferDetailStatus);
            }
        }

        private void Update(SccWithdrawalTransfer transfer, TransferDetailStatusChanged transferDetailStatusChanged)
        {
            Update((Transfer)transfer, transferDetailStatusChanged);
            if (transfer.Source2?.TransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId)
            {
                UpdateFundTransferDetailByFundTransferDetailKey(transfer.Source2.FundTransferDetailKey, transferDetailStatusChanged.TransferDetailStatus);
            }
            else if (transfer.Source2?.ReversalTransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId)
            {
                UpdateFundTransferDetailByFundTransferDetailKey(transfer.Source2.ReversalFundTransferDetailKey, transferDetailStatusChanged.TransferDetailStatus);
            }
        }

        private void Update(IftTransfer transfer, TransferDetailStatusChanged transferDetailStatusChanged)
        {
            if (transfer.Source?.TransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId)
            {
                UpdateFundTransferDetailByFundTransferDetailKey(transfer.Source.FundTransferDetailKey, transferDetailStatusChanged.TransferDetailStatus);
            }
            else if (transfer.Source?.ReversalTransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId)
            {
                UpdateFundTransferDetailByFundTransferDetailKey(transfer.Source.ReversalFundTransferDetailKey, transferDetailStatusChanged.TransferDetailStatus);
            }
            else if (transfer.Target?.TransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId)
            {
                UpdateFundTransferDetailByFundTransferDetailKey(transfer.Target.FundTransferDetailKey, transferDetailStatusChanged.TransferDetailStatus);
            }
            else if (transfer.Target?.ReversalTransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId)
            {
                UpdateFundTransferDetailByFundTransferDetailKey(transfer.Target.ReversalFundTransferDetailKey, transferDetailStatusChanged.TransferDetailStatus);
            }
            else if (transfer.TargetFee?.TransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId)
            {
                UpdateFundTransferDetailByFundTransferDetailKey(transfer.TargetFee.FundTransferDetailKey, transferDetailStatusChanged.TransferDetailStatus);
            }
            else if (transfer.TargetFee?.ReversalTransactionReferenceId == transferDetailStatusChanged.TransactionReferenceId)
            {
                UpdateFundTransferDetailByFundTransferDetailKey(transfer.TargetFee.ReversalFundTransferDetailKey, transferDetailStatusChanged.TransferDetailStatus);
            }

        }

        private void UpdateFundTransferByFundTransferKey(long fundTransferKey, TransferStatus transferStatus, TransferStatusReason transferStatusReason)
        {
            var parameters = new[] {
                new SqlParameter() { ParameterName = "ChangeBy", Value = _userName, SqlDbType = SqlDbType.NVarChar, Size = 100 },
                new SqlParameter() { ParameterName = "FundTransferKey", Value = fundTransferKey, SqlDbType = SqlDbType.BigInt },
                new SqlParameter() { ParameterName = "FundTransferStatusKey", Value = (short)transferStatus, SqlDbType = SqlDbType.SmallInt },
                new SqlParameter() { ParameterName = "FundTransferStatusReasonKey", Value = transferStatusReason == TransferStatusReason.None ? null : (short?) transferStatusReason, SqlDbType = SqlDbType.SmallInt }
            };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdFundTransferByFundTransferKey]", _dataAccess.CreateConnection(), parameters);
        }

        private void UpdateFundTransferByFundTransferKey(long fundTransferKey, string description)
        {
            var parameters = new[]
            {
                new SqlParameter() {ParameterName = "ChangeBy", Value = _userName, SqlDbType = SqlDbType.NVarChar, Size = 100},
                new SqlParameter() {ParameterName = "FundTransferKey", Value = fundTransferKey, SqlDbType = SqlDbType.BigInt},
                new SqlParameter() {ParameterName = "TransactionDetail", Value = description, SqlDbType = SqlDbType.NVarChar, Size = 100}
            };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdFundTransferByFundTransferKey]", _dataAccess.CreateConnection(), parameters);
        }

        private void UpdateFundTransferDetailByFundTransferDetailKey(long fundTransferDetailKey, TransferStatus transferStatus)
        {
            var parameters = new[] {
                new SqlParameter() { ParameterName = "ChangeBy", Value = _userName, SqlDbType = SqlDbType.NVarChar, Size = 100 },
                new SqlParameter() { ParameterName = "FundTransferDetailKey", Value = fundTransferDetailKey, SqlDbType = SqlDbType.BigInt },
                new SqlParameter() { ParameterName = "FundTransferStatusKey", Value = (short)transferStatus, SqlDbType = SqlDbType.SmallInt }
            };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdFundTransferDetailByFundTransferDetailKey]", _dataAccess.CreateConnection(), parameters);
        }

        private void UpdateFundTransferDetailByFundTransferDetailKey(long fundTransferDetailKey, TransferEndpointType endPointType,
            AccountIdentifier accountIdentifier, //string externalHandle, 
            IdentifierType identifierType)
        {
            var parameters = new[] {
                new SqlParameter() { ParameterName = "ChangeBy", Value = _userName, SqlDbType = SqlDbType.NVarChar, Size = 100 },
                new SqlParameter() { ParameterName = "FundTransferDetailKey", Value = fundTransferDetailKey, SqlDbType = SqlDbType.BigInt },
                //new SqlParameter() { ParameterName = "FundTransferStatusKey", Value = (short)transferStatus, SqlDbType = SqlDbType.SmallInt },
                new SqlParameter() { ParameterName = "IdentifierTypeKey", Value =(int)identifierType/*account*/, SqlDbType = SqlDbType.SmallInt },
                new SqlParameter() { ParameterName = "Identifier", Value = accountIdentifier?.ToGuid(), SqlDbType = SqlDbType.UniqueIdentifier },
                //new SqlParameter() { ParameterName = "ExternalIdentifier", Value = externalHandle, SqlDbType = SqlDbType.Variant},
            };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdFundTransferDetailByFundTransferDetailKey]", _dataAccess.CreateConnection(), parameters);
        }

        private void Update(Transfer transfer, TransferDetailChanged changed)
        {

            var parameters = new[] {
                new SqlParameter() { ParameterName = "ChangeBy", Value = _userName, SqlDbType = SqlDbType.NVarChar, Size = 100 },
                new SqlParameter() { ParameterName = "FundTransferDetailKey", Value = changed.FundTransferDetailKey , SqlDbType = SqlDbType.BigInt },
                new SqlParameter() { ParameterName = "TransClassKey", Value = changed.HoldingTransClass.TransClassKey, SqlDbType = SqlDbType.Int }
            };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdFundTransferDetailByFundTransferDetailKey]", _dataAccess.CreateConnection(), parameters);
        }


        private long InsertFundTransferDetail(long fundTransferKey, SqlDataRecord fundTransferDetailRecord)
        {
            List<Tuple<long, Guid>> returnValue = new List<Tuple<long, Guid>>();

            var parameters = new[] {
                new SqlParameter() { ParameterName = "ChangeBy", Value = _userName, SqlDbType = SqlDbType.NVarChar, Size = 100 },
                new SqlParameter() { ParameterName = "FundTransferKey", Value = fundTransferKey, SqlDbType = SqlDbType.BigInt },
               new SqlParameter() { ParameterName = "TypeFundTransferDetail", Value = CreateDetailRows(fundTransferDetailRecord), SqlDbType = SqlDbType.Structured, TypeName = "dbo.typeFundTransferDetailV2" }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[InsFundTransferDetailV2]", _dataAccess.CreateConnection(), parameters))
            {
                if (!reader.Read())
                {
                    throw new Exception("No primary key returned for InsFundTransferDetail.");
                }

                return reader.GetInt64(reader.GetOrdinal("FundTransferDetailKey"));
            }
        }


        public decimal GetAchOutTransactionLimit(AccountIdentifier accountIdentifier, bool weeklyLimits, bool monthlyLimits)
        {
            var transClass = GetTransClassByTransClassCode("1-008");
            decimal amount = 0;
            DateTime startDateTime;
            if (weeklyLimits == true)
                startDateTime = DateTime.Now.AddDays(-7);
            else if (monthlyLimits == true)
                startDateTime = DateTime.Now.AddMonths(-1);
            else
                startDateTime = DateTime.Now.AddHours(-24);
            var parameters = new[]
            {
                new SqlParameter() {ParameterName = "AccountIdentifier", Value = accountIdentifier.ToGuid(), SqlDbType = SqlDbType.UniqueIdentifier},
                new SqlParameter(){ParameterName = "StartDate", Value = startDateTime, SqlDbType = SqlDbType.DateTime},
                new SqlParameter() {ParameterName = "EndDate", Value = DateTime.Now, SqlDbType = SqlDbType.DateTime },
                new SqlParameter() { ParameterName = "TransClassValue", Value = CreateFundTransferForTransClassRows(transClass.TransClassKey, TransferStatus.Completed).Convert(),  SqlDbType = SqlDbType.Structured, TypeName = "dbo.typeTransClassFundTransferStatus" }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetFundTransferDetailByTransClass]", _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    amount += Convert.ToDecimal(reader["TransactionAmount"]);
                }

                return amount;
            }
        }

        public long GetAchOutTransactionCount(AccountIdentifier accountIdentifier, DateTime startDateTime, DateTime endDateTime)
        {
            var transClass = GetTransClassByTransClassCode("1-008");
            var count = 0;
            var parameters = new[]
            {
                new SqlParameter() {ParameterName = "AccountIdentifier", Value = accountIdentifier.ToGuid(), SqlDbType = SqlDbType.UniqueIdentifier},
                new SqlParameter(){ParameterName = "StartDate", Value = startDateTime, SqlDbType = SqlDbType.DateTime},
                new SqlParameter() {ParameterName = "EndDate", Value = endDateTime, SqlDbType = SqlDbType.DateTime },
                new SqlParameter() { ParameterName = "TransClassValue", Value = CreateFundTransferForTransClassRows(transClass.TransClassKey, TransferStatus.Completed).Convert(),  SqlDbType = SqlDbType.Structured, TypeName = "dbo.typeTransClassFundTransferStatus" }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetFundTransferDetailByTransClass]", _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read()) count++;
            }

            return count;
        }

        public Dictionary<string, string> GetFundsTransferToken(List<string> transferReferenceIds)
        {
            Dictionary<string, string> transferIdentifiers = new Dictionary<string, string>();
            DataTable transferTable = new DataTable();
            transferTable.Columns.Add("UniqueID", typeof(Guid));
            foreach (var item in transferReferenceIds)
            {
                DataRow row = transferTable.NewRow();
                row[0] = item;
                transferTable.Rows.Add(row);
            }

            var parameters = new[]
            {
                new SqlParameter() {ParameterName = "TransactionReferenceID", Value = transferTable, SqlDbType = SqlDbType.Structured, TypeName = "typeUniqueIdentifiers"},
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetFundTransferByBatch]", _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    var transactionRefId = reader["TransactionReferenceID"].ToString();
                    var transferIdentifier = reader["FundTransferToken"].ToString();

                    transferIdentifiers.Add(transactionRefId.ToLower(), transferIdentifier);
                }
            }

            return transferIdentifiers;
        }

        private List<SqlDataRecord> CreateFundTransferForTransClassRows(int transClassKey, TransferStatus fundTransferStatusKey)
        {
            List<SqlDataRecord> returnValue = new List<SqlDataRecord>();

            SqlMetaData[] metadata = new SqlMetaData[2];

            metadata[0] = new SqlMetaData("TransClassKey", SqlDbType.Int);
            metadata[1] = new SqlMetaData("FundTransferStatusKey", SqlDbType.SmallInt);

            SqlDataRecord record = new SqlDataRecord(metadata);

            record.SetInt32(0, transClassKey);
            record.SetInt16(1, (short)fundTransferStatusKey);

            returnValue.Add(record);

            return returnValue;
        }

        private List<SqlDataRecord> CreateDetailRows(Transfer transfer)
        {
            List<SqlDataRecord> returnValue = new List<SqlDataRecord>();

            if (!transfer.IsReversal)
            {
                returnValue.Add(CreateFundTransferDetailRecord(transfer.Source));
                returnValue.Add(CreateFundTransferDetailRecord(transfer.Target));

            }
            else
            {
                returnValue.Add(CreateFundTransferDetailExecuteReversalRecord(transfer.Source));
                returnValue.Add(CreateFundTransferDetailExecuteReversalRecord(transfer.Target));
            }
            return returnValue;
        }

        private List<SqlDataRecord> CreateDetailRows(MrdcPartialTransfer transfer)
        {
            List<SqlDataRecord> returnValue = new List<SqlDataRecord>();

            if (!transfer.IsReversal)
            {
                returnValue.Add(CreateFundTransferDetailRecord(transfer.Source));

                foreach (var transferSubTarget in transfer.SubTargets)
                {
                    returnValue.Add(CreateFundTransferDetailRecord(transferSubTarget));
                }
            }
            else
            {
                returnValue.Add(CreateFundTransferDetailExecuteReversalRecord(transfer.Source));

                foreach (var transferSubTarget in transfer.SubTargets)
                {
                    returnValue.Add(CreateFundTransferDetailExecuteReversalRecord(transferSubTarget));
                }
            }

            return returnValue;
        }

        private List<SqlDataRecord> CreateDetailRows(WireOutTransfer transfer)
        {
            List<SqlDataRecord> returnValue = new List<SqlDataRecord>();

            if (!transfer.IsReversal)
            {
                returnValue.Add(CreateFundTransferDetailRecord(transfer.Fee));
                returnValue.Add(CreateFundTransferDetailRecord(transfer.Source));
                returnValue.Add(CreateFundTransferDetailRecord(transfer.Target));

            }
            else
            {
                returnValue.Add(CreateFundTransferDetailExecuteReversalRecord(transfer.Source));
                returnValue.Add(CreateFundTransferDetailExecuteReversalRecord(transfer.Fee));
            }
            return returnValue;
        }

        private List<SqlDataRecord> CreateDetailRows(EGiftTransfer transfer)
        {
            List<SqlDataRecord> returnValue = new List<SqlDataRecord>();

            if (!transfer.IsReversal)
            {
                if (transfer.Source2 != null)
                    returnValue.Add(CreateFundTransferDetailRecord(transfer.Source2));
                returnValue.Add(CreateFundTransferDetailRecord(transfer.Source));
                returnValue.Add(CreateFundTransferDetailRecord(transfer.Target));
                if (transfer.Target2 != null)
                    returnValue.Add(CreateFundTransferDetailRecord(transfer.Target2));
            }
            else
            {
                if (transfer.Source2 != null)
                    returnValue.Add(CreateFundTransferDetailExecuteReversalRecord(transfer.Source2));
                returnValue.Add(CreateFundTransferDetailExecuteReversalRecord(transfer.Source));
                returnValue.Add(CreateFundTransferDetailExecuteReversalRecord(transfer.Target));
                if (transfer.Target2 != null)
                    returnValue.Add(CreateFundTransferDetailExecuteReversalRecord(transfer.Target2));
            }
            return returnValue;
        }

        private List<SqlDataRecord> CreateDetailRows(SccBalanceSweepTransfer transfer)
        {
            List<SqlDataRecord> returnValue = new List<SqlDataRecord>();

            if (!transfer.IsReversal)
            {
                returnValue.Add(CreateFundTransferDetailRecord(transfer.Source));
                foreach (var source in transfer.OtherSources)
                {
                    returnValue.Add(CreateFundTransferDetailRecord(source));
                }

                if (transfer.Target != null)
                {
                    returnValue.Add(CreateFundTransferDetailRecord(transfer.Target));
                }

                foreach (var target in transfer.OtherTargets)
                {
                    returnValue.Add(CreateFundTransferDetailRecord(target));
                }
            }

            return returnValue;
        }

        private List<SqlDataRecord> CreateDetailRows(SccFundingTransfer transfer)
        {
            List<SqlDataRecord> returnValue = new List<SqlDataRecord>();

            if (!transfer.IsReversal)
            {
                returnValue.Add(CreateFundTransferDetailRecord(transfer.Source));
                returnValue.Add(CreateFundTransferDetailRecord(transfer.Target));
                returnValue.Add(CreateFundTransferDetailRecord(transfer.Target2));

            }
            else
            {
                returnValue.Add(CreateFundTransferDetailExecuteReversalRecord(transfer.Source));
                returnValue.Add(CreateFundTransferDetailExecuteReversalRecord(transfer.Target));
                returnValue.Add(CreateFundTransferDetailExecuteReversalRecord(transfer.Target2));
            }
            return returnValue;
        }

        private List<SqlDataRecord> CreateDetailRows(SccWithdrawalTransfer transfer)
        {
            List<SqlDataRecord> returnValue = new List<SqlDataRecord>();

            if (!transfer.IsReversal)
            {
                returnValue.Add(CreateFundTransferDetailRecord(transfer.Source));
                returnValue.Add(CreateFundTransferDetailRecord(transfer.Source2));
                returnValue.Add(CreateFundTransferDetailRecord(transfer.Target));

            }
            else
            {
                returnValue.Add(CreateFundTransferDetailExecuteReversalRecord(transfer.Source));
                returnValue.Add(CreateFundTransferDetailExecuteReversalRecord(transfer.Source2));
                returnValue.Add(CreateFundTransferDetailExecuteReversalRecord(transfer.Target));
            }
            return returnValue;
        }

        private List<SqlDataRecord> CreateDetailRows(IftTransfer transfer)
        {
            List<SqlDataRecord> returnValue = new List<SqlDataRecord>();

            if (!transfer.IsReversal)
            {
                returnValue.Add(CreateFundTransferDetailRecord(transfer.Source));
                returnValue.Add(CreateFundTransferDetailRecord(transfer.Target));
                returnValue.Add(CreateFundTransferDetailRecord(transfer.TargetFee));
            }
            else
            {
                returnValue.Add(CreateFundTransferDetailExecuteReversalRecord(transfer.Source));
                returnValue.Add(CreateFundTransferDetailExecuteReversalRecord(transfer.Target));
                returnValue.Add(CreateFundTransferDetailExecuteReversalRecord(transfer.TargetFee));
            }
            return returnValue;
        }

        private List<SqlDataRecord> CreateDetailRows(SqlDataRecord record)
        {
            List<SqlDataRecord> returnValue = new List<SqlDataRecord>();

            returnValue.Add(record);
            return returnValue;
        }

        private SqlDataRecord CreateFundTransferDetailRecord(TransferLeg transferLeg)
        {
            SqlDataRecord record = new SqlDataRecord(_typeFundTransferDetailMetadata);

            record.SetInt16(0, (short)transferLeg.Status);
            record.SetGuid(1, transferLeg.TransactionReferenceId.ToGuid());
            record.SetDecimal(2, transferLeg.Amount);
            record.SetBoolean(3, !transferLeg.IsCredit); // IsSource
            record.SetValue(7, null);
            record.SetBoolean(8, false); // IsReversal

            if (transferLeg.GetType() == typeof(AccountTransferLeg))
            {
                CreateFundTransferDetailRecord((AccountTransferLeg)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(ProgramFundingTransferLeg))
            {
                CreateFundTransferDetailRecord((ProgramFundingTransferLeg)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(AchTransferLeg))
            {
                CreateFundTransferDetailRecord((AchTransferLeg)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(RetailSaleTransferLeg))
            {
                CreateFundTransferDetailRecord((RetailSaleTransferLeg)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(AdjustmentTransferLeg))
            {
                CreateFundTransferDetailRecord((AdjustmentTransferLeg)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(PurseTransferLeg) || transferLeg.GetType() == typeof(CblPaymentByAchPurseTransferLeg))
            {
                CreateFundTransferDetailRecord((PurseTransferLeg)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(MrdcTransferLeg))
            {
                CreateFundTransferDetailRecord((MrdcTransferLeg)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(BillPayTransferLeg))
            {
                CreateFundTransferDetailRecord((BillPayTransferLeg)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(HandleTransferLeg))
            {
                CreateFundTransferDetailRecord((HandleTransferLeg)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(EGiftPurchase))
            {
                CreateFundTransferDetailRecord((EGiftPurchase)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(InstantFundTransferLeg))
            {
                CreateFundTransferDetailRecord((InstantFundTransferLeg)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(PointsSystemTransferLeg))
            {
                CreateFundTransferDetailRecord((PointsSystemTransferLeg)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(EGiftRewardsTransferLeg))
            {
                CreateFundTransferDetailRecord((AccountTransferLeg)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(WireTransferLeg))
            {
                CreateFundTransferDetailRecord((WireTransferLeg)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(SccFundingTransferLeg))
            {
                CreateFundTransferDetailRecord((SccFundingTransferLeg)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(EmptyTransferLeg))
            {
                CreateFundTransferDetailRecord((EmptyTransferLeg)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(MrdcPartialTransferLeg))
            {
                CreateFundTransferDetailRecord((MrdcPartialTransferLeg)transferLeg, record);
            }

            return record;
        }

        private SqlDataRecord CreateFundTransferDetailRecord(AccountTransferLeg transferLeg)
        {
            SqlDataRecord record = new SqlDataRecord(_typeFundTransferDetailMetadata);

            record.SetInt16(0, (short)transferLeg.Status);
            record.SetGuid(1, transferLeg.TransactionReferenceId.ToGuid());
            record.SetDecimal(2, transferLeg.Amount);
            record.SetBoolean(3, !transferLeg.IsCredit); // IsSource
            record.SetBoolean(8, false); // IsReversal

            var (identifierType, accountHolderIdentifier) = StatusMapper.GetIdentifierTypeAddValue(transferLeg);
            record.SetInt16(4, (short)transferLeg.TransClass.TransClassKey); // TransClassKey
            record.SetInt16(5, (short)identifierType);
            record.SetGuid(6, accountHolderIdentifier);
            if (!string.IsNullOrEmpty(transferLeg.AccountTransferEndpoint?.ExternalHandle))
            {
                record.SetValue(7, transferLeg.AccountTransferEndpoint.ExternalHandle);
            }
            return record;
        }

        private SqlDataRecord CreateFundTransferDetailExecuteReversalRecord(TransferLeg transferLeg)
        {
            SqlDataRecord record = new SqlDataRecord(_typeFundTransferDetailMetadata);

            record.SetInt16(0, (short)transferLeg.Status);
            record.SetGuid(1, transferLeg.TransactionReferenceId.ToGuid());
            record.SetDecimal(2, transferLeg.Amount);
            record.SetBoolean(3, !transferLeg.IsCredit); // IsSource
            record.SetBoolean(8, true); // IsReversal

            if (transferLeg.GetType() == typeof(AccountTransferLeg))
            {
                CreateFundTransferDetailReversalRecord((AccountTransferLeg)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(RetailSaleTransferLeg))
            {
                CreateFundTransferDetailReversalRecord((RetailSaleTransferLeg)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(EmptyTransferLeg))
            {
                CreateFundTransferDetailReversalRecord((EmptyTransferLeg)transferLeg, record);
            }
            else
            {
                throw new NotSupportedException();
            }

            return record;
        }

        private void CreateFundTransferDetailRecord(AccountTransferLeg transferLeg, SqlDataRecord record)
        {
            var (identifierType, accountHolderIdentifier) = StatusMapper.GetIdentifierTypeAddValue(transferLeg);
            record.SetInt16(4, (short)transferLeg.TransClass.TransClassKey); // TransClassKey
            record.SetInt16(5, (short)identifierType);
            record.SetGuid(6, accountHolderIdentifier);
            if (!string.IsNullOrEmpty(transferLeg.AccountTransferEndpoint?.ExternalHandle))
            {
                record.SetValue(7, transferLeg.AccountTransferEndpoint.ExternalHandle);
            }
        }

        private void CreateFundTransferDetailRecord(WireTransferLeg transferLeg, SqlDataRecord record)
        {
            record.SetInt16(4, (short)transferLeg.TransClass.TransClassKey); // TransClassKey
            record.SetInt16(5, (short)StatusMapper.GetIdentifierType(transferLeg));


            if (!string.IsNullOrEmpty(transferLeg.WireTransferEndpoint.WireRequest))
            {
                record.SetValue(7, transferLeg.WireTransferEndpoint.WireRequest);
            }
        }

        private void CreateFundTransferDetailRecord(SccFundingTransferLeg transferLeg, SqlDataRecord record)
        {
            record.SetInt16(4, (short)transferLeg.TransClass.TransClassKey); // TransClassKey
            record.SetInt16(5, (short)StatusMapper.GetIdentifierType(transferLeg));
            record.SetGuid(6, transferLeg.SccFundingTransferEndpoint.MultranAccountBalanceIdentifier.ToGuid());
        }

        private void CreateFundTransferDetailRecord(EGiftPurchase transferLeg, SqlDataRecord record)
        {
            record.SetInt16(4, (short)transferLeg.TransClass.TransClassKey); // TransClassKey 93
            record.SetInt16(5, (short)StatusMapper.GetIdentifierType(transferLeg));
            record.SetGuid(6, transferLeg.TargetAccountIdentifier.ToGuid());
            record.SetValue(7, transferLeg.Description); //ExternalIdentifier
        }

        private void CreateFundTransferDetailRecord(ProgramFundingTransferLeg transferLeg, SqlDataRecord record)
        {
            record.SetInt16(4, (short)transferLeg.TransClass.TransClassKey); // TransClassKey 1
            record.SetInt16(5, (short)StatusMapper.GetIdentifierType(transferLeg));
            record.SetGuid(6, transferLeg.ProgramFundingTransferEndpoint.ProgramFundingIdentifier.ToGuid());
        }


        private void CreateFundTransferDetailRecord(BillPayTransferLeg transferLeg, SqlDataRecord record)
        {
            //Records 0 to 4 are set above
            //record.SetInt16(0, 29); // FundTransferDetailStatusKey
            //record.SetGuid(1, transferLeg.TransactionReferenceId.ToGuid()); //TransactionReferenceID
            //record.SetSqlMoney(2, transferLeg.Amount); //FundDetailTransactionAmount
            //record.SetBoolean(3, false); //IsSource
            record.SetInt16(4, (short)transferLeg.TransClass.TransClassKey); // TransClassKey 29
            record.SetInt16(5, (short)StatusMapper.GetIdentifierType(transferLeg)); //IdentifierTypeKey
            //record.SetGuid(6, null); //Identifier
            if (!string.IsNullOrEmpty(transferLeg.PayeeName))
            {
                record.SetValue(7, transferLeg.PayeeName); //ExternalIdentifier
            }
        }

        private void CreateFundTransferDetailRecord(AchTransferLeg transferLeg, SqlDataRecord record)
        {
            record.SetInt16(4, (short)transferLeg.TransClass.TransClassKey); // TransClassKey 1
            record.SetInt16(5, (short)StatusMapper.GetIdentifierType(transferLeg));

            Domain.Model.Account.BankAccount bankAccount = new Domain.Model.Account.BankAccount
            {
                AccountNumber = transferLeg.AchTransferEndpoint.AccountNumber,
                RoutingNumber = transferLeg.AchTransferEndpoint.RoutingNumber,
                FirstName = transferLeg.AchTransferEndpoint.FirstName,
                LastName = transferLeg.AchTransferEndpoint.LastName,
                BankName = transferLeg.AchTransferEndpoint.BankName,
                AccountType = transferLeg.AchTransferEndpoint.AccountType,
                BusinessName = transferLeg.AchTransferEndpoint.BusinessName,
                BankAccountReferenceId = transferLeg.BankAccountReferenceId
            };

            JsonSerializer serializer = new JsonSerializer();

            StringWriter sw = new StringWriter();

            serializer.Serialize(sw, bankAccount);

            sw.Flush();

            record.SetValue(7, sw.ToString());
        }

        private void CreateFundTransferDetailRecord(RetailSaleTransferLeg transferLeg, SqlDataRecord record)
        {
            record.SetInt16(4, (short)transferLeg.TransClass.TransClassKey); // TransClassKey 2
            record.SetInt16(5, (short)StatusMapper.GetIdentifierType(transferLeg));

            RetailSaleData retailSaleData = new RetailSaleData
            {
                MerchantName = transferLeg.RetailSaleTransferEndpoint.MerchantName,
                StoreNumber = transferLeg.RetailSaleTransferEndpoint.StoreNumber,
                City = transferLeg.RetailSaleTransferEndpoint.City,
                State = transferLeg.RetailSaleTransferEndpoint.State
            };

            if (transferLeg.RetailSaleTransferEndpoint?.AccountIdentifier != null)
            {
                record.SetGuid(6, transferLeg.RetailSaleTransferEndpoint.AccountIdentifier.ToGuid());
            }

            JsonSerializer serializer = new JsonSerializer();

            StringWriter sw = new StringWriter();

            serializer.Serialize(sw, retailSaleData);

            sw.Flush();

            record.SetValue(7, sw.ToString());
        }

        private void CreateFundTransferDetailRecord(AdjustmentTransferLeg transferLeg, SqlDataRecord record)
        {
            record.SetInt16(4, (short)transferLeg.TransClass.TransClassKey); // TransClassKey 1
            record.SetInt16(5, (short)StatusMapper.GetIdentifierType(transferLeg));

            if (!string.IsNullOrEmpty(transferLeg.AdjustmentTransferEndpoint.AdjustmentData))
            {
                record.SetValue(7, transferLeg.AdjustmentTransferEndpoint.AdjustmentData);
            }
        }
        private void CreateFundTransferDetailRecord(PurseTransferLeg transferLeg, SqlDataRecord record)
        {
            record.SetInt16(4, (short)transferLeg.TransClass.TransClassKey); // TransClassKey
            record.SetInt16(5, (short)StatusMapper.GetIdentifierType(transferLeg));
            record.SetGuid(6, transferLeg.PurseTransferEndpoint.AccountBalanceIdentifier.ToGuid());
        }

        private void CreateFundTransferDetailRecord(MrdcTransferLeg transferLeg, SqlDataRecord record)
        {
            record.SetInt16(4, (short)transferLeg.TransClass.TransClassKey); // TransClassKey 2
            record.SetInt16(5, (short)StatusMapper.GetIdentifierType(transferLeg));

            Check check = new Check
            {
                FrontImage = "",//Empty the image is too big
                BackImage = "",
                ImageFormat = transferLeg.MrdcTransferEndpoint.Check.ImageFormat,
                Latitude = transferLeg.MrdcTransferEndpoint.Check.Latitude,
                Longitude = transferLeg.MrdcTransferEndpoint.Check.Longitude,
                DeviceInfo = transferLeg.MrdcTransferEndpoint.Check.DeviceInfo
            };

            JsonSerializer serializer = new JsonSerializer();

            StringWriter sw = new StringWriter();

            serializer.Serialize(sw, check);

            sw.Flush();

            record.SetValue(7, sw.ToString());
        }
        private void CreateFundTransferDetailRecord(HandleTransferLeg transferLeg, SqlDataRecord record)
        {
            record.SetInt16(4, (short)transferLeg.TransClass.TransClassKey); // TransClassKey
            record.SetInt16(5, (short)StatusMapper.GetIdentifierType(transferLeg));
            if (transferLeg.HandleTransferEndpoint != null && !string.IsNullOrEmpty(transferLeg.HandleTransferEndpoint.Handle))
            {
                record.SetValue(7, transferLeg.HandleTransferEndpoint.Handle);
            }
        }
        private void CreateFundTransferDetailRecord(InstantFundTransferLeg transferLeg, SqlDataRecord record)
        {
            record.SetInt16(4, (short)transferLeg.TransClass.TransClassKey); // TransClassKey 1
            record.SetInt16(5, (short)StatusMapper.GetIdentifierType(transferLeg));

            if (transferLeg.InstantFundTransferEndpoint.CardIdentifier != null)
            {
                record.SetGuid(6, transferLeg.InstantFundTransferEndpoint.CardIdentifier.ToGuid());
            }
        }

        private void CreateFundTransferDetailRecord(EmptyTransferLeg transferLeg, SqlDataRecord record)
        {
            record.SetInt16(4, (short)transferLeg.TransClass.TransClassKey); // TransClassKey 1
            record.SetInt16(5, (short)StatusMapper.GetIdentifierType(transferLeg));

            if (!string.IsNullOrEmpty(transferLeg.EmptyTransferEndpoint?.AccountIdentifier?.ToString()))
            {
                record.SetGuid(6, transferLeg.EmptyTransferEndpoint.AccountIdentifier.ToGuid());
            }

        }

        private void CreateFundTransferDetailRecord(PointsSystemTransferLeg transferLeg, SqlDataRecord record)
        {
            record.SetInt16(4, (short)transferLeg.TransClass.TransClassKey); // TransClassKey 1
            record.SetInt16(5, (short)StatusMapper.GetIdentifierType(transferLeg));
            record.SetGuid(6, transferLeg.GiftCardId); //identifier: giftcardid 
            record.SetValue(7, transferLeg.EGiftCatalogItem?.BrandName); //TODO: save required catalogitem fields in json


        }

        private SqlDataRecord CreateFundTransferDetailReversalRecord(TransferLeg transferLeg)
        {
            SqlDataRecord record = new SqlDataRecord(_typeFundTransferDetailMetadata);

            record.SetInt16(0, (short)transferLeg.ReversalStatus);
            record.SetGuid(1, transferLeg.ReversalTransactionReferenceId.ToGuid());
            record.SetDecimal(2, transferLeg.Amount);
            record.SetBoolean(3, !transferLeg.IsCredit); // IsSource
            record.SetBoolean(8, true); // IsReversal

            if (transferLeg.GetType() == typeof(AccountTransferLeg))
            {
                CreateFundTransferDetailReversalRecord((AccountTransferLeg)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(BillPayTransferLeg))
            {
                CreateFundTransferDetailReversalRecord((BillPayTransferLeg)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(InstantFundTransferLeg))
            {
                CreateFundTransferDetailReversalRecord((InstantFundTransferLeg)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(RetailSaleTransferLeg))
            {
                CreateFundTransferDetailReversalRecord((RetailSaleTransferLeg)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(ProgramFundingTransferLeg))
            {
                CreateFundTransferDetailReversalRecord((ProgramFundingTransferLeg)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(PointsSystemTransferLeg))
            {
                CreateFundTransferDetailReversalRecord((PointsSystemTransferLeg)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(EGiftPurchase))
            {
                CreateFundTransferDetailReversalRecord((EGiftPurchase)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(PurseTransferLeg))
            {
                CreateFundTransferDetailReversalRecord((PurseTransferLeg)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(AchTransferLeg))
            {
                CreateFundTransferDetailReversalRecord((AchTransferLeg)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(SccFundingTransferLeg))
            {
                CreateFundTransferDetailReversalRecord((SccFundingTransferLeg)transferLeg, record);
            }
            else if (transferLeg.GetType() == typeof(EmptyTransferLeg))
            {
                CreateFundTransferDetailReversalRecord((EmptyTransferLeg)transferLeg, record);
            }
            else
            {
                throw new NotSupportedException();
            }

            return record;
        }

        private SqlDataRecord CreateRewardsCreditFundTransferDetailRecord(AccountTransferLeg transferLeg)
        {
            var record = new SqlDataRecord(_typeFundTransferDetailMetadata);

            record.SetInt16(0, (short)transferLeg.Status);
            record.SetGuid(1, transferLeg.TransactionReferenceId.ToGuid());
            record.SetDecimal(2, transferLeg.Amount);
            record.SetBoolean(3, !transferLeg.IsCredit); // IsSource
            record.SetInt16(4, (short)transferLeg.TransClass.TransClassKey); // TransClassKey
            record.SetInt16(5, 1);
            record.SetGuid(6, transferLeg.TransferEndpoint.AccountIdentifier.ToGuid());
            record.SetValue(7, ((AccountTransferEndpoint)transferLeg.TransferEndpoint).ExternalHandle); // external identifier in fundtransferdetail
            record.SetBoolean(8, false); // IsReversal 
            return record;
        }

        private void CreateFundTransferDetailReversalRecord(AccountTransferLeg transferLeg, SqlDataRecord record)
        {
            var identifierTypeAddValue = StatusMapper.GetIdentifierTypeAddValue(transferLeg);
            record.SetInt16(4, (short)transferLeg.ReversalTransClass.TransClassKey); // TransClassKey
            record.SetInt16(5, (short)identifierTypeAddValue.Item1);
            record.SetGuid(6, identifierTypeAddValue.Item2);
        }
        private void CreateFundTransferDetailReversalRecord(RetailSaleTransferLeg transferLeg, SqlDataRecord record)
        {
            record.SetInt16(4, (short)transferLeg.ReversalTransClass.TransClassKey); // TransClassKey 1
            record.SetInt16(5, (short)StatusMapper.GetIdentifierType(transferLeg)); //retail type identifier

            RetailSaleData retailSaleData = new RetailSaleData
            {
                MerchantName = transferLeg.RetailSaleTransferEndpoint.MerchantName,
                StoreNumber = transferLeg.RetailSaleTransferEndpoint.StoreNumber,
                City = transferLeg.RetailSaleTransferEndpoint.City,
                State = transferLeg.RetailSaleTransferEndpoint.State
            };

            if (transferLeg.RetailSaleTransferEndpoint?.AccountIdentifier != null)
            {
                record.SetGuid(6, transferLeg.RetailSaleTransferEndpoint.AccountIdentifier.ToGuid());
            }

            JsonSerializer serializer = new JsonSerializer();

            StringWriter sw = new StringWriter();

            serializer.Serialize(sw, retailSaleData);

            sw.Flush();

            record.SetValue(7, sw.ToString());
        }
        private void CreateFundTransferDetailReversalRecord(PurseTransferLeg transferLeg, SqlDataRecord record)
        {
            record.SetInt16(4, (short)transferLeg.ReversalTransClass.TransClassKey); // TransClassKey
            record.SetInt16(5, (short)StatusMapper.GetIdentifierType(transferLeg));
            record.SetGuid(6, transferLeg.PurseTransferEndpoint.AccountBalanceIdentifier.ToGuid());
        }

        private void CreateFundTransferDetailReversalRecord(InstantFundTransferLeg transferLeg, SqlDataRecord record)
        {
            record.SetInt16(4, (short)transferLeg.ReversalTransClass.TransClassKey); // TransClassKey 2
            record.SetInt16(5, (short)StatusMapper.GetIdentifierType(transferLeg));

            if (transferLeg.InstantFundTransferEndpoint.CardIdentifier != null)
                record.SetGuid(6, transferLeg.InstantFundTransferEndpoint.CardIdentifier.ToGuid());
        }

        private void CreateFundTransferDetailReversalRecord(EmptyTransferLeg transferLeg, SqlDataRecord record)
        {
            record.SetInt16(4, (short)transferLeg.ReversalTransClass.TransClassKey);
            record.SetInt16(5, (short)StatusMapper.GetIdentifierType(transferLeg));
            if (!string.IsNullOrEmpty(transferLeg.EmptyTransferEndpoint?.AccountIdentifier?.ToString()))
            {
                record.SetGuid(6, transferLeg.EmptyTransferEndpoint.AccountIdentifier.ToGuid());
            }
        }

        private void CreateFundTransferDetailReversalRecord(BillPayTransferLeg transferLeg, SqlDataRecord record)
        {
            record.SetInt16(4, (short)transferLeg.ReversalTransClass.TransClassKey); // TransClassKey 32
            record.SetInt16(5, (short)StatusMapper.GetIdentifierType(transferLeg)); //IdentifierTypeKey
            if (!string.IsNullOrEmpty(transferLeg.PayeeName))
            {
                record.SetValue(7, transferLeg.PayeeName); //ExternalIdentifier
            }
        }
        private void CreateFundTransferDetailReversalRecord(ProgramFundingTransferLeg transferLeg, SqlDataRecord record)
        {
            record.SetInt16(4, (short)transferLeg.ReversalTransClass.TransClassKey); // TransClassKey 2
            record.SetInt16(5, (short)StatusMapper.GetIdentifierType(transferLeg)); //Account type identifier
            record.SetGuid(6, transferLeg.ProgramFundingTransferEndpoint.ProgramFundingIdentifier.ToGuid());
        }

        private void CreateFundTransferDetailReversalRecord(EGiftPurchase transferLeg, SqlDataRecord record)
        {
            record.SetInt16(4, (short)transferLeg.ReversalTransClass.TransClassKey); // TransClassKey 2
            record.SetInt16(5, (short)StatusMapper.GetIdentifierType(transferLeg)); //Account type identifier
            record.SetGuid(6, transferLeg.TargetAccountIdentifier.ToGuid());
            record.SetValue(7, transferLeg.Description); //ExternalIdentifier
        }

        private void CreateFundTransferDetailReversalRecord(PointsSystemTransferLeg transferLeg, SqlDataRecord record)
        {
            record.SetInt16(4, (short)transferLeg.ReversalTransClass.TransClassKey); // TransClassKey 2
            record.SetInt16(5, (short)StatusMapper.GetIdentifierType(transferLeg)); //Account type identifier
            record.SetGuid(6, transferLeg.GiftCardId); //identifier: giftcardid 
            record.SetValue(7, transferLeg.EGiftCatalogItem.BrandName); //TODO: save required catalogitem fields in json
        }

        private void CreateFundTransferDetailReversalRecord(AchTransferLeg transferLeg, SqlDataRecord record)
        {
            record.SetInt16(4, (short)transferLeg.ReversalTransClass.TransClassKey); // TransClassKey 2
            record.SetInt16(5, (short)StatusMapper.GetIdentifierType(transferLeg)); //Account type identifier

            Domain.Model.Account.BankAccount bankAccount = new Domain.Model.Account.BankAccount
            {
                AccountNumber = transferLeg.AchTransferEndpoint.AccountNumber,
                RoutingNumber = transferLeg.AchTransferEndpoint.RoutingNumber,
                FirstName = transferLeg.AchTransferEndpoint.FirstName,
                LastName = transferLeg.AchTransferEndpoint.LastName,
                BankName = transferLeg.AchTransferEndpoint.BankName,
                AccountType = transferLeg.AchTransferEndpoint.AccountType,
                BusinessName = transferLeg.AchTransferEndpoint.BusinessName,
                BankAccountReferenceId = transferLeg.BankAccountReferenceId
            };
            JsonSerializer serializer = new JsonSerializer();
            StringWriter sw = new StringWriter();
            serializer.Serialize(sw, bankAccount);
            sw.Flush();

            record.SetValue(7, sw.ToString());
        }
        private void CreateFundTransferDetailReversalRecord(SccFundingTransferLeg transferLeg, SqlDataRecord record)
        {
            var identifierTypeAddValue = StatusMapper.GetIdentifierTypeAddValue(transferLeg);
            record.SetInt16(4, (short)transferLeg.ReversalTransClass.TransClassKey); // TransClassKey
            record.SetInt16(5, (short)identifierTypeAddValue.Item1);
            record.SetGuid(6, identifierTypeAddValue.Item2);
        }

        private void CreateFundTransferDetailRecord(MrdcPartialTransferLeg transferLeg, SqlDataRecord record)
        {
            record.SetInt16(4, (short)transferLeg.TransClass.TransClassKey); // TransClassKey 2
            record.SetInt16(5, (short)StatusMapper.GetIdentifierType(transferLeg));

            Check check = new Check
            {
                FrontImage = "",//Empty the image is too big
                BackImage = "",
                ImageFormat = transferLeg.MrdcTransferEndpoint.Check.ImageFormat,
                Latitude = transferLeg.MrdcTransferEndpoint.Check.Latitude,
                Longitude = transferLeg.MrdcTransferEndpoint.Check.Longitude,
                DeviceInfo = transferLeg.MrdcTransferEndpoint.Check.DeviceInfo
            };

            JsonSerializer serializer = new JsonSerializer();

            StringWriter sw = new StringWriter();

            serializer.Serialize(sw, check);

            sw.Flush();

            record.SetValue(7, sw.ToString());
        }


        private static SqlMetaData[] CreateTypeFundTransferDetailMetadata()
        {
            SqlMetaData[] metadata = new SqlMetaData[9];

            metadata[0] = new SqlMetaData("FundTransferDetailStatusKey", SqlDbType.SmallInt);
            metadata[1] = new SqlMetaData("TransactionReferenceId", SqlDbType.UniqueIdentifier);
            metadata[2] = new SqlMetaData("FundDetailTransactionAmount", SqlDbType.Money);
            metadata[3] = new SqlMetaData("IsSource", SqlDbType.Bit);
            metadata[4] = new SqlMetaData("TransClassKey", SqlDbType.SmallInt);
            metadata[5] = new SqlMetaData("IdentifierTypeKey", SqlDbType.SmallInt);
            metadata[6] = new SqlMetaData("Identifier", SqlDbType.UniqueIdentifier);
            // this is actually defined as sql_variant in the schema, doesn't work on linux, faking it to be nvarchar
            metadata[7] = new SqlMetaData("ExternalIdentifier", SqlDbType.NVarChar, 400);
            metadata[8] = new SqlMetaData("IsReversal", SqlDbType.Bit);
            return metadata;
        }

        public Dictionary<string, TransClass> GetAllTransClasses()
        {
            if (_transClasses == null || DateTime.Now > _transClassesExpiration)
            {
                lock (_transClassesLockObject)
                {
                    if (_transClasses == null || DateTime.Now > _transClassesExpiration)
                    {
                        _transClasses = _cache?.Value?.Get<Dictionary<string, TransClass>>("TransClasses");

                        if (_transClasses == null)
                        {
                            _transClasses = new Dictionary<string, TransClass>();

                            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetTransClassList]", _dataAccess.CreateConnection()))
                            {
                                while (reader.Read())
                                {
                                    TransClass transClass = new TransClass(
                                        reader["TransClass"].ToString().Trim(),
                                        reader["TransClassDescription"].ToString().Trim(),
                                        Convert.ToBoolean(reader["IsCredit"]),
                                        Convert.ToBoolean(reader["IsAdjustable"]),
                                        Convert.ToBoolean(reader["IsReversal"]))
                                    {
                                        TransClassKey = Convert.ToInt16(reader["TransClassKey"])
                                    };

                                    if (!_transClasses.ContainsKey(transClass.Code))
                                    {
                                        _transClasses.Add(transClass.Code, transClass);
                                    }
                                }
                            }

                            _cache?.Value?.Set("TransClasses", _transClasses, _transClassesCacheTtl);
                        }

                        _transClassesExpiration = DateTime.Now + _transClassesLocalTtl;
                    }
                }
            }

            return _transClasses;
        }

        public TransClass GetTransClassByTransClassCode(string code)
        {
            var transClasses = GetAllTransClasses();

            if (!transClasses.ContainsKey(code))
            {
                throw new Exception($"No TransClass found matching code: {code}");
            }

            return transClasses[code];
        }

        public TransClass GetTransClassByTransClassKey(int transClassKey)
        {
            var transClasses = GetAllTransClasses();

            foreach (var currTransClass in transClasses.Values)
            {
                if (currTransClass.TransClassKey == transClassKey)
                {
                    return currTransClass;
                }
            }

            throw new Exception($"No TransClass found matching TransClassKey: {transClassKey}");
        }

        public Tuple<decimal, decimal> GetPeerPaymentTransferAmountRemaining(AccountIdentifier accountIdentifier, string programCode)
        {
            var allTransfers = new List<FundTransfer>();

            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "Identifier", Value = accountIdentifier.ToGuid(), SqlDbType = SqlDbType.UniqueIdentifier },
                new SqlParameter() {ParameterName = "FundTransferStatusKey" ,
                    Value = CreateTypeStatusKey().Convert(),
                    SqlDbType = SqlDbType.Structured , TypeName = "dbo.typeStatusKey"},
                new SqlParameter() { ParameterName = "StartDate", Value = DateTime.Now.AddDays(-7), SqlDbType = SqlDbType.DateTime2 },
                new SqlParameter() { ParameterName = "EndDate", Value = DateTime.Now, SqlDbType = SqlDbType.DateTime2 }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetFundTransferByIdentifierAndStatusV3]", _dataAccess.CreateConnection(), parameters.ToArray()))
            {
                while (reader.Read())
                {
                    var transferType = (TransferType)Enum.Parse(typeof(TransferType),
                            reader["FundTransferTypeKey"].ToString());
                    var transferDelayType = Int16.Parse(reader["FundTransferDelayTypeKey"].ToString());
                    var tran = new FundTransfer();
                    tran.InitiatorAccountIdentifier = reader["InitiatorAccountIdentifier"].ToString();
                    tran.FundTransferToken = reader["FundTransferToken"].ToString();
                    tran.IsSource = reader["IsSource"] == DBNull.Value
                        ? false
                        : bool.Parse(reader["IsSource"].ToString());
                    tran.AccountIdentifier = reader["Identifier"].ToString();
                    tran.TransferIdentifier = reader["FundTransferToken"].ToString();
                    tran.TransferStatus = (TransferStatus)Enum.Parse(typeof(TransferStatus),
                        reader["FundTransferStatusKey"].ToString());
                    tran.TransactionAmount = reader.GetDecimal(reader.GetOrdinal("TransactionAmount"));
                    tran.MobilePhoneNumber = reader["ExternalIdentifier"] == DBNull.Value ? null : reader["ExternalIdentifier"].ToString();
                    tran.Memo = reader["Memo"] == DBNull.Value ? null : reader["Memo"].ToString();

                    if (transferType == TransferType.PeerPayment || transferType == TransferType.ECashSend || transferType == TransferType.IFTSend)
                    {
                        allTransfers.Add(tran);
                    }
                }
            }

            decimal sumOfSentAmount = 0M;
            decimal sumOfReceivedAmount = 0M;

            foreach (var transfer in allTransfers)
            {
                if (!string.IsNullOrEmpty(transfer.AccountIdentifier) &&
                    transfer.AccountIdentifier == accountIdentifier && transfer.IsSource)
                {
                    sumOfSentAmount += transfer.TransactionAmount;
                }
                else if (!string.IsNullOrEmpty(transfer.AccountIdentifier) &&
                         transfer.AccountIdentifier == accountIdentifier &&
                         !transfer.IsSource &&
                         transfer.TransferStatus == TransferStatus.Completed)
                {
                    sumOfReceivedAmount += transfer.TransactionAmount;
                }
            }

            return new Tuple<decimal, decimal>(sumOfSentAmount, sumOfReceivedAmount);
        }

        public Tuple<decimal, decimal, int, int> GetPeerPaymentTransferAmountRemainingV2(AccountIdentifier accountIdentifier, string programCode, DateTime? startDate = null, DateTime? endDate = null)
        {
            var allTransfers = new List<FundTransfer>();

            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "Identifier", Value = accountIdentifier.ToGuid(), SqlDbType = SqlDbType.UniqueIdentifier },
                new SqlParameter() {ParameterName = "FundTransferStatusKey" ,
                    Value = CreateTypeStatusKey().Convert(),
                    SqlDbType = SqlDbType.Structured , TypeName = "dbo.typeStatusKey"},
                new SqlParameter() { ParameterName = "StartDate", Value = startDate ?? DateTime.Now.AddDays(-7), SqlDbType = SqlDbType.DateTime2 },
                new SqlParameter() { ParameterName = "EndDate", Value = endDate ?? DateTime.Now, SqlDbType = SqlDbType.DateTime2 }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetFundTransferByIdentifierAndStatusV3]", _dataAccess.CreateConnection(), parameters.ToArray()))
            {
                while (reader.Read())
                {
                    var transferType = (TransferType)Enum.Parse(typeof(TransferType),
                            reader["FundTransferTypeKey"].ToString());
                    var transferDelayType = Int16.Parse(reader["FundTransferDelayTypeKey"].ToString());
                    var tran = new FundTransfer();
                    tran.InitiatorAccountIdentifier = reader["InitiatorAccountIdentifier"].ToString();
                    tran.FundTransferToken = reader["FundTransferToken"].ToString();
                    tran.IsSource = reader["IsSource"] == DBNull.Value
                        ? false
                        : bool.Parse(reader["IsSource"].ToString());
                    tran.AccountIdentifier = reader["Identifier"].ToString();
                    tran.TransferIdentifier = reader["FundTransferToken"].ToString();
                    tran.TransferStatus = (TransferStatus)Enum.Parse(typeof(TransferStatus),
                        reader["FundTransferStatusKey"].ToString());
                    tran.TransactionAmount = reader.GetDecimal(reader.GetOrdinal("TransactionAmount"));
                    tran.MobilePhoneNumber = reader["ExternalIdentifier"] == DBNull.Value ? null : reader["ExternalIdentifier"].ToString();
                    tran.Memo = reader["Memo"] == DBNull.Value ? null : reader["Memo"].ToString();

                    if (transferType == TransferType.PeerPayment || transferType == TransferType.ECashSend || transferType == TransferType.IFTSend)
                    {
                        allTransfers.Add(tran);
                    }
                }
            }

            decimal sumOfSentAmount = 0M;
            decimal sumOfReceivedAmount = 0M;
            int sumOfSentCount = 0;
            int sumOfReceivedCount = 0;

            foreach (var transfer in allTransfers)
            {
                if (!string.IsNullOrEmpty(transfer.AccountIdentifier) &&
                    transfer.AccountIdentifier == accountIdentifier && transfer.IsSource)
                {
                    sumOfSentAmount += transfer.TransactionAmount;
                    sumOfSentCount++;
                }
                else if (!string.IsNullOrEmpty(transfer.AccountIdentifier) &&
                         transfer.AccountIdentifier == accountIdentifier &&
                         !transfer.IsSource &&
                         transfer.TransferStatus == TransferStatus.Completed)
                {
                    sumOfReceivedAmount += transfer.TransactionAmount;
                    sumOfReceivedCount++;
                }
            }

            return new Tuple<decimal, decimal, int, int>(sumOfSentAmount, sumOfReceivedAmount, sumOfSentCount, sumOfReceivedCount);
        }

        public Tuple<decimal, decimal, decimal, decimal> GetIFTAmountRemaining(AccountIdentifier accountIdentifier, string programCode)
        {
            var allTransfers = new List<FundTransfer>();

            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "InitiatorAccountIdentifier", Value = accountIdentifier.ToGuid(), SqlDbType = SqlDbType.UniqueIdentifier },
                new SqlParameter() {ParameterName = "FundTransferStatusKey" ,
                    Value = CreateTypeStatusKey().Convert(),
                    SqlDbType = SqlDbType.Structured , TypeName = "dbo.typeStatusKey"},
                new SqlParameter() { ParameterName = "StartDate", Value = DateTime.Now.AddDays(-7), SqlDbType = SqlDbType.DateTime2 },
                new SqlParameter() { ParameterName = "EndDate", Value = DateTime.Now, SqlDbType = SqlDbType.DateTime2 }
            };

            decimal sumOfSentAmount = 0M;
            decimal sumOfReceivedAmount = 0M;
            decimal sumOfP2PSentAmount = 0M;
            decimal sumOfP2PReceivedAmount = 0M;

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetFundTransferByInitiatorAccountIdentifier]", _dataAccess.CreateConnection(), parameters.ToArray()))
            {
                while (reader.Read())
                {
                    var transferType = (TransferType)Enum.Parse(typeof(TransferType),
                            reader["FundTransferTypeKey"].ToString());
                    var transferDelayType = Int16.Parse(reader["FundTransferDelayTypeKey"].ToString());
                    var tran = new FundTransfer();
                    tran.InitiatorAccountIdentifier = reader["InitiatorAccountIdentifier"].ToString();
                    tran.FundTransferToken = reader["FundTransferToken"].ToString();
                    tran.IsSource = reader["IsSource"] == DBNull.Value
                        ? false
                        : bool.Parse(reader["IsSource"].ToString());
                    tran.AccountIdentifier = reader["Identifier"].ToString();
                    tran.TransferIdentifier = reader["FundTransferToken"].ToString();
                    tran.TransferStatus = (TransferStatus)Enum.Parse(typeof(TransferStatus),
                        reader["FundTransferStatusKey"].ToString());
                    tran.TransactionAmount = reader.GetDecimal(reader.GetOrdinal("TransactionAmount"));
                    tran.MobilePhoneNumber = reader["ExternalIdentifier"] == DBNull.Value ? null : reader["ExternalIdentifier"].ToString();
                    tran.Memo = reader["Memo"] == DBNull.Value ? null : reader["Memo"].ToString();
                    tran.TransferType = transferType.GetDescription()?.ToLower();

                    if ((transferType == TransferType.IFTLoad || transferType == TransferType.IFTSend) && tran.IsSource)
                    {
                        sumOfSentAmount += tran.TransactionAmount;
                    }

                    if ((transferType == TransferType.IFTSend) && tran.IsSource)
                    {
                        sumOfP2PSentAmount += tran.TransactionAmount;
                    }

                    if ((transferType == TransferType.ECashSend || transferType == TransferType.PeerPayment) &&
                        !string.IsNullOrEmpty(tran.AccountIdentifier) &&
                         tran.AccountIdentifier == accountIdentifier && tran.IsSource)
                    {
                        sumOfP2PSentAmount += tran.TransactionAmount;
                    }

                    if ((transferType == TransferType.ECashSend || transferType == TransferType.PeerPayment) &&
                        !string.IsNullOrEmpty(tran.AccountIdentifier) &&
                        tran.AccountIdentifier == accountIdentifier && !tran.IsSource && tran.TransferStatus == TransferStatus.Completed)
                    {
                        sumOfP2PReceivedAmount += tran.TransactionAmount;
                    }

                    if (transferType == TransferType.IFTOut && tran.IsSource
                    && tran.TransferStatus == TransferStatus.Completed)
                    {
                        sumOfReceivedAmount += tran.TransactionAmount;
                    }
                }


            }

            return new Tuple<decimal, decimal, decimal, decimal>(sumOfSentAmount, sumOfReceivedAmount, sumOfP2PSentAmount, sumOfP2PReceivedAmount);
        }

        public List<TransferTypeToFeature> GetAllTransferTypeToFeature()
        {
            var transferTypeToFeatureMap = new List<TransferTypeToFeature>();

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAllFundTransferType_Feature]", _dataAccess.CreateConnection()))
            {
                while (reader.Read())
                {
                    transferTypeToFeatureMap.Add(new TransferTypeToFeature()
                    {
                        FeatureType = (Shared.Common.Logic.FeatureLimitsFees.Contract.Enum.FeatureType)Convert.ToInt16(reader["FeatureKey"].ToString()),
                        TransferType = (Shared.Common.Core.CoreApi.Contract.Data.Enum.TransferType)Convert.ToInt16(reader["FundTransferTypeKey"].ToString())
                    });
                }
                return transferTypeToFeatureMap;
            }
        }

        public FundTransfer GetSuccessfulAchPullTransfer(AccountIdentifier accountIdentifier, DateTime? activationDate)
        {
            var tran = new FundTransfer();
            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "Identifier", Value = accountIdentifier.ToGuid(), SqlDbType = SqlDbType.UniqueIdentifier},
                new SqlParameter() {ParameterName = "FundTransferStatusKey" ,  Value = CreateTypeStatusKey().Convert(),  SqlDbType = SqlDbType.Structured , TypeName = "dbo.typeStatusKey"},
                new SqlParameter() { ParameterName = "FundTransferTypeKey", Value = 7, SqlDbType = SqlDbType.SmallInt },
                new SqlParameter() { ParameterName = "StartDate", Value = activationDate, SqlDbType = SqlDbType.DateTime },
                new SqlParameter() { ParameterName = "EndDate", Value = DateTime.Now, SqlDbType = SqlDbType.DateTime }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetFundTransferByIdentifierAndStatusV3]",
                _dataAccess.CreateConnection(), parameters.ToArray()))
            {
                while (reader.Read())
                {
                    tran.TransferStatus = (TransferStatus)Enum.Parse(typeof(TransferStatus),
                        reader["FundTransferStatusKey"].ToString());
                    if (tran.TransferStatus == TransferStatus.Completed)
                    {
                        tran.TransactionDate = reader.GetDateTime(reader.GetOrdinal("TransactionDate"));
                        return tran;
                    }
                }
            }

            return null;
        }

        public bool CheckPendingAchPullTransfer(AccountIdentifier accountIdentifier, DateTime? activationDate)
        {
            var tran = new FundTransfer();
            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "Identifier", Value = accountIdentifier.ToGuid(), SqlDbType = SqlDbType.UniqueIdentifier},
                new SqlParameter() {ParameterName = "FundTransferStatusKey" ,  Value = CreateTypeStatusKey().Convert(),  SqlDbType = SqlDbType.Structured , TypeName = "dbo.typeStatusKey"},
                new SqlParameter() { ParameterName = "FundTransferTypeKey", Value = 7, SqlDbType = SqlDbType.SmallInt },
                new SqlParameter() { ParameterName = "StartDate", Value = activationDate, SqlDbType = SqlDbType.DateTime },
                new SqlParameter() { ParameterName = "EndDate", Value = DateTime.Now, SqlDbType = SqlDbType.DateTime }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetFundTransferByIdentifierAndStatusV3]",
                _dataAccess.CreateConnection(), parameters.ToArray()))
            {
                while (reader.Read())
                {
                    tran.TransferStatus = (TransferStatus)Enum.Parse(typeof(TransferStatus),
                        reader["FundTransferStatusKey"].ToString());
                }
            }

            return tran.TransferStatus == TransferStatus.Pending;
        }

        public TransferStatus ChecksStatusCreditLineDecreaseEligibility(AccountIdentifier accountIdentifier, int days = -30)
        {
            var startDate = DateTime.Today.AddDays(days);
            var endDate = DateTime.Today.AddDays(1);
            var tran = new FundTransfer();
            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "Identifier", Value = accountIdentifier.ToGuid(), SqlDbType = SqlDbType.UniqueIdentifier},
                new SqlParameter() {ParameterName = "FundTransferStatusKey" ,  Value = CreateTypeStatusKey().Convert(),  SqlDbType = SqlDbType.Structured , TypeName = "dbo.typeStatusKey"},
                new SqlParameter() { ParameterName = "FundTransferTypeKey", Value = (short)TransferType.CreditLineDecrease, SqlDbType = SqlDbType.SmallInt },
                new SqlParameter() { ParameterName = "StartDate", Value = startDate, SqlDbType = SqlDbType.DateTime },
                new SqlParameter() { ParameterName = "EndDate", Value = endDate, SqlDbType = SqlDbType.DateTime }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetFundTransferByIdentifierAndStatusV3]",
                _dataAccess.CreateConnection(), parameters.ToArray()))
            {
                while (reader.Read())
                {
                    tran.TransferStatus = (TransferStatus)Enum.Parse(typeof(TransferStatus),
                        reader["FundTransferStatusKey"].ToString());
                }
            }

            return tran.TransferStatus;
        }

        ///// <summary>
        /////  Adds each dollar amount of every ach pull transaction from the specified dates.
        ///// </summary>
        ///// <param name="accountIdentifier"></param>
        ///// <param name="startDate"></param> Starting transfer date
        ///// <param name="endDate"></param> Ending transfer date
        ///// <returns></returns>
        //public decimal GetAchPullTransactionAmount(AccountIdentifier accountIdentifier, DateTime startDate, DateTime endDate)
        //{
        //    decimal amount = 0;

        //    var parameters = new[]
        //    {
        //        new SqlParameter() { ParameterName = "AccountIdentifier", Value = accountIdentifier.ToGuid(), SqlDbType = SqlDbType.UniqueIdentifier },
        //        new SqlParameter() { ParameterName = "StartTime", Value = startDate, SqlDbType = SqlDbType.DateTime },
        //        new SqlParameter() { ParameterName = "EndTime", Value = endDate, SqlDbType = SqlDbType.DateTime },
        //        new SqlParameter() { ParameterName = "FundTransferTypeKey", Value = 7, SqlDbType = SqlDbType.SmallInt }
        //    };

        //    using (var reader = _dataAccess.ExecuteReader("[dbo].[GetFundTransferByAccountIdentifier]", _dataAccess.CreateConnection(), parameters.ToArray()))
        //    {
        //        while (reader.Read())
        //        {
        //            bool isSource = reader.GetBoolean(reader.GetOrdinal("IsSource"));
        //            var transferStatus = (TransferStatus)Enum.Parse(typeof(TransferStatus),
        //                reader["FundTransferStatusKey"].ToString());
        //            if (isSource && (transferStatus == TransferStatus.Completed || transferStatus == TransferStatus.Pending))
        //                amount += Convert.ToDecimal(reader["TransactionAmount"]);
        //        }

        //        return amount;
        //    }
        //}  

        /// <summary>
        ///  Get all ach pull transactions from the specified dates.
        /// </summary>
        /// <param name="accountIdentifier"></param>
        /// <param name="startDate"></param> Starting transfer date
        /// <param name="endDate"></param> Ending transfer date
        /// <returns></returns>
        public List<Tuple<DateTime, decimal>> GetAchPullTransactions(AccountIdentifier accountIdentifier, DateTime startDate, DateTime endDate)
        {
            var transactions = new List<Tuple<DateTime, decimal>>();

            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "AccountIdentifier", Value = accountIdentifier.ToGuid(), SqlDbType = SqlDbType.UniqueIdentifier },
                new SqlParameter() { ParameterName = "StartTime", Value = startDate, SqlDbType = SqlDbType.DateTime },
                new SqlParameter() { ParameterName = "EndTime", Value = endDate, SqlDbType = SqlDbType.DateTime },
                new SqlParameter() { ParameterName = "FundTransferTypeKey", Value = 7, SqlDbType = SqlDbType.SmallInt }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetFundTransferByAccountIdentifier]", _dataAccess.CreateConnection(), parameters.ToArray()))
            {
                while (reader.Read())
                {
                    var isSource = reader.GetBoolean(reader.GetOrdinal("IsSource"));
                    var transferStatus = (TransferStatus)Enum.Parse(typeof(TransferStatus),
                        reader["FundTransferStatusKey"].ToString());
                    if (isSource && (transferStatus == TransferStatus.Completed || transferStatus == TransferStatus.Pending))
                    {
                        var transactionDate = Convert.ToDateTime(reader["TransactionDate"]);
                        var amount = Convert.ToDecimal(reader["TransactionAmount"]);
                        transactions.Add(new Tuple<DateTime, decimal>(transactionDate, amount));
                    }
                }

                return transactions;
            }
        }

        public List<WireTransferData> GetWires(int transferStatusKey, DateTime? startDate, DateTime? endDate, int? transferStatusReasonKey)
        {
            var transfers = new List<WireTransferData>();

            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "FundTransferStatusKey", Value = transferStatusKey, SqlDbType = SqlDbType.SmallInt },
                new SqlParameter() { ParameterName = "StartDate", Value = startDate == null? DBNull.Value : (object)startDate, SqlDbType = SqlDbType.DateTime },
                new SqlParameter() { ParameterName = "EndDate", Value = endDate == null ? DBNull.Value : (object)endDate, SqlDbType = SqlDbType.DateTime },
                new SqlParameter() { ParameterName = "FundTransferStatusReasonKey", Value = transferStatusReasonKey, SqlDbType = SqlDbType.SmallInt },
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetWiresFundTransfer]", _dataAccess.CreateConnection(), parameters.ToArray()))
            {
                while (reader.Read())
                {
                    var transfer = new WireTransferData
                    {
                        AccountIdentifier = reader["InitiatorAccountIdentifier"] == DBNull.Value ? null : reader["InitiatorAccountIdentifier"].ToString(),
                        CreateDate = reader["CreateDate"] == DBNull.Value ? (DateTime?)null : reader.GetDateTime(reader.GetOrdinal("CreateDate")),
                        ChangeDate = reader["ChangeDate"] == DBNull.Value ? (DateTime?)null : reader.GetDateTime(reader.GetOrdinal("ChangeDate")),
                        TransferIdentifier = reader["FundTransferToken"] == DBNull.Value ? null : reader["FundTransferToken"].ToString(),
                        Status = (FundTransferStatus)Enum.Parse(typeof(FundTransferStatus), reader["FundTransferStatusKey"].ToString()),
                        Currency = (Currency)Enum.Parse(typeof(Currency), reader["CurrencyKey"].ToString()),
                        Amount = reader["TransactionAmount"] == DBNull.Value ? (decimal?)null : reader.GetDecimal(reader.GetOrdinal("TransactionAmount")),
                        ExternalIdentifier = reader["ExternalIdentifier"] == DBNull.Value ? null : reader["ExternalIdentifier"].ToString(),
                        Memo = reader["Memo"] == DBNull.Value ? null : reader["Memo"].ToString(),
                        AccountNumber = reader["AccountNumber"] == DBNull.Value ? null : reader["AccountNumber"].ToString(),
                        FirstName = reader["FirstName"] == DBNull.Value ? null : reader["FirstName"].ToString(),
                        LastName = reader["LastName"] == DBNull.Value ? null : reader["LastName"].ToString(),
                        AddressLine1 = reader["Address1"] == DBNull.Value ? null : reader["Address1"].ToString(),
                        AddressLine2 = reader["Address2"] == DBNull.Value ? null : reader["Address2"].ToString(),
                        City = reader["City"] == DBNull.Value ? null : reader["City"].ToString(),
                        State = reader["State"] == DBNull.Value ? null : reader["State"].ToString(),
                        ZipCode = reader["ZipCode"] == DBNull.Value ? null : reader["ZipCode"].ToString()
                    };
                    transfers.Add(transfer);
                }

                return transfers;
            }
        }

        public bool WasNotCompletedAchLastNDays(AccountIdentifier accountIdentifier, int days = 5)
        {
            var dateStart = DateTime.Now.AddDays(-days);
            var transfers = GetFundTransferByIdentifierAndStatusV3(accountIdentifier.ToGuid(), TransferType.AchPull, dateStart, DateTime.Now);

            var transfer = transfers.OrderBy(t => t.TransactionDate).FirstOrDefault(t => t.TransferStatus != TransferStatus.Completed);

            if (null != transfer)
            {
                _logger.Info($"There is a not completed transfer starting from {dateStart} for account id: {accountIdentifier}, FundTransferKey={transfer.FundTransferKey}, FundTransferKey={transfer.FundTransferToken}, TransferStatus={transfer.TransferStatus}");
                return true;
            }

            return false;
        }

        public DateTime? FindEarliestActivationDateFromPaymentInstruments(AccountIdentifier accountIdentifier)
        {
            DateTime? activationDate = null;
            var paymentInstruments = new List<PaymentInstrumentLight>();

            var parameters = new[] {
                    new SqlParameter() { ParameterName = "AccountIdentifier", Value = accountIdentifier.ToGuid(), SqlDbType = SqlDbType.UniqueIdentifier},
                };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetPaymentInstrumentInfoCustomerInfoByAccountIdentifier]",
               _dataAccess.CreateConnection(), parameters.ToArray()))
            {
                while (reader.Read())
                {
                    var paymentInstrument = new PaymentInstrumentLight
                    {
                        PaymentIdentifier = Cast<Guid>(reader["PaymentIdentifier"]).ToString(),
                        PaymentInstrumentIdentifier = Cast<Guid>(reader["PaymentInstrumentIdentifier"]).ToString(),
                        PaymentInstrumentType = (PaymentInstrumentType)Cast<short>(reader["PaymentInstrumentTypeKey"]),
                    };

                    paymentInstrument.IssuedDateTime = Cast<DateTime?>(reader["IssuedDateTime"]);
                    paymentInstrument.ActivatedDateTime = Cast<DateTime?>(reader["ActivationDate"]);

                    paymentInstruments.Add(paymentInstrument);
                }
            }

            // https://pd.nextestate.com/browse/GBOS-43272 find earliest activation date that's not null
            var earliestCard = paymentInstruments.Where(x => x.ActivatedDateTime != null).OrderBy(y => y.ActivatedDateTime).FirstOrDefault();

            if (earliestCard != null)
            {
                activationDate = earliestCard.ActivatedDateTime;
                _logger.Info($"Retrieving Earliest Activation Date: AcountIdentifier={accountIdentifier}, ActivationDate={activationDate}, PaymentInstrument used={earliestCard.PaymentInstrumentIdentifier}, Type={earliestCard.PaymentInstrumentType}");
            }
            else
            {
                _logger.Info($"No PaymentInstrument with a non null ActivationDate found: AcountIdentifier={accountIdentifier}");
            }

            return activationDate;
        }

        private DateTime? FindCreateDate(AccountIdentifier accountIdentifier, string programCode)
        {
            DateTime? activationDate = null;

            // check if delayed funding
            if (_baasConfiguration.DelaySetBillCycleDayToFirstFunding(programCode))
            {
                // if delayed funding, take the create date            
                activationDate = FindEarliestActivationDateFromPaymentInstruments(accountIdentifier);
            }

            // if nothing else available, take the account create date (the case where no delayed funding)
            if (activationDate == null)
                activationDate = _accountRepository.GetAccountInfoByAccountIdentifier(accountIdentifier).ActivationDate;

            return activationDate;
        }

        private static T Cast<T>(object value)
        {
            if (value == DBNull.Value || value == null)
                return default(T);

            return (T)value;
        }

        public Tuple<DateTime?, bool, decimal, decimal, decimal> GetAchInitialTransferDateAndAmountUsed(AccountIdentifier accountIdentifier, string programCode = "test", TransferType fundTransferType = TransferType.AchPull)
        {
            DateTime? activationDate = FindCreateDate(accountIdentifier, programCode);

            if (null == activationDate)
                return new Tuple<DateTime?, bool, decimal, decimal, decimal>(activationDate, false, 0, 0, 0);

            activationDate = activationDate.Value.AddMinutes(-1);

            _logger.Info($"Calling stored proc GetFundTransferByIdentifierAndStatusV3 for account id: {accountIdentifier}, startDate={activationDate}, transferType={fundTransferType}");

            var transfers = GetFundTransferByIdentifierAndStatusV3(accountIdentifier.ToGuid(), fundTransferType, activationDate.Value, DateTime.Now);
            var firstTransfer = transfers.OrderBy(t => t.TransactionDate).FirstOrDefault(t => t.TransferStatus == TransferStatus.Completed);

            var completed = false;
            if (null == firstTransfer)
            {
                firstTransfer = transfers.OrderBy(t => t.TransactionDate).FirstOrDefault(t => t.TransferStatus == TransferStatus.Pending);
            }
            else
            {
                completed = true;
            }
            if (null == firstTransfer)
            {
                return new Tuple<DateTime?, bool, decimal, decimal, decimal>(null, false, 0, 0, 0);
            }

            var transferAmountPast24Hours = transfers.Where(it => it.TransactionDate > DateTime.Now.AddDays(-1)).Sum(it => it.TransactionAmount);
            var totalTransferAmountPastWeek = transfers.Where(it => it.TransactionDate > DateTime.Now.AddDays(-7)).Sum(it => it.TransactionAmount);

            _logger.Info($"account id: {accountIdentifier},  StartDate={DateTime.Now.AddDays(-30)}");
            var totalTransferAmountPastThirtyDays = transfers.Where(it => it.TransactionDate > DateTime.Now.AddDays(-30)).Sum(it => it.TransactionAmount);
            _logger.Info($"account id: {accountIdentifier}, totalTransferAmountPastThirtyDays={totalTransferAmountPastThirtyDays}, StartDate={DateTime.Now.AddDays(-30)}");


            _logger.Info($"firstTransfer not null,{transferAmountPast24Hours}");
            return new Tuple<DateTime?, bool, decimal, decimal, decimal>(firstTransfer.TransactionDate, completed, transferAmountPast24Hours, totalTransferAmountPastWeek, totalTransferAmountPastThirtyDays);
        }

        public Tuple<DateTime?, bool, decimal, decimal, decimal, int, int> GetAchTransferData(AccountIdentifier accountIdentifier, string programCode = "test", TransferType fundTransferType = TransferType.AchPull)
        {
            DateTime? activationDate = FindCreateDate(accountIdentifier, programCode);

            if (null == activationDate)
                return new Tuple<DateTime?, bool, decimal, decimal, decimal, int, int>(activationDate, false, 0, 0, 0, 0, 0);

            activationDate = activationDate.Value.AddMinutes(-1);

            _logger.Info($"Calling stored proc GetFundTransferByIdentifierAndStatusV3 for account id: {accountIdentifier}, startDate={activationDate}, transferType={fundTransferType}");

            var transfers = GetFundTransferByIdentifierAndStatusV3(accountIdentifier.ToGuid(), fundTransferType, activationDate.Value, DateTime.Now);
            var firstTransfer = transfers.OrderBy(t => t.TransactionDate).FirstOrDefault(t => t.TransferStatus == TransferStatus.Completed);

            var completed = false;
            if (null == firstTransfer)
            {
                firstTransfer = transfers.OrderBy(t => t.TransactionDate).FirstOrDefault(t => t.TransferStatus == TransferStatus.Pending);
            }
            else
            {
                completed = true;
            }
            if (null == firstTransfer)
            {
                return new Tuple<DateTime?, bool, decimal, decimal, decimal, int, int>(null, false, 0, 0, 0, 0, 0);
            }

            var transferAmountPast24Hours = transfers.Where(it => it.TransactionDate > DateTime.Now.AddDays(-1)).Sum(it => it.TransactionAmount);
            var transferCountPast24Hours = transfers.Where(it => it.TransactionDate > DateTime.Now.AddDays(-1)).Count();

            var totalTransferAmountPastWeek = transfers.Where(it => it.TransactionDate > DateTime.Now.AddDays(-7)).Sum(it => it.TransactionAmount);

            _logger.Info($"account id: {accountIdentifier},  StartDate={DateTime.Now.AddDays(-30)}");
            var totalTransferAmountPastThirtyDays = transfers.Where(it => it.TransactionDate > DateTime.Now.AddDays(-30)).Sum(it => it.TransactionAmount);
            var totalTransferCountPastThirtyDays = transfers.Where(it => it.TransactionDate > DateTime.Now.AddDays(-30)).Count();
            _logger.Info($"account id: {accountIdentifier}, totalTransferAmountPastThirtyDays={totalTransferAmountPastThirtyDays}, StartDate={DateTime.Now.AddDays(-30)}, totalTransferCountPastThirtyDays={totalTransferCountPastThirtyDays}");


            _logger.Info($"firstTransfer not null,{transferAmountPast24Hours}");
            return new Tuple<DateTime?, bool, decimal, decimal, decimal, int, int>(firstTransfer.TransactionDate, completed, transferAmountPast24Hours, totalTransferAmountPastWeek, totalTransferAmountPastThirtyDays, transferCountPast24Hours, totalTransferCountPastThirtyDays);
        }

        private List<FundTransfer> GetFundTransferByIdentifierAndStatusV3(Guid accountIdentifier, TransferType transferType, DateTime start, DateTime end)
        {
            var transfers = new List<FundTransfer>();
            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "Identifier", Value = accountIdentifier, SqlDbType = SqlDbType.UniqueIdentifier},
                new SqlParameter() {ParameterName = "FundTransferStatusKey" ,  Value = CreateTypeStatusKey().Convert(),  SqlDbType = SqlDbType.Structured , TypeName = "dbo.typeStatusKey"},
                new SqlParameter() { ParameterName = "FundTransferTypeKey", Value = transferType, SqlDbType = SqlDbType.SmallInt },
                new SqlParameter() { ParameterName = "StartDate", Value = start, SqlDbType = SqlDbType.DateTime },
                new SqlParameter() { ParameterName = "EndDate", Value = end, SqlDbType = SqlDbType.DateTime }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetFundTransferByIdentifierAndStatusV3]",
                _dataAccess.CreateConnection(), parameters.ToArray()))
            {
                while (reader.Read())
                {
                    var tran = new FundTransfer
                    {
                        TransferType = reader["FundTransferTypeKey"].ToString(),
                        TransactionDate = DateTime.Parse(reader["TransactionDate"].ToString()),
                        InitiatorAccountIdentifier = reader["InitiatorAccountIdentifier"].ToString(),
                        FundTransferToken = reader["FundTransferToken"].ToString(),
                        IsSource = reader["IsSource"] != DBNull.Value && bool.Parse(reader["IsSource"].ToString()),
                        AccountIdentifier = reader["Identifier"].ToString(),
                        TransferIdentifier = reader["FundTransferToken"].ToString(),
                        TransferStatus = (TransferStatus)Enum.Parse(typeof(TransferStatus), reader["FundTransferStatusKey"].ToString()),
                        TransactionAmount = reader.GetDecimal(reader.GetOrdinal("TransactionAmount")),
                        Memo = reader["Memo"] == DBNull.Value ? null : reader["Memo"].ToString()
                    };

                    if (tran.IsSource)
                    {
                        transfers.Add(tran);
                    }
                }
            }

            return transfers;
        }

        public List<FundTransfer> GetFundTransfersByAccountIdentifier(AccountIdentifier accountIdentifier, DateTime startDate,
            DateTime endDate, TransferType fundTransferType)
        {
            var transactions = new List<FundTransfer>();

            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "@AccountIdentifier", Value = accountIdentifier.ToGuid(), SqlDbType = SqlDbType.UniqueIdentifier },
                new SqlParameter() { ParameterName = "StartTime", Value = startDate, SqlDbType = SqlDbType.DateTime },
                new SqlParameter() { ParameterName = "EndTime", Value = endDate, SqlDbType = SqlDbType.DateTime },
                new SqlParameter() { ParameterName = "FundTransferTypeKey", Value = fundTransferType== TransferType.None ? DBNull.Value : (object)(short)fundTransferType }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetFundTransferByAccountIdentifier]", _dataAccess.CreateConnection(), parameters.ToArray()))
            {
                while (reader.Read())
                {
                    var fundTransfer = new FundTransfer
                    {
                        IsSource = reader.GetBoolean(reader.GetOrdinal("IsSource")),
                        TransferStatus = (TransferStatus)Enum.Parse(typeof(TransferStatus),
                        reader["FundTransferStatusKey"].ToString()),
                        TransferType = reader["FundTransferTypeKey"] == DBNull.Value ? "0" : reader["FundTransferTypeKey"].ToString(),
                        InitiatorAccountIdentifier = reader["InitiatorAccountIdentifier"] == DBNull.Value ? "" : reader["InitiatorAccountIdentifier"].ToString(),
                        AccountIdentifier = reader["Identifier"] == DBNull.Value ? "" : reader["Identifier"].ToString(),
                        TransactionDetailAmount = reader["DetailTransactionAmount"] == DBNull.Value ? 0 : (decimal)reader["DetailTransactionAmount"],
                        TransClassKey = (int)reader["TransClassKey"],
                        TransactionDate = (DateTime)reader.GetDateTime(reader.GetOrdinal("TransactionDate"))
                    };
                    transactions.Add(fundTransfer);
                }

                return transactions;
            }
        }

        /// <summary>
        /// GetSccFundingTransfers in Pending or Completed status.
        /// </summary>
        /// <param name="accountIdentifier"></param>
        /// <returns></returns>
        public List<FundTransfer> GetSccFundingTransfers(AccountIdentifier accountIdentifier)
        {
            var transfers = new List<FundTransfer>();

            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "Identifier", Value = accountIdentifier.ToGuid(), SqlDbType = SqlDbType.UniqueIdentifier },
                new SqlParameter() {ParameterName = "FundTransferStatusKey" ,
                    Value = CreateTypeStatusKey().Convert(), // Pending , completed
                    SqlDbType = SqlDbType.Structured , TypeName = "dbo.typeStatusKey"},
                new SqlParameter() { ParameterName = "StartDate", Value = System.Data.SqlTypes.SqlDateTime.MinValue, SqlDbType = SqlDbType.DateTime },
                new SqlParameter() { ParameterName = "EndDate", Value = DateTime.Now.AddDays(1), SqlDbType = SqlDbType.DateTime },
                new SqlParameter() { ParameterName = "FundTransferTypeKey", Value = TransferType.SccFunding, SqlDbType = SqlDbType.SmallInt }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetFundTransferByIdentifierAndStatusV3]", _dataAccess.CreateConnection(), parameters.ToArray()))
            {
                while (reader.Read())
                {
                    var tran = new FundTransfer
                    {
                        FundTransferKey = long.Parse(reader["FundTransferKey"].ToString()),
                        InitiatorAccountIdentifier = reader["InitiatorAccountIdentifier"].ToString(),
                        FundTransferToken = reader["FundTransferToken"].ToString(),
                        IsSource = reader["IsSource"] != DBNull.Value && bool.Parse(reader["IsSource"].ToString()),
                        AccountIdentifier = reader["Identifier"].ToString(),
                        TransferIdentifier = reader["FundTransferToken"].ToString(),
                        TransferStatus = (TransferStatus)Enum.Parse(typeof(TransferStatus), reader["FundTransferStatusKey"].ToString()),
                        TransactionAmount = reader.GetDecimal(reader.GetOrdinal("TransactionAmount")),
                        MobilePhoneNumber = reader["ExternalIdentifier"] == DBNull.Value ? null : reader["ExternalIdentifier"].ToString(),
                        Memo = reader["Memo"] == DBNull.Value ? null : reader["Memo"].ToString()
                    };
                    transfers.Add(tran);
                }
            }

            return transfers;
        }

        private static List<SqlDataRecord> CreateTypeStatusKey()
        {
            var returnValue = new List<SqlDataRecord>();
            var metadata = new SqlMetaData[1];

            metadata[0] = new SqlMetaData("StatusKey", SqlDbType.SmallInt);

            var record = new SqlDataRecord(metadata);
            record.SetInt16(0, (short)TransferStatus.Pending);
            returnValue.Add(record);

            record = new SqlDataRecord(metadata);
            record.SetInt16(0, (short)TransferStatus.Completed);
            returnValue.Add(record);

            return returnValue;
        }

        public bool InsertRafRewardTransaction(
        List<RewardTransaction> rewardTransactions)
        {
            if (rewardTransactions?.Count > 0)
            {
                DataTable rewardTransactionTable = new DataTable();
                rewardTransactionTable.Columns.Add("AccountIdentifier", typeof(Guid));
                rewardTransactionTable.Columns.Add("RewardDate", typeof(DateTime));
                rewardTransactionTable.Columns.Add("RewardAmount", typeof(decimal));


                foreach (var t in rewardTransactions)
                {
                    var row = rewardTransactionTable.NewRow();
                    row["AccountIdentifier"] = Guid.Parse(t.AccountIdentifer);
                    row["RewardDate"] = t.RewardDate;
                    row["RewardAmount"] = Convert.ToDecimal(t.RewardAmount);

                    rewardTransactionTable.Rows.Add(row);
                }

                var spParams = new[]
                {
                    new SqlParameter()
                    {
                        ParameterName = "@RAFRewardTransactions", Value = rewardTransactionTable,
                        SqlDbType = System.Data.SqlDbType.Structured,
                        TypeName = "typeRAFRewardTransaction"
                    }

                };
                try
                {
                    _dataAccess.ExecuteNonQuery("[dbo].[InsRAFRewardTransaction]",
                        _dataAccess.CreateConnection(), spParams);
                    return true;
                }
                catch (Exception ex)
                {
                    throw new Exception(
                        $"Could not Update Statuses.  {ex.ToString()}");
                }
            }
            return true;
        }

        public List<ReversalSweepTransClass> GetReversalSweepTransClassConfiguration(string programCode)
        {
            return _baasConfiguration.GetReversalSweepTransClassConfiguration(programCode);
        }

        private readonly ICareSharedApiService _careSharedApiService;
        private readonly IDataAccess _dataAccess;
        private readonly ILazyCache _cache;
        private static readonly object _transClassesLockObject = new object();
        private static Dictionary<string, TransClass> _transClasses;
        private static DateTime _transClassesExpiration = DateTime.MinValue;
        private static readonly TimeSpan _transClassesCacheTtl = TimeSpan.FromHours(1);
        private static readonly TimeSpan _transClassesLocalTtl = TimeSpan.FromHours(2);
        private string _userName = IdentityHelper.GetIdentityName();
        private static readonly Logger _logger = LogManager.GetCurrentClassLogger();
        private static readonly SqlMetaData[] _typeFundTransferDetailMetadata = CreateTypeFundTransferDetailMetadata();
        private readonly IDcppService _dcppService;
        private readonly IAchService _achService;
        private readonly IMrdcService _mrdcService;
        private readonly IAccountBalanceRepository _accountBalanceRepository;
        private readonly IAccountRepository _accountRepository;
        private readonly IProgramFundingRepository _programFundingRepository;
        private readonly IRulesEngine _rulesEngine;
        private readonly IBaasConfiguration _baasConfiguration;
        private readonly IUserService _userService;
        private readonly ILoanManagementService _loanManagementService;
        private readonly IUserRepository _userRepository;
        private readonly IRequestHandlerSettings _configuration;
        private readonly IProductRepository _productRepository;
        private readonly ITransactionsRepository _transactionsRepository;
        private IEGiftRepository _eGiftRepository;
        private readonly ITransClassService _transClassService;
        private readonly ITransferDescriptionProvider _transferDescriptionProvider;
        private readonly IExternalPaymentRepository _externalPaymentRepository;
        private readonly IInstantFundTransferService _instantFundTransferService;
        public IEGiftService _eGiftService { get; set; }
        private readonly IPointsSystemService _pointsSystemService;
    }
}
