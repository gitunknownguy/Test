﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Security.Authentication;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using LazyCache;
using NLog;
using RequestHandler.Core.Domain.Model.Vau;
using RequestHandler.Core.Infrastructure.Configuration;
using LogManager = NLog.LogManager;

namespace RequestHandler.Core.Infrastructure
{
    public interface IVauVaultProvider
    {
        public VauVault Vault { get; }
        public RSA MlePublicKey { get; }
        public RSA MlePrivateKey { get; }
        bool UpdVauVault(string kId, string uId, string value, VauVault existVauVault);
    }
    [ExcludeFromCodeCoverage(Justification = "Will test as part of GBOS-116633")]
    public class VauVaultProvider(IAppCache appCache, IVauSecretRepository vauSecretRepository) : IVauVaultProvider
    {
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();
        private const string VauVaultCacheKey = "Vau_Vault";
        private const string VauMlePublicCacheKey = "Vau_MlePublic";
        private const string VauMlePrivateCacheKey = "Vau_MlePrivate";
        private VauVault _vault;
        public VauVault Vault =>
                    _vault ??= appCache.GetOrAdd(VauVaultCacheKey, vauSecretRepository.GetVauSecret, DateTimeOffset.Now.AddDays(1));

        RSA IVauVaultProvider.MlePublicKey => appCache.GetOrAdd(VauMlePublicCacheKey, () =>
        {
            var storeLocation = ConfigurationHelper.GetStoreLocation();
            using var my = new X509Store(StoreName.My, storeLocation);
            my.Open(OpenFlags.ReadOnly);
            var collection = my.Certificates.Find(X509FindType.FindBySubjectName, Vault.KId, false);
            if (collection.Count < 2) throw new InvalidCredentialException("MLE cert should be in pair.");
            var clientCertificate = collection.First(x => x.HasPrivateKey == false).GetRSAPublicKey();
            return clientCertificate;
        }, DateTimeOffset.Now.AddDays(1));

        RSA IVauVaultProvider.MlePrivateKey => appCache.GetOrAdd(VauMlePrivateCacheKey, () =>
        {
            var storeLocation = ConfigurationHelper.GetStoreLocation();
            using var my = new X509Store(StoreName.My, storeLocation);
            my.Open(OpenFlags.ReadOnly);
            var collection = my.Certificates.Find(X509FindType.FindBySubjectName, Vault.KId, false);
            if (collection.Count < 2) throw new InvalidCredentialException("MLE cert should be in pair.");
            var certWithPrivateKey = collection.FirstOrDefault(x => x.HasPrivateKey);
            if(certWithPrivateKey == null) 
            {
                Logger.Error("No MLE cert with PK was found");
                throw new InvalidCredentialException("No cert with PK was found");
            }
            var asymmetricAlgorithm = certWithPrivateKey.GetRSAPrivateKey();
            if (asymmetricAlgorithm == null)
                throw new InvalidCredentialException("No PK included in MLE Client Cert");
            var pars = asymmetricAlgorithm.ExportParameters(true);
            var rsa = RSA.Create();
            rsa.ImportParameters(pars);
            return rsa;
        }, DateTimeOffset.Now.AddDays(1));


        public bool UpdVauVault(string kId, string uId, string value, VauVault existVauVault)
        {
            // Check if the KeyId is the same as existing, if yes, exit the method
            if (existVauVault != null && string.Equals(existVauVault.KId, kId, StringComparison.OrdinalIgnoreCase))
            {
                Logger.Info("KId is the same as the existing one. No update needed.");
                return false;
            }

            // KId is different, log that an update is needed
            Logger.Info($"KId '{kId}' is different from existing KId '{existVauVault?.KId}'. Update needed.");

            // Create new VauVault object
            var newVauVault = new VauVault
            {
                KId = kId,
                UId = uId,
                Value = value
            };

            // Update the VauVault in the database
            bool updateSuccess = vauSecretRepository.UpdateVauSecret(newVauVault);

            if (updateSuccess)
            {
                Logger.Info("VauVault updated successfully in the database. Removing cache entry.");

                // Remove only the Vau_Vault cache entry
                appCache.Remove(VauVaultCacheKey);
                appCache.Remove(VauMlePublicCacheKey);
                appCache.Remove(VauMlePrivateCacheKey);

                // Set the new Vau Vault in VauSecretProvider
                _vault = newVauVault;

                Logger.Info("Cache updated with new VauVault.");
                return true;
            }

            Logger.Error("Failed to update VauVault in the database.");
            return false;
        }
    }
}
