﻿using System;
using System.Collections.Generic;
using Gd.Bos.RequestHandler.Core.Domain;
using Gd.Bos.RequestHandler.Core.Domain.Services.AccountMigration;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Newtonsoft.Json;
using NLog;
using RequestHandler.Core.Application;
using RequestHandler.Core.Domain.Services.AccountMigration;

namespace RequestHandler.Core.Infrastructure
{
    public class AccountMigrationService : IAccountMigrationService
    {
        private const string ProspectDetailsByIdRedisKeyPrefix = "RH_ProspectDetailsById_";
        private const string ProspectCardProxyKeyPrefix = "RH_ProspectDetails_CardProxy_";
        private readonly string _gssAccountMigrationApiBaseUrl;
        private readonly IServiceInvokeProvider _serviceInvokerProvider;
        private string _accountMigrationConfirmationApiUrl = "/AccountMigration/{0}/{1}/confirmation";
        private const string _prospectOptOutByCardProxy = "/api/prospect/optout";
        private const string _updateProspectStatusUrl = "/api/prospect/Status";
        private const string _accountMigrationUrl = "/AccountMigration";
        private const string _accountMigrationGetLegacyAccountBalanceUrl = "/balanceTransfer/accountbalance";

        private static readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        private readonly IRequestHandlerSettings _configuration;
        private readonly ILazyCache _lazyCache;

        public AccountMigrationService(IServiceInvokeProvider serviceInvokeProvider, IRequestHandlerSettings requestHandlerSettings, ILazyCache lazyCache)
        {
            _serviceInvokerProvider = serviceInvokeProvider;
            _gssAccountMigrationApiBaseUrl = Gd.Bos.RequestHandler.Core.Infrastructure.Configuration.Configuration.Current
                .GSSAccountMigrationApiBaseUrl;
            _configuration = requestHandlerSettings;
            _lazyCache = lazyCache;
        }

        public GetAccountMigrationItemConfirmationResponseDTO GetAccountMigrationItemConfirmation(string migrationType, string sourceAccountId)
        {
            var url = _gssAccountMigrationApiBaseUrl + string.Format(_accountMigrationConfirmationApiUrl, migrationType, sourceAccountId);
            GetTimeout("X-GD-Bos-GetAccountMigrationItemConfirmation", out var requestTimeout);
            var response = _serviceInvokerProvider.GetWebResponseAsync<GetAccountMigrationItemConfirmationResponseDTO>(
                url, "GET", null, requestTimeout).Result;
            if (response?.ResponseHeader == null)
                throw new Exception($"GetAccountMigrationItemConfirmation for {sourceAccountId} did not return a recognizable response.");
            if (response.ResponseHeader?.StatusCode != 200 || response?.AccountMigration == null)
            {
                _logger.Info($"GetAccountMigrationItemConfirmation for {sourceAccountId} failed", response);
                return response;
            }

            var payeeDetails = new List<PayeeDetail>();
            if (response.AccountMigration?.BillPayMigration?.PayeeDetails != null)
            {
                foreach (var payDetail in response.AccountMigration.BillPayMigration.PayeeDetails)
                {
                    var payMents = new List<BillPayment>();
                    if (payDetail.Payments != null)
                    {
                        foreach (var payment in payDetail.Payments)
                        {
                            payMents.Add(new BillPayment()
                            {
                                PayeeIdentifier = payment.PayeeIdentifier,
                                Amount = payment.Amount,
                                PaymentDate = payment.PaymentDate,
                                PaymentEndDate = payment.PaymentEndDate,
                                PaymentMemo = payment.PaymentMemo,
                                Note = payment.Note,
                                BankRoutingNumber = payment.BankRoutingNumber,
                                BankAccountNumber = payment.BankAccountNumber,
                                BankAccountType = payment.BankAccountType,
                                FrequencyType = payment.FrequencyType,
                                PaymentStatus = payment.PaymentStatus,
                                PaymentDelivery = payment.PaymentDelivery,
                                TransactionId = payment.TransactionId,
                                ActivityStatus = payment.ActivityStatus == null
                                    ? null
                                    : new ActivityStatus()
                                    {
                                        Id = payment.ActivityStatus.Id,
                                        Name = payment.ActivityStatus.Name,
                                        Description = payment.ActivityStatus.Description
                                    },
                                AttemptCount = payment.AttemptCount == null
                                    ? null
                                    : new AttemptCount()
                                    {
                                        Value = payment.AttemptCount.Value,
                                        RetryCount = payment.AttemptCount.RetryCount
                                    },
                                AccountMigrationActivityKey = payment.AccountMigrationActivityKey,
                                Index = payment.Index
                            });
                        }
                    }

                    payeeDetails.Add(new PayeeDetail()
                    {
                        Payments = payMents,
                        Name = payDetail.Name,
                        NickName = payDetail.NickName,
                        Address1 = payDetail.Address1,
                        Address2 = payDetail.Address2,
                        City = payDetail.City,
                        State = payDetail.State,
                        Zip = payDetail.Zip,
                        Zip4 = payDetail.Zip4,
                        Country = payDetail.Country,
                        AccountNumber = payDetail.AccountNumber,
                        PhoneNumber = payDetail.PhoneNumber,
                        MerchantId = payDetail.MerchantId,
                        Index = payDetail.Index,
                        ActivityStatus = payDetail.ActivityStatus == null
                            ? null
                            : new ActivityStatus()
                            {
                                Id = payDetail.ActivityStatus.Id,
                                Name = payDetail.ActivityStatus.Name,
                                Description = payDetail.ActivityStatus.Description
                            },
                        AttemptCount = payDetail.AttemptCount == null
                            ? null
                            : new AttemptCount()
                            {
                                Value = payDetail.AttemptCount.Value,
                                RetryCount = payDetail.AttemptCount.RetryCount
                            }
                    });
                }
            }

            var result = new GetAccountMigrationItemConfirmationResponseDTO()
            {
                AccountMigration = new GetAccountMigrationItemConfirmationDTO()
                {
                    GenerationTimestamp = response.AccountMigration.GenerationTimestamp,
                    ConfirmationTimestamp = response.AccountMigration.ConfirmationTimestamp,
                    CreditRatingKey = response.AccountMigration.CreditRatingKey,
                    SubscriptionShortNames = response.AccountMigration.SubscriptionShortNames,
                    BalanceMigration = response.AccountMigration.BalanceMigration == null ? null : new BalanceMigrationDTO()
                    {
                        Amount = response.AccountMigration.BalanceMigration.Amount
                    },
                    SavingsMigration = response.AccountMigration.SavingsMigration == null ? null : new SavingsMigrationDTO()
                    {
                        Amount = response.AccountMigration.SavingsMigration.Amount
                    },
                    BillCycleMigration = response.AccountMigration.BillCycleMigration == null ? null : new BillCycleMigrationDTO()
                    {
                        BillCycleDay = response.AccountMigration.BillCycleMigration.BillCycleDay
                    },
                    BillPayMigration = response.AccountMigration.BillPayMigration == null ? null : new BillPayMigrationDTO()
                    {
                        EnrollBillPay = response.AccountMigration.BillPayMigration.EnrollBillPay == null ? null : new EnrollBillPay()
                        {
                            FirstName = response.AccountMigration.BillPayMigration.EnrollBillPay.FirstName,
                            MiddleName = response.AccountMigration.BillPayMigration.EnrollBillPay.MiddleName,
                            LastName = response.AccountMigration.BillPayMigration.EnrollBillPay.LastName,
                            Address1 = response.AccountMigration.BillPayMigration.EnrollBillPay.Address1,
                            Address2 = response.AccountMigration.BillPayMigration.EnrollBillPay.Address2,
                            City = response.AccountMigration.BillPayMigration.EnrollBillPay.City,
                            State = response.AccountMigration.BillPayMigration.EnrollBillPay.State,
                            Zip = response.AccountMigration.BillPayMigration.EnrollBillPay.Zip,
                            Country = response.AccountMigration.BillPayMigration.EnrollBillPay.Country,
                            PhoneNumber = response.AccountMigration.BillPayMigration.EnrollBillPay.PhoneNumber,
                            Email = response.AccountMigration.BillPayMigration.EnrollBillPay.Email,
                            Dob = response.AccountMigration.BillPayMigration.EnrollBillPay.Dob,
                            SsnToken = response.AccountMigration.BillPayMigration.EnrollBillPay.SsnToken,
                            BankRoutingNumber = response.AccountMigration.BillPayMigration.EnrollBillPay.BankRoutingNumber,
                            BankAccountNumber = response.AccountMigration.BillPayMigration.EnrollBillPay.BankAccountNumber,
                            BankAccountType = response.AccountMigration.BillPayMigration.EnrollBillPay.BankAccountType,
                            ActivityStatus = response.AccountMigration.BillPayMigration.EnrollBillPay?.ActivityStatus == null ? null : new ActivityStatus()
                            {
                                Id = response.AccountMigration.BillPayMigration.EnrollBillPay.ActivityStatus.Id,
                                Name = response.AccountMigration.BillPayMigration.EnrollBillPay.ActivityStatus.Name,
                                Description = response.AccountMigration.BillPayMigration.EnrollBillPay.ActivityStatus.Description
                            },
                            AttemptCount = response.AccountMigration.BillPayMigration.EnrollBillPay?.AttemptCount == null ? null : new AttemptCount()
                            {
                                Value = response.AccountMigration.BillPayMigration.EnrollBillPay.AttemptCount.Value,
                                RetryCount = response.AccountMigration.BillPayMigration.EnrollBillPay.AttemptCount.RetryCount
                            }
                        },
                        PayeeDetails = payeeDetails
                    }
                },
                ResponseHeader = new ResponseHeader
                {
                    StatusCode = response.ResponseHeader.StatusCode,
                    Details = response.ResponseHeader.Message,
                    SubStatusCode = 0
                }
            };
            return result;
        }

        private void GetTimeout(string headerName, out int? requestTimeout)
        {
            requestTimeout = null;
            if (OptionsContext.Current.IsDefined(headerName))
            {
                requestTimeout = 1;
                if (int.TryParse(OptionsContext.Current.GetString(headerName), out var rt))
                    requestTimeout = rt;
            }
        }

        AccountMigrationResponseDTO IAccountMigrationService.AccountMigration(AccountMigrationRequestDTO request)
        {
            var serviceUrl = _configuration.GSSAccountMigrationApiBaseUrl + _accountMigrationUrl;
            var requestBody = JsonConvert.SerializeObject(request);
            var response = _serviceInvokerProvider.GetWebResponseAsync<AccountMigrationResponseDTO>(serviceUrl, "post", requestBody).Result;

            if (response == null)
                throw new System.Exception($"AccountMigration service did not return a successful response.");

            return response;
        }

        LegacyAccountBalanceResponse IAccountMigrationService.GetLegacyAccountBalance(LegacyAccountBalanceRequest request)
        {
            var serviceUrl = _configuration.GSSAccountMigrationApiBaseUrl + _accountMigrationGetLegacyAccountBalanceUrl;
            var response = _serviceInvokerProvider.GetWebResponseAsync<LegacyAccountBalanceResponse>(serviceUrl, "post", JsonConvert.SerializeObject(request)).Result;

            if (response == null)
                throw new System.Exception($"LegacyAccountBalance service did not return a successful response.");

            return response;
        }
    }
}
