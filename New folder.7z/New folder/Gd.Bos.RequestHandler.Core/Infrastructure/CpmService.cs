﻿using System;
using System.Collections.Generic;
using System.Linq;
using Gd.Bos.Dcpp.Contract.Message;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Application.AsyncCommandHandlers;
using Gd.Bos.RequestHandler.Core.Domain.Context;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Business;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Services.AsyncCommandService;
using Gd.Bos.RequestHandler.Core.Domain.Services.Dcpp;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.CBSProcessorManager.Contract.Enums;
using Gd.Bos.Shared.Common.CBSProcessorManager.Contract.Message.Request;
using Gd.Bos.Shared.Common.CBSProcessorManager.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.Logic;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using RequestHandler.Core.Domain.Services.CPM;
using AdjustAccountBalanceResponse = Gd.Bos.Dcpp.Contract.Message.AdjustAccountBalanceResponse;
using ChangeAccountStatusRequest = Gd.Bos.Shared.Common.CBSProcessorManager.Contract.Message.Request.ChangeAccountStatusRequest;
using ChangeAccountStatusResponse = Gd.Bos.Dcpp.Contract.Message.ChangeAccountStatusResponse;
using ChangeCardStatusResponse = Gd.Bos.Dcpp.Contract.Message.ChangeCardStatusResponse;
using ChangePurseStatusResponse = Gd.Bos.Dcpp.Contract.Message.ChangePurseStatusResponse;
using CPMContract = Gd.Bos.Shared.Common.CBSProcessorManager.Contract;
using CreateAccountResponse = Gd.Bos.Dcpp.Contract.Message.CreateAccountResponse;
using CurrencyAmount = Gd.Bos.Shared.Common.Core.Contract.CurrencyAmount;
using DcppContract = Gd.Bos.Dcpp.Contract.Message;
using DeliveryMethod = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.DeliveryMethod;
using GetAccountBalanceResponse = Gd.Bos.Dcpp.Contract.Message.GetAccountBalanceResponse;
using LossType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.LossType;
using OrderCardResponse = Gd.Bos.Dcpp.Contract.Message.OrderCardResponse;
using PaymentInstrumentType = Gd.Bos.Shared.Common.CBSProcessorManager.Contract.Enums.PaymentInstrumentType;
using PhoneNumber = Gd.Bos.RequestHandler.Core.Domain.Model.User.PhoneNumber;
using PhysicalCardType = Gd.Bos.RequestHandler.Core.Domain.Services.Dcpp.PhysicalCardType;
using ProductTierInfo = Gd.Bos.Shared.Common.Core.Common.Data.ProductTierInfo;
using PurseStatus = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.PurseStatus;
using PurseType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.PurseType;
using ReplacementReason = Gd.Bos.Dcpp.Contract.Enum.ReplacementReason;
using RequestHeader = Gd.Bos.Shared.Common.CBSProcessorManager.Contract.Message.Request.RequestHeader;
using SetCycleResponse = Gd.Bos.Dcpp.Contract.Message.SetCycleResponse;
using TokenAction = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.TokenAction;
using UpdateCreditLimitHistoryRequest = Gd.Bos.Dcpp.Contract.Message.UpdateCreditLimitHistoryRequest;
using UpdateCreditLimitHistoryResponse = Gd.Bos.Dcpp.Contract.Message.UpdateCreditLimitHistoryResponse;
using UpdateProductResponse = Gd.Bos.Dcpp.Contract.Message.UpdateProductResponse;
using ValidateCvvByPanRequest = RequestHandler.Core.Domain.Services.Dcpp.ValidateCvvByPanRequest;
using ValidateCvvByPanResponse = RequestHandler.Core.Domain.Services.Dcpp.ValidateCvvByPanResponse;
using AuthorizePaymentRequest = Gd.Bos.Dcpp.Contract.Message.AuthorizePaymentRequest;
using AuthorizePaymentResponse = Gd.Bos.Dcpp.Contract.Message.AuthorizePaymentResponse;
using GetPurchaseStatusRequest = Gd.Bos.Dcpp.Contract.Message.GetPurchaseStatusRequest;
using GetPurchaseStatusResponse = Gd.Bos.Dcpp.Contract.Message.GetPurchaseStatusResponse;

namespace RequestHandler.Core.Infrastructure
{
    public class CpmService : ICpmService
    {
        private readonly IServiceInvokeProvider _serviceInvokeProvider;

        private readonly string _cpmBaseUrl;
        private readonly string _adjustAccountBalanceUrl = "/Transfer/AdjustAccountBalance";
        private readonly string _validateCvvUrl = "/programs/{0}/card/ValidateCvv";
        private readonly string _createAccountUrl = "/programs/{0}/account";
        private readonly string _getCardDetailsUrl = "/programs/{0}/card/GetCardDetails";
        private readonly string _adjustPurseBalanceUrl = "/Transfer/AdjustPurseBalance";
        private readonly string _orderPhysicalCardUrl = "/programs/{0}/card/orderCard";
        private readonly string _reportLostStolenUrl = "/programs/{0}/card/ReportLostStolen";
        private readonly string _reportLostStolenV2Url = "/programs/{0}/card/ReportLostStolenV2";
        private readonly string _setPinUrl = "/Card/SetPin";
        private readonly string _activateCardUrl = "/programs/{0}/card/activateCard";
        private readonly string _changeAccountStatusUrl = "/programs/{0}/changeAccountStatus";
        private readonly string _changePurseStatusUrl = "/Purse/Status/Change";
        private readonly string _updateAccountUrl = "/programs/{0}/updateAccount";
        private readonly string _upgradeAccountUrl = "/programs/{0}/upgradeAccount";
        private readonly string _addPurseToAccountUrl = "/programs/{0}/AddPurseToAccount";
        private readonly string _changeCardStatusUrl = "/programs/{0}/card/changeCardStatus";
        private readonly string _setCycleUrl = "/programs/{0}/accounts/{1}/billCycleDay";
        private readonly string _yearTodateFee = "/programs/{0}/card/GetCardAccountYtdFees";
        private readonly string _registerCard = "/programs/{0}/card/registerCard";
        private readonly string _registerCustomer = "/programs/{0}/card/registerCustomer";
        private readonly string _addPlasticCard = "/programs/{0}/cards/plastic";
        private readonly string _activateProspectSampleCard = "/programs/{0}/card/activateProspectSampleCard";
        private readonly string _getAccountBalance = "/programs/{0}/card/GetAccountBalance";
        private readonly string _updateProductUrl = "/programs/{0}/accounts/{1}/updateProduct";
        private readonly string _overrideProductUrl = "/programs/{0}/accounts/{1}/overrideProduct";
        private readonly string _updateCreditLimitHistory = "/programs/{0}/accounts/{1}/UpdateCreditLimitHistory";
        private readonly string _validateCvvByPanUrl = "/programs/{0}/card/ValidateCvvByPan";
        private readonly string _linkCard = "/programs/{0}/card/LinkCard";
        private readonly string _authorizePaymentUrl = "/programs/{0}/payments/authorize";
        private readonly string _getPurchaseStatusUrl = "/programs/{0}/payments/{1}/status/{2}";
        private readonly string _bindJointAccountUrl = "/programs/{0}/accounts/bindingJointAccount";
        private readonly string _restoreAccountUrl = "/programs/{0}/accounts/{1}/restore";

        private readonly IRequestHandlerSettings _settings;
        private readonly IAsyncCommandService _asyncCommandService;
        private readonly IPaymentIdentifierRepository _paymentIdentifierRepository;
        private readonly IAccountRepository _accountRepository;
        private readonly IProductService _productService;

        public CpmService(IServiceInvokeProvider serviceInvokerProvider,
            IRequestHandlerSettings settings,
            IAsyncCommandService asyncCommandService,
            IPaymentIdentifierRepository paymentIdentifierRepository,
            IAccountRepository accountRepository,
            IProductService productService
            )
        {
            _serviceInvokeProvider = serviceInvokerProvider;
            _cpmBaseUrl = Gd.Bos.RequestHandler.Core.Infrastructure.Configuration.Configuration.Current.CPMBaseUrl;
            _settings = settings;
            _asyncCommandService = asyncCommandService;
            _paymentIdentifierRepository = paymentIdentifierRepository;
            _accountRepository = accountRepository;
            _productService = productService;
        }

        public SetCycleResponse SetCycle(AccountIdentifier accountIdentifier)
        {
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);
            var cpmRequest = new SetBillCycleRequest
            {
                Header = new RequestHeader() { RequestId = reqId, Source = null },
                AccountIdentifier = accountIdentifier.ToString(),
                ProgramCode = DomainContext.Current?.ProgramCode?.ToString(),
            };

            var response = _serviceInvokeProvider.GetResponseAsync<SetBillCycleRequest, SetBillCycleResponse>(
                       _cpmBaseUrl + string.Format(_setCycleUrl, DomainContext.Current?.ProgramCode?.ToString(),
                       accountIdentifier.ToString()), "POST", cpmRequest, null).Result;
            if (response == null)
                throw new Exception($"CPM service did not return a recognizable response for SetCycle.");

            if (response.Header?.StatusCode != "200" && response.Header?.StatusCode != "0")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for SetCycle: Message: {response.Header.ErrorInfo.Message};");

            return new SetCycleResponse()
            {
                Header = new DcppContract.ResponseHeader
                {
                    StatusCode = response.Header?.StatusCode,
                    ErrorInfo = new Gd.Bos.Dcpp.Contract.Data.ErrorInfo
                    {
                        Details = response.Header?.ErrorInfo?.Details,
                        Message = response.Header?.ErrorInfo?.Message,
                        SubStatusCode = response.Header?.ErrorInfo?.SubStatusCode,
                        Source = response.Header?.ErrorInfo?.Source,
                    }
                }
            };
        }
        public AdjustAccountBalanceResponse AdjustBalanceForAccountTransaction(AccountIdentifier accountIdentifier, decimal amount, bool allowNegativeBalance, string currencyCode, string transClass, string transactionReferenceId, string description, string comment, string commentPostfix, int? requestTimeout)
        {
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);
            var cpmRequest = new CPMContract.Message.Request.AdjustAccountBalanceRequest
            {
                AccountId = accountIdentifier.ToString(),
                Adjustment = new CPMContract.Message.CurrencyAmount
                {
                    Amount = amount,
                    CurrencyCode = currencyCode
                },
                TransClass = transClass,
                TransactionReferenceId = transactionReferenceId,
                Description = description,
                Comment = comment + commentPostfix,
                AllowNegativeBalance = allowNegativeBalance,
                Header = new RequestHeader { RequestId = reqId, Source = null },
                ProgramCode = DomainContext.Current?.ProgramCode?.ToString()
            };

            var response = _serviceInvokeProvider.GetResponseAsync<CPMContract.Message.Request.AdjustAccountBalanceRequest, CPMContract.Message.Response.AdjustAccountBalanceResponse>(
                       _cpmBaseUrl + _adjustAccountBalanceUrl, "POST", cpmRequest, null, requestTimeout).Result;
            if (response == null)
                throw new Exception($"CPM service did not return a recognizable response for AdjustAccountBalance.");

            AdjustAccountBalanceResponse dcppResponse = new AdjustAccountBalanceResponse
            {
                AvailableBalance = new Gd.Bos.Dcpp.Contract.Data.CurrencyAmount
                {
                    Amount = response.AvailableBalance == null ? 0 : response.AvailableBalance.Amount,
                    CurrencyCode = response.AvailableBalance == null ? "USD" : response.AvailableBalance.CurrencyCode
                },
                CurrentBalance = new Gd.Bos.Dcpp.Contract.Data.CurrencyAmount
                {
                    Amount = response.CurrentBalance == null ? 0 : response.CurrentBalance.Amount,
                    CurrencyCode = response.CurrentBalance == null ? "USD" : response.CurrentBalance.CurrencyCode
                },
                Header = new DcppContract.ResponseHeader
                {
                    StatusCode = response.Header?.StatusCode,
                    ErrorInfo = new Gd.Bos.Dcpp.Contract.Data.ErrorInfo
                    {
                        Details = response.Header?.ErrorInfo?.Details,
                        Message = response.Header?.ErrorInfo?.Message,
                        SubStatusCode = response.Header?.ErrorInfo?.SubStatusCode,
                        Source = response.Header?.ErrorInfo?.Source,
                    }
                }

            };
            return dcppResponse;
        }
        private Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.AddressType GetAddressType(string addressType)
        {
            var result = int.TryParse(addressType, out int intDefaultAddressType);
            if (result)
            {
                return (Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.AddressType)intDefaultAddressType;
            }
            var defaultAddressType = (Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.AddressType)Enum.Parse(typeof(Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.AddressType), (string)addressType, true);
            return defaultAddressType;

        }
        public Gd.Bos.RequestHandler.Core.Domain.Services.Dcpp.CreateAccountResponse CreateAccount(AccountIdentifier accountIdentifier, UserIdentifier userIdentifier,
            IEnumerable<string> additionalUserIdentifiers, UserName name, IEnumerable<Address> addresses, IEnumerable<PhoneNumber> phoneNumbers, string programCode,
            string productCode, PhysicalCardType physicalCardType, bool personalized, string productMaterialType,
            int productTierKey, bool isVirtualTierAllowed, string embossName, string businessName, string accountNumber,
            int expirationMonths, int expirationRandomMonths, BusinessAddress businessAddress = null, string productType = null, int billCycleDay = 1, string routingNumber = null, bool needEmbossing = true, string storeId = null, string businessEmbossName = null)
        {
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);
            GetTimeout("X-GD-Bos-Dcpp-CreateAccountTimeOut", out var requestTimeout);
            if (requestTimeout <= 1) throw new TimeoutException("Timeout for CreateAccount");//For QA Testing

            CPMContract.Data.PostalAddress postalAddress;

            var address = addresses?.FirstOrDefault(item =>
                GetAddressType(item.Type) == Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.AddressType.Home) ?? new Address();
            var shippingAddress = addresses?.FirstOrDefault(item =>
                GetAddressType(item.Type) == Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.AddressType.Shipping);

            if (businessAddress != null && businessAddress.IsBusinessAddressForPostal)
            {
                postalAddress = new CPMContract.Data.PostalAddress()
                {
                    AddressLines = new string[]
                    {
                        businessAddress.BusinessAddressLine1,
                        businessAddress.BusinessAddressLine2
                    },
                    City = businessAddress.BusinessCity,
                    PostalCode = businessAddress.BusinessZipCode,
                    CountrySubdivision = businessAddress.BusinessState,
                    AddressType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.AddressType.Work
                };
            }
            else
            {
                postalAddress = new CPMContract.Data.PostalAddress()
                {
                    AddressLines = new string[]
                    {
                        address.AddressLine1,
                        address.AddressLine2
                    },
                    City = address.City,
                    PostalCode = address.ZipCode,
                    CountrySubdivision = address.State,
                    AddressType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.AddressType.Home
                };
            }
            var cpmRequest = new CPMContract.Message.Request.CreateAccountRequest()
            {
                BusinessName = businessName,
                Header = new RequestHeader() { RequestId = reqId, Source = null },
                AccountIdentifier = accountIdentifier,
                UserIdentifier = new Guid(userIdentifier.ToString()),
                AdditionalUserIdentifiers = additionalUserIdentifiers?.ToList().Select(Guid.Parse).ToList(),
                ProgramCode = programCode,
                ProductCode = productCode,
                PhysicalCardType = (CPMContract.Enums.PhysicalCardType)physicalCardType,
                Personalized = false,
                EmbossName = embossName,
                BusinessEmbossName = businessEmbossName,
                Name = new CPMContract.Data.CardholderName()
                {
                    FirstName = name.FirstName,
                    LastName = name.LastName
                },
                Address = postalAddress,
                ProductMaterialType = productMaterialType,
                ProductTierKey = productTierKey,
                IsVirtualTierAllowed = isVirtualTierAllowed,
                AccountNumber = accountNumber,
                ExpirationMonths = expirationMonths,
                BillCycleDay = billCycleDay,
                NeedEmbossing = needEmbossing,
                //GBOS-78089 ypc
                RoutingNumber = routingNumber,
                StoreId = storeId
            };
            if (productType != null && (productType.ToUpperInvariant() == "DDA" || productType.ToUpperInvariant() == "GPR"))
            {
                if (shippingAddress != null)
                {
                    cpmRequest.ShippingAddress = new CPMContract.Data.PostalAddress
                    {
                        AddressLines = new string[]
                    {
                        shippingAddress.AddressLine1,
                        shippingAddress.AddressLine2
                    },
                        City = shippingAddress.City,
                        PostalCode = shippingAddress.ZipCode,
                        CountrySubdivision = shippingAddress.State,
                        AddressType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.AddressType.Shipping
                    };
                }
            }

            var response = _serviceInvokeProvider.GetResponseAsync<CPMContract.Message.Request.CreateAccountRequest, CPMContract.Message.Response.CreateAccountResponse>(
                $"{_cpmBaseUrl}{string.Format(_createAccountUrl, programCode)}", "POST", cpmRequest, null).Result;
            if (response == null)
                throw new Exception($"CPM service did not return a recognizable response for CreateAccount.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for CreateAccount: Message: {response.Header.ErrorInfo.Message};");

            var dcppResponse = new Gd.Bos.RequestHandler.Core.Domain.Services.Dcpp.CreateAccountResponse()
            {
                CardDetails = new CardDetails()
                {
                    Cvv = response.Cvv,
                    Pan = response.CardNumber,
                    ExpirationMonth = response.Expiration.Month,
                    ExpirationYear = response.Expiration.Year
                },
                PaymentIdentifierIdentifier = response.PaymentIdentifierIdentifier.ToString(),
                AccountBalanceIdentifier = response.AccountBalanceIdentifier.ToString(),
                PaymentInstrumentIdentifier = response.PaymentInstrumentIdentifier.ToString(),
                AccountNumber = response.AccountNumber,
                RoutingNumber = response.RoutingNumber
            };
            return dcppResponse;
        }

        public CreateAccountResponse AddAccountHolder(string accountIdentifier, string userIdentifier, string accountHolderIdentifier,
            string productMaterialType, UserName cardholderName, string embossName, DateTime dateOfBirth, string productCode,
            bool isVirtualTierAllowed, IEnumerable<Address> addresses, IEnumerable<PhoneNumber> phoneNumbers)
        {
            throw new NotImplementedException();
        }

        public CardDetails GetCardDetails(AccountIdentifier accountIdentifier, CardExpirationDate expirationDate,
            Guid? paymentIdentifier = null, Guid? paymentInstrumentIdentifier = null)
        {
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            GetTimeout("X-GD-Bos-Dcpp-GetCardDetailsTimeOut", out var requestTimeout);

            CPMContract.Message.Request.GetCardDetailsRequest request = new CPMContract.Message.Request.GetCardDetailsRequest
            {
                Header = new RequestHeader() { RequestId = reqId, Source = null },
                ProgramCode = DomainContext.Current?.ProgramCode?.ToString(),
                AccountId = accountIdentifier.ToString(),
                Expiration = new CPMContract.Data.ExpirationDate
                {
                    Month = expirationDate.CardExpirationMonth,
                    Year = expirationDate.CardExpirationYear
                },
                PaymentIdentifierIdentifier = paymentIdentifier,
                PaymentInstrumentIdentifier = paymentInstrumentIdentifier,
            };

            var response = _serviceInvokeProvider.GetResponseAsync<CPMContract.Message.Request.GetCardDetailsRequest, CPMContract.Message.Response.GetCardDetailsResponse>(_cpmBaseUrl + string.Format(_getCardDetailsUrl, request.ProgramCode), "POST", request, null, requestTimeout).Result;

            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for GetCardDetails.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                        $"A downstream provider did not return success for GetCardDetails: Message: {response.Header.ErrorInfo.Message};");

            return new CardDetails
            {
                Pan = response.CardNumber,
                Cvv = response.Cvv,
                ExpirationMonth = int.Parse(response.Expiration.Month),
                ExpirationYear = int.Parse(response.Expiration.Year)
            };
        }

        public ValidateCvvByPanResponse ValidateCvvByPan(ValidateCvvByPanRequest request)
        {
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            GetTimeout("X-GD-Bos-Dcpp-ValidateCvvByPanTimeout", out var requestTimeout);
            var cpmRequest = new CPMContract.Message.Request.ValidateCvvByPanRequest
            {
                ProgramCode = string.Empty,
                CVV = request.CVV,
                Pan = request.Pan,
                ExpirationDate = new CPMContract.Data.ExpirationDate
                {
                    Month = request.ExpirationDate?.Month,
                    Year = request.ExpirationDate?.Year,
                },
                IsExpirationDateOptional = request.IsExpirationDateOptional,
                Header = new RequestHeader() { RequestId = reqId, Source = null },
            };

            var response = _serviceInvokeProvider
                .GetResponseAsync<CPMContract.Message.Request.ValidateCvvByPanRequest,
                    CPMContract.Message.Response.ValidateCvvByPanResponse>(_cpmBaseUrl +
                                                                          string.Format(_validateCvvByPanUrl, request.ProgramCode)
                                                                          , "POST", cpmRequest, null, requestTimeout).Result;
            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for ValidateCvvByPan.");

            return new ValidateCvvByPanResponse
            {
                CardProxy = response.CardProxy,
                ValidationStatus = response.ValidationStatus,
                Header = new DcppContract.ResponseHeader
                {
                    StatusCode = response.Header?.StatusCode

                }
            };
        }

        public AdjustBalanceResponse AdjustBalance(AccountIdentifier accountIdentifier, decimal amount, bool allowNegativeBalance,
            string currencyCode, string transClass, string transactionReferenceId, string description, string comment,
            string commentPostfix = ",FT", int? requestTimeout = null, string originalTransactionId = null)
        {
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            if (requestTimeout == null)
                GetTimeout("X-GD-Bos-Dcpp-AdjustBalanceTimeOut", out requestTimeout, accountIdentifier);

            if (OptionsContext.Current.IsDefined("X-GD-Bos-Dcpp-AdjustBalanceFailure"))
            {
                throw new DcppException(OptionsContext.Current.GetInt("X-GD-Bos-Dcpp-AdjustBalanceFailure", 0), 0, "DCPP did not return success for AdjustAccountBalance");
            }

            if (OptionsContext.Current.IsDefined("X-GD-Bos-CPM-AdjustBalanceFailure"))
            {
                throw new CpmException(OptionsContext.Current.GetInt("X-GD-Bos-CPM-AdjustBalanceFailure", 0), 0, "CPM did not return success for AdjustAccountBalance");
            }

            var cpmRequest = new CPMContract.Message.Request.AdjustAccountBalanceRequest
            {
                AccountId = accountIdentifier.ToString(),
                Adjustment = new CPMContract.Message.CurrencyAmount
                {
                    Amount = amount,
                    CurrencyCode = currencyCode
                },
                TransClass = transClass,
                TransactionReferenceId = transactionReferenceId,
                Description = description,
                Comment = comment + commentPostfix,
                AllowNegativeBalance = allowNegativeBalance,
                //After CBS-6940, no need to re-generate RequestId.
                //  Orchestration will take transCode into compose orchestration id also.
                //  reversal case would have different orchestration id for cached response
                Header = new RequestHeader
                {
                    RequestId = reqId,
                    Source = null,
                    Options = new Dictionary<string, string> { { "OriginalTransactionId", originalTransactionId } }
                },
                ProgramCode = DomainContext.Current?.ProgramCode?.ToString()
            };

            var response = _serviceInvokeProvider.GetResponseAsync<CPMContract.Message.Request.AdjustAccountBalanceRequest, CPMContract.Message.Response.AdjustAccountBalanceResponse>(
                _cpmBaseUrl + _adjustAccountBalanceUrl, "POST", cpmRequest, null, requestTimeout).Result;

            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for CPM AdjustAccountBalance.");

            if (response.Header.StatusCode != "200")
                throw new CpmException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                        $"A downstream provider did not return success for CPM AdjustAccountBalance: Message: {response.Header.ErrorInfo.Message};");

            return new AdjustBalanceResponse
            {
                AvailableBalance = response.AvailableBalance.Amount,
                CurrentBalance = response.CurrentBalance.Amount,
                CurrencyCode = response.AvailableBalance.CurrencyCode
            };
        }

        public AdjustBalanceResponse AdjustPurseBalance(AccountIdentifier accountIdentifier,
            AccountBalanceIdentifier accountBalanceIdentifier, decimal amount, bool allowNegativeBalance, string currencyCode,
            string transClass, string transactionReferenceId, string description, string comment,
            string commentPostfix = ",FT")
        {
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);
            GetTimeout("X-GD-Bos-Dcpp-AdjustPurseBalanceTimeOut", out var requestTimeout, accountBalanceIdentifier);

            var cpmRequest = new CPMContract.Message.Request.AdjustPurseBalanceRequest()
            {
                AccountIdentifier = accountIdentifier,
                AccountBalanceIdentifier = accountBalanceIdentifier.ToGuid(),
                Amount = new CPMContract.Message.CurrencyAmount
                {
                    Amount = amount,
                    CurrencyCode = currencyCode
                },
                TransClass = transClass,
                TransactionReferenceId = transactionReferenceId,
                Description = description,
                Comment = comment + commentPostfix,
                AllowNegativeBalance = allowNegativeBalance,
                //After CBS-6940, no need to re-generate RequestId, as Orchestration will take transCode into compose orchestration id.
                //  although real-time reversal has same requestId, but it has different transCode (ACI).
                Header = new RequestHeader { RequestId = reqId, Source = null },
                //Header = new RequestHeader() { RequestId = reqId, Source = _source },
                ProgramCode = DomainContext.Current?.ProgramCode?.ToString()
            };

            var response = _serviceInvokeProvider.GetResponseAsync<CPMContract.Message.Request.AdjustPurseBalanceRequest, CPMContract.Message.Response.AdjustPurseBalanceResponse>(
                _cpmBaseUrl + _adjustPurseBalanceUrl, "POST", cpmRequest, null, requestTimeout).Result;


            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for CPM AdjustPurseBalance.");

            if (response.Header.StatusCode != "200")
                throw new CpmException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for CPM AdjustPurseBalance: Message: {response.Header.ErrorInfo.Message};");

            return new AdjustBalanceResponse
            {
                AvailableBalance = response.AvailableBalance.Amount,
                CurrentBalance = response.CurrentBalance.Amount,
                CurrencyCode = response.AvailableBalance.CurrencyCode
            };
        }

        public OrderCardResponse OrderPhysicalCard(AccountIdentifier accountIdentifier,
            PaymentIdentifierIdentifier paymentIdentifier,
            PaymentInstrumentIdentifier paymentInstrumentIdentifier, string programCode,
            string productMaterialType = null,
            string customCardImageIdentifier = null, ReplacementReason replacementReason = ReplacementReason.NewCard,
            bool override10DayLimit = false, DeliveryMethod deliveryMethod = DeliveryMethod.Regular,
            string retryId = null,
            string source = null,
            bool? waiveFee = null, bool? waiveOvernightFee = null, bool needEmbossing = true, string storeId = null)
        {
            GetTimeout("X-GD-Bos-Dcpp-OrderPhysicalCardTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);
            if (!string.IsNullOrEmpty(retryId))
            {
                reqId = Guid.Parse(retryId);
            }

            #region QA testing timeout from DCPP

            //if (_settings.RetryMaxTimeoutEnable)
            //{
            //    throw new TimeoutException($"RetryMaxTimeoutEnable is set to {_settings.RetryMaxTimeoutEnable} OrderPhysicalCard - so " +
            //                               $"forcing timeout from QA for accountIdentifier: {accountIdentifier}");
            //}

            #endregion

            CPMContract.Message.Request.OrderCardRequest request = new CPMContract.Message.Request.OrderCardRequest
            {
                AccountIdentifier = accountIdentifier.ToGuid(),
                PaymentIdentifierIdentifier = paymentIdentifier.ToGuid(),
                Header = new RequestHeader() { RequestId = reqId, Source = source },
                ReplacementReason =
                    (CPMContract.Enums.ReplacementReason)Enum.Parse(typeof(CPMContract.Enums.ReplacementReason),
                        replacementReason.ToString()),
                PaymentInstrumentIdentifier = paymentInstrumentIdentifier.ToGuid(),
                Override10DayLimit = override10DayLimit,
                DeliveryMethod = (CPMContract.Enums.DeliveryMethod)Enum.Parse(typeof(CPMContract.Enums.DeliveryMethod),
                    deliveryMethod.ToString()),
                ProgramCode = programCode,
                ProductMaterialType = productMaterialType,
                CustomCardImageIdentifier = customCardImageIdentifier,
                WaiveFee = waiveFee,
                WaiveOvernightFee = waiveOvernightFee,
                OverrideDispatIndicator = true,
                NeedEmbossing = needEmbossing,
                StoreId = storeId
            };

            var response = _serviceInvokeProvider
                .GetResponseAsync<CPMContract.Message.Request.OrderCardRequest,
                    CPMContract.Message.Response.OrderCardResponse>(
                    string.Format(_cpmBaseUrl + _orderPhysicalCardUrl, request.ProgramCode), "POST", request, null,
                    requestTimeout).Result;

            if (response == null)
                throw new Exception(
                    $"A downstream CbsDcpp provider did not return a recognizable response for OrderPhysicalCard.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0),
                    response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream CbsDcpp provider did not return success for OrderPhysicalCard: Message: {response.Header.ErrorInfo.Message};");

            return new OrderCardResponse()
            {
                Header = new DcppContract.ResponseHeader()
                {
                    StatusCode = response.Header.StatusCode,
                },
                AccountIdentifier = response.AccountIdentifier.ToString(),
                PaymentInstrumentIdentifier = response.PaymentInstrumentIdentifier.ToString(),
            };
        }

        public DcppContract.ReportLostStolenV2Response ReportLostStolen(AccountIdentifier accountIdentifier,
            PaymentInstrumentIdentifier paymentInstrumentIdentifier, LossType lossType, DeliveryMethod deliveryMethod,
            DateTime? dateLastUsed, DateTime? dateDiscoveredMissing, bool? policeNotified, string notes,
            string productMaterialType, bool createVirtualCard, string customCardImageIdentifier = null,
            bool isProductEligibleForDigitalWallet = false, string source = null, bool? waiveFee = null, bool? waiveOvernightFee = null, int PhysicalProductTierKey = 0, bool needEmbossing = true)
        {
            GetTimeout("X-GD-Bos-Dcpp-ReportLostStolenTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            var request = new CPMContract.Message.Request.ReportLostStolenRequest()
            {
                Header = new RequestHeader() { RequestId = reqId, Source = source },
                ProgramCode = DomainContext.Current?.ProgramCode?.ToString(),
                AccountIdentifier = accountIdentifier.ToGuid(),
                PaymentInstrumentIdentifier = paymentInstrumentIdentifier.ToGuid(),
                LossType = (CPMContract.Enums.LossType)Enum.Parse(typeof(CPMContract.Enums.LossType),
                    lossType.ToString()),
                DeliveryMethod = (CPMContract.Enums.DeliveryMethod)Enum.Parse(typeof(CPMContract.Enums.DeliveryMethod),
                    deliveryMethod.ToString()),
                DateLastUsed = dateLastUsed,
                DateDiscoveredMissing = dateDiscoveredMissing,
                PoliceNotified = policeNotified ?? false,
                Notes = notes,
                ProductMaterialType = productMaterialType,
                CustomCardImageIdentifier = customCardImageIdentifier,
                IsProductEligibleForDigitalWallet = isProductEligibleForDigitalWallet,
                CreateVirtualCard = createVirtualCard,
                WaiveFee = waiveFee,
                WaiveOvernightFee = waiveOvernightFee,
                OverrideDispatIndicator = true,
                OrderPhysicalCard = true,
                NeedEmbossing = needEmbossing
            };

            var response = _serviceInvokeProvider
                .GetResponseAsync<CPMContract.Message.Request.ReportLostStolenRequest,
                    CPMContract.Message.Response.ReportLostStolenResponse>(
                    string.Format(_cpmBaseUrl + _reportLostStolenUrl, request.ProgramCode), "POST", request,
                    null, requestTimeout).Result;

            if (response == null)
                throw new Exception(
                    $"A downstream CbsDcpp provider did not return a recognizable response for ReportLostStolen.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0),
                    response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream CbsDcpp provider did not return success for ReportLostStolen: Message: {response.Header.ErrorInfo.Message};");

            var reportLostStolenResponse = new DcppContract.ReportLostStolenV2Response()
            {
                Header = new DcppContract.ResponseHeader()
                {
                    StatusCode = response.Header.StatusCode,
                },
                AccountIdentifier = response.AccountIdentifier.ToString(),
                PaymentIdentifierIdentifier = response.PaymentIdentifierIdentifier.ToString(),
                PaymentInstrumentIdentifier = response.PaymentInstrumentIdentifier.ToString(),
                PhysicalPaymentInstrumentIdentifier = response.PhysicalPaymentInstrumentIdentifier == Guid.Empty ? null : response.PhysicalPaymentInstrumentIdentifier.ToString()
            };
            return reportLostStolenResponse;
        }

        public DcppContract.ReportLostStolenV2Response ReportLostStolenv2(AccountIdentifier accountIdentifier,
            PaymentInstrumentIdentifier paymentInstrumentIdentifier, LossType lossType, DeliveryMethod deliveryMethod,
            DateTime? dateLastUsed, DateTime? dateDiscoveredMissing, bool? policeNotified, string notes,
            string productMaterialType, bool createVirtualCard, string customCardImageIdentifier = null,
            bool isProductEligibleForDigitalWallet = false, string source = null, bool? waiveFee = null,
            bool? waiveOvernightFee = null, int PhysicalProductTierKey = 0, bool needEmbossing = true,
            bool override10DayLimit = false, Guid? requestId = null, string programCode = "", string storeId = null)
        {
            GetTimeout("X-GD-Bos-Dcpp-ReportLostStolenTimeOut", out var requestTimeout);
            programCode = string.IsNullOrEmpty(programCode) ? DomainContext.Current?.ProgramCode?.ToString() : programCode;
            Guid reqId = Guid.NewGuid();
            if (requestId != null)
            {
                reqId = requestId.Value;
            }
            else
            {
                Guid.TryParse(OptionsContext.Current.GetString("requestId"), out reqId);
            }

            var request = new CPMContract.Message.Request.ReportLostStolenV2Request()
            {
                Header = new RequestHeader() { RequestId = reqId, Source = source },
                ProgramCode = programCode,
                AccountIdentifier = accountIdentifier.ToGuid(),
                PaymentInstrumentIdentifier = paymentInstrumentIdentifier.ToGuid(),
                LossType = (CPMContract.Enums.LossType)Enum.Parse(typeof(CPMContract.Enums.LossType),
                    lossType.ToString()),
                DeliveryMethod = (CPMContract.Enums.DeliveryMethod)Enum.Parse(typeof(CPMContract.Enums.DeliveryMethod),
                    deliveryMethod.ToString()),
                DateLastUsed = dateLastUsed,
                DateDiscoveredMissing = dateDiscoveredMissing,
                PoliceNotified = policeNotified ?? false,
                ProductMaterialType = productMaterialType,
                CustomCardImageIdentifier = customCardImageIdentifier,
                IsProductEligibleForDigitalWallet = isProductEligibleForDigitalWallet,
                CreateVirtualCard = createVirtualCard,
                WaiveFee = waiveFee,
                WaiveOvernightFee = waiveOvernightFee,
                OverrideDispatIndicator = true,
                NeedEmbossing = needEmbossing,
                StoreId = storeId
            };

            var response = _serviceInvokeProvider
                .GetResponseAsync<CPMContract.Message.Request.ReportLostStolenV2Request,
                    CPMContract.Message.Response.ReportLostStolenV2Response>(
                    string.Format(_cpmBaseUrl + _reportLostStolenV2Url, request.ProgramCode), "POST", request,
                    null, requestTimeout).Result;

            if (response == null)
                throw new Exception(
                    $"A downstream CbsDcpp provider did not return a recognizable response for ReportLostStolen.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0),
                    response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream CbsDcpp provider did not return success for ReportLostStolen: Message: {response.Header.ErrorInfo.Message};");

            var paymentIdentifier = _paymentIdentifierRepository.GetPaymentIdentifierByPaymentInstrumentIdentifier(paymentInstrumentIdentifier, out _);
            if (createVirtualCard && paymentIdentifier.PaymentInstrument.PaymentInstrumentType != Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PaymentInstrumentType.Virtual)
            {
                var accountProductTierClassKey = _accountRepository.GetProductTierClassByAccountIdentifier(accountIdentifier);
                var productTier = GetProductTier(request.ProgramCode, paymentIdentifier.ProductCode, productMaterialType, paymentIdentifier.CardStock, accountProductTierClassKey, out _);
                var retryOrderPhysicalCard = new RetryOrderPhysicalCard
                {
                    RetryId = Guid.NewGuid().ToString(),
                    WaitIntervalSeconds = _settings.WaitIntervalSecondsForEnrollOrderCard, //GBOS-78646 Set wait period to the same as for order card
                    RetryCount = 0,
                    MaxRetryCount = 3,
                    PaymentInstrumentIdentifier = response.PaymentInstrumentIdentifier.ToString(), //paymentInstrumentIdentifier.ToString(),
                    AccountIdentifier = accountIdentifier.ToString(),
                    CustomCardImageIdentifier = customCardImageIdentifier,
                    DateDiscMissing = dateDiscoveredMissing,
                    DateLastUsed = dateLastUsed,
                    DeliveryMethod = deliveryMethod,
                    LossType = lossType,
                    Notes = notes,
                    PoliceNotified = policeNotified,
                    ProductMaterialType = productTier.ProductMaterialType,//productMaterialType,
                    ProgramCode = request.ProgramCode,
                    StateInfo = "orderPhysicalCard",
                    ReplaceCardOriginalRequestId = reqId.ToString(),
                    WaiveFee = waiveFee,
                    WaiveOvernightFee = waiveOvernightFee,
                    Override10DayLimit = override10DayLimit,
                    ProductTier = productTier,
                    AccountProductTierClassKey = accountProductTierClassKey,
                    Source = source,
                    NeedEmbossing = needEmbossing,
                    ReplacementReason = Gd.Bos.Shared.Common.CBSProcessorManager.Contract.Enums.ReplacementReason.VirtualCardLostStolenReplacement
                };
                _asyncCommandService.Send(retryOrderPhysicalCard);
            }

            var reportLostStolenResponse = new DcppContract.ReportLostStolenV2Response()
            {
                Header = new DcppContract.ResponseHeader()
                {
                    StatusCode = response.Header.StatusCode,
                },
                AccountIdentifier = response.AccountIdentifier.ToString(),
                PaymentIdentifierIdentifier = response.PaymentIdentifierIdentifier.ToString(),
                PaymentInstrumentIdentifier = response.PaymentInstrumentIdentifier.ToString()
            };
            return reportLostStolenResponse;
        }

        public DcppContract.ReportLostStolenV2Response ReportLostStolenRetry(AccountIdentifier accountIdentifier,
            PaymentInstrumentIdentifier paymentInstrumentIdentifier, Guid requestId, LossType lossType,
            DeliveryMethod deliveryMethod, DateTime? dateLastUsed, DateTime? dateDiscoveredMissing, bool? policeNotified,
            string notes, string productMaterialType, bool createVirtualCard, string programCode, string customCardImageIdentifier = null,
            bool isProductEligibleForDigitalWallet = false, string source = null, bool? waiveFee = null, bool? waiveOvernightFee = null, int PhysicalProductTierKey = 0, bool needEmbossing = true)
        {
            GetTimeout("X-GD-Bos-Dcpp-ReportLostStolenTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            var request = new CPMContract.Message.Request.ReportLostStolenRequest()
            {
                Header = new RequestHeader() { RequestId = reqId, Source = source },
                ProgramCode = DomainContext.Current?.ProgramCode?.ToString(),
                AccountIdentifier = accountIdentifier.ToGuid(),
                PaymentInstrumentIdentifier = paymentInstrumentIdentifier.ToGuid(),
                LossType = (CPMContract.Enums.LossType)Enum.Parse(typeof(CPMContract.Enums.LossType),
                    lossType.ToString()),
                DeliveryMethod = (CPMContract.Enums.DeliveryMethod)Enum.Parse(typeof(CPMContract.Enums.DeliveryMethod),
                    deliveryMethod.ToString()),
                DateLastUsed = dateLastUsed,
                DateDiscoveredMissing = dateDiscoveredMissing,
                PoliceNotified = policeNotified ?? false,
                Notes = notes,
                ProductMaterialType = productMaterialType,
                CustomCardImageIdentifier = customCardImageIdentifier,
                IsProductEligibleForDigitalWallet = isProductEligibleForDigitalWallet,
                CreateVirtualCard = createVirtualCard,
                WaiveFee = waiveFee,
                WaiveOvernightFee = waiveOvernightFee,
                OverrideDispatIndicator = true,
                OrderPhysicalCard = true,
                NeedEmbossing = needEmbossing
            };

            var response = _serviceInvokeProvider
                .GetResponseAsync<CPMContract.Message.Request.ReportLostStolenRequest,
                    CPMContract.Message.Response.ReportLostStolenResponse>(
                    string.Format(_cpmBaseUrl + _reportLostStolenUrl, request.ProgramCode), "POST", request,
                    null, requestTimeout).Result;

            if (response == null)
                throw new Exception(
                    $"A downstream CbsDcpp provider did not return a recognizable response for ReportLostStolen.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0),
                    response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream CbsDcpp provider did not return success for ReportLostStolen: Message: {response.Header.ErrorInfo.Message};");

            var reportLostStolenResponse = new DcppContract.ReportLostStolenV2Response()
            {
                Header = new DcppContract.ResponseHeader()
                {
                    StatusCode = response.Header.StatusCode,
                },
                AccountIdentifier = response.AccountIdentifier.ToString(),
                PaymentIdentifierIdentifier = response.PaymentIdentifierIdentifier.ToString(),
                PaymentInstrumentIdentifier = response.PaymentInstrumentIdentifier.ToString(),
                PhysicalPaymentInstrumentIdentifier = response.PhysicalPaymentInstrumentIdentifier == Guid.Empty ? null : response.PhysicalPaymentInstrumentIdentifier.ToString()
            };
            return reportLostStolenResponse;
        }

        public void SetPin(AccountIdentifier accountIdentifier, string paymentInstrumentIdentifier, string pin)
        {
            GetTimeout("X-GD-Bos-CPM-SetPinTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            var request = new SetAtmPinRequest
            {
                Header = new RequestHeader() { RequestId = reqId, Source = null },
                ProgramCode = DomainContext.Current?.ProgramCode?.ToString(),
                AccountIdentifier = accountIdentifier.ToString(),
                PaymentInstrumentIdentifier = paymentInstrumentIdentifier,
                Pin = pin
            };

            var response = _serviceInvokeProvider.GetResponseAsync<SetAtmPinRequest, SetAtmPinResponse>(
                    _cpmBaseUrl + _setPinUrl, "POST", request, null, requestTimeout).Result;

            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for SetPin.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                        $"A downstream provider did not return success for SetPin: Message: {response.Header.ErrorInfo.Message};");
        }

        public bool VerifyPin(AccountIdentifier accountIdentifier, string paymentInstrumentIdentifier, string pin)
        {
            throw new NotImplementedException();
        }

        public void ActivateCard(AccountIdentifier accountIdentifier, string paymentInstrumentIdentifier, string source = null)
        {
            if (OptionsContext.Current.IsDefined("X-GD-Bos-Dcpp-ActivateCardFailure"))
                throw new DcppException(OptionsContext.Current.GetInt("X-GD-Bos-Dcpp-ActivateCardFailure", 0), 0, "DCPP did not return success for ActivateCard");
            GetTimeout("X-GD-Bos-CPM-ActivateCardTimeOut", out var requestTimeout);
            
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);
            var cpmRequest = new CPMContract.Message.Request.ActivateCardRequest
            {
                Header = new RequestHeader() { RequestId = reqId, Source = source },
                AccountIdentifier = accountIdentifier,
                PaymentInstrumentIdentifier = Guid.Parse(paymentInstrumentIdentifier),
                ProgramCode = DomainContext.Current?.ProgramCode?.ToString(),
                Source = source
            };

            var response = _serviceInvokeProvider.GetResponseAsync<CPMContract.Message.Request.ActivateCardRequest, CPMContract.Message.Response.ActivateCardResponse>(
                       _cpmBaseUrl + string.Format(_activateCardUrl, DomainContext.Current?.ProgramCode?.ToString()), 
                       "POST", cpmRequest, null, requestTimeout).Result;
            if (response == null)
                throw new Exception($"CPM service did not return a recognizable response for ActivateCard.");
            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for ActivateCard: Message: {response.Header.ErrorInfo.Message};");
        }

        public ActivateSampleCardResponse ActivateSamplesCard(AccountIdentifier accountIdentifier, string cardProxy, bool? isEmv,
            string cardStockCode, string embossedName, string accountNumber, string productCode)
        {
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            ActivateProspectSampleCardRequest activateProspectSampleCardRequest = new ActivateProspectSampleCardRequest()
            {
                ProductCode = productCode,
                AccountIdentifier = accountIdentifier.ToString(),
                CardProxy = cardProxy,
                PaymentInstrumentType = isEmv != null && (bool)isEmv ? PaymentInstrumentType.Emv : PaymentInstrumentType.MagStripe,
                CardStockCode = cardStockCode,
                AccountNumber = accountNumber,
                ProgramCode = DomainContext.Current?.ProgramCode?.ToString(),
                Header = new RequestHeader() { RequestId = reqId }
            };
            var response = _serviceInvokeProvider.GetResponseAsync<ActivateProspectSampleCardRequest, ActivateProspectSampleCardResponse>(
                $"{_cpmBaseUrl}{string.Format(_activateProspectSampleCard, DomainContext.Current?.ProgramCode?.ToString())}", "POST", activateProspectSampleCardRequest, null).Result;
            if (response == null)
                throw new Exception($"CPM service did not return a recognizable response for ActivateProspectSampleCard.");

            if (response.Header.StatusCode == "400" && response.Header.ErrorInfo.SubStatusCode == "5012")
                throw new ValidationException(int.Parse(response.Header.StatusCode),
                    int.Parse(response.Header.ErrorInfo.SubStatusCode),
                    "Sample card is already in use");
            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0),
                    response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for ActivateProspectSampleCard: Message: {response.Header.ErrorInfo.Message};");

            var activateSampleCardResponse = new ActivateSampleCardResponse()
            {
                Header = new DcppContract.ResponseHeader
                {
                    StatusCode = response.Header?.StatusCode,
                    ErrorInfo = new Gd.Bos.Dcpp.Contract.Data.ErrorInfo
                    {
                        Details = response.Header?.ErrorInfo?.Details,
                        Message = response.Header?.ErrorInfo?.Message,
                        SubStatusCode = response.Header?.ErrorInfo?.SubStatusCode,
                        Source = response.Header?.ErrorInfo?.Source,
                    },
                },
                AccountIdentifier = response.AccountIdentifier,
                PaymentIdentifier = response.PaymentIdentifier,
                PaymentInstrumentIdentifier = response.PaymentInstrumentIdentifier,
                Status = response.Header?.StatusCode,
                AccountBalanceIdentifier = response.AccountBalanceIdentifier,
                AccountNumber = response.AccountNumber,
                RoutingNumber = response.RoutingNumber,

            };
            return activateSampleCardResponse;
        }

        public ValidateCVVResponse ValidateCvv(string pan, string cvv, string accountIdentifier, CardExpirationDate cardExpirationDate,
           bool usePan)
        {
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            var cpmRequest = new ValidateCvvRequest
            {
                AccountIdentifier = Guid.Parse(accountIdentifier),
                Header = new RequestHeader { RequestId = reqId, Source = null },
                ProgramCode = DomainContext.Current?.ProgramCode?.ToString(),
                Pan = pan,
                Cvv = cvv,
                ExpirationDate = new CPMContract.Data.ExpirationDate
                {
                    Year = cardExpirationDate.CardExpirationYear,
                    Month = cardExpirationDate.CardExpirationMonth
                },
                UsePan = usePan
            };

            var response = _serviceInvokeProvider.GetResponseAsync<ValidateCvvRequest, ValidateCvvResponse>(
                       _cpmBaseUrl + string.Format(_validateCvvUrl, DomainContext.Current?.ProgramCode?.ToString()), 
                       "POST", cpmRequest, null).Result;
            if (response == null)
                throw new Exception("CPM service did not return a recognizable response for ValidateCvv.");

            if (response.Header?.StatusCode != "200" && response.Header?.StatusCode != "0")
                throw new Exception($"CPM did not return success for ValidateCvv: Message: {response.Header?.ErrorInfo.Message},StatusCode: {response.Header?.StatusCode}, SubStatusCode: {response.Header?.StatusCode}, ErrorReason: {response.Header?.ErrorInfo.Message}");

            var serviceResponse = new ValidateCVVResponse
            {
                Header = new DcppContract.ResponseHeader
                {
                    StatusCode = response.Header?.StatusCode,
                    ErrorInfo = new Gd.Bos.Dcpp.Contract.Data.ErrorInfo
                    {
                        Details = response.Header?.ErrorInfo?.Details,
                        Message = response.Header?.ErrorInfo?.Message,
                        SubStatusCode = response.Header?.ErrorInfo?.SubStatusCode,
                        Source = response.Header?.ErrorInfo?.Source,
                    },

                },
                AccountIdentifier = accountIdentifier,
                PaymentInstrumentIdentifier = response.PaymentInstrumentIdentifier.ToString(),
                ValidationStatus = response.ValidateCvvSuccess
            };
            return serviceResponse;
        }

        public ChangeAccountStatusResponse ChangeAccountStatus(string accountId, string accountStatus, List<CPMAccountStatusReason> accountStatusReasonsToAdd = null, List<CPMAccountStatusReason> accountStatusReasonsToRemove = null, Guid? userIdentifier = null)
        {
            GetTimeout("X-GD-Bos-CPM-SetPinTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            CPMContract.Enums.AccountStatus enumAccountStatus = CPMContract.Enums.AccountStatus.Normal;
            if (!Enum.TryParse(accountStatus, out enumAccountStatus))
            {
                throw new Exception($"Unknow AccountStatus {accountStatus} is not supported.");
            }

            //var binType = _accountRepository.GetAccountBinType(AccountIdentifier.FromString(accountId));
            if (enumAccountStatus == CPMContract.Enums.AccountStatus.Restricted)
            {
                enumAccountStatus = CPMContract.Enums.AccountStatus.Normal;
            }

            var request = new ChangeAccountStatusRequest
            {
                Header = new RequestHeader() { RequestId = reqId, Source = null },
                ProgramCode = DomainContext.Current?.ProgramCode?.ToString(),
                AccountIdentifier = AccountIdentifier.FromString(accountId),
                AccountStatus = enumAccountStatus,
                AccountStatusReasonsToAdd = accountStatusReasonsToAdd ?? new List<CPMAccountStatusReason>(),
                AccountStatusReasonsToRemove = accountStatusReasonsToRemove ?? new List<CPMAccountStatusReason>(),
                UserIdentifier = userIdentifier
            };

            var response = _serviceInvokeProvider.GetResponseAsync<ChangeAccountStatusRequest, CPMContract.Message.Response.ChangeAccountStatusResponse>(
                    _cpmBaseUrl + string.Format(_changeAccountStatusUrl, request.ProgramCode), 
                    "POST", request, null, requestTimeout).Result;

            if (response == null)
                throw new Exception($"[CPM] A downstream provider did not return a recognizable response for ChangeAccountStatus.");

            if (response.Header.StatusCode != "200" && response.Header.StatusCode != "0" && response.Header.ErrorInfo?.SubStatusCode != "+000002003")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                        $"[CPM] A downstream provider did not return success for ChangeAccountStatus: Message: {response.Header.ErrorInfo.Message}, {response.Header.ErrorInfo.Details};");

            return new ChangeAccountStatusResponse()
            {
                Header = new DcppContract.ResponseHeader()
                {
                    StatusCode = response.Header?.StatusCode,
                    ErrorInfo = new Gd.Bos.Dcpp.Contract.Data.ErrorInfo
                    {
                        Details = response.Header?.ErrorInfo?.Details,
                        Message = response.Header?.ErrorInfo?.Message,
                        SubStatusCode = response.Header?.ErrorInfo?.SubStatusCode,
                        Source = response.Header?.ErrorInfo?.Source,
                    },
                }
            };
        }

        public ChangePurseStatusResponse ChangePurseStatus(string accountIdentifier, string purseIdentifier, string accountStatus)
        {
            GetTimeout("X-GD-Bos-Dcpp-ChangePurseStatusTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);
            if (reqId == Guid.Empty) reqId = Guid.NewGuid();

            var response = _serviceInvokeProvider.GetResponseAsync<CPMContract.Message.Request.ChangePurseStatusRequest, CPMContract.Message.Response.ChangePurseStatusResponse>(
                _cpmBaseUrl + _changePurseStatusUrl,
                "POST",
                new CPMContract.Message.Request.ChangePurseStatusRequest()
                {
                    AccountIdentifier = accountIdentifier,
                    PurseIdentifier = purseIdentifier,
                    Status = accountStatus,
                    Header = new RequestHeader() { RequestId = reqId, Source = null },
                    ProgramCode = DomainContext.Current?.ProgramCode?.ToString()
                }, null, requestTimeout).Result;
            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for {_changePurseStatusUrl}.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for {_changePurseStatusUrl}: Message: {response.Header.ErrorInfo.Message};");

            return new ChangePurseStatusResponse()
            {
                Header = new DcppContract.ResponseHeader()
                {
                    StatusCode = response.Header?.StatusCode,
                    ErrorInfo = new Gd.Bos.Dcpp.Contract.Data.ErrorInfo
                    {
                        Details = response.Header?.ErrorInfo?.Details,
                        Message = response.Header?.ErrorInfo?.Message,
                        SubStatusCode = response.Header?.ErrorInfo?.SubStatusCode,
                        Source = response.Header?.ErrorInfo?.Source,
                    },
                }
            };
        }

        public DcppContract.UpdateAccountResponse UpdateAccount(DcppContract.UpdateAccountRequest request, string middleName = null)
        {
            GetTimeout("X-GD-Bos-CPM-UpdateAccount", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);
            if (reqId == Guid.Empty)
                reqId = request?.Header?.RequestId ?? Guid.NewGuid();

            request.ProgramCode = string.IsNullOrEmpty(request?.ProgramCode) ? DomainContext.Current?.ProgramCode?.ToString() : request?.ProgramCode;

            var cpmRequest = new CPMContract.Message.Request.UpdateAccountRequest()
            {
                Header = new RequestHeader() { RequestId = reqId, Source = null },
                AccountIdentifier = Guid.Parse(request?.AccountIdentifier),
                BusinessName = request?.BusinessName,
                HomeAddressUpdateUsers = request?.HomeAddressUpdateUsers,
                Name = new CPMContract.Data.CardholderName()
                {
                    FirstName = request?.Name?.FirstName,
                    LastName = request?.Name?.LastName,
                    MiddleInitial = request?.Name?.MiddleInitial,
                    MiddleName = middleName
                },
                PaymentIdentifierIdentifier = request.PaymentIdentifierIdentifier,
                PhoneNumbers = request.PhoneNumbers?.Select(x => new CPMContract.Data.PhoneNumber()
                {
                    Number = x.Number,
                    PhoneType = (CPMContract.Data.PhoneType)(int)x.Type,
                    IsPrimary = x.IsPrimary,

                }).ToList(),
                PostalAddress = new CPMContract.Data.PostalAddress()
                {
                    AddressLines = request?.PostalAddress?.AddressLines,
                    City = request?.PostalAddress?.City,
                    Country = request?.PostalAddress?.Country,
                    CountrySubdivision = request?.PostalAddress?.CountrySubdivision,
                    County = request?.PostalAddress?.County,
                    PostalCode = request?.PostalAddress?.PostalCode,
                },
                ProgramCode = request.ProgramCode,
                EmailAddress = request.EmailAddress
            };

            var response = _serviceInvokeProvider.GetResponseAsync<CPMContract.Message.Request.UpdateAccountRequest, CPMContract.Message.Response.UpdateAccountResponse>(
                    _cpmBaseUrl + string.Format(_updateAccountUrl, request.ProgramCode), 
                    "POST", cpmRequest, null, requestTimeout).Result;
            if (response == null)
                throw new Exception($"[CPM] A downstream provider did not return a recognizable response for UpdateAccount.");

            if (response.Header?.StatusCode != "200" && response.Header?.StatusCode != "0")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"[CPM] A downstream provider did not return success for UpdateAccount: Message: {response.Header.ErrorInfo.Message};");

            return new DcppContract.UpdateAccountResponse()
            {
                Header = new DcppContract.ResponseHeader()
                {
                    StatusCode = response.Header?.StatusCode,
                    ErrorInfo = new Gd.Bos.Dcpp.Contract.Data.ErrorInfo
                    {
                        Details = response.Header?.ErrorInfo?.Details,
                        Message = response.Header?.ErrorInfo?.Message,
                        SubStatusCode = response.Header?.ErrorInfo?.SubStatusCode,
                        Source = response.Header?.ErrorInfo?.Source,
                    },
                }
            };
        }

        public DcppContract.OverrideProductResponse OverrideProduct(string accountIdentifier, string programCode, bool isRevert,
            List<Gd.Bos.Shared.Common.Dcpp.Contract.Data.ProductFeatureGroupOverride> productFeatureGroups)
        {
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);
            var productFeatureGroupOverrides = new List<ProductFeatureGroupOverride>();
            if (!isRevert)
            {
                foreach (var productFeature in productFeatureGroups)
                {
                    var productFeatureGroupOverride = new ProductFeatureGroupOverride()
                    {
                        ProductTierAttribute = productFeature.ProductTierAttribute,
                        Value = productFeature.Value
                    };
                    productFeatureGroupOverrides.Add(productFeatureGroupOverride);
                }
            }

            var cpmRequest = new OverrideProductRequest()
            {
                Header = new RequestHeader()
                {
                    Source = null,
                    RequestId = reqId
                },
                AccountIdentifier = accountIdentifier,
                ProgramCode = programCode,
                IsRevert = isRevert,
                ProductFeatureGroupOverrides = productFeatureGroupOverrides
            };

            var response = _serviceInvokeProvider.GetResponseAsync<OverrideProductRequest, CPMContract.Message.Response.OverrideProductResponse>(
                 string.Format(_cpmBaseUrl + _overrideProductUrl, programCode, accountIdentifier), 
                 "POST", cpmRequest, null).Result;
            if (response == null)
                throw new Exception($"CPM service did not return a recognizable response for OverrideProduct.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for OverrideProductResponse: Message: {response.Header.ErrorInfo.Message};");

            return new DcppContract.OverrideProductResponse()
            {
                Header = new DcppContract.ResponseHeader()
                {
                    ErrorInfo = new Gd.Bos.Dcpp.Contract.Data.ErrorInfo()
                    {
                        Source = null,
                        Message = response.Header?.ErrorInfo?.Message,
                        Details = response.Header?.ErrorInfo?.Details,
                        SubStatusCode = response.Header?.ErrorInfo?.SubStatusCode
                    },
                    StatusCode = response.Header?.StatusCode,
                }
            };
        }

        public AddPurseResponse AddPurseToAccount(string programCode, AccountIdentifier accountIdentifier, PurseType purseType,
            string userDescription = null, decimal? goalAmount = null, string goalDate = null, string iconName = null,
            string purseSubType = null)
        {

            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            var response = _serviceInvokeProvider.GetResponseAsync<DcppContract.AddPurseToAccountRequest, DcppContract.AddPurseToAccountResponse>(
                string.Format(_cpmBaseUrl + _addPurseToAccountUrl, programCode), "POST", new DcppContract.AddPurseToAccountRequest()
                {
                    Header = new DcppContract.
                        RequestHeader()
                    { RequestId = reqId },
                    ProgramCode = programCode,
                    AccountIdentifier = accountIdentifier.ToString(),
                    UserDescription = userDescription,
                    PurseType = purseType.ToPurseType().ToString(),
                    GoalAmount = goalAmount,
                    GoalDate = goalDate,
                    IconName = iconName,
                    PurseSubType = purseSubType
                }, null).Result;
            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for {_addPurseToAccountUrl}.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for {_addPurseToAccountUrl}: Message: {response.Header.ErrorInfo.Message};");

            return new AddPurseResponse()
            {
                AccountIdentifier = response.AccountIdentifier,
                PurseType = response.PurseType.ToPurseType(),
                AccountBalanceIdentifier = response.AccountBalanceIdentifier,
                AccountBalanceKey = response.AccountBalanceKey,
                AvailableBalance = new CurrencyAmount { Amount = response.AvailableBalance.Amount, CurrencyCode = response.AvailableBalance.CurrencyCode },
                AvailableBalanceAsOfDate = response.AvailableBalanceAsOfDate,
                CurrentBalance = new CurrencyAmount { Amount = response.CurrentBalance.Amount, CurrencyCode = response.CurrentBalance.CurrencyCode },
                CurrentBalanceAsOfDate = response.CurrentBalanceAsOfDate,
                UserDescription = response.UserDescription,
                IsHidden = response.IsHidden,
                Status = (PurseStatus)((int)response.Status),
                GoalAmount = response.GoalAmount,
                IconName = response.IconName,
                CreateDate = response.CreateDate,
                ChangeDate = response.ChangeDate,
                PurseNumber = response.PurseNumber,
                PurseSubType = response.PurseSubType
            };


        }

        public UpdateProductResponse UpdateProduct(string accountIdentifier, string programCode, int productTierKey,
            string productMaterialType, string cardStock = null)
        {
            if (OptionsContext.Current.IsDefined("X-GD-Bos-Dcpp-UpdateProductFailure"))
                throw new DcppException(OptionsContext.Current.GetInt("X-GD-Bos-Dcpp-UpdateProductFailure", 0), 0, "DCPP did not return success for UpdateProduct");
            GetTimeout("X-GD-Bos-CPM-UpdateProductTimeOut", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            var cpmRequest = new CPMContract.Message.Request.UpdateProductRequest()
            {
                Header = new RequestHeader()
                {
                    Source = null,
                    RequestId = reqId
                },
                AccountIdentifier = accountIdentifier,
                ProgramCode = programCode,
                ProductTierKey = productTierKey,
                ProductMaterialType = productMaterialType,
                CardStock = cardStock
            };

            var response = _serviceInvokeProvider.GetResponseAsync<CPMContract.Message.Request.UpdateProductRequest, CPMContract.Message.Response.UpdateProductResponse>(
                 string.Format(_cpmBaseUrl + _updateProductUrl, programCode, accountIdentifier,requestTimeout), 
                 "POST", cpmRequest, null).Result;
            if (response == null)
                throw new Exception($"CPM service did not return a recognizable response for UpdateProduct.");

            if (response.Header.StatusCode != "200" && response.Header.ErrorInfo.Message.Contains("+000002636"))
                throw new DcppException(500, 2636,
                    $"This account cannot be updated to an employee account till 24 hours from the account creation. Please try after 24 hours of account creation.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for UpdateProduct: Message: {response.Header.ErrorInfo.Message};");

            return new UpdateProductResponse()
            {
                Header = new DcppContract.ResponseHeader()
                {
                    ErrorInfo = new Gd.Bos.Dcpp.Contract.Data.ErrorInfo()
                    {
                        Source = null,
                        Message = response.Header?.ErrorInfo?.Message,
                        Details = response.Header?.ErrorInfo?.Details,
                        SubStatusCode = response.Header?.ErrorInfo?.SubStatusCode
                    },
                    StatusCode = response.Header?.StatusCode,
                }
            };
        }

        public ActivateOrSuspendTokenResponse ActivateOrSuspendToken(AccountIdentifier accountIdentifier, string tokenId,
            TokenAction action, string comment)
        {
            throw new NotImplementedException();
        }

        public ChangeCardStatusResponse ChangeCardStatus(Guid accountId, string cardStatus, Guid? paymentIdentifier = null, string lifeTimeEventType = null)
        {
            if (OptionsContext.Current.IsDefined("X-GD-Bos-Dcpp-ChangeCardStatusFailure"))
                throw new DcppException(OptionsContext.Current.GetInt("X-GD-Bos-Dcpp-ChangeCardStatusFailure", 0), 0, "DCPP did not return success for ChangeCardStatus");
            GetTimeout("X-GD-Bos-CPM-ChangeCardStatusTimeOut", out var requestTimeout);
            
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);
            if (!Enum.TryParse(cardStatus, out CardStatus status))
            {
                throw new Exception($"Original status {cardStatus} cannot convert to CPM card status.");
            }

            var cpmRequest = new CPMContract.Message.Request.ChangeCardStatusRequest()
            {
                AccountIdentifier = accountId,
                PaymentIdentifierIdentifier = paymentIdentifier,
                Header = new RequestHeader()
                {
                    Source = null,
                    RequestId = reqId
                },
                Status = status,
                LifeTimeEventType = lifeTimeEventType
            };

            var response = _serviceInvokeProvider.GetResponseAsync<CPMContract.Message.Request.ChangeCardStatusRequest, CPMContract.Message.Response.ChangeCardStatusResponse>(
                 string.Format(_cpmBaseUrl + _changeCardStatusUrl, DomainContext.Current?.ProgramCode?.ToString()), 
                 "POST", cpmRequest, null, requestTimeout).Result;
            if (response == null)
                throw new Exception($"CPM service did not return a recognizable response for ChangeCardStatus.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for ChangeCardStatus: Message: {response.Header.ErrorInfo.Message};");

            return new ChangeCardStatusResponse()
            {
                Header = new DcppContract.ResponseHeader()
                {
                    ErrorInfo = new Gd.Bos.Dcpp.Contract.Data.ErrorInfo()
                    {
                        Source = null,
                        Message = response.Header?.ErrorInfo?.Message,
                        Details = response.Header?.ErrorInfo?.Details,
                        SubStatusCode = response.Header?.ErrorInfo?.SubStatusCode
                    },
                    StatusCode = response.Header?.StatusCode,
                }
            };
        }

        public AddSegmentResponse AddSegment(string paymentIdentifier, string segmentName, DateTime startDate, DateTime endDate,
            string accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public DeleteSegmentResponse DeleteSegment(string paymentIdentifier, string segmentName, string accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public GetAccountYtdFeesResponse GetYearToDateAccountFees(Guid requestId, string programCode, string accountIdentifier)
        {
            GetAccountYtdFeesRequest getAccountYtdFeesRequest = new GetAccountYtdFeesRequest
            {
                Header = new RequestHeader() { RequestId = requestId, Source = null },
                ProgramCode = programCode,
                AccountId = accountIdentifier
            };
            var response = _serviceInvokeProvider.GetResponseAsync<GetAccountYtdFeesRequest, GetAccountYtdFeesResponse>(
                $"{_cpmBaseUrl}{string.Format(_yearTodateFee, programCode)}", 
                "POST", getAccountYtdFeesRequest, null).Result;
            if (response == null)
                throw new Exception($"CPM service did not return a recognizable response for Get Account Fees.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(503), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for Get Account Fees: Message: {response.Header.ErrorInfo.Message}:{response.Header.ErrorInfo.Details};");

            return response;
        }

        public RegisterCardResponse RegisterCard(Guid requestId, string programCode, string productCode, string accountIdentifier,
            string cardProxy, PaymentInstrumentType? paymentInstrumentType, string cardStockCode, string accountNumber = null, string routingNumber = null, string productMaterialType = null, string storeId = null)
        {
            if (OptionsContext.Current.IsDefined("X-GD-Bos-Dcpp-RegisterCardFailure"))
                throw new DcppException(OptionsContext.Current.GetInt("X-GD-Bos-Dcpp-RegisterCardFailure", 0), 0, "DCPP did not return success for RegisterCard");
            
            GetTimeout("X-GD-Bos-Dcpp-RegisterCardTimeOut", out var requestTimeout);
            
            accountNumber = (accountNumber == string.Empty ? null : accountNumber);
            routingNumber = (routingNumber == string.Empty ? null : routingNumber);
            RegisterCardRequest registerCardRequest = new RegisterCardRequest()
            {
                Header = new RequestHeader() { RequestId = requestId, Source = null },
                AccountIdentifier = accountIdentifier,
                CardProxy = cardProxy,
                PaymentInstrumentType = paymentInstrumentType,
                CardStockCode = cardStockCode,
                ProgramCode = programCode,
                ProductCode = productCode,
                AccountNumber = accountNumber,
                RoutingNumber = routingNumber,
                NextProductMaterialType = productMaterialType,
                StoreId = storeId,
            };
            var response = _serviceInvokeProvider.GetResponseAsync<RegisterCardRequest, RegisterCardResponse>(
                $"{_cpmBaseUrl}{string.Format(_registerCard, programCode)}",
                "POST",
                registerCardRequest,
                null, requestTimeout).Result;
            if (response == null)
                throw new Exception($"CPM service did not return a recognizable response for Register Card.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(503), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for Register Card: Message: {response.Header.ErrorInfo.Message};");

            var cardResponse = new RegisterCardResponse()
            {
                Header = response.Header,
                AccountIdentifier = response.AccountIdentifier,
                PaymentIdentifier = response.PaymentIdentifier,
                PaymentInstrumentIdentifier = response.PaymentInstrumentIdentifier,
                Status = response.Status,
                AccountBalanceIdentifier = response.AccountBalanceIdentifier,
                AccountNumber = response.AccountNumber,
                RoutingNumber = response.RoutingNumber,
                Pan = response.Pan
            };
            return cardResponse;
        }

        public RegisterCustomerResponse RegisterCustomer(Guid requestId, string programCode, string productCode, string accountIdentifier, string userIdentifier)
        {
            RegisterCustomerRequest registerCustomerRequest = new RegisterCustomerRequest()
            {
                Header = new RequestHeader() { RequestId = requestId, Source = null },
                AccountIdentifier = accountIdentifier,
                ProgramCode = programCode,
                ProductCode = productCode,
                UserIdentifier = userIdentifier
            };
            var response = _serviceInvokeProvider.GetResponseAsync<RegisterCustomerRequest, RegisterCustomerResponse>(
                $"{_cpmBaseUrl}{string.Format(_registerCustomer, programCode)}", 
                "POST", registerCustomerRequest, null).Result;
            if (response == null)
                throw new Exception($"CPM service did not return a recognizable response for Register Customer.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(503), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for Register Customer: Message: {response.Header.ErrorInfo.Message};");
         
            return response;
        }

        public AddPlasticCardResponse AddPlasticCard(Guid requestId,
            string productCode,
            string programCode,
            string aciContactId,
            string aciDeviceStyleId,
            string embossingVendorId,
            string embooserName,
            string paymentDeviceId,
            string issueReason,
            string accountIdentifier,
            string userIdentifier)
        {
            var addPlasticRequest = new AddPlasticCardRequest()
            {
                Header = new RequestHeader() { RequestId = requestId, Source = null },
                ProductCode = productCode,
                ProgramCode = programCode,
                CardMailerContactId = aciContactId,
                DeviceStyleId = aciDeviceStyleId,
                EmbosserName1 = embooserName,
                PaymentDeviceId = paymentDeviceId,
                IssueReason = issueReason,
                OutputFileEmbossingVendorId = embossingVendorId,
                UserIdentifier = userIdentifier,
                Accounts = new List<AddPlasticAccount>()
                {
                    new AddPlasticAccount()
                    {
                        AccountIdentifier = accountIdentifier
                    }
                }
            };
            var response = _serviceInvokeProvider.GetResponseAsync<AddPlasticCardRequest, AddPlasticCardResponse>(
                 $"{_cpmBaseUrl}{string.Format(_addPlasticCard, programCode)}", 
                 "POST", addPlasticRequest, null).Result;
            if (response == null)
                throw new Exception($"CPM service did not return a recognizable response for AddPlasticCard.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(503), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for Register Customer: Message: {response.Header.ErrorInfo.Message};");

            return response;
        }

        public UpgradeAccountResponse UpgradeAccount(UpgradeAccountRequest request)
        {
            GetTimeout("X-GD-Bos-CPM-UpdateAccount", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);
            if (reqId == Guid.Empty)
                reqId = request?.Header?.RequestId ?? Guid.NewGuid();

            request.ProgramCode = string.IsNullOrEmpty(request?.ProgramCode) ? DomainContext.Current?.ProgramCode?.ToString() : request?.ProgramCode;

            var cpmRequest = new UpgradeAccountRequest()
            {
                Header = new RequestHeader() { RequestId = reqId, Source = null },
                AccountIdentifier = request.AccountIdentifier,
                ProgramCode = request.ProgramCode,
                TargetProductCode = request.TargetProductCode,
                ProductMaterialType = request.ProductMaterialType
            };

            var response = _serviceInvokeProvider.GetResponseAsync<UpgradeAccountRequest, UpgradeAccountResponse>(
                _cpmBaseUrl + string.Format(_upgradeAccountUrl, request.ProgramCode), "POST", cpmRequest, null, requestTimeout).Result;

            return response;
        }

        public RestoreAccountResponse RestoreAccount(RestoreAccountRequest request)
        {
            var response = _serviceInvokeProvider.GetResponseAsync<RestoreAccountRequest, RestoreAccountResponse>(
                _cpmBaseUrl + string.Format(_restoreAccountUrl, request.ProgramCode, request.AccountIdentifier), 
                "POST", request, null).Result;

            if (response == null)
                throw new Exception($"CPM service did not return a recognizable response for RestoreAccount.");

            if (response.Header.StatusCode != "200")
                throw new CpmException(response.Header.StatusCode.ParseInt(503), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for RestoreAccount: Message: {response.Header.ErrorInfo.Message};");

            return response;
        }

        public GetAccountBalanceResponse GetAccountBalance(string programCode, string accountIdentifier)
        {
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var requestId);
            var getAccountBalanceRequest = new CPMContract.Message.Request.GetAccountBalanceRequest
            {
                Header = new RequestHeader() { RequestId = requestId, Source = null },
                ProgramCode = programCode,
                AccountId = accountIdentifier
            };
            var response = _serviceInvokeProvider.GetResponseAsync<CPMContract.Message.Request.GetAccountBalanceRequest, CPMContract.Message.Response.GetAccountBalanceResponse>(
                $"{_cpmBaseUrl}{string.Format(_getAccountBalance, programCode)}", 
                "POST", getAccountBalanceRequest, null).Result;
            if (response == null)
                throw new Exception($"CPM service did not return a recognizable response for GetAccountBalance.");

            if (response.Header.StatusCode != "200")
                throw new CpmException(response.Header.StatusCode.ParseInt(503), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for GetAccountBalance: Message: {response.Header.ErrorInfo.Message}:{response.Header.ErrorInfo.Details};");

            GetAccountBalanceResponse serviceResponse = new GetAccountBalanceResponse
            {
                Header = new DcppContract.ResponseHeader
                {
                    StatusCode = response.Header?.StatusCode,
                    ErrorInfo = new Gd.Bos.Dcpp.Contract.Data.ErrorInfo
                    {
                        Details = response.Header?.ErrorInfo?.Details,
                        Message = response.Header?.ErrorInfo?.Message,
                        SubStatusCode = response.Header?.ErrorInfo?.SubStatusCode,
                        Source = response.Header?.ErrorInfo?.Source,
                    }
                },
                AvailableBalance = new Gd.Bos.Dcpp.Contract.Data.CurrencyAmount()
                {
                    Amount = response.AvailableBalance.Amount,
                    CurrencyCode = response.AvailableBalance.CurrencyCode
                },
                CurrentBalance = new Gd.Bos.Dcpp.Contract.Data.CurrencyAmount()
                {
                    Amount = response.CurrentBalance.Amount,
                    CurrencyCode = response.CurrentBalance.CurrencyCode
                }
            };

            return serviceResponse;
        }

        public UpdateCreditLimitHistoryResponse UpdateCreditLimitHistory(UpdateCreditLimitHistoryRequest request)
        {
            GetTimeout("X-GD-Bos-CPM-UpdateCreditLimitHistory", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);
            if (reqId == Guid.Empty)
                reqId = request?.Header?.RequestId ?? Guid.NewGuid();
            if (request!.Header == null)
            {
                request.Header = new DcppContract.RequestHeader
                {
                    RequestId = Guid.NewGuid()
                };
            }

            request.ProgramCode = string.IsNullOrEmpty(request?.ProgramCode) ? DomainContext.Current?.ProgramCode?.ToString() : request?.ProgramCode;

            var response = _serviceInvokeProvider.GetResponseAsync<UpdateCreditLimitHistoryRequest, UpdateCreditLimitHistoryResponse>(
                _cpmBaseUrl + string.Format(_updateCreditLimitHistory, request.ProgramCode, request.AccountIdentifier), 
                "POST", request, null, requestTimeout).Result;

            if (response == null)
                throw new Exception($"A downstream provider did not return a recognizable response for CPM UpdateCreditLimitHistory.");

            if (response.Header.StatusCode != "200")
                throw new CpmException(response.Header.StatusCode.ParseInt(0), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for CPM UpdateCreditLimitHistory: Message: {response.Header.ErrorInfo.Message};");

            return response;
        }
        public LinkCardResponse LinkCard(LinkCardRequest request)
        {
            GetTimeout("X-GD-Bos-CPM-LinkCard", out var requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);
            if (reqId == Guid.Empty)
                reqId = request?.Header?.RequestId ?? Guid.NewGuid();
            if (request!.Header == null)
            {
                request.Header = new RequestHeader
                {
                    RequestId = reqId
                };
            }

            request.ProgramCode = string.IsNullOrEmpty(request?.ProgramCode) ? DomainContext.Current?.ProgramCode?.ToString() : request?.ProgramCode;

            var response = _serviceInvokeProvider.GetResponseAsync<LinkCardRequest, LinkCardResponse>(
                _cpmBaseUrl + string.Format(_linkCard, request.ProgramCode), 
                "POST", request, null, requestTimeout).Result;

            if (response == null)
                throw new Exception(
                    $"A downstream CbsDcpp provider did not return a recognizable response for LinkCard.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0),
                    response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream CbsDcpp provider did not return success for LinkCard: Message: {response.Header.ErrorInfo.Message};");
            return response;
        }

        public AuthorizePaymentResponse AuthorizePayment(AuthorizePaymentRequest request)
        {
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);
            if (reqId == Guid.Empty)
                reqId = request?.Header?.RequestId ?? Guid.NewGuid();
            if (request!.Header == null)
            {
                request.Header = new DcppContract.RequestHeader
                {
                    RequestId = reqId
                };
            }

            request.ProgramCode = string.IsNullOrEmpty(request?.ProgramCode) ? DomainContext.Current?.ProgramCode?.ToString() : request?.ProgramCode;

            var response = _serviceInvokeProvider.GetResponseAsync<AuthorizePaymentRequest, AuthorizePaymentResponse>(
                _cpmBaseUrl + string.Format(_authorizePaymentUrl, request.ProgramCode), 
                "POST", request, null).Result;

            if (response == null)
                throw new Exception(
                    $"[CPM] A downstream provider did not return a recognizable response for AuthorizePayment.");
            return response;
        }

        public GetPurchaseStatusResponse GetPurchaseStatus(string programCode, string paymentInstrumentIdentifier, string retrievalReferenceNumber)
        {
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);
            var request = new GetPurchaseStatusRequest
            {
                Header = new DcppContract.RequestHeader
                {
                    RequestId = reqId
                },
                ProgramCode = programCode,
            };

            var response = _serviceInvokeProvider.GetResponseAsync<GetPurchaseStatusRequest, GetPurchaseStatusResponse>(
                _cpmBaseUrl + string.Format(_getPurchaseStatusUrl, request.ProgramCode, paymentInstrumentIdentifier, retrievalReferenceNumber), "POST", request, null).Result;

            if (response == null)
                throw new Exception(
                    $"A downstream PNT provider did not return a recognizable response for GetPurchaseStatus.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(0),
                    response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream PNT provider did not return success for GetPurchaseStatus: Message: {response.Header.ErrorInfo.Message};");
            return response;
        }
    
        #region private methods
        private ProductTierInfo GetProductTier(string programCode, string productCode, string productMaterialType,
            string cardStock, short accountProductTierClassKey, out bool getNonDefaultProductTier)
        {
            getNonDefaultProductTier = false;

            #region Get ProductMaterialType of affected payment instrument if ProductMaterialType is empty
            var existingProductMaterialType = _productService.GetProductMaterialTypeByCardStock(programCode, cardStock);

            if (string.IsNullOrEmpty(existingProductMaterialType) ||
                !existingProductMaterialType.Equals(productMaterialType, StringComparison.InvariantCultureIgnoreCase))
            {
                existingProductMaterialType = !string.IsNullOrEmpty(productMaterialType) ? productMaterialType : existingProductMaterialType;
            }

            if (!string.IsNullOrEmpty(existingProductMaterialType))
            {
                var productTier = _productService.GetProductTierByMaterialType(
                    programCode,
                    productCode,
                    4, //cbs
                    existingProductMaterialType);

                if (productTier != null)
                {
                    return productTier;
                }
            }
            #endregion

            return _productService.GetDefaultProductTierByProgramCodeProductCode(programCode, productCode);
        }
        private void GetTimeout(string headerName, out int? requestTimeout)
        {
            GetTimeout(headerName, out requestTimeout, "");
        }
        private void GetTimeout(string headerName, out int? requestTimeout, AccountIdentifier accountIdentifier)
        {
            GetTimeout(headerName, out requestTimeout, accountIdentifier?.ToString());
        }
        private void GetTimeout(string headerName, out int? requestTimeout, AccountBalanceIdentifier accountBalanceIdentifier)
        {
            GetTimeout(headerName, out requestTimeout, accountBalanceIdentifier?.ToString());
        }
        private void GetTimeout(string headerName, out int? requestTimeout, string id)
        {
            requestTimeout = null;
            if (OptionsContext.Current.IsDefined(headerName))
            {
                requestTimeout = 1;
                if (int.TryParse(OptionsContext.Current.GetString(headerName), out var rt))
                    requestTimeout = rt;
                else if (OptionsContext.Current.GetString(headerName).Equals(id, StringComparison.CurrentCultureIgnoreCase))
                    requestTimeout = 1;
                else
                    requestTimeout = null;

                // 0 throws ArgumentOutOfRangeException in web client
                if (requestTimeout == 0)
                    requestTimeout = 1;
            }
        }
        #endregion

        public BindingJointAccountResponse BindingJointAccount(Guid requestId, string programCode, string accountIdentifier, string userIdentifier)
        {
            BindingJointAccountRequest bindingJointAccountRequest = new BindingJointAccountRequest()
            {
                Header = new RequestHeader() { RequestId = requestId, Source = null },
                AccountIdentifier = accountIdentifier,
                ProgramCode = programCode,
                UserIdentifier = userIdentifier
            };            
            var response = _serviceInvokeProvider.GetResponseAsync<BindingJointAccountRequest, BindingJointAccountResponse>(
                $"{_cpmBaseUrl}{string.Format(_bindJointAccountUrl, programCode)}", 
                "POST", bindingJointAccountRequest, null).Result;
            if (response == null)
                throw new Exception($"CPM service did not return a recognizable response for binding JointAccount.");

            if (response.Header.StatusCode != "200")
                throw new DcppException(response.Header.StatusCode.ParseInt(503), response.Header.ErrorInfo.SubStatusCode.ParseInt(0),
                    $"A downstream provider did not return success for binding JointAccount: Message: {response.Header.ErrorInfo.Message};");
            return response;           
        }
    }
}
