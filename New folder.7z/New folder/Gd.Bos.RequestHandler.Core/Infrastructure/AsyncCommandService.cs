﻿using Gd.Bos.RequestHandler.Core.Domain.Services.AsyncCommandService;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration.RabbitMq;
using Newtonsoft.Json;
using NLog;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using RequestHandler.Core.Infrastructure.Configuration;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Net.Security;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Threading.Tasks;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    [ExcludeFromCodeCoverage(Justification = "Wrapper of Rabbit Mq client used on other tests")]
    public class AsyncCommandService : IAsyncCommandService
    {
        private readonly IRequestHandlerSettings _settings;

        public AsyncCommandService(
            RabbitMqConfig config,
            IAsyncCommandFactory retryCommandFactory,
            IAsyncCommandHandlerFactory retryCommandHandlerFactory,
            IRequestHandlerSettings settings)
        {
            _configuration = new RabbitMqConfig
            {
                HostName = config.HostName,
                Username = config.UseSsl ? default(string) : config.Username,
                Password = config.UseSsl ? default(string) : config.Password,
                Port = config.Port.GetValueOrDefault(),
                VirtualHost = Environment.ExpandEnvironmentVariables(config.VirtualHost ?? "/"),
                RequestQueueName = config.RequestQueueName,
                PrefetchCount = config.PrefetchCount ?? 3,
                MaxExecutingCommands = config.MaxExecutingCommands ?? 50,
                UseSsl = config.UseSsl,
                CertSubject = config.CertSubject,
                /*ExchangeDeclaration = config.ExchangeDeclaration ??
                                      new ExchangeDeclaration
                                      {
                                          ExchangeName = "request-handler",
                                          ExchangeType = "topic",
                                          Durable = false,
                                          AutoDelete = false
                                      },
                QueueDeclaration = config.QueueDeclaration ??
                                   new QueueDeclaration
                                   {
                                       QueueName = "request-handler-all",
                                       Durable = false,
                                       AutoDelete = false,
                                       Exclusive = false
                                   },
                QueueBind = config.QueueBind ??
                            new QueueBind
                            {
                                QueueName = "request-handler-all",
                                Exchange = "request-handler",
                                RoutingKey = "*"
                            }*/
            };

            _semaphore = new SemaphoreSlim(_configuration.MaxExecutingCommands.Value);

            _consumerTag = Environment.MachineName + "." + Process.GetCurrentProcess().Id + "." + Guid.NewGuid();
            _retryCommandFactory = retryCommandFactory;
            _retryCommandHandlerFactory = retryCommandHandlerFactory;
            _settings = settings;
        }

        public void Start()
        {
            CheckDisposed();

            if (_running)
                throw new InvalidOperationException("Service is already running.");

            try
            {
                Connect();
            }
            catch (Exception)
            {
                Disconnect();

                throw;
            }
        }

        public void Stop()
        {
            CheckDisposed();

            if (!_running)
                throw new InvalidOperationException("Service is not running.");

            Disconnect();
        }

        private void Connect()
        {
            ConnectionFactory factory = new ConnectionFactory();

            factory.HostName = _configuration.HostName;
            factory.UserName = _configuration.Username;
            factory.Password = _configuration.Password;
            factory.VirtualHost = _configuration.VirtualHost;
            factory.Port = _configuration.Port.GetValueOrDefault();
            factory.Ssl = _configuration.UseSsl ? new SslOption
            {
                Enabled = true,
                ServerName = factory.HostName,
                AcceptablePolicyErrors = SslPolicyErrors.RemoteCertificateNameMismatch |
                                         SslPolicyErrors.RemoteCertificateChainErrors,
                CertificateSelectionCallback = ConfigOnCertificateSelection,
                Version = SslProtocols.Tls12
            } : factory.Ssl;
            factory.AuthMechanisms = _configuration.UseSsl
               ? new AuthMechanismFactory[] { new ExternalMechanismFactory() }
                : ConnectionFactory.DefaultAuthMechanisms;

            bool hasClientProvidedName = _settings.ClientName != null;

            _connection = hasClientProvidedName
                ? factory.CreateConnection(_settings.ClientName + "_async")
                : factory.CreateConnection(Environment.MachineName + "_async");

            _connection.ConnectionRecoveryError += _connection_ConnectionRecoveryError;
            _connection.ConnectionShutdown += _connection_ConnectionShutdown;
            _connection.RecoverySucceeded += _connection_RecoverySucceeded;


            _model = _connection.CreateModel();
            _model.BasicQos(0, _configuration.PrefetchCount.Value, false);

            AsyncCommandServiceConfig retryConfig = new AsyncCommandServiceConfig();
            retryConfig.RetryIntervals = new int[] { _settings.WaitIntervalSeconds, _settings.WaitIntervalSecondsSetStatus, _settings.WaitIntervalSecondsRetryEnroll, _settings.WaitIntervalSecondsForEnrollOrderCard, _settings.WaitIntervalSecondsForEnrollSetBcd };

            retryConfig.DelayQueuePrefix = _settings.RabbitAsyncCommandDelayPrefixQueue;

            _consumerTag = "rh_async_command" + "." + Environment.MachineName + "." + Process.GetCurrentProcess().Id + "." + Guid.NewGuid();

            _model.ExchangeDeclare(_settings.RabbitAsyncCommandDelayDeadletterExchange, ExchangeType.Direct);
            _model.QueueDeclare(_settings.RabbitAsyncCommandQueue, _settings.RabbitMqQueueDurable, false, false, null);
            _model.QueueBind(_settings.RabbitAsyncCommandQueue, _settings.RabbitAsyncCommandDelayDeadletterExchange, "async_command");

            var args = new Dictionary<string, object>();
            args.Add("x-message-ttl", 1 * 60 * 60 * 1000);

            _model.QueueDeclare(_settings.RabbitAsyncCommandGraveyardQueue, _settings.RabbitMqQueueDurable, false, false, args);

            foreach (var currInterval in retryConfig.RetryIntervals.Distinct())
            {
                args = new Dictionary<string, object>();
                args.Add("x-message-ttl", currInterval * 1000);
                args.Add("x-dead-letter-exchange", _settings.RabbitAsyncCommandDelayDeadletterExchange);
                args.Add("x-dead-letter-routing-key", "async_command");

                _model.QueueDeclare(retryConfig.DelayQueuePrefix + currInterval, _settings.RabbitMqQueueDurable, false, false, args);
            }

            _consumer = new EventingBasicConsumer(_model);
            _consumer.Received += OnMessageReceived;
            _model.BasicConsume(_settings.RabbitAsyncCommandQueue, false, _consumerTag, _consumer);

            _running = true;

            _logger.Info("Connection to RabbitMQ established.");
            _logger.Info($"AsyncCommnadService.Connect " +
                         $"_settings.RabbitAsyncCommandDelayDeadletterExchange: {_settings.RabbitAsyncCommandDelayDeadletterExchange} "+
                         $"_settings.RabbitAsyncCommandQueue: {_settings.RabbitAsyncCommandQueue} "+
                         $"_settings.RabbitAsyncCommandDelayDeadletterExchange: {_settings.RabbitAsyncCommandDelayDeadletterExchange} " +
                         $"_settings.RabbitAsyncCommandGraveyardQueue: {_settings.RabbitAsyncCommandGraveyardQueue} " +
                         $"factory.HostName: {factory.HostName} " +
                         $"factory.VirtualHost: {factory.VirtualHost} ");
        }

        private void CheckConnection()
        {
            if (_model == null || _model.IsOpen == false)
            {
                lock (_locker)
                {
                    if (_model == null || _model.IsOpen == false)
                    {
                        Connect();
                    }
                }
            }
        }

        public void Send<TCommand>(TCommand retryRequest, bool graveyard = false)
            where TCommand : AsyncCommand
        {
            CheckConnection();

            var serializer = new JsonSerializer();
            byte[] responseBuffer = new byte[0];

            using (var responseStream = new MemoryStream())
            {
                var sw = new StreamWriter(responseStream);
                serializer.Serialize(sw, retryRequest);
                sw.Flush();
                responseBuffer = responseStream.ToArray();
            }

            var responseProperties = _model.CreateBasicProperties();
            responseProperties.Type = typeof(TCommand).FullName;
            responseProperties.DeliveryMode = 2;

            if (graveyard)
            {
                _logger.Info($"Sent to graveyard queue: {_settings.RabbitAsyncCommandGraveyardQueue}");

                _model.BasicPublish("", $"{_settings.RabbitAsyncCommandGraveyardQueue}", responseProperties, responseBuffer);
            }
            else
            {
                _logger.Info("Sent to delay queue: " + $"{_settings.RabbitAsyncCommandDelayPrefixQueue}{retryRequest.WaitIntervalSeconds}");

                _model.BasicPublish("", $"{_settings.RabbitAsyncCommandDelayPrefixQueue}" + retryRequest.WaitIntervalSeconds,
                    responseProperties, responseBuffer);
            }
        }

        private void SendToGraveyard(string originalType, byte[] body)
        {
            CheckConnection();

            var responseProperties = _model.CreateBasicProperties();
            responseProperties.Type = originalType;
            responseProperties.DeliveryMode = 2;

            _logger.Info($"Sending to graveyard queue: {_settings.RabbitAsyncCommandGraveyardQueue}");

            _model.BasicPublish("", $"{_settings.RabbitAsyncCommandGraveyardQueue}", responseProperties, body);
        }

        private X509Certificate2 CertFactory()
        {
            var storeLocation = ConfigurationHelper.GetStoreLocation();
            using (var store = new X509Store(StoreName.My, storeLocation))
            {
                store.Open(OpenFlags.ReadOnly);
                var certFindType = X509FindType.FindBySubjectName;
                var certFindValue = _configuration.CertSubject;
                var certificateCol = store.Certificates.Find(certFindType, certFindValue, true);
                store.Close();
                return certificateCol[0];
            }
        }

        private X509Certificate ConfigOnCertificateSelection(object sender, string targetHost, X509CertificateCollection localCertificates, X509Certificate remoteCertificate, string[] acceptableIssuers)
        {
            _lazyCert = _lazyCert ?? new Lazy<X509Certificate2>(CertFactory);
            return _lazyCert.Value;
        }

        private void Disconnect()
        {
            if (_running)
            {
                _disconnecting = true;

                try
                {
                    _model?.BasicCancel(_consumerTag);
                }
                catch (Exception e)
                {
                    _logger.Warn(e, "Exception calling BasicCancel on consumer.");
                }
                finally
                {
                    _consumer = null;
                }

                Stopwatch waitTime = Stopwatch.StartNew();

                while (_semaphore.CurrentCount < _configuration.MaxExecutingCommands && waitTime.Elapsed.Seconds < 60)
                    Thread.Sleep(100);

                waitTime.Stop();

                if (_semaphore.CurrentCount < _configuration.MaxExecutingCommands)
                    _logger.Warn("Timeout waiting for all commands to complete.  Disposing of model.");

                try
                {
                    _model?.Dispose();
                }
                catch (Exception e)
                {
                    _logger.Warn(e, "Exception disposing model.");
                }
                finally
                {
                    _model = null;
                }

                try
                {
                    _connection?.Dispose();
                }
                catch (Exception e)
                {
                    _logger.Warn(e, "Exception disposing connection.");
                }
                finally
                {
                    _connection = null;
                }

                _disconnecting = false;
                _running = false;

                _logger.Info("Disconnected from RabbitMQ.");
            }
        }

        private void _connection_ConnectionShutdown(object sender, ShutdownEventArgs e)
        {
            if (!_disconnecting)
                _logger.Warn("Connection to RabbitMQ lost.");
        }

        private void _connection_ConnectionRecoveryError(object sender, ConnectionRecoveryErrorEventArgs e)
        {
            _logger.Warn(e.Exception, "Error reconnecting to RabbitMQ.");
        }

        private void _connection_RecoverySucceeded(object sender, EventArgs e)
        {
            _logger.Info("Connection to RabbitMQ reestablished.");
        }

        private void OnMessageReceived(object source, BasicDeliverEventArgs eventArgs)
        {
            var model = ((EventingBasicConsumer)source).Model;

            try
            {
                var command = _retryCommandFactory.GetCommand(eventArgs?.BasicProperties?.Type, eventArgs.Body);

                _logger.Info($"Received async command type: {command.GetType().FullName}, RetryId: {command.RetryId};  Executing...");

                var handler = _retryCommandHandlerFactory.GetHandler(command.GetType());

                Task newTask = new Task(
                    async () =>
                    {
                        try
                        {
                            await handler.HandleAsync(command);
                        }
                        catch (Exception e)
                        {
                            _logger.Warn(e, "Exception while executing async command.");
                        }
                        finally
                        {
                            model.BasicAck(eventArgs.DeliveryTag, false);
                            _semaphore.Release();
                        }
                    });

                _semaphore.Wait();

                newTask.Start();
            }
            catch (Exception e)
            {
                _logger.Warn(e, "Exception in OnMessageReceived when interpreting message.  Sending to graveyard.");
                SendToGraveyard(eventArgs.BasicProperties?.Type, eventArgs.Body);
            }
        }

        #region IDisposable

        public void Dispose()
        {
            Dispose(true);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                Disconnect();
            }

            _disposed = true;
        }

        private void CheckDisposed()
        {
            if (_disposed)
                throw new ObjectDisposedException(GetType().Name);
        }

        private bool _disposed;

        #endregion

        private readonly RabbitMqConfig _configuration;
        private readonly IAsyncCommandFactory _retryCommandFactory;
        private readonly IAsyncCommandHandlerFactory _retryCommandHandlerFactory;
        private IConnection _connection;
        private IModel _model;
        private EventingBasicConsumer _consumer;
        private string _consumerTag;
        private readonly SemaphoreSlim _semaphore;
        private bool _running;
        private bool _disconnecting;
        private static readonly Logger _logger = LogManager.GetCurrentClassLogger();
        private Lazy<X509Certificate2> _lazyCert;
        private static readonly object _locker = new object();
    }
}
