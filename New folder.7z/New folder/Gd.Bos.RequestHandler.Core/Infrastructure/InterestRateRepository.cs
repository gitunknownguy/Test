﻿#nullable enable
using Gd.Bos.RequestHandler.Core.Domain.Model.Interest;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.Data;
using Microsoft.Data.SqlClient;
using NLog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Gd.Bos.Shared.Common.Caching;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.RequestHandler.Core.Utils;
using RequestHandler.Core.Domain.Model.Interest;
using PurseType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.PurseType;
using System.Diagnostics.CodeAnalysis;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    [ExcludeFromCodeCoverage(Justification = "Will cover with GBOS-116633")]
    public class InterestRateRepository : IInterestRateRepository
    {
        private readonly IDataAccess _dataAccess;
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();
        private readonly string _userName = IdentityHelper.GetIdentityName();
        private readonly ILazyCache _lazyCache;

        public InterestRateRepository(IDataAccess dataAccess, ILazyCache lazyCache)
        {
            _dataAccess = dataAccess;
            _lazyCache = lazyCache;
        }

        public List<ProgramInterestTier> GetProgramInterestTiers(string programCode)
        {
            try
            {
                var productInterestTierList = new List<ProgramInterestTier>();

                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetProductInterestTierByProgramCode]",
                    _dataAccess.CreateConnection(),
                    new SqlParameter
                    {
                        ParameterName = "programCode",
                        Value = programCode,
                        DbType = DbType.String
                    }))
                {
                    while (reader.Read())
                    {
                        productInterestTierList.Add(new ProgramInterestTier()
                        {
                            ProductCode = Cast<string>(reader["ProductCode"]),
                            ProductInterestTierKey = Cast<long>(reader["ProductInterestTierKey"]),
                            APY = Cast<decimal>(reader["APY"]),
                            InterestRate = Cast<decimal>(reader["InterestRate"]),
                            InterestTierKey = Cast<short>(reader["InterestTierKey"]),
                            InterestTierName = Cast<string>(reader["InterestTier"]),
                            MaxAccountInterestTypeKey = (reader["MaxAccountInterestTypeKey"] != DBNull.Value) ? Cast<short>(reader["MaxAccountInterestTypeKey"]) : (short)0,
                            FrequencyKey = Cast<short>(reader["FrequencyKey"]),
                            StartDate = (DateTime)reader["StartDate"],
                            EndDate = Cast<DateTime?>(reader["EndDate"]),
                            PurseTypeKey = Cast<short>(reader["AccountBalanceTypeKey"]),
                            CreateDate = (DateTime)reader["CreateDate"],
                            MinimumBalance = Cast<decimal?>(reader["MinimumBalance"]),
                            MaximumBalance = Cast<decimal?>(reader["MaximumBalance"]),
                            MaxInterestBalance = Cast<decimal?>(reader["MaxInterestBalance"]),
                            ProductInterestTierHistoryKey = Cast<long>(reader["ProductInterestTierHistoryKey"])
                        });
                    }
                }

                return productInterestTierList;


            }
            catch (Exception ex)
            {
                Logger.Error(
                    $"InterestRateRepository.GetProgramInterestTiers, error occurred. ProgramCode: {programCode} : {ex}");
                throw;
            }
        }

        public ProgramInterestTierV2? GetProgramInterestTiersByProgramCode(string programCode)
        {
            
            try
            {
                ProgramInterestTierV2? programInterestInfo = null;

                using var reader = _dataAccess.ExecuteReader("[dbo].[GetProgramInterestTierByProgramCode]",
                    _dataAccess.CreateConnection(),
                    new SqlParameter
                    {
                        ParameterName = "programCode",
                        Value = programCode,
                        SqlDbType = SqlDbType.NVarChar,
                    });
                
                while (reader.Read())
                {
                    programInterestInfo = new ProgramInterestTierV2
                    {
                        ProgramInterestTierKey = Cast<long>(reader["ProgramInterestTierKey"]),
                        CreateDate = (DateTime)reader["CreateDate"],
                        ChangeDate = Cast<DateTime>(reader["ChangeDate"]),
                        ChangeBy = Cast<string>(reader["ChangeBy"]),
                        APY = Cast<decimal>(reader["APY"]),
                        StartDate = Cast<DateTime>(reader["StartDate"]),
                        EndDate = Cast<DateTime>(reader["EndDate"]),
                        MinimumBalance = Cast<decimal?>(reader["MinimumBalance"]),
                        MaximumBalance = Cast<decimal?>(reader["MaximumBalance"]),
                        ProgramKey = Cast<int>(reader["ProgramKey"]),
                        InterestTierKey = Cast<short>(reader["InterestTierKey"]),
                        AccountBalanceTypeKey = Cast<short>(reader["AccountBalanceTypeKey"]),
                        FrequencyKey = Cast<short>(reader["FrequencyKey"]),
                        InterestRate = Cast<decimal>(reader["InterestRate"]),
                        MaxInterestBalance = Cast<decimal?>(reader["MaxInterestBalance"]),
                        MaxAccountInterestTypeKey = Cast<short>(reader["MaxAccountInterestTypeKey"]),
                        InterestCalculationMethodKey = Cast<short>(reader["InterestCalculationMethodKey"]),
                        InterestPayoutDateKey = Cast<short>(reader["InterestPayoutDateKey"]),
                        InterestCalculationPeriodKey = Cast<short>(reader["InterestCalculationPeriodKey"]),
                        InterestTierTypeKey = Cast<short>(reader["InterestTierTypeKey"]),
                        InterestTypeKey = Cast<short>(reader["InterestTypeKey"]),
                        InterestEffectiveCycleKey = Cast<short>(reader["InterestEffectiveCycleKey"]),
                        IsAggregate = Cast<bool>(reader["IsAggregate"]),
                        IsFixed = Cast<bool>(reader["IsFixed"]),
                        //MarginRate = Cast<double>(reader["MarginRate"]),
                        IsBackUpWitholdingEligible = Cast<bool>(reader["IsBackUpWitholdingEligible"])
                    };
                }

                return programInterestInfo;
            }
            catch (Exception ex)
            {
                Logger.Error(
                    $"InterestRateRepository.GetProductInterestTierInfoByProgramCode, error occurred. ProgramCode: {programCode} : {ex}");
                throw;
            }
        }

        public List<ProgramInterestTierHistory?> GetProgramInterestTiersHistoryByProgramCode(string programCode)
        {

            try
            {
                List<ProgramInterestTierHistory?> programInterestInfo = new List<ProgramInterestTierHistory?>();

                using var reader = _dataAccess.ExecuteReader("[dbo].[GetProgramInterestTierHistoryByProgramCode]",
                    _dataAccess.CreateConnection(),
                    new SqlParameter
                    {
                        ParameterName = "programCode",
                        Value = programCode,
                        SqlDbType = SqlDbType.NVarChar,
                    });

                while (reader.Read())
                {
                    programInterestInfo.Add( new ProgramInterestTierHistory
                    {
                        ProgramInterestTierHistoryKey = Cast<long>(reader["ProgramInterestTierHistoryKey"]),
                        CreateDate = (DateTime)reader["CreateDate"],
                        HistoryCreateDate = (DateTime)reader["HistoryCreateDate"],
                        ChangeDate = Cast<DateTime>(reader["ChangeDate"]),
                        ChangeBy = Cast<string>(reader["ChangeBy"]),
                        ProgramInterestTierKey = Cast<long>(reader["ProgramInterestTierKey"]),
                        APY = Cast<decimal>(reader["APY"]),
                        StartDate = Cast<DateTime>(reader["StartDate"]),
                        EndDate = Cast<DateTime>(reader["EndDate"]),
                        MinimumBalance = Cast<decimal?>(reader["MinimumBalance"]),
                        MaximumBalance = Cast<decimal?>(reader["MaximumBalance"]),
                        ProgramKey = Cast<int>(reader["ProgramKey"]),
                        InterestTierKey = Cast<short>(reader["InterestTierKey"]),
                        AccountBalanceTypeKey = Cast<short>(reader["AccountBalanceTypeKey"]),
                        FrequencyKey = Cast<short>(reader["FrequencyKey"]),
                        InterestRate = Cast<decimal>(reader["InterestRate"]),
                        MaxInterestBalance = Cast<decimal?>(reader["MaxInterestBalance"]),
                        MaxAccountInterestTypeKey = Cast<short>(reader["MaxAccountInterestTypeKey"]),
                        InterestCalculationMethodKey = Cast<short>(reader["InterestCalculationMethodKey"]),
                        InterestPayoutDateKey = Cast<short>(reader["InterestPayoutDateKey"]),
                        InterestCalculationPeriodKey = Cast<short>(reader["InterestCalculationPeriodKey"]),
                        InterestTierTypeKey = Cast<short>(reader["InterestTierTypeKey"]),
                        InterestTypeKey = Cast<short>(reader["InterestTypeKey"]),
                        InterestEffectiveCycleKey = Cast<short>(reader["InterestEffectiveCycleKey"]),
                        IsAggregate = Cast<bool>(reader["IsAggregate"]),
                        IsFixed = Cast<bool>(reader["IsFixed"]),
                        IsBackUpWitholdingEligible = Cast<bool>(reader["IsBackUpWitholdingEligible"])
                    });
                }

                return programInterestInfo;
            }
            catch (Exception ex)
            {
                Logger.Error(
                    $"InterestRateRepository.GetProgramInterestTiersHistoryByProgramCode, error occurred. ProgramCode: {programCode} : {ex}");
                throw;
            }
        }

        public List<ProductInterestTier> GetProductInterestTierByProductKey(int productKey)
        {
            try
            {
                string cacheKey = $"ProductInterestTier_ProductKey_{productKey}";

                List<ProductInterestTier> productInterestTiers = _lazyCache.Get(cacheKey,
                    new TimeSpan(1, 0, 0, 0),
                    () =>
                    {
                        var productInterestTierList = new List<ProductInterestTier>();

                        using (var reader = _dataAccess.ExecuteReader(
                            "[dbo].[GetProductInterestRateTierByProductKey]",
                            _dataAccess.CreateConnection(),
                            new SqlParameter
                            {
                                ParameterName = "ProductKey",
                                Value = productKey,
                                DbType = DbType.Int32
                            }))
                        {
                            while (reader.Read())
                            {
                                productInterestTierList.Add(new ProductInterestTier()
                                {
                                    ProductInterestTierKey = Cast<long>(reader["ProductInterestTierKey"]),
                                    APY = Cast<decimal>(reader["APY"]),
                                    InterestRate = Cast<decimal>(reader["InterestRate"]),
                                    InterestTierKey = Cast<short>(reader["InterestTierKey"]),
                                    AccountBalanceType = (AccountBalanceType)Cast<short>(reader["AccountBalanceTypeKey"]),
                                    StartDate = (DateTime)reader["StartDate"],
                                    EndDate = Cast<DateTime?>(reader["EndDate"]),
                                    PurseType = (PurseType)Cast<short>(reader["AccountBalanceTypeKey"]),
                                    CreateDate = (DateTime)reader["CreateDate"],
                                    MinimumBalance = Cast<decimal?>(reader["MinimumBalance"]),
                                    MaximumBalance = Cast<decimal?>(reader["MaximumBalance"]),
                                    MaxInterestBalance = Cast<decimal?>(reader["MaxInterestBalance"])
                                });
                            }
                        }

                        return productInterestTierList;
                    });

                return productInterestTiers;
            }
            catch (Exception ex)
            {
                Logger.Error(
                    $"InterestRateRepository.GProductInterestTiersByProductKey, error occurred. ProductKey: {productKey} : {ex}");
                throw;
            }
        }

        public ProductInterestTier GetProductInterestTierByProductKey(int productKey, short interestTierKey, AccountBalanceType accountBalanceType)
        {
            var productInterestTiers = new List<ProductInterestTier>();
            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetProductInterestTierByProductKey]",
                    _dataAccess.CreateConnection(), new SqlParameter
                    {
                        ParameterName = "ProductKey",
                        Value = productKey
                    }))
                {
                    while (reader.Read())
                    {
                        productInterestTiers.Add(new ProductInterestTier()
                        {
                            ProductInterestTierKey = Convert.ToInt64(reader["ProductInterestTierKey"]),
                            APY = (decimal)reader["APY"],
                            InterestTierKey = Convert.ToInt16(reader["InterestTierKey"]),
                            AccountBalanceType = reader["AccountBalanceTypeKey"] == DBNull.Value ? 0 : (AccountBalanceType)Convert.ToInt64(reader["AccountBalanceTypeKey"]),
                            StartDate = (DateTime)reader["StartDate"],
                            EndDate = reader["EndDate"] == DBNull.Value ? null : (DateTime?)reader["EndDate"]
                        });
                    }
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(
                    $"InterestRateRepository.GetProductInterestTierByProductKey, error occurred. ProductKey: {productKey} : {ex}");
                throw;
            }

            return productInterestTiers.FirstOrDefault(x => x.InterestTierKey == interestTierKey && x.AccountBalanceType == accountBalanceType);
        }

        public void InsAccountBalanceInterest(Guid accountBalanceInterestIdentifier, long accountBalanceKey, long productInterestTierKey, DateTime interestYieldStartDate)
        {
            var dataTable = new DataTable();
            dataTable.Columns.Add("AccountBalanceKey", typeof(long));
            dataTable.Columns.Add("ProductInterestTierKey", typeof(long));
            dataTable.Columns.Add("OverrideAPY", typeof(decimal));
            dataTable.Columns.Add("OverrideReason", typeof(string));
            dataTable.Columns.Add("InterestYieldStartDate", typeof(DateTime));
            dataTable.Columns.Add("InterestYieldEndDate", typeof(DateTime));
            dataTable.Columns.Add("AccountBalanceInterestIdentifier", typeof(Guid));

            var dataRow = dataTable.NewRow();
            dataRow["AccountBalanceKey"] = accountBalanceKey;
            dataRow["ProductInterestTierKey"] = productInterestTierKey;
            dataRow["OverrideAPY"] = DBNull.Value;
            dataRow["OverrideReason"] = DBNull.Value;
            dataRow["InterestYieldStartDate"] = interestYieldStartDate;
            dataRow["InterestYieldEndDate"] = DBNull.Value;
            dataRow["AccountBalanceInterestIdentifier"] = accountBalanceInterestIdentifier;
            dataTable.Rows.Add(dataRow);

            var parameters = new[]
            {
                new SqlParameter() {ParameterName = "ChangeBy", SqlDbType = SqlDbType.NVarChar, Size = 100, Value = _userName},
                new SqlParameter
                {
                    ParameterName = "AccountBalanceInterest",
                    Value = dataTable,
                    TypeName = "typeAccountBalanceInterestV2",
                    SqlDbType = SqlDbType.Structured
                }
            };

            _dataAccess.ExecuteNonQuery("[dbo].[InsAccountBalanceInterestV2]", _dataAccess.CreateConnection(), parameters);
        }

        public void UpdAccountBalanceInterest(AccountBalanceInterest accountBalanceInterest)
        {
            var parameters = new[]
            {
                new SqlParameter {ParameterName = "AccountBalanceInterestKey", Value = accountBalanceInterest.AccountBalanceInterestKey, SqlDbType = SqlDbType.BigInt},
                new SqlParameter {ParameterName = "ChangeBy", Value = _userName, SqlDbType = SqlDbType.NVarChar, Size = 100},
                new SqlParameter {ParameterName = "InterestYieldStartDate", Value = accountBalanceInterest.InterestYieldStartDate, SqlDbType = SqlDbType.Date},
                new SqlParameter {ParameterName = "InterestYieldEndDate", Value = accountBalanceInterest.InterestYieldEndDate, SqlDbType = SqlDbType.Date},
                new SqlParameter {ParameterName = "ProductInterestTierKey", Value = accountBalanceInterest.ProductInterestTierKey},
                new SqlParameter {ParameterName = "IsActive", Value = accountBalanceInterest.IsActive}
            };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdAccountBalanceInterestByPK]", _dataAccess.CreateConnection(), parameters);
        }

        public AccountInterestConfig? GetAccountInterestConfig(long accountKey)
        {
            AccountInterestConfig? result = null;
            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountInterestConfigByAccountKey]",
                           _dataAccess.CreateConnection(), new SqlParameter
                           {
                               ParameterName = "@pAccountKey",
                               Value = accountKey
                           }))
                {
                    while (reader.Read())
                    {
                        result = new AccountInterestConfig
                        {
                            AccountInterestConfigKey = Cast<long>(reader["AccountInterestConfigKey"]),
                            AccountKey = Cast<long>(reader["AccountKey"]),
                            IsBackUpWithholdingEligible = Cast<bool>(reader["IsBackUpWithholding"]),
                            NextInterestPeriodStartDate = Cast<DateTime>(reader["NextInterestPeriodStartDate"]),
                            NextInterestPeriodEndDate = Cast<DateTime?>(reader["NextInterestPeriodEndDate"]),
                            NextInterestPeriodPayoutDate = Cast<DateTime?>(reader["NextInterestPeriodPayoutDate"]),
                            LastInterestPeriodPayoutDate = Cast<DateTime?>(reader["LastInterestPeriodPayoutDate"]),
                            InterestPayoutActivationDate = Cast<DateTime>(reader["InterestPayoutActivationDate"]),
                            InterestCycleDay = Cast<short>(reader["InterestCycleDay"])
                        };
                    }
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(
                    $"InterestRateRepository.GetAccountInterestConfig, error occurred. AccountKey: {accountKey} : {ex}");
                throw;
            }

            return
                result;
        }

        public void UpdateAccountInterestConfig(AccountInterestConfig config)
        {
            var dt = new DataTable();
            dt.Columns.Add("AccountInterestConfigKey", typeof(long));
            dt.Columns.Add("NextInterestPeriodStartDate", typeof(DateTime));
            dt.Columns.Add("NextInterestPeriodEndDate", typeof(DateTime));
            dt.Columns.Add("NextInterestPeriodPayoutDate", typeof(DateTime));
            dt.Columns.Add("LastInterestPeriodPayoutDate", typeof(DateTime));

            var row = dt.NewRow();
            row["AccountInterestConfigKey"] = config.AccountInterestConfigKey;
            row["NextInterestPeriodStartDate"] = config.NextInterestPeriodStartDate;
            row["NextInterestPeriodEndDate"] =config.NextInterestPeriodEndDate.HasValue? config.NextInterestPeriodEndDate:DBNull.Value;
            row["NextInterestPeriodPayoutDate"] = config.NextInterestPeriodPayoutDate.HasValue? config.NextInterestPeriodPayoutDate:DBNull.Value;
            row["LastInterestPeriodPayoutDate"] = config.LastInterestPeriodPayoutDate.HasValue ? config.LastInterestPeriodPayoutDate : DBNull.Value;
            dt.Rows.Add(row);

            var parameters = new[]
            {
                new SqlParameter {ParameterName = "@ptypeAccountInterestConfig", Value = dt, SqlDbType = SqlDbType.Structured, TypeName = "[dbo].[typeAccountInterestConfig]"}
            };

            try
            {
                _dataAccess.ExecuteNonQuery("[dbo].[UpdateAccountInterestConfigByAccountInterestConfigKey]", _dataAccess.CreateConnection(), parameters);
            }
            catch (Exception ex)
            {
                Logger.Error(
                    $"InterestRateRepository.UpdateAccountInterestConfig, error occurred. AccountInterestConfig: {System.Text.Json.JsonSerializer.Serialize(config)} : {ex}");
                throw;
            }
        }

        public void InsertAccountInterestConfig(AccountInterestConfig config)
        {
            var parameters = new[]
            {
                new SqlParameter {ParameterName = "@pIsBackUpWithholding", Value = config.IsBackUpWithholdingEligible, SqlDbType = SqlDbType.Bit},
                new SqlParameter {ParameterName = "@pAccountKey", Value =  config.AccountKey, SqlDbType = SqlDbType.BigInt},
                new SqlParameter {ParameterName = "@pNextInterestPeriodStartDate", Value = config.NextInterestPeriodStartDate, SqlDbType = SqlDbType.Date},
                new SqlParameter {ParameterName = "@pNextInterestPeriodEndDate", Value = config.NextInterestPeriodEndDate.HasValue ? config.NextInterestPeriodEndDate.Value : DBNull.Value, SqlDbType = SqlDbType.Date},
                new SqlParameter {ParameterName = "@pNextInterestPeriodPayoutDate", Value = config.NextInterestPeriodPayoutDate.HasValue ? config.NextInterestPeriodPayoutDate.Value : DBNull.Value, SqlDbType = SqlDbType.Date},
                new SqlParameter {ParameterName = "@pLastInterestPeriodPayoutDate", Value = config.LastInterestPeriodPayoutDate.HasValue ? config.LastInterestPeriodPayoutDate.Value : DBNull.Value, SqlDbType = SqlDbType.Date},
                new SqlParameter {ParameterName = "@pInterestPayoutActivationDate", Value = config.InterestPayoutActivationDate, SqlDbType = SqlDbType.Date},
                new SqlParameter {ParameterName = "@pInterestCycleDay", Value = config.InterestCycleDay, SqlDbType = SqlDbType.SmallInt}
            };

            try
            {
                _dataAccess.ExecuteNonQuery("[dbo].[InsertAccountInterestConfig]", _dataAccess.CreateConnection(), parameters);
            }
            catch (Exception ex)
            {
                Logger.Error(
                    $"InterestRateRepository.InsertAccountInterestConfig, error occurred. AccountInterestConfig: {System.Text.Json.JsonSerializer.Serialize(config)} : {ex}");
                throw;
            }
        }

        public void AddNewInterestRateChangeRequest(InterestRateChangeRequest rateChangeRequest)
        {
            var parameters = new[]
            {
                new SqlParameter
                {
                    ParameterName = "ProgramCode", Value = rateChangeRequest.ProgramCode,
                    SqlDbType = SqlDbType.NVarChar
                },
                new SqlParameter
                {
                    ParameterName = "InterestRateName",
                    Value = rateChangeRequest.InterestRateName,
                    SqlDbType = SqlDbType.NVarChar
                },
                new SqlParameter
                {
                    ParameterName = "ProductCode",
                    Value = rateChangeRequest.ProductCode, 
                    SqlDbType = SqlDbType.NVarChar
                },
                new SqlParameter
                {
                    ParameterName = "ProcessingStatus",
                    Value = rateChangeRequest.ProcessingStatus,
                    SqlDbType = SqlDbType.NVarChar
                },
                new SqlParameter
                {
                    ParameterName = "APY",
                    Value = rateChangeRequest.AnnualPercentageYield,
                    SqlDbType = SqlDbType.Float
                },
                new SqlParameter
                {
                    ParameterName = "InterestRate",
                    Value = rateChangeRequest.InterestRate,
                    SqlDbType = SqlDbType.Float
                }
            };
            try
            {
                _dataAccess.ExecuteNonQuery("[dbo].[InsInterestRateChangeRequest]", _dataAccess.CreateConnection(),
                    parameters);
            }
            catch (Exception ex)
            {
                Logger.Error(
                    $"InterestRateRepository.AddNewInterestRateChangeRequest, error occurred. ProgramCode: {rateChangeRequest.InterestRateName} : {ex}");
                throw;
            }
        }

        public IEnumerable<AccountBalanceInterest> GetAccountBalanceInterests(string accountIdentifier)
        {
            var accountBalanceInterests = new List<AccountBalanceInterest>();
            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountBalanceInterestByAccountIdentifier]",
                    _dataAccess.CreateConnection(), new SqlParameter
                    {
                        ParameterName = "AccountIdentifier",
                        Value = accountIdentifier
                    }))
                {
                    while (reader.Read())
                    {
                        accountBalanceInterests.Add(new AccountBalanceInterest()
                        {
                            AccountBalanceInterestKey = Cast<long>(reader["AccountBalanceInterestKey"]),
                            APY = Cast<decimal>(reader["APY"]),
                            InterestRate = Cast<decimal>(reader["InterestRate"]),
                            InterestRateTierKey = Cast<short>(reader["InterestTierKey"]),
                            AccountBalanceIdentifier = reader["AccountBalanceIdentifier"].ToString(),
                            InterestYieldStartDate = Cast<DateTime>(reader["InterestYieldStartDate"]),
                            InterestYieldEndDate = Cast<DateTime?>(reader["InterestYieldEndDate"]),
                            AccountBalanceInterestIdentifier = Cast<Guid>(reader["AccountBalanceInterestIdentifier"]),
                            ProductInterestTierKey = Cast<long>(reader["ProductInterestTierKey"]),
                            IsActive = Cast(reader["IsActive"], true)
                        });
                    }
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(
                    $"InterestRateRepository.GetAccountBalanceInterests, error occurred. ProductKey: {accountIdentifier} : {ex}");
                throw;
            }

            return accountBalanceInterests;
        }

        public AccountBalanceInterest GetActiveTier(IEnumerable<AccountBalanceInterest> accountBalanceInterests)
        {

            foreach (var accountBalanceInterest in accountBalanceInterests)
            {
                if (!accountBalanceInterest.IsActive)
                    continue;
                if (accountBalanceInterest.InterestYieldEndDate == null &&
                    accountBalanceInterest.InterestYieldStartDate <= DateTime.Now.Date)
                    return accountBalanceInterest;

                DateTime endDate = accountBalanceInterest.InterestYieldEndDate ?? DateTime.Now.Date;
                if (accountBalanceInterest.InterestYieldStartDate <= DateTime.Now.Date && DateTime.Now.Date <= endDate)
                    return accountBalanceInterest;
            }

            return null;
        }

        public List<AccountBalanceInterestSnapshot> GetAccountBalanceInterestSnapshots(long accountKey, DateTime? startDate, DateTime? endDate)
        {
            var accountBalanceInterestSnapshot = new List<AccountBalanceInterestSnapshot>();

            try
            {
                SqlParameter[] parameters = {
                    new SqlParameter() {ParameterName = "AccountKey",Value = accountKey},
                    new SqlParameter() {ParameterName = "StartDate", DbType = DbType.Date, Value = startDate},
                    new SqlParameter() {ParameterName = "EndDate", DbType = DbType.Date, Value = endDate},
                };

                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountBalanceInterestSnapshotByAccountKey]",
                    _dataAccess.CreateConnection(), parameters))
                {
                    while (reader.Read())
                    {
                        accountBalanceInterestSnapshot.Add(new AccountBalanceInterestSnapshot()
                        {
                            APY = (decimal)reader["APY"],
                            InterestCreditAmount = (decimal)reader["InterestAmount"],
                            AverageDailyBalance = (decimal)reader["AverageDailyBalance"],
                            AccountBalanceInterestKey = Cast<long>(reader["AccountBalanceInterestKey"]),
                            AccountBalanceKey = Cast<long>(reader["AccountBalanceKey"]),
                            PeriodStartDate = Cast<DateTime>(reader["AverageDailyBalanceStartDate"]),
                            PeriodEndDate = Cast<DateTime>(reader["AverageDailyBalanceEndDate"]),
                            TransactionReferenceId = Cast<Guid>(reader["TransactionReferenceID"]),
                        });
                    }
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(
                    $"InterestRateRepository.GetAccountBalanceInterestSnapshots, error occurred. AccountKey: {accountKey}, StartDate:{startDate}, EndDate:{endDate}. ex: {ex}");
                throw;
            }

            return accountBalanceInterestSnapshot;
        }

        public ProductInterestTierMetaData GetProductInterestTierInfoByProgramCode(string programCode)
        {
            try
            {
                var productInterestInfo = new ProductInterestTierMetaData();
                productInterestInfo.Tiers = new List<Tier>();
                productInterestInfo.Frequencies = new List<TierFrequency>();
                productInterestInfo.PurseTypes = new List<global::RequestHandler.Core.Domain.Model.Interest.PurseType>();
                productInterestInfo.MaxAccountInterestTypes = new List<MaxAccountInterestType>();
                productInterestInfo.Products = new List<Product>();

                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetProductInterestTierInfoByProgramCode]",
                    _dataAccess.CreateConnection(),
                    new SqlParameter
                    {
                        ParameterName = "programCode",
                        Value = programCode,
                        SqlDbType = SqlDbType.NVarChar,
                    }))
                {
                    while (reader.Read())
                    {
                        productInterestInfo.Tiers.Add(new Tier
                        {
                            Key = Cast<short>(reader["InterestTierKey"]),
                            Name = Cast<string>(reader["InterestTierName"])
                        });
                    }
                    reader.NextResult();
                    while (reader.Read())
                    {
                        productInterestInfo.PurseTypes.Add(new global::RequestHandler.Core.Domain.Model.Interest.PurseType
                        {
                            Key = Cast<short>(reader["AccountBalanceTypeKey"]),
                            Name = Cast<string>(reader["AccountBalanceTypeName"])
                        });
                    }
                    reader.NextResult();
                    while (reader.Read())
                    {
                        productInterestInfo.Frequencies.Add(new TierFrequency()
                        {
                            Key = Cast<short>(reader["FrequencyKey"]),
                            Name = Cast<string>(reader["FrequencyName"])
                        });
                    }
                    reader.NextResult();
                    while (reader.Read())
                    {
                        productInterestInfo.MaxAccountInterestTypes.Add(new MaxAccountInterestType
                        {
                            Key = Cast<short>(reader["MaxAccountInterestTypeKey"]),
                            Name = Cast<string>(reader["MaxAccountInterestTypeName"])
                        });
                    }
                    reader.NextResult();
                    while (reader.Read())
                    {
                        productInterestInfo.Products.Add(new Product
                        {
                            Key = Cast<int>(reader["ProductKey"]),
                            Code = Cast<string>(reader["ProductCode"]),
                            Name = Cast<string>(reader["ProductName"])
                        });
                    }
                }

                return productInterestInfo;


            }
            catch (Exception ex)
            {
                Logger.Error(
                    $"InterestRateRepository.GetProductInterestTierInfoByProgramCode, error occurred. ProgramCode: {programCode} : {ex}");
                throw;
            }
        }

        public void AddNewInterestTierForProduct(ProgramInterestTier productInterestTier)
        {
            var parameters = new[]
            {
                new SqlParameter {ParameterName = "ProductKey", Value = productInterestTier.ProductKey, SqlDbType = SqlDbType.Int},
                new SqlParameter {ParameterName = "InterestTier", Value = productInterestTier.InterestTierName, SqlDbType = SqlDbType.NVarChar},
                new SqlParameter {ParameterName = "APY", Value = productInterestTier.APY, SqlDbType = SqlDbType.Decimal},
                new SqlParameter {ParameterName = "StartDate", Value = productInterestTier.StartDate, SqlDbType = SqlDbType.DateTime},
                new SqlParameter {ParameterName = "EndDate", Value = productInterestTier.EndDate != null?productInterestTier.EndDate:DBNull.Value, SqlDbType = SqlDbType.Date},
                new SqlParameter {ParameterName = "MinimumBalance", Value = productInterestTier.MinimumBalance, SqlDbType = SqlDbType.Money},
                new SqlParameter {ParameterName = "MaximumBalance", Value = productInterestTier.MaximumBalance, SqlDbType = SqlDbType.Money},
                new SqlParameter {ParameterName = "MaxInterestBalance", Value = productInterestTier.MaxInterestBalance, SqlDbType = SqlDbType.Money},
                new SqlParameter {ParameterName = "AccountBalanceTypeKey", Value = productInterestTier.PurseTypeKey, SqlDbType = SqlDbType.SmallInt},
                new SqlParameter {ParameterName = "FrequencyKey", Value = productInterestTier.FrequencyKey, SqlDbType = SqlDbType.SmallInt},
                new SqlParameter {ParameterName = "MaxAccountInterestTypeKey", Value = productInterestTier.MaxAccountInterestTypeKey, SqlDbType = SqlDbType.SmallInt},
                new SqlParameter {ParameterName = "InterestRate", Value = productInterestTier.InterestRate, SqlDbType = SqlDbType.Decimal},
                new SqlParameter {ParameterName = "ChangeBy", Value = _userName, SqlDbType = SqlDbType.NVarChar, Size = 100}
            };
            try
            {
                _dataAccess.ExecuteNonQuery("[dbo].[InsProductInterestTierByProductKeyInterestTier]", _dataAccess.CreateConnection(), parameters);
            }
            catch (Exception ex)
            {
                Logger.Error(
                    $"InterestRateRepository.AddNewInterestTierForProduct, error occurred. ProgramCode: {productInterestTier.InterestTierName} : {ex}");
                throw;
            }

        }

        public void AddNewProgramInterestTier(ProgramInterestTierV2 programInterestTier)
        {
            var parameters = new[]
            {
                new SqlParameter
                {
                    ParameterName = "APY", Value = programInterestTier.APY,
                    SqlDbType = SqlDbType.Decimal
                },
                new SqlParameter
                {
                    ParameterName = "StartDate",
                    Value = programInterestTier.StartDate,
                    SqlDbType = SqlDbType.DateTime
                },
                new SqlParameter
                {
                    ParameterName = "EndDate",
                    Value = programInterestTier.EndDate != null ? programInterestTier.EndDate : DBNull.Value,
                    SqlDbType = SqlDbType.Date
                },
                new SqlParameter
                {
                    ParameterName = "MinimumBalance",
                    Value = programInterestTier.MinimumBalance,
                    SqlDbType = SqlDbType.Money
                },
                new SqlParameter
                {
                    ParameterName = "MaximumBalance",
                    Value = programInterestTier.MaximumBalance,
                    SqlDbType = SqlDbType.Money
                },
                new SqlParameter
                {
                    ParameterName = "MaxInterestBalance",
                    Value = programInterestTier.MaxInterestBalance,
                    SqlDbType = SqlDbType.Money
                },
                new SqlParameter
                {
                    ParameterName = "ProgramCode",
                    Value = programInterestTier.ProgramCode,
                    SqlDbType = SqlDbType.NVarChar,
                    Size = 100
                },
                new SqlParameter
                {
                    ParameterName = "InterestTier",
                    Value = programInterestTier.InterestTierName,
                    SqlDbType = SqlDbType.NVarChar,
                    Size = 100
                },
                new SqlParameter
                {
                    ParameterName = "AccountBalanceTypeKey",
                    Value = programInterestTier.PurseTypeKey,
                    SqlDbType = SqlDbType.SmallInt
                },
                new SqlParameter
                {
                    ParameterName = "FrequencyKey",
                    Value = programInterestTier.FrequencyKey,
                    SqlDbType = SqlDbType.SmallInt
                },
                new SqlParameter
                {
                    ParameterName = "InterestRate",
                    Value = programInterestTier.InterestRate,
                    SqlDbType = SqlDbType.Decimal
                },
                new SqlParameter
                {
                    ParameterName = "MaxAccountInterestTypeKey",
                    Value = programInterestTier.MaxAccountInterestTypeKey,
                    SqlDbType = SqlDbType.SmallInt
                },
                new SqlParameter
                {
                    ParameterName = "InterestCalculationMethodKey",
                    Value = programInterestTier.InterestCalculationMethodKey,
                    SqlDbType = SqlDbType.SmallInt
                },
                new SqlParameter
                {
                    ParameterName = "InterestPayoutDateKey",
                    Value = programInterestTier.InterestPayoutDateKey,
                    SqlDbType = SqlDbType.SmallInt
                },
                new SqlParameter
                {
                    ParameterName = "InterestCalculationPeriodKey",
                    Value = programInterestTier.InterestCalculationPeriodKey,
                    SqlDbType = SqlDbType.SmallInt
                },
                new SqlParameter
                {
                    ParameterName = "InterestTierTypeKey",
                    Value = programInterestTier.InterestTierTypeKey,
                    SqlDbType = SqlDbType.SmallInt
                },
                new SqlParameter
                {
                    ParameterName = "InterestTypeKey",
                    Value = programInterestTier.InterestTypeKey,
                    SqlDbType = SqlDbType.SmallInt
                },
                new SqlParameter
                {
                    ParameterName = "InterestEffectiveCycleKey",
                    Value = programInterestTier.InterestEffectiveCycleKey,
                    SqlDbType = SqlDbType.SmallInt
                },
                new SqlParameter
                {
                    ParameterName = "IsAggregate",
                    Value = programInterestTier.IsAggregate,
                    SqlDbType = SqlDbType.Bit
                },
                new SqlParameter
                {
                    ParameterName = "IsFixed",
                    Value = programInterestTier.IsFixed,
                    SqlDbType = SqlDbType.Bit
                },
                new SqlParameter
                {
                    ParameterName = "MarginRate",
                    Value = programInterestTier.MarginRate,
                    SqlDbType = SqlDbType.Decimal
                },
                new SqlParameter
                {
                    ParameterName = "IsBackUpWitholdingEligible",
                    Value = programInterestTier.IsBackUpWitholdingEligible,
                    SqlDbType = SqlDbType.Bit
                },
                new SqlParameter
                {
                    ParameterName = "ChangeBy",
                    Value = _userName,
                    SqlDbType = SqlDbType.NVarChar,
                    Size = 100
                }
            };
            try
            {
                _dataAccess.ExecuteNonQuery("[dbo].[InsProgramInterestTier]", _dataAccess.CreateConnection(),
                    parameters);
            }
            catch (Exception ex)
            {
                Logger.Error(
                    $"InterestRateRepository.AddNewProgramInterestTier, error occurred. ProgramCode: {programInterestTier.InterestTierName} : {ex}");
                throw;
            }
        }

        public void UpdateProgramInterestTier(ProgramInterestTierV2 programInterestTier)
        {
            var parameters = new[]
            {
                new SqlParameter
                {
                    ParameterName = "ProgramInterestTierKey", Value = programInterestTier.ProgramInterestTierKey,
                    SqlDbType = SqlDbType.BigInt
                },
                 new SqlParameter
                {
                    ParameterName = "APY", Value = programInterestTier.APY,
                    SqlDbType = SqlDbType.Decimal
                },
                new SqlParameter
                {
                    ParameterName = "StartDate",
                    Value = programInterestTier.StartDate,
                    SqlDbType = SqlDbType.DateTime
                },
                 new SqlParameter
                 {
                     ParameterName = "EndDate",
                     Value = programInterestTier.EndDate != null ? programInterestTier.EndDate : DBNull.Value,
                     SqlDbType = SqlDbType.Date
                 },
                new SqlParameter
                {
                    ParameterName = "ProgramCode",
                    Value = programInterestTier.ProgramCode,
                    SqlDbType = SqlDbType.NVarChar,
                    Size = 100
                },
                new SqlParameter
                {
                    ParameterName = "InterestRate",
                    Value = programInterestTier.InterestRate,
                    SqlDbType = SqlDbType.Decimal,
                    Size = 100
                },
                new SqlParameter
                {
                    ParameterName = "ChangeBy",
                    Value = _userName,
                    SqlDbType = SqlDbType.NVarChar,
                    Size = 100
                },
                new SqlParameter
                {
                    ParameterName = "MinimumBalance",
                    Value = programInterestTier.MinimumBalance,
                    SqlDbType = SqlDbType.Money,
                },
                new SqlParameter
                {
                    ParameterName = "MaximumBalance",
                    Value = programInterestTier.MaximumBalance,
                    SqlDbType = SqlDbType.Money,
                },
                new SqlParameter
                {
                    ParameterName = "MaxInterestBalance",
                    Value = programInterestTier.MaxInterestBalance,
                    SqlDbType = SqlDbType.Money,
                },
                new SqlParameter
                {
                    ParameterName = "AccountBalanceTypeKey",
                    Value = programInterestTier.AccountBalanceTypeKey,
                    SqlDbType = SqlDbType.SmallInt,
                },
                new SqlParameter
                {
                    ParameterName = "FrequencyKey",
                    Value = programInterestTier.FrequencyKey,
                    SqlDbType = SqlDbType.SmallInt,
                },
                new SqlParameter
                {
                    ParameterName = "InterestTier",
                    Value = programInterestTier.InterestTierName,
                    SqlDbType = SqlDbType.NVarChar,
                },
                new SqlParameter
                {
                    ParameterName = "MaxAccountInterestTypeKey",
                    Value = programInterestTier.MaxAccountInterestTypeKey,
                    SqlDbType = SqlDbType.SmallInt,
                }
            };
            try
            {
                _dataAccess.ExecuteNonQuery("[dbo].[UpdProgramInterestTier]", _dataAccess.CreateConnection(),
                    parameters);
            }
            catch (Exception ex)
            {
                Logger.Error(
                    $"InterestRateRepository.AddNewProgramInterestTier, error occurred. ProgramCode: {programInterestTier.InterestTierName} : {ex}");
                throw;
            }
        }


        public void UpdateProductInterestTier(ProgramInterestTier productInterestTier)
        {
            var parameters = new[]
            {
                new SqlParameter {ParameterName = "ProductKey", Value = productInterestTier.ProductKey, SqlDbType = SqlDbType.Int},
                new SqlParameter {ParameterName = "InterestTier", Value = productInterestTier.InterestTierName, SqlDbType = SqlDbType.NVarChar},
                new SqlParameter {ParameterName = "APY", Value = productInterestTier.APY, SqlDbType = SqlDbType.Decimal},
                new SqlParameter {ParameterName = "StartDate", Value = productInterestTier.StartDate, SqlDbType = SqlDbType.DateTime},
                new SqlParameter {ParameterName = "EndDate", Value = productInterestTier.EndDate, SqlDbType = SqlDbType.Date},
                new SqlParameter {ParameterName = "MinimumBalance", Value = productInterestTier.MinimumBalance, SqlDbType = SqlDbType.Money},
                new SqlParameter {ParameterName = "MaximumBalance", Value = productInterestTier.MaximumBalance, SqlDbType = SqlDbType.Money},
                new SqlParameter {ParameterName = "MaxInterestBalance", Value = productInterestTier.MaxInterestBalance, SqlDbType = SqlDbType.Money},
                new SqlParameter {ParameterName = "AccountBalanceTypeKey", Value = productInterestTier.PurseTypeKey, SqlDbType = SqlDbType.SmallInt},
                new SqlParameter {ParameterName = "FrequencyKey", Value = productInterestTier.FrequencyKey, SqlDbType = SqlDbType.SmallInt},
                new SqlParameter {ParameterName = "MaxAccountInterestTypeKey", Value = productInterestTier.MaxAccountInterestTypeKey, SqlDbType = SqlDbType.SmallInt},
                new SqlParameter {ParameterName = "InterestRate", Value = productInterestTier.InterestRate, SqlDbType = SqlDbType.Decimal},
                new SqlParameter {ParameterName = "ChangeBy", Value = _userName, SqlDbType = SqlDbType.NVarChar, Size = 100}
            };

            try
            {
                _dataAccess.ExecuteNonQuery("[dbo].[UpdateProductInterestTierByProductKeyInterestTier]", _dataAccess.CreateConnection(), parameters);
            }
            catch (Exception ex)
            {
                Logger.Error(
                    $"InterestRateRepository.UpdateProductInterestTier, error occurred. ProgramCode: {productInterestTier.InterestTierName} : {ex}");
                throw;
            }
        }

        /// <summary>
        /// Cast can provide better performance than ConvertTo if you are sure about the data type.
        /// </summary>
        /// <typeparam name="T">Type to cast to</typeparam>
        /// <param name="value">Value to cast</param>
        /// <param name="defaultValue"></param>
        /// <returns></returns>
        private static T Cast<T>(object value, T defaultValue = default(T))
        {
            if (value == DBNull.Value || value == null)
                return defaultValue;

            return (T)value;
        }
    }
}
