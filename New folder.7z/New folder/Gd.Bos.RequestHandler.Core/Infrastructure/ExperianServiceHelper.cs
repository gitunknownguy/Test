﻿using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Services.FinancialDataApi.Enums;
using Gd.Bos.RequestHandler.Core.Domain.Services.FinancialDataApi.Requests;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Newtonsoft.Json;
using NLog;
using RequestHandler.Core.Domain.Services.Experian;
using RequestHandler.Core.Domain.Services.Experian.Contracts;
using System;
using System.Linq;
using Address = RequestHandler.Core.Domain.Services.Experian.Contracts.Address;
using RequestHandler.Core.Domain.Services.Experian.Enum;
using StatusCode = Gd.Bos.RequestHandler.Core.Domain.Services.FinancialDataApi.Enums.StatusCode;

namespace RequestHandler.Core.Infrastructure
{
    public class ExperianServiceHelper : IExperianServiceHelper
    {
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();
        private readonly IExperianService _experianService;
        private readonly ITokenizerService _tokenizerService;
        private readonly IFinancialDataService _financialDataService;
        private readonly IAccountRepository _accountRepository;
        private readonly IUserRepository _userRepository;

        public ExperianServiceHelper(IExperianService experianService, ITokenizerService tokenizerService, IFinancialDataService financialDataService,
                                        IAccountRepository accountRepository, IUserRepository userRepository)
        {
            _experianService = experianService;
            _tokenizerService = tokenizerService;
            _financialDataService = financialDataService;
            _accountRepository = accountRepository;
            _userRepository = userRepository;
        }

        public CreateCustomerHelperResponse CreateCustomer(CreateCustomerHelperRequest request)
        {
            var response = new CreateCustomerHelperResponse();

            Account account = _accountRepository.GetAccountInfoByAccountIdentifier(AccountIdentifier.FromString(request.AccountIdentifier));
            if (account == null)
            {
                // account doesnt exists
                response.StatusCode = 10;
                response.Message = "Account Not Found.";
                return response;
            }

            var users = _userRepository.GetUser(account?.AccountIdentifier, account?.AccountHolders?.FirstOrDefault()?.UserIdentifier);
            if (users == null || !users.Any())
            {
                response.StatusCode = 20;
                response.Message = "Consumer profile Not Found.";
                return response;
            }

            var user = users?.FirstOrDefault(x => x.IsPrimaryAccountHolder) ?? users?.FirstOrDefault();

            string brandId = request.ProgramCode.Equals(Gd.Bos.RequestHandler.Core.Infrastructure.Configuration.Configuration.Current.GBRProgramCode, StringComparison.OrdinalIgnoreCase)
                                ? Gd.Bos.RequestHandler.Core.Infrastructure.Configuration.Configuration.Current.Go2BankProgramCode
                                : request.ProgramCode;


            if (request.Source == CreateCustomerSource.RedirectUrl)
            {
                CreateExperianUser(request.RequestId, brandId, request.ProgramCode, account, user, out var partnerCustomerId);
                response.NewPartnerCustomerId = partnerCustomerId;
                return response;
            }

            var experianCustomer = _financialDataService.GetCustomer(request.RequestId.ToString(), brandId, user?.Identities.First().IdentityToken);
            if (request.OptIn && experianCustomer.ResponseDetails.Any(d => d.Code == StatusCode.CustomerNotFound))
            {
                // create experian user
                CreateExperianUser(request.RequestId, brandId, request.ProgramCode, account, user, out var partnerCustomerId);
                response.NewPartnerCustomerId = partnerCustomerId;
            }
            else
            {
                //Account update record required to add/update in both OptIn and OptOut scenario
                _financialDataService.AddUpdateOptIn(new UpdateOptInRequest()
                {
                    Header = new Gd.Bos.RequestHandler.Core.Domain.Services.FinancialDataApi.Entities.RequestHeader()
                    {
                        RequestId = request.RequestId.ToString()
                    },
                    BrandId = brandId,
                    BrandAccountId = account?.AccountIdentifier.ToString(),
                    BrandSsnToken = user?.Identities.First().IdentityToken,
                    OptIn = request.OptIn
                });

                //Customer record only be required to add/updated when OptIn request come
                if (request.OptIn)
                {
                    _financialDataService.AddUpdatePartnerCustomerId(new UpdatePartnerCustomerIdRequest()
                    {
                        Header = new Gd.Bos.RequestHandler.Core.Domain.Services.FinancialDataApi.Entities.RequestHeader()
                        {
                            RequestId = request.RequestId.ToString()
                        },
                        BrandId = brandId,
                        BrandAccountId = account?.AccountIdentifier.ToString(),
                        PartnerCustomerId = experianCustomer.PartnerCustomerId,
                        ExperianResponseCode = ExperianResponseCode.e005,
                        IsNewExperian = experianCustomer.IsNewExperian
                    });
                }
                response.NewPartnerCustomerId = experianCustomer.PartnerCustomerId;
            }

            return response;
        }

        private void CreateExperianUser(Guid requestId, string brandId, string programCode, Account account, UserProfile user, out string partnerCustomerId)
        {
            try
            {
                partnerCustomerId = "";
                // get ssn
                var ssnToken = user.Identities.First().IdentityToken;
                var newCustomerPartnerId = Guid.NewGuid().ToString();

                string ssn = _tokenizerService.DeTokenizeSsn(ssnToken, programCode);

                var token = _experianService.GetClientToken();

                #region Experian Offer Eligibility Check

                var offerEligibleCheckRequest = new OfferEligibleCheckRequest()
                {
                    CustomerDetails = new CustomerDetails()
                    {
                        Ssn = ssn
                    }
                };

                var offerEligibleCheckResponse = _experianService.GetOfferCheck(token, offerEligibleCheckRequest);

                #endregion

                // generate the customer partner id

                var dateOfBirth = DateTime.Parse(user.DateOfBirth);

                var address = user.Addresses.FirstOrDefault(x => x.IsDefault) ?? user.Addresses.FirstOrDefault();

                if (address == null)
                    Logger.Error($"Address is null");

                var phoneNumber = user.PhoneNumbers.FirstOrDefault(x => x.IsDefault)?.Number ?? user.PhoneNumbers.FirstOrDefault().Number;

                if (phoneNumber == null)
                    Logger.Error($"Phone Number is null");

                if (user.Email == null || string.IsNullOrEmpty(user.Email.EmailAddress))
                    Logger.Error($"Email is null");

                var createCustomerRequest = new CreateCustomerRequest()
                {
                    PartnerCustomerId = newCustomerPartnerId,
                    CustomerDetails = new CustomerDetails
                    {
                        FirstName = account.FirstName,
                        LastName = account.LastName,
                        EMail = user.Email.EmailAddress,
                        Ssn = ssn,
                        DateOfBirth = new DateOfBirth(dateOfBirth),
                        PhoneNumber = phoneNumber,
                        Address = new Address
                        {
                            StreetName = address.AddressLine1,
                            ZipCode = address.ZipCode,
                            City = address.City,
                            State = address.State
                        }
                    }
                };

                var createCustomerResponse = _experianService.CreateCustomer(token, createCustomerRequest);

                Enum.TryParse(createCustomerResponse.Status, out ExperianResponseCode responseCode);

                if (responseCode == ExperianResponseCode.success || responseCode == ExperianResponseCode.e005)
                {
                    partnerCustomerId = responseCode == ExperianResponseCode.success
                                            ? newCustomerPartnerId
                                            : createCustomerResponse.OriginalPartnerCustomerId;

                    _financialDataService.AddUpdateOptIn(new UpdateOptInRequest()
                    {
                        Header = new Gd.Bos.RequestHandler.Core.Domain.Services.FinancialDataApi.Entities.RequestHeader()
                        {
                            RequestId = requestId.ToString()
                        },
                        BrandId = brandId,
                        BrandAccountId = account.AccountIdentifier.ToString(),
                        BrandSsnToken = ssnToken,
                        OptIn = true,
                    });

                    _financialDataService.AddUpdatePartnerCustomerId(new UpdatePartnerCustomerIdRequest()
                    {
                        Header = new Gd.Bos.RequestHandler.Core.Domain.Services.FinancialDataApi.Entities.RequestHeader()
                        {
                            RequestId = requestId.ToString()
                        },
                        BrandId = brandId,
                        BrandAccountId = account.AccountIdentifier.ToString(),
                        PartnerCustomerId = partnerCustomerId,
                        ExperianResponseCode = responseCode,
                        IsNewExperian = offerEligibleCheckResponse.OfferEligible
                    });
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex, $"User Object: {JsonConvert.SerializeObject(user)}, CreateExperianUser failed.");

                throw;
            }
        }
    }
}
