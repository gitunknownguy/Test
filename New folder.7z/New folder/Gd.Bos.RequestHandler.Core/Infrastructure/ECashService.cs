﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.RequestHandler.Core.Domain;
using Gd.Bos.RequestHandler.Core.Domain.Services.ECash;
using NLog;
using GetECashPartnersRequest = Gd.Bos.RequestHandler.Core.Domain.Services.ECash.GetECashPartnersRequest;
using GetECashPartnersResponse = Gd.Bos.RequestHandler.Core.Domain.Services.ECash.GetECashPartnersResponse;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class ECashService : IECashService
    {
        private readonly IServiceInvokeProvider _serviceInvokerProvider;
        private readonly string _eCashUrl;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        private readonly IRequestHandlerSettings _configuration;

        public ECashService(IServiceInvokeProvider serviceInvokeProvider, IRequestHandlerSettings settings)
        {
            _serviceInvokerProvider = serviceInvokeProvider;
            _configuration = settings;
            _eCashUrl = _configuration.ECashBaseUrl;
        }



        public GetECashPartnersResponse GetECashPartners(GetECashPartnersRequest request)
        {
            var getECashPartnersResponse =
                _serviceInvokerProvider.GetWebResponse<GetECashPartnersResponse>(
                    GenerateGetRetailersUrl(request.ProgramCode, request.AccountIdentifier),
                    "GET", null);



            return getECashPartnersResponse;
        }

        /// <summary>
        /// Get eCash Partners by location
        /// </summary>
        /// <param name="request">The request</param>
        /// <returns></returns>
        public GetECashPartnersByLocationResponse GetECashPartnersByLocation(GetECashPartnersByLocationRequest request)
        {
            var getECashPartnersResponse =
                _serviceInvokerProvider.GetWebResponse<GetECashPartnersByLocationResponse>(
                    GenerateGetECashPartnersByLocationUrl(request),
                    "GET", null);



            return getECashPartnersResponse;
        }

        public GenerateBarcodeResponse GenerateBarcode(GenerateBarcodeRequest request)
        {
            GenerateBarcodeResponse generateBarcodeResponse;

            try
            {
                GetTimeout("X-GD-Bos-Ecash-GssCallTimeout", out var requestTimeout);

                generateBarcodeResponse =
                    _serviceInvokerProvider.GetWebResponse<GenerateBarcodeRequest, GenerateBarcodeResponse>(
                        GenerateBarcodeUrl(request.ProgramCode, request.AccountIdentifier),
                        "POST", request, requestTimeout);
            }
            catch (WebException)
            {
                _logger.Error($"GenerateBarcode timed out for GSS call for AccountId: {request.AccountIdentifier}");
                generateBarcodeResponse = new GenerateBarcodeResponse
                {
                    ResponseDetails = new List<ResponseDetail>
                    {
                        new ResponseDetail
                        {
                            Code = ECashStatusCode.OperationFailed, // "950",
                            Description = "ECash Service timed out",
                            SubCode = ECashSubStatusCode.Timeout // "600"
                        }
                    }
                };

            }
            catch (TimeoutException)
            {
                _logger.Error($"GenerateBarcode timed out for GSS call for AccountId: {request.AccountIdentifier}");
                generateBarcodeResponse = new GenerateBarcodeResponse
                {
                    ResponseDetails = new List<ResponseDetail>
                    {
                        new ResponseDetail
                        {
                            Code = ECashStatusCode.OperationFailed, // "950",
                            Description = "ECash Service timed out",
                            SubCode = ECashSubStatusCode.Timeout, // "600"
                        }
                    }
                };
            }
            return generateBarcodeResponse;
        }

        public GetBarcodeDetailsResponse GetBarcodeDetails(GetBarcodeDetailsRequest request)
        {
            var getBarcodeDetailsResponse =
                _serviceInvokerProvider.GetWebResponse<GetBarcodeDetailsResponse>(
                    GetBarcodeDetailsUrl(request.ProgramCode, request.AccountIdentifier, request.BarcodeHumanReadable),
                    "GET", null);



            return getBarcodeDetailsResponse;
        }

        public GetBarcodeListResponse GetECashBarcodes(GetBarcodeListRequest request)
        {
            var getECashBarcodesResponse =
                _serviceInvokerProvider.GetWebResponse<GetBarcodeListResponse>(
                    GetECashBarcodesUrl(request.ProgramCode, request.AccountIdentifier),
                    "GET", null);



            return getECashBarcodesResponse;
        }

        private string GenerateGetRetailersUrl(string programCode, string accountIdentifier)
        {
            return _eCashUrl + $"/programs/{programCode}/accounts/{accountIdentifier}/ecashpartners";
        }

        private string GenerateGetECashPartnersByLocationUrl(GetECashPartnersByLocationRequest request)
        {
            return _eCashUrl + $"/programs/{request.ProgramCode}/accounts/{request.AccountIdentifier}/eCashPartnersByLocation?latitude={request.Latitude}&longitude={request.Longitude}&zip={request.Zip}&city={request.City}&state={request.State}&radius={request.Radius}";
        }

        private string GenerateBarcodeUrl(string programCode, string accountIdentifier)
        {
            return _eCashUrl + $"/programs/{programCode}/accounts/{accountIdentifier}/barcodes";
        }

        private string GetBarcodeDetailsUrl(string programCode, string accountIdentifier, string barcodeHumanReadable)
        {
            return _eCashUrl + $"/programs/{programCode}/accounts/{accountIdentifier}/barcodes/{barcodeHumanReadable}";
        }

        private string GetECashBarcodesUrl(string programCode, string accountIdentifier)
        {
            return _eCashUrl + $"/programs/{programCode}/accounts/{accountIdentifier}/barcodes/list";
        }


        private void GetTimeout(string headerName, out int? requestTimeout)
        {
            requestTimeout = null;
            if (OptionsContext.Current.IsDefined(headerName))
            {
                requestTimeout = 1;
                if (int.TryParse(OptionsContext.Current.GetString(headerName), out var rt))
                    requestTimeout = rt;
            }
        }
    }
}
