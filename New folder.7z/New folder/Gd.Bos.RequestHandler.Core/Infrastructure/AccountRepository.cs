﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Transactions;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Enums;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Core.Utils;
using Gd.Bos.Shared.Common;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Core.Common.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.Shared.Common.Core.Logic;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using NLog;
using RequestHandler.Core.Application.Exception;
using RequestHandler.Core.Domain.Model.Account;
using RequestHandler.Core.Domain.Model.CollectionAccount;
using RequestHandler.Core.Domain.Model.Product;
using RequestHandler.Core.Domain.Model.Showcase;
using RequestHandler.Core.Domain.Model.Upgrade;
using RequestHandler.Core.Infrastructure.Configuration;
using RequestHandler.Core.Infrastructure.Enrollment;
using Account = Gd.Bos.RequestHandler.Core.Domain.Model.Account.Account;
using AccountHolder = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolder;
using AccountHolderCure = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountHolderCure;
using AccountStatus = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountStatus;
using AccountStatusReason = Gd.Bos.RequestHandler.Core.Domain.Model.Account.AccountStatusReason;
using Address = Gd.Bos.RequestHandler.Core.Domain.Model.User.Address;
using BinType = Gd.Bos.RequestHandler.Core.Domain.Enums.BinType;
using Email = Gd.Bos.RequestHandler.Core.Domain.Model.User.Email;
using FeeType = Gd.Bos.Shared.Common.Logic.FeatureLimitsFees.Contract.Enum.FeeType;
using GetEnrollmentResponse = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.GetEnrollmentResponse;
using IsolationLevel = System.Transactions.IsolationLevel;
using KycStateData = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.KycStateData;
using PaymentIdentifierInfo = Gd.Bos.RequestHandler.Core.Domain.Model.Payment.PaymentIdentifierInfo;
using PaymentInstrument = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PaymentInstrument;
using PaymentInstrumentInfo = Gd.Bos.RequestHandler.Core.Domain.Model.Payment.PaymentInstrumentInfo;
using PaymentInstrumentType = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.PaymentInstrumentType;
using PhoneNumber = Gd.Bos.RequestHandler.Core.Domain.Model.User.PhoneNumber;
using ProgramCode = Gd.Bos.RequestHandler.Core.Domain.Model.ProgramCode;
using User = Gd.Bos.RequestHandler.Core.Domain.Model.User.User;
using UserProfile = Gd.Bos.RequestHandler.Core.Domain.Model.User.UserProfile;
using VerificationActivityType = Gd.Bos.RequestHandler.Core.Domain.Model.Account.VerificationActivityType;
using VerificationStatus = Gd.Bos.RequestHandler.Core.Domain.Model.Account.VerificationStatus;
using VerificationStatusReason = Gd.Bos.RequestHandler.Core.Domain.Model.Account.VerificationStatusReason;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    [ExcludeFromCodeCoverage(Justification = "DB Connections and SQL commands are not unit testable")]
    public partial class AccountRepository : IAccountRepository
    {
        private readonly IBaasConfiguration _baasConfiguration;
        private readonly string _userName = IdentityHelper.GetIdentityName();
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();
        private readonly ILazyCache _lazyCache;
        private readonly IProgramRepository _programRepository;
        private readonly IRequestHandlerSettings _requestHandlerSettings;
        private readonly ITokenizerService _tokenizerService;

        private readonly IMemoryCache _cache;
        private readonly AccountRepositorySettings _settings;
        private const string GetIndividualAccountHolderSP = 
            "[dbo].[GetIndividualAccountHolderByAccountIdentifier]";

        public AccountRepository(
            IDataAccess dataAccess, 
            IBaasConfiguration baasConfiguration, 
            ILazyCache lazyCache, 
            IProgramRepository programRepository, 
            IRequestHandlerSettings requestHandlerSettings, 
            ITokenizerService tokenizerService,
            IOptions<AccountRepositorySettings> settings,
            IMemoryCache cache)
        {
            _dataAccess = dataAccess;
            _baasConfiguration = baasConfiguration;
            _lazyCache = lazyCache;
            _programRepository = programRepository;
            _requestHandlerSettings = requestHandlerSettings;
            _tokenizerService = tokenizerService;
            _settings = settings.Value;
            _cache = cache;
        }

        public AccountIdentifier NextAccountIdentifier()
        {
            return AccountIdentifier.FromGuid(Guid.NewGuid());
        }

        public int GetProcessorKeyByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            var processorKey = 0;
            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetProcessorByAccountIdentifier]",
                    _dataAccess.CreateConnection(), new SqlParameter
                    {
                        ParameterName = "AccountIdentifier",
                        Value = accountIdentifier.ToGuid()
                    }))
                {
                    if (reader.Read())
                    {
                        processorKey = reader["ProcessorKey"] != DBNull.Value ? reader.GetInt16(reader.GetOrdinal("ProcessorKey")) : 0;
                    }
                    return processorKey;
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(
                    $"AccountRepository.GetProcessorKeyByAccountIdentifier, error occurred when retrieving account identifier {accountIdentifier} : {ex}");
                throw;
            }
        }

        public AccountBalanceIdentifier NextAccountBalanceIdentifier()
        {
            return AccountBalanceIdentifier.FromString(Guid.NewGuid().ToString());
        }

        public Account GetKeysByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            var accountKeys = GetAdditionalHolderAccountByAccountIdentifier(accountIdentifier);
            if (accountKeys == null)
            {
                Logger.Debug(
                    $"AccountRepository.GetKeysByAccountIdentifier, error occurred when retrieving account identifier keys {accountIdentifier}");
                throw new AccountNotFoundException();
            }

            return accountKeys;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns>productKey, produdctName, productCode, programCode, achPrefix, abaRoutingNumber, binProductKey</returns>
        private List<AccountKeyInfo> GetAccountKeyInfo(string accountIdentifier)
        {
            var returnValue = new List<AccountKeyInfo>();
            using (var reader = _dataAccess.ExecuteReader("GetAccountPKs", _dataAccess.CreateConnection(), null))
            {
                while (reader.Read())
                {
                    AccountKeyInfo info = new AccountKeyInfo();

                    info.AccountKey = reader.GetInt64(0);
                    info.AccountIdentifier = reader.GetGuid(1);
                    info.AccountHolderKey = reader.GetInt64(2);
                    info.AccountHolderIdentifier = reader.GetGuid(3);
                    info.IsPrimaryAccountHolder = false;
                    info.ConsumerProfileKey = reader.GetInt64(6);
                    info.UserIdentifier = UserIdentifier.FromGuid(reader.GetGuid(7));
                    info.ProductKey = reader.GetInt32(9);
                    info.ProductCode = reader.GetString(10);
                    info.ProgramKey = reader.GetInt32(11);
                    info.PaymentIdentifierKey = reader.GetInt32(12);
                    info.PaymentIdentifier = reader.IsDBNull(13) ? null : reader.GetString(13);
                    info.PaymentIntrumentKey = reader.IsDBNull(16) ? 0 : reader.GetInt32(16);
                    info.PaymentInstrumentIdentifier = reader.IsDBNull(17) ? null : reader.GetString(17);

                    returnValue.Add(info);
                }
            }

            return returnValue;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="accountIdentifiers"></param>
        /// <returns></returns>
        public List<AccountCardStatus> GetAccountCardStatus(List<Guid> accountIdentifiers)
        {
            List<AccountCardStatus> accounts = new List<AccountCardStatus>();

            var cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "[dbo].[GetAccountInfoByAccountIdentifiers]";

            var dt = new DataTable();
            dt.Columns.Add("AccountIdentifier", typeof(Guid));

            foreach (var pi in accountIdentifiers)
            {
                var row = dt.NewRow();
                row["AccountIdentifier"] = pi;
                dt.Rows.Add(row);
            }

            cmd.Parameters.AddRange(
                new[]
                {
                    new SqlParameter() { ParameterName = "AccountList", Value=dt, SqlDbType= SqlDbType.Structured, TypeName = "[dbo].[typeAccountIdentifiers]"},
                });

            using (var conn = new SqlConnection(_dataAccess.ConnectionString))
            {
                cmd.Connection = conn;
                conn.Open();

                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    var status = new AccountCardStatus();

                    status.AccountKey = reader.GetInt64(reader.GetOrdinal("AccountKey"));
                    status.AccountIdentifier = reader.GetGuid(reader.GetOrdinal("AccountIdentifier")).ToString();
                    status.AccountStatusKey = reader["AccountStatusKey"] == DBNull.Value ? -1 : (Int16)reader["AccountStatusKey"];
                    status.AccountStatusReasonKey = Enum.Parse<AccountStatusReason>(reader["AccountStatusKey"] == DBNull.Value ? "0" : reader["AccountStatusReasonKey"].ToString());
                    status.ProductCode = reader["ProductCode"] == DBNull.Value ? null : reader["ProductCode"].ToString();
                    status.PaymentIdentifierCreateDate = reader["PaymentIdentifier_CreateDate"] == DBNull.Value ? (DateTime?)null : (DateTime)reader["PaymentIdentifier_CreateDate"];
                    status.PaymentIdentifierKey = reader["PaymentIdentifierKey"] == DBNull.Value ? -1 : (Int64)reader["PaymentIdentifierKey"];
                    status.PaymentIdentifierStatusKey = reader["PaymentIdentifierStatusKey"] == DBNull.Value ? -1 : (Int16)reader["PaymentIdentifierStatusKey"];
                    status.PaymentInstrumentCreateDate = reader["PaymentInstrument_CreateDate"] == DBNull.Value ? (DateTime?)null : (DateTime)reader["PaymentInstrument_CreateDate"];
                    status.PaymentInstrumentKey = reader["PaymentInstrumentKey"] == DBNull.Value ? -1 : (Int64)reader["PaymentInstrumentKey"];
                    status.PaymentInstrumentTypeKey = reader["PaymentInstrumentTypeKey"] == DBNull.Value ? -1 : (Int16)reader["PaymentInstrumentTypeKey"];
                    status.PaymentInstrumentStatusKey = reader["PaymentInstrumentStatusKey"] == DBNull.Value ? -1 : (Int16)reader["PaymentInstrumentStatusKey"];
                    status.ProgramCode = reader["ProgramCode"] == DBNull.Value ? null : reader["ProgramCode"].ToString();

                    accounts.Add(status);
                }
            }

            return accounts;
        }

        public AccountHolderIdentifier NextAccountHolderIdentifier()
        {
            return AccountHolderIdentifier.FromString(Guid.NewGuid().ToString());
        }

        public VerificationRequestIdentifier NextVerificationRequestIdentifier()
        {
            return VerificationRequestIdentifier.FromString(Guid.NewGuid().ToString());
        }

        private void GenerateAccountNumber(Account account, bool disableHeader, int length, string prefix)
        {
            string programCode = account.Product.ProgramCode.ToString();
            int processorKey = account.Product.ProcessorKey;

            bool needGenerateAccountNumberByGd = _baasConfiguration.GetGenerateAccountNumberByGD(programCode);
            if (!needGenerateAccountNumberByGd && (processorKey == 4 || processorKey == 5 || processorKey == 6))
            {
                account.AccountNumber = null;
                account.RoutingNumber = null;
            }
            else
            {
                account.AccountNumber = SetAccountNumber(prefix, length, disableHeader);
            }
            Logger.Info($"GenerateAccountNumber is {account.AccountNumber ?? "null"}, RoutingNumber is {account.RoutingNumber ?? "null"}," +
                $"Accountidentifier is {account.AccountIdentifier.ToString()},ProgramCode is {programCode},ProcessorKey is {processorKey}");
        }

        public void Add(Account account)
        {
            bool retry = true;
            bool middleAccountNumber = false;
            bool disableHeader = false;
            int retryCount = 5;

            try
            {
                int accountNumberLength = account.Product.ProgramCode.ToString().ToLower().Equals("stash") ? 11 : 10;
                string arnPrefix = _baasConfiguration.GetArnPrefix(account.Product.ProgramCode.ToString().ToLower());
                var txOptions = new TransactionOptions { IsolationLevel = IsolationLevel.ReadCommitted };
                var isTransferAutoAccept = _baasConfiguration.IsTransferAutoAccept(account.Product.ProgramCode.ToString());

                var stopWatch = new Stopwatch();
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, txOptions))
                {

                    do
                    {
                        stopWatch.Start();
                        var productProgramInfo = _programRepository.GetProductProgramPartner(account.Product.ProgramCode);

                        if (productProgramInfo.PartnerKey >= _requestHandlerSettings.NewPartnerKey)
                        {
                            string midNumber = middleAccountNumber == true ? "02" : "01";
                            if (account.AccountNumber == null)
                            {
                                GenerateAccountNumber(account, disableHeader, 8, account.Product.AchPrefix + midNumber);// SetAccountNumber(account.Product.AchPrefix + midNumber, 8, disableHeader); // GenerateAccountNumber(account, 8, disableHeader); //
                            }
                        }
                        else
                        {
                            if (account.AccountNumber == null)
                            {
                                GenerateAccountNumber(account, disableHeader, accountNumberLength, account.Product.AchPrefix);// SetAccountNumber(account.Product.AchPrefix + midNumber, 8, disableHeader); // GenerateAccountNumber(account, 8, disableHeader); //
                            }
                        }
                        string accountNumber = account.AccountNumber;

                        stopWatch.Stop();
                        Logger.Info($"AccountRepository.Add Get productProgramInfo completed.  cost time: {stopWatch.Elapsed.TotalMilliseconds}");
                        stopWatch.Restart();

                        string customerAccountNumber = SetCustomerAccountNumber(arnPrefix);
                        var language = string.IsNullOrEmpty(account.Language) ? "en-us" : account.Language.ToLower();
                        var accountParams = new[]
                        {
                            new SqlParameter
                            {
                                ParameterName = "AccountIdentifier",
                                Value = Guid.Parse(account.AccountIdentifier.ToString())
                            },
                            new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                            new SqlParameter {ParameterName = "ProcessorCreateDate", Value = DateTime.Now},
                            new SqlParameter {ParameterName = "AccountNumber", Value = accountNumber??string.Empty},
                            new SqlParameter {ParameterName = "RoutingNumber", Value = account.RoutingNumber??string.Empty},
                            new SqlParameter
                            {
                                ParameterName = "AccountReferenceNumber",
                                Value = customerAccountNumber
                            },
                            new SqlParameter {ParameterName = "AccountStatusKey", Value = 1},
                            new SqlParameter {ParameterName = "ProductKey", Value = account.Product.ProductKey},
                            new SqlParameter {ParameterName = "ProductTierKey", Value = account.ProductTierKey},
                            new SqlParameter {ParameterName = "SystemKey", Value = account.SystemKey },
                            new SqlParameter {ParameterName = "AccountLanguage", Value = language},
                            new SqlParameter {ParameterName = "AccountToken", Value = account.AccountToken}
                        };

                        using (var reader = _dataAccess.ExecuteReader("[dbo].[InsAccount]",
                                   _dataAccess.CreateConnection(), accountParams))
                        {
                            if (reader.Read())
                            {
                                if (Convert.ToInt32(reader["AlreadyExists"]) == 1)
                                {
                                    var maskedAccountNumber = string.IsNullOrEmpty(accountNumber) ? string.Empty : accountNumber.Replace(accountNumber.Substring(0, 10), "**********");

                                    Logger.Info(
                                        $"AccountRepository.Add, ACH/Customer Account Number already exists. RetryCount: {5 - retryCount} , AccountNumber： " +
                                        maskedAccountNumber +
                                        " CustomerAccountNumber： " +
                                        customerAccountNumber.Replace(customerAccountNumber.Substring(0, 6), "******"));
                                    retryCount--;

                                    // account.AccountNumber is passed in for prospect cards, and existing/duplicate accountNumber found, then stop processing.
                                    if (account.AccountNumber != null && retryCount < 0)
                                    {
                                        throw new Exception($"AccountNumber {account.AccountNumber} already exists.");
                                    }
                                    account.AccountNumber = null;
                                    middleAccountNumber = true;
                                    disableHeader = true;
                                }
                                else
                                {
                                    account.AccountKey = Convert.ToInt64(reader["AccountKey"]);
                                    account.AccountNumber = accountNumber ?? string.Empty;
                                    account.CustomerAccountNumber = customerAccountNumber;
                                    account.AccountStatusChangedDateTime = reader.GetDateTime(reader.GetOrdinal("StatusChangeDate"));
                                    retry = false;
                                }
                            }
                        }

                        stopWatch.Stop();
                        Logger.Info(
                            $"AccountRepository.Add InsAccount completed.  cost time: {stopWatch.Elapsed.TotalMilliseconds}");
                    } while (retry && retryCount >= 0);



                    stopWatch.Restart();

                    var accountStatusReasonParams = new[]
                    {
                        new SqlParameter
                        {
                            ParameterName = "AccountIdentifier",
                            Value = Guid.Parse(account.AccountIdentifier.ToString())
                        },
                        new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                        new SqlParameter
                        {
                            ParameterName = "AccountStatusReasonKey",
                            Value = AccountStatusReason.verificationNeeded
                        },
                        new SqlParameter {ParameterName = "IsActive", Value = true}
                    };

                    _dataAccess.ExecuteNonQuery("[dbo].[InsAccountStatusReasonHistory]", _dataAccess.CreateConnection(),
                        accountStatusReasonParams);
                    stopWatch.Stop();
                    Logger.Info($"AccountRepository.Add InsAccountStatusReasonHistory completed.  cost time: {stopWatch.Elapsed.TotalMilliseconds}");


                    var primaryAccountHolder = new AccountHolder();
                    foreach (AccountHolder ah in account.AccountHolders)
                    {
                        stopWatch.Restart();

                        var accountHolderParams = new[]
                        {
                            new SqlParameter {ParameterName = "ConsumerProfileKey", Value = ah.ConsumerProfileKey},
                            new SqlParameter {ParameterName = "IsTransferAutoAccept", Value = isTransferAutoAccept},
                            new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                            new SqlParameter {ParameterName = "AccountKey", Value = account.AccountKey},
                            new SqlParameter
                            {
                                ParameterName = "AccountHolderIdentifier",
                                Value = Guid.Parse(ah.AccountHolderIdentifier.ToString())
                            },
                            new SqlParameter {ParameterName = "IsPrimaryAccountHolder", Value = ah.IsPrimary}
                        };

                        object accountHolderKey = _dataAccess.ExecuteScalar("[dbo].[InsAccountHolder]",
                            _dataAccess.CreateConnection(), accountHolderParams);

                        ah.AccountHolderKey = Convert.ToInt64(accountHolderKey);
                        if (ah.IsPrimary)
                            primaryAccountHolder = ah;

                        stopWatch.Stop();
                        Logger.Info($"AccountRepository.Add InsAccountHolder with consumer {ah.ConsumerProfileKey} completed.  cost time: {stopWatch.Elapsed.TotalMilliseconds}");

                    }



                    if (account?.TermsAcceptances != null)
                    {

                        foreach (var ta in account?.TermsAcceptances)
                        {
                            stopWatch.Restart();

                            var termsParams = new[]
                            {
                            new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                            new SqlParameter
                            {
                                ParameterName = "AccountHolderKey",
                                Value = primaryAccountHolder.AccountHolderKey
                            },
                            new SqlParameter
                            {
                                ParameterName = "ProductAgreementTypeKey",
                                Value = ta.ProductAgreementTypeKey
                            },
                            new SqlParameter {ParameterName = "AcceptanceDate", Value = ta.TermsAcceptanceDateTime},
                            new SqlParameter {ParameterName = "HasAccepted", Value = ta.TermsAcceptanceFlag},
                            new SqlParameter {ParameterName = "OptoutDate", Value = ta.TermsAcceptanceFlag ? (DateTime?)null : ta.TermsAcceptanceDateTime}
                        };
                            _dataAccess.ExecuteNonQuery("[dbo].[InsAccountHolderAgreement]", _dataAccess.CreateConnection(),
                                termsParams);

                            stopWatch.Stop();
                            Logger.Info($"AccountRepository.Add InsAccountHolderAgreement with accountholder {primaryAccountHolder.AccountHolderKey} completed.  cost time: {stopWatch.Elapsed.TotalMilliseconds}");
                        }
                    }
                    scope.Complete();
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(ex, 
                    $"AccountRepository.Add, an error occurred for this Account identifier {account.AccountIdentifier} :" +
                    ex.Message);
                throw;
            }
        }

        public void CreateVerificationRequest(Account account,
            Dictionary<VerificationActivityType, VerificationStatus> verifyList, TriggerType triggerType)
        {
            try
            {
                var ah = account.AccountHolders?.FirstOrDefault();

                var verificationParams = new[]
                {
                        new SqlParameter
                        {
                            ParameterName = "VerificationRequestIdentifier",
                            Value = Guid.Parse(ah.VerificationRequestIdentifier.ToString())
                        },
                        new SqlParameter {ParameterName = "VerificationTriggerTypeKey", Value = triggerType},
                        new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                        new SqlParameter {ParameterName = "VerificationStatusKey", Value = 1},
                        new SqlParameter {ParameterName = "ConsumerProfileKey", Value = ah.ConsumerProfileKey},
                        new SqlParameter {ParameterName = "AccountHolderKey", Value = ah.AccountHolderKey},
                        new SqlParameter {ParameterName = "ProductKey", Value = account.Product.ProductKey}
                    };

                object verificationRequestKey = _dataAccess.ExecuteScalar("[dbo].[InsVerificationRequest]",
                    _dataAccess.CreateConnection(), verificationParams);

                foreach (var type in verifyList)
                {
                    var verificationActivityParams = new[]
                    {
                            new SqlParameter
                            {
                                ParameterName = "verificationRequestKey",
                                Value = verificationRequestKey
                            },
                            new SqlParameter {ParameterName = "VerificationChannelKey", Value = 1},
                            new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                            new SqlParameter {ParameterName = "VerificationActivityTypeKey", Value = type.Key},
                            new SqlParameter {ParameterName = "VerificationStatusKey", Value = type.Value},
                            new SqlParameter {ParameterName = "VerificationActivityStartDate", Value = DateTime.Now}
                        };

                    _dataAccess.ExecuteScalar("[dbo].[InsVerificationActivity]",
                        _dataAccess.CreateConnection(), verificationActivityParams);


                    account.VerificationRequestKey = Convert.ToInt64(verificationRequestKey);
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex, @"CreateVerificationRequest, error occurred when creating verification request : " +
                              ex.Message);
                throw;
            }
        }

        public void CreateVerificationRequestForBenificialOwner(Account account, AccountHolder accountHolder,
            Dictionary<VerificationActivityType, VerificationStatus> verifyList, TriggerType triggerType)
        {
            try
            {
                var ah = accountHolder;
                var verificationParams = new[]
                {
                        new SqlParameter
                        {
                            ParameterName = "VerificationRequestIdentifier",
                            Value = Guid.Parse(accountHolder.VerificationRequestIdentifier.ToString())
                        },
                        new SqlParameter {ParameterName = "VerificationTriggerTypeKey", Value = triggerType},
                        new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                        new SqlParameter {ParameterName = "VerificationStatusKey", Value = 1},
                        new SqlParameter {ParameterName = "ConsumerProfileKey", Value = ah.ConsumerProfileKey},
                        new SqlParameter {ParameterName = "AccountHolderKey", Value = ah.AccountHolderKey},
                        new SqlParameter {ParameterName = "ProductKey", Value = account.Product.ProductKey}
                    };

                object verificationRequestKey = _dataAccess.ExecuteScalar("[dbo].[InsVerificationRequest]",
                    _dataAccess.CreateConnection(), verificationParams);

                foreach (var type in verifyList)
                {
                    var verificationActivityParams = new[]
                    {
                            new SqlParameter
                            {
                                ParameterName = "verificationRequestKey",
                                Value = verificationRequestKey
                            },
                            new SqlParameter {ParameterName = "VerificationChannelKey", Value = 1},
                            new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                            new SqlParameter {ParameterName = "VerificationActivityTypeKey", Value = type.Key},
                            new SqlParameter {ParameterName = "VerificationStatusKey", Value = type.Value},
                            new SqlParameter {ParameterName = "VerificationActivityStartDate", Value = DateTime.Now}
                        };

                    _dataAccess.ExecuteScalar("[dbo].[InsVerificationActivity]",
                        _dataAccess.CreateConnection(), verificationActivityParams);


                    account.VerificationRequestKey = Convert.ToInt64(verificationRequestKey);
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex, @"CreateVerificationRequest, error occurred when creating verification request : " +
                              ex.Message);
                throw;
            }
        }


        public void CreateVerificationRequestFromSetStatus(Account account, AccountHolder ah, Dictionary<VerificationActivityType, VerificationStatus> verifyList, TriggerType triggerType)
        {
            try
            {
                var verificationParams = new[]
                {
                        new SqlParameter
                        {
                            ParameterName = "VerificationRequestIdentifier",
                            Value = Guid.Parse(ah.VerificationRequestIdentifier.ToString())
                        },
                        new SqlParameter {ParameterName = "VerificationTriggerTypeKey", Value = triggerType},
                        new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                        new SqlParameter {ParameterName = "VerificationStatusKey", Value = 1},
                        new SqlParameter {ParameterName = "ConsumerProfileKey", Value = ah.ConsumerProfileKey},
                        new SqlParameter {ParameterName = "AccountHolderKey", Value = ah.AccountHolderKey},
                        new SqlParameter {ParameterName = "ProductKey", Value = account.Product.ProductKey}
                    };

                object verificationRequestKey = _dataAccess.ExecuteScalar("[dbo].[InsVerificationRequest]",
                    _dataAccess.CreateConnection(), verificationParams);

                foreach (var type in verifyList)
                {
                    var verificationActivityParams = new[]
                    {
                            new SqlParameter
                            {
                                ParameterName = "verificationRequestKey",
                                Value = verificationRequestKey
                            },
                            new SqlParameter {ParameterName = "VerificationChannelKey", Value = 1},
                            new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                            new SqlParameter {ParameterName = "VerificationActivityTypeKey", Value = type.Key},
                            new SqlParameter {ParameterName = "VerificationStatusKey", Value = type.Value},
                            new SqlParameter {ParameterName = "VerificationActivityStartDate", Value = DateTime.Now}
                        };

                    _dataAccess.ExecuteScalar("[dbo].[InsVerificationActivity]",
                        _dataAccess.CreateConnection(), verificationActivityParams);


                    account.VerificationRequestKey = Convert.ToInt64(verificationRequestKey);
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex, @"CreateVerificationRequest, error occurred when creating verification request : " +
                              ex.Message);
                throw;
            }
        }

        public void CreateAdHocVerificationRequest(AccountHolder ah, long prodKey, Dictionary<VerificationActivityType, VerificationStatus> verifyList, TriggerType triggerType, short verificationStatusKey = 1)
        {
            try
            {
                var verificationParams = new[]
                {
                        new SqlParameter
                        {
                            ParameterName = "VerificationRequestIdentifier",
                            Value = Guid.Parse(ah.VerificationRequestIdentifier.ToString())
                        },
                        new SqlParameter {ParameterName = "VerificationTriggerTypeKey", Value = triggerType},
                        new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                        new SqlParameter {ParameterName = "VerificationStatusKey", Value = verificationStatusKey},
                        new SqlParameter {ParameterName = "ConsumerProfileKey", Value = ah.ConsumerProfileKey},
                        new SqlParameter {ParameterName = "AccountHolderKey", Value = ah.AccountHolderKey},
                        new SqlParameter {ParameterName = "ProductKey", Value = prodKey}
                    };

                object verificationRequestKey = _dataAccess.ExecuteScalar("[dbo].[InsVerificationRequest]",
                    _dataAccess.CreateConnection(), verificationParams);

                foreach (var type in verifyList)
                {
                    var verificationActivityParams = new[]
                    {
                            new SqlParameter
                            {
                                ParameterName = "verificationRequestKey",
                                Value = verificationRequestKey
                            },
                            new SqlParameter {ParameterName = "VerificationChannelKey", Value = 1},
                            new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                            new SqlParameter {ParameterName = "VerificationActivityTypeKey", Value = type.Key},
                            new SqlParameter {ParameterName = "VerificationStatusKey", Value = type.Value},
                            new SqlParameter {ParameterName = "VerificationActivityStartDate", Value = DateTime.Now}
                        };

                    _dataAccess.ExecuteScalar("[dbo].[InsVerificationActivity]",
                        _dataAccess.CreateConnection(), verificationActivityParams);
                }


            }
            catch (Exception ex)
            {
                Logger.Error(ex, @"CreateVerificationRequest, error occurred when creating verification request : " +
                              ex.Message);
                throw;
            }
        }

        public void CreateVerificationActivity(Account account,
            Dictionary<VerificationActivityType, VerificationStatus> verifyList, TriggerType triggerType)
        {
            try
            {
                foreach (var type in verifyList)
                {
                    var verificationActivityParams = new[]
                    {
                        new SqlParameter
                        {
                            ParameterName = "verificationRequestKey",
                            Value = account.VerificationRequestKey
                        },
                        new SqlParameter {ParameterName = "VerificationChannelKey", Value = 1},
                        new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                        new SqlParameter {ParameterName = "VerificationActivityTypeKey", Value = type.Key},
                        new SqlParameter {ParameterName = "VerificationStatusKey", Value = type.Value},
                        new SqlParameter {ParameterName = "VerificationActivityStartDate", Value = DateTime.Now}
                    };

                    _dataAccess.ExecuteScalar("[dbo].[InsVerificationActivity]",
                        _dataAccess.CreateConnection(), verificationActivityParams);
                }

            }
            catch (Exception ex)
            {
                Logger.Error(ex, @"CreateVerificationRequest, error occurred when creating verification request : " +
                              ex.Message);
                throw;
            }
        }

        /// <summary>
        /// GBOS-74610 2023-02-06 Add 
        /// </summary>
        /// <param name="paymentIdentifier"></param>
        /// <param name="embossedName"></param>
        public void UpdateCardEmbossName(Guid paymentIdentifier, string embossedName)
        {

            SqlParameter[] param = new[]
            {
                    new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                    new SqlParameter {ParameterName = "PaymentIdentifier", Value = paymentIdentifier},
                    new SqlParameter {ParameterName = "EmbossedName", Value = embossedName}
                };
            _dataAccess.ExecuteNonQuery("[dbo].[UpdEmbossedName]", _dataAccess.CreateConnection(),
                param);

        }

        /// <summary>
        /// GBOS-74610 2023-02-06 Add 
        /// </summary>
        /// <param name="accountIdentifier"></param>
        /// <returns></returns>

        public List<ConsumerProfile> GetConsumerProfiles(Guid accountIdentifier)
        {
            List<ConsumerProfile> profiles = new List<ConsumerProfile>();
            try
            {
                ;
                SqlParameter[] parameters = new SqlParameter[] { new SqlParameter("AccountIdentifier", accountIdentifier) };


                using (var rdr = _dataAccess.ExecuteReader("[dbo].[GetConsumerProfileByAccountIdentifier]",
                           _dataAccess.CreateConnection(), parameters))
                {

                    while (rdr.Read())
                    {
                        ConsumerProfile profile = new ConsumerProfile();

                        profile.ConsumerProfileKey = rdr.GetInt64(rdr.GetOrdinal("ConsumerProfileKey"));
                        profile.ConsumerProfileIdentifier = rdr.GetGuid(rdr.GetOrdinal("ConsumerProfileIdentifier"));
                        profile.IsPrimaryAccountHolder = rdr["IsPrimary"] != DBNull.Value && rdr.GetBoolean(rdr.GetOrdinal("IsPrimary"));
                        profile.IsTransferAutoAccept = rdr["IsTransferAutoAccept"] != DBNull.Value && rdr.GetBoolean(rdr.GetOrdinal("IsTransferAutoAccept"));
                        profile.FirstName = rdr["FirstName"] == DBNull.Value ? null : rdr["FirstName"].ToString();
                        profile.MiddleName = rdr["MiddleName"] == DBNull.Value ? null : rdr["MiddleName"].ToString();
                        profile.LastName = rdr["LastName"] == DBNull.Value ? null : rdr["LastName"].ToString();
                        profile.ConsumerProfileType = rdr["ConsumerProfileTypeKey"] == DBNull.Value ? null : (ConsumerProfileType?)rdr.GetInt16(rdr.GetOrdinal("ConsumerProfileTypeKey"));
                        profile.BusinessName = rdr["BusinessName"] == DBNull.Value ? null : rdr["BusinessName"].ToString();
                        profile.PaymentIdentifierIdentifier = rdr.GetGuid(rdr.GetOrdinal("PaymentIdentifier"));
                        profiles.Add(profile);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }

            return profiles;
        }

        public List<(long AccountKey, string IdentityCountryCode)> GetConsumerProfileCountryInfoByAccountKeys(
            List<long> accountKeys)
        {
            var result = new List<(long AccountKey, string IdentityCountryCode)>();
            try
            {
                var dt = new DataTable();
                dt.Columns.Add("AccountKey");
                foreach (var accountKey in accountKeys)
                {
                    var newRow = dt.NewRow();
                    newRow["AccountKey"] = accountKey;
                    dt.Rows.Add(newRow);
                }

                var parameters = new[]
                {
                    new SqlParameter()
                    {
                        ParameterName = "pAccountKeys",
                        SqlDbType = SqlDbType.Structured,
                        Value = dt,
                        TypeName = "typeAccountKey"
                    }
                };
                using var rdr = _dataAccess.ExecuteReader("[dbo].[GetConsumerProfileCountryInfoByAccountKeys]",
                    _dataAccess.CreateConnection(), parameters);
                while (rdr.Read())
                {
                    var accountKey = rdr.GetInt64(rdr.GetOrdinal("AccountKey"));
                    var identityAttributeValue = rdr.GetString(rdr.GetOrdinal("IdentityAttributeValue"));
                    result.Add((accountKey, identityAttributeValue));
                }
            }
            catch (Exception e)
            {
                Logger.Error(
                    $"AccountRepository.GetConsumerProfileCountryInfoByAccountKeys: error occurred when retrieving country info : {e}");
                throw;
            }

            return result;
        }


        public AccountPrimaryConsumerProfile GetAccountConsumerProfile(Guid? accountIdentifier, Guid? consumerProfileIdentifier,
            Guid? accountHolderIdentifier)
        {
            try
            {
                AccountPrimaryConsumerProfile accountPrimaryConsumerProfile = null;

                List<SqlParameter> sqlParameters = new List<SqlParameter>();

                if (accountIdentifier != null)
                    sqlParameters.Add(new SqlParameter { ParameterName = "AccountIdentifier", Value = accountIdentifier.Value });

                if (consumerProfileIdentifier != null)
                    sqlParameters.Add(new SqlParameter { ParameterName = "ConsumerProfileIdentifier", Value = consumerProfileIdentifier.Value });

                if (accountHolderIdentifier != null)
                {
                    sqlParameters.Add(new SqlParameter { ParameterName = "AccountHolderIdentifier", Value = accountHolderIdentifier.Value });
                }


                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetPrimaryConsumerProfileV3]",
                    _dataAccess.CreateConnectionWithColumnEncryption(), sqlParameters.ToArray()))
                {
                    while (reader.Read())
                    {
                        accountPrimaryConsumerProfile = new AccountPrimaryConsumerProfile();

                        if (accountIdentifier != null)
                            accountPrimaryConsumerProfile.AccountIdentifier = accountIdentifier.Value;

                        accountPrimaryConsumerProfile.FirstName = reader["FirstName"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("FirstName"));
                        accountPrimaryConsumerProfile.MiddleName = reader["MiddleName"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("MiddleName"));
                        accountPrimaryConsumerProfile.LastName = reader["LastName"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("LastName"));
                        accountPrimaryConsumerProfile.DOB = reader["EncryptedDOB"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("EncryptedDOB"));
                        accountPrimaryConsumerProfile.AddressType = (AddressType)Enum.Parse(typeof(AddressType), reader["AddressTypeKey"].ToString());
                        accountPrimaryConsumerProfile.Address1 = reader["Address1"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Address1"));
                        accountPrimaryConsumerProfile.Address2 = reader["Address2"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Address2"));
                        accountPrimaryConsumerProfile.City = reader["City"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("City"));
                        accountPrimaryConsumerProfile.State = reader["State"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("State"));
                        accountPrimaryConsumerProfile.ZipCode = reader["ZipCode"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("ZipCode"));
                        accountPrimaryConsumerProfile.Country = reader["Country"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Country"));
                        accountPrimaryConsumerProfile.Email = reader["Email"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Email"));
                        accountPrimaryConsumerProfile.PhoneNumber = reader["PhoneNumber"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("PhoneNumber"));
                        accountPrimaryConsumerProfile.ProgramCode = reader["ProgramCode"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("ProgramCode"));
                        accountPrimaryConsumerProfile.ProductCode = reader["ProductCode"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("ProductCode"));
                        accountPrimaryConsumerProfile.AccountStatus = (AccountStatus)Convert.ToInt32(reader["AccountStatusKey"]);
                        accountPrimaryConsumerProfile.AccountHolderKey = reader.GetInt64(reader.GetOrdinal("AccountHolderKey"));
                        accountPrimaryConsumerProfile.AccountKey = reader.GetInt64(reader.GetOrdinal("AccountKey"));
                        accountPrimaryConsumerProfile.ProductKey = reader.GetInt32(reader.GetOrdinal("ProductKey"));
                        accountPrimaryConsumerProfile.ConsumerProfileKey = reader.GetInt64(reader.GetOrdinal("ConsumerProfileKey"));
                        accountPrimaryConsumerProfile.AccountHolderIdentifier = reader["AccountHolderIdentifier"] == DBNull.Value ? new Guid() : reader.GetGuid(reader.GetOrdinal("AccountHolderIdentifier"));
                        accountPrimaryConsumerProfile.AccountHolderCure = reader["AccountHolderCureKey"] == DBNull.Value ? AccountHolderCure.Unknown : (AccountHolderCure)(Convert.ToInt32(reader["AccountHolderCureKey"]));
                        accountPrimaryConsumerProfile.AccountNumber = reader["AccountNumber"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("AccountNumber"));
                        accountPrimaryConsumerProfile.RoutingNumber = reader["RoutingNumber"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("RoutingNumber"));
                        accountPrimaryConsumerProfile.AccountReferenceNumber = reader["AccountReferenceNumber"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("AccountReferenceNumber"));

                        break;
                    }

                    // no consumer profile found!
                    if (accountPrimaryConsumerProfile == null)
                        return null;

                    // payment info
                    reader.NextResult();

                    accountPrimaryConsumerProfile.PaymentIdentifiers = new List<PaymentIdentifier>();
                    while (reader.Read())
                    {
                        // backwards compability
                        accountPrimaryConsumerProfile.PaymentIdentifier = reader["PaymentIdentifier"] == DBNull.Value ? null : reader["PaymentIdentifier"].ToString();
                        accountPrimaryConsumerProfile.PaymentIdentifierStatus = (PaymentIdentifierStatus)(short)reader["PaymentIdentifierStatusKey"];
                        accountPrimaryConsumerProfile.PaymentIdentifierKey = reader["PaymentIdentifierKey"] == DBNull.Value ? 0 : Convert.ToInt64(reader["PaymentIdentifierKey"]);
                        accountPrimaryConsumerProfile.PaymentInstrumentIdentifier = reader["PaymentInstrumentIdentifier"] == DBNull.Value ? null : reader["PaymentInstrumentIdentifier"].ToString();
                        accountPrimaryConsumerProfile.IsVirtualCardExist = true;


                        var paymentIdentifier = new PaymentIdentifier(PaymentIdentifierIdentifier.FromString(accountPrimaryConsumerProfile.PaymentIdentifier))
                        {
                            PaymentIdentifierStatusKey = (int)accountPrimaryConsumerProfile.PaymentIdentifierStatus,
                            PaymentIdentifierKey = accountPrimaryConsumerProfile.PaymentIdentifierKey,
                            PaymentInstrument = new Gd.Bos.RequestHandler.Core.Domain.Model.Payment.PaymentInstrument
                            {
                                PaymentInstrumentIdentifier = accountPrimaryConsumerProfile.PaymentInstrumentIdentifier,
                            }
                        };
                        accountPrimaryConsumerProfile.PaymentIdentifiers.Add(paymentIdentifier);
                    }

                    // token identity
                    reader.NextResult();
                    var identityInfo = ReadUserProfileIdentity(reader, 0);
                    accountPrimaryConsumerProfile.IdentityToken = identityInfo?.IdentityToken;
                    accountPrimaryConsumerProfile.IdentityType = identityInfo?.IdentityType;

                    return accountPrimaryConsumerProfile;
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(ex, $"AccountRepository.GetAccountPrimaryConsumerProfile: error occurred when retrieving profile for user identifier {accountIdentifier} : {ex}");
                throw new Exception("An error occurred trying to retrieve consumer profile: " + ex.Message);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="deviceTokenId">DeviceIdentifier</param>
        /// <returns>AccountPrimaryConsumerProfile (caution: with limited propertys populated)</returns>
        /// <exception cref="Exception"></exception>
        public AccountPrimaryConsumerProfile GetAccountConsumerProfile(string deviceTokenId)
        {
            try
            {
                List<AccountPrimaryConsumerProfile> cProfiles = new List<AccountPrimaryConsumerProfile>();

                List<SqlParameter> sqlParameters = new List<SqlParameter>();

                if (deviceTokenId != null)
                    sqlParameters.Add(new SqlParameter { ParameterName = "DPANID", Value = deviceTokenId });

                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetConsumerProfileContactByDPANID]",
                    _dataAccess.CreateConnection(), sqlParameters.ToArray()))
                {
                    while (reader.Read())
                    {
                        AccountPrimaryConsumerProfile accountPrimaryConsumerProfile = new AccountPrimaryConsumerProfile();

                        accountPrimaryConsumerProfile.AccountIdentifier = AccountIdentifier.FromGuid(Guid.Parse(reader["AccountIdentifier"].ToString()));
                        accountPrimaryConsumerProfile.FirstName = reader["FirstName"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("FirstName"));
                        accountPrimaryConsumerProfile.LastName = reader["LastName"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("LastName"));
                        accountPrimaryConsumerProfile.PhoneNumber = reader["PhoneNumber"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("PhoneNumber"));
                        accountPrimaryConsumerProfile.ProgramCode = reader["ProgramCode"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("ProgramCode"));
                        accountPrimaryConsumerProfile.ProductCode = reader["ProductCode"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("ProductCode"));
                        accountPrimaryConsumerProfile.Email = reader["Email"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Email"));
                        accountPrimaryConsumerProfile.AccountCreateDate = reader.GetDateTime(reader.GetOrdinal("CreateDate"));

                        cProfiles.Add(accountPrimaryConsumerProfile);
                    }

                    if (!cProfiles.Any())
                    {
                        return null;
                    }

                    return cProfiles.Select(p => p).OrderByDescending(d => d.AccountCreateDate).FirstOrDefault();

                }
            }
            catch (SqlException ex)
            {
                Logger.Error(ex, $"AccountRepository.GetAccountConsumerProfile(string deviceTokenId): error occurred when retrieving profile" +
                    $" by device token id {deviceTokenId} : {ex}");
                throw new Exception("An error occurred trying to retrieve consumer profile: " + ex.Message);
            }
        }

        public void UpdateDeviceProvisioningMessage(string deviceIdentifier, string dPanId, string fPanId)
        {
            try
            {
                List<SqlParameter> sqlParameters = new List<SqlParameter>
                {
                    new SqlParameter { ParameterName = "DeviceIdentifier", Value = deviceIdentifier },
                    new SqlParameter
                        { ParameterName = "DPANID", Value = string.IsNullOrEmpty(dPanId) ? DBNull.Value : dPanId },
                    new SqlParameter
                        { ParameterName = "FPANID", Value = string.IsNullOrEmpty(fPanId) ? DBNull.Value : fPanId }
                };

                _dataAccess.ExecuteNonQuery("[dbo].[UpdDeviceProvisioningMessageByDeviceIdentifier]",
                    _dataAccess.CreateConnection(), sqlParameters.ToArray());

            }
            catch (SqlException ex)
            {
                Logger.Error(ex, $"AccountRepository.UpdateDeviceProvisioningMessage(string deviceIdentifier, string DPAN, string FPAN): error occurred when updating DeviceProvisionMessage" +
                    $" by device token id {deviceIdentifier} : {ex}");
                throw new Exception("An error occurred trying to update DeviceProvisionMessage: " + ex.Message);
            }
        }

        public void UpdateAdhocVerificationReason(Account account, AccountHolder ah, Dictionary<int, Tuple<VerificationActivityType, VerificationStatus, List<VerificationStatusReason>>> resultData)
        {
            try
            {
                foreach (var statusData in resultData)
                {
                    string endDate = DateTime.Now.ToString(CultureInfo.InvariantCulture);

                    var result = statusData.Value;

                    VerificationActivityType verificationType = result.Item1;
                    VerificationStatus verificationStatusKey = result.Item2;

                    var verificationStatusReason = result.Item3 != null ? ToDataTable(result.Item3) : null;

                    var verificationActivityParams = new[]
                    {
                        new SqlParameter
                        {
                            ParameterName = "verificationRequestKey",
                            Value = account.VerificationRequestKey
                        },
                        new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                        new SqlParameter {ParameterName = "VerificationActivityTypeKey", Value = verificationType},
                        new SqlParameter {ParameterName = "VerificationStatusKey", Value = verificationStatusKey},
                        new SqlParameter {ParameterName = "VerificationActivityEndDate", Value = endDate},
                        new SqlParameter
                        {
                            ParameterName = "VerificationStatusReason",
                            Value = verificationStatusReason,
                            TypeName = "typeVerificationStatusReason",
                            SqlDbType = SqlDbType.Structured
                        }
                    };

                    _dataAccess.ExecuteNonQuery("[dbo].[UpdVerificationActivityStatus]", _dataAccess.CreateConnection(),
                        verificationActivityParams);
                }


            }
            catch (Exception ex)
            {
                throw new Exception("Verification activity not found, please review the risk response.", ex);
            }
        }


        public void UpdateVerificationRequestAdditionalHolder(Account account, AccountHolder ah,
            VerificationStatus verificationStatus, Dictionary<int, Tuple<VerificationActivityType, VerificationStatus, List<VerificationStatusReason>>> resultData)
        {

            var accountHolderParams = new[]
            {
                    new SqlParameter {ParameterName = "AccountHolderKey", Value = ah.AccountHolderKey},
                    new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                    new SqlParameter {ParameterName = "AccountHolderCureKey", Value = ah.AccountHolderCure}
                };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdAccountHolderCureByAccountHolderKey]",
                _dataAccess.CreateConnection(), accountHolderParams);

            var verificationParams = new[]
            {
                    new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                    new SqlParameter {ParameterName = "VerificationStatusKey", Value = verificationStatus},
                    new SqlParameter
                    {
                        ParameterName = "verificationRequestKey",
                        Value = account.VerificationRequestKey
                    }
                };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdVerificationRequestStatus]", _dataAccess.CreateConnection(),
                verificationParams);

            try
            {
                foreach (var statusData in resultData)
                {
                    string endDate = null;

                    var result = statusData.Value;

                    VerificationActivityType verificationType = result.Item1;
                    VerificationStatus verificationStatusKey = result.Item2;

                    if (verificationType != VerificationActivityType.OFAC &&
                          (ah.kycStateData.KycPendingGate != "kyc2"))
                    {
                        if (verificationStatusKey == VerificationStatus.Passed ||
                            verificationStatusKey == VerificationStatus.Failed)
                            endDate = DateTime.Now.ToString(CultureInfo.InvariantCulture);
                    }
                    else
                    {
                        if (verificationStatusKey == VerificationStatus.Passed)
                            endDate = DateTime.Now.ToString(CultureInfo.InvariantCulture);
                    }

                    var verificationStatusReason = result.Item3 != null ? ToDataTable(result.Item3) : null;

                    var verificationActivityParams = new[]
                    {
                        new SqlParameter
                        {
                            ParameterName = "verificationRequestKey",
                            Value = account.VerificationRequestKey
                        },
                        new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                        new SqlParameter {ParameterName = "VerificationActivityTypeKey", Value = verificationType},
                        new SqlParameter {ParameterName = "VerificationStatusKey", Value = verificationStatusKey},
                        new SqlParameter {ParameterName = "VerificationActivityEndDate", Value = endDate},
                        new SqlParameter
                        {
                            ParameterName = "VerificationStatusReason",
                            Value = verificationStatusReason,
                            TypeName = "typeVerificationStatusReason",
                            SqlDbType = SqlDbType.Structured
                        }
                    };

                    _dataAccess.ExecuteNonQuery("[dbo].[UpdVerificationActivityStatus]", _dataAccess.CreateConnection(),
                        verificationActivityParams);
                }
            }
            catch (Exception)
            {
                throw new Exception("Verification activity not found, please review the risk response.");
            }
        }

        public void UpdateVerificationRequest(Account account, AccountHolder ah, Dictionary<VerificationActivityType, VerificationStatus> verifyList,
            VerificationStatus verificationStatus, List<AccountStatusReason> statusReasons,
            Dictionary<int, Tuple<VerificationActivityType, VerificationStatus, List<VerificationStatusReason>>> resultData,
            bool isJoinAccount = false, bool isHardDeclined = false, bool isNeededToUpdateAccountStatus = true)
        {
            try
            {
                var accountHolderParams = new[]
                {
                    new SqlParameter {ParameterName = "AccountHolderKey", Value = ah.AccountHolderKey},
                    new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                    new SqlParameter {ParameterName = "AccountHolderCureKey", Value = ah.AccountHolderCure}
                };

                _dataAccess.ExecuteNonQuery("[dbo].[UpdAccountHolderCureByAccountHolderKey]",
                    _dataAccess.CreateConnection(), accountHolderParams);

                var verificationParams = new[]
                {
                    new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                    new SqlParameter {ParameterName = "VerificationStatusKey", Value = verificationStatus},
                    new SqlParameter
                    {
                        ParameterName = "verificationRequestKey",
                        Value = account.VerificationRequestKey
                    }
                };

                _dataAccess.ExecuteNonQuery("[dbo].[UpdVerificationRequestStatus]", _dataAccess.CreateConnection(),
                    verificationParams);

                try
                {
                    if (resultData != null)
                    {
                        foreach (var statusData in resultData)
                        {
                            string endDate = null;

                            var result = statusData.Value;

                            VerificationActivityType verificationType = result.Item1;
                            VerificationStatus verificationStatusKey = result.Item2;

                            if (verificationType != VerificationActivityType.OFAC &&
                                (ah.kycStateData.KycPendingGate != "kyc2"))
                            {
                                if (verificationStatusKey == VerificationStatus.Passed ||
                                    verificationStatusKey == VerificationStatus.Failed)
                                    endDate = DateTime.Now.ToString(CultureInfo.InvariantCulture);
                            }
                            else
                            {
                                if (verificationStatusKey == VerificationStatus.Passed 
                                    || (isJoinAccount && ah.kycStateData.KycPendingGate == "none")
                                    || (isHardDeclined && verificationStatusKey == VerificationStatus.Failed))
                                    endDate = DateTime.Now.ToString(CultureInfo.InvariantCulture);
                            }

                            var verificationStatusReason = result.Item3 != null ? ToDataTable(result.Item3) : null;

                            var verificationActivityParams = new[]
                            {
                                new SqlParameter
                                {
                                    ParameterName = "verificationRequestKey",
                                    Value = account.VerificationRequestKey
                                },
                                new SqlParameter { ParameterName = "ChangeBy", Value = _userName },
                                new SqlParameter
                                    { ParameterName = "VerificationActivityTypeKey", Value = verificationType },
                                new SqlParameter
                                    { ParameterName = "VerificationStatusKey", Value = verificationStatusKey },
                                new SqlParameter { ParameterName = "VerificationActivityEndDate", Value = endDate },
                                new SqlParameter
                                {
                                    ParameterName = "VerificationStatusReason",
                                    Value = verificationStatusReason,
                                    TypeName = "typeVerificationStatusReason",
                                    SqlDbType = SqlDbType.Structured
                                }
                            };

                            if (account.VerificationRequestKey > 0)
                                _dataAccess.ExecuteNonQuery("[dbo].[UpdVerificationActivityStatus]",
                                    _dataAccess.CreateConnection(),
                                    verificationActivityParams);
                        }
                    }

                }
                catch (Exception)
                {
                    throw new Exception("Verification activity not found, please review the risk response.");
                }

                if (isNeededToUpdateAccountStatus)
                {
                    if (ah.IsPrimaryHolderExists)
                    {
                        UpdateSecondaryAccountStatusAndReasonAfterVerification(account, statusReasons);
                    }
                    else
                    {
                        UpdatePrimaryAccountStatusAndReasonAfterVerification(account, statusReasons);
                    }
                }

                if (ah.AccountHolderCure == AccountHolderCure.IDV)
                {
                    foreach (var type in verifyList)
                    {
                        var verificationActivityParams = new[]
                        {
                            new SqlParameter
                            {
                                ParameterName = "verificationRequestKey",
                                Value = account.VerificationRequestKey
                            },
                            new SqlParameter {ParameterName = "VerificationChannelKey", Value = 1},
                            new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                            new SqlParameter {ParameterName = "VerificationActivityTypeKey", Value = type.Key},
                            new SqlParameter {ParameterName = "VerificationStatusKey", Value = type.Value},
                            new SqlParameter {ParameterName = "VerificationActivityStartDate", Value = DateTime.Now}
                        };

                        _dataAccess.ExecuteScalar("[dbo].[InsVerificationActivity]",
                            _dataAccess.CreateConnection(), verificationActivityParams);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex, 
                    $"UpdateVerificationRequest, an error occurred for this Account identifier {account.AccountIdentifier} :" +
                    ex.Message);
                throw;
            }
        }


        private void UpdateSecondaryAccountStatusAndReasonAfterVerification(Account account,
            List<AccountStatusReason> statusReasons)
        {
            var accountParams = new[]
            {
                new SqlParameter {ParameterName = "AccountKey", Value = account.AccountKey},
                new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                new SqlParameter {ParameterName = "AccountStatusKey", Value = account.AccountStatus}
            };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdAccountStatusByAccountKey]", _dataAccess.CreateConnection(),
                accountParams);

            if (statusReasons.Count > 0)
            {
                var accountStatusReasonsToRemove = new List<AccountStatusReason>
                {
                    AccountStatusReason.registrationFailed,
                    AccountStatusReason.registrationNotComplete,
                    AccountStatusReason.potentialFraud,
                    AccountStatusReason.verificationNeeded,
                    AccountStatusReason.confirmedFraud,
                    AccountStatusReason.identityTheft,
                    AccountStatusReason.spendDown,
                    AccountStatusReason.ownerInfoNotComplete,
                    AccountStatusReason.businessProfileNotComplete,
                    AccountStatusReason.healthy,
                    AccountStatusReason.IdvManual
                };

                _dataAccess.ExecuteNonQuery(
                    "[dbo].[UpdAccountStatusReasonHistoryV2]", _dataAccess.CreateConnection(),
                    new SqlParameter("ChangeBy", _userName),
                    new SqlParameter("AccountIdentifier", (Guid)account.AccountIdentifier),
                    new SqlParameter { ParameterName = "AccountStatusReasonKey", Value = ToAccountStatusReasonTable(accountStatusReasonsToRemove).Convert(), TypeName = "typeAccountStatusReason", SqlDbType = SqlDbType.Structured }
                );
            }

            foreach (AccountStatusReason statusReason in statusReasons)
            {
                var accountStatusReasonParams = new[]
                {
                    new SqlParameter
                    {
                        ParameterName = "AccountIdentifier",
                        Value = Guid.Parse(account.AccountIdentifier.ToString())
                    },
                    new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                    new SqlParameter {ParameterName = "AccountStatusReasonKey", Value = statusReason},
                    new SqlParameter("IsActive", true)  };

                _dataAccess.ExecuteNonQuery("[dbo].[InsAccountStatusReasonHistory]",
                    _dataAccess.CreateConnection(), accountStatusReasonParams);
            }
        }

        private void UpdatePrimaryAccountStatusAndReasonAfterVerification(Account account, List<AccountStatusReason> statusReasons)
        {

            if (account.TriggerType == TriggerType.FraudStatusCure && account.AccountStatus == AccountStatus.Normal)
            {
                var accountParams = new[]
                {
                        new SqlParameter {ParameterName = "AccountKey", Value = account.AccountKey},
                        new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                        new SqlParameter {ParameterName = "AccountStatusKey", Value = account.AccountStatus}
                    };

                _dataAccess.ExecuteNonQuery("[dbo].[UpdAccountStatusByAccountKey]", _dataAccess.CreateConnection(),
                    accountParams);
            }
            else if (account.TriggerType != TriggerType.FraudStatusCure)
            {
                var accountParams = new[]
                {
                        new SqlParameter {ParameterName = "AccountKey", Value = account.AccountKey},
                        new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                        new SqlParameter {ParameterName = "AccountStatusKey", Value = account.AccountStatus}
                    };

                _dataAccess.ExecuteNonQuery("[dbo].[UpdAccountStatusByAccountKey]", _dataAccess.CreateConnection(),
                    accountParams);
            }

            if (statusReasons.Count > 0)
            {
                var accountStatusReasonsToRemove = new List<AccountStatusReason>
                    {
                        AccountStatusReason.registrationFailed,
                        AccountStatusReason.registrationNotComplete,
                        AccountStatusReason.potentialFraud,
                        AccountStatusReason.verificationNeeded,
                        AccountStatusReason.confirmedFraud,
                        AccountStatusReason.identityTheft,
                        AccountStatusReason.spendDown,
                        AccountStatusReason.ownerInfoNotComplete,
                        AccountStatusReason.businessProfileNotComplete,
                        AccountStatusReason.healthy,
                        AccountStatusReason.IdvManual
                    };

                _dataAccess.ExecuteNonQuery(
                    "[dbo].[UpdAccountStatusReasonHistoryV2]", _dataAccess.CreateConnection(),
                    new SqlParameter("ChangeBy", _userName),
                    new SqlParameter("AccountIdentifier", (Guid)account.AccountIdentifier),
                    new SqlParameter { ParameterName = "AccountStatusReasonKey", Value = ToAccountStatusReasonTable(accountStatusReasonsToRemove).Convert(), TypeName = "typeAccountStatusReason", SqlDbType = SqlDbType.Structured }
                );
            }

            foreach (AccountStatusReason statusReason in statusReasons)
            {
                var accountStatusReasonParams = new[]
                {
                        new SqlParameter
                        {
                            ParameterName = "AccountIdentifier",
                            Value = Guid.Parse(account.AccountIdentifier.ToString())
                        },
                        new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                        new SqlParameter {ParameterName = "AccountStatusReasonKey", Value = statusReason},
                        new SqlParameter("IsActive", true)  };

                _dataAccess.ExecuteNonQuery("[dbo].[InsAccountStatusReasonHistory]",
                    _dataAccess.CreateConnection(), accountStatusReasonParams);
            }

        }




        public void UpdateVerificationRequest(Account account, AccountHolder ah, Dictionary<VerificationActivityType, VerificationStatus> verifyList,
            VerificationStatus verificationStatus, Dictionary<int, Tuple<VerificationActivityType, VerificationStatus, List<VerificationStatusReason>>> resultData, bool updateAccountHolderCure, AccountHolderCure upgradeCure)
        {
            try
            {
                if (updateAccountHolderCure)
                {
                    var accountHolderParams = new[]
                    {
                        new SqlParameter {ParameterName = "AccountHolderKey", Value = ah.AccountHolderKey},
                        new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                        new SqlParameter {ParameterName = "AccountHolderCureKey", Value = ah.AccountHolderCure}
                    };

                    _dataAccess.ExecuteNonQuery("[dbo].[UpdAccountHolderCureByAccountHolderKey]",
                        _dataAccess.CreateConnection(), accountHolderParams);
                }

                var verificationParams = new[]
                {
                    new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                    new SqlParameter {ParameterName = "VerificationStatusKey", Value = verificationStatus},
                    new SqlParameter
                    {
                        ParameterName = "verificationRequestKey",
                        Value = account.VerificationRequestKey
                    }
                };

                _dataAccess.ExecuteNonQuery("[dbo].[UpdVerificationRequestStatus]", _dataAccess.CreateConnection(),
                    verificationParams);

                try
                {
                    if (resultData != null)
                    {
                        foreach (var statusData in resultData)
                        {
                            var result = statusData.Value;

                            VerificationActivityType verificationType = result.Item1;
                            VerificationStatus verificationStatusKey = result.Item2;

                            string verificationEndDate = null;
                            if (verificationType != VerificationActivityType.OFAC)
                            {
                                if (verificationStatusKey == VerificationStatus.Passed || verificationStatusKey == VerificationStatus.Failed)
                                    verificationEndDate = DateTime.Now.ToString(CultureInfo.InvariantCulture);
                            }
                            else
                            {
                                if (verificationStatusKey == VerificationStatus.Passed ||
                                    verificationStatusKey == VerificationStatus.Failed && upgradeCure == AccountHolderCure.None)
                                {
                                    verificationEndDate = DateTime.Now.ToString(CultureInfo.InvariantCulture);
                                }
                            }

                            var verificationStatusReason = result.Item3 != null ? ToDataTable(result.Item3) : null;

                            var verificationActivityParams = new[]
                            {
                                new SqlParameter
                                {
                                    ParameterName = "verificationRequestKey",
                                    Value = account.VerificationRequestKey
                                },
                                new SqlParameter { ParameterName = "ChangeBy", Value = _userName },
                                new SqlParameter
                                    { ParameterName = "VerificationActivityTypeKey", Value = verificationType },
                                new SqlParameter
                                    { ParameterName = "VerificationStatusKey", Value = verificationStatusKey },
                                new SqlParameter { ParameterName = "VerificationActivityEndDate", Value = verificationEndDate },
                                new SqlParameter
                                {
                                    ParameterName = "VerificationStatusReason",
                                    Value = verificationStatusReason,
                                    TypeName = "typeVerificationStatusReason",
                                    SqlDbType = SqlDbType.Structured
                                }
                            };

                            if (account.VerificationRequestKey > 0)
                                _dataAccess.ExecuteNonQuery("[dbo].[UpdVerificationActivityStatus]",
                                    _dataAccess.CreateConnection(),
                                    verificationActivityParams);
                        }
                    }

                }
                catch (Exception)
                {
                    throw new Exception("Verification activity not found, please review the risk response.");
                }

                if (upgradeCure == AccountHolderCure.IDV)
                {
                    foreach (var type in verifyList)
                    {
                        var verificationActivityParams = new[]
                        {
                            new SqlParameter
                            {
                                ParameterName = "verificationRequestKey",
                                Value = account.VerificationRequestKey
                            },
                            new SqlParameter {ParameterName = "VerificationChannelKey", Value = 1},
                            new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                            new SqlParameter {ParameterName = "VerificationActivityTypeKey", Value = type.Key},
                            new SqlParameter {ParameterName = "VerificationStatusKey", Value = type.Value},
                            new SqlParameter {ParameterName = "VerificationActivityStartDate", Value = DateTime.Now}
                        };

                        _dataAccess.ExecuteScalar("[dbo].[InsVerificationActivity]",
                            _dataAccess.CreateConnection(), verificationActivityParams);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error(
                    $"UpdateVerificationRequest, an error occurred for this Account identifier {account.AccountIdentifier} :" +
                    ex.Message);
                throw;
            }
        }

        private DataTable ToDataTable<T>(IList<T> data)
        {
            PropertyDescriptorCollection props = TypeDescriptor.GetProperties(typeof(T).Name);

            DataTable table = new DataTable();
            for (int i = 0; i < props.Count; i++)
            {
                PropertyDescriptor prop = props[i];
                table.Columns.Add(prop.Name, prop.PropertyType);
            }

            object[] values = new object[props.Count];
            foreach (T item in data)
            {
                for (int i = 0; i < values.Length; i++)
                {
                    values[i] = item;
                }

                table.Rows.Add(values);
            }

            return table;
        }

        /// <summary>
        /// GetAccountStatusByAccountIdentifier
        /// </summary>
        /// <param name="accountIdentifier"></param>
        /// <returns></returns>
        public AdditionalAccountLimit GetAccountStatusByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            var additionalAccountLimit = new AdditionalAccountLimit();
            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountStatusByAccountIdentifier]",
                    _dataAccess.CreateConnection(), new SqlParameter
                    {
                        ParameterName = "AccountIdentifier",
                        Value = accountIdentifier.ToString()
                    }))
                {
                    if (reader.Read())
                    {
                        additionalAccountLimit.AccountStatus = reader["AccountStatusKey"] != DBNull.Value ? (AccountStatus)(short)reader["AccountStatusKey"] : AccountStatus.Pending;
                        reader.NextResult();

                        if (additionalAccountLimit.AccountStatus != AccountStatus.Normal)
                        {
                            while (reader.Read())
                            {
                                var status = reader["AccountStatusKey"] != DBNull.Value ? (AccountStatus)(short)reader["AccountStatusKey"] : AccountStatus.Pending;
                                if (status == AccountStatus.Normal)
                                {
                                    additionalAccountLimit.IsAccountEverActive = true;
                                }
                            }
                        }
                        return additionalAccountLimit;
                    }

                    throw new AccountNotFoundException();
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(
                    $"AccountRepository.GetAccountStatusByAccountIdentifier, error occurred when retrieving account identifier {accountIdentifier} : {ex}");
                throw;
            }
        }

        public Tuple<AccountHolder, int, int> GetAdditionalHolderAccountByAccountHolderIdentifier(string accountHolderIdentifier)
        {
            try
            {
                AccountHolder ah = null;
                int verificationRequestKey = 0;
                int accountKey = 0;

                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountHolderbyAccountHolderIdentifier]",
                    _dataAccess.CreateConnection(), new SqlParameter
                    {
                        ParameterName = "AccountHolderIdentifier",
                        Value = Guid.Parse(accountHolderIdentifier)
                    }))
                {
                    while (reader.Read())
                    {

                        var isPrimaryAccountHolder = reader["IsPrimaryAccountHolder"] != DBNull.Value && reader.GetBoolean(reader.GetOrdinal("IsPrimaryAccountHolder"));
                        var accountHolderKey = Convert.ToInt32(reader["AccountHolderKey"]);
                        var consumerProfileKey = Convert.ToInt32(reader["ConsumerProfileKey"]);
                        accountKey = Convert.ToInt32(reader["AccountKey"]);
                        var accountHolderCure = reader["AccountHolderCureKey"] == DBNull.Value ? AccountHolderCure.Unknown : (AccountHolderCure)(Convert.ToInt32(reader["AccountHolderCureKey"]));
                        ah = new AccountHolder(null, AccountHolderIdentifier.FromString(accountHolderIdentifier), null, isPrimaryAccountHolder);
                        ah.AccountHolderCure = accountHolderCure;
                        ah.ConsumerProfileKey = consumerProfileKey;
                        ah.AccountHolderKey = accountHolderKey;
                    }

                    reader.NextResult();

                    if (reader.Read())
                        verificationRequestKey = Convert.ToInt32(reader["VerificationRequestKey"]);

                    return new Tuple<AccountHolder, int, int>(ah, verificationRequestKey, accountKey);
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(
                    $"AccountRepository.GetAdditionalHolderAccountByAccountHolderIdentifier, error occurred when retrieving account identifier {accountHolderIdentifier} : {ex}");
                throw;
            }
        }

        public AccountForShowcase GetAccountByAccountIdentifierForShowcase(string accountIdentifier)
        {
            try
            {
                AccountForShowcase account = new AccountForShowcase();

                using var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountInfoByAccountIdentifier]",
                    _dataAccess.CreateConnection(),
                    new SqlParameter { ParameterName = "AccountIdentifier", Value = accountIdentifier });
                while (reader.Read())
                {
                    account.AccountIdentifier = reader["AccountIdentifier"] != DBNull.Value ? reader["AccountIdentifier"].ToString() : string.Empty;
                    account.AccountCreateDate = Cast<DateTime>(reader["AccountCreateDate"]);
                    account.AccountBillCycleDay = reader["BillCycleDay"] == DBNull.Value
                        ? (short)account.AccountCreateDate.Day
                        : reader.GetInt16(reader.GetOrdinal("BillCycleDay"));
                    account.AccountStatus = (AccountStatus)(short)reader["AccountStatusKey"];
                    account.AccountStatusChangeDate = Cast<DateTime>(reader["StatusChangeDate"]);
                    account.ProductCode = reader["ProductCode"] != DBNull.Value ? reader["ProductCode"].ToString() : string.Empty;
                }

                return account;
            }
            catch (SqlException ex)
            {
                Logger.Error(
                    $"AccountRepository.GetAccountByAccountIdentifierForShowcase, error occurred when retrieving account identifier {accountIdentifier} : {ex}");
                throw;
            }
        }

        public Account GetAdditionalHolderAccountByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            try
            {
                Account acc = null;
                AccountHolder ah = null;
                bool flag = false;
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountInfoByAccountIdentifier]",
                    _dataAccess.CreateConnection(), new SqlParameter
                    {
                        ParameterName = "AccountIdentifier",
                        Value = accountIdentifier.ToString()
                    }))
                {
                    while (reader.Read())
                    {

                        var routingNumber = reader["RoutingNumber"] != DBNull.Value ? reader["RoutingNumber"].ToString() : string.Empty;
                        var accountHolderIdentifier = reader["AccountHolderIdentifier"] != DBNull.Value ? reader["AccountHolderIdentifier"].ToString() : string.Empty;
                        var isPrimaryAccountHolder = reader["IsPrimaryAccountHolder"] != DBNull.Value && reader.GetBoolean(reader.GetOrdinal("IsPrimaryAccountHolder"));
                        var productCode = reader["ProductCode"].ToString();
                        var productKey = Convert.ToInt32(reader["ProductKey"]);
                        var accountHolderKey = Convert.ToInt32(reader["AccountHolderKey"]);
                        var consumerProfileIdentifier = reader["ConsumerProfileIdentifier"] != DBNull.Value ? reader["ConsumerProfileIdentifier"].ToString() : string.Empty;
                        var consumerProfileKey = Convert.ToInt32(reader["ConsumerProfileKey"]);
                        var accountHolderCure = reader["AccountHolderCureKey"] == DBNull.Value ? AccountHolderCure.Unknown : (AccountHolderCure)(Convert.ToInt32(reader["AccountHolderCureKey"]));
                        int consumerProfileTypeKey = reader.IsDBNull(reader.GetOrdinal("ConsumerProfileTypeKey")) ? 0 : reader.GetInt16(reader.GetOrdinal("ConsumerProfileTypeKey"));
                        var product = new Product(ProductCode.FromString(productCode), null, productKey, null, null, routingNumber);
                        var createDate = Cast<DateTime>(reader["AccountCreateDate"]);

                        if (flag == false)
                        {
                            acc = new Account(accountIdentifier, product, null);
                            acc.AccountKey = (long)reader["AccountKey"];
                            acc.AccountStatus = (AccountStatus)(short)reader["AccountStatusKey"];
                            acc.ProductTierKey = (int)reader["ProductTierKey"];
                            acc.UserIdentifier = consumerProfileIdentifier;
                            acc.AccountStatusChangedDateTime = (DateTime)reader["StatusChangeDate"];
                            var productTierClassKey = (ProducttierClass)(short)reader["ProductTierClassKey"];
                            acc.PhysicalCardFlag = productTierClassKey == ProducttierClass.EMV || productTierClassKey == ProducttierClass.ContactlessEmv;
                            acc.AccountCreateDate = createDate;

                            flag = true;
                        }

                        ah = new AccountHolder(consumerProfileIdentifier, AccountHolderIdentifier.FromString(accountHolderIdentifier), null, isPrimaryAccountHolder);
                        ah.AccountHolderCure = accountHolderCure;
                        ah.ConsumerProfileKey = consumerProfileKey;
                        ah.AccountHolderKey = accountHolderKey;
                        ah.ConsumerProfileTypeKey = consumerProfileTypeKey;
                        acc.AddAccountHolder(ah);

                    }

                    reader.NextResult();
                    acc.AccountStatusReasons = new List<AccountStatusReason>();

                    while (reader.Read())
                    {
                        AccountStatusReason reason = (AccountStatusReason)reader.GetInt16(1);
                        acc.AccountStatusReasons.Add(reason);
                    }

                    return acc;

                    throw new AccountNotFoundException();
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(
                    $"AccountRepository.GetByAccountIdentifier, error occurred when retrieving account identifier {accountIdentifier} : {ex}");
                throw;
            }
        }

        public void Link(AccountLink accountLink)
        {
            var input = new[]
            {
                new SqlParameter {ParameterName = "PrimaryAccountIdentifier", Value = Guid.Parse(accountLink.PrimaryAccountIdentifier)},
                new SqlParameter {ParameterName = "LinkedAccountIdentifier", Value = Guid.Parse(accountLink.LinkAccountIdentifier)},
                new SqlParameter {ParameterName = "AccountLinkTypeKey", Value = accountLink.AccountLinkType},
                new SqlParameter {ParameterName = "StartDate", Value = accountLink.StartDate},
                new SqlParameter {ParameterName = "EndDate", Value = accountLink.EndDate},
                new SqlParameter {ParameterName = "ChangeBy", Value = _userName}
            };
            try
            {
                _dataAccess.ExecuteNonQuery("[dbo].[InsAccountLink]", _dataAccess.CreateConnection(), input);
            }
            catch (SqlException ex)
            {
                Logger.Error(
                    $"AccountRepository.Link method, error occurred while trying to link account for primary account ID {accountLink.PrimaryAccountIdentifier} : {ex}");
                throw;
            }

            DeCache(new List<string>
            {
                "getLinkedAccounts_" + accountLink.PrimaryAccountIdentifier,
                "getLinkedAccounts_" + accountLink.LinkAccountIdentifier
            });

        }

        public void UpdateLinkAccount(long accountLinkKey)
        {
            var input = new[]
            {
                new SqlParameter {ParameterName = "AccountLinkKey", Value = accountLinkKey},
                new SqlParameter {ParameterName = "EndDate", Value = DateTime.Now}
            };
            try
            {
                _dataAccess.ExecuteNonQuery("[dbo].[UpdAccountLink]", _dataAccess.CreateConnection(), input);
            }
            catch (SqlException ex)
            {
                Logger.Error(
                    $"AccountRepository.UpdateLinkAccount method, error occurred while trying to update link account for accountLinkKey {accountLinkKey} : {ex}");
                throw;
            }
        }

        public Account GetByAccountIdentifier(AccountIdentifier accountIdentifier, Boolean replaceByChildAccountHolder = false)
        {
            try
            {
                var stopwatch = Stopwatch.StartNew();

                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountInfoByAccountIdentifier]",
                    _dataAccess.CreateConnection(), new SqlParameter
                    {
                        ParameterName = "AccountIdentifier",
                        Value = accountIdentifier.ToString()
                    }))
                {
                    Account account = null;
                    while (reader.Read())
                    {
                        var routingNumber = reader["RoutingNumber"] != DBNull.Value ? reader["RoutingNumber"].ToString() : string.Empty;
                        var productCode = reader["ProductCode"].ToString();
                        var productName = reader["ProductName"] != DBNull.Value ? reader["ProductName"].ToString() : string.Empty;
                        var productKey = Convert.ToInt32(reader["ProductKey"]);
                        var product = new Product(ProductCode.FromString(productCode), null, productKey, productName, null, routingNumber);
                        var consumerProfileIdentifier = reader["ConsumerProfileIdentifier"] != DBNull.Value ? reader["ConsumerProfileIdentifier"].ToString() : string.Empty;
                        if (account == null)
                        {
                            account = new Account(accountIdentifier, product, null)
                            {
                                AccountKey = (long)reader["AccountKey"],
                                AccountStatus = (AccountStatus)(short)reader["AccountStatusKey"],
                                ProductTierKey = (int)reader["ProductTierKey"],
                                UserIdentifier = consumerProfileIdentifier,
                                AccountStatusChangedDateTime = (DateTime)reader["StatusChangeDate"],
                                AccountNumber = reader["AccountNumber"] != DBNull.Value ? reader["AccountNumber"].ToString() : string.Empty,
                                AccountReferenceNumber = reader["AccountReferenceNumber"] != DBNull.Value ? reader["AccountReferenceNumber"].ToString() : string.Empty,
                                Language = reader["AccountLanguage"] != DBNull.Value ? reader["AccountLanguage"].ToString() : string.Empty,
                                FirstName = reader["FirstName"] != DBNull.Value ? reader["FirstName"].ToString() : string.Empty,
                                LastName = reader["LastName"] != DBNull.Value ? reader["LastName"].ToString() : string.Empty
                            };
                        }

                        bool IsPrimaryAccountHolder = false;
                        bool.TryParse(reader["IsPrimaryAccountHolder"].ToString(), out IsPrimaryAccountHolder);
                        if (replaceByChildAccountHolder && !IsPrimaryAccountHolder)
                        {
                            account.AccountKey = (long)reader["AccountKey"];
                            account.AccountStatus = (AccountStatus)(short)reader["AccountStatusKey"];
                            account.ProductTierKey = (int)reader["ProductTierKey"];
                            account.UserIdentifier = consumerProfileIdentifier;
                            account.AccountStatusChangedDateTime = (DateTime)reader["StatusChangeDate"];
                            account.AccountNumber = reader["AccountNumber"] != DBNull.Value ? reader["AccountNumber"].ToString() : string.Empty;
                            account.AccountReferenceNumber = reader["AccountReferenceNumber"] != DBNull.Value ? reader["AccountReferenceNumber"].ToString() : string.Empty;
                            account.Language = reader["AccountLanguage"] != DBNull.Value ? reader["AccountLanguage"].ToString() : string.Empty;
                            account.FirstName = reader["FirstName"] != DBNull.Value ? reader["FirstName"].ToString() : string.Empty;
                            account.LastName = reader["LastName"] != DBNull.Value ? reader["LastName"].ToString() : string.Empty;
                        }

                        int consumerProfileTypeKey = reader.IsDBNull(reader.GetOrdinal("ConsumerProfileTypeKey")) ? 0 : reader.GetInt16(reader.GetOrdinal("ConsumerProfileTypeKey"));
                        var consumerProfileKey = Convert.ToInt32(reader["ConsumerProfileKey"]);
                        var accountHolderIdentifier = reader["AccountHolderIdentifier"] != DBNull.Value ? reader["AccountHolderIdentifier"].ToString() : string.Empty;
                        var isPrimaryAccountHolder = reader["IsPrimaryAccountHolder"] != DBNull.Value && reader.GetBoolean(reader.GetOrdinal("IsPrimaryAccountHolder"));
                        var accountHolderCure = reader["AccountHolderCureKey"] == DBNull.Value ? AccountHolderCure.Unknown : (AccountHolderCure)(Convert.ToInt32(reader["AccountHolderCureKey"]));

                        AccountHolder ah = new AccountHolder(null, AccountHolderIdentifier.FromString(accountHolderIdentifier), null, isPrimaryAccountHolder);
                        ah.AccountHolderKey = (long)reader["AccountHolderKey"];
                        ah.AccountIdentifier = AccountIdentifier.FromGuid(Guid.Parse(reader["AccountIdentifier"].ToString()));
                        ah.AccountHolderCure = accountHolderCure;
                        ah.ConsumerProfileKey = consumerProfileKey;
                        ah.ConsumerProfileTypeKey = consumerProfileTypeKey;
                        ah.UserIdentifier = UserIdentifier.FromString(consumerProfileIdentifier);

                        account.AddAccountHolder(ah);
                    }

                    reader.NextResult();

                    if (account != null)
                    {
                        account.AccountStatusReasons = new List<AccountStatusReason>();
                        while (reader.Read())
                        {
                            AccountStatusReason reason = (AccountStatusReason)reader.GetInt16(1);
                            account.AccountStatusReasons.Add(reason);
                        }
                    }

                    // optional log stopwatch
                    stopwatch.Stop();
                    if (_requestHandlerSettings.LogStopwatch || OptionsContext.Current.ContainsKey("X-GD-LogStopwatch"))
                    {
                        Logger.Info(
                            "[{Class}.{Method}] retrieved by identifier {identifier} in {elapsedMs:F3} ms",
                            nameof(AccountRepository),
                            nameof(GetByAccountIdentifier),
                            accountIdentifier,
                            stopwatch.Elapsed.TotalMilliseconds);
                    }

                    if (account != null)
                    {
                        return account;
                    }

                    throw new AccountNotFoundException();
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(
                    $"AccountRepository.GetByAccountIdentifier, error occurred when retrieving account identifier {accountIdentifier} : {ex}");
                throw;
            }
        }

        public Tuple<Account, List<PaymentIdentifierInfo>, List<PaymentInstrumentInfo>> GetPaymentIdentifierInfoByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountInfoByAccountIdentifier]",
                    _dataAccess.CreateConnection(), new SqlParameter
                    {
                        ParameterName = "AccountIdentifier",
                        Value = accountIdentifier.ToString()
                    }))
                {
                    Account account = null;

                    var paymentIdentifierInfoList = new List<PaymentIdentifierInfo>();
                    var paymentInstrumentInfoList = new List<PaymentInstrumentInfo>();

                    while (reader.Read())
                    {
                        var routingNumber = reader["RoutingNumber"] != DBNull.Value ? reader["RoutingNumber"].ToString() : string.Empty;
                        var productCode = reader["ProductCode"].ToString();
                        var productKey = Convert.ToInt32(reader["ProductKey"]);
                        var product = new Product(ProductCode.FromString(productCode), null, productKey, null, null, routingNumber);
                        var consumerProfileIdentifier = reader["ConsumerProfileIdentifier"] != DBNull.Value ? reader["ConsumerProfileIdentifier"].ToString() : string.Empty;
                        if (account == null)
                        {
                            account = new Account(accountIdentifier, product, null)
                            {
                                AccountKey = (long)reader["AccountKey"],
                                AccountStatus = (AccountStatus)(short)reader["AccountStatusKey"],
                                ProductTierKey = (int)reader["ProductTierKey"],
                                UserIdentifier = consumerProfileIdentifier,
                                AccountStatusChangedDateTime = (DateTime)reader["StatusChangeDate"]
                            };
                        }

                        var consumerProfileKey = Convert.ToInt32(reader["ConsumerProfileKey"]);
                        var accountHolderIdentifier = reader["AccountHolderIdentifier"] != DBNull.Value ? reader["AccountHolderIdentifier"].ToString() : string.Empty;
                        var isPrimaryAccountHolder = reader["IsPrimaryAccountHolder"] != DBNull.Value && reader.GetBoolean(reader.GetOrdinal("IsPrimaryAccountHolder"));
                        var accountHolderCure = reader["AccountHolderCureKey"] == DBNull.Value ? AccountHolderCure.Unknown : (AccountHolderCure)(Convert.ToInt32(reader["AccountHolderCureKey"]));

                        AccountHolder ah = new AccountHolder(null, AccountHolderIdentifier.FromString(accountHolderIdentifier), null, isPrimaryAccountHolder);
                        ah.AccountHolderKey = (long)reader["AccountHolderKey"];
                        ah.AccountIdentifier = AccountIdentifier.FromGuid(Guid.Parse(reader["AccountIdentifier"].ToString()));
                        ah.AccountHolderCure = accountHolderCure;
                        ah.ConsumerProfileKey = consumerProfileKey;
                        account.AddAccountHolder(ah);


                        PaymentIdentifierInfo paymentIdentifierInfo = new PaymentIdentifierInfo();
                        if (reader["PaymentIdentifierKey"] != DBNull.Value)
                            paymentIdentifierInfo.PaymentIdentifierKey = (long)reader["PaymentIdentifierKey"];

                        if (reader["PaymentIdentifierStatusKey"] != DBNull.Value && Enum.TryParse(reader["PaymentIdentifierStatusKey"].ToString(),
                            out PaymentIdentifierStatus paymentIdentifierStatus))
                        {
                            paymentIdentifierInfo.PaymentIdentifierStatus = paymentIdentifierStatus;
                        }

                        if (reader["PaymentIdentifier"] != DBNull.Value)
                        {
                            paymentIdentifierInfo.PaymentIdentifierIdentifier = Guid.Parse(reader["PaymentIdentifier"].ToString());
                        }
                        paymentIdentifierInfo.IsTemp = reader["IsTemp"] == DBNull.Value ? false : Convert.ToBoolean(reader["IsTemp"].ToString());

                        paymentIdentifierInfoList.Add(paymentIdentifierInfo);
                    }

                    reader.NextResult();

                    if (account != null)
                    {
                        account.AccountStatusReasons = new List<AccountStatusReason>();
                        while (reader.Read())
                        {
                            AccountStatusReason reason = (AccountStatusReason)reader.GetInt16(1);
                            account.AccountStatusReasons.Add(reason);
                        }
                    }

                    reader.NextResult();

                    while (reader.Read())
                    {
                        var paymentInstrumentInfo = new PaymentInstrumentInfo();

                        paymentInstrumentInfo.PaymentInstrumentIdentifier = Guid.Parse(reader["PaymentInstrumentIdentifier"].ToString());

                        if (reader["PaymentInstrumentKey"] != DBNull.Value)
                            paymentInstrumentInfo.PaymentInstrumentKey = Convert.ToInt64(reader["PaymentInstrumentKey"]);

                        if (reader["PaymentIdentifierKey"] != DBNull.Value)
                            paymentInstrumentInfo.PaymentIdentifierKey = (long)reader["PaymentIdentifierKey"];

                        if (Enum.TryParse(reader["PaymentInstrumentStatusKey"].ToString(),
                            out PaymentInstrumentStatus paymentInstrumentStatus))
                        {
                            paymentInstrumentInfo.PaymentInstrumentStatus = paymentInstrumentStatus;
                        }

                        if (Enum.TryParse(reader["PaymentInstrumentTypeKey"].ToString(),
                            out Shared.Common.Core.CoreApi.Contract.Data.PaymentInstrumentType paymentInstrumentType))
                        {
                            paymentInstrumentInfo.PaymentInstrumentType = paymentInstrumentType;
                        }
                        paymentInstrumentInfoList.Add(paymentInstrumentInfo);
                    }

                    return new Tuple<Account, List<PaymentIdentifierInfo>, List<PaymentInstrumentInfo>>(account, paymentIdentifierInfoList, paymentInstrumentInfoList);
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(
                    $"AccountRepository.GetByAccountIdentifier, error occurred when retrieving account identifier {accountIdentifier} : {ex}");
                throw;
            }
        }

        public Account GetByAccountIdentifierWithPrimaryUser(AccountIdentifier accountIdentifier, ref string primaryUserFirstName, ref string primaryUserLastName)
        {
            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountByAccountIdentifier]",
                    _dataAccess.CreateConnection(), new SqlParameter
                    {
                        ParameterName = "AccountIdentifier",
                        Value = accountIdentifier.ToString()
                    }))
                {
                    if (reader.Read())
                    {
                        string routingNumber = reader["RoutingNumber"] != DBNull.Value ? reader["RoutingNumber"].ToString() : string.Empty;
                        string accountHolderIdentifier = reader["AccountHolderIdentifier"] != DBNull.Value ? reader["AccountHolderIdentifier"].ToString() : string.Empty;
                        bool isPrimaryAccountHolder = reader["IsPrimaryAccountHolder"] != DBNull.Value && reader.GetBoolean(reader.GetOrdinal("IsPrimaryAccountHolder"));

                        if (isPrimaryAccountHolder)
                        {
                            string firstName = reader["FirstName"].ToString();
                            string lastName = reader["LastName"].ToString();
                            primaryUserFirstName = firstName;
                            primaryUserLastName = lastName;
                        }

                        var acc = new Account(
                            accountIdentifier,
                            new Product(ProductCode.FromString("7750"), ProgramCode.FromString("stash"), 3, null, "1010", routingNumber),
                            AccountBalanceIdentifier.FromString(Guid.NewGuid().ToString("D"))
                        )
                        {
                            AccountStatus = (AccountStatus)(short)reader["AccountStatusKey"],
                            ProductTierKey = reader["ProductTierKey"] != DBNull.Value ? (int)reader["ProductTierKey"] : 0,
                            AccountToken = reader["AccountToken"] != DBNull.Value ? reader["AccountToken"].ToString() : string.Empty
                        };

                        acc.AddAccountHolder(new AccountHolder(null, AccountHolderIdentifier.FromString(accountHolderIdentifier), null, isPrimaryAccountHolder));
                        return acc;
                    }

                    throw new AccountNotFoundException();
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(
                    $"AccountRepository.GetByAccountIdentifier, error occurred when retrieving account identifier {accountIdentifier} : {ex}");
                throw;
            }
        }
        public AccountStatusAndBalances GetAccountStatusAndBalancesByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            var verificationParams = new[]
            {
                new SqlParameter
                {
                    ParameterName = "AccountIdentifier",
                    Value = accountIdentifier.ToGuid(),
                    SqlDbType = SqlDbType.UniqueIdentifier
                }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountStatusInfoByAccountIdentifier]",
                _dataAccess.CreateConnection(), verificationParams))
            {
                AccountStatus? accountStatus = null;
                HashSet<AccountStatusReason> accountStatusReasons = new HashSet<AccountStatusReason>();
                Dictionary<Guid, AccountBalance> purses = new Dictionary<Guid, AccountBalance>();
                Dictionary<Guid, AccountHolder> accountHolders = new Dictionary<Guid, AccountHolder>();
                string programCode = String.Empty;

                while (reader.Read())
                {
                    accountStatus = reader["AccountStatusKey"] == DBNull.Value
                        ? (AccountStatus?)null
                        : (AccountStatus)(short)reader["AccountStatusKey"];
                    programCode = reader["ProgramCode"].ToString();

                    Guid consumerProfileIdentifier = reader["ConsumerProfileIdentifier"] == DBNull.Value
                        ? Guid.Empty
                        : (Guid)reader["ConsumerProfileIdentifier"];

                    //if (reader["AccountHolderCureKey"] != DBNull.Value)
                    var accHolder = new AccountHolder(accountIdentifier,
                        UserIdentifier.FromString(consumerProfileIdentifier.ToString()), null, null, false, 0)
                    {
                        AccountHolderCure = reader["AccountHolderCureKey"] == DBNull.Value
                            ? default(AccountHolderCure)
                            : (AccountHolderCure)Enum.Parse(typeof(AccountHolderCure),
                                reader["AccountHolderCureKey"].ToString())
                    };
                    accountHolders[consumerProfileIdentifier] = accHolder;

                    accHolder.PeerTransferAcceptPreference = reader["IsTransferAutoAccept"] != DBNull.Value && bool.Parse(reader["IsTransferAutoAccept"].ToString());
                    accHolder.IsPrimary = bool.Parse(reader["IsPrimaryAccountHolder"].ToString());
                    accHolder.ConsumerProfileKey = reader["ConsumerProfileKey"] == DBNull.Value
                        ? 0
                        : (long)reader["ConsumerProfileKey"];
                }

                reader.NextResult();
                while (reader.Read())
                {
                    Guid currentAccountBalanceIdentifier = reader["AccountBalanceIdentifier"] == DBNull.Value
                        ? Guid.Empty
                        : (Guid)reader["AccountBalanceIdentifier"];

                    if (currentAccountBalanceIdentifier != Guid.Empty && !purses.ContainsKey(currentAccountBalanceIdentifier))
                    {
                        var accountBanlanceTypeKey = (Int16)reader["AccountBalanceTypeKey"];
                        bool isPrimary = accountBanlanceTypeKey == 1;
                        bool isHolding = accountBanlanceTypeKey == 3;
                        //if(isHolding) continue; // "Force Purses money around" need all purses while updating status to spend down.
                        string userDescription = reader["UserDescription"] == DBNull.Value ? "" : reader["UserDescription"].ToString();
                        var purseStatusKey = reader["AccountBalanceStatusKey"] == DBNull.Value ? 1 : (short)reader["AccountBalanceStatusKey"];
                        var purseStatus = (PurseStatus)purseStatusKey;
                        var purseType = (PurseType)accountBanlanceTypeKey;
                        var goalAmount = reader["GoalAmount"] == DBNull.Value ? 0 : (decimal)reader["GoalAmount"];
                        var newPurse = new AccountBalance(AccountBalanceIdentifier.FromGuid(currentAccountBalanceIdentifier), isPrimary,
                            isHolding, userDescription, status: purseStatus, goalAmount: goalAmount, purseType: purseType);
                        var dtLedger = reader["LedgerBalanceAsOfDate"] != DBNull.Value ? (DateTime)reader["LedgerBalanceAsOfDate"] : DateTime.UtcNow;
                        var dtAvailable = reader["AvailableBalanceAsOfDate"] != DBNull.Value ? (DateTime)reader["AvailableBalanceAsOfDate"] : DateTime.UtcNow;

                        newPurse.SetCurrentBalance((decimal)reader["LedgerBalance"], dtLedger);
                        newPurse.SetAvailableBalance((decimal)reader["AvailableBalance"], dtAvailable);
                        newPurse.IsRoundUp = reader["IsRoundUp"] != DBNull.Value && (bool)reader["IsRoundUp"];

                        purses[currentAccountBalanceIdentifier] = newPurse;
                    }
                }

                reader.NextResult();
                while (reader.Read())
                {
                    if (reader["AccountStatusReasonKey"] != DBNull.Value)
                        accountStatusReasons.Add((AccountStatusReason)(short)reader["AccountStatusReasonKey"]);
                }

                if (!accountStatus.HasValue)
                    throw new AccountNotFoundException("Could not obtain AccountStatus.");

                return new AccountStatusAndBalances(accountStatus.Value, accountStatusReasons, purses.Values,
                    accountHolders.Values, programCode);
            }
        }

        public Tuple<Account, string> GetAccountByPaymentIdentifierProxy(string piProxy)
        {
            string trimmedProxy = piProxy?.Trim();
            if (string.IsNullOrEmpty(trimmedProxy))
                throw new Exception("Proxy cannot be null nor empty");

            Tuple<Account, string> accountInfo = null;

            var parameters = new[]
            {
                new SqlParameter {ParameterName = "PaymentIdentifierProxy", Value = trimmedProxy}
            };
            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountByPaymentIdentifierProxy]",
                _dataAccess.CreateConnection(), parameters))
            {
                if (reader.Read())
                {
                    string accountIdentifier = reader["accountIdentifier"] == DBNull.Value
                        ? null
                        : reader["accountIdentifier"].ToString();
                    string consumerProfileIdentifier = reader["consumerProfileIdentifier"] == DBNull.Value
                        ? null
                        : reader["consumerProfileIdentifier"].ToString();

                    if (accountIdentifier == null || consumerProfileIdentifier == null)
                        throw new AccountNotFoundException($"No account was found for payment identifier proxy {piProxy}");

                    Account account = new Account(accountIdentifier)
                    {
                        AccountStatus = (AccountStatus)(short)reader["AccountStatusKey"]
                    };

                    accountInfo = new Tuple<Account, string>(account, consumerProfileIdentifier);
                }

                if (accountInfo == null)
                    throw new AccountNotFoundException($"No account was found for payment identifier proxy {piProxy}");

                return accountInfo;
            }
        }

        public Dictionary<string, List<Account>> GetAccountByPaymentIdentifierProxyList(List<string> proxyList)
        {
            var proxyDic = new Dictionary<string, List<Account>>();
            var dt = new DataTable();
            dt.Columns.Add("PaymentIdentifierProxy", typeof(string));
            foreach (var proxy in proxyList)
            {
                var row = dt.NewRow();
                row["PaymentIdentifierProxy"] = proxy;
                dt.Rows.Add(row);
            }

            var parameters = new[]
            {
                new SqlParameter {ParameterName = "@typePaymentIdentifierProxys", Value = dt, SqlDbType = SqlDbType.Structured, TypeName = "[dbo].[typePaymentIdentifierProxys]"}
            };
            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountByPaymentIdentifierProxys]",
                       _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    var proxy = reader["PaymentIdentifierProxy"] == DBNull.Value
                        ? null
                        : reader["PaymentIdentifierProxy"].ToString();
                    if (proxy == null)
                    {
                        continue;
                    }
                    string accountIdentifier = reader["accountIdentifier"] == DBNull.Value
                        ? null
                        : reader["accountIdentifier"].ToString();
                    string consumerProfileIdentifier = reader["consumerProfileIdentifier"] == DBNull.Value
                        ? null
                        : reader["consumerProfileIdentifier"].ToString();

                    if (accountIdentifier == null || consumerProfileIdentifier == null)
                        throw new AccountNotFoundException($"No account was found for payment identifier proxy {proxy}");

                    Account account = new Account(accountIdentifier)
                    {
                        AccountStatus = (AccountStatus)(short)reader["AccountStatusKey"],
                        PaymentIdentifierProxy = proxy
                    };
                    if (proxyDic.ContainsKey(consumerProfileIdentifier))
                    {
                        var accountList = proxyDic[consumerProfileIdentifier];
                        accountList.Add(account);
                    }
                    else
                    {
                        var accountList = new List<Account>()
                        {
                            account
                        };
                        proxyDic.Add(consumerProfileIdentifier, accountList);
                    }
                }

                return proxyDic;

            }
        }

        /// <summary>
        /// GetIdvInfoByAccountIdentifierUserIdentifier
        /// </summary>
        /// <param name="createVerifyRequest"></param>
        /// <param name="activityType"></param>
        /// <returns></returns>
        public CreateVerifyRequest GetIdvInfoByAccountIdentifierUserIdentifier(CreateVerifyRequest createVerifyRequest, VerificationActivityType activityType, bool isSecondCip = false)
        {
            SqlParameter[] parameters;
            string statusKey = string.Empty;
            string verificationRequestIdentifier = string.Empty;
            var ssnToken = createVerifyRequest?.IdentityRequest?.SSNToken;
            var last4ssn = createVerifyRequest?.IdentityRequest?.Last4SSN;

            createVerifyRequest.IdentityRequest = new CreateRiskRequest();

            try
            {
                parameters = new[]
                {
                    new SqlParameter
                    {
                        ParameterName = "AccountIdentifier",
                        Value = Guid.Parse(createVerifyRequest.AccountIdentifier)
                    },
                    new SqlParameter
                    {
                        ParameterName = "ConsumerProfileIdentifier",
                        Value = Guid.Parse(createVerifyRequest.UserIdentifier)
                    },
                    new SqlParameter
                    {
                        ParameterName = "VerificationActivityTypeKey",
                        Value = activityType
                    }
                };
            }
            catch (Exception)
            {
                throw new AccountHolderNotFoundException();
            }

            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetVerificationRequestByAccountHolderIdentifier]",
                    _dataAccess.CreateConnectionWithColumnEncryption(), parameters))
                {
                    while (reader.Read())
                    {
                        statusKey = reader["ActivityStatusKey"] == DBNull.Value
                            ? null
                            : reader["ActivityStatusKey"].ToString();

                        if (statusKey == "1" || string.IsNullOrEmpty(statusKey) || !string.IsNullOrEmpty(ssnToken) || isSecondCip)
                        {
                            verificationRequestIdentifier = reader["VerificationRequestIdentifier"] == DBNull.Value ? null : reader.GetGuid(reader.GetOrdinal("VerificationRequestIdentifier")).ToString();
                            createVerifyRequest.VerificationRequestKey = reader.GetInt64(reader.GetOrdinal("VerificationRequestKey"));
                            createVerifyRequest.TriggerType = (TriggerType)(short)reader["VerificationTriggerTypeKey"];

                        }
                    }
                }

                AccountPrimaryConsumerProfile accountPrimaryConsumerProfile = GetAccountPrimaryConsumerProfileAnyToken(Guid.Parse(createVerifyRequest.AccountIdentifier), Guid.Parse(createVerifyRequest.UserIdentifier));

                if (accountPrimaryConsumerProfile != null)
                {
                    if (statusKey == "1" || string.IsNullOrEmpty(statusKey) || !string.IsNullOrEmpty(ssnToken) || isSecondCip)
                    {
                        createVerifyRequest.IdentityRequest.FirstName = accountPrimaryConsumerProfile.FirstName;
                        createVerifyRequest.IdentityRequest.MiddleName = accountPrimaryConsumerProfile.MiddleName;
                        createVerifyRequest.IdentityRequest.LastName = accountPrimaryConsumerProfile.LastName;
                        createVerifyRequest.IdentityRequest.Last4SSN = !string.IsNullOrEmpty(ssnToken)
                            ? last4ssn  // new ssn's last 4
                            : accountPrimaryConsumerProfile.Last4SSN;
                        createVerifyRequest.IdentityRequest.DateOfBirth = accountPrimaryConsumerProfile.DOB;
                        createVerifyRequest.IdentityRequest.Address1 = accountPrimaryConsumerProfile.Address1;
                        createVerifyRequest.IdentityRequest.Address2 = accountPrimaryConsumerProfile.Address2;
                        createVerifyRequest.IdentityRequest.City = accountPrimaryConsumerProfile.City;
                        createVerifyRequest.IdentityRequest.State = accountPrimaryConsumerProfile.State;
                        createVerifyRequest.IdentityRequest.ZipCode = accountPrimaryConsumerProfile.ZipCode;
                        createVerifyRequest.IdentityRequest.Country = accountPrimaryConsumerProfile.Country;
                        createVerifyRequest.IdentityRequest.Email = accountPrimaryConsumerProfile.Email;
                        createVerifyRequest.IdentityRequest.PhoneNumber = accountPrimaryConsumerProfile.PhoneNumber;
                        createVerifyRequest.AccountHolderKey = accountPrimaryConsumerProfile.AccountHolderKey;
                        createVerifyRequest.AccountKey = accountPrimaryConsumerProfile.AccountKey;
                        createVerifyRequest.ConsumerProfileKey = accountPrimaryConsumerProfile.ConsumerProfileKey;
                        createVerifyRequest.ProductKey = accountPrimaryConsumerProfile.ProductKey;
                        createVerifyRequest.ProductCode = accountPrimaryConsumerProfile.ProductCode;
                        createVerifyRequest.IdentityRequest.ExternalIdentifiers = new Dictionary<string, object>
                                {
                                    { "AccountIdentifier", createVerifyRequest.AccountIdentifier},
                                    { "VerificationRequestIdentifier", verificationRequestIdentifier},
                                    { "AccountHolderIdentifier", accountPrimaryConsumerProfile.AccountHolderIdentifier }
                                };

                        createVerifyRequest.IdentityRequest.Program = accountPrimaryConsumerProfile.ProgramCode;

                        if (!string.IsNullOrEmpty(ssnToken))
                            createVerifyRequest.IdentityRequest.SSNToken = ssnToken;
                        // if it is non USA and pls we dont want to send the identity token to fraud because its not a ssn
                        // if the contry code is null or empty it is the default and usually USA
                        else if (string.Compare(createVerifyRequest.IdentityRequest.Program, "pls", true) == 0)
                        {
                            createVerifyRequest.IdentityRequest.IdentityType = accountPrimaryConsumerProfile.IdentityType.ToString();
                            createVerifyRequest.IdentityRequest.IdentityToken = accountPrimaryConsumerProfile.IdentityToken;
                            createVerifyRequest.IdentityRequest.IdentityCountryCode = accountPrimaryConsumerProfile.IdentityCountryCode;
                        }
                        else
                            createVerifyRequest.IdentityRequest.SSNToken = accountPrimaryConsumerProfile.IdentityToken;
                    }

                    createVerifyRequest.AccountHolderCureKey = (int)accountPrimaryConsumerProfile.AccountHolderCure;

                    createVerifyRequest.PaymentIdentifierStatus = accountPrimaryConsumerProfile.PaymentIdentifierStatus;
                    createVerifyRequest.PaymentIdentifierKey = accountPrimaryConsumerProfile.PaymentIdentifierKey;

                    return createVerifyRequest;
                }
                else // account not found
                    throw new AccountHolderNotFoundException();
            }
            catch (Exception ex)
            {
                Logger.Error(
                    $"AccountRepository.GetIdvInfoByAccountIdentifierUserIdentifier, error occurred when retrieving account identifier {createVerifyRequest.AccountIdentifier} : {ex}");
                throw new AccountHolderNotFoundException();
            }
        }

        /// <summary>
        /// VerifyAccountLimitByProduct
        /// </summary>
        /// <param name="ssnToken"></param>
        /// <param name="productCode"></param>
        /// <param name="accountCure"></param>
        public AccountLimit VerifyAccountLimitByProduct(string ssnToken, string productCode, string accountCure)
        {
            int xActiveAccountsCount = 0;
            int xActiveAccountsOverLifetimeCount = 0;
            int xCreatedAccountsOverLifetimeCount = 0;
            var accountLimit = new AccountLimit();

            var parameters = new[]
            {
                new SqlParameter {ParameterName = "IdentityToken", Value = ssnToken},
                new SqlParameter {ParameterName = "ProductCode", Value = productCode},
                new SqlParameter {ParameterName = "IdentityType", Value = 1}
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountLimitByProduct]",
                _dataAccess.CreateConnectionWithColumnEncryption(), parameters))
            {
                if (reader.Read())
                    xActiveAccountsCount = Convert.ToInt32(reader["RestrictLockWithCure"]);

                reader.NextResult();

                if (xActiveAccountsCount == 0)
                {
                    var accountLimitList = new List<AccountLimit>();
                    while (reader.Read())
                    {
                        xActiveAccountsCount = Convert.ToInt32(reader["AccountKey"]);
                        accountLimit.AccountCreatedDate = Convert.ToDateTime(reader["CreateDate"].ToString());
                        accountLimit.AccountIdentifier = Guid.Parse(reader["AccountIdentifier"].ToString());

                        accountLimitList.Add(accountLimit);
                    }

                    if (accountLimitList.Count >= Configuration.Configuration.Current.ActiveAccounts)
                    {
                        Logger.Debug(
                            $"AccountRepository.VerifyAccountLimitByProduct, Number of active accounts are {xActiveAccountsCount}.");

                        accountLimit = accountLimitList.FirstOrDefault(s =>
                            s.AccountCreatedDate == accountLimitList.Max(x => x.AccountCreatedDate));
                        accountLimit.ResponseCode = "260";

                        if (accountCure == "kyc1")
                            throw new RequestHandlerException(2, 60, "Number of Active Accounts Exceeded.");
                        return accountLimit;
                    }
                }

                reader.NextResult();

                if (reader.Read())
                    xActiveAccountsOverLifetimeCount = Convert.ToInt32(reader["PreviousHealthy"]);

                reader.NextResult();

                if (reader.Read())
                    xCreatedAccountsOverLifetimeCount = Convert.ToInt32(reader["Total"]);


                if (xActiveAccountsCount >= Configuration.Configuration.Current.ActiveAccounts)
                {
                    Logger.Debug(
                        $"AccountRepository.VerifyAccountLimitByProduct, Number of active accounts are {xActiveAccountsCount}.");
                    throw new RequestHandlerException(2, 60, "Number of Active Accounts Exceeded.");
                }

                if (xActiveAccountsOverLifetimeCount >= Configuration.Configuration.Current.AccountsActiveOverLifeTime)
                {
                    Logger.Debug(
                        $"AccountRepository.VerifyAccountLimitByProduct, Number of accounts activated over the lifetime are {xActiveAccountsOverLifetimeCount}.");
                    throw new RequestHandlerException(2, 61, "Number of Activated Accounts over Lifetime exceeded.");
                }

                if (xCreatedAccountsOverLifetimeCount >= Configuration.Configuration.Current.AccountsCreatedOverLifeTime)
                {
                    Logger.Debug(
                        $"AccountRepository.VerifyAccountLimitByProduct, Number of accounts created over the lifetime are {xCreatedAccountsOverLifetimeCount}.");
                    throw new RequestHandlerException(2, 62, "Number of Enrollment Attempts over Lifetime exceeded.");
                }
            }

            Logger.Debug("AccountRepository.VerifyAccountLimitByProduct, Account limits are successfully verified.");

            return null;
        }

        public void SetBillingCycleDate(string accountIdentifier, int billingCycleDay, DateTime activationDate, DateTime firstBillCycleDate)
        {
            var setBillingCycleDateParams = new[]
            {
                new SqlParameter {ParameterName = "AccountIndentifier", Value = Guid.Parse(accountIdentifier)},
                new SqlParameter {ParameterName = "BillCycleDay", Value = billingCycleDay},
                new SqlParameter {ParameterName = "ActivationDate", Value = activationDate},
                new SqlParameter {ParameterName = "FirstBillCycleDate", Value = firstBillCycleDate.Date}
            };
            try
            {
                _dataAccess.ExecuteNonQuery("[dbo].[InsAccountBillCycle]", _dataAccess.CreateConnection(),
                    setBillingCycleDateParams);
            }
            catch (SqlException ex)
            {
                throw new SqlValidationException("Bill Cycle Day already exists", ex);
            }
        }


        public AccountBillCycleInfo GetAccountBillCycle(string accountIdentifier, long accountKey = 0)
        {
            AccountBillCycleInfo accountBillCycleInfo = null;
            var param = new[]
            {
                new SqlParameter {ParameterName = "AccountKey", Value = accountKey},
                new SqlParameter {ParameterName = "AccountIdentifier", Value = Guid.Parse(accountIdentifier)}
            };
            using (var reader = _dataAccess.ExecuteReader("[dbo].GetAccountBillCycle", _dataAccess.CreateConnection(), param))
            {
                while (reader.Read())
                {
                    accountBillCycleInfo = new AccountBillCycleInfo
                    {
                        AccountKey = reader.GetInt64(reader.GetOrdinal("AccountKey")),
                        AccountIdentifier = reader.GetGuid(reader.GetOrdinal("AccountIdentifier")),
                        BillCycleDay = reader["BillCycleDay"] == DBNull.Value ? (short)0 : reader.GetInt16(reader.GetOrdinal("BillCycleDay"))
                    };
                }
            }
            return accountBillCycleInfo;
        }

        public AccountPrimaryConsumerProfile GetAccountConsumerProfileByTokenizedPan(string tokenizedPan)
        {
            try
            {
                List<AccountPrimaryConsumerProfile> consumerProfiles = new List<AccountPrimaryConsumerProfile>();


                var param = new[]
                {
                    new SqlParameter {ParameterName = "TokenizedPAN", Value = tokenizedPan},
                    new SqlParameter {ParameterName = "ReturnOnlyPrimary", Value = 0}
                };
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountInfoByTokenizedPAN]",
                           _dataAccess.CreateConnection(), param))
                {
                    while (reader.Read())
                    {
                        AccountPrimaryConsumerProfile accountPrimaryConsumerProfile = new AccountPrimaryConsumerProfile();
                        accountPrimaryConsumerProfile.AccountIdentifier = reader["AccountIdentifier"] == DBNull.Value ? Guid.Empty : AccountIdentifier.FromGuid(Guid.Parse(reader["AccountIdentifier"].ToString()));
                        accountPrimaryConsumerProfile.FirstName = reader["FirstName"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("FirstName"));
                        accountPrimaryConsumerProfile.LastName = reader["LastName"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("LastName"));
                        accountPrimaryConsumerProfile.PhoneNumber = reader["PhoneNumber"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("PhoneNumber"));
                        //accountPrimaryConsumerProfile.ProgramCode = reader["ProgramCode"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("ProgramCode"));
                        accountPrimaryConsumerProfile.ProductKey = reader["ProductKey"] == DBNull.Value ? 0 : reader.GetInt32(reader.GetOrdinal("ProductKey"));
                        accountPrimaryConsumerProfile.Email = reader["Email"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Email"));
                        //accountPrimaryConsumerProfile.AccountCreateDate = reader.GetDateTime(reader.GetOrdinal("CreateDate"));
                        accountPrimaryConsumerProfile.PaymentIdentifierProxy = reader["PaymentIdentifierProxy"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("PaymentIdentifierProxy"));
                        accountPrimaryConsumerProfile.AccountStatus = (AccountStatus)Convert.ToInt32(reader["AccountStatusKey"]);
                        accountPrimaryConsumerProfile.PaymentIdentifier = reader["PaymentIdentifier"] == DBNull.Value ? null : reader.GetGuid(reader.GetOrdinal("PaymentIdentifier")).ToString();
                        accountPrimaryConsumerProfile.PaymentInstrumentIdentifier = reader["PaymentInstrumentIdentifier"] == DBNull.Value ? null : reader.GetGuid(reader.GetOrdinal("PaymentInstrumentIdentifier")).ToString();
                        accountPrimaryConsumerProfile.IsPrimaryAccountHolder = reader["IsPrimaryAccountHolder"] != DBNull.Value && (bool)reader["IsPrimaryAccountHolder"];
                        accountPrimaryConsumerProfile.TokenizedPAN = reader["TokenizedPAN"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("TokenizedPAN"));
                        accountPrimaryConsumerProfile.ConsumerProfileIdentifier = reader["ConsumerProfileIdentifier"] == DBNull.Value ? null : reader.GetGuid(reader.GetOrdinal("ConsumerProfileIdentifier")).ToString();
                        consumerProfiles.Add(accountPrimaryConsumerProfile);
                    }
                }

                var result = consumerProfiles.Where(x => x.TokenizedPAN.Equals(tokenizedPan, StringComparison.OrdinalIgnoreCase)).OrderByDescending(l => l.IsPrimaryAccountHolder).FirstOrDefault();
                return result;
            }
            catch (SqlException ex)
            {
                Logger.Error(ex, $"AccountRepository.GetAccountConsumerProfileByTokenizedPan(string tokenizedPan): error occurred when retrieving profile" +
                    $" by tokenizedPan : {ex}");
                throw new Exception("An error occurred trying to retrieve consumer profile: " + ex.Message);
            }
        }

        /// <summary>
        /// GetAccountPrimaryConsumerProfile
        /// </summary>
        /// <param name="accountIdentifier"></param>
        /// <returns></returns>
        public AccountPrimaryConsumerProfile GetAccountPrimaryConsumerProfile(AccountIdentifier accountIdentifier)
        {
            // considers only SSN, unless there is no SSN and only ITIN or Matricula ID
            return GetAccountPrimaryConsumerProfile((Guid)accountIdentifier, null, IdentityType.SSN);
        }

        /// <summary>
        /// GetAccountPrimaryConsumerProfile
        /// </summary>
        /// <param name="accountIdentifier"></param>
        /// <returns></returns>
        public AccountPrimaryConsumerProfile GetAccountPrimaryConsumerProfile(AccountIdentifier accountIdentifier, Guid userIdentifier)
        {
            // considers only SSN, unless there is no SSN and only ITIN or Matricula ID
            return GetAccountPrimaryConsumerProfile((Guid)accountIdentifier, userIdentifier, IdentityType.SSN);
        }

        /// <summary>
        /// GetAccountPrimaryConsumerProfile
        /// </summary>
        /// <param name="accountIdentifier"></param>
        /// <returns></returns>
        [ExcludeFromCodeCoverage(Justification = "Db access")]
        public AccountPrimaryConsumerProfile GetAccountPrimaryConsumerProfileAnyToken(AccountIdentifier accountIdentifier, Guid userIdentifier)
        {
            var parameters = new[]
{
               new SqlParameter {ParameterName = "AccountIdentifier", Value = (accountIdentifier!=null)?(object)accountIdentifier.ToString():DBNull.Value}
            };
            List<UserProfile> users = new List<UserProfile>();
            var identityCountryCode = string.Empty;
            Guid accountHolderId;
            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].GetConsumerProfile",
                    _dataAccess.CreateConnection(), parameters))
                {
                    long key = 0;
                    while (reader.Read())
                    {
                        UserProfile userProfile = new UserProfile
                        {
                            UserIdentifier = UserIdentifier.FromString(reader["ConsumerProfileIdentifier"].ToString()),
                            AccountHolderIdentifier = reader.GetGuid(reader.GetOrdinal("AccountHolderIdentifier")).ToString()
                        };
                        key = Convert.ToInt64(reader["ProductKey"]);
                        var consumerProfileTypeKey = Int64.Parse(reader["ConsumerProfileTypeKey"].ToString());
                        if (consumerProfileTypeKey == (long)ConsumerProfileType.BeneficialOwner && (key == 61 || key == 64))
                        {
                            users.Add(userProfile);
                        }
                    }

                    // Read Identity CountryCode 
                    try
                    {
                        reader.NextResult();
                        reader.NextResult();
                        reader.NextResult();
                        reader.NextResult();
                        while (reader.Read())
                        {
                            identityCountryCode = reader["IdentityAttributeValue"] == DBNull.Value 
                                ? string.Empty : reader.GetString(reader.GetOrdinal("IdentityAttributeValue"));
                        }
                    }
                    catch (Exception e)
                    {
                        Logger.Error(e,
                            "Could not read IdentityCountryCode for Account {accountIdentifier}", accountIdentifier);
                    }
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(ex, 
                    $"Error occurred when retrieving profile for account identifier {accountIdentifier} : {ex}");
                throw new Exception("An error occurred trying to retrieve consumer profile: " + ex.Message);
            }
            if (users != null && users.Count != 0)
            {
                var user = users.Where(x => x.UserIdentifier.ToString() == userIdentifier.ToString()).FirstOrDefault();
                if (user != null)
                {
                    accountHolderId = Guid.Parse(user.AccountHolderIdentifier);
                    return GetAccountBeneficialOwner((Guid)accountIdentifier, userIdentifier, accountHolderId, 0);
                }
            }
            // gets either SSN, ITIN or Matricula ID token 
            var profile = GetAccountPrimaryConsumerProfile((Guid)accountIdentifier, userIdentifier, 0);
            profile.IdentityCountryCode = identityCountryCode;
            return profile;
        }

        public string GetAccountPrimaryPhoneNumber(AccountIdentifier accountIdentifier)
        {
            var consumerProfile = default(ConsumerProfile);
            var phoneNumber = string.Empty;
            var parameters = new[]
{
               new SqlParameter {ParameterName = "AccountIdentifier", Value = (accountIdentifier!=null)?(object)accountIdentifier.ToString():DBNull.Value}
            };
            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].GetConsumerProfile",
                    _dataAccess.CreateConnection(), parameters))
                {
                    long key = 0;
                    while (reader.Read())
                    {
                        consumerProfile = new ConsumerProfile
                        {
                            ConsumerProfileKey = Convert.ToInt64(reader["ConsumerProfileKey"]),
                        };
                    }
                    if (!reader.NextResult())
                    {
                        return phoneNumber;
                    }

                    if (!reader.NextResult())
                    {
                        return phoneNumber;
                    }
                    if (!reader.NextResult())
                    {
                        return phoneNumber;
                    }
                    while (reader.Read())
                    {
                        phoneNumber = Regex.Replace(Convert.ToString(reader["PhoneNumber"]), @"[^\d]", "");
                    }
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(ex, 
                    $"Error occurred when GetAccountPrimaryPhoneNumber for account identifier {accountIdentifier} : {ex}");
                throw new Exception("An error occurred trying to GetAccountPrimaryPhoneNumber: " + ex.Message);
            }
            return phoneNumber;
        }


        public AccountPrimaryConsumerProfile GetAccountPrimaryConsumerProfileAnyTokenWithMultipleAddresses(AccountIdentifier accountIdentifier, Guid userIdentifier)
        {
            var parameters = new[]
{
               new SqlParameter {ParameterName = "AccountIdentifier", Value = (accountIdentifier!=null)?(object)accountIdentifier.ToString():DBNull.Value}
            };
            List<UserProfile> users = new List<UserProfile>();
            Guid accountHolderId;
            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].GetConsumerProfile",
                    _dataAccess.CreateConnection(), parameters))
                {
                    long key = 0;
                    while (reader.Read())
                    {
                        UserProfile userProfile = new UserProfile
                        {
                            UserIdentifier = UserIdentifier.FromString(reader["ConsumerProfileIdentifier"].ToString()),
                            AccountHolderIdentifier = reader.GetGuid(reader.GetOrdinal("AccountHolderIdentifier")).ToString()
                        };
                        key = Convert.ToInt64(reader["ProductKey"]);
                        var consumerProfileTypeKey = Int64.Parse(reader["ConsumerProfileTypeKey"].ToString());
                        if (consumerProfileTypeKey == (long)ConsumerProfileType.BeneficialOwner && (key == 61 || key == 64))
                        {
                            users.Add(userProfile);
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(ex, 
                    $"Error occurred when retrieving profile for account identifier {accountIdentifier} : {ex}");
                throw new Exception("An error occurred trying to retrieve consumer profile: " + ex.Message);
            }
            if (users != null && users.Count != 0)
            {
                var user = users.Where(x => x.UserIdentifier.ToString() == userIdentifier.ToString()).FirstOrDefault();
                if (user != null)
                {
                    accountHolderId = Guid.Parse(user.AccountHolderIdentifier);
                    return GetAccountBeneficialOwnerWithMultipleAddresses((Guid)accountIdentifier, userIdentifier, accountHolderId, 0);
                }
            }
            // gets either SSN, ITIN or Matricula ID token 
            return GetAccountPrimaryConsumerProfileWithMultipleAddresses((Guid)accountIdentifier, userIdentifier, 0);
        }

        public AccountPrimaryConsumerProfile GetAccountBeneficialOwnerWithMultipleAddresses(Guid accountIdentifier, Guid userIdentifier, Guid accountHolderId, IdentityType identityType)
        {
            try
            {
                List<AccountPrimaryConsumerProfile> accountPrimaryConsumerProfiles = new List<AccountPrimaryConsumerProfile>();
                AccountPrimaryConsumerProfile accountPrimaryConsumerProfile = null;
                var addressList = new List<ConsumerProfileAddress>();
                List<SqlParameter> sqlParameters = new List<SqlParameter>();

                if (accountIdentifier != null)
                    sqlParameters.Add(new SqlParameter { ParameterName = "AccountIdentifier", Value = accountIdentifier });


                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAllConsumerProfileByAccountIdentifier]",
                    _dataAccess.CreateConnectionWithColumnEncryption(), sqlParameters.ToArray()))
                {
                    while (reader.Read())
                    {
                        accountPrimaryConsumerProfile = new AccountPrimaryConsumerProfile();

                        if (accountIdentifier != null)
                            accountPrimaryConsumerProfile.AccountIdentifier = accountIdentifier;

                        accountPrimaryConsumerProfile.AccountHolderIdentifier = reader["AccountHolderIdentifier"] == DBNull.Value ? new Guid() : reader.GetGuid(reader.GetOrdinal("AccountHolderIdentifier"));
                        if (accountPrimaryConsumerProfile.AccountHolderIdentifier == accountHolderId)
                        {
                            accountPrimaryConsumerProfile.FirstName = reader["FirstName"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("FirstName"));
                            accountPrimaryConsumerProfile.MiddleName = reader["MiddleName"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("MiddleName"));
                            accountPrimaryConsumerProfile.LastName = reader["LastName"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("LastName"));
                            accountPrimaryConsumerProfile.DOB = reader["EncryptedDOB"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("EncryptedDOB"));
                            //accountPrimaryConsumerProfile.AddressType = (AddressType)Enum.Parse(typeof(AddressType), reader["AddressTypeKey"].ToString());
                            //accountPrimaryConsumerProfile.Address1 = reader["Address1"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Address1"));
                            //accountPrimaryConsumerProfile.Address2 = reader["Address2"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Address2"));
                            //accountPrimaryConsumerProfile.City = reader["City"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("City"));
                            //accountPrimaryConsumerProfile.State = reader["State"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("State"));
                            //accountPrimaryConsumerProfile.ZipCode = reader["ZipCode"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("ZipCode"));
                            //accountPrimaryConsumerProfile.Country = reader["Country"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Country"));
                            accountPrimaryConsumerProfile.Email = reader["Email"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Email"));
                            accountPrimaryConsumerProfile.PhoneNumber = reader["PhoneNumber"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("PhoneNumber"));
                            accountPrimaryConsumerProfile.IdentityToken = reader.GetString(reader.GetOrdinal("IdentityToken"));
                            accountPrimaryConsumerProfile.ProgramCode = reader["ProgramCode"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("ProgramCode"));
                            accountPrimaryConsumerProfile.ProductCode = reader["ProductCode"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("ProductCode"));
                            accountPrimaryConsumerProfile.AccountStatus = (AccountStatus)Convert.ToInt32(reader["AccountStatusKey"]);
                            accountPrimaryConsumerProfile.AccountHolderKey = reader.GetInt64(reader.GetOrdinal("AccountHolderKey"));
                            accountPrimaryConsumerProfile.AccountKey = reader.GetInt64(reader.GetOrdinal("AccountKey"));
                            accountPrimaryConsumerProfile.ConsumerProfileKey = reader.GetInt64(reader.GetOrdinal("ConsumerProfileKey"));
                            accountPrimaryConsumerProfile.AccountHolderCure = reader["AccountHolderCureKey"] == DBNull.Value ? AccountHolderCure.Unknown : (AccountHolderCure)(Convert.ToInt32(reader["AccountHolderCureKey"]));
                            //break;
                            addressList.Add(new ConsumerProfileAddress
                            {
                                Address1 = reader["Address1"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Address1")),
                                Address2 = reader["Address2"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Address2")),
                                AddressType = (AddressType)Enum.Parse(typeof(AddressType), reader["AddressTypeKey"].ToString()),
                                City = reader["City"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("City")),
                                Country = reader["Country"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Country")),
                                State = reader["State"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("State")),
                                ZipCode = reader["ZipCode"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("ZipCode"))
                            });
                        }

                    }
                    // no consumer profile found!
                    if (accountPrimaryConsumerProfile == null)
                        return null;

                    accountPrimaryConsumerProfile.Addresses = addressList;
                    var selectedAddress = addressList.FirstOrDefault();
                    accountPrimaryConsumerProfile.AddressType = selectedAddress.AddressType;
                    accountPrimaryConsumerProfile.Address1 = selectedAddress.Address1;
                    accountPrimaryConsumerProfile.Address2 = selectedAddress.Address2;
                    accountPrimaryConsumerProfile.City = selectedAddress.City;
                    accountPrimaryConsumerProfile.State = selectedAddress.State;
                    accountPrimaryConsumerProfile.ZipCode = selectedAddress.ZipCode;
                    accountPrimaryConsumerProfile.Country = selectedAddress.Country;

                    // payment info
                    reader.NextResult();

                    accountPrimaryConsumerProfile.PaymentIdentifiers = new List<PaymentIdentifier>();
                    while (reader.Read())
                    {
                        // backwards compability
                        accountPrimaryConsumerProfile.PaymentIdentifier = reader["PaymentIdentifier"] == DBNull.Value ? null : reader["PaymentIdentifier"].ToString();
                        accountPrimaryConsumerProfile.IsVirtualCardExist = true;
                        var paymentIdentifier = new PaymentIdentifier(PaymentIdentifierIdentifier.FromString(accountPrimaryConsumerProfile.PaymentIdentifier))
                        {
                            PaymentIdentifierStatusKey = (int)accountPrimaryConsumerProfile.PaymentIdentifierStatus,
                        };
                        accountPrimaryConsumerProfile.PaymentIdentifiers.Add(paymentIdentifier);
                    }
                    // token identity
                    reader.NextResult();
                    return accountPrimaryConsumerProfile;
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(ex, $"AccountRepository.GetAllConsumerProfileByAccountIdentifier: error occurred when retrieving profile for user identifier {accountIdentifier} : {ex}");
                throw new Exception("An error occurred trying to retrieve consumer profile: " + ex.Message);
            }
        }
        /// <summary>
        /// GetAccountPrimaryConsumerProfile
        /// </summary>
        /// <param name="accountIdentifier"></param>
        /// <returns></returns>
        public AccountPrimaryConsumerProfile GetAccountPrimaryConsumerProfileWithMultipleAddresses(Guid? accountIdentifier, Guid? userIdentifier, IdentityType identityType)
        {
            try
            {
                AccountPrimaryConsumerProfile accountPrimaryConsumerProfile = null;
                var addressList = new List<ConsumerProfileAddress>();
                List<SqlParameter> sqlParameters = new List<SqlParameter>();

                if (accountIdentifier != null)
                    sqlParameters.Add(new SqlParameter { ParameterName = "AccountIdentifier", Value = accountIdentifier.Value });

                if (userIdentifier != null)
                    sqlParameters.Add(new SqlParameter { ParameterName = "ConsumerProfileIdentifier", Value = userIdentifier.Value });


                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetPrimaryConsumerProfileV5]",
                    _dataAccess.CreateConnectionWithColumnEncryption(), sqlParameters.ToArray()))
                {
                    while (reader.Read())
                    {
                        accountPrimaryConsumerProfile = new AccountPrimaryConsumerProfile();

                        if (accountIdentifier != null)
                            accountPrimaryConsumerProfile.AccountIdentifier = accountIdentifier.Value;

                        accountPrimaryConsumerProfile.FirstName = reader["FirstName"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("FirstName"));
                        accountPrimaryConsumerProfile.MiddleName = reader["MiddleName"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("MiddleName"));
                        accountPrimaryConsumerProfile.LastName = reader["LastName"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("LastName"));
                        accountPrimaryConsumerProfile.DOB = reader["EncryptedDOB"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("EncryptedDOB"));
                        //accountPrimaryConsumerProfile.AddressType = (AddressType)Enum.Parse(typeof(AddressType), reader["AddressTypeKey"].ToString());
                        //accountPrimaryConsumerProfile.Address1 = reader["Address1"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Address1"));
                        //accountPrimaryConsumerProfile.Address2 = reader["Address2"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Address2"));
                        //accountPrimaryConsumerProfile.City = reader["City"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("City"));
                        //accountPrimaryConsumerProfile.State = reader["State"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("State"));
                        //accountPrimaryConsumerProfile.ZipCode = reader["ZipCode"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("ZipCode"));
                        //accountPrimaryConsumerProfile.Country = reader["Country"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Country"));
                        accountPrimaryConsumerProfile.Email = reader["Email"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Email"));
                        accountPrimaryConsumerProfile.IsEmailVerified = reader["IsEmailVerified"] != DBNull.Value && reader.GetBoolean(reader.GetOrdinal("IsEmailVerified"));
                        accountPrimaryConsumerProfile.PhoneNumber = reader["PhoneNumber"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("PhoneNumber"));
                        accountPrimaryConsumerProfile.PhoneType = (PhoneType)Enum.Parse(typeof(PhoneType), reader["PhoneTypeKey"].ToString());
                        accountPrimaryConsumerProfile.ProgramCode = reader["ProgramCode"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("ProgramCode"));
                        accountPrimaryConsumerProfile.ProductCode = reader["ProductCode"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("ProductCode"));
                        accountPrimaryConsumerProfile.AccountStatus = (AccountStatus)Convert.ToInt32(reader["AccountStatusKey"]);
                        accountPrimaryConsumerProfile.AccountHolderKey = reader.GetInt64(reader.GetOrdinal("AccountHolderKey"));
                        accountPrimaryConsumerProfile.AccountKey = reader.GetInt64(reader.GetOrdinal("AccountKey"));
                        accountPrimaryConsumerProfile.ProductKey = reader.GetInt32(reader.GetOrdinal("ProductKey"));
                        accountPrimaryConsumerProfile.ConsumerProfileKey = reader.GetInt64(reader.GetOrdinal("ConsumerProfileKey"));
                        accountPrimaryConsumerProfile.AccountHolderIdentifier = reader["AccountHolderIdentifier"] == DBNull.Value ? new Guid() : reader.GetGuid(reader.GetOrdinal("AccountHolderIdentifier"));
                        accountPrimaryConsumerProfile.AccountHolderCure = reader["AccountHolderCureKey"] == DBNull.Value ? AccountHolderCure.Unknown : (AccountHolderCure)(Convert.ToInt32(reader["AccountHolderCureKey"]));
                        accountPrimaryConsumerProfile.AccountNumber = reader["AccountNumber"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("AccountNumber"));
                        accountPrimaryConsumerProfile.RoutingNumber = reader["RoutingNumber"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("RoutingNumber"));
                        accountPrimaryConsumerProfile.AccountReferenceNumber = reader["AccountReferenceNumber"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("AccountReferenceNumber"));
                        accountPrimaryConsumerProfile.AccountCreateDate = reader.GetDateTime(reader.GetOrdinal("AccountCreateDate"));
                        //break;

                        addressList.Add(new ConsumerProfileAddress
                        {
                            Address1 = reader["Address1"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Address1")),
                            Address2 = reader["Address2"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Address2")),
                            AddressType = (AddressType)Enum.Parse(typeof(AddressType), reader["AddressTypeKey"].ToString()),
                            City = reader["City"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("City")),
                            Country = reader["Country"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Country")),
                            State = reader["State"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("State")),
                            ZipCode = reader["ZipCode"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("ZipCode")),
                            IsPrimary = reader.GetBoolean(reader.GetOrdinal("IsPrimary"))
                        });
                    }

                    // no consumer profile found!
                    if (accountPrimaryConsumerProfile == null || !addressList.Any(x => x.IsPrimary && x.AddressType == AddressType.Home))
                        return null;

                    accountPrimaryConsumerProfile.Addresses = addressList;
                    var selectedAddress = addressList.FirstOrDefault(x => x.IsPrimary && x.AddressType == AddressType.Home);
                    accountPrimaryConsumerProfile.AddressType = selectedAddress.AddressType;
                    accountPrimaryConsumerProfile.Address1 = selectedAddress.Address1;
                    accountPrimaryConsumerProfile.Address2 = selectedAddress.Address2;
                    accountPrimaryConsumerProfile.City = selectedAddress.City;
                    accountPrimaryConsumerProfile.State = selectedAddress.State;
                    accountPrimaryConsumerProfile.ZipCode = selectedAddress.ZipCode;
                    accountPrimaryConsumerProfile.Country = selectedAddress.Country;


                    // payment info
                    reader.NextResult();

                    accountPrimaryConsumerProfile.PaymentIdentifiers = new List<PaymentIdentifier>();
                    while (reader.Read())
                    {
                        // backwards compability
                        accountPrimaryConsumerProfile.PaymentIdentifier = reader["PaymentIdentifier"] == DBNull.Value ? null : reader["PaymentIdentifier"].ToString();
                        accountPrimaryConsumerProfile.PaymentIdentifierStatus = (PaymentIdentifierStatus)(short)reader["PaymentIdentifierStatusKey"];
                        accountPrimaryConsumerProfile.PaymentIdentifierKey = reader["PaymentIdentifierKey"] == DBNull.Value ? 0 : Convert.ToInt64(reader["PaymentIdentifierKey"]);
                        accountPrimaryConsumerProfile.PaymentInstrumentIdentifier = reader["PaymentInstrumentIdentifier"] == DBNull.Value ? null : reader["PaymentInstrumentIdentifier"].ToString();
                        accountPrimaryConsumerProfile.IsVirtualCardExist = true;


                        var paymentIdentifier = new PaymentIdentifier(PaymentIdentifierIdentifier.FromString(accountPrimaryConsumerProfile.PaymentIdentifier))
                        {
                            PaymentIdentifierStatusKey = (int)accountPrimaryConsumerProfile.PaymentIdentifierStatus,
                            PaymentIdentifierKey = accountPrimaryConsumerProfile.PaymentIdentifierKey,
                            PaymentInstrument = new Gd.Bos.RequestHandler.Core.Domain.Model.Payment.PaymentInstrument
                            {
                                PaymentInstrumentIdentifier = accountPrimaryConsumerProfile.PaymentInstrumentIdentifier,
                            }
                        };
                        accountPrimaryConsumerProfile.PaymentIdentifiers.Add(paymentIdentifier);
                    }

                    // token identity
                    reader.NextResult();

                    var userProfile = ReadUserProfileIdentity(reader, identityType);
                    accountPrimaryConsumerProfile.IdentityToken = userProfile?.IdentityToken;
                    accountPrimaryConsumerProfile.IdentityType = userProfile?.IdentityType;

                    return accountPrimaryConsumerProfile;
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(ex, $"AccountRepository.GetAccountPrimaryConsumerProfile: error occurred when retrieving profile for user identifier {accountIdentifier} : {ex}");
                throw new Exception("An error occurred trying to retrieve consumer profile: " + ex.Message);
            }
        }

        [ExcludeFromCodeCoverage(Justification ="only a log was added")]
        private AccountPrimaryConsumerProfile GetAccountBeneficialOwner(Guid accountIdentifier, Guid userIdentifier, Guid accountHolderId, IdentityType identityType)
        {
            try
            {
                List<AccountPrimaryConsumerProfile> accountPrimaryConsumerProfiles = new List<AccountPrimaryConsumerProfile>();
                AccountPrimaryConsumerProfile accountPrimaryConsumerProfile = null;

                List<SqlParameter> sqlParameters = new List<SqlParameter>();

                if (accountIdentifier != null)
                    sqlParameters.Add(new SqlParameter { ParameterName = "AccountIdentifier", Value = accountIdentifier });


                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAllConsumerProfileByAccountIdentifier]",
                    _dataAccess.CreateConnectionWithColumnEncryption(), sqlParameters.ToArray()))
                {
                    while (reader.Read())
                    {
                        accountPrimaryConsumerProfile = new AccountPrimaryConsumerProfile();

                        if (accountIdentifier != null)
                            accountPrimaryConsumerProfile.AccountIdentifier = accountIdentifier;

                        accountPrimaryConsumerProfile.AccountHolderIdentifier = reader["AccountHolderIdentifier"] == DBNull.Value ? new Guid() : reader.GetGuid(reader.GetOrdinal("AccountHolderIdentifier"));
                        if (accountPrimaryConsumerProfile.AccountHolderIdentifier == accountHolderId)
                        {
                            accountPrimaryConsumerProfile.FirstName = reader["FirstName"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("FirstName"));
                            accountPrimaryConsumerProfile.MiddleName = reader["MiddleName"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("MiddleName"));
                            accountPrimaryConsumerProfile.LastName = reader["LastName"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("LastName"));
                            accountPrimaryConsumerProfile.DOB = reader["EncryptedDOB"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("EncryptedDOB"));
                            accountPrimaryConsumerProfile.AddressType = (AddressType)Enum.Parse(typeof(AddressType), reader["AddressTypeKey"].ToString());
                            accountPrimaryConsumerProfile.Address1 = reader["Address1"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Address1"));
                            accountPrimaryConsumerProfile.Address2 = reader["Address2"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Address2"));
                            accountPrimaryConsumerProfile.City = reader["City"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("City"));
                            accountPrimaryConsumerProfile.State = reader["State"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("State"));
                            accountPrimaryConsumerProfile.ZipCode = reader["ZipCode"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("ZipCode"));
                            accountPrimaryConsumerProfile.Country = reader["Country"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Country"));
                            accountPrimaryConsumerProfile.Email = reader["Email"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Email"));
                            accountPrimaryConsumerProfile.PhoneNumber = reader["PhoneNumber"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("PhoneNumber"));
                            accountPrimaryConsumerProfile.IdentityToken = reader.GetString(reader.GetOrdinal("IdentityToken"));
                            accountPrimaryConsumerProfile.ProgramCode = reader["ProgramCode"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("ProgramCode"));
                            accountPrimaryConsumerProfile.ProductCode = reader["ProductCode"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("ProductCode"));
                            accountPrimaryConsumerProfile.AccountStatus = (AccountStatus)Convert.ToInt32(reader["AccountStatusKey"]);
                            accountPrimaryConsumerProfile.AccountHolderKey = reader.GetInt64(reader.GetOrdinal("AccountHolderKey"));
                            accountPrimaryConsumerProfile.AccountKey = reader.GetInt64(reader.GetOrdinal("AccountKey"));
                            accountPrimaryConsumerProfile.ConsumerProfileKey = reader.GetInt64(reader.GetOrdinal("ConsumerProfileKey"));
                            accountPrimaryConsumerProfile.AccountHolderCure = reader["AccountHolderCureKey"] == DBNull.Value ? AccountHolderCure.Unknown : (AccountHolderCure)(Convert.ToInt32(reader["AccountHolderCureKey"]));
                            break;
                        }

                    }
                    // no consumer profile found!
                    if (accountPrimaryConsumerProfile == null)
                        return null;

                    // payment info
                    reader.NextResult();

                    accountPrimaryConsumerProfile.PaymentIdentifiers = new List<PaymentIdentifier>();
                    while (reader.Read())
                    {
                        // backwards compability
                        accountPrimaryConsumerProfile.PaymentIdentifier = reader["PaymentIdentifier"] == DBNull.Value ? null : reader["PaymentIdentifier"].ToString();
                        accountPrimaryConsumerProfile.IsVirtualCardExist = true;
                        var paymentIdentifier = new PaymentIdentifier(PaymentIdentifierIdentifier.FromString(accountPrimaryConsumerProfile.PaymentIdentifier))
                        {
                            PaymentIdentifierStatusKey = (int)accountPrimaryConsumerProfile.PaymentIdentifierStatus,
                        };
                        accountPrimaryConsumerProfile.PaymentIdentifiers.Add(paymentIdentifier);
                    }
                    // token identity
                    reader.NextResult();
                    return accountPrimaryConsumerProfile;
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(ex, $"AccountRepository.GetAllConsumerProfileByAccountIdentifier: error occurred when retrieving profile for user identifier {accountIdentifier} : {ex}");
                throw new Exception("An error occurred trying to retrieve consumer profile: " + ex.Message);
            }
        }

        /// <summary>
        /// GetAccountPrimaryConsumerProfile
        /// </summary>
        /// <param name="accountIdentifier"></param>
        /// <returns></returns>
        public AccountPrimaryConsumerProfile GetAccountPrimaryConsumerProfileAnyToken(AccountIdentifier accountIdentifier, string programCode = null)
        {
            // gets either SSN, ITIN or Matricula ID token 
            if (programCode != null && "toast".Equals(programCode, StringComparison.InvariantCultureIgnoreCase))
                return GetAccountPrimaryConsumerProfileWithDefaultAddress((Guid)accountIdentifier, null, 0);
            else
                return GetAccountPrimaryConsumerProfile((Guid)accountIdentifier, null, 0);
        }
     
        private AccountPrimaryConsumerProfile GetAccountPrimaryConsumerProfile(Guid? accountIdentifier, Guid? userIdentifier, IdentityType identityType)
        {
            try
            {
                AccountPrimaryConsumerProfile accountPrimaryConsumerProfile = null;

                List<SqlParameter> sqlParameters = new List<SqlParameter>();

                if (accountIdentifier != null)
                    sqlParameters.Add(new SqlParameter { ParameterName = "AccountIdentifier", Value = accountIdentifier.Value });

                if (userIdentifier != null)
                    sqlParameters.Add(new SqlParameter { ParameterName = "ConsumerProfileIdentifier", Value = userIdentifier.Value });


                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetPrimaryConsumerProfileV3]",
                    _dataAccess.CreateConnectionWithColumnEncryption(), sqlParameters.ToArray()))
                {
                    while (reader.Read())
                    {
                        accountPrimaryConsumerProfile = new AccountPrimaryConsumerProfile();

                        if (accountIdentifier != null)
                            accountPrimaryConsumerProfile.AccountIdentifier = accountIdentifier.Value;

                        accountPrimaryConsumerProfile.FirstName = reader["FirstName"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("FirstName"));
                        accountPrimaryConsumerProfile.MiddleName = reader["MiddleName"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("MiddleName"));
                        accountPrimaryConsumerProfile.LastName = reader["LastName"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("LastName"));
                        accountPrimaryConsumerProfile.DOB = reader["EncryptedDOB"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("EncryptedDOB"));
                        accountPrimaryConsumerProfile.AddressType = (AddressType)Enum.Parse(typeof(AddressType), reader["AddressTypeKey"].ToString());
                        accountPrimaryConsumerProfile.Address1 = reader["Address1"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Address1"));
                        accountPrimaryConsumerProfile.Address2 = reader["Address2"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Address2"));
                        accountPrimaryConsumerProfile.City = reader["City"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("City"));
                        accountPrimaryConsumerProfile.State = reader["State"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("State"));
                        accountPrimaryConsumerProfile.ZipCode = reader["ZipCode"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("ZipCode"));
                        accountPrimaryConsumerProfile.Country = reader["Country"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Country"));
                        accountPrimaryConsumerProfile.Email = reader["Email"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Email"));
                        accountPrimaryConsumerProfile.IsEmailVerified = reader["IsEmailVerified"] != DBNull.Value && reader.GetBoolean(reader.GetOrdinal("IsEmailVerified"));
                        accountPrimaryConsumerProfile.PhoneNumber = reader["PhoneNumber"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("PhoneNumber"));
                        accountPrimaryConsumerProfile.PhoneType = (PhoneType)Enum.Parse(typeof(PhoneType), reader["PhoneTypeKey"].ToString());
                        accountPrimaryConsumerProfile.ProgramCode = reader["ProgramCode"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("ProgramCode"));
                        accountPrimaryConsumerProfile.ProductCode = reader["ProductCode"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("ProductCode"));
                        accountPrimaryConsumerProfile.AccountStatus = (AccountStatus)Convert.ToInt32(reader["AccountStatusKey"]);
                        accountPrimaryConsumerProfile.AccountHolderKey = reader.GetInt64(reader.GetOrdinal("AccountHolderKey"));
                        accountPrimaryConsumerProfile.AccountKey = reader.GetInt64(reader.GetOrdinal("AccountKey"));
                        accountPrimaryConsumerProfile.ProductKey = reader.GetInt32(reader.GetOrdinal("ProductKey"));
                        accountPrimaryConsumerProfile.ConsumerProfileKey = reader.GetInt64(reader.GetOrdinal("ConsumerProfileKey"));
                        accountPrimaryConsumerProfile.AccountHolderIdentifier = reader["AccountHolderIdentifier"] == DBNull.Value ? new Guid() : reader.GetGuid(reader.GetOrdinal("AccountHolderIdentifier"));
                        accountPrimaryConsumerProfile.AccountHolderCure = reader["AccountHolderCureKey"] == DBNull.Value ? AccountHolderCure.Unknown : (AccountHolderCure)(Convert.ToInt32(reader["AccountHolderCureKey"]));
                        accountPrimaryConsumerProfile.AccountNumber = reader["AccountNumber"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("AccountNumber"));
                        accountPrimaryConsumerProfile.RoutingNumber = reader["RoutingNumber"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("RoutingNumber"));
                        accountPrimaryConsumerProfile.AccountReferenceNumber = reader["AccountReferenceNumber"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("AccountReferenceNumber"));
                        accountPrimaryConsumerProfile.AccountCreateDate = reader.GetDateTime(reader.GetOrdinal("AccountCreateDate"));
                        break;
                    }

                    // no consumer profile found!
                    if (accountPrimaryConsumerProfile == null)
                        return null;

                    // payment info
                    reader.NextResult();

                    accountPrimaryConsumerProfile.PaymentIdentifiers = new List<PaymentIdentifier>();
                    while (reader.Read())
                    {
                        // backwards compability
                        accountPrimaryConsumerProfile.PaymentIdentifier = reader["PaymentIdentifier"] == DBNull.Value ? null : reader["PaymentIdentifier"].ToString();
                        accountPrimaryConsumerProfile.PaymentIdentifierStatus = (PaymentIdentifierStatus)(short)reader["PaymentIdentifierStatusKey"];
                        accountPrimaryConsumerProfile.PaymentIdentifierKey = reader["PaymentIdentifierKey"] == DBNull.Value ? 0 : Convert.ToInt64(reader["PaymentIdentifierKey"]);
                        accountPrimaryConsumerProfile.PaymentInstrumentIdentifier = reader["PaymentInstrumentIdentifier"] == DBNull.Value ? null : reader["PaymentInstrumentIdentifier"].ToString();
                        accountPrimaryConsumerProfile.IsVirtualCardExist = true;


                        var paymentIdentifier = new PaymentIdentifier(PaymentIdentifierIdentifier.FromString(accountPrimaryConsumerProfile.PaymentIdentifier))
                        {
                            PaymentIdentifierStatusKey = (int)accountPrimaryConsumerProfile.PaymentIdentifierStatus,
                            PaymentIdentifierKey = accountPrimaryConsumerProfile.PaymentIdentifierKey,
                            PaymentInstrument = new Gd.Bos.RequestHandler.Core.Domain.Model.Payment.PaymentInstrument
                            {
                                PaymentInstrumentIdentifier = accountPrimaryConsumerProfile.PaymentInstrumentIdentifier,
                            }
                        };
                        accountPrimaryConsumerProfile.PaymentIdentifiers.Add(paymentIdentifier);
                    }

                    // token identity
                    reader.NextResult();
                    var identityDetail = ReadUserProfileIdentity(reader, identityType);
                    accountPrimaryConsumerProfile.IdentityToken = identityDetail?.IdentityToken;
                    accountPrimaryConsumerProfile.IdentityType = identityDetail?.IdentityType;

                    return accountPrimaryConsumerProfile;
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(ex, $"AccountRepository.GetAccountPrimaryConsumerProfile: error occurred when retrieving profile for user identifier {accountIdentifier} : {ex}");
                throw new Exception("An error occurred trying to retrieve consumer profile: " + ex.Message);
            }
        }

        /// <summary>
        /// GetVerficationRequestInfoByAccountIdentifierUserIdentifier
        /// </summary>
        /// <param name="createVerifyRequest"></param>
        /// <param name="activityType"></param>
        /// <returns></returns>
        /// <exception cref="AccountHolderNotFoundException"></exception>
        public CreateVerifyRequest GetVerficationRequestInfoByAccountIdentifierUserIdentifier(CreateVerifyRequest createVerifyRequest, VerificationActivityType activityType)
        {
            SqlParameter[] parameters;
            string statusKey = string.Empty;
            string verificationRequestIdentifier = string.Empty;
            var ssnToken = createVerifyRequest?.IdentityRequest?.SSNToken;
            var last4ssn = createVerifyRequest?.IdentityRequest?.Last4SSN;

            createVerifyRequest.IdentityRequest = new CreateRiskRequest();

            try
            {
                parameters = new[]
                {
                    new SqlParameter
                    {
                        ParameterName = "AccountIdentifier",
                        Value = Guid.Parse(createVerifyRequest.AccountIdentifier)
                    },
                    new SqlParameter
                    {
                        ParameterName = "ConsumerProfileIdentifier",
                        Value = Guid.Parse(createVerifyRequest.UserIdentifier)
                    },
                    new SqlParameter
                    {
                        ParameterName = "VerificationActivityTypeKey",
                        Value = activityType
                    }
                };
            }
            catch (Exception)
            {
                throw new AccountHolderNotFoundException();
            }

            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetVerificationRequestByAccountHolderIdentifier]",
                    _dataAccess.CreateConnectionWithColumnEncryption(), parameters))
                {
                    while (reader.Read())
                    {
                        statusKey = reader["ActivityStatusKey"] == DBNull.Value
                            ? null
                            : reader["ActivityStatusKey"].ToString();

                        if (statusKey == "1" || string.IsNullOrEmpty(statusKey) || !string.IsNullOrEmpty(ssnToken))
                        {
                            verificationRequestIdentifier = reader["VerificationRequestIdentifier"] == DBNull.Value ? null : reader.GetGuid(reader.GetOrdinal("VerificationRequestIdentifier")).ToString();
                            createVerifyRequest.VerificationRequestKey = reader.GetInt64(reader.GetOrdinal("VerificationRequestKey"));
                            createVerifyRequest.TriggerType = (TriggerType)(short)reader["VerificationTriggerTypeKey"];

                        }
                    }
                }

                AccountPrimaryConsumerProfile accountPrimaryConsumerProfile = GetAccountPrimaryConsumerProfileWithDefaultAddress(Guid.Parse(createVerifyRequest.AccountIdentifier), Guid.Parse(createVerifyRequest.UserIdentifier), 0);

                if (accountPrimaryConsumerProfile != null)
                {
                    if (statusKey == "1" || string.IsNullOrEmpty(statusKey) || !string.IsNullOrEmpty(ssnToken))
                    {
                        createVerifyRequest.IdentityRequest.FirstName = accountPrimaryConsumerProfile.FirstName;
                        createVerifyRequest.IdentityRequest.MiddleName = accountPrimaryConsumerProfile.MiddleName;
                        createVerifyRequest.IdentityRequest.LastName = accountPrimaryConsumerProfile.LastName;
                        createVerifyRequest.IdentityRequest.Last4SSN = !string.IsNullOrEmpty(ssnToken)
                            ? last4ssn  // new ssn's last 4
                            : accountPrimaryConsumerProfile.Last4SSN;
                        createVerifyRequest.IdentityRequest.DateOfBirth = accountPrimaryConsumerProfile.DOB;
                        createVerifyRequest.IdentityRequest.Address1 = accountPrimaryConsumerProfile.Address1;
                        createVerifyRequest.IdentityRequest.Address2 = accountPrimaryConsumerProfile.Address2;
                        createVerifyRequest.IdentityRequest.City = accountPrimaryConsumerProfile.City;
                        createVerifyRequest.IdentityRequest.State = accountPrimaryConsumerProfile.State;
                        createVerifyRequest.IdentityRequest.ZipCode = accountPrimaryConsumerProfile.ZipCode;
                        createVerifyRequest.IdentityRequest.Country = accountPrimaryConsumerProfile.Country;
                        createVerifyRequest.IdentityRequest.Email = accountPrimaryConsumerProfile.Email;
                        createVerifyRequest.IdentityRequest.PhoneNumber = accountPrimaryConsumerProfile.PhoneNumber;
                        createVerifyRequest.AccountHolderKey = accountPrimaryConsumerProfile.AccountHolderKey;
                        createVerifyRequest.AccountKey = accountPrimaryConsumerProfile.AccountKey;
                        createVerifyRequest.ConsumerProfileKey = accountPrimaryConsumerProfile.ConsumerProfileKey;
                        createVerifyRequest.ProductKey = accountPrimaryConsumerProfile.ProductKey;
                        createVerifyRequest.ProductCode = accountPrimaryConsumerProfile.ProductCode;
                        createVerifyRequest.IdentityRequest.ExternalIdentifiers = new Dictionary<string, object>
                        {
                            { "AccountIdentifier", createVerifyRequest.AccountIdentifier },
                            {
                                "VerificationRequestIdentifier",
                                !string.IsNullOrWhiteSpace(verificationRequestIdentifier)
                                    ? verificationRequestIdentifier
                                    : Guid.NewGuid().ToString()
                            },
                            { "AccountHolderIdentifier", accountPrimaryConsumerProfile.AccountHolderIdentifier }
                        };

                        createVerifyRequest.IdentityRequest.Program = accountPrimaryConsumerProfile.ProgramCode;

                        createVerifyRequest.IdentityRequest.SSNToken = !string.IsNullOrEmpty(ssnToken) ? ssnToken : accountPrimaryConsumerProfile.IdentityToken;
                    }

                    createVerifyRequest.AccountHolderCureKey = (int)accountPrimaryConsumerProfile.AccountHolderCure;

                    createVerifyRequest.PaymentIdentifierStatus = accountPrimaryConsumerProfile.PaymentIdentifierStatus;
                    createVerifyRequest.PaymentIdentifierKey = accountPrimaryConsumerProfile.PaymentIdentifierKey;

                    return createVerifyRequest;
                }
                else // account not found
                    throw new AccountHolderNotFoundException();
            }
            catch (Exception ex)
            {
                Logger.Error(
                    $"AccountRepository.GetVerficationRequestInfoByAccountIdentifierUserIdentifier, error occurred when retrieving account identifier {createVerifyRequest.AccountIdentifier} : {ex}");
                throw new AccountHolderNotFoundException();
            }
        }

        public AccountPrimaryConsumerProfile GetAccountPrimaryConsumerProfileWithDefaultAddress(Guid? accountIdentifier, Guid? userIdentifier, IdentityType identityType)
        {
            try
            {
                AccountPrimaryConsumerProfile accountPrimaryConsumerProfile = null;
                List<SqlParameter> sqlParameters = new List<SqlParameter>();
                var addressList = new List<ConsumerProfileAddress>();

                if (accountIdentifier != null)
                    sqlParameters.Add(new SqlParameter { ParameterName = "AccountIdentifier", Value = accountIdentifier.Value });

                if (userIdentifier != null)
                    sqlParameters.Add(new SqlParameter { ParameterName = "ConsumerProfileIdentifier", Value = userIdentifier.Value });

                sqlParameters.Add(new SqlParameter { ParameterName = "RequireAddress", Value = 0 });

                using var reader = _dataAccess.ExecuteReader("[dbo].[GetPrimaryConsumerProfileV5]",
                    _dataAccess.CreateConnectionWithColumnEncryption(), sqlParameters.ToArray());
                while (reader.Read())
                {
                    accountPrimaryConsumerProfile = new AccountPrimaryConsumerProfile();

                    if (accountIdentifier != null)
                        accountPrimaryConsumerProfile.AccountIdentifier = accountIdentifier.Value;

                    accountPrimaryConsumerProfile.FirstName = reader["FirstName"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("FirstName"));
                    accountPrimaryConsumerProfile.MiddleName = reader["MiddleName"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("MiddleName"));
                    accountPrimaryConsumerProfile.LastName = reader["LastName"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("LastName"));
                    accountPrimaryConsumerProfile.DOB = reader["EncryptedDOB"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("EncryptedDOB"));
                    accountPrimaryConsumerProfile.Email = reader["Email"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Email"));
                    accountPrimaryConsumerProfile.IsEmailVerified = reader["IsEmailVerified"] != DBNull.Value && reader.GetBoolean(reader.GetOrdinal("IsEmailVerified"));
                    accountPrimaryConsumerProfile.PhoneNumber = reader["PhoneNumber"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("PhoneNumber"));
                    accountPrimaryConsumerProfile.PhoneType = (PhoneType)Enum.Parse(typeof(PhoneType), reader["PhoneTypeKey"].ToString());
                    accountPrimaryConsumerProfile.ProgramCode = reader["ProgramCode"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("ProgramCode"));
                    accountPrimaryConsumerProfile.ProductCode = reader["ProductCode"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("ProductCode"));
                    accountPrimaryConsumerProfile.AccountStatus = (AccountStatus)Convert.ToInt32(reader["AccountStatusKey"]);
                    accountPrimaryConsumerProfile.AccountHolderKey = reader.GetInt64(reader.GetOrdinal("AccountHolderKey"));
                    accountPrimaryConsumerProfile.AccountKey = reader.GetInt64(reader.GetOrdinal("AccountKey"));
                    accountPrimaryConsumerProfile.ProductKey = reader.GetInt32(reader.GetOrdinal("ProductKey"));
                    accountPrimaryConsumerProfile.ConsumerProfileKey = reader.GetInt64(reader.GetOrdinal("ConsumerProfileKey"));
                    accountPrimaryConsumerProfile.AccountHolderIdentifier = reader["AccountHolderIdentifier"] == DBNull.Value ? new Guid() : reader.GetGuid(reader.GetOrdinal("AccountHolderIdentifier"));
                    accountPrimaryConsumerProfile.AccountHolderCure = reader["AccountHolderCureKey"] == DBNull.Value ? AccountHolderCure.Unknown : (AccountHolderCure)(Convert.ToInt32(reader["AccountHolderCureKey"]));
                    accountPrimaryConsumerProfile.AccountNumber = reader["AccountNumber"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("AccountNumber"));
                    accountPrimaryConsumerProfile.RoutingNumber = reader["RoutingNumber"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("RoutingNumber"));
                    accountPrimaryConsumerProfile.AccountReferenceNumber = reader["AccountReferenceNumber"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("AccountReferenceNumber"));
                    accountPrimaryConsumerProfile.AccountCreateDate = reader.GetDateTime(reader.GetOrdinal("AccountCreateDate"));

                    var defaultAddress = _requestHandlerSettings.ToastDefaultAddress;
                    if (defaultAddress != null)
                    {
                        addressList.Add(new ConsumerProfileAddress
                        {
                            Address1 = defaultAddress.AddressLine1,
                            Address2 = defaultAddress.AddressLine2,
                            AddressType = AddressType.Home,
                            City = defaultAddress.City,
                            Country = defaultAddress.Country,
                            State = defaultAddress.State,
                            ZipCode = defaultAddress.ZipCode,
                            IsPrimary = true
                        });
                        accountPrimaryConsumerProfile.Addresses = addressList;
                        var selectedAddress = addressList.FirstOrDefault(x => x.IsPrimary && x.AddressType == AddressType.Home);
                        accountPrimaryConsumerProfile.AddressType = selectedAddress!.AddressType;
                        accountPrimaryConsumerProfile.Address1 = selectedAddress.Address1;
                        accountPrimaryConsumerProfile.Address2 = selectedAddress.Address2;
                        accountPrimaryConsumerProfile.City = selectedAddress.City;
                        accountPrimaryConsumerProfile.State = selectedAddress.State;
                        accountPrimaryConsumerProfile.ZipCode = selectedAddress.ZipCode;
                        accountPrimaryConsumerProfile.Country = selectedAddress.Country;
                    }

                    break;
                }

                // no consumer profile found!
                if (accountPrimaryConsumerProfile == null)
                    return null;


                // payment info
                reader.NextResult();

                accountPrimaryConsumerProfile.PaymentIdentifiers = new List<PaymentIdentifier>();
                while (reader.Read())
                {
                    // backwards compability
                    accountPrimaryConsumerProfile.PaymentIdentifier = reader["PaymentIdentifier"] == DBNull.Value ? null : reader["PaymentIdentifier"].ToString();
                    accountPrimaryConsumerProfile.PaymentIdentifierStatus = (PaymentIdentifierStatus)(short)reader["PaymentIdentifierStatusKey"];
                    accountPrimaryConsumerProfile.PaymentIdentifierKey = reader["PaymentIdentifierKey"] == DBNull.Value ? 0 : Convert.ToInt64(reader["PaymentIdentifierKey"]);
                    accountPrimaryConsumerProfile.PaymentInstrumentIdentifier = reader["PaymentInstrumentIdentifier"] == DBNull.Value ? null : reader["PaymentInstrumentIdentifier"].ToString();
                    accountPrimaryConsumerProfile.IsVirtualCardExist = true;

                    var paymentIdentifier = new PaymentIdentifier(PaymentIdentifierIdentifier.FromString(accountPrimaryConsumerProfile.PaymentIdentifier))
                    {
                        PaymentIdentifierStatusKey = (int)accountPrimaryConsumerProfile.PaymentIdentifierStatus,
                        PaymentIdentifierKey = accountPrimaryConsumerProfile.PaymentIdentifierKey,
                        PaymentInstrument = new Gd.Bos.RequestHandler.Core.Domain.Model.Payment.PaymentInstrument
                        {
                            PaymentInstrumentIdentifier = accountPrimaryConsumerProfile.PaymentInstrumentIdentifier,
                        }
                    };
                    accountPrimaryConsumerProfile.PaymentIdentifiers.Add(paymentIdentifier);
                }

                // token identity
                reader.NextResult();
                var identityDetail = ReadUserProfileIdentity(reader, identityType);
                accountPrimaryConsumerProfile.IdentityToken = identityDetail?.IdentityToken ?? "";
                accountPrimaryConsumerProfile.IdentityType = identityDetail?.IdentityType;

                return accountPrimaryConsumerProfile;
            }
            catch (SqlException ex)
            {
                Logger.Error(ex, $"AccountRepository.GetAccountPrimaryConsumerProfile: error occurred when retrieving profile for user identifier {accountIdentifier} : {ex}");
                throw new Exception("An error occurred trying to retrieve consumer profile: " + ex.Message);
            }
        }

        public UserProfileIdentity ReadUserProfileIdentity(IDataReader reader, IdentityType identityType)
        {
            var userProfileIdentities = new List<UserProfileIdentity>();
            while (reader.Read())
            {
                var userProfileIdentity = new UserProfileIdentity
                {
                    IdentityToken = reader.GetString(reader.GetOrdinal("IdentityToken")),
                    Last4Identity = reader["Last4Identity"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Last4Identity")),
                    IdentityType = (IdentityType)reader.GetInt16(reader.GetOrdinal("IdentityTypeKey")),
                    CreateDateUtc = reader.GetDateTime(reader.GetOrdinal("CreateDate"))
                };

                userProfileIdentities.Add(userProfileIdentity);
            }

            //// return SSN identity if identityType is specified - maybe needed in near future
            //if(identityType == IdentityType.SSN)
            //    return userProfileIdentities.OrderByDescending(c => c.CreateDateUtc).FirstOrDefault(i => i.IdentityType == IdentityType.SSN);

            return userProfileIdentities.OrderByDescending(c => c.CreateDateUtc).FirstOrDefault();
        }

        public Tuple<User, List<UserProfileIdentity>> GetUserByAccountHolderIdentifier(string accountHolderIdentifier)
        {
            try
            {
                var parameters = new[]
                {
                    new SqlParameter {ParameterName = "AccountHolderIdentifier", Value = accountHolderIdentifier}
                };

                using (var reader = _dataAccess.ExecuteReader("[dbo].GetUserInfoByAccountHolderIdentifier",
                    _dataAccess.CreateConnection(), parameters))
                {
                    User user = null;
                    while (reader.Read())
                    {
                        var firstName = reader["FirstName"].Cast<string>();
                        var middleName = reader["MiddleName"].Cast<string>();
                        var lastName = reader["LastName"].Cast<string>();
                        UserName name = new UserName(firstName, middleName, lastName);

                        user = new User(UserIdentifier.FromGuid(reader["ConsumerProfileIdentifier"].Cast<Guid>()), ProgramCode.FromString(reader["ProgramCode"].Cast<string>()), name, null, null, null)
                        {
                            ConsumerProfileKey = reader["ConsumerProfileKey"].Cast<Int64>(),
                        };
                    }

                    reader.NextResult();

                    while (reader.Read())
                    {
                        AddressType type =
                            (AddressType)Enum.Parse(typeof(AddressType), reader["AddressTypeKey"].ToString());
                        Address address = new Address
                        {
                            AddressLine1 = reader["Address1"].Cast<string>(),
                            AddressLine2 = reader["Address2"].Cast<string>(),
                            City = reader["City"].Cast<string>(),
                            State = reader["State"].Cast<string>(),
                            ZipCode = reader["ZipCode"].Cast<string>(),
                            Country = reader["Country"].Cast<string>(),
                            Type = type.ToString(),
                            IsDefault = reader["IsPrimary"].Cast<bool>(),
                            IsVerified = reader["IsReturned"].Cast<bool>(),
                            LastModified = DateTimeOffset.Parse(reader["ChangeDate"].ToString())
                        };

                        if (user != null)
                            user.AddAddress(address);
                    }

                    reader.NextResult();

                    while (reader.Read())
                    {
                        var email = new Email(reader["Email"].Cast<string>(),
                            (Domain.Model.User.EmailType)Enum.Parse(typeof(Domain.Model.User.EmailType), reader["EmailTypeKey"].ToString()),
                            reader["IsVerified"].Cast<bool>(),
                             reader["IsPrimary"].Cast<bool>(),
                            DateTimeOffset.Parse(reader["ChangeDate"].ToString()));

                        if (email.IsPrimary)
                        {
                            user?.SetEmail(email);
                        }
                    }

                    reader.NextResult();
                    while (reader.Read())
                    {
                        PhoneNumber phoneNumber = new PhoneNumber
                        {
                            Number = reader["PhoneNumber"].Cast<string>(),
                            Type = (PhoneType)Enum.Parse(typeof(PhoneType), reader["PhoneTypeKey"].ToString()),
                            IsDefault = reader["IsPrimary"].Cast<bool>(),
                            IsVerified = reader["IsVerified"].Cast<bool>(),
                            LastModified = DateTimeOffset.Parse(reader["ChangeDate"].ToString())
                        };

                        user?.AddPhoneNumber(phoneNumber);
                    }

                    reader.NextResult();

                    var userProfileIdentities = new List<UserProfileIdentity>();

                    // read user profile identities
                    while (reader.Read())
                    {
                        var consumerProfileKey = reader["ConsumerProfileKey"].Cast<long>();

                        var userProfileIdentity = new UserProfileIdentity
                        {
                            ConsumerProfileKey = consumerProfileKey,
                            IdentityType = (IdentityType)reader.GetInt16(reader.GetOrdinal("IdentityTypeKey")),
                            CreateDateUtc = DateTimeOffset.Parse(reader["CreateDate"].ToString()),
                            Last4Identity = reader["Last4Identity"].Cast<string>(),
                            IdentityToken = reader.GetString(reader.GetOrdinal("IdentityToken"))
                        };

                        userProfileIdentities.Add(userProfileIdentity);
                    }

                    return new Tuple<User, List<UserProfileIdentity>>(user, userProfileIdentities);
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(ex, 
                    $"AccountHolderIdentifier:{accountHolderIdentifier} - UserRepository.GetUserByAccountHolderIdentifier: error occurred when get user. Exception : {ex}");
                throw new Exception("An error occurred trying to get user: " + ex.Message);
            }
        }

        [ExcludeFromCodeCoverage(Justification ="only a log was added")]
        public Tuple<Account, User> GetAccountInfoForFraud(AccountIdentifier accountIdentifier, string programCode = null)
        {
            try
            {
                AccountPrimaryConsumerProfile accountPrimaryConsumerProfile = GetAccountPrimaryConsumerProfileAnyToken(accountIdentifier, programCode);

                if (accountPrimaryConsumerProfile == null)
                {
                    Logger.Error($"AccountRepository.GetInfoForFraud: no profile for account identifier {accountIdentifier}");
                    throw new ConsumerProfileNotFoundException(503, 0, "Consumer profile not found");
                }

                Account account = new Account(accountIdentifier);
                AccountHolder ah = new AccountHolder(null, accountPrimaryConsumerProfile.AccountHolderIdentifier, null, true);
                account.AddAccountHolder(ah);
                account.AccountKey = accountPrimaryConsumerProfile.AccountKey;
                account.AccountReferenceNumber = accountPrimaryConsumerProfile.AccountReferenceNumber;
                account.AccountNumber = accountPrimaryConsumerProfile.AccountNumber;
                account.RoutingNumber = accountPrimaryConsumerProfile.RoutingNumber;
                account.AccountCreateDate = accountPrimaryConsumerProfile.AccountCreateDate;

                account.Product = new Product(ProductCode.FromString(accountPrimaryConsumerProfile.ProductCode), null, 0, null, null, null);

                UserName name = new UserName(accountPrimaryConsumerProfile.FirstName, accountPrimaryConsumerProfile.MiddleName, accountPrimaryConsumerProfile.LastName);

                Address address = new Address
                {
                    AddressLine1 = accountPrimaryConsumerProfile.Address1,
                    AddressLine2 = accountPrimaryConsumerProfile.Address2,
                    City = accountPrimaryConsumerProfile.City,
                    State = accountPrimaryConsumerProfile.State,
                    ZipCode = accountPrimaryConsumerProfile.ZipCode,
                    Country = accountPrimaryConsumerProfile.Country
                };
                Email email = new Email(accountPrimaryConsumerProfile.Email, true);
                PhoneNumber number = new PhoneNumber
                {
                    Number = accountPrimaryConsumerProfile.PhoneNumber
                };
                programCode = accountPrimaryConsumerProfile.ProgramCode;
                User user = new User(null, ProgramCode.FromString(programCode), name, null, null, accountPrimaryConsumerProfile.IdentityToken);
                user.AddAddress(address);
                user.SetEmail(email);
                user.AddPhoneNumber(number);

                return new Tuple<Account, User>(account, user);
            }
            catch (SqlException ex)
            {
                Logger.Error(ex, 
                    $"AccountRepository.GetInfoForFraud: error occurred when retrieving profile for account identifier {accountIdentifier} : {ex}");
                throw new Exception("An error occurred trying to retrieve consumer profile: " + ex.Message);
            }
        }

        public List<Tuple<short, long, DateTime?>> GetAccountDetails(AccountIdentifier accountIdentifier, ProgramCode programCode)
        {
            var result = new List<Tuple<short, long, DateTime?>>();
            var parameters = new[]
            {
                new SqlParameter {ParameterName = "AccountIdentifier", Value = accountIdentifier.ToString()},
                new SqlParameter {ParameterName = "ProgramCode", Value = programCode.ToString()}

            };
            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountDetails]",
                _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    var billCycle = reader["BillCycleDay"] == DBNull.Value
                        ? (short)0
                        : Convert.ToInt16(reader["BillCycleDay"]);
                    var linkedAccountKey = reader["LinkedAccountKey"] == DBNull.Value
                        ? 0
                        : Convert.ToInt64(reader["LinkedAccountKey"]);
                    var endDate = reader["EndDate"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(reader["EndDate"]);
                    var accountDetail = new Tuple<short, long, DateTime?>(billCycle, linkedAccountKey, endDate);
                    result.Add(accountDetail);
                }
            }
            return result;
        }

        public List<Tuple<long, DateTime?>> GetAccountDetailsByLinkedAccountIdentifier(AccountIdentifier accountIdentifier, ProgramCode programCode)
        {
            var result = new List<Tuple<long, DateTime?>>();
            var parameters = new[]
            {
                new SqlParameter {ParameterName = "LinkedAccountIdentifier", Value = accountIdentifier.ToString()},
                new SqlParameter {ParameterName = "ProgramCode", Value = programCode.ToString()}

            };
            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountDetailsByLinkedAccountIdentifier]",
                _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    var accountLinkKey = reader["AccountLinkKey"] == DBNull.Value
                        ? 0
                        : Convert.ToInt64(reader["AccountLinkKey"]);
                    var endDate = reader["EndDate"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(reader["EndDate"]);
                    if (accountLinkKey != 0)
                    {
                        result.Add(new Tuple<long, DateTime?>(accountLinkKey, endDate));
                    }
                }
            }
            return result;
        }
        public void UpdateAccountToken(string accountIdentifier, string partnerAccountIdentifier)
        {
            var updateAccountTokenParams = new[] {
                new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                new SqlParameter {ParameterName = "AccountIdentifier", Value = accountIdentifier },
                new SqlParameter {ParameterName = "AccountToken", Value = partnerAccountIdentifier}
            };

            try
            {
                _dataAccess.ExecuteScalar("[dbo].[UpdAccountTokenByAccountIdentifier]", _dataAccess.CreateConnection(), updateAccountTokenParams);
            }
            catch (Exception ex)
            {
                Logger.Error($"UpdateAccountToken accountIdentifier {accountIdentifier} : {ex}");
                throw;
            }
        }

        public void UpdateIsPrimaryAccountHolder(string accountHolderIdentifier)
        {
            var updateAccountTokenParams = new[] {
                new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                new SqlParameter {ParameterName = "AccountHolderIdentifier", Value = accountHolderIdentifier }
                            };

            try
            {
                _dataAccess.ExecuteScalar("[dbo].[UpdPrimaryAccountHolderFlag]", _dataAccess.CreateConnection(), updateAccountTokenParams);
            }
            catch (Exception ex)
            {
                Logger.Error($"UpdateIsPrimaryAccountHolder accountHolderIdentifier {accountHolderIdentifier} : {ex}");
                throw;
            }
        }


        /// <summary>
        /// SetCustomerAccountNumber
        /// </summary>
        private string SetCustomerAccountNumber(string arnPrefix)
        {
            string prefix = RandomString(3);
            if (!string.IsNullOrEmpty(arnPrefix))
            {
                if (arnPrefix.Length == 2)
                    prefix = arnPrefix + RandomString(2);
                else
                    throw new Exception($"ArnPrefix {arnPrefix} is incorrect length");
            }

            Guid customerAccountNumber = Guid.NewGuid();

            Byte[] buffer = new byte[17];

            Array.Copy(customerAccountNumber.ToByteArray(), buffer, 7);

            Lcg rand = new Lcg(Fnv1a64Hash.Hash(buffer));

            var sb = new StringBuilder();

            for (int i = 0; i < 7; i++)
                sb.Append(rand.Next() % 10);

            return prefix + sb;
        }


        private string RandomString(int length)
        {
            const string valid = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            StringBuilder res = new StringBuilder();
            using (RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider())
            {
                byte[] uintBuffer = new byte[sizeof(uint)];

                while (length-- > 0)
                {
                    rng.GetBytes(uintBuffer);
                    uint num = BitConverter.ToUInt32(uintBuffer, 0);
                    res.Append(valid[(int)(num % (uint)valid.Length)]);
                }
            }

            return res.ToString();
        }


        /// <summary>
        /// SetAccountNumber
        /// </summary>
        private string SetAccountNumber(string achPrefix, int length, bool disableHeader)
        {
            if (OptionsContext.Current.IsDefined("X-GD-Bos-Duplicate-AccountNumber") && !disableHeader)
            {
                if (!string.IsNullOrEmpty(OptionsContext.Current.GetString("X-GD-Bos-Duplicate-AccountNumber")))
                    return OptionsContext.Current.GetString("X-GD-Bos-Duplicate-AccountNumber");
            }

            Guid accountIdentifier = Guid.NewGuid();

            Byte[] buffer = new byte[17];

            Array.Copy(accountIdentifier.ToByteArray(), buffer, 11);

            Lcg rand = new Lcg(Fnv1a64Hash.Hash(buffer));

            var sb = new StringBuilder();

            for (int i = 0; i < length; i++)
                sb.Append(rand.Next() % 10);

            string accountNumber = achPrefix + sb;

            return accountNumber;
        }

        public (AccountStatus, List<AccountStatusReason>, AccountHolderCure) GetStatus(Guid accountIdentifier)
        {
            if (accountIdentifier == null)
                return (AccountStatus.Unknown, new List<AccountStatusReason>(), AccountHolderCure.Unknown);

            var account = GetAccountInfoByAccountIdentifier(accountIdentifier);

            if (account == null)
                return (AccountStatus.Unknown, new List<AccountStatusReason>(), AccountHolderCure.Unknown);

            var cure = account.AccountHolders?.FirstOrDefault()?.AccountHolderCure;

            return (account.AccountStatus, account.AccountStatusReasons, cure == null ? AccountHolderCure.Unknown : cure.Value);
        }

        public List<AccountLink> GetLinkedAccounts(AccountIdentifier accountIdentifier)
        {
            var stopwatch = Stopwatch.StartNew();

            List<AccountLink> accounts = new List<AccountLink>();
            var input = new[]
            {
                new SqlParameter {ParameterName = "AccountIdentifier", Value = accountIdentifier.ToGuid()},
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetLinkedAccounts]", _dataAccess.CreateConnection(), input))
            {
                while (reader.Read())
                {
                    var acc = new AccountLink();
                    acc.AccountLinkKey = long.Parse(reader["AccountLinkKey"].ToString());
                    acc.PrimaryAccountIdentifier = reader["PrimaryAccountIdentifier"].ToString();
                    acc.LinkAccountIdentifier = reader["LinkedAccountIdentifier"].ToString();
                    acc.StartDate = reader["StartDate"] == DBNull.Value ? (DateTime?)null : (DateTime)reader["StartDate"];
                    acc.EndDate = reader["EndDate"] == DBNull.Value ? (DateTime?)null : (DateTime)reader["EndDate"];
                    acc.AccountLinkType = (AccountLinkType)Enum.Parse(typeof(AccountLinkType), reader["AccountLinkTypeKey"].ToString());
                    acc.PrimaryAccountStatus = reader["PrimaryAccountStatusKey"] == null ? AccountStatus.Unknown : (AccountStatus)Cast<short>(reader["PrimaryAccountStatusKey"]);
                    acc.LinkAccountStatus = reader["LinkedAccountStatusKey"] == null ? AccountStatus.Unknown : (AccountStatus)Cast<short>(reader["LinkedAccountStatusKey"]);
                    acc.LinkedAccountKey = long.Parse(reader["LinkedAccountKey"].ToString());
                    accounts.Add(acc);
                }
            }

            // optional log stopwatch
            stopwatch.Stop();
            if (_requestHandlerSettings.LogStopwatch || OptionsContext.Current.ContainsKey("X-GD-LogStopwatch"))
            {
                Logger.Info(
                        "[{Class}.{Method}] retrieved by identifier {identifier} in {elapsedMs:F3} ms",
                        nameof(AccountRepository),
                        nameof(GetLinkedAccounts),
                        accountIdentifier,
                        stopwatch.Elapsed.TotalMilliseconds);
            }

            return accounts;
        }

        public List<AccountLinkDetail> GetLinkedAccountDetails(AccountIdentifier accountIdentifier)
        {
            List<AccountLinkDetail> accounts = new List<AccountLinkDetail>();
            var input = new[]
            {
                new SqlParameter {ParameterName = "AccountIdentifier", Value = accountIdentifier.ToGuid()},
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetLinkedAccountsByAccountIdentifier]", _dataAccess.CreateConnection(), input))
            {
                while (reader.Read())
                {
                    var acc = new AccountLinkDetail();
                    acc.AccountLinkKey = long.Parse(reader["AccountLinkKey"].ToString());
                    acc.PrimaryAccountIdentifier = reader["PrimaryAccountIdentifier"].ToString();
                    acc.LinkAccountIdentifier = reader["LinkedAccountIdentifier"].ToString();
                    acc.StartDate = reader["StartDate"] == DBNull.Value ? (DateTime?)null : (DateTime)reader["StartDate"];
                    acc.EndDate = reader["EndDate"] == DBNull.Value ? (DateTime?)null : (DateTime)reader["EndDate"];
                    acc.AccountLinkType = (AccountLinkType)Enum.Parse(typeof(AccountLinkType), reader["AccountLinkTypeKey"].ToString());
                    acc.PrimaryAccountStatus = reader["PrimaryAccountStatusKey"] == null ? AccountStatus.Unknown : (AccountStatus)Cast<short>(reader["PrimaryAccountStatusKey"]);
                    acc.LinkAccountStatus = reader["LinkedAccountStatusKey"] == null ? AccountStatus.Unknown : (AccountStatus)Cast<short>(reader["LinkedAccountStatusKey"]);
                    acc.LinkAccountStatusReasonList = new List<AccountStatusReason>();
                    accounts.Add(acc);
                }

                reader.NextResult();

                while (reader.Read())
                {
                    var linkKey = long.Parse(reader["AccountLinkKey"].ToString());
                    var linkedAccount = accounts.FirstOrDefault(al => al.AccountLinkKey == linkKey);
                    if (linkedAccount == null)
                    {
                        continue;
                    }
                    var statusReason = reader["AccountStatusReasonKey"] == null ? AccountStatusReason.unknown : (AccountStatusReason)Cast<short>(reader["AccountStatusReasonKey"]);
                    if (!linkedAccount.LinkAccountStatusReasonList.Contains(statusReason))
                    {
                        linkedAccount.LinkAccountStatusReasonList.Add(statusReason);
                    }
                }
            }
            return accounts;
        }

        public BinType GetAccountBinType(AccountIdentifier accountIdentifier)
        {
            var result = BinType.Unknown;
            var parameters = new[]
            {
                new SqlParameter {ParameterName = "@AccountIdentifier", Value = accountIdentifier.ToString()}

            };
            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetBinTypeByAccountIdentifier]", _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    result = (BinType)(reader["BINTypeKey"] == DBNull.Value ? (short)0 : (short)reader["BINTypeKey"]);
                }
            }
            return result;
        }

        public List<Account> GetAccountsBySccAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            var accounts = new List<Account>();
            var parameters = new[] {
                new SqlParameter() {  ParameterName = "@AccountIdentifier",Value = accountIdentifier.ToString()}
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountHolderBySCCAccountIdentifier]",
                _dataAccess.CreateConnection(), parameters))
            {

                while (reader.Read())
                {
                    var accountId = (Guid)reader["AccountIdentifier"];
                    Account account = new Account(accountId);
                    account.BinType = (BinType)(reader["BINTypeKey"] == DBNull.Value
                        ? (short)0
                        : (short)reader["BINTypeKey"]);
                    account.AccountStatus = (AccountStatus)(reader["AccountStatusKey"] == DBNull.Value
                        ? (short)0
                        : (short)reader["AccountStatusKey"]);

                    account.AccountHolderCureKey = (AccountHolderCure)(reader["AccountHolderCureKey"] == DBNull.Value
                        ? (short)0
                        : (short)reader["AccountHolderCureKey"]);

                    accounts.Add(account);
                }
            }

            return accounts;
        }

        public List<Account> GetAccountBalanceBySccAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            var accounts = new List<Account>();
            var parameters = new[] {
                new SqlParameter() {  ParameterName = "@AccountIdentifier",Value = accountIdentifier.ToString()}
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountInfoBySccAccountIdentifier]",
                _dataAccess.CreateConnection(), parameters))
            {

                while (reader.Read())
                {
                    var accountId = (Guid)reader["AccountIdentifier"];
                    var accountBalanceId = AccountBalanceIdentifier.FromString(reader["AccountBalanceIdentifier"].ToString());
                    var isPrimary = Convert.ToInt16(reader["AccountBalanceTypeKey"]) == 1;
                    var isHolding = Convert.ToInt16(reader["AccountBalanceTypeKey"]) == 3;
                    var userDescription = reader["UserDescription"] == DBNull.Value
                        ? ""
                        : reader["UserDescription"].ToString();
                    var isHidden = reader["IsHidden"] != DBNull.Value && (bool)reader["IsHidden"];
                    var accountBalance = new AccountBalance(accountBalanceId, isPrimary, isHolding, userDescription, isHidden);
                    accountBalance.AccountBalanceKey = (long)reader["AccountBalanceKey"];
                    accountBalance.AccountBalanceType =
                        (AccountBalanceType)(reader["AccountBalanceTypeKey"] == DBNull.Value
                            ? 1
                            : (short)reader["AccountBalanceTypeKey"]);
                    var ledgerBalance = reader["LedgerBalance"] == DBNull.Value ? 0 : (decimal)reader["LedgerBalance"];
                    var ledgerBalanceDate = reader["LedgerBalanceAsOfDate"] == DBNull.Value ? (DateTime?)null : (DateTime?)reader["LedgerBalanceAsOfDate"];
                    var availableBalance = reader["AvailableBalance"] == DBNull.Value
                        ? 0
                        : (decimal)reader["AvailableBalance"];
                    var availableBalanceDate = reader["AvailableBalanceAsOfDate"] == DBNull.Value ? (DateTime?)null : (DateTime?)reader["AvailableBalanceAsOfDate"];
                    accountBalance.SetCurrentBalance(ledgerBalance, ledgerBalanceDate);
                    accountBalance.SetAvailableBalance(availableBalance, availableBalanceDate);
                    accountBalance.Status = (PurseStatus)(reader["AccountBalanceStatusKey"] == DBNull.Value
                        ? 1
                        : (short)reader["AccountBalanceStatusKey"]);
                    accountBalance.GoalAmount = reader["GoalAmount"] == DBNull.Value ? 0 : (decimal)reader["GoalAmount"];
                    accountBalance.CreateDate =
                        reader["CreateDate"] == DBNull.Value ? null : (DateTime?)reader["CreateDate"];
                    accountBalance.ChangeDate =
                        reader["ChangeDate"] == DBNull.Value ? null : (DateTime?)reader["ChangeDate"];
                    accountBalance.PurseNumber = reader["AccountBalanceNumber"] == DBNull.Value
                        ? ""
                        : reader["AccountBalanceNumber"].ToString();
                    Account account = new Account(accountId, null, accountBalanceId, accountBalance);
                    account.BinType = (BinType)(reader["BINTypeKey"] == DBNull.Value
                        ? (short)0
                        : (short)reader["BINTypeKey"]);
                    account.AccountStatus = (AccountStatus)(reader["AccountStatusKey"] == DBNull.Value
                        ? (short)0
                        : (short)reader["AccountStatusKey"]);
                    account.AccountKey = (long)reader["AccountKey"];
                    accounts.Add(account);
                }
            }

            return accounts;
        }

        public short GetProductTierClassByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountInfoByAccountIdentifier]",
                    _dataAccess.CreateConnection(), new SqlParameter
                    {
                        ParameterName = "AccountIdentifier",
                        Value = accountIdentifier.ToString()
                    }))
                {
                    if (reader.Read())
                    {
                        return (short)(reader["ProductTierClassKey"] != DBNull.Value ? reader["ProductTierClassKey"] : 0);
                    }
                }
                throw new Exception($"No ProductTierClassKey found for GetProductTierClassByAccountIdentifier. AccountIdentifier : {accountIdentifier}");
            }
            catch (SqlException ex)
            {
                Logger.Error(
                    $"AccountRepository.GetProductTierClassByAccountIdentifier, error occurred when retrieving account identifier {accountIdentifier} : {ex}");
                throw;
            }
        }

        public List<AccountStatusReason> GetActiveAccountStatusReasons(AccountIdentifier accountIdentifier)
        {
            List<AccountStatusReason> accountStatusReasons = new List<AccountStatusReason>();
            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountStatusReasonByAccountIdentifier]",
                    _dataAccess.CreateConnection(), new SqlParameter
                    {
                        ParameterName = "AccountIdentifier",
                        Value = accountIdentifier.ToString()
                    }))
                {
                    while (reader.Read())
                    {
                        accountStatusReasons.Add((AccountStatusReason)Enum.Parse(typeof(AccountStatusReason), reader["AccountStatusReasonKey"] != DBNull.Value ? reader["AccountStatusReasonKey"].ToString() : "unknown2"));
                    }
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(
                    $"AccountRepository.GetActiveAccountStatusReasons, error occurred when retrieving accountstatusreasons for account identifier {accountIdentifier} : {ex}");
                throw;
            }

            return accountStatusReasons;
        }

        public Shared.Common.Core.CoreApi.Contract.Message.Response.GetPursesResponse GetPurses(string accountIdentifier, string programCode)
        {
            Shared.Common.Core.CoreApi.Contract.Message.Response.GetPursesResponse getAccountResponse = null;
            SqlParameter[] parameters;

            try
            {
                parameters = new[]
                {
                  new SqlParameter() { ParameterName = "AccountIdentifier",Value = Guid.Parse(accountIdentifier) }
                };
            }// Try/Catch added to validate the accountidentifier (GUID) and catch the exception upfront before sending to database
            catch (Exception ex) { throw new AccountNotFoundException(); }

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountBalanceByAccountIdentifier]", _dataAccess.CreateConnectionWithColumnEncryption(), parameters))
            {

                var purses = new List<Purse>();
                while (reader.Read())
                {
                    var purse = new Purse
                    {
                        PurseIdentifier = reader["AccountBalanceIdentifier"].ToString(),
                        PurseType = (PurseType)(short)reader["AccountBalanceTypeKey"],
                        AvailableBalance = reader["AvailableBalance"] == DBNull.Value ? 0 : (decimal)reader["AvailableBalance"],
                        LedgerBalance = reader["LedgerBalance"] == DBNull.Value ? 0 : (decimal)reader["LedgerBalance"],
                        AvailableBalanceAsOfDateTime = reader["AvailableBalanceAsOfDate"] == DBNull.Value ? DateTime.Now : (DateTime?)reader["AvailableBalanceAsOfDate"],
                        LedgerBalanceAsOfDateTime = reader["LedgerBalanceAsOfDate"] == DBNull.Value ? DateTime.Now : (DateTime?)reader["LedgerBalanceAsOfDate"],
                        PurseDescription = reader["UserDescription"] == DBNull.Value ? null : reader["UserDescription"].ToString(),
                        IsHidden = reader["IsHidden"] != DBNull.Value && ((bool)reader["IsHidden"]),
                        Status = (PurseStatus)(short)reader["AccountBalanceStatusKey"],
                        GoalAmount = reader["GoalAmount"] == DBNull.Value ? null : (decimal?)reader["GoalAmount"],
                        GoalDate = reader["GoalDate"] == DBNull.Value ? null : (DateTime?)reader["GoalDate"],
                        IconName = reader["IconName"] == DBNull.Value ? null : reader["IconName"].ToString(),
                        CreateDate = reader["CreateDate"] == DBNull.Value ? null : (DateTime?)reader["CreateDate"],
                        ChangeDate = reader["ChangeDate"] == DBNull.Value ? null : (DateTime?)reader["ChangeDate"],
                        PurseNumber = reader["AccountBalanceNumber"] == DBNull.Value ? null : reader["AccountBalanceNumber"].ToString(),
                        PurseSubType = reader["AccountBalanceTypeSubCategory"] == DBNull.Value ? null : reader["AccountBalanceTypeSubCategory"].ToString(),
                        IsRoundUp = reader["IsRoundUp"] != DBNull.Value && ((bool)reader["IsRoundUp"])
                    };

                    purses.Add(purse);
                }

                if (purses.Count > 0)
                {
                    getAccountResponse = new Shared.Common.Core.CoreApi.Contract.Message.Response.GetPursesResponse { Purses = purses.ToArray() };
                }

                return getAccountResponse;
            }
        }

        public List<Account> GetAccountsBySsnToken(string ssnToken)
        {
            var accounts = new List<Account>();
            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountInfoBySSNToken]",
                    _dataAccess.CreateConnection(), new SqlParameter
                    {
                        ParameterName = "SSNToken",
                        Value = ssnToken
                    }))
                {
                    while (reader.Read())
                    {
                        accounts.Add(new Account()
                        {
                            AccountKey = (long)reader["AccountKey"],
                            AccountStatus = (AccountStatus)(short)reader["AccountStatusKey"],

                        });
                    }

                    return accounts;
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(
                    $"AccountRepository.GetAccountInfoBySSNToken, error occurred when retrieving accounts by SSN token : {ex}");
                throw;
            }
        }


        public Tuple<Guid, string> GetAccountIdentifierByTokenizedPan(string tokenizedPan)
        {
            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetPaymentInstrumentByTokenizedPan]",
                    _dataAccess.CreateConnection(), new SqlParameter
                    {
                        ParameterName = "TokenizedPAN",
                        Value = tokenizedPan
                    }))
                {
                    while (reader.Read())
                    {
                        var accountIdentifier = reader["AccountIdentifier"] == DBNull.Value ? Guid.Empty : reader.GetGuid(reader.GetOrdinal("AccountIdentifier"));
                        var programCode = reader["ProgramCode"] == DBNull.Value ? "" : reader["ProgramCode"].ToString();
                        return new Tuple<Guid, string>(accountIdentifier, programCode);
                    }

                    return new Tuple<Guid, string>(Guid.Empty, "");
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(
                    $"AccountRepository.GetAccountIdentifierByTokenizedPan, error occurred when retrieving accounts by TokenizedPan : {ex}");
                throw;
            }
        }

        public List<AccountHolderInfo> GetJointAccountHolderListByAccountIdentifier(Guid accountIdentifier)
        {
            return _cache.GetOrCreate(accountIdentifier, entry =>
            {
                Logger.Info($"GetJointAccountHolderListByAccountIdentifier - " +
                    $"The cache is empty, getting data from db. " +
                    $"AccountIdentifier: {accountIdentifier}");

                entry.SetAbsoluteExpiration(TimeSpan.FromMilliseconds(_settings.JointAccountHolderListCacheExpirationInMilliseconds));

                entry.RegisterPostEvictionCallback((key, value, reason, state) =>
                {
                    Logger.Info($"GetJointAccountHolderListByAccountIdentifier - Cache entry with key '{key}' was removed. Reason: {reason}");
                });

                List<AccountHolderInfo> returnAccountHolderInfos = new List<AccountHolderInfo>();
                
                SqlParameter[] parameters =
                {
                    new SqlParameter() 
                    {
                        ParameterName = "@AccountIdentifier", 
                        SqlDbType = SqlDbType.UniqueIdentifier, 
                        Value = accountIdentifier
                    }
                };

                using (var reader = _dataAccess.ExecuteReader(
                    GetIndividualAccountHolderSP,
                    _dataAccess.CreateConnection(), 
                    parameters))
                {
                    while (reader.Read())
                    {
                        AccountHolderInfo accountHolderInfo = new AccountHolderInfo();
                        accountHolderInfo.AccountHolderIdentifier = ((Guid)reader["AccountHolderIdentifier"]).ToString();
                        accountHolderInfo.UserIdentifier = ((Guid)reader["ConsumerProfileIdentifier"]).ToString();
                        accountHolderInfo.PaymentIdentifier = ((Guid)reader["PaymentIdentifier"]).ToString();
                        returnAccountHolderInfos.Add(accountHolderInfo);
                    }
                }

                Logger.Info($"GetJointAccountHolderListByAccountIdentifier - " +
                    $"Cache loaded successfully. " +
                    $"AccountIdentifier: {accountIdentifier}");
                
                return returnAccountHolderInfos;
            });
        }

        public void VerifyEmailLimitByProgram(string programCode, string email, int responseCodeWhenThrowException, long? accountKey = null)
        {
            var accountKeys = new List<long>();

            var parameters = new[]
            {
                new SqlParameter() {ParameterName = "@Email", SqlDbType = SqlDbType.NVarChar, Value = email}
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountDetailByConsumerEmail]", _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {

                    var accountKeyInDb = (long)reader["AccountKey"];
                    var accountStatus = (AccountStatus)(short)reader["AccountStatusKey"];
                    var programCodeInDb = reader["ProgramCode"].ToString();

                    if (programCode.Equals(programCodeInDb, StringComparison.CurrentCultureIgnoreCase) &&
                        accountKeyInDb != accountKey &&
                        accountStatus != AccountStatus.Pending)
                    {
                        accountKeys.Add(accountKeyInDb);
                    }
                }
            }

            if (accountKeys.Distinct().Any())
            {
                throw new RequestHandlerException(responseCodeWhenThrowException, 69, "Number of Email Exceeded.");
            }
        }

        public AccountForCBS GetAccountByAccountIdentifierForCBS(string AccountIdentifier)
        {
            var account = new AccountForCBS();
            var parameters = new[]
            {
                new SqlParameter {ParameterName = "AccountIdentifier", Value = AccountIdentifier}
            };
            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountByAccountIdentifierForCBS]",
                       _dataAccess.CreateConnection(), parameters))
            {
                if (reader.Read())
                {
                    account.ACIAccountExternalID = reader["ACIAccountExternalID"].ToString();
                    account.ACIAccountSystemKey = reader["ACIAccountSystemKey"].ToString();
                    account.AccountKey = (long)reader["AccountKey"];
                }
            }
            return account;
        }

        public void UpdateAccountNumber(Guid accountIdentifier, string accountNumber)
        {
            var parms = new[]
            {
                new SqlParameter {ParameterName = "@AccountIdentifier",Value = accountIdentifier},
                new SqlParameter {ParameterName = "@AccountNumber", Value = accountNumber},
            };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdAccountNumberByAccountIdentifier]", _dataAccess.CreateConnection(), parms);
        }

        public List<Tuple<int, string>> GetIdentityTokenByAccountIdentity(string accountIdentifier, string programCode)
        {
            var identityTokens = new List<Tuple<int, string>>();

            SqlParameter[] sqlParameters =
            {
                    new SqlParameter() { ParameterName = "AccountIdentifier",Value = accountIdentifier },
                    new SqlParameter() {  ParameterName = "ProgramCode",Value = programCode }
            };
            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccount]", _dataAccess.CreateConnection(), sqlParameters))
                {
                    do
                    {
                        DataReaderMatchingValueSet(reader,
                            (r, index) => r.GetName(index) == "IdentityToken",
                            r =>
                            {
                                if (reader["IdentityTypeKey"] != DBNull.Value && reader["IdentityTypeKey"] != DBNull.Value)
                                {
                                    identityTokens.Add(new Tuple<int, string>(reader.GetInt16(reader.GetOrdinal("IdentityTypeKey")), reader.GetString(reader.GetOrdinal("IdentityToken"))));
                                }
                            });

                    } while (reader.NextResult());

                    return identityTokens;
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(
                    $"AccountRepository.GetIdentityTokenByAccountIdentity, error occurred when get IdentityToken  : {ex}");
                throw;
            }
        }

        public List<Guid> GetAccountIdentitisByIdentityToken(List<Tuple<int, string>> identityTokens)
        {
            var accountIdentities = new List<Guid>();
            try
            {
                using (var connection = _dataAccess.CreateConnection())
                {
                    identityTokens.ForEach(identity =>
                    {
                        SqlParameter[] sqlParameters =
                        {
                          new SqlParameter() { ParameterName = "IdentityToken", DbType = DbType.String,Value = identity.Item2  },
                          new SqlParameter() {  ParameterName = "IdentityTypeKey", DbType = DbType.Int16, Value = identity.Item1 }
                        };
                        using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountInfoByIdentity]", connection, sqlParameters))
                        {
                            do
                            {
                                DataReaderMatchingValueSet(reader, (r, index) => r.GetName(index) == "AccountIdentifier", r =>
                                {
                                    if (r["AccountIdentifier"] != DBNull.Value)
                                    {
                                        accountIdentities.Add(r.GetGuid(r.GetOrdinal("AccountIdentifier")));
                                    }
                                });
                            } while (reader.NextResult());
                        }
                    });
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(
                    $"AccountRepository.GetAccountIdentitisByIdentityToken, error occurred when get AccountIdentity  : {ex}");
                throw;
            }
            return accountIdentities;
        }

        public void InsAccountFeeTypeOverRide(AccountFeeTypeOverRide accountFeeTypeOverRide)
        {

            var sqlParameters = new[]
            {
                new SqlParameter()
                {
                    ParameterName = "@IP_AccountKey", DbType = DbType.Int64, Value = accountFeeTypeOverRide.AccountKey
                },
                new SqlParameter()
                {
                    ParameterName = "@IP_FeeTypeKey", DbType = DbType.Int16, Value = accountFeeTypeOverRide.FeeTypeKey
                },
                new SqlParameter()
                {
                    ParameterName = "@IP_FeeAmount", DbType = DbType.Decimal, Value = accountFeeTypeOverRide.FeeAmount
                },
                new SqlParameter()
                {
                    ParameterName = "@IP_FrequencyKey", DbType = DbType.Int16,
                    Value = accountFeeTypeOverRide.FrequencyKey
                },
                new SqlParameter()
                {
                    ParameterName = "@IP_OverRideStartDate", DbType = DbType.DateTime,
                    Value = accountFeeTypeOverRide.OverRideStartDate
                },
                new SqlParameter()
                {
                    ParameterName = "@IP_OverRideEndDate",
                    Value = accountFeeTypeOverRide.OverRideEndDate == null
                        ? DBNull.Value
                        : accountFeeTypeOverRide.OverRideEndDate
                },
                new SqlParameter()
                {
                    ParameterName = "@IP_OverRideReason", DbType = DbType.String,
                    Value = accountFeeTypeOverRide.OverRideReason
                },
                new SqlParameter()
                {
                    ParameterName = "@IP_FeeChargeCount", Value = DBNull.Value
                },
                new SqlParameter()
                {
                    ParameterName = "@IP_FeeChargeDurationKey",
                    Value = DBNull.Value
                },
            };
            using var connection = _dataAccess.CreateConnection();
            _dataAccess.ExecuteNonQuery("[dbo].[InsAccountFeeTypeOverRide]", connection, sqlParameters);
        }

        public List<AccountFeeTypeOverRide> GetAccountFeeTypeOverRideByAccountKeys(List<long> accountKeys,
            FeeType feeType)
        {
            var accountFeeTypeOverRides = new List<AccountFeeTypeOverRide>();
            var dt = new DataTable();
            dt.Columns.Add("AccountKey");
            foreach (var accountKey in accountKeys)
            {
                var newRow = dt.NewRow();
                newRow["AccountKey"] = accountKey;
                dt.Rows.Add(newRow);
            }

            var parameters = new[]
            {
                new SqlParameter()
                {
                    ParameterName = "AccountKeys", SqlDbType = SqlDbType.Structured, Value = dt,
                    TypeName = "typeAccountKey"
                },
                new SqlParameter()
                    { ParameterName = "FeeTypeKey", SqlDbType = SqlDbType.SmallInt, Value = (short)feeType },
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountFeeTypeOverRideByAccountKeys]",
                       _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    accountFeeTypeOverRides.Add(new AccountFeeTypeOverRide()
                    {
                        AccountFeeTypeOverRideKey = (long)reader["AccountFeeTypeOverRideKey"],
                    });
                }
            }

            return accountFeeTypeOverRides;
        }

        public void UpdAccountFeeTypeOverRide(long accountFeeTypeOverRideKey, DateTime overRideEndDate)
        {
            var sqlParameters = new[]
            {
                new SqlParameter()
                {
                    ParameterName = "@IP_AccountFeeTypeOverRideKey", DbType = DbType.Int64,
                    Value = accountFeeTypeOverRideKey
                },
                new SqlParameter()
                    { ParameterName = "@IP_OverRideEndDate", DbType = DbType.DateTime, Value = overRideEndDate }
            };
            using var connection = _dataAccess.CreateConnection();
            _dataAccess.ExecuteNonQuery("[dbo].[UpdAccountFeeTypeOverRide]", connection, sqlParameters);
        }

        private void DataReaderMatchingValueSet(IDataReader reader, Func<IDataReader, int, bool> predicate, Action<IDataReader> action)
        {
            var isReadTable = false;
            for (int i = 0; i < reader.FieldCount; i++)
            {
                isReadTable = predicate(reader, i);
                if (isReadTable)
                {
                    break;
                }
            }
            if (isReadTable)
            {
                while (reader.Read())
                {
                    action(reader);
                }
            }
        }

        public ProductInfoDetail GetProductInfoByAccountIdentifier(Guid accountIdentifier)
        {
            var productInfoDetail = new ProductInfoDetail();
            var parameters = new[]
            {
                new SqlParameter { ParameterName = "AccountIdentifier", Value = accountIdentifier }
            };
            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetProductInfoByAccountIdentifier]",
                       _dataAccess.CreateConnection(), parameters))
            {
                if (reader.Read())
                {
                    productInfoDetail.ProductCode = reader["ProductCode"]?.ToString();
                    productInfoDetail.ProductName = reader["ProductName"]?.ToString();
                    productInfoDetail.ProgramCode = reader["ProgramCode"]?.ToString();
                    productInfoDetail.ProgramName = reader["ProgramName"]?.ToString();
                    productInfoDetail.AccountStatusKey = Convert.ToInt16(reader["AccountStatusKey"] == DBNull.Value ? 0 : reader["AccountStatusKey"]);
                    productInfoDetail.ProductTierKey = Convert.ToInt32(reader["ProductTierKey"] == DBNull.Value ? 0 : reader["ProductTierKey"]);
                    productInfoDetail.ProductKey = Convert.ToInt32(reader["ProductKey"] == DBNull.Value ? 0 : reader["ProductKey"]);
                    productInfoDetail.PartnerKey = Convert.ToInt16(reader["PartnerKey"] == DBNull.Value ? 0 : reader["PartnerKey"]);
                }
            }
            return productInfoDetail;
        }

        //public List<AccountStatusReasonFisCodeMapping> GetAccountStatusReasonFISCodeMapping()
        //{
        //    List<AccountStatusReasonFisCodeMapping> listAccountStatusReason_FISCodeMapping = new List<AccountStatusReasonFisCodeMapping>();
        //    SqlConnection connection = null;

        //        connection = _dataAccess.CreateConnection();
        //        var command = connection.CreateCommand();

        //        command.CommandType = CommandType.StoredProcedure;
        //        command.CommandText = "GetAccountStatusReason_FISCodeMapping";
        //        connection.Open();

        //        using (var reader = command.ExecuteReader())
        //        {

        //            while (reader.Read())
        //            {
        //            AccountStatusReasonFisCodeMapping mapping = new AccountStatusReasonFisCodeMapping();
        //                mapping.CreateDate = reader["CreateDate"] == DBNull.Value ? DateTime.MinValue : reader.GetDateTime(reader.GetOrdinal("CreateDate"));
        //                mapping.AccountStatusReasonKey = reader["AccountStatusReasonKey"] == DBNull.Value ? default(short) : reader.GetInt16(reader.GetOrdinal("AccountStatusReasonKey"));
        //                mapping.Description = reader["Description"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Description"));
        //                mapping.FISBlockCode = reader["FISBlockCode"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("FISBlockCode"));
        //                mapping.FISReclassCode = reader["FISReclassCode"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("FISReclassCode"));
        //                mapping.IsOutgoing = reader["IsOutgoing"] == DBNull.Value ? default(bool) : reader.GetBoolean(reader.GetOrdinal("IsOutgoing"));

        //                listAccountStatusReason_FISCodeMapping.Add(mapping);
        //            }
        //        }                    
        //    return listAccountStatusReason_FISCodeMapping;
        //}

        /// <summary>
        /// GetAccountByAccountIdentifier
        /// </summary>
        /// <param name="accountIdentifier"></param>
        /// <param name="programCode"></param>
        /// <param name="includeCardData"></param>
        /// <returns></returns>
        public GetEnrollmentResponse GetEnrollmentByAccountIdentifier(string accountIdentifier, string programCode,
            bool includeCardData)
        {
            GetEnrollmentResponse getEnrollmentResponse = new GetEnrollmentResponse();
            SqlParameter[] parameters;
            string pan = null;

            try
            {
                parameters = new[]
                {
                    new SqlParameter() {ParameterName = "AccountIdentifier", Value = Guid.Parse(accountIdentifier)},
                    new SqlParameter() {ParameterName = "ProgramCode", Value = programCode}
                };
            } // Try/Catch added to validate the account identifier (GUID) and catch the exception upfront before sending to database
            catch (Exception)
            {
                throw new AccountNotFoundException();
            }

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccount]",
                _dataAccess.CreateConnectionWithColumnEncryption(), parameters))
            {
                if (reader.Read())
                {
                    getEnrollmentResponse.Account = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Account
                    {
                        AccountHolders = new List<Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.AccountHolder>(),
                        AccountIdentifier = reader["AccountIdentifier"].ToString(),
                        Status = ((AccountStatus)(short)reader["AccountStatusKey"]).ToString().ToLower()
                    };


                    DateTime accountStatusDateChange = reader.GetDateTime(reader.GetOrdinal("StatusChangeDate"));
                    accountStatusDateChange = accountStatusDateChange.ToUniversalTime();
                    getEnrollmentResponse.Account.AccountStatusChangedDateTime =
                        accountStatusDateChange.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");

                    getEnrollmentResponse.Account.ProductCode = reader["ProductCode"].ToString();
                    var accountProductKey = Convert.ToInt32(reader["ProductKey"]);
                    getEnrollmentResponse.Account.ProductName = reader["ProductName"].ToString();
                    getEnrollmentResponse.Account.DirectDepositInformation = new DirectDepositInformation
                    {
                        AccountNumber = reader["AccountNumber"].ToString(),
                        RoutingNumber = reader["RoutingNumber"].ToString()
                    };
                    getEnrollmentResponse.Account.CustomerReferenceNumber = reader["AccountReferenceNumber"].ToString();
                    getEnrollmentResponse.Account.AccountCycleDay = reader["BillCycleDay"] == DBNull.Value ? (short)0 : (short)reader["BillCycleDay"];

                    reader.NextResult();
                    getEnrollmentResponse.Account.Purses = new List<Purse>();

                    while (reader.Read())
                    {
                        if (reader["AccountBalanceIdentifier"] != DBNull.Value)
                        {
                            getEnrollmentResponse.Account.Currency = reader["CurrencyKey"] == DBNull.Value
                                ? null
                                : ((CurrencyType)(short)reader["CurrencyKey"]).ToString();
                            var purseStatusKey = reader["AccountBalanceStatusKey"] == DBNull.Value
                                ? 1
                                : (short)reader["AccountBalanceStatusKey"];
                            Purse purse = new Purse
                            {
                                PurseIdentifier = reader["AccountBalanceIdentifier"].ToString(),
                                PurseType = (PurseType)(short)reader["AccountBalanceTypeKey"],
                                AvailableBalance = reader["AvailableBalance"] == DBNull.Value
                                    ? 0
                                    : (decimal)reader["AvailableBalance"],
                                LedgerBalance = reader["LedgerBalance"] == DBNull.Value
                                    ? 0
                                    : (decimal)reader["LedgerBalance"],
                                AvailableBalanceAsOfDateTime = reader["AvailableBalanceAsOfDate"] == DBNull.Value
                                    ? DateTime.Now
                                    : (DateTime?)reader["AvailableBalanceAsOfDate"],
                                LedgerBalanceAsOfDateTime = reader["LedgerBalanceAsOfDate"] == DBNull.Value
                                    ? DateTime.Now
                                    : (DateTime?)reader["LedgerBalanceAsOfDate"],
                                PurseDescription = reader["UserDescription"] == DBNull.Value
                                    ? null
                                    : reader["UserDescription"].ToString(),
                                Status = (PurseStatus)purseStatusKey
                            };

                            getEnrollmentResponse.Account.Purses.Add(purse);
                        }
                    }

                    if (getEnrollmentResponse.Account.Purses.Count == 0)
                        getEnrollmentResponse.Account.Purses = null;

                    reader.NextResult();

                    Dictionary<long, string> ahKeyIdentifier = new Dictionary<long, string>();
                    while (reader.Read())
                    {
                        if (Convert.ToInt32(reader["ConsumerProfileTypeKey"]) == 1)
                        {
                            Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.User user = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.User();
                            var accountHolderKey = Convert.ToInt64(reader["AccountHolderKey"]);
                            Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.AccountHolder accountHolder = new Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.AccountHolder();
                            bool isTransferAutoAccept =
                                reader["IsTransferAutoAccept"] != DBNull.Value &&
                                bool.Parse(reader["IsTransferAutoAccept"].ToString());
                            accountHolder.AccountHolderIdentifier = reader["AccountHolderIdentifier"] == DBNull.Value
                                ? null
                                : reader["AccountHolderIdentifier"].ToString();
                            user.PeerTransferAcceptPreference = isTransferAutoAccept == false ? "manual" : "automatic";
                            user.UserIdentifier = reader["ConsumerProfileIdentifier"].ToString();
                            user.ConsumerProfileKey = reader.GetInt64(reader.GetOrdinal("ConsumerProfileKey"));
                            user.FirstName = reader["FirstName"] == DBNull.Value
                                ? string.Empty
                                : reader["FirstName"].ToString();
                            user.LastName = reader["LastName"] == DBNull.Value
                                ? string.Empty
                                : reader["LastName"].ToString();
                            bool isVerified = reader["IsDOBVerified"] == DBNull.Value
                                ? false
                                : Convert.ToBoolean(reader["IsDOBVerified"]);
                            bool isDOBBMatched = reader["IsDOBMatched"] == DBNull.Value
                                ? false
                                : Convert.ToBoolean(reader["IsDOBMatched"]);
                            if (isVerified)
                                user.DobStatus = "verified";
                            else
                                user.DobStatus = isDOBBMatched ? "matched" : "notMatched";
                            user.Status = UserStatus.Active;
                            user.IsPrimaryAccountHolder = reader["IsPrimaryAccountHolder"] != DBNull.Value &&
                                                          (bool)reader["IsPrimaryAccountHolder"];
                            user.DateOfBirth = reader["EncryptedDOB"].ToString();
                            user.SsnSuffux = reader["Last4SSN"] == DBNull.Value ? null : reader["Last4SSN"].ToString();
                            user.KycStateData = new KycStateData
                            {
                                OfacStatus = "pending",
                                KycStatus = "pending"
                            };
                            user.KycStateData.PendingKycGate = reader["AccountHolderCureKey"] == DBNull.Value
                                ? "kyc2"
                                : ((Core.Domain.Model.Account.AccountHolderCure)(short)reader["AccountHolderCureKey"])
                                .ToString().ToLower();
                            user.MiddleName = reader["MiddleName"] == DBNull.Value
                                ? string.Empty
                                : reader["MiddleName"].ToString();

                            ahKeyIdentifier.Add(accountHolderKey, accountHolder.AccountHolderIdentifier);
                            accountHolder.User = user;
                            accountHolder.PaymentInstruments = new List<PaymentInstrument>();
                            getEnrollmentResponse.Account.AccountHolders.Add(accountHolder);
                        }
                    }

                    reader.NextResult();

                    while (reader.Read())
                    {
                        var currentKey = Convert.ToInt64(reader["AccountHolderKey"]);
                        if (ahKeyIdentifier.TryGetValue(currentKey, out string currentAHIdentifier))
                        {
                            var currentAccountHolder = getEnrollmentResponse.Account.AccountHolders.Find(ah =>
                            string.Equals(currentAHIdentifier, ah.AccountHolderIdentifier,
                                    StringComparison.InvariantCultureIgnoreCase));

                            if (includeCardData)
                                pan = _tokenizerService.DeTokenizePan(reader["TokenizedPAN"].ToString());

                            if (reader["PaymentInstrumentIdentifier"] != DBNull.Value)
                            {
                                PaymentInstrument paymentInstrument = new PaymentInstrument
                                {
                                    PaymentInstrumentIdentifier = reader["PaymentInstrumentIdentifier"].ToString(),
                                    PaymentIdentifier = reader["PaymentIdentifier"].ToString(),
                                    PaymentInstrumentType =
                                        (PaymentInstrumentType)(short)reader["PaymentInstrumentTypeKey"],
                                    Status = (PaymentInstrumentStatus)(short)reader["PaymentInstrumentStatusKey"],
                                    IsPinSet = reader["ATMPinSetDate"] != DBNull.Value,
                                    Last4Pan = reader["Last4PAN"].ToString(),
                                    ActivatedDateTime = reader["ActivationDate"] == DBNull.Value
                                        ? null
                                        : (DateTime?)reader["ActivationDate"],
                                    IssuedDateTime = reader["IssuedDateTime"] == DBNull.Value
                                        ? DateTime.Now
                                        : (DateTime)reader["IssuedDateTime"],
                                    PaymentInstrumentStatusReason =
                                        reader.IsDBNull(reader.GetOrdinal("PaymentInstrumentStatusReasonKey"))
                                            ? (PaymentInstrumentStatusReason?)null
                                            : (PaymentInstrumentStatusReason)(short)reader[
                                                "PaymentInstrumentStatusReasonKey"],
                                    PaymentIdentifierStatusReason =
                                        reader.IsDBNull(reader.GetOrdinal("PaymentIdentifierStatusReasonKey"))
                                            ? (PaymentIdentifierStatusReason?)null
                                            : (PaymentIdentifierStatusReason)(short)reader[
                                                "PaymentIdentifierStatusReasonKey"],
                                    CustomCardImageIdentifier = reader["CustomCardImageIdentifier"] == DBNull.Value
                                        ? null
                                        : reader["CustomCardImageIdentifier"].ToString(),
                                    IsTemp = reader["IsTemp"] != DBNull.Value && (bool)reader["IsTemp"]
                                };

                                if ((programCode == "gbr" || programCode == "chirp") &&
                                    Gd.Bos.RequestHandler.Core.Infrastructure.Configuration.Configuration.Current.RetailCardProductCode.Contains(getEnrollmentResponse.Account
                                        .ProductCode))
                                {
                                    bool? IsTemp = reader["IsTemp"] == DBNull.Value ? null : (bool?)reader["IsTemp"];

                                    if (IsTemp.HasValue && IsTemp == true)
                                        paymentInstrument.PaymentInstrumentLevel = PaymentInstrumentLevel.NonPersonalized;
                                    else
                                        paymentInstrument.PaymentInstrumentLevel = PaymentInstrumentLevel.Personalized;
                                }
                                else paymentInstrument.PaymentInstrumentLevel = null;


                                paymentInstrument.ActivatedDateTime =
                                    paymentInstrument.ActivatedDateTime?.ToUniversalTime();
                                paymentInstrument.IssuedDateTime = paymentInstrument.IssuedDateTime?.ToUniversalTime();



                                if (includeCardData && _baasConfiguration.IsPinSetNeed(programCode, paymentInstrument.IsPinSet.Value))
                                {
                                    paymentInstrument.PrivateCardData = new PrivateCardData
                                    {
                                        Pan = pan,
                                        Cvv = null,

                                        ExpirationDate = new CardExpirationDate()
                                    };
                                    paymentInstrument.PrivateCardData.ExpirationDate.CardExpirationMonth =
                                        reader["EncryptedExpirationDate"] == DBNull.Value
                                            ? ""
                                            : reader["EncryptedExpirationDate"].ToString().Substring(0, 2);
                                    paymentInstrument.PrivateCardData.ExpirationDate.CardExpirationyear =
                                        reader["EncryptedExpirationDate"] == DBNull.Value
                                            ? ""
                                            : reader["EncryptedExpirationDate"].ToString().Substring(2, 4);
                                }

                                PaymentIdentifierStatus pIdStatus =
                                    (PaymentIdentifierStatus)(short)reader["PaymentIdentifierStatusKey"];
                                paymentInstrument.Status =
                                    StatusMapper.GetPaymentInstrumentStatus(pIdStatus, paymentInstrument.Status);
                                paymentInstrument.PaymentInstrumentStatusReasons =
                                    StatusMapper.GetPaymentInstrumentStatusReasons(pIdStatus, paymentInstrument.Status,
                                        paymentInstrument.PaymentInstrumentStatusReason,
                                        paymentInstrument.PaymentIdentifierStatusReason);


                                // initialize to "false"
                                paymentInstrument.IsPrivateDataViewable = "false";

                                if (paymentInstrument.PaymentInstrumentType == PaymentInstrumentType.Virtual
                                    && paymentInstrument.Status == PaymentInstrumentStatus.Activated
                                    && _baasConfiguration.IsPinSetNeed(programCode, paymentInstrument.IsPinSet.Value)
                                    && _baasConfiguration.IsPrivateDataViewable(programCode,
                                        paymentInstrument.IssuedDateTime)
                                    && _baasConfiguration.IsCvvViewable(programCode,
                                        paymentInstrument.IssuedDateTime))
                                {
                                    paymentInstrument.IsPrivateDataViewable = "true";
                                }

                                currentAccountHolder.PaymentInstruments.Add(paymentInstrument);
                            }
                        }
                    }

                    foreach (var ah in getEnrollmentResponse.Account.AccountHolders)
                    {
                        if (ah.PaymentInstruments.Count == 0)
                        {
                            ah.PaymentInstruments = null;
                        }
                    }

                    GetAccountInfo(reader, getEnrollmentResponse, ahKeyIdentifier, accountProductKey);

                    reader.NextResult();
                    var userProfileIdentities = ReadUserProfileIdentities(reader);
                    foreach (var accountHolder in getEnrollmentResponse.Account.AccountHolders)
                    {
                        var identity = userProfileIdentities
                            .FindAll(u => u.ConsumerProfileKey == accountHolder.User.ConsumerProfileKey && u.IdentityType != IdentityType.EIN)
                            .OrderByDescending(c => c.CreateDateUtc).FirstOrDefault();
                        accountHolder.SsnToken = identity?.IdentityToken;
                        if (null != identity && identity.IdentityType != 0)
                        {
                            accountHolder.User.IdentityType = identity.IdentityType;
                            accountHolder.User.Last4Identity = identity.Last4Identity;
                        }
                        else
                        {
                            accountHolder.User.IdentityType = null;
                            accountHolder.User.Last4Identity = null;
                        }

                        // https://pd/browse/GBOS-29170 - Uncomment this
                        //if (!accountHolder.User.KycStateData.KycStatus.Equals("passed",
                        //        StringComparison.InvariantCultureIgnoreCase) ||
                        //    !accountHolder.User.KycStateData.OfacStatus.Equals("passed",
                        //        StringComparison.InvariantCultureIgnoreCase))
                        //{
                        //    if (accountHolder.User.KycStateData.PendingKycGate.Equals("none",
                        //        StringComparison.InvariantCultureIgnoreCase))
                        //    {
                        //        if (accountHolder.PaymentInstruments == null || accountHolder.PaymentInstruments.Count == 0)
                        //            accountHolder.User.Status = "regFailedNoCure";
                        //        else
                        //            accountHolder.User.Status = "undefined"; //out of scope in GBOS-27104
                        //    }
                        //    else if (accountHolder.User.KycStateData.PendingKycGate.Equals("healthy",
                        //        StringComparison.InvariantCultureIgnoreCase))
                        //    {
                        //        accountHolder.User.Status = "notAllowed";
                        //    }
                        //    else
                        //    {
                        //        if (accountHolder.PaymentInstruments == null || accountHolder.PaymentInstruments.Count == 0)
                        //            accountHolder.User.Status = "pending";
                        //        else
                        //            accountHolder.User.Status = "undefined"; //out of scope in GBOS-27104
                        //    }
                        //}
                        //else if (accountHolder.User.KycStateData.KycStatus.Equals("passed",
                        //                StringComparison.InvariantCultureIgnoreCase) &&
                        //            accountHolder.User.KycStateData.OfacStatus.Equals("passed",
                        //                StringComparison.InvariantCultureIgnoreCase))
                        //{
                        //    if (accountHolder.PaymentInstruments == null || accountHolder.PaymentInstruments.Count == 0)
                        //    {
                        //        if (accountHolder.User.KycStateData.PendingKycGate.Equals("healthy",
                        //            StringComparison.InvariantCultureIgnoreCase))
                        //        {
                        //            accountHolder.User.Status = "pendingCardCreation";
                        //        }
                        //        else
                        //        {
                        //            accountHolder.User.Status = "notAllowed";
                        //        }
                        //    }
                        //    else
                        //    {
                        //        if (accountHolder.PaymentInstruments.Exists(c =>
                        //            c.Status == PaymentInstrumentStatus.Activated ||
                        //            c.Status == PaymentInstrumentStatus.NotActivated ||
                        //            c.Status == PaymentInstrumentStatus.Blocked))
                        //        {
                        //            accountHolder.User.Status = "active";
                        //        }
                        //        else
                        //        {
                        //            accountHolder.User.Status = "closed";
                        //        }
                        //    }
                        //}
                    }
                }

                return getEnrollmentResponse;
            }
        }

        public (string accountIdentifier, int productKey) GetAccountProductByAccountHolderKey(long accountHolderKey)
        {
            var parameters = new[]
            {
                new SqlParameter()
                    { ParameterName = "@AccountHolderKey", SqlDbType = SqlDbType.BigInt, Value = accountHolderKey },
            };

            using var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountProductByAccountHolderKey]",
                _dataAccess.CreateConnection(), parameters);
            while (reader.Read())
            {
                return (((Guid)reader["AccountIdentifier"]).ToString(), (int)reader["ProductKey"]);
            }
            return (string.Empty, 0);
        }

        /// <summary>
        /// GetAccountInfo
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="getEnrollmentResponse"></param>
        /// <returns></returns>
        private void GetAccountInfo(IDataReader reader, GetEnrollmentResponse getEnrollmentResponse, Dictionary<long, string> ahKeyIdentifier, int accountProductKey)
        {
            reader.NextResult();

            getEnrollmentResponse.Account.StatusReasons = new List<string>();
            while (reader.Read())
            {
                getEnrollmentResponse.Account.StatusReasons.Add(
                    ((Core.Domain.Model.Account.AccountStatusReason)(short)reader["AccountStatusReasonKey"])
                    .ToString());
            }

            if (getEnrollmentResponse.Account.StatusReasons.Count == 0)
                getEnrollmentResponse.Account.StatusReasons = null;

            reader.NextResult();
            Dictionary<long, string> verificationKeyIdentifier = new Dictionary<long, string>();
            var requestTriggerTypes = new Dictionary<long, TriggerType>();
            while (reader.Read())
            {
                var verificationRequestKey = Convert.ToInt64(reader["VerificationRequestKey"]);
                requestTriggerTypes[verificationRequestKey] = (TriggerType)Convert.ToInt16(reader["VerificationTriggerTypeKey"]);
                var accountHolderKey = Convert.ToInt64(reader["AccountHolderKey"]);
                if (ahKeyIdentifier.TryGetValue(accountHolderKey, out string currentAHIdentifier))
                {
                    verificationKeyIdentifier.Add(verificationRequestKey, currentAHIdentifier);
                }
            }

            reader.NextResult();
            while (reader.Read())
            {
                var verificationRequestKey = Convert.ToInt64(reader["VerificationRequestKey"]);
                var isUpgrade = requestTriggerTypes[verificationRequestKey] == TriggerType.AccountUpgrade;
                if (isUpgrade)
                {
                    if (getEnrollmentResponse.Account.UpgradeKycStateData == null)
                    {
                        getEnrollmentResponse.Account.UpgradeKycStateData = new KycStateData();
                    }
                    var activityType = (VerificationActivityType)Convert.ToInt16(reader["VerificationActivityTypeKey"]);
                    var status = (VerificationStatus)Convert.ToInt16(reader["VerificationActivityStatusKey"]);
                    switch (activityType)
                    {
                        case VerificationActivityType.KYC:
                            getEnrollmentResponse.Account.UpgradeKycStateData.KycStatus = status.ToString().ToLower();
                            break;
                        case VerificationActivityType.OFAC:
                            getEnrollmentResponse.Account.UpgradeKycStateData.OfacStatus = status.ToString().ToLower();
                            break;
                        case VerificationActivityType.IDV:
                            if (status == VerificationStatus.Passed)
                                getEnrollmentResponse.Account.UpgradeKycStateData.KycStatus = VerificationStatus.Passed.ToString().ToLower();
                            break;
                    }
                }
                else
                {
                    if (verificationKeyIdentifier.TryGetValue(verificationRequestKey, out string accountHolderIdentifier))
                    {
                        var ah = getEnrollmentResponse.Account.AccountHolders.FirstOrDefault(p => string.Equals(accountHolderIdentifier, p.AccountHolderIdentifier,
                            StringComparison.InvariantCultureIgnoreCase));
                        if (ah != null)
                        {
                            string idvStatus = string.Empty;
                            if (reader["VerificationActivityTypeKey"] != DBNull.Value)
                            {
                                if (Convert.ToInt32(reader["VerificationActivityTypeKey"]) == 2)
                                {
                                    ah.User.KycStateData.OfacStatus =
                                        ((Core.Domain.Model.Account.VerificationStatus)(short)Convert.ToInt32(
                                            reader["VerificationActivityStatusKey"])).ToString().ToLower();
                                }
                                else if (Convert.ToInt32(reader["VerificationActivityTypeKey"]) == 1 ||
                                         Convert.ToInt32(reader["VerificationActivityTypeKey"]) == 11)
                                {
                                    ah.User.KycStateData.KycStatus =
                                        ((Core.Domain.Model.Account.VerificationStatus)(short)Convert.ToInt32(
                                            reader["VerificationActivityStatusKey"])).ToString().ToLower();
                                }
                                else if (Convert.ToInt32(reader["VerificationActivityTypeKey"]) == 5)
                                {
                                    idvStatus =
                                        ((Core.Domain.Model.Account.VerificationStatus)(short)Convert.ToInt32(
                                            reader["VerificationActivityStatusKey"])).ToString().ToLower();
                                }
                            }

                            if (ah.User.KycStateData.KycStatus == "failed" && idvStatus == "passed")
                            {
                                ah.User.KycStateData.KycStatus = "passed";
                            }
                        }
                    }
                }
            }

            reader.NextResult();
            getEnrollmentResponse.Account.TermsAcceptances = new List<TermsAcceptance>();
            while (reader.Read())
            {
                if (reader["IsPrimaryAccountHolder"].Cast<bool>())
                {
                    var brandAgreementTypeIdentifier = reader["BrandAgreementTypeIdentifier"].Cast<string>().Trim();
                    var optOutDate = reader["OptOutDate"].Cast<DateTime?>();
                    var acceptanceDate = reader["AcceptanceDate"].Cast<DateTime>().ToUniversalTime();
                    var hasAccepted = optOutDate == null;
                    if (accountProductKey != Convert.ToInt32(reader["ProductKey"]) && !hasAccepted)
                        continue;
                    getEnrollmentResponse.Account.TermsAcceptances.Add(
                        new TermsAcceptance
                        {
                            TermsIdentifier = brandAgreementTypeIdentifier,
                            TermsAcceptanceDateTime = acceptanceDate.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
                            TermsAcceptanceFlag = hasAccepted
                        });
                }
            }

            //reader.NextResult();

            //foreach (var ah in getEnrollmentResponse.Account.AccountHolders)
            //{
            //    ah.SsnToken = _accountRepository.ReadUserProfileIdentity(reader)?.IdentityToken;
            //}
        }

        private List<Core.Domain.Model.User.UserProfileIdentity> ReadUserProfileIdentities(IDataReader reader)
        {
            var userProfileIdentities = new List<Core.Domain.Model.User.UserProfileIdentity>();
            while (reader.Read())
            {
                var userProfileIdentity = new Core.Domain.Model.User.UserProfileIdentity
                {
                    ConsumerProfileKey = reader.GetInt64(reader.GetOrdinal("ConsumerProfileKey")),
                    IdentityToken = reader.GetString(reader.GetOrdinal("IdentityToken")),
                    Last4Identity = reader["Last4Identity"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Last4Identity")),
                    IdentityType = (IdentityType)(short)reader["IdentityTypeKey"],
                    CreateDateUtc = reader.GetDateTime(reader.GetOrdinal("CreateDate"))
                };

                userProfileIdentities.Add(userProfileIdentity);
            }

            return userProfileIdentities;
        }

        public Account GetAccountByAccountNumber(string accountNumber)
        {
            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountInfoByAccountNumber]",
                    _dataAccess.CreateConnection(), new SqlParameter
                    {
                        ParameterName = "AccountNumber",
                        Value = accountNumber
                    }))
                {
                    Account account = null;
                    while (reader.Read())
                    {
                        var accountIdentifier = AccountIdentifier.FromGuid(Guid.Parse(reader["AccountIdentifier"].ToString()));
                        var productKey = Convert.ToInt32(reader["ProductKey"]);
                        var product = new Product(null, null, productKey, null, null, null);
                        account = new Account(accountIdentifier, product, null)
                        {
                            AccountKey = (long)reader["AccountKey"],
                            AccountStatus = (AccountStatus)(short)reader["AccountStatusKey"],

                            AccountNumber = accountNumber,
                            AccountReferenceNumber = reader["AccountReferenceNumber"] != DBNull.Value ? reader["AccountReferenceNumber"].ToString() : string.Empty,
                            Language = reader["AccountLanguage"] != DBNull.Value ? reader["AccountLanguage"].ToString() : string.Empty,
                            FirstName = reader["FirstName"] != DBNull.Value ? reader["FirstName"].ToString() : string.Empty,
                            LastName = reader["LastName"] != DBNull.Value ? reader["LastName"].ToString() : string.Empty
                        };

                        var accountHolderIdentifier = reader["AccountHolderIdentifier"] != DBNull.Value ? reader["AccountHolderIdentifier"].ToString() : string.Empty;
                        var isPrimaryAccountHolder = reader["IsPrimaryAccountHolder"] != DBNull.Value && reader.GetBoolean(reader.GetOrdinal("IsPrimaryAccountHolder"));

                        AccountHolder ah = new AccountHolder(null, AccountHolderIdentifier.FromString(accountHolderIdentifier), null, isPrimaryAccountHolder);
                        ah.AccountHolderKey = (long)reader["AccountHolderKey"];

                        account.AddAccountHolder(ah);
                    }

                    return account;
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(
                    $"AccountRepository.GetByAccountNumber, error occurred when retrieving account number {accountNumber} : {ex}");
                throw;
            }
        }
        public bool IsJointAccount(string accountIdentifier)
        {
            var accounts = GetLinkedAccountDetails(AccountIdentifier.FromString(accountIdentifier));
            if (accounts == null || accounts.Count == 0)
                return false;
            //jointaccount 
            return accounts.Where(x => x.LinkAccountIdentifier.Equals(accountIdentifier, StringComparison.OrdinalIgnoreCase)
                                      && x.AccountLinkType == AccountLinkType.JointAccount).Any();
        }
        
        public void UpdAccountProductTier(Guid accountIdentifier, int productTierKey)
        {
            try
            {
                using (var cnn = _dataAccess.CreateConnection())
                {
                    var cmd = cnn.CreateCommand();
                    cmd.CommandText = "[dbo].[UpdAccountProductTier]";
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "ChangeBy", Value = IdentityHelper.GetIdentityName() });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "AccountIdentifier", Value = accountIdentifier });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "ProductTierKey", Value = productTierKey });
                    cnn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex, $"UpdAccountProductTier failed, AccountIdentifier:{accountIdentifier}, ProductTierKey:{productTierKey}");
                throw;
            }
        }

        public CollectionAccount GetCollectionAccountByAccountIdentifier(Guid accountIdentifier)
        {
            CollectionAccount collectionAccount = null;
            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "@AccountIdentifier", SqlDbType = SqlDbType.UniqueIdentifier, Value = accountIdentifier}

            };
            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetCollectionAccountByAccountIdentifier]", _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    collectionAccount = new CollectionAccount
                    {
                        CollectionAccountKey = (long)reader["CollectionAccountKey"],
                        AccountKey = (long)reader["AccountKey"],
                        CollectionAccountStatus = (CollectionAccountStatus)((short)reader["CollectionAccountStatusKey"]),
                        CollectionAccountStatusChangeDate = reader["CollectionAccountStatusChangeDate"] == DBNull.Value ? DateTime.MinValue : (DateTime)reader["CollectionAccountStatusChangeDate"]
                    };
                }
            }
            return collectionAccount;
        }

        public List<VerificationActivity> GetVerificationActivities(
            Guid? accountHolderIdentifier, 
            Guid? accountIdentifier,
            Guid? consumerProfileIdentifier, 
            VerificationActivityType verificationActivityType)
        {
            List<VerificationActivity> activities = new List<VerificationActivity>();

            using (var reader = _dataAccess.ExecuteReader(
                "[dbo].[GetVerificationRequestByAccountHolderIdentifier]",
                _dataAccess.CreateConnection(),
                new SqlParameter("AccountHolderIdentifier", accountHolderIdentifier),
                new SqlParameter("AccountIdentifier", accountIdentifier),
                new SqlParameter("ConsumerProfileIdentifier", consumerProfileIdentifier),
                new SqlParameter("VerificationActivityTypeKey",(short)verificationActivityType)))
            {
                while (reader.Read())
                {
                    VerificationActivity activity = new VerificationActivity();
                    activity.VerificationRequestKey = (long)reader["VerificationRequestKey"];
                    activity.ActivityKey = (long)reader["VerificationActivityKey"];
                    activity.ActivityTypeKey = (short)reader["VerificationActivityTypeKey"];
                    activity.StatusKey = (short)reader["ActivityStatusKey"];

                    activities.Add(activity);
                }
            }

            return activities;
        }

        public AccountStatusInfo GetAccountInfoByAccountKeys(List<long> accountKeyList)
        {
            var result = new AccountStatusInfo();
            result.AccountStatusReasonInfo = new List<AccountStatusReasonInfo>();

            if (accountKeyList == null || accountKeyList.Count == 0)
            {
                return result;
            }

            var dt = new DataTable();
            dt.Columns.Add("AccountKey", typeof(long));
            foreach (var accountKey in accountKeyList)
            {
                var row = dt.NewRow();
                row["AccountKey"] = accountKey;
                dt.Rows.Add(row);
            }

            var input = new[]
            {
                new SqlParameter {ParameterName = "ptypeAccountKey", Value = dt, SqlDbType = SqlDbType.Structured, TypeName = "[dbo].[typeAccountKey]"},
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountInfoByAccountKeys]", _dataAccess.CreateConnection(), input))
            {
                while (reader.Read())
                {
                    result.AccountKey = Convert.ToInt64(reader["AccountKey"]);
                    result.AccountStatusKey = Convert.ToInt32(reader["AccountStatusKey"]);
                    result.AccountIdentifier = reader["AccountIdentifier"].ToString();
                    result.ProductKey = Convert.ToInt32(reader["ProductKey"]);
                    result.ProductTierKey = Convert.ToInt32(reader["ProductTierKey"]);
                    result.ProgramCode = reader["ProgramCode"].ToString();
                    result.IsPrimaryAccountHolder = reader["IsPrimaryAccountHolder"] != DBNull.Value && reader.GetBoolean(reader.GetOrdinal("IsPrimaryAccountHolder"));
                    result.AccountHolderCureKey = Convert.ToInt16(reader["AccountHolderCureKey"]);
                }

                reader.NextResult();

                while (reader.Read())
                {
                    var item = new AccountStatusReasonInfo();
                    item.AccountStatusReasonHistoryKey = Convert.ToInt64(reader["AccountStatusReasonHistoryKey"]);
                    item.AccountKey = Convert.ToInt64(reader["AccountKey"]);
                    item.AccountStatusReasonKey = Convert.ToInt16(reader["AccountStatusReasonKey"]);
                    result.AccountStatusReasonInfo.Add(item);
                }
            }
            return result;
        }

        private readonly IDataAccess _dataAccess;
    }
}
