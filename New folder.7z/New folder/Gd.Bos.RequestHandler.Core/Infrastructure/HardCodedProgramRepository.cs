﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using Gd.Bos.Shared.Common.Core.Common.Data;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using RequestHandler.Core.Domain.Model.Product;


namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class HardCodedProgramRepository : IProgramRepository
    {
        public Program GetByProgramIdentifier(ProgramCode programCode)
        {
            if (programCode != ProgramCode.FromString("12345"))
                throw new Exception("No Program exists for specified ProgramCode.");

            return new Program(programCode, 11, "1112");
        }

        public ProgramInfo GetProgramTierInfo(int programKey)
        {
            return new ProgramInfo()
            {
                ProductTiers = new List<ProductTierInfo>(),
                ProductmaterialTypes = new List<ProductmaterialType>()
            };
        }

        public ProductProgramPartner GetProductProgramPartner(ProgramCode programCode)
        {
            return new ProductProgramPartner();
        }

        public ProductTypeInfo GetProductTypeByProductKey(int productKey)
        {
            throw new NotImplementedException();
        }
    }
}
