﻿using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Business;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Utils;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.Shared.Common.Core.Logic;
using Microsoft.Data.SqlClient;
using NLog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.UtilityCoreApi.Contract.Enum;
using RequestHandler.Core.Domain.Model.Account;
using RequestHandler.Core.Domain.Model.User;
using Address = Gd.Bos.RequestHandler.Core.Domain.Model.User.Address;
using BusinessAddress = Gd.Bos.RequestHandler.Core.Domain.Model.Business.BusinessAddress;
using Email = Gd.Bos.RequestHandler.Core.Domain.Model.User.Email;
using PhoneNumber = Gd.Bos.RequestHandler.Core.Domain.Model.User.PhoneNumber;
using User = Gd.Bos.RequestHandler.Core.Domain.Model.User.User;
using UserProfile = Gd.Bos.RequestHandler.Core.Domain.Model.User.UserProfile;
using Gd.Bos.RequestHandler.Core.Domain.Enums;
using RequestHandler.Core.Domain.Enums;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    [ExcludeFromCodeCoverage(Justification = "Data Access class. Hard to test.")]
    public class UserRepository : IUserRepository
    {
        private readonly string _userName = IdentityHelper.GetIdentityName();
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();
        public UserRepository(IDataAccess dataAccess)
        {
            _dataAccess = dataAccess;
        }

        public UserIdentifier NextUserIdentifier()
        {
            return UserIdentifier.FromString(Guid.NewGuid().ToString());
        }

        public void UpdateUserName(UserName newName, UserIdentifier userIdentifier)
        {
            if (newName == null || userIdentifier == null)
                return;

            var updateNameParameters = new[]
            {
                new SqlParameter {ParameterName = "ConsumerProfileIdentifier", Value = Guid.Parse(userIdentifier.ToString())},
                new SqlParameter {ParameterName = "FirstName", Value = newName.FirstName},
                new SqlParameter {ParameterName = "LastName", Value = newName.LastName},
                new SqlParameter {ParameterName = "MiddleName", Value = newName.MiddleName},
                new SqlParameter {ParameterName = "ChangeBy", Value = _userName}
            };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdConsumerProfileV2]", _dataAccess.CreateConnection(),
                updateNameParameters);
        }

        public Tuple<bool, bool, bool> CheckChanged(UserProfile userProfile, UserIdentifier userIdentifier, AccountIdentifier accountIdentifier)
        {
            var addressChanged = CheckAddressesChanged(userProfile, userIdentifier, accountIdentifier);
            var phoneChanged = CheckPhonesChanged(userProfile.PhoneNumbers, userIdentifier);
            var emailChanged = CheckEmailChanged(userProfile.Email, userIdentifier);

            return new Tuple<bool, bool, bool>(addressChanged, phoneChanged, emailChanged);
        }

        /// <summary>
        /// addressChanged, phoneChanged, emailChanged
        /// </summary>
        /// <param name="updatedProfileInfo"></param>
        /// <param name="userIdentifier"></param>
        /// <param name="accountIdentifier"></param>
        /// <param name="consumerProfileKey"></param>
        /// <param name="userIdCreateDate"></param>
        /// <param name="passwordChangeDate"></param>
        /// <returns></returns>
        public Tuple<bool, bool, bool> Update(UserProfile updatedProfileInfo, UserIdentifier userIdentifier, AccountIdentifier accountIdentifier, long customerProfileKey,
            bool updateAllAHHomeAddress, DateTime? userIdCreateDate, DateTime? passwordChangeDate)
        {
            var addressChanged = false;
            var phoneChanged = false;
            var emailChanged = false;

            try
            {
                UpdateAccountHolder(updatedProfileInfo.IsTransferAutoAccept, userIdentifier, accountIdentifier, userIdCreateDate, passwordChangeDate);
                UpdateEncryptedDOB(userIdentifier, updatedProfileInfo.DateOfBirth, updatedProfileInfo.IsDobVerified);

                if (updatedProfileInfo.Addresses?.Count > 0)
                    addressChanged = UpdateAndInsertAddresses(updatedProfileInfo, userIdentifier, accountIdentifier, updateAllAHHomeAddress);

                if (updatedProfileInfo.PhoneNumbers?.Count > 0)
                    phoneChanged = UpdateAndInsertPhoneNumbers(updatedProfileInfo.PhoneNumbers, userIdentifier, customerProfileKey);

                if (updatedProfileInfo.Email != null)
                    emailChanged = UpdateEmailAddress(updatedProfileInfo.Email, userIdentifier);

                if (updatedProfileInfo.ConsumerProfileExtensions?.Count > 0)
                {
                    UpdateAndInsertConsumerProfileExtensions(updatedProfileInfo.ConsumerProfileExtensions, customerProfileKey);
                }

                return new Tuple<bool, bool, bool>(addressChanged, phoneChanged, emailChanged);
            }
            catch (Exception ex)
            {
                Logger.Error(ex, $"UserRepository.Update, error occurred when updating user profile Error: {ex.Message}");
                throw;
            }
        }

        private bool CheckAddressesChanged(UserProfile updatedProfileInfo, UserIdentifier userIdentifier, AccountIdentifier accountIdentifier)
        {
            var consumerAddresses = GetConsumerAddress(userIdentifier);
            List<Address> newAddresses = updatedProfileInfo.Addresses;
            List<Address> currentAddresses = consumerAddresses.Item2;
            var hasChange = false;
            if (newAddresses != null && currentAddresses != null)
            {
                foreach (var newAddress in newAddresses)
                {
                    var currentAddress = currentAddresses.FirstOrDefault(a => a.AddressTypeKey == newAddress.AddressTypeKey);
                    if (currentAddress == null)
                    {
                        hasChange = true;
                        break;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(currentAddress.AddressLine2) || string.IsNullOrWhiteSpace(currentAddress.AddressLine2))
                        {
                            currentAddress.AddressLine2 = null;
                        }
                        if (newAddress.EqualsIgnoreVerified(currentAddress))
                            continue;

                        hasChange = true;
                        break;
                    }
                }
            }

            return hasChange;
        }

        private bool UpdateAndInsertAddresses(UserProfile updatedProfileInfo, UserIdentifier userIdentifier, AccountIdentifier accountIdentifier, bool updateAllAHHomeAddress)
        {
            var consumerAddresses = GetConsumerAddress(userIdentifier);
            var addressChanged = UpdateAndInsertAddresses(updatedProfileInfo.Addresses, userIdentifier, consumerAddresses.Item2, consumerAddresses.Item1);

            var userProfiles = GetUser(accountIdentifier, null);
            var isJoinAccount = userProfiles.Count > 1;
            if (isJoinAccount && updateAllAHHomeAddress)
            {
                var newHomeAddress = updatedProfileInfo.Addresses.FirstOrDefault(a => a.AddressTypeKey == 1);
                if (newHomeAddress != null)
                {
                    var newAddresses = new List<Address> { newHomeAddress };
                    foreach (var userProfile in userProfiles.Where(u => u.UserIdentifier != userIdentifier))
                    {
                        var currentAddresses = userProfile.Addresses.Where(a => a.AddressTypeKey == 1).ToList();
                        UpdateAndInsertAddresses(newAddresses, userProfile.UserIdentifier, currentAddresses, userProfile.ConsumerProfileKey);
                    }
                }
            }

            return addressChanged;
        }

        private void UpdateAccountHolder(bool isTransferAuto, UserIdentifier userIdentifier, AccountIdentifier accountIdentifier, DateTime? userIdCreateDate, DateTime? passwordChangeDate)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>
                {
                    new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                    new SqlParameter {ParameterName = "ConsumerProfileIdentifier",Value = Guid.Parse(userIdentifier.ToString())},
                    new SqlParameter {ParameterName = "AccountHolderIdentifier",Value = null},
                    new SqlParameter {ParameterName = "AccountIdentifier",Value =  Guid.Parse(accountIdentifier.ToString())},
                    new SqlParameter {ParameterName = "IsTransferAutoAccept",Value = isTransferAuto},
                };
                if (userIdCreateDate.HasValue)
                    parameters.Add(new SqlParameter { ParameterName = "UserIdCreateDate", Value = userIdCreateDate });
                if (passwordChangeDate.HasValue)
                    parameters.Add(new SqlParameter { ParameterName = "LastPasswordChangeDate", Value = passwordChangeDate });

                _dataAccess.ExecuteNonQuery("[dbo].[UpdAccountHolder]", _dataAccess.CreateConnection(), parameters.ToArray());
            }
            catch (Exception ex)
            {
                throw new AccountHolderNotFoundException(null, ex);
            }
        }

        private bool UpdateAndInsertAddresses(List<Address> newAddresses, UserIdentifier userIdentifier, List<Address> currentAddresses, long consumerProfileKey)
        {
            var hasChange = false;
            if (newAddresses != null && currentAddresses != null)
            {
                foreach (var newAddress in newAddresses)
                {
                    var currentAddress = currentAddresses.FirstOrDefault(a => a.AddressTypeKey == newAddress.AddressTypeKey);
                    if (currentAddress == null)
                    {
                        InsertAddress(newAddress, consumerProfileKey);
                        hasChange = true;
                    }
                    else
                    {
                        if (newAddress.EqualsIgnoreVerified(currentAddress))
                            continue;

                        UpdateAddress(newAddress, userIdentifier);
                        hasChange = true;
                    }
                }
            }

            return hasChange;
        }

        private void UpdateAddress(Address newAddress, UserIdentifier userIdentifier)
        {
            var updateAddressParameters = new[]
            {
                new SqlParameter {ParameterName = "ConsumerProfileIdentifier", Value = Guid.Parse(userIdentifier.ToString())},
                new SqlParameter {ParameterName = "AddressTypeKey", Value = newAddress.AddressTypeKey},
                new SqlParameter {ParameterName = "Address1", Value = newAddress.AddressLine1},
                new SqlParameter {ParameterName = "Address2", Value = newAddress.AddressLine2},
                new SqlParameter {ParameterName = "City", Value = newAddress.City},
                new SqlParameter {ParameterName = "State", Value = newAddress.State},
                new SqlParameter {ParameterName = "ZipCode", Value = newAddress.ZipCode},
                new SqlParameter {ParameterName = "Country", Value = newAddress.Country},
                new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                new SqlParameter {ParameterName = "IsPrimary", Value = newAddress.IsDefault},
                new SqlParameter {ParameterName = "IsReturned", Value = false}
            };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdConsumerProfileAddress]", _dataAccess.CreateConnection(),
                updateAddressParameters);
        }

        public void UpdateAddressReturnedFlag(UserIdentifier userIdentifier, bool isReturned)
        {
            var updateFlagParameters = new[]
            {
                new SqlParameter{ParameterName = "ChangeBy", Value = _userName},
                new SqlParameter{ParameterName = "ConsumerProfileIdentifier", Value = Guid.Parse(userIdentifier.ToString())},
                new SqlParameter{ParameterName = "IsReturned", Value = isReturned},
                new SqlParameter{ParameterName = "AddressTypeKey", Value = 1}
            };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdConsumerProfileAddress]", _dataAccess.CreateConnection(),
                updateFlagParameters);
        }

        private void InsertAddress(Address newAddress, long consumerProfileKey)
        {
            var updateAddressParameters = new[]
            {
                new SqlParameter {ParameterName = "ConsumerProfileKey", Value = consumerProfileKey},
                new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                new SqlParameter {ParameterName = "AddressTypeKey", Value = newAddress.AddressTypeKey},
                new SqlParameter {ParameterName = "Address1", Value = newAddress.AddressLine1},
                new SqlParameter {ParameterName = "Address2", Value = newAddress.AddressLine2},
                new SqlParameter {ParameterName = "City", Value = newAddress.City},
                new SqlParameter {ParameterName = "State", Value = newAddress.State},
                new SqlParameter {ParameterName = "ZipCode", Value = newAddress.ZipCode},
                new SqlParameter {ParameterName = "Country", Value = newAddress.Country},
                new SqlParameter {ParameterName = "IsPrimary", Value = newAddress.IsDefault},
                new SqlParameter {ParameterName = "IsReturned", Value = false}
            };

            _dataAccess.ExecuteNonQuery("[dbo].[InsConsumerProfileAddress]", _dataAccess.CreateConnection(),
                updateAddressParameters);
        }

        private bool CheckPhonesChanged(List<PhoneNumber> newPhoneNumbers, UserIdentifier userIdentifier)
        {
            var hasChange = false;
            var getConsumerPhoneResponse = GetConsumerPhone(userIdentifier);
            var currentPhoneNumbers = getConsumerPhoneResponse.Item2;
            if (newPhoneNumbers != null && currentPhoneNumbers != null)
            {
                if (!newPhoneNumbers.Any(p => p.IsDefault))
                {
                    var currentPhone = currentPhoneNumbers.FirstOrDefault(cpn => cpn.IsDefault);
                    if (currentPhone == null)
                    {
                        throw new PhoneValidationException(1050, 0, "NO DEFAULT PROVIDED");
                    }

                    var newPhone = newPhoneNumbers.FirstOrDefault(n => n.Type == currentPhone.Type);

                    if (newPhone != null)
                    {
                        newPhone.IsDefault = true;
                    }
                }

                foreach (PhoneNumber newPhoneNumber in newPhoneNumbers)
                {
                    bool foundMatching = false;
                    if (hasChange)
                    {
                        break;
                    }
                    foreach (PhoneNumber currentPhoneNumber in currentPhoneNumbers)
                    {
                        if (currentPhoneNumber.Type == PhoneType.Unspecified && newPhoneNumber.Number?.Trim() == currentPhoneNumber.Number?.Trim())
                        {
                            foundMatching = true;

                            if (newPhoneNumber.Type != currentPhoneNumber.Type)
                            {
                                hasChange = true;
                                currentPhoneNumber.Type = newPhoneNumber.Type;
                                break;
                            }
                        }

                        if (newPhoneNumber.Type == currentPhoneNumber.Type)
                        {
                            foundMatching = true;

                            if (!newPhoneNumber.Equals(currentPhoneNumber))
                            {
                                hasChange = !newPhoneNumber.EqualsWithoutVerified(currentPhoneNumber);
                                if (hasChange)
                                {
                                    break;
                                }
                            }
                        }
                    }

                    if (!foundMatching)
                    {
                        hasChange = true;
                        break;
                    }
                }
            }

            return hasChange;
        }

        private bool UpdateAndInsertPhoneNumbers(List<PhoneNumber> newPhoneNumbers, UserIdentifier userIdentifier, long customerProfileKey)
        {
            var hasChange = false;
            var getConsumerPhoneResponse = GetConsumerPhone(userIdentifier);
            var currentPhoneNumbers = getConsumerPhoneResponse.Item2;
            if (newPhoneNumbers != null && currentPhoneNumbers != null)
            {
                if (!newPhoneNumbers.Any(p => p.IsDefault))
                {
                    var currentPhone = currentPhoneNumbers.FirstOrDefault(cpn => cpn.IsDefault);
                    if (currentPhone == null)
                    {
                        throw new PhoneValidationException(1050, 0, "NO DEFAULT PROVIDED");
                    }

                    var newPhone = newPhoneNumbers.FirstOrDefault(n => n.Type == currentPhone.Type);

                    if (newPhone != null)
                    {
                        newPhone.IsDefault = true;
                    }
                }

                foreach (PhoneNumber newPhoneNumber in newPhoneNumbers)
                {
                    bool foundMatching = false;
                    foreach (PhoneNumber currentPhoneNumber in currentPhoneNumbers)
                    {
                        if (currentPhoneNumber.Type == PhoneType.Unspecified && newPhoneNumber.Number?.Trim() == currentPhoneNumber.Number?.Trim())
                        {
                            foundMatching = true;

                            if (newPhoneNumber.Type != currentPhoneNumber.Type)
                            {
                                // update phone type
                                hasChange = true;
                                UpdatePhoneType(getConsumerPhoneResponse.Item1, PhoneType.Unspecified, newPhoneNumber.Type);
                                currentPhoneNumber.Type = newPhoneNumber.Type;
                            }
                        }

                        if (newPhoneNumber.Type == currentPhoneNumber.Type)
                        {
                            foundMatching = true;

                            if (!newPhoneNumber.Equals(currentPhoneNumber))
                            {
                                //GBOS-35668: update the flag no matter what the existing value is
                                //newPhoneNumber.IsVerified = newPhoneNumber.IsVerified
                                //    ? newPhoneNumber.IsVerified
                                //    : currentPhoneNumber.IsVerified;

                                hasChange = !newPhoneNumber.EqualsWithoutVerified(currentPhoneNumber);

                                UpdatePhoneNumber(newPhoneNumber, userIdentifier);
                                if (newPhoneNumber.IsDefault)
                                {
                                    var currentPrimary = currentPhoneNumbers.FirstOrDefault(p => p.IsDefault);
                                    if (null != currentPrimary && currentPrimary.Type != newPhoneNumber.Type)
                                    {
                                        currentPrimary.IsDefault = false;
                                        UpdatePhoneNumber(currentPrimary, userIdentifier);
                                    }
                                }
                            }
                        }
                    }

                    if (!foundMatching)
                    {
                        hasChange = true;
                        InsertPhoneNumber(newPhoneNumber, customerProfileKey);
                        if (newPhoneNumber.IsDefault)
                        {
                            var currentPrimary = currentPhoneNumbers.FirstOrDefault(p => p.IsDefault);
                            if (null != currentPrimary)
                            {
                                currentPrimary.IsDefault = false;
                                UpdatePhoneNumber(currentPrimary, userIdentifier);
                            }
                        }
                    }
                }
            }

            return hasChange;
        }

        private void UpdateAndInsertConsumerProfileExtensions(List<ConsumerProfileExtensionV2> newConsumerProfileExtensions, long customerProfileKey)
        {
            if (newConsumerProfileExtensions != null && newConsumerProfileExtensions.Count > 0)
            {
                foreach (var newConsumerProfileExtension in newConsumerProfileExtensions)
                {
                    UpdateConsumerProfileExtension(customerProfileKey, newConsumerProfileExtension.ConsumerProfileExtensionAttribute, newConsumerProfileExtension.ConsumerProfileExtensionAttributeValue);
                }
            }
        }

        public void UpdatePhoneNumber(PhoneNumber newPhoneNumber, UserIdentifier userIdentifier)
        {
            var updatePhoneParameters = new[]
            {
                new SqlParameter {ParameterName = "ConsumerProfileIdentifier", Value = Guid.Parse(userIdentifier.ToString())},
                new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                new SqlParameter {ParameterName = "PhoneNumber", Value = newPhoneNumber.Number},
                new SqlParameter {ParameterName = "PhoneTypeKey", Value = newPhoneNumber.Type},
                new SqlParameter {ParameterName = "IsPrimary", Value = newPhoneNumber.IsDefault},
                new SqlParameter {ParameterName = "IsVerified", Value = newPhoneNumber.IsVerified},
            };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdConsumerProfilePhone]", _dataAccess.CreateConnection(),
                updatePhoneParameters);
        }

        public void UpdatePhoneNumberVerificationFlag(bool isVerified, UserIdentifier userIdentifier)
        {
            var getConsumerPhoneResponse = GetConsumerPhone(userIdentifier);
            var currentPhoneNumbers = getConsumerPhoneResponse.Item2;

            if (currentPhoneNumbers != null)
            {
                var mobilePhoneNum = currentPhoneNumbers.FirstOrDefault(n => n.Type == PhoneType.Mobile);
                var unspecifiedPhoneNum = currentPhoneNumbers.FirstOrDefault(n => n.Type == PhoneType.Unspecified);
                var mobilePhone = mobilePhoneNum != null ? mobilePhoneNum : unspecifiedPhoneNum;
                var updatePhoneParameters = new[]
                {
                new SqlParameter {ParameterName = "ConsumerProfileIdentifier", Value = Guid.Parse(userIdentifier.ToString())},
                new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                new SqlParameter {ParameterName = "PhoneNumber", Value = mobilePhone.Number},
                new SqlParameter {ParameterName = "PhoneTypeKey", Value = mobilePhone.Type},
                new SqlParameter {ParameterName = "IsPrimary", Value = mobilePhone.IsDefault},
                new SqlParameter {ParameterName = "IsVerified", Value = isVerified},
            };

                _dataAccess.ExecuteNonQuery("[dbo].[UpdConsumerProfilePhone]", _dataAccess.CreateConnection(),
                    updatePhoneParameters);
            }
        }

        public void UpdatePhoneType(long consumerProfileKey, PhoneType oldPhoneTypeKey, PhoneType newphoneTypeKey)
        {
            var updatePhoneParameters = new[]
            {
                new SqlParameter {ParameterName = "ConsumerProfileKey", Value = consumerProfileKey},
                new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                new SqlParameter {ParameterName = "OldPhoneTypeKey", Value = oldPhoneTypeKey},
                new SqlParameter {ParameterName = "NewPhoneTypeKey", Value = newphoneTypeKey}
                };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdConsumerProfilePhonePhoneType]", _dataAccess.CreateConnection(),
                updatePhoneParameters);
        }

        private void InsertPhoneNumber(PhoneNumber newPhoneNumber, long consumerProfileKey)
        {
            var insertPhoneParameters = new[]
            {
                new SqlParameter {ParameterName = "ConsumerProfileKey", Value = consumerProfileKey},
                new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                new SqlParameter {ParameterName = "PhoneNumber", Value = newPhoneNumber.Number},
                new SqlParameter {ParameterName = "PhoneTypeKey", Value = newPhoneNumber.Type},
                new SqlParameter {ParameterName = "IsPrimary", Value = newPhoneNumber.IsDefault},
                new SqlParameter {ParameterName = "IsVerified", Value = newPhoneNumber.IsVerified},
            };

            _dataAccess.ExecuteNonQuery("[dbo].InsConsumerProfilePhone", _dataAccess.CreateConnection(),
                insertPhoneParameters);
        }

        private bool CheckEmailChanged(Email newEmail, UserIdentifier userIdentifier)
        {
            var hasChange = false;
            var getConsumerEmailResponse = GetConsumerEmail(userIdentifier);
            List<Email> currentEmails = getConsumerEmailResponse.Item2;
            var currentEmail = currentEmails.First();
            if (newEmail != null && !newEmail.Equals(currentEmail))
            {
                hasChange = !newEmail.EqualsWithoutVerified(currentEmail);
                newEmail.IsPrimary = newEmail.IsPrimary ? newEmail.IsPrimary : currentEmail.IsPrimary;
                newEmail.IsVerified = newEmail.IsVerified ? newEmail.IsVerified : currentEmail.IsVerified;
                if (newEmail.Equals(currentEmail))
                {
                    return false;
                }
            }

            return hasChange;
        }

        public bool UpdateEmailAddress(Email newEmail, UserIdentifier userIdentifier)
        {
            var hasChange = false;
            var getConsumerEmailResponse = GetConsumerEmail(userIdentifier);
            List<Email> currentEmails = getConsumerEmailResponse.Item2;
            var currentEmail = currentEmails.First();
            if (newEmail != null && !newEmail.Equals(currentEmail))
            {

                hasChange = !newEmail.EqualsWithoutVerified(currentEmail);

                newEmail.IsPrimary = newEmail.IsPrimary ? newEmail.IsPrimary : currentEmail.IsPrimary;
                newEmail.IsVerified = newEmail.IsVerified ? newEmail.IsVerified : currentEmail.IsVerified;

                if (newEmail.Equals(currentEmail))
                {
                    return false;
                }

                var updateEmailParameters = new[]
                {
                    new SqlParameter {ParameterName = "ConsumerProfileIdentifier", Value = Guid.Parse(userIdentifier.ToString())},
                    new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                    new SqlParameter {ParameterName = "Email", Value = newEmail.EmailAddress},
                    new SqlParameter {ParameterName = "EmailTypeKey", Value = 1},
                    new SqlParameter {ParameterName = "IsPrimary", Value = newEmail.IsPrimary},
                    new SqlParameter {ParameterName = "IsVerified", Value = newEmail.IsVerified}
                };

                _dataAccess.ExecuteNonQuery("[dbo].[UpdConsumerProfileEmail]", _dataAccess.CreateConnection(),
                    updateEmailParameters);

            }

            return hasChange;

        }

        private void AddBusiness(BusinessAccount businessAccount, BusinessAddress businessAddress, User user)
        {
            var userIdentifier = NextUserIdentifier();

            var consumerParams = new[] {
                new SqlParameter()
                {
                    ParameterName = "ConsumerProfileIdentifier",
                    Value = Guid.Parse(userIdentifier.ToString())
                },
                new SqlParameter() {ParameterName = "BusinessName", Value = businessAccount.BusinessName},
                new SqlParameter() {ParameterName = "LegalName", Value = businessAccount.BusinessLegalName},
                new SqlParameter() {ParameterName = "EmbossedName", Value = businessAccount.BusinessEmbossedName},
                new SqlParameter() {ParameterName = "ConsumerProfileTypeKey", Value = businessAccount.BusinessType},
                new SqlParameter() {ParameterName = "ChangeBy", Value = _userName}
            };

            var consumerKey = _dataAccess.ExecuteScalar("[dbo].[InsConsumerProfileV2]", _dataAccess.CreateConnectionWithColumnEncryption(), consumerParams);
            var businessConsumerKey = Convert.ToInt64(consumerKey);

            if (businessConsumerKey != 0)
            {
                var parameters = new[] {
                    new SqlParameter()
                    {
                        ParameterName = "ConsumerProfileKey",
                        Value = businessConsumerKey
                    },
                    new SqlParameter() {ParameterName = "AddressTypeKey", Value = 2},
                    new SqlParameter() {ParameterName = "Address1", Value = businessAddress.BusinessAddressLine1},
                    new SqlParameter() {ParameterName = "Address2", Value = businessAddress.BusinessAddressLine2},
                    new SqlParameter() {ParameterName = "City", Value = businessAddress.BusinessCity},
                    new SqlParameter() {ParameterName = "State", Value = businessAddress.BusinessState},
                    new SqlParameter() {ParameterName = "ZipCode", Value = businessAddress.BusinessZipCode},
                    new SqlParameter() {ParameterName = "Country", Value = businessAddress.BusinessCountryCode},
                    new SqlParameter() {ParameterName = "ChangeBy", Value = _userName},
                    new SqlParameter() {ParameterName = "IsPrimary", Value = false},
                    new SqlParameter() {ParameterName = "IsReturned", Value = false}
                };

                _dataAccess.ExecuteNonQuery("[dbo].[InsConsumerProfileAddress]", _dataAccess.CreateConnection(), parameters);
            }


            //GBOS-99171 intuit requirement add new BusinessPhoneNumber in BusinessData, so now only intuit will use this field
            //if this field is not null, use it as the BusinessConsumerProfile's related ConsumerProfilePhone
            if (!string.IsNullOrEmpty(businessAccount.BusinessPhoneNumber))
            {
                InsertConsumerProfilePhoneForBusinessProfile(businessConsumerKey, PhoneType.Work, false, false, businessAccount.BusinessPhoneNumber);
            }
            else
            {
                foreach (PhoneNumber phone in user.PhoneNumbers)
                {
                    if (businessConsumerKey != 0 && phone.Type == PhoneType.Work)
                    {
                        phone.IsVerified = false;
                        phone.IsDefault = false;

                        InsertConsumerProfilePhoneForBusinessProfile(businessConsumerKey, PhoneType.Work, false, false, phone.Number);
                    }
                }
            }

            if (businessConsumerKey != 0 && !string.IsNullOrEmpty(businessAccount.BusinessEmailAddress))
            {
                var parameters = new[] {
                    new SqlParameter()
                    {
                        ParameterName = "ConsumerProfileKey",
                        Value = businessConsumerKey
                    },
                    new SqlParameter() {ParameterName = "EmailTypeKey", Value = 2},
                    new SqlParameter() {ParameterName = "ChangeBy", Value =_userName},
                    new SqlParameter() {ParameterName = "Email", Value = businessAccount.BusinessEmailAddress},
                    new SqlParameter() {ParameterName = "IsPrimary", Value = false},
                    new SqlParameter() {ParameterName = "IsVerified", Value = false}
                };

                _dataAccess.ExecuteNonQuery("[dbo].[InsConsumerProfileEmail]", _dataAccess.CreateConnection(), parameters);
            }

            if (!string.IsNullOrEmpty(businessAccount.BusinessToken))
            {
                InsertConsumerProfileIdentity(businessConsumerKey, businessAccount.BusinessTaxID,
                    businessAccount.BusinessToken, IdentityType.EIN);

            }

            user.BusinessConsumerProfileKey = businessConsumerKey;
            user.BusinessUserIdentifier = userIdentifier;
        }

        private void InsertConsumerProfilePhoneForBusinessProfile(long businessConsumerKey,PhoneType phoneType, bool isDefault, bool isVerified, string number)
        {
            var parameters = new[] {
                    new SqlParameter()
                    {
                        ParameterName = "ConsumerProfileKey",
                        Value = businessConsumerKey
                    },
                    new SqlParameter() {ParameterName = "PhoneTypeKey", Value = (int)phoneType}, // Need to send mobile type integer value from Core API
                    new SqlParameter() {ParameterName = "ChangeBy", Value = _userName},
                    new SqlParameter() {ParameterName = "IsPrimary", Value = isDefault},
                    new SqlParameter() {ParameterName = "IsVerified", Value = isVerified},
                    new SqlParameter() {ParameterName = "PhoneNumber", Value = number}
                };

            _dataAccess.ExecuteNonQuery("[dbo].[InsConsumerProfilePhone]", _dataAccess.CreateConnection(), parameters);
        }

        public void UpdateDOBMatchedFlag(bool isDobMatched, UserIdentifier userIdentifier)
        {
            var updateNameParameters = new[]
            {
                new SqlParameter {ParameterName = "ConsumerProfileIdentifier", Value = Guid.Parse(userIdentifier.ToString())},
                new SqlParameter {ParameterName = "IsDOBMatched", Value = isDobMatched},
                new SqlParameter {ParameterName = "ChangeBy", Value = _userName}
            };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdConsumerProfileV2]", _dataAccess.CreateConnection(),
                updateNameParameters);
        }

        public void Add(User user, IdentityType identityType)
        {
            try
            {
                var consumerParams = new[] {
                new SqlParameter()
                {
                    ParameterName = "ConsumerProfileIdentifier",
                    Value = Guid.Parse(user.UserIdentifier.ToString())
                },
                new SqlParameter() {ParameterName = "FirstName", Value = user.Name?.FirstName},
                new SqlParameter() {ParameterName = "MiddleName", Value = user.Name?.MiddleName},
                new SqlParameter() {ParameterName = "LastName", Value = user.Name?.LastName},
                //new SqlParameter() {ParameterName = "Last4SSN", Value = ssnSuffix},
                new SqlParameter() {ParameterName = "IsDOBMatched", Value = false},
                new SqlParameter() {ParameterName = "IsDOBVerified", Value = false},
                new SqlParameter() {ParameterName = "ConsumerProfileTypeKey", Value = 1},
                new SqlParameter() {ParameterName = "EncryptedDOB", Value = user.UserIdentifyingData?.DateOfBirth, SqlDbType = SqlDbType.NVarChar, Size = 50},
                new SqlParameter() {ParameterName = "ChangeBy", Value = _userName}
                };

                object consumerProfileKey = _dataAccess.ExecuteScalar("[dbo].[InsConsumerProfileV2]", _dataAccess.CreateConnectionWithColumnEncryption(), consumerParams);
                user.ConsumerProfileKey = Convert.ToInt64(consumerProfileKey);

                var tasks = new List<Task>();

                if (!string.Equals("toast", user.ProgramCode.ToString().ToLower()))
                {
                    tasks.Add(Task.Run(() =>
                    {
                        foreach (Address add in user.Addresses)
                        {
                            var parameters = new[] {
                                new SqlParameter() { ParameterName = "ConsumerProfileKey", Value = consumerProfileKey },
                                new SqlParameter() {ParameterName = "AddressTypeKey", Value = add.AddressTypeKey},
                                new SqlParameter() {ParameterName = "Address1", Value = add.AddressLine1},
                                new SqlParameter() {ParameterName = "Address2", Value = add.AddressLine2},
                                new SqlParameter() {ParameterName = "City", Value = add.City},
                                new SqlParameter() {ParameterName = "State", Value = add.State},
                                new SqlParameter() {ParameterName = "ZipCode", Value = add.ZipCode},
                                new SqlParameter() {ParameterName = "Country", Value = "USA"},
                                new SqlParameter() {ParameterName = "ChangeBy", Value = _userName},
                                new SqlParameter() {ParameterName = "IsPrimary", Value = add.IsDefault},
                                new SqlParameter() {ParameterName = "IsReturned", Value = false}
                            };

                            _dataAccess.ExecuteNonQuery("[dbo].[InsConsumerProfileAddress]", _dataAccess.CreateConnection(),
                                parameters);
                        }
                    }));
                }

                tasks.Add(Task.Run(() =>
                {
                    foreach (PhoneNumber phone in user.PhoneNumbers)
                    {
                        var parameters = new[] {
                            new SqlParameter() { ParameterName = "ConsumerProfileKey", Value = consumerProfileKey },
                            new SqlParameter() {ParameterName = "PhoneTypeKey", Value = (int)phone.Type}, // Need to send mobile type integer value from Core API
                            new SqlParameter() {ParameterName = "ChangeBy", Value = _userName},
                            new SqlParameter() {ParameterName = "IsPrimary", Value = phone.IsDefault},
                            new SqlParameter() {ParameterName = "IsVerified", Value = phone.IsVerified},
                            new SqlParameter() {ParameterName = "PhoneNumber", Value = phone.Number}
                        };

                        _dataAccess.ExecuteNonQuery("[dbo].[InsConsumerProfilePhone]", _dataAccess.CreateConnection(),
                            parameters);
                    }
                }));

                if (user.Email != null)
                {
                    tasks.Add(Task.Run(() =>
                    {
                        var parameters = new[] {
                            new SqlParameter() { ParameterName = "ConsumerProfileKey", Value = consumerProfileKey },
                            new SqlParameter() {ParameterName = "EmailTypeKey", Value = 1},
                            new SqlParameter() {ParameterName = "ChangeBy", Value =_userName},
                            new SqlParameter() {ParameterName = "Email", Value = user.Email.EmailAddress},
                            new SqlParameter() {ParameterName = "IsPrimary", Value = user.Email.IsPrimary},
                            new SqlParameter() {ParameterName = "IsVerified", Value = user.Email.IsVerified}
                        };

                        _dataAccess.ExecuteNonQuery("[dbo].[InsConsumerProfileEmail]", _dataAccess.CreateConnection(), parameters);
                    }));
                }

                if (!string.IsNullOrEmpty(user.IdentityToken))
                {
                    var identityValue = string.IsNullOrEmpty(user.UserIdentifyingData?.Ssn)
                        ? user.UserIdentifyingData?.IdentityValue
                        : user.UserIdentifyingData?.Ssn;

                    // Task to insert consumer profile identity
                    var insertIdentityTask = Task.Run(() =>
                        InsertConsumerProfileIdentity(user.ConsumerProfileKey, identityValue, user.IdentityToken, identityType)
                    );
                    tasks.Add(insertIdentityTask);

                    // Task to insert consumer profile identity detail if IdentityCountryCode is not null or empty
                    var insertIdentityDetailTask = insertIdentityTask.ContinueWith(identityTask =>
                    {
                        if (!string.IsNullOrEmpty(user.UserIdentifyingData?.IdentityCountryCode))
                        {
                            InsertConsumerProfileIdentityDetail(identityTask.Result, (short)IdentityAttribute.CountryAlphaCode, user.UserIdentifyingData?.IdentityCountryCode);
                        }
                    }, TaskContinuationOptions.OnlyOnRanToCompletion);
                    tasks.Add(insertIdentityDetailTask);

                    if (user.BusinessAccount != null)
                    {
                        tasks.Add(Task.Run(() =>
                            AddBusiness(user.BusinessAccount, user.BusinessAddress, user)
                        ));
                    }

                    // Wait for all tasks to complete
                    Task.WaitAll(tasks.ToArray());
                }

            }
            catch (Exception ex)
            {
                Logger.Error(ex, $"UserRepository.Add, error occurred when adding user: Error: {ex.Message}");
                throw;
            }
        }

        public List<UserProfile> GetUser(AccountIdentifier accountIdentifier, UserIdentifier userIdentifier)
        {
            var parameters = new[]
            {
                new SqlParameter {ParameterName = "ConsumerProfileIdentifier", Value = (userIdentifier!=null)?(object)userIdentifier.ToString():DBNull.Value},
                new SqlParameter {ParameterName = "AccountIdentifier", Value = (accountIdentifier!=null)?(object)accountIdentifier.ToString():DBNull.Value}
            };

            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].GetConsumerProfile",
                    _dataAccess.CreateConnectionWithColumnEncryption(), parameters))
                {
                    List<UserProfile> users = new List<UserProfile>();
                    while (reader.Read())
                    {
                        UserProfile userProfile = new UserProfile
                        {
                            ConsumerProfileKey = Int64.Parse(reader["ConsumerProfileKey"].ToString()),
                            UserIdentifier = UserIdentifier.FromString(reader["ConsumerProfileIdentifier"].ToString()),
                            AccountHolderIdentifier = reader.GetGuid(reader.GetOrdinal("AccountHolderIdentifier")).ToString(),
                            AccountIdentifier = reader.GetGuid(reader.GetOrdinal("AccountIdentifier")).ToString(),
                            IsPrimaryAccountHolder = reader["IsPrimary"] != DBNull.Value && bool.Parse(reader["IsPrimary"].ToString()),
                            IsTransferAutoAccept = reader["IsTransferAutoAccept"] != DBNull.Value && bool.Parse(reader["IsTransferAutoAccept"].ToString()),
                            FirstName = reader["FirstName"] == DBNull.Value ? null : reader["FirstName"].ToString(),
                            MiddleName = reader["MiddleName"] == DBNull.Value ? null : reader["MiddleName"].ToString(),
                            LastName = reader["LastName"] == DBNull.Value ? null : reader["LastName"].ToString(),
                            Addresses = new List<Address>(),
                            PhoneNumbers = new List<PhoneNumber>(),
                            Identities = new List<Identity>(),
                            LastModified = DateTimeOffset.Parse(reader["ChangeDate"].ToString()),
                            TermsAcceptances = new List<TermsAcceptance>(),
                            DateOfBirth = reader["EncryptedDOB"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("EncryptedDOB")),
                        };
                        var consumerProfileTypeKey = Int64.Parse(reader["ConsumerProfileTypeKey"].ToString());
                        if (consumerProfileTypeKey == 1)
                        {
                            users.Add(userProfile);
                        }
                    }

                    reader.NextResult();

                    while (reader.Read())
                    {
                        long consumerProfileKey = Int64.Parse(reader["ConsumerProfileKey"].ToString());
                        AddressType type =
                            (AddressType)Enum.Parse(typeof(AddressType), reader["AddressTypeKey"].ToString());
                        Address address = new Address
                        {
                            AddressLine1 = reader["Address1"] == DBNull.Value ? null : reader["Address1"].ToString(),
                            AddressLine2 = reader["Address2"] == DBNull.Value ? null : reader["Address2"].ToString(),
                            City = reader["City"] == DBNull.Value ? null : reader["City"].ToString(),
                            State = reader["State"] == DBNull.Value ? null : reader["State"].ToString(),
                            ZipCode = reader["ZipCode"] == DBNull.Value ? null : reader["ZipCode"].ToString(),
                            Country = reader["Country"] == DBNull.Value ? null : reader["Country"].ToString(),
                            Type = type.ToString(),
                            IsDefault = reader["IsPrimary"] != DBNull.Value && bool.Parse(reader["IsPrimary"].ToString()),
                            IsVerified = reader["IsReturned"] != DBNull.Value && bool.Parse(reader["IsReturned"].ToString()),
                            LastModified = DateTimeOffset.Parse(reader["ChangeDate"].ToString()),
                            Created = DateTimeOffset.Parse(reader["CreateDate"].ToString()),
                            ACIContactId = reader["ACIContactID"] == DBNull.Value ? null : reader["ACIContactID"].ToString()
                        };
                        var user = users.FirstOrDefault(d => d.ConsumerProfileKey == consumerProfileKey);
                        user?.Addresses.Add(address);
                    }
                    reader.NextResult();
                    while (reader.Read())
                    {
                        long consumerProfileKey = Int64.Parse(reader["ConsumerProfileKey"].ToString());


                        Email email = new Email(reader["Email"].ToString(),
                            (Domain.Model.User.EmailType)Enum.Parse(typeof(Domain.Model.User.EmailType), reader["EmailTypeKey"].ToString()),
                            bool.Parse(reader["IsVerified"].ToString()),
                            bool.Parse(reader["IsPrimary"].ToString()),
                            DateTimeOffset.Parse(reader["ChangeDate"].ToString()));
                        if (email.IsPrimary)
                        {
                            var user = users.FirstOrDefault(d => d.ConsumerProfileKey == consumerProfileKey);
                            if (user != null)
                                user.Email = email;
                        }
                    }

                    reader.NextResult();
                    while (reader.Read())
                    {
                        long consumerProfileKey = Int64.Parse(reader["ConsumerProfileKey"].ToString());

                        PhoneNumber phoneNumber = new PhoneNumber
                        {
                            Number = reader["PhoneNumber"] == DBNull.Value ? null : reader["PhoneNumber"].ToString(),
                            Type = (PhoneType)Enum.Parse(typeof(PhoneType), reader["PhoneTypeKey"].ToString()),
                            IsDefault = bool.Parse(reader["IsPrimary"].ToString()),
                            IsVerified = bool.Parse(reader["IsVerified"].ToString()),
                            LastModified = DateTimeOffset.Parse(reader["ChangeDate"].ToString())
                        };
                        var user = users.FirstOrDefault(d => d.ConsumerProfileKey == consumerProfileKey);
                        user?.PhoneNumbers.Add(phoneNumber);
                    }

                    reader.NextResult();
                    while (reader.Read())
                    {
                        long consumerProfileKey = reader["ConsumerProfileKey"].Cast<long>();

                        var identity = new Identity
                        {
                            IdentityType = (IdentityType)reader.GetInt16(reader.GetOrdinal("IdentityTypeKey")),
                            IdentityToken = reader.GetString(reader.GetOrdinal("IdentityToken")),
                            Last4Identity = reader["Last4Identity"].Cast<string>(),
                            CountryCode = reader["IdentityAttributeValue"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("IdentityAttributeValue"))
                        };
                        var user = users.FirstOrDefault(d => d.ConsumerProfileKey == consumerProfileKey);
                        user?.Identities.Add(identity);
                    }

                    reader.NextResult();
                    while (reader.Read())
                    {
                        DateTime acceptanceDate = reader.GetDateTime(reader.GetOrdinal("AcceptanceDate"));
                        acceptanceDate = DateTime.SpecifyKind(acceptanceDate, DateTimeKind.Local);
                        acceptanceDate = acceptanceDate.ToUniversalTime();

                        DateTime? optOutDate = reader.IsDBNull(reader.GetOrdinal("OptOutDate")) ? (DateTime?)null
                            : reader.GetDateTime(reader.GetOrdinal("OptOutDate"));

                        var termsAcceptance = new TermsAcceptance
                        {
                            TermsIdentifier = reader["BrandAgreementTypeIdentifier"].ToString().Trim(),
                            TermsAcceptanceDateTime = acceptanceDate.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
                            TermsAcceptanceFlag = optOutDate == null
                        };

                        long consumerProfileKey = reader["ConsumerProfileKey"].Cast<long>();
                        var user = users.FirstOrDefault(d => d.ConsumerProfileKey == consumerProfileKey);
                        user?.TermsAcceptances.Add(termsAcceptance);
                    }

                    // Populate EmailHistory and PhoneNumbersHistory for each user
                    foreach (var user in users)
                    {
                        user.EmailHistory = GetConsumerProfileEmailHistoryByConsumerProfileKey(user.ConsumerProfileKey);
                        user.PhoneNumbersHistory = GetConsumerProfilePhoneHistoryByConsumerProfileKey(user.ConsumerProfileKey);
                    }

                    return users;
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(ex, 
                    $"UserRepository.GetConsumerProfileAddress: error occurred when retrieving profile for user identifier {userIdentifier}. Error: {ex.Message}");
                throw new Exception("An error occurred trying to retrieve consumer profile: " + ex.Message);
            }

        }

        public List<UserProfile> GetBusinessUsers(AccountIdentifier accountIdentifier)
        {
            var parameters = new[]
           {
               new SqlParameter {ParameterName = "AccountIdentifier", Value = (accountIdentifier!=null)?(object)accountIdentifier.ToString():DBNull.Value}
            };

            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].GetConsumerProfile",
                    _dataAccess.CreateConnection(), parameters))
                {
                    List<UserProfile> users = new List<UserProfile>();
                    while (reader.Read())
                    {
                        UserProfile userProfile = new UserProfile
                        {
                            ConsumerProfileKey = Int64.Parse(reader["ConsumerProfileKey"].ToString()),
                            UserIdentifier = UserIdentifier.FromString(reader["ConsumerProfileIdentifier"].ToString()),
                            IsPrimaryAccountHolder = reader["IsPrimary"] != DBNull.Value && bool.Parse(reader["IsPrimary"].ToString()),
                            IsTransferAutoAccept = reader["IsTransferAutoAccept"] != DBNull.Value && bool.Parse(reader["IsTransferAutoAccept"].ToString()),
                            FirstName = reader["FirstName"] == DBNull.Value ? null : reader["FirstName"].ToString(),
                            MiddleName = reader["MiddleName"] == DBNull.Value ? null : reader["MiddleName"].ToString(),
                            LastName = reader["LastName"] == DBNull.Value ? null : reader["LastName"].ToString(),
                            Addresses = new List<Address>(),
                            PhoneNumbers = new List<PhoneNumber>(),
                            Identities = new List<Identity>(),
                            LastModified = DateTimeOffset.Parse(reader["ChangeDate"].ToString())
                            //Email = email
                        };
                        var consumerProfileTypeKey = Int64.Parse(reader["ConsumerProfileTypeKey"].ToString());
                        if (consumerProfileTypeKey != 1)
                        {
                            users.Add(userProfile);
                        }
                    }
                    return users;
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(ex, 
                    $"UserRepository.GetBusinessUsers: error occurred when retrieving profile for account identifier {accountIdentifier}. Error: {ex.Message}");
                throw new Exception("An error occurred trying to retrieve consumer profile: " + ex.Message);
            }
        }

        public Tuple<List<Tuple<long, UserIdentifier>>, long> GetBusinessUsersKey(AccountIdentifier accountIdentifier)
        {
            var parameters = new[]
           {
               new SqlParameter {ParameterName = "AccountIdentifier", Value = (accountIdentifier!=null)?(object)accountIdentifier.ToString():DBNull.Value}
            };

            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].GetConsumerProfile",
                    _dataAccess.CreateConnection(), parameters))
                {
                    long key = 0;
                    List<Tuple<long, UserIdentifier>> users = new();
                    while (reader.Read())
                    {
                        UserProfile userProfile = new UserProfile
                        {
                            UserIdentifier = UserIdentifier.FromString(reader["ConsumerProfileIdentifier"].ToString()),
                        };
                        key = Convert.ToInt64(reader["ProductKey"]);
                        var consumerProfileTypeKey = Int64.Parse(reader["ConsumerProfileTypeKey"].ToString());
                        if (consumerProfileTypeKey != (long)ConsumerProfileType.BeneficialOwner)
                        {
                            users.Add(Tuple.Create(consumerProfileTypeKey, userProfile.UserIdentifier));
                        }
                    }
                    return new Tuple<List<Tuple<long, UserIdentifier>>, long>(users, key);
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(ex,
                    $"UserRepository.GetBusinessUsersKey: error occurred when retrieving profile for account identifier {accountIdentifier}. Error:  {ex.Message}");
                throw new Exception("An error occurred trying to retrieve consumer profile: " + ex.Message);
            }
        }

        //GBOS-65500: Retrieving existing business user/owner data from GBOS database based on ConsumerProfileType=BeneficialOwner
        public Tuple<UserProfile, long> GetBusinessUser(AccountIdentifier accountIdentifier)
        {
            var parameters = new[]
            {
                new SqlParameter
                {
                    ParameterName = "AccountIdentifier",
                    Value = (accountIdentifier != null) ? (object)accountIdentifier.ToString() : DBNull.Value
                }
            };

            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].GetConsumerProfile",
                           _dataAccess.CreateConnection(), parameters))
                {
                    var consumerProfileTypeKey = default(long);
                    var userProfiles = new List<UserProfile>();
                    while (reader.Read())
                    {
                        userProfiles.Add(new UserProfile
                        {
                            ConsumerProfileKey = Int64.Parse(reader["ConsumerProfileKey"].ToString()),
                            FirstName = reader["FirstName"] == DBNull.Value ? null : reader["FirstName"].ToString(),
                            MiddleName =
                                reader["MiddleName"] == DBNull.Value ? null : reader["MiddleName"].ToString(),
                            LastName = reader["LastName"] == DBNull.Value ? null : reader["LastName"].ToString(),
                            UserIdentifier =
                                reader["ConsumerProfileIdentifier"] == DBNull.Value
                                    ? null
                                    : reader["ConsumerProfileIdentifier"].ToString(),
                            Addresses = new List<Address>(),
                            PhoneNumbers = new List<PhoneNumber>(),
                            Identities = new List<Identity>(),
                            ConsumerProfileTypeKey = reader["ConsumerProfileTypeKey"] == DBNull.Value
                                ? (short)ConsumerProfileType.Individual
                                : short.Parse(reader["ConsumerProfileTypeKey"].ToString())
                        });
                    }

                    var userProfile = userProfiles.MinBy(it=>it.ConsumerProfileKey);
                    return new Tuple<UserProfile, long>(userProfile, userProfile.ConsumerProfileTypeKey);
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(ex,
                    $"UserRepository.GetBusinessUser: error occurred when retrieving profile for account identifier {accountIdentifier}. Error: {ex.Message}");
                throw new Exception("An error occurred trying to retrieve consumer profile: " + ex.Message);
            }
        }

        public List<UserProfileIdentity> GetUserProfileIdentities(AccountIdentifier accountIdentifier)
        {
            var parameters = new[]
            {
                new SqlParameter {ParameterName = "ConsumerProfileIdentifier", Value = DBNull.Value},
                new SqlParameter {ParameterName = "AccountIdentifier", Value = (accountIdentifier!=null)?(object)accountIdentifier.ToString():DBNull.Value}
            };

            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].GetConsumerProfile",
                    _dataAccess.CreateConnection(), parameters))
                {
                    var consumerProfileIndividualKeys = new List<long>();

                    while (reader.Read())
                    {
                        var consumerProfileTypeKey = Int64.Parse(reader["ConsumerProfileTypeKey"].ToString());

                        if (consumerProfileTypeKey == 1) //Individual
                            consumerProfileIndividualKeys.Add(Int64.Parse(reader["ConsumerProfileKey"].ToString()));
                    }

                    reader.NextResult();

                    reader.NextResult();

                    reader.NextResult();

                    reader.NextResult();

                    var userProfileIdentities = new List<UserProfileIdentity>();

                    // read user profile identities
                    while (reader.Read())
                    {
                        long consumerProfileKey = long.Parse(reader["ConsumerProfileKey"].ToString());
                        //int identityTypeKey = int.Parse(reader["IdentityTypeKey"].ToString());

                        if (consumerProfileIndividualKeys.Contains(consumerProfileKey)) // if its a individual User profile key
                        {
                            var userProfileIdentity = new UserProfileIdentity
                            {
                                ConsumerProfileKey = consumerProfileKey,
                                IdentityType = (IdentityType)reader.GetInt16(reader.GetOrdinal("IdentityTypeKey")),
                                CreateDateUtc = DateTimeOffset.Parse(reader["CreateDate"].ToString()),
                                IdentityToken = reader["IdentityToken"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("IdentityToken")),
                                Last4Identity = reader["Last4Identity"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("Last4Identity")),
                                CountryCode = reader["IdentityAttributeValue"] == DBNull.Value ? null : reader.GetString(reader.GetOrdinal("IdentityAttributeValue"))
                            };

                            //if (!Enum.TryParse(identityTypeKey.ToString(), out IdentityType identityType))
                            //    _logger.Warn(
                            //        $"AccountIdentifier:{accountIdentifier} - UserRepository.GetUserProfileIdentities: unable to extract IdentityType enum from IdentityTypeKey:{identityTypeKey} ");

                            //userProfileIdentityType.IdentityType = identityType;

                            userProfileIdentities.Add(userProfileIdentity);
                        }
                    }
                    return userProfileIdentities;
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(ex,
                    $"AccountIdentifier:{accountIdentifier} - UserRepository.GetUserProfileIdentityTypes: error occurred when retrieving Identity types. Error: {ex.Message}");
                throw new Exception("An error occurred trying to retrieve consumer profile identity types: " + ex.Message);
            }

        }

        public Tuple<long, List<Address>> GetConsumerAddress(UserIdentifier userIdentifier)
        {
            var parameters = new[]
            {
                new SqlParameter {ParameterName = "ConsumerProfileIdentifier", Value = userIdentifier.ToString()}
            };

            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].GetConsumerProfileAddress",
                    _dataAccess.CreateConnection(), parameters))
                {
                    List<Address> addresses = new List<Address>();
                    long consumerProfileKey = 0;

                    while (reader.Read())
                    {
                        consumerProfileKey = Int64.Parse(reader["ConsumerProfileKey"].ToString());
                        Address address = new Address
                        {
                            AddressLine1 = reader["Address1"] == DBNull.Value ? null : reader["Address1"].ToString(),
                            AddressLine2 = reader["Address2"] == DBNull.Value ? null : reader["Address2"].ToString(),
                            City = reader["City"] == DBNull.Value ? null : reader["City"].ToString(),
                            State = reader["State"] == DBNull.Value ? null : reader["State"].ToString(),
                            ZipCode = reader["ZipCode"] == DBNull.Value ? null : reader["ZipCode"].ToString(),
                            Country = reader["Country"] == DBNull.Value ? null : reader["Country"].ToString(),
                            Type = reader["AddressTypeKey"] == DBNull.Value ? null : reader["AddressTypeKey"].ToString(),
                            IsDefault = reader["IsPrimary"] != DBNull.Value && bool.Parse(reader["IsPrimary"].ToString())
                        };

                        addresses.Add(address);
                    }


                    return new Tuple<long, List<Address>>(consumerProfileKey, addresses);
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(ex,
                    $"UserRepository.GetConsumerProfileAddress: error occurred when retrieving profile for user identifier {userIdentifier}. Error: {ex.Message}");
                throw new Exception("An error occurred trying to retrieve consumer profile: " + ex.Message);
            }

        }

        public List<ConsumerProfileAddressHistory> GetConsumerProfileAddressHistory(long consumerProfileKey)
        {
            var addresses = new List<ConsumerProfileAddressHistory>();

            var parameters = new[]
            {
                new SqlParameter {ParameterName = "ConsumerProfileKey", Value = consumerProfileKey}
            };

            try
            {
                using (var reader = _dataAccess.ExecuteReader(
                    "[dbo].GetConsumerProfileAddressHistoryByConsumerProfileKey",
                    _dataAccess.CreateConnection(),
                    parameters))
                {
                    while (reader.Read())
                    {
                        var address = new ConsumerProfileAddressHistory()
                        {
                            ConsumerProfileAddressHistoryKey =
                                long.Parse(reader["ConsumerProfileAddressHistoryKey"].ToString()),
                            CreateDate = DateTime.Parse(reader["CreateDate"].ToString()),
                            ChangeDate = DateTime.Parse(reader["ChangeDate"].ToString()),
                            AddressTypeKey = int.Parse(reader["AddressTypeKey"].ToString()),
                            Address1 = reader["Address1"].ToString(),
                            Address2 = reader["Address2"] == DBNull.Value ? "" : reader["Address2"].ToString(),
                            City = reader["City"].ToString(),
                            State = reader["State"].ToString(),
                            Country = reader["Country"].ToString(),
                            ZipCode = reader["ZipCode"].ToString(),
                            IsPrimary = bool.Parse(reader["IsPrimary"].ToString()),
                            IsReturned = bool.Parse(reader["IsReturned"].ToString()),
                            AciAddressId = reader["ACIAddressID"] == DBNull.Value ? "" : reader["ACIAddressID"].ToString(),
                            AciContactId = reader["ACIContactID"] == DBNull.Value ? "" : reader["ACIContactID"].ToString()
                        };

                        addresses.Add(address);
                    }

                    return addresses;
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(ex,
                    $"UserRepository.GetConsumerProfileAddressHistory: error occurred when retrieving address for ConsumerProfileKey {consumerProfileKey}. Error: {ex.Message}");
                throw new Exception("An error occurred trying to retrieve ConsumerProfileAddressHistory: " + ex.Message);
            }

        }

        /// <summary>
        /// Get all AccountHolders' address under one paymentIdentifier(individual and business AccountHolder)
        /// </summary>
        public List<Address> GetConsumerAddress(long paymentIdentifierKey)
        {
            var parameters = new[]
            {
                new SqlParameter {ParameterName = "PaymentIdentifierKey", Value = paymentIdentifierKey}
            };

            try
            {
                List<Address> addresses = new List<Address>();
                using (var reader = _dataAccess.ExecuteReader("[dbo].GetConsumerProfileAddressByPaymentIdentifierKey",
                    _dataAccess.CreateConnection(), parameters))
                {
                    while (reader.Read())
                    {
                        AddressType type = (AddressType)Enum.Parse(typeof(AddressType), reader["AddressTypeKey"].ToString());
                        Address address = new Address
                        {
                            AddressLine1 = reader["Address1"] == DBNull.Value ? null : reader["Address1"].ToString(),
                            AddressLine2 = reader["Address2"] == DBNull.Value ? null : reader["Address2"].ToString(),
                            City = reader["City"] == DBNull.Value ? null : reader["City"].ToString(),
                            State = reader["State"] == DBNull.Value ? null : reader["State"].ToString(),
                            ZipCode = reader["ZipCode"] == DBNull.Value ? null : reader["ZipCode"].ToString(),
                            Country = reader["Country"] == DBNull.Value ? null : reader["Country"].ToString(),
                            Type = type.ToString(),
                            IsDefault = reader["IsPrimary"] != DBNull.Value && bool.Parse(reader["IsPrimary"].ToString()),
                            IsVerified = reader["IsReturned"] != DBNull.Value && bool.Parse(reader["IsReturned"].ToString()),
                            LastModified = DateTimeOffset.Parse(reader["ChangeDate"].ToString())
                        };
                        addresses.Add(address);
                    }
                }

                return addresses;
            }
            catch (SqlException ex)
            {
                Logger.Error(ex,
                    $"UserRepository.GetConsumerAddress: error occurred when retrieving profile for paymentIdentifierKey {paymentIdentifierKey}. Error: {ex.Message}");
                throw new Exception("An error occurred trying to retrieve consumer profile: " + ex.Message);
            }
        }

        public Tuple<long, List<PhoneNumber>> GetConsumerPhone(UserIdentifier userIdentifier)
        {
            var parameters = new[]
            {
                new SqlParameter {ParameterName = "ConsumerProfileIdentifier", Value = userIdentifier.ToString()}
            };

            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].GetConsumerProfilePhone",
                    _dataAccess.CreateConnection(), parameters))
                {
                    List<PhoneNumber> phoneNumbers = new List<PhoneNumber>();
                    long consumerProfileKey = 0;

                    while (reader.Read())
                    {
                        consumerProfileKey = Int64.Parse(reader["ConsumerProfileKey"].ToString());
                        PhoneNumber phoneNumber = new PhoneNumber
                        {
                            Number = reader["PhoneNumber"] == DBNull.Value ? null : reader["PhoneNumber"].ToString(),
                            Type = (PhoneType)Enum.Parse(typeof(PhoneType), reader["PhoneTypeKey"].ToString()),
                            IsDefault = bool.Parse(reader["IsPrimary"].ToString()),
                            IsVerified = bool.Parse(reader["IsVerified"].ToString())
                        };

                        phoneNumbers.Add(phoneNumber);
                    }

                    return new Tuple<long, List<PhoneNumber>>(consumerProfileKey, phoneNumbers);
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(ex,
                    $"UserRepository.GetConsumerProfilePhone: error occurred when retrieving phone numbers for user identifier {userIdentifier}. Error: {ex.Message}");
                throw new Exception($"An error occurred trying to retrieve consumer phone numbers for user identifier {userIdentifier}:  + {ex.Message}");
            }

        }

        public Tuple<long, List<Email>> GetConsumerEmail(UserIdentifier userIdentifier)
        {
            var parameters = new[]
            {
                new SqlParameter {ParameterName = "ConsumerProfileIdentifier", Value = userIdentifier.ToString()}
            };

            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].GetConsumerProfileEmail",
                    _dataAccess.CreateConnection(), parameters))
                {
                    List<Email> emails = new List<Email>();
                    long consumerProfileKey = 0;

                    while (reader.Read())
                    {
                        consumerProfileKey = Int64.Parse(reader["ConsumerProfileKey"].ToString());
                        Console.WriteLine(reader["EmailTypeKey"].ToString());
                        Email email = new Email(reader["Email"].ToString(),
                            (Domain.Model.User.EmailType)Enum.Parse(typeof(Domain.Model.User.EmailType), reader["EmailTypeKey"].ToString()),
                            bool.Parse(reader["IsVerified"].ToString()),
                            bool.Parse(reader["IsPrimary"].ToString()),
                            DateTimeOffset.Parse(reader["ChangeDate"].ToString()));

                        emails.Add(email);
                    }

                    return new Tuple<long, List<Email>>(consumerProfileKey, emails);
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(ex,
                    $"UserRepository.GetConsumerProfileEmail: error occurred when retrieving emails for user identifier {userIdentifier}. Error: {ex.Message}");
                throw new Exception("An error occurred trying to retrieve consumer emails for user identifier {userIdentifier}: " + ex.Message);
            }

        }

        //public void UpdateConsumerSsnToken(UserIdentifier userIdentifier, string ssnToken)
        //{
        //    if (!string.IsNullOrEmpty(ssnToken))
        //    {
        //        var consumerParams = new[] {

        //        new SqlParameter() {ParameterName = "ChangeBy", Value = userName},
        //        new SqlParameter()
        //        {
        //            ParameterName = "ConsumerProfileIdentifier",
        //            Value = Guid.Parse(userIdentifier.ToString())
        //        },
        //        new SqlParameter() {ParameterName = "IdentityTypeKey", Value = 1},
        //        new SqlParameter() {ParameterName = "IdentityToken", Value = ssnToken}

        //        };
        //        _dataAccess.ExecuteNonQuery("[dbo].[UpdConsumerProfileIdentityTokenByConsumerProfileIdentifier]", _dataAccess.CreateConnection(),
        //            consumerParams);
        //    }
        //}

        public void UpdateEncryptedDOB(UserIdentifier userIdentifier, string dateOfBirth, bool? isDobVerified = null)
        {
            var consumerParams = new[] {
               new SqlParameter() {ParameterName = "ChangeBy", Value = _userName},
           new SqlParameter()
           {
               ParameterName = "ConsumerProfileIdentifier",
               Value = Guid.Parse(userIdentifier.ToString())
           },
            new SqlParameter() {ParameterName = "EncryptedDOB", Value =string.IsNullOrEmpty(dateOfBirth)?DBNull.Value:(object)dateOfBirth, SqlDbType = SqlDbType.NVarChar, Size = 50},
            new SqlParameter() {ParameterName = "IsDOBVerified", Value =isDobVerified.HasValue?(object)isDobVerified:DBNull.Value, SqlDbType = SqlDbType.Bit}
           };
            _dataAccess.ExecuteScalar("[dbo].[UpdConsumerProfileEncryptedDOB]", _dataAccess.CreateConnectionWithColumnEncryption(), consumerParams);
        }

        public void UpdateConsumerIdentity(UserIdentifier userIdentifier, string identity, string tokenizedIdentity,
            IdentityType identityType = IdentityType.SSN)
        {
            string ssnSuffix = null;
            if (!string.IsNullOrEmpty(identity) && identity.Length >= 4)
            {
                ssnSuffix = identity.Substring(identity.Length - 4, 4);
            }

            var consumerParams = new[]
            {
                new SqlParameter()
                {
                    ParameterName = "ConsumerProfileIdentifier",
                    Value = Guid.Parse(userIdentifier.ToString())
                },
                new SqlParameter() {ParameterName = "Last4Identity", Value = ssnSuffix},
                new SqlParameter() {ParameterName = "ChangeBy", Value = _userName},
                new SqlParameter() {ParameterName = "IdentityTypeKey", Value = identityType},
                new SqlParameter() {ParameterName = "IdentityToken", Value = tokenizedIdentity}
            };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdConsumerProfileIdentityV2]", _dataAccess.CreateConnection(),
                consumerParams);
        }

        public long InsertConsumerProfileIdentity(long consumerProfileKey, string identity, string identityToken, IdentityType identityType)
        {
            string last4Identity = null;
            if (!string.IsNullOrEmpty(identity))
                last4Identity = identity.Substring(identity.Length - 4, 4);

            var data = new[] {
                new SqlParameter() { ParameterName = "ConsumerProfileKey", Value = consumerProfileKey},
                new SqlParameter() {ParameterName = "IdentityTypeKey", Value = identityType},
                new SqlParameter() {ParameterName = "IdentityToken", Value = identityToken},
                new SqlParameter() {ParameterName = "Last4Identity", Value = last4Identity},
                new SqlParameter() {ParameterName = "ChangeBy", Value = _userName}
            };

            var consumerProfileIdentityKey = _dataAccess.ExecuteScalar("[dbo].[InsConsumerProfileIdentityV3]", _dataAccess.CreateConnection(), data);
            return Convert.ToInt64(consumerProfileIdentityKey);
        }
        public void InsertConsumerProfileIdentityDetail(long consumerProfileIdentityKey, short identityAttributeKey, string identityAttributeValue)
        {
            var consumerProfileIdentityDetail = new DataTable();
            consumerProfileIdentityDetail.Columns.Add("ConsumerProfileIdentityKey", typeof(long));
            consumerProfileIdentityDetail.Columns.Add("IdentityAttributeKey", typeof(short));
            consumerProfileIdentityDetail.Columns.Add(new DataColumn("IdentityAttributeValue", typeof(string)) { MaxLength = 1000 });
            var row = consumerProfileIdentityDetail.NewRow();
            row["ConsumerProfileIdentityKey"] = consumerProfileIdentityKey;
            row["IdentityAttributeKey"] = identityAttributeKey;
            row["IdentityAttributeValue"] = identityAttributeValue;
            consumerProfileIdentityDetail.Rows.Add(row);

            var data = new[]
            {
                new SqlParameter
                {
                    ParameterName = "@ChangeBy", Value = _userName,
                    SqlDbType = SqlDbType.NVarChar,
                },
                new SqlParameter
                {
                    ParameterName = "@ConsumerProfileIdentityDetail", Value = consumerProfileIdentityDetail,
                    SqlDbType = SqlDbType.Structured,
                    TypeName = "typeConsumerProfileIdentityDetail"
                }
            };

            _dataAccess.ExecuteNonQuery("[dbo].[InsConsumerProfileIdentityDetail]", _dataAccess.CreateConnection(), data);
        }


        public ConsumerProfileIncome GetConsumerProfileIncome(long consumerProfileKey)
        {
            var result = new ConsumerProfileIncome();
            var parameters = new[]
            {
                new SqlParameter {ParameterName = "ConsumerProfileKey", Value = consumerProfileKey}
            };

            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetConsumerProfileIncome]",
                    _dataAccess.CreateConnection(), parameters))
                {
                    if (reader.Read())
                    {
                        result.ConsumerProfileKey = Cast<long>(reader["ConsumerProfileKey"]);
                        result.Income = Cast<decimal>(reader["Amount"]);
                        result.FrequencyType = Cast<Application.FrequencyType>(reader["FrequencyKey"]);
                    }
                    else
                    {
                        result = null;
                    }
                }

                return result;
            }
            catch (SqlException ex)
            {
                Logger.Error(ex,
                    $"UserRepository.GetConsumerProfileIncome: error occurred when retrieving income for consumerProfileKey {consumerProfileKey}. Error: {ex.Message}");
                throw new Exception("An error occurred trying to retrieve consumer income: " + ex.Message);
            }
        }

        public void UpdateConsumerProfileIncome(long consumerProfileKey, decimal expense, Application.FrequencyType frequencyType)
        {
            var data = new[] {
                new SqlParameter() {ParameterName = "ConsumerProfileKey", Value = consumerProfileKey},
                new SqlParameter() {ParameterName = "Amount", Value = expense},
                new SqlParameter() {ParameterName = "FrequencyKey", Value = frequencyType},
                new SqlParameter() {ParameterName = "ChangeBy", Value = _userName}
            };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdConsumerProfileIncome]", _dataAccess.CreateConnection(), data);
        }

        public void InsConsumerProfileIncome(long consumerProfileKey, decimal income, Application.FrequencyType frequencyType)
        {
            var data = new[] {
                new SqlParameter() { ParameterName = "ConsumerProfileKey", Value = consumerProfileKey},
                new SqlParameter() {ParameterName = "Amount", Value = income},
                new SqlParameter() {ParameterName = "FrequencyKey", Value = frequencyType},
                new SqlParameter() {ParameterName = "ChangeBy", Value = _userName}
            };

            _dataAccess.ExecuteNonQuery("[dbo].[InsConsumerProfileIncome]", _dataAccess.CreateConnection(), data);
        }


        public ConsumerProfileExpense GetConsumerProfileExpense(long consumerProfileKey)
        {
            var result = new ConsumerProfileExpense();
            var parameters = new[]
            {
                new SqlParameter {ParameterName = "ConsumerProfileKey", Value = consumerProfileKey}
            };

            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetConsumerProfileExpense]",
                    _dataAccess.CreateConnection(), parameters))
                {
                    if (reader.Read())
                    {
                        result.ConsumerProfileKey = Cast<long>(reader["ConsumerProfileKey"]);
                        result.Expense = Cast<decimal>(reader["Amount"]);
                        result.FrequencyType = Cast<Application.FrequencyType>(reader["FrequencyKey"]);
                    }
                    else
                    {
                        result = null;
                    }
                }

                return result;
            }
            catch (SqlException ex)
            {
                Logger.Error(ex,
                    $"UserRepository.GetConsumerProfileExpense: error occurred when retrieving income for consumerProfileKey {consumerProfileKey}. Error: {ex.Message}");
                throw new Exception("An error occurred trying to retrieve consumer Expense: " + ex.Message);
            }
        }

        public void UpdateConsumerProfileExpense(long consumerProfileKey, decimal expense, Application.FrequencyType frequencyType)
        {
            var data = new[] {
                new SqlParameter() {ParameterName = "ConsumerProfileKey", Value = consumerProfileKey},
                new SqlParameter() {ParameterName = "Amount", Value = expense},
                new SqlParameter() {ParameterName = "FrequencyKey", Value = frequencyType},
                new SqlParameter() {ParameterName = "ChangeBy", Value = _userName}
            };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdConsumerProfileExpense]", _dataAccess.CreateConnection(), data);
        }

        public void InsConsumerProfileExpense(long consumerProfileKey, decimal expense, Application.FrequencyType frequencyType)
        {
            var data = new[] {
                new SqlParameter() { ParameterName = "ConsumerProfileKey", Value = consumerProfileKey},
                new SqlParameter() {ParameterName = "Amount", Value = expense},
                new SqlParameter() {ParameterName = "FrequencyKey", Value = frequencyType},
                new SqlParameter() {ParameterName = "ChangeBy", Value = _userName}
            };

            _dataAccess.ExecuteNonQuery("[dbo].[InsConsumerProfileExpense]", _dataAccess.CreateConnection(), data);
        }

        public List<ConsumerProfileExtension> GetConsumerProfileExtension(string consumerProfileIdentifier)
        {
            var result = new List<ConsumerProfileExtension>();
            var parameters = new[]
            {
                new SqlParameter {ParameterName = "pConsumerProfileIdentifier", Value = Guid.Parse(consumerProfileIdentifier)}
            };

            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetConsumerProfileExtensionByConsumerProfileIdentifier]",
                    _dataAccess.CreateConnection(), parameters))
                {
                    while (reader.Read())
                    {
                        var consumerProfileExtension = new ConsumerProfileExtension();
                        consumerProfileExtension.ConsumerProfileExtensionAttributeKey = Cast<int>(reader["ConsumerProfileExtensionAttributeKey"]);
                        consumerProfileExtension.ConsumerProfileExtensionAttributeValue = Cast<string>(reader["ConsumerProfileExtensionAttributeValue"]);
                        result.Add(consumerProfileExtension);
                    }
                }

                return result;
            }
            catch (SqlException ex)
            {
                Logger.Error(ex,
                    $"UserRepository.GetConsumerProfileExtension: error occurred when retrieving income for consumerProfileIdentifier {consumerProfileIdentifier}. Error: {ex.Message}");
                throw new Exception("An error occurred trying to retrieve consumerProfileExtension: " + ex.Message);
            }
        }

        public void SaveOrUpdateConsumerProfileExtension(
            long consumerProfileKey,
            int attributeKey,
            string jsonAttributeValue)
        {
            var parameters = new[]
            {
                new SqlParameter {ParameterName = "pConsumerProfileKey", Value =consumerProfileKey},
                new SqlParameter {ParameterName = "pConsumerProfileExtensionAttributeKey", Value =attributeKey},
                new SqlParameter {ParameterName = "pConsumerProfileExtensionAttributeValue", Value =jsonAttributeValue},
            };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdConsumerProfileExtension]", _dataAccess.CreateConnection(), parameters);

        }

        public void UpdateConsumerProfileExtension(long consumerProfileKey, ConsumerProfileExtensionAttribute attr,
            string consumerProfileExtensionAttributeValue)
        {
            var data = new[] {
                new SqlParameter() {ParameterName = "pConsumerProfileKey", Value = consumerProfileKey},
                new SqlParameter() {ParameterName = "pConsumerProfileExtensionAttributeKey", Value = (int)attr},
                new SqlParameter() {ParameterName = "pConsumerProfileExtensionAttributeValue", Value = consumerProfileExtensionAttributeValue},
            };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdConsumerProfileExtension]", _dataAccess.CreateConnection(), data);
        }
        public string GetAccountIdentifierByProspectId(string prospectIdentifier)
        {
            string value = null;
            var parameters = new[]
            {
                new SqlParameter {ParameterName = "@CustomerAcquisitionReferenceId", Value = prospectIdentifier}
            };

            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetConsumerProfileExtensionByCustomerAcquisitionReferenceId]",
                    _dataAccess.CreateConnection(), parameters))
                {
                    if (reader.Read())
                    {
                        value = Cast<string>(reader["ConsumerProfileExtensionAttributeValue"]);
                    }
                }

                return value;
            }
            catch (SqlException ex)
            {
                Logger.Error(ex,
                    $"UserRepository.GetAccountIdentifierByProspectId: error occurred when retrieving income for prospectId {prospectIdentifier}. Error: {ex.Message}");
                throw new Exception("An error occurred trying to retrieve consumerProfileExtension: " + ex.Message);
            }
        }

        public List<UserProfile> GetUserProfilesByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            var parameters = new[]
            {
                new SqlParameter {ParameterName = "AccountIdentifier", Value = (accountIdentifier!=null)?(object)accountIdentifier.ToString():DBNull.Value}
            };

            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].GetConsumerProfile",
                    _dataAccess.CreateConnectionWithColumnEncryption(), parameters))
                {
                    List<UserProfile> users = new List<UserProfile>();
                    while (reader.Read())
                    {
                        UserProfile userProfile = new UserProfile
                        {
                            ConsumerProfileKey = Int64.Parse(reader["ConsumerProfileKey"].ToString()),
                            UserIdentifier = UserIdentifier.FromString(reader["ConsumerProfileIdentifier"].ToString()),
                            AccountHolderIdentifier =
                                reader.GetGuid(reader.GetOrdinal("AccountHolderIdentifier")).ToString(),
                            AccountIdentifier = reader.GetGuid(reader.GetOrdinal("AccountIdentifier")).ToString(),
                            IsPrimaryAccountHolder =
                                reader["IsPrimary"] != DBNull.Value && bool.Parse(reader["IsPrimary"].ToString()),
                            IsTransferAutoAccept =
                                reader["IsTransferAutoAccept"] != DBNull.Value &&
                                bool.Parse(reader["IsTransferAutoAccept"].ToString()),
                            FirstName = reader["FirstName"] == DBNull.Value ? "" : reader["FirstName"].ToString(),
                            MiddleName = reader["MiddleName"] == DBNull.Value ? "" : reader["MiddleName"].ToString(),
                            LastName = reader["LastName"] == DBNull.Value ? "" : reader["LastName"].ToString(),
                            LastModified = DateTimeOffset.Parse(reader["ChangeDate"].ToString()),
                            DateOfBirth =
                                reader["EncryptedDOB"] == DBNull.Value
                                    ? null
                                    : reader.GetString(reader.GetOrdinal("EncryptedDOB")),
                            ConsumerProfileTypeKey = reader["ConsumerProfileTypeKey"] == DBNull.Value
                                ? (short)ConsumerProfileType.Individual
                                : (short)reader["ConsumerProfileTypeKey"]
                            //Email = email
                        };
                        users.Add(userProfile);
                    }
                    return users;
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(ex, $"UserRepository.GetUserProfilesByAccountIdentifier: error occurred when retrieving profile for account identifier {accountIdentifier}. Error: {ex.Message}");
                throw new Exception("An error occurred trying to retrieve consumer profile: " + ex.Message);
            }

        }

        public List<AccountHolderCureData> GetAccountHolderCureData(AccountIdentifier accountIdentifier)
        {
            var result = new List<AccountHolderCureData>();
            var parameters = new[]
            {
                new SqlParameter {ParameterName = "AccountIdentifier", Value = (accountIdentifier!=null)?(object)accountIdentifier.ToString():DBNull.Value}
            };

            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountHolderCureByAccountIdentifier]",
                    _dataAccess.CreateConnection(), parameters))
                {
                    while (reader.Read())
                    {
                        var accountHolderCureData = new AccountHolderCureData();
                        accountHolderCureData.AccountKey = Cast<long>(reader["AccountKey"]);
                        accountHolderCureData.AccountStatusKey = Cast<short>(reader["AccountStatusKey"]);
                        accountHolderCureData.AccountHolderKey = Cast<long>(reader["AccountHolderKey"]);
                        accountHolderCureData.AccountHolderIdentifier = Cast<Guid>(reader["AccountHolderIdentifier"]);
                        accountHolderCureData.IsPrimaryAccountHolder = Cast<bool>(reader["IsPrimaryAccountHolder"]);
                        accountHolderCureData.AccountHolderCureKey = Cast<short>(reader["AccountHolderCureKey"]);
                        result.Add(accountHolderCureData);
                    }
                }
                return result;
            }
            catch (SqlException ex)
            {
                Logger.Error(ex, $"UserRepository.GetAccountHolderCureData: error occurred when retrieving AccountHolder Cure Data for account identifier {accountIdentifier}. Error: {ex.Message}");
                throw new Exception("An error occurred trying to retrieve AccountHolder Cure: " + ex.Message);
            }
        }


        private List<Email> GetConsumerProfileEmailHistoryByConsumerProfileKey(long consumerProfileKey)
        {
            var parameters = new[]
            {
                new SqlParameter {ParameterName = "ConsumerProfileKey", Value = consumerProfileKey}
            };

            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetConsumerProfileEmailHistoryByConsumerProfileKey]",
                    _dataAccess.CreateConnection(), parameters))
                {
                    List<Email> emails = new List<Email>();

                    while (reader.Read())
                    {
                        Email email = new Email(reader["Email"].ToString(),
                        (Domain.Model.User.EmailType)Enum.Parse(typeof(Domain.Model.User.EmailType), reader["EmailTypeKey"].ToString()),
                        bool.Parse(reader["IsVerified"].ToString()),
                        bool.Parse(reader["IsPrimary"].ToString()),
                        DateTimeOffset.Parse(reader["ChangeDate"].ToString()));

                        emails.Add(email);
                    }

                    return emails;
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(ex,
                    $"UserRepository.GetEmailHistory: error occurred when retrieving email history for consumer profile key {consumerProfileKey}. Error: {ex.Message}");
                throw new Exception($"An error occurred trying to retrieve email history for consumer profile key {consumerProfileKey}: {ex.Message}");
            }
        }
        private List<PhoneNumber> GetConsumerProfilePhoneHistoryByConsumerProfileKey(long consumerProfileKey)
        {
            var parameters = new[]
            {
                new SqlParameter {ParameterName = "ConsumerProfileKey", Value = consumerProfileKey}
            };

            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetConsumerProfilePhoneHistoryByConsumerProfileKey]",
                    _dataAccess.CreateConnection(), parameters))
                {
                    List<PhoneNumber> phoneNumbers = new List<PhoneNumber>();

                    while (reader.Read())
                    {
                        PhoneNumber phoneNumber = new PhoneNumber
                        {
                            Number = reader["PhoneNumber"] == DBNull.Value ? null : reader["PhoneNumber"].ToString(),
                            Type = (PhoneType)Enum.Parse(typeof(PhoneType), reader["PhoneTypeKey"].ToString()),
                            IsDefault = bool.Parse(reader["IsPrimary"].ToString()),
                            IsVerified = bool.Parse(reader["IsVerified"].ToString()),
                            LastModified = DateTimeOffset.Parse(reader["ChangeDate"].ToString())
                        };

                        phoneNumbers.Add(phoneNumber);
                    }

                    return phoneNumbers;
                }
            }
            catch (SqlException ex)
            {
                Logger.Error(ex,
                    $"UserRepository.GetPhoneNumbersHistory: error occurred when retrieving phone number history for consumer profile key {consumerProfileKey}. Error: {ex.Message}");
                throw new Exception($"An error occurred trying to retrieve phone number history for consumer profile key {consumerProfileKey}: {ex.Message}");
            }
        }

        /// <param name="updatedProfileInfo">The updated profile information containing the user's new phone numbers, email address, and physical
        /// addresses.</param>
        /// <param name="userIdentifier">The identifier for the user whose information is being updated.</param>
        /// <param name="accountIdentifier">The identifier for the account associated with the user.</param>
        /// <param name="customerProfileKey">A unique key representing the customer's profile in the system.</param>
        /// <returns>A <see cref="Tuple{T1, T2, T3}"/> where: <list type="bullet"> <item><description>The first value indicates
        /// whether the address was updated (<see langword="true"/> if updated; otherwise, <see
        /// langword="false"/>).</description></item> <item><description>The second value indicates whether the phone
        /// numbers were updated (<see langword="true"/> if updated; otherwise, <see
        /// langword="false"/>).</description></item> <item><description>The third value indicates whether the email
        /// address was updated (<see langword="true"/> if updated; otherwise, <see
        /// langword="false"/>).</description></item> </list></returns>
        public Tuple<bool, bool, bool> UpdatePhoneEmailAddress(UserProfile updatedProfileInfo, UserIdentifier userIdentifier, AccountIdentifier accountIdentifier, long customerProfileKey)
        {
            var addressChanged = false;
            var phoneChanged = false;
            var emailChanged = false;
            try
            {
                var userProfiles = GetUser(accountIdentifier, null);

                if (updatedProfileInfo.Addresses?.Count > 0)
                {
                    var consumerAddresses = userProfiles?.FirstOrDefault()?.Addresses ?? [];
                    addressChanged = UpdateAndInsertAddresses(updatedProfileInfo.Addresses, userIdentifier, consumerAddresses, customerProfileKey);
                }

                if (updatedProfileInfo.PhoneNumbers?.Count > 0)
                {
                    var consumerPhoneNumbers = userProfiles?.FirstOrDefault()?.PhoneNumbers ?? [];
                    phoneChanged = UpdateAndInsertPhoneNumbers(updatedProfileInfo.PhoneNumbers, userIdentifier, consumerPhoneNumbers, customerProfileKey);
                }

                if (updatedProfileInfo.Email != null)
                {
                    var consumerEmail = userProfiles?.FirstOrDefault()?.Email;
                    emailChanged = UpdateAndInsertEmail(updatedProfileInfo.Email, userIdentifier, consumerEmail, customerProfileKey);
                }

                return new Tuple<bool, bool, bool>(addressChanged, phoneChanged, emailChanged);
            }
            catch (Exception ex)
            {
                Logger.Error(ex, $"UserRepository.UpdatePhoneEmailAddress, error occurred when updating user phone, email or address Error: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Updates and inserts phone numbers for a user profile. 
        /// </summary>
        /// <param name="newPhoneNumbers">List of new phone numbers to update or insert.</param>
        /// <param name="userIdentifier">The unique identifier of the user.</param>
        /// <param name="currentPhoneNumbers">List of current phone numbers associated with the user.</param>
        /// <param name="customerProfileKey">The unique key identifying the customer's profile in the database.</param>
        /// <returns>True if any phone numbers were updated or inserted; otherwise, false.</returns>
        public bool UpdateAndInsertPhoneNumbers(List<PhoneNumber> newPhoneNumbers, UserIdentifier userIdentifier, List<PhoneNumber> currentPhoneNumbers, long customerProfileKey)
        {
            var hasChange = false;
            if (newPhoneNumbers != null && currentPhoneNumbers != null)
            {
                if (!newPhoneNumbers.Any(p => p.IsDefault))
                {
                    var currentPhone = currentPhoneNumbers.FirstOrDefault(cpn => cpn.IsDefault);
                    if (currentPhone != null)
                    {
                        var newPhone = newPhoneNumbers.FirstOrDefault(n => n.Type == currentPhone.Type);
                        if (newPhone != null)
                        {
                            newPhone.IsDefault = true;
                        }
                    }
                }

                foreach (PhoneNumber newPhoneNumber in newPhoneNumbers)
                {
                    bool foundMatching = false;
                    foreach (PhoneNumber currentPhoneNumber in currentPhoneNumbers)
                    {
                        if (currentPhoneNumber.Type == PhoneType.Unspecified && newPhoneNumber.Number?.Trim() == currentPhoneNumber.Number?.Trim())
                        {
                            foundMatching = true;

                            if (newPhoneNumber.Type != currentPhoneNumber.Type)
                            {
                                hasChange = true;
                                UpdatePhoneType(customerProfileKey, PhoneType.Unspecified, newPhoneNumber.Type);
                                currentPhoneNumber.Type = newPhoneNumber.Type;
                            }
                        }

                        if (newPhoneNumber.Type == currentPhoneNumber.Type)
                        {
                            foundMatching = true;

                            if (!newPhoneNumber.Equals(currentPhoneNumber))
                            {
                                hasChange = !newPhoneNumber.EqualsWithoutVerified(currentPhoneNumber);

                                UpdatePhoneNumber(newPhoneNumber, userIdentifier);
                                if (newPhoneNumber.IsDefault)
                                {
                                    var currentPrimary = currentPhoneNumbers.FirstOrDefault(p => p.IsDefault);
                                    if (null != currentPrimary && currentPrimary.Type != newPhoneNumber.Type)
                                    {
                                        currentPrimary.IsDefault = false;
                                        UpdatePhoneNumber(currentPrimary, userIdentifier);
                                    }
                                }
                            }
                        }
                    }

                    if (!foundMatching)
                    {
                        hasChange = true;
                        InsertPhoneNumber(newPhoneNumber, customerProfileKey);
                        if (newPhoneNumber.IsDefault)
                        {
                            var currentPrimary = currentPhoneNumbers.FirstOrDefault(p => p.IsDefault);
                            if (null != currentPrimary)
                            {
                                currentPrimary.IsDefault = false;
                                UpdatePhoneNumber(currentPrimary, userIdentifier);
                            }
                        }
                    }
                }
            }

            return hasChange;
        }

        /// <summary>
        /// Updates an existing email address or inserts a new one for a specified user profile.
        /// </summary>
        /// <param name="newEmail">The new email address to be added or updated. Cannot be <see langword="null"/>.</param>
        /// <param name="userIdentifier">The unique identifier of the user associated with the email address.</param>
        /// <param name="consumerEmail">The current email address associated with the user. Can be <see langword="null"/> if no email exists.</param>
        /// <param name="customerProfileKey">The unique key identifying the customer's profile in the database.</param>
        /// <returns><see langword="true"/> if the email address was successfully inserted or updated; otherwise, <see
        /// langword="false"/> if no changes were made.</returns>
        public bool UpdateAndInsertEmail(Email newEmail, UserIdentifier userIdentifier, Email consumerEmail, long customerProfileKey)
        {
            if (newEmail == null)
            {
                return false;
            }

            if (consumerEmail == null)
            {
                var parameters = new[] {
                    new SqlParameter() { ParameterName = "ConsumerProfileKey", Value = customerProfileKey },
                    new SqlParameter() {ParameterName = "EmailTypeKey", Value = 1},
                    new SqlParameter() {ParameterName = "ChangeBy", Value =_userName},
                    new SqlParameter() {ParameterName = "Email", Value = newEmail.EmailAddress},
                    new SqlParameter() {ParameterName = "IsPrimary", Value = newEmail.IsPrimary},
                    new SqlParameter() {ParameterName = "IsVerified", Value = newEmail.IsVerified}
                };

                _dataAccess.ExecuteNonQuery("[dbo].[InsConsumerProfileEmail]", _dataAccess.CreateConnection(), parameters);
                return true;
            }

            var hasChange = !newEmail.EqualsWithoutVerified(consumerEmail);
            newEmail.IsPrimary = newEmail.IsPrimary ? newEmail.IsPrimary : consumerEmail.IsPrimary;
            newEmail.IsVerified = newEmail.IsVerified ? newEmail.IsVerified : consumerEmail.IsVerified;
            if (newEmail.Equals(consumerEmail))
            {
                return false;
            }

            var updateEmailParameters = new[]
            {
                new SqlParameter
                {
                    ParameterName = "ConsumerProfileIdentifier",
                    Value = Guid.Parse(userIdentifier.ToString())
                },
                new SqlParameter { ParameterName = "ChangeBy", Value = _userName },
                new SqlParameter { ParameterName = "Email", Value = newEmail.EmailAddress },
                new SqlParameter { ParameterName = "EmailTypeKey", Value = 1 },
                new SqlParameter { ParameterName = "IsPrimary", Value = newEmail.IsPrimary },
                new SqlParameter { ParameterName = "IsVerified", Value = newEmail.IsVerified }
            };

            _dataAccess.ExecuteNonQuery("[dbo].[UpdConsumerProfileEmail]", _dataAccess.CreateConnection(),
                updateEmailParameters);
            return hasChange;
        }

        private static T Cast<T>(object value)
        {
            if (value == DBNull.Value || value == null)
                return default(T);

            return (T)value;
        }
        
        private readonly IDataAccess _dataAccess;
    }
}
