﻿using Gd.Bos.Dcpp.Contract.Data;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.Shared.Common.Core.CareCoreApi.Contract.Data.Enum;
using Microsoft.Data.SqlClient;
using NLog;
using RequestHandler.Core.Domain.Services.Risk;
using RequestHandler.Core.Domain.Services.Risk.Data;
using RequestHandler.Core.Domain.Services.Risk.Messages.Request;
using RequestHandler.Core.Domain.Services.Risk.Messages.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RequestHandler.Core.Infrastructure
{
    public class FraudProxy : IFraudProxy
    {
        private IGssFraudEventService _gssFraudEventService;
        private ITokenizerService _tokenizerService;
        private ISuperTokenService _superTokenService;

        public FraudProxy(IGssFraudEventService gssFraudEventService, ITokenizerService tokenizerService, ISuperTokenService superTokenService)
        {
            _gssFraudEventService = gssFraudEventService;
            _tokenizerService = tokenizerService;
            _superTokenService = superTokenService;
        }
        public bool CallNegativeMatch(NegativeMatchArguments negativeMatchArguments)
        {
            List<Action<NegativeMatchArguments>> transcations = new List<Action<NegativeMatchArguments>>();
            transcations.Add(arg =>
            {
                arg.Identities.ForEach(identity =>
                {
                    var deTokenizeResult = _tokenizerService.DeTokenizeIdentity(identity.Token);
                    identity.Token = deTokenizeResult.Value;
                    identity.Country = !string.IsNullOrEmpty(deTokenizeResult.Country) ? deTokenizeResult.Country : (identity.Type == "NationalIdCard" || identity.Type == "MatriculaId") ? "MEX" : "USA";
                });
            });
            transcations.Add(arg =>
            {
                arg.Identities.ForEach(identity =>
                {
                    var superTokenRequest = new SuperTokenRequest() { CallChainID = Guid.NewGuid().ToString(), Country = identity.Country, Type = identity.Type, Value = identity.Token };
                    var superTokenizeResponse = _superTokenService.SuperTokenize(superTokenRequest);
                    if (!superTokenizeResponse.Success)
                    {
                        throw new Exception($"Occur error when execute SuperTokenize : {superTokenizeResponse.ResponseMessage}");
                    }
                    identity.Token = superTokenizeResponse.SuperToken;
                });
            });
            transcations.Add(arg =>
            {
                var res = _gssFraudEventService.AddFraudIdentity(arg.ProgramCode, arg.AccountIdentifer, arg.Identities, null, new List<Gd.Bos.RequestHandler.Core.Domain.Model.User.PhoneNumber>(), "exc-ulcl"); ;

                if (res == null)
                {
                    throw new Exception("Occur error when execute FraudIdentity");
                }
            });

            var enumator = transcations.GetEnumerator();
            while (enumator.MoveNext())
            {
                var isSuccess = EnumExecute(enumator.Current, negativeMatchArguments);
                if (!isSuccess)
                {
                    return false;
                }
            };
            return true;
        }
        private bool EnumExecute(Action<NegativeMatchArguments> action, NegativeMatchArguments matchArguments)
        {
            try
            {
                action(matchArguments);
                return true;
            }
            catch (Exception ex)
            {
                LogManager.GetCurrentClassLogger().Warn(ex, $"Occur error when execute NegativeMatch. Error: {ex.Message}");
                return false;
            }
        }
    }
}
