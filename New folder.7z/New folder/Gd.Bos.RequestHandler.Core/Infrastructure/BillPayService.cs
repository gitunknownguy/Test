﻿using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Services.BillPay;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Newtonsoft.Json;
using NLog;
using System;
using System.Linq;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class BillPayService : IBillPayService
    {
        private readonly IServiceInvokeProvider _serviceInvokerProvider;
        private readonly IAccountRepository _accountRepository;
        private readonly ITokenizerService _tokenizerService;
        private readonly string _billPayUrl;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        private readonly IBaasConfiguration _baasConfiguration;
        private int _maxNumberOfEnrollRequests = 3;
        public BillPayService(IServiceInvokeProvider serviceInvokeProvider, IAccountRepository accountRepository, ITokenizerService tokenizerService, IBaasConfiguration baasConfiguration)
        {
            _serviceInvokerProvider = serviceInvokeProvider;
            _accountRepository = accountRepository;
            _tokenizerService = tokenizerService;
            _billPayUrl = Configuration.Configuration.Current.GSSBillPayUrl;
            _baasConfiguration = baasConfiguration;
        }

        public void EnrollCustomer(BillPayEnrollRequest billPayEnrollRequest)
        {
            AccountPrimaryConsumerProfile accountInfo = _accountRepository.GetAccountPrimaryConsumerProfileAnyToken(billPayEnrollRequest.AccountIdentifier);

            if (accountInfo == null || accountInfo.AccountKey == 0)
            {
                throw new RequestHandlerException(404, 0, $"Unable to locate AccountPrimaryConsumerProfile by AccountIdentifier: {billPayEnrollRequest.AccountIdentifier}");
            }

            _logger.Info(JsonConvert.SerializeObject(accountInfo));

            string plainTextSSN = _tokenizerService.DeTokenizeSsn(accountInfo.IdentityToken, billPayEnrollRequest.ProgramCode);

            BillPayEnrollSubscriberRequest billPayEnrollSubscriberRequest = new BillPayEnrollSubscriberRequest()
            {
                firstName = accountInfo.FirstName,
                middleName = accountInfo.MiddleName,
                lastName = accountInfo.LastName,
                address1 = accountInfo.Address1,
                address2 = accountInfo.Address2,
                city = accountInfo.City,
                state = accountInfo.State,
                zip = accountInfo.ZipCode,
                country = accountInfo.Country,
                phoneNumber = accountInfo.PhoneNumber,
                email = accountInfo.Email,
                dob = accountInfo.DOB,
                ssn = plainTextSSN,
                bankRoutingNumber = accountInfo.RoutingNumber,
                bankAccountNumber = accountInfo.AccountNumber,
                bankAccountType = "DDA"
            };

            var billPayEnrollSubscriberResponse = BillPayEnroll(billPayEnrollSubscriberRequest, billPayEnrollRequest.ProgramCode,
                billPayEnrollRequest.AccountIdentifier);

            //The response should be logged by ServiceInvokerProvider
            //_logger.Info(JsonConvert.SerializeObject(billPayEnrollSubscriberResponse));

            //per confluence page here: https://confluence/display/MOTX/GSS+BillPay+APIs
            if (billPayEnrollSubscriberResponse == null || billPayEnrollSubscriberResponse.ErrorCode == null || billPayEnrollSubscriberResponse.ErrorCode.ToLower() != "0")
            {
                throw new RequestHandlerException(503, 0, $"Unable to enroll customer in BillPay");
            }
        }



        public BillPayEnrollSubscriberResponse BillPayEnroll(BillPayEnrollSubscriberRequest billPayEnrollRequest, string programCode, string accountIdentifier)
        {
            var billPayEnrollSubscriberResponse =
                _serviceInvokerProvider.GetResponseAsync<BillPayEnrollSubscriberRequest, BillPayEnrollSubscriberResponse>(
                     GenerateEnrollUrl(programCode, accountIdentifier),
                    "POST", billPayEnrollRequest, null).Result;

            return billPayEnrollSubscriberResponse;
        }

        public AddBillPayeeResponse AddBillPayee(AddBillPayeeRequest addBillPayeeRequest, string programCode, string accountIdentifier)
        {
            int attempts = 0;
            while (attempts < _maxNumberOfEnrollRequests)
            {
                var addBillPayeeResponse =
                _serviceInvokerProvider.GetResponseAsync<AddBillPayeeRequest, AddBillPayeeResponse>(
                    GenerateBillPayPayeesUrl(programCode, accountIdentifier),
                    "POST", addBillPayeeRequest, null).Result;
                //BillPay_CustomerNotEnrolled = "03002" //Customer is not enrolled to BillPay. Enrollment is required first using Enroll API
                //https://confluence/display/MOTX/GSS+BillPay+APIs
                if (addBillPayeeResponse.ErrorCode == "03002")
                {
                    EnrollCustomer(new BillPayEnrollRequest()
                    {
                        AccountIdentifier = accountIdentifier,
                        ProgramCode = programCode,
                    });

                    attempts++;
                }
                else
                {
                    return addBillPayeeResponse;
                }
            }

            throw new RequestHandlerException(503, 0, $"Max Number of Enroll Attempts exceeded({_maxNumberOfEnrollRequests}).");
        }

        public GssGetPayeeResponse GetPayee(GssGetPayeeRequest request)
        {
            var url = $"{_billPayUrl}/programs/{request.PartnerId}/accounts/{request.AccountIdentifier}/billpayPayees/{request.PayeeIdentifier}";
            const string method = "GET";
            var attempts = 0;
            while (attempts < _maxNumberOfEnrollRequests)
            {
                var response = _serviceInvokerProvider.GetWebResponseAsync<GssGetPayeeResponse>(url, method, null).Result;

                if (response.ErrorCode == "03002")
                {
                    try
                    {
                        EnrollCustomer(new BillPayEnrollRequest()
                        {
                            AccountIdentifier = request.AccountIdentifier,
                            ProgramCode = request.PartnerId,
                        });
                    }
                    catch
                    {
                        // ignored
                    }
                    finally
                    {
                        attempts++;
                    }
                }
                else
                {
                    return response;
                }
            }
            throw new RequestHandlerException(503, 0, $"Max Number of Enroll Attempts exceeded({_maxNumberOfEnrollRequests}).");
        }

        public GssGetPayeeListResponse GetPayeeList(GssGetPayeeListRequest request)
        {
            var url = $"{_billPayUrl}/programs/{request.PartnerId}/accounts/{request.AccountIdentifier}/billpayPayees";
            const string method = "GET";
            var attempts = 0;
            while (attempts < _maxNumberOfEnrollRequests)
            {
                var response = _serviceInvokerProvider.GetWebResponseAsync<GssGetPayeeListResponse>(url, method, null).Result;

                if (response.ErrorCode == "03002")
                {
                    try
                    {
                        EnrollCustomer(new BillPayEnrollRequest()
                        {
                            AccountIdentifier = request.AccountIdentifier,
                            ProgramCode = request.PartnerId,
                        });
                    }
                    catch
                    {
                        // ignored
                    }
                    finally
                    {
                        attempts++;
                    }
                }
                else
                {
                    return response;
                }
            }
            throw new RequestHandlerException(503, 0, $"Max Number of Enroll Attempts exceeded({_maxNumberOfEnrollRequests}).");
        }

        public SearchPayeesResponse SearchPayees(SearchPayeesRequest searchPayeesRequest, string programCode, string accountIdentifier)
        {
            var url = GenerateBillPayPayeesSearchUrl(programCode, accountIdentifier);
            int attempts = 0;
            while (attempts < _maxNumberOfEnrollRequests)
            {
                var addBillPayeeResponse =
                _serviceInvokerProvider.GetResponseAsync<SearchPayeesRequest, SearchPayeesResponse>(url, "POST", searchPayeesRequest, null).Result;

                if (addBillPayeeResponse.ErrorCode == "03002")
                {
                    EnrollCustomer(new BillPayEnrollRequest()
                    {
                        AccountIdentifier = accountIdentifier,
                        ProgramCode = programCode,
                    });

                    attempts++;
                }
                else
                {
                    return addBillPayeeResponse;
                }
            }
            throw new RequestHandlerException(503, 0, $"Max Number of Enroll Attempts exceeded({_maxNumberOfEnrollRequests}).");
        }

        public UpdateBillPayeeResponse UpdateBillPayee(UpdateBillPayeeRequest updateBillPayeeRequest, string programCode, string accountIdentifier, string payeeIdentifier)
        {
            var updateBillPayeeResponse =
                _serviceInvokerProvider.GetResponseAsync<UpdateBillPayeeRequest, UpdateBillPayeeResponse>(
                    GenerateBillPayPayeesUrl(programCode, accountIdentifier, payeeIdentifier),
                    "PUT", updateBillPayeeRequest, null).Result;

            return updateBillPayeeResponse;
        }

        public CancelBillPayPayeeResponse CancelBillPayPayee(string programCode, string accountIdentifier, string payeeIdentifier)
        {
            var updateBillPayeeResponse =
                _serviceInvokerProvider.GetResponseAsync<CancelBillPayPayeeResponse>(
                    GenerateBillPayPayeesUrl(programCode, accountIdentifier, payeeIdentifier),
                    "DELETE", null, null).Result;

            return updateBillPayeeResponse;
        }

        public GssAddPaymentResponse AddPayment(GssAddPaymentRequest request)
        {
            var isEnforceTerm = _baasConfiguration.GetEnforceTermsRequireConfig("billpay", request.PartnerId);

            _logger.Debug($"Enforce Term - accountIdentifier : {request.AccountIdentifier} and isEnforceTerm : {isEnforceTerm}");

            if (isEnforceTerm)
            {
                _logger.Debug($"Bill Pay terms were not accepted.! - accountIdentifier : {request.AccountIdentifier} and isEnforceTerm : {isEnforceTerm}");
                throw new RequestHandlerException(5, 55, "Bill Pay terms were not accepted.");
            }

            var accountInfo = _accountRepository.GetAccountInfoByAccountIdentifier(request.AccountIdentifier);

            if (accountInfo == null || accountInfo.AccountKey == 0)
            {
                throw new RequestHandlerException(404, 0, $"Unable to locate AccountPrimaryConsumerProfile by AccountIdentifier: {request.AccountIdentifier}");
            }
            #region JointAccount                   
            var isJointAccount = _accountRepository.IsJointAccount(request.AccountIdentifier);          
            if (isJointAccount && string.IsNullOrEmpty(request.UserIdentifier))
            {
                throw new RequestHandlerException(3, 107, "User identifier is required for account which has multiple individual account holders.");
            }
            if (isJointAccount && !accountInfo.AccountHolders.Where(m => request.UserIdentifier.Equals(m.UserIdentifier.ToString(), StringComparison.OrdinalIgnoreCase)).Any())
            {               
                throw new RequestHandlerException(3, 107, "User identifier is valid for account which has multiple individual account holders.");               
            }
            #endregion

            request.BankAccountNumber = accountInfo.AccountNumber;
            request.BankAccountType = "dda";
            request.BankRoutingNumber = accountInfo.RoutingNumber;

            var url = $"{_billPayUrl}/programs/{request.PartnerId}/accounts/{request.AccountIdentifier}/billpayPayments";
            const string method = "POST";
            var response =
                _serviceInvokerProvider.GetResponseAsync<GssAddPaymentRequest, GssAddPaymentResponse>(
                    url, method, request, null).Result;

            return response;
        }


        public GssUpdatePaymentResponse UpdatePayment(GssUpdatePaymentRequest request)
        {
            AccountPrimaryConsumerProfile accountInfo = _accountRepository.GetAccountPrimaryConsumerProfile(request.AccountIdentifier);

            if (accountInfo == null || accountInfo.AccountKey == 0)
            {
                throw new RequestHandlerException(404, 0, $"Unable to locate AccountPrimaryConsumerProfile by AccountIdentifier: {request.AccountIdentifier}");
            }

            request.BankAccountNumber = accountInfo.AccountNumber;
            request.BankAccountType = "dda";
            request.BankRoutingNumber = accountInfo.RoutingNumber;

            var url = $"{_billPayUrl}/programs/{request.PartnerId}/accounts/{request.AccountIdentifier}/billpayPayments/{request.PaymentIdentifier}";
            const string method = "PUT";

            return _serviceInvokerProvider.GetResponseAsync<GssUpdatePaymentRequest, GssUpdatePaymentResponse>(url, method, request, null).Result;
        }

        public GssDeletePaymentResponse DeletePayment(GssDeletePaymentRequest request)
        {
            var url = $"{_billPayUrl}/programs/{request.PartnerId}/accounts/{request.AccountIdentifier}/billpayPayments/{request.PaymentIdentifier}";
            const string method = "DELETE";

            return _serviceInvokerProvider.GetResponseAsync<GssDeletePaymentResponse>(url, method, null, null).Result;
        }

        public GssGetPaymentResponse GetPayment(GssGetPaymentRequest request)
        {
            var url = $"{_billPayUrl}/programs/{request.PartnerId}/accounts/{request.AccountIdentifier}/billpayPayments/{request.PaymentIdentifier}";
            const string method = "GET";

            return _serviceInvokerProvider.GetResponseAsync<GssGetPaymentResponse>(url, method, null, null).Result;
        }

        public GssGetAllPaymentsResponse GetAllPayments(GssGetAllPaymentsRequest request)
        {
            string query = buildQuery(request);
            var url = $"{_billPayUrl}/programs/{request.PartnerId}/accounts/{request.AccountIdentifier}/billpayPayments{query}";
            const string method = "GET";

            return _serviceInvokerProvider.GetResponseAsync<GssGetAllPaymentsResponse>(url, method, null, null).Result;
        }

        #region Private Methods
        private string buildQuery(GssGetAllPaymentsRequest request)
        {
            string statusFilter = $"statusFilter={request.PaymentFilter.StatusFilter}";
            string startingDate = String.IsNullOrEmpty(request.PaymentFilter.StartingPaymentDate)
                ? String.Empty : $"&startingPaymentDate={request.PaymentFilter.StartingPaymentDate}";
            string endingDate = String.IsNullOrEmpty(request.PaymentFilter.EndingPaymentDate)
                ? String.Empty : $"&endingPaymentDate={request.PaymentFilter.EndingPaymentDate}";
            string offset = String.IsNullOrEmpty(request.PaymentFilter.Offset)
                ? String.Empty : $"&offset={request.PaymentFilter.Offset}";
            string pageSize = request.PaymentFilter.PageSize == null
                ? String.Empty
                : $"&pageSize={request.PaymentFilter.PageSize}";

            return $"?{statusFilter}{startingDate}{endingDate}{offset}{pageSize}";
        }
        private string GenerateBillPayBaseUrl(string programCode, string accountIdentifier)
        {
            return _billPayUrl + $"/programs/{programCode}/accounts/{accountIdentifier}";
        }

        private string GenerateEnrollUrl(string programCode, string accountIdentifier)
        {
            return GenerateBillPayBaseUrl(programCode, accountIdentifier) + "/enroll";
        }

        private string GenerateBillPayPayeesUrl(string programCode, string accountIdentifier)
        {
            return GenerateBillPayBaseUrl(programCode, accountIdentifier) + "/billpayPayees";
        }
        private string GenerateBillPayPayeesUrl(string programCode, string accountIdentifier, string payeeIdentifier)
        {
            return GenerateBillPayPayeesUrl(programCode, accountIdentifier) + "/" + payeeIdentifier;
        }

        private string GenerateBillPayPayeesSearchUrl(string programCode, string accountIdentifier)
        {
            return GenerateBillPayPayeesUrl(programCode, accountIdentifier) + "/search";
        }

        private string GenerateBillPayBillPaymentsUrl(string programCode, string accountIdentifier)
        {
            return GenerateBillPayBaseUrl(programCode, accountIdentifier) + "/billpayPayments";
        }

        private string GenerateBillPayBillPaymentsUrl(string programCode, string accountIdentifier, string paymentIdentifier)
        {
            return GenerateBillPayBillPaymentsUrl(programCode, accountIdentifier) + "/" + paymentIdentifier;
        }

        #endregion
    }
}
