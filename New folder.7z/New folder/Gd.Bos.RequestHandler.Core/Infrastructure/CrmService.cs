﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Services.Crm;
using Gd.Bos.RequestHandler.Core.Utils;
using Newtonsoft.Json;
using NLog;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using System.Runtime.InteropServices;
using Gd.K8s.Containers.Utils.Extensions;
using Gd.K8s.Containers.Utils.Models.Kerberos;
using Gd.K8s.Containers.Utils.Authentication;
using RabbitMQ.Client;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    [ExcludeFromCodeCoverage(Justification = "Will be tested later")]
    public class CrmService : ICrmService
    {
        public CrmService(IServiceInvokeProvider serviceInvokeProvider, IRequestHandlerSettings settings)
        {
            _serviceInvokerProvider = serviceInvokeProvider;
            _configuration = settings;
        }

        public AddNoteResponse AddNote(Account account, string programCode)
        {
            AddNoteRequest request = new AddNoteRequest
            {
                Category = NoteCategory.Card,
                System = NoteSystem.Backend,
                UserName = _userName,
                ProgramCode = programCode
            };

            Dictionary<string, string> options = new Dictionary<string, string>();

            if (OptionsContext.Current.IsDefined("X-GD-Bos-RequestHandler-CrmNotesCorrelationId"))
                options.Add("x-CorrelationId", OptionsContext.Current.GetString("X-GD-Bos-RequestHandler-CrmNotesCorrelationId"));

            if (OptionsContext.Current.IsDefined("X-GD-Bos-RequestHandler-CrmNotesUserName"))
                options.Add("x-UserName", OptionsContext.Current.GetString("X-GD-Bos-RequestHandler-CrmNotesUserName"));

            if (account.AccountStatus == AccountStatus.Normal)
                request.Note = "Return Mail Received. Instructions to Care agents: update address.";
            else if (account.AccountStatus == AccountStatus.Closed)
                request.Note = "Return Mail Received. No action needed as account is closed.";

            var response = GetWebResponse<AddNoteResponse>(
                GenerateNotesUrl(programCode, account.AccountIdentifier.ToString()), "POST", JsonConvert.SerializeObject(request), options);

            return response;
        }

        public void AddNoteForMRDC(string accountIdentifier, string programCode, string mrdcNote)
        {
            AddNote(accountIdentifier, programCode, mrdcNote, NoteCategory.MRDC, "MRDC Finance Process Team");
        }

        public void AddNote(string accountIdentifier, string programCode, string note, NoteCategory noteCategory, string noteUserName, Guid requestId = default, NoteSystem noteSystem = NoteSystem.Backend)
        {
            try
            {
                // Check if noteUserName is null and assign a default value if necessary
                if (string.IsNullOrWhiteSpace(noteUserName))
                {
                    noteUserName = Environment.MachineName; // Default to the machine name
                }
                AddNoteRequest request = new AddNoteRequest
                {
                    Category = noteCategory,
                    System = noteSystem,
                    UserName = noteUserName,
                    ProgramCode = programCode
                };
                Dictionary<string, string> options = new Dictionary<string, string>();
                options.Add("x-CorrelationId", requestId == default ? Guid.NewGuid().ToString() : requestId.ToString());
                options.Add("x-sessionID", Guid.NewGuid().ToString());
                options.Add("x-UserName", noteUserName);
                request.Note = note;
                request.RequestHeader = new RequestHeader
                {
                    Options = options,
                };
                _logger.Info($"AddNote request: {JsonConvert.SerializeObject(request)}");

                var response = GetWebResponse<AddNoteResponse>(
                    GenerateNotesUrl(programCode, accountIdentifier), "POST", JsonConvert.SerializeObject(request), options);

                _logger.Info($"AddNote response: {JsonConvert.SerializeObject(response)}");
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }

        private string GenerateNotesUrl(string programCode, string accountIdentifier)
        {
            var notesUrl = $"{_configuration.CareMtApiBaseUrl}/{programCode}/accounts/{accountIdentifier}/Notes";
            _logger.Info($"Notes Url for Account {accountIdentifier}: {notesUrl}");
            return notesUrl;
        }

        public static async Task<HttpWebResponse> GetResponseAsync(string uri, string method, string requestJson, Dictionary<string, string> options, int? requestTimeout = null)
        {
            var httpWebRequest = (HttpWebRequest)WebRequest.Create(uri);
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = method;

            var kerberosTicketOptions= new GenerateKerberosTicketOptions
            {
                UserName = Environment.GetEnvironmentVariable("RequestHandler__Kerberos__Username"),
                Password = Environment.GetEnvironmentVariable("RequestHandler__Kerberos__Password"),
                DomainRealm = Environment.GetEnvironmentVariable("RequestHandler__Kerberos__DnsDomain"),
                DownstreamSpn = new Uri(uri).GetServiceHttpSpn(),
            };

            var ticket = await KerberosTicketGenerator.GenerateAsync(kerberosTicketOptions);
            var encodedTicket = ticket.EncodeGssApi().ToArray();
            httpWebRequest.Headers.Add("Authorization", $"Negotiate {Convert.ToBase64String(encodedTicket)}");


            if (options.Count > 0)
            {
                foreach (var keyItem in options)
                    httpWebRequest.Headers.Add(keyItem.Key, keyItem.Value);
            }

            using (StreamWriter streamWriter = new StreamWriter(await httpWebRequest.GetRequestStreamAsync()))
            {
                await streamWriter.WriteAsync(requestJson);
                streamWriter.Flush();
                streamWriter.Close();
            }

            HttpWebResponse httpResponse = (HttpWebResponse)await httpWebRequest.GetResponseAsync();

            return httpResponse;
        }

        public static T GetWebResponse<T>(string uri, string method, string requestJson, Dictionary<string, string> options, int? requestTimeout = null)
        {
            Task<HttpWebResponse> webResponse = GetResponseAsync(uri, method, requestJson, options, requestTimeout);
            if (webResponse == null) return default(T);
            return Deserialize<T>(webResponse.Result.GetResponseStream());
        }


        public static T Deserialize<T>(Stream s)
        {
            var jd = new Newtonsoft.Json.JsonSerializer();
            T result = jd.Deserialize<T>(new Newtonsoft.Json.JsonTextReader(new StreamReader(s)));
            return result;
        }

        private readonly string _userName = IdentityHelper.GetIdentityName();
        private readonly IServiceInvokeProvider _serviceInvokerProvider;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        private readonly IRequestHandlerSettings _configuration;
    }
}
