﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Services.Crypto;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Logic;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Newtonsoft.Json;
using NLog;
using RequestHandler.Core.Domain.Services.RetailCard;
using RequestHandler.Core.Domain.Services.RetailCard.Enum;
using RequestHandler.Core.Domain.Services.RetailCard.Model;
using GetRetailCardBalanceTransferStatusResponse = RequestHandler.Core.Domain.Services.RetailCard.Model.GetRetailCardBalanceTransferStatusResponse;
using GetTransactionsRequest = RequestHandler.Core.Domain.Services.RetailCard.Model.GetTransactionsRequest;
using GetTransactionsResponse = RequestHandler.Core.Domain.Services.RetailCard.Model.GetTransactionsResponse;
using ReportLostStolenRequest = RequestHandler.Core.Domain.Services.RetailCard.Model.ReportLostStolenRequest;
using ReportLostStolenResponse = RequestHandler.Core.Domain.Services.RetailCard.Model.ReportLostStolenResponse;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using SetAtmPinRequest = RequestHandler.Core.Domain.Services.RetailCard.Model.SetAtmPinRequest;
using SetAtmPinResponse = RequestHandler.Core.Domain.Services.RetailCard.Model.SetAtmPinResponse;
using TransactionStatus = RequestHandler.Core.Domain.Services.RetailCard.Model.TransactionStatus;
using VerificationActivityType = Gd.Bos.RequestHandler.Core.Domain.Model.Account.VerificationActivityType;
using VerificationStatus = Gd.Bos.RequestHandler.Core.Domain.Model.Account.VerificationStatus;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    [ExcludeFromCodeCoverage(Justification = "mainly handles infrastructure operations and external dependencies")]
    public class AsyncRetailCardService : IAsyncRetailCardService
    {
        private static readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        private readonly IServiceInvokeProvider _serviceInvokeProvider;
        private readonly IProductService _productService;
        private readonly ICryptoService _cryptoService;
        private readonly IAccountRepository _accountRepository;
        private readonly string _gssAccountUtilityBaseUrl;
        private readonly IPaymentIdentifierRepository _paymentIdentifierRepository;
        private readonly ITokenizerService _tokenizerService;

        public AsyncRetailCardService(IServiceInvokeProvider serviceInvokeProvider, IProductService productService,
            ICryptoService cryptoService, IAccountRepository accountRepository, IPaymentIdentifierRepository paymentIdentifierRepository, ITokenizerService tokenizerService)
        {
            _serviceInvokeProvider = serviceInvokeProvider;
            _productService = productService;
            _cryptoService = cryptoService;
            _accountRepository = accountRepository;
            _paymentIdentifierRepository = paymentIdentifierRepository;
            _tokenizerService = tokenizerService;
            _gssAccountUtilityBaseUrl = Configuration.Configuration.Current.GSSLegacyAccountUtilityBaseUrl;
        }

        public ActivateRetailTempCardResponse ActivateRetailTempCard(string programCode, ActivateRetailTempCardRequest request)
        {
            throw new NotImplementedException();
        }

        public ConsumePinResponse ConsumerPin(ConsumePinRequest request)
        {
            throw new NotImplementedException();
        }

        public void DeactivateLegacyTempCard(DeactivateRetailTempCardRequest request)
        {
            throw new NotImplementedException();
        }

        public async Task<GetPursesResponse> GetBalance(GetPursesRequest request)
        {
            GetPursesResponse getPursesResponse = null;

            _logger.Debug($"RetailCardService - GetBalance Call to GSS to pull balance from NEC. requestId:{request.RequestHeader.RequestId},accountIdentifier:{request.AccountIdentifier}");

            GetTimeout("X-GD-Bos-GSSLegacyAccountUtility-GetBalance", out var requestTimeout);

            GetBalanceRequest getBalanceRequest = new GetBalanceRequest()
            {
                RequestId = request.RequestHeader.RequestId.ToString(),
                ProgramCode = request.ProgramCode,
                AccountIdentifier = request.AccountIdentifier
            };

            //_gssAccountUtilityBaseUrl = "https://gssactutl.qa.nextestate.com/legacyaccountutility/V1";

            var url1 = _gssAccountUtilityBaseUrl + $"/programs/{request.ProgramCode}/retailcard/getbalance";

            try
            {
                var jsonRequest = JsonConvert.SerializeObject(getBalanceRequest);

                var response = await _serviceInvokeProvider.GetWebResponseAsync<GetBalanceResponse>(url1
                    , "POST", jsonRequest, requestTimeout);


                if (response.StatusCode == 0)
                {
                    //var dtAvailableBalanceAsOfUtc = TimeZoneInfo.ConvertTimeToUtc(response.AvailableBalance.AsOf, TimeZoneInfo.Local);
                    //var dtLedgerBalanceAsOfUtc = TimeZoneInfo.ConvertTimeToUtc(response.LedgerBalance.AsOf, TimeZoneInfo.Local);

                    getPursesResponse = new GetPursesResponse()
                    {
                        Purses = new Purse[]
                        {
                            new Purse()
                            {
                                AvailableBalance = response.AvailableBalance.Amount,
                                AvailableBalanceAsOfDateTime = response.AvailableBalance.AsOf,
                                LedgerBalance = response.LedgerBalance.Amount,
                                LedgerBalanceAsOfDateTime = response.LedgerBalance.AsOf,
                                PurseType = PurseType.Primary,
                                Status = PurseStatus.Active
                            }
                        }

                    };
                    getPursesResponse.ResponseHeader = new ResponseHeader()
                    {
                        StatusCode = 0,
                        SubStatusCode = 0,
                        Message = "Success",
                        ResponseId = request.RequestHeader.RequestId
                    };
                }
                else
                {
                    getPursesResponse = new GetPursesResponse();
                    getPursesResponse.ResponseHeader = new ResponseHeader()
                    {
                        StatusCode = 10,
                        SubStatusCode = 0,
                        Message = response.Message,
                        ResponseId = request.RequestHeader.RequestId
                    };
                }

            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"RetailCardService - GetBalance method failed for ProgramCode:{request.ProgramCode}, requestId:{request.RequestHeader.RequestId},AccountIdentifier:{request.AccountIdentifier}");

                getPursesResponse = new GetPursesResponse()
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        ResponseId = request.RequestHeader.RequestId,
                        StatusCode = 500,
                        Message = "Error occurred while fetching Retail card GetBalance."
                    }
                };
            }

            return getPursesResponse;
        }

        public GetLegacyTransactionResponse GetLegacyTransactions(GetLegacyTransactionRequest request)
        {
            throw new NotImplementedException();
        }

        public GetLegacyTransactionResponse GetLegacyTransactionsBySearchTerm(GetLegacyTransactionBySearchTermRequest request)
        {
            throw new NotImplementedException();
        }

        public GetPinKeyByExternIdResponse GetPinKeyByExternId(GetPinKeyByExternIdRequest request)
        {
            throw new NotImplementedException();
        }

        public GetRetailCardBalanceTransferStatusResponse GetRetailCardBalanceTransferStatus(string accountIdentifier, string programCode)
        {
            throw new NotImplementedException();
        }

        public GetRetailSaleInfoResponse GetRetailSaleInfo(GetRetailSaleInfoRequest request)
        {
            throw new NotImplementedException();
        }

        public GetRetailSaleInfoResponse GetRetailSaleInfo(int pinKey)
        {
            throw new NotImplementedException();
        }

        public ReportLostStolenResponse ReportLostStolen(string accountIdentifier, string programCode, Shared.Common.Core.CoreApi.Contract.Data.Enum.LossType lossType, DateTime? dateLastUsed, bool? policeNotified, string notes)
        {
            throw new NotImplementedException();
        }

        public Shared.Common.Core.CoreApi.Contract.Message.Response.SetAtmPinResponse SetAtmPin(Shared.Common.Core.CoreApi.Contract.Message.Request.SetAtmPinRequest request)
        {
            throw new NotImplementedException();
        }

        public SyncRegisterCardResponse SyncRegisterCard(SyncRegisterCardRequest request)
        {
            throw new NotImplementedException();
        }

        public MigrateAccountResponse TransferRetailTempCardBalance(string programCode, string accountIdentifier, MigrateAccountRequest request)
        {
            throw new NotImplementedException();
        }

        public GetBalanceResponse UpdateBalance(GetBalanceRequest request)
        {
            throw new NotImplementedException();
        }

        public UpgradeRetailTempToPersoResponse UpgradTempToPerso(UpgradeRetailTempToPersoRequest request)
        {
            throw new NotImplementedException();
        }

        public ValidateCvvResponse ValidateCard(ValidateCvvRequest request)
        {
            throw new NotImplementedException();
        }

        public bool VerifyPin(string programCode, string pan, CardExpirationDate expDate, string atmPin)
        {
            throw new NotImplementedException();
        }

        private void GetTimeout(string headerName, out int? requestTimeout)
        {
            requestTimeout = null;
            if (OptionsContext.Current.IsDefined(headerName))
            {
                requestTimeout = 1;
                if (int.TryParse(OptionsContext.Current.GetString(headerName), out var rt))
                    requestTimeout = rt;
            }
        }
    }
}
