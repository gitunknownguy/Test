﻿using System.Diagnostics.CodeAnalysis;

namespace RequestHandler.Core.Infrastructure
{
    public class InstantIssueEnrollmentProductCode
    {
        public string ProductCode { get; set; }
        public bool AcceptsInstantIssueEnrollment { get; set; }
        public string DefaultProductMaterialType { get; set; }
    }
}
