﻿using System;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Logic;
using NLog;
using RequestHandler.Core.Application;
using RequestHandler.Core.Domain.Services.AciRetailApi;
using RequestHandler.Core.Utils;
using GetAciPackageResponse = RequestHandler.Core.Domain.Services.AciRetailApi.GetAciPackageResponse;

namespace RequestHandler.Core.Infrastructure
{
    public class AciRetailService : IAciRetailService
    {
        private readonly IHttpClientAciRetailProvider _httpClientAciRetailProvider;

        public AciRetailService(IHttpClientAciRetailProvider httpClientAciRetailProvider)
        {
            _httpClientAciRetailProvider = httpClientAciRetailProvider;
        }

        public async Task<GetAciPackageResponse> GetPackageDetailsById(GetAciPackageRequest request)
        {
            GetAciPackageResponse response;
            try
            {
                response = await _httpClientAciRetailProvider.GetAciPackageResponse(request);
            }
            catch (Exception e)
            {
                response = new GetAciPackageResponse()
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        StatusCode = 5000,
                        SubStatusCode = 5011,
                        Message = e.Message,
                        ResponseId = request.RequestHeader.RequestId
                    }
                };
            }

            if (response?.ResponseHeader == null)
                throw new Exception($"Package did not return a recognizable response.");
            if (response.ResponseHeader?.StatusCode != 0)
            {
                Logger.Info("Get Aci Package failed {0}", response);
            }

            return response;
        }

        public async Task<UpdatePackageStatusResponse> UpdatePackageStatus(UpdatePackageStatusRequest request)
        {
            UpdatePackageStatusResponse response;
            try
            {
                response = await _httpClientAciRetailProvider.UpdatePackageStatusResponse(request);
            }
            catch (Exception e)
            {
                response = new UpdatePackageStatusResponse()
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        StatusCode = 5000,
                        SubStatusCode = 5011,
                        Message = e.Message,
                        ResponseId = request.RequestHeader.RequestId
                    }
                };
            }

            if (response?.ResponseHeader == null)
                throw new Exception($"Package did not return a recognizable response.");
            if (response.ResponseHeader?.StatusCode != 0)
            {
                Logger.Info("Update Aci Package failed {0}", response);
            }

            return response;
        }

        public async Task<GetAciPackageByAltPanResponse> GetAciPackageByAltPan(GetAciPackageByAltPanRequest request)
        {
            GetAciPackageByAltPanResponse response;
            try
            {
                response = await _httpClientAciRetailProvider.GetAciPackageByAltPan(request);
            }
            catch (Exception e)
            {
                response = new GetAciPackageByAltPanResponse()
                {
                    ResponseHeader = new ResponseHeader()
                    {
                        StatusCode = 5000,
                        SubStatusCode = 5011,
                        Message = e.Message,
                        ResponseId = request.RequestHeader.RequestId
                    }
                };
            }

            if (response?.ResponseHeader == null)
                throw new Exception($"{nameof(GetAciPackageByAltPan)} did not return a recognizable response.");
            if (response.ResponseHeader?.StatusCode != 0)
            {
                Logger.Info($"{nameof(GetAciPackageByAltPan)} failed {0}", response.SerializeToJson());
            }

            return response;
        }

        private static readonly ILogger Logger = LogManager.GetCurrentClassLogger();
    }
}
