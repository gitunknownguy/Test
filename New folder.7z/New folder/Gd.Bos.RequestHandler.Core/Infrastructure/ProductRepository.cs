﻿using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.Shared.Common.Caching;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.Shared.Common.UtilityCoreApi.Contract.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using Microsoft.Data.SqlClient;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    [ExcludeFromCodeCoverage(Justification = "Data Access")]
    public class ProductRepository : IProductRepository
    {
        public ProductRepository(IDataAccess dataAccess, ILazyCache lazyCache)
        {
            _dataAccess = dataAccess;
            _lazyCache = lazyCache;
        }

        public Product GetByProductCode(ProductCode productCode)
        {
            var products = _lazyCache.Get("PRODUCT_CODES", new TimeSpan(0, 2, 0, 0), () => GetAllProducts());
            var product = products.Find(p => ProductCode.FromString(p.Item3).Equals(productCode));
            if (product == null)
                throw new Exception("No Product exists for specified ProductCode.");

            return new Product(productCode, ProgramCode.FromString(product.Item4), product.Item1, product.Item2, product.Item5, product.Item6,
                product.Rest.Item2, product.Rest.Item3);
        }

        public Product GetByProductCode(ProductCode productCode, ProgramCode programCode)
        {
            Func<string, List<Tuple<int, string, string, string, string, string, int, Tuple<string, string, int>>>> getAllProduct = key
                 => _lazyCache.Get(key, new TimeSpan(0, 2, 0, 0), () => GetAllProducts());

            var products = getAllProduct("PRODUCT_CODES");
            var product = products.Find(p => ProductCode.FromString(p.Item3).Equals(productCode) && ProgramCode.FromString(p.Item4).Equals(programCode));
            if (product == null)
                throw new Exception("No Product exists for specified ProductCode.");

            return new Product(productCode,
                programCode,
                product.Item1,
                product.Item2,
                product.Item5,
                product.Item6,
                product.Rest.Item2,
                product.Rest.Item3);//processor key
        }

        public (bool result, ProductTierData? npnrProduct, ProductTierData? emvProduct) IsGbosRetailProductTier(int productTierKey)
        {
            List<ProductTierData> allProductTiers = GetAllCachedProductTiers();
            ProductTierData? npnrProduct = null;
            ProductTierData? emvProduct = null;
            
            var productTier = allProductTiers.Find(n => n.ProductTierKey == productTierKey);
            if (productTier == null)
                return (false, null, null);

            var deviceStyleDefinitions =
                GetProductTierDefinitionByProductCodeAndProductTierAttributeKey(productTier.ProductCode, 25);

            if (productTier.ProductClassKey == 1)
            {
                npnrProduct = productTier;
                
                var npnrDefinition =
                    deviceStyleDefinitions.Find(n => n.ProductTierKey == productTier.ProductTierKey);

                if (npnrDefinition.ProductTierKey == 0)
                    return (true, npnrProduct, null);
                
                var emv = deviceStyleDefinitions.Find(n =>
                    n.Value.Equals(npnrDefinition.Value) && n.ProductTierKey != npnrDefinition.ProductTierKey);

                if (emv.ProductTierKey == 0)
                    return (true, npnrProduct, null);
                
                emvProduct = allProductTiers.Find(n => n.ProductTierKey == emv.ProductTierKey);
                
                return (true, npnrProduct, emvProduct);
            }

            emvProduct = productTier;
                
            var emvDefinition =
                deviceStyleDefinitions.Find(n => n.ProductTierKey == productTier.ProductTierKey);
            
            if (emvDefinition.ProductTierKey == 0)
                return (false, null, emvProduct);
            
            var baseProductDefinition = deviceStyleDefinitions.Find(n =>
                n.Value.Equals(emvDefinition.Value) && n.ProductTierKey != emvDefinition.ProductTierKey);
                
            if (baseProductDefinition.ProductTierKey == 0)
                return (false, null, emvProduct);
                
            npnrProduct = allProductTiers.Find(n => n.ProductTierKey == baseProductDefinition.ProductTierKey);
            if (npnrProduct == null)
                return (false, null, emvProduct);
                
            return (npnrProduct.ProductClassKey == 1, npnrProduct, emvProduct);
        }

        public string GetNameByProductCode(ProductCode productCode, ProgramCode programCode)
        {
            Func<string, List<Tuple<int, string, string, string, string, string, int, Tuple<string, string, int>>>> getAllProductUnformatted = key
                 => _lazyCache.Get(key, new TimeSpan(0, 2, 0, 0), () => GetAllProducts(false));

            var products = getAllProductUnformatted("PRODUCT_CODES_UNFORMATTED");
            var product = products.Find(p => ProductCode.FromString(p.Item3).Equals(productCode) && ProgramCode.FromString(p.Item4).Equals(programCode));
            if (product == null)
                throw new Exception("No Product exists for specified ProductCode.");

            return product.Item2;
        }

        public Product GetProductByBin(int binProductKey)
        {
            Func<string, List<Tuple<int, string, string, string, string, string, int, Tuple<string, string, int>>>> getAllProduct = key
                 => _lazyCache.Get(key, new TimeSpan(0, 2, 0, 0), () => GetAllProducts());
            var products = getAllProduct("PRODUCT_BINS_RH");
            var product = products.Find(p => p.Item7 == binProductKey);
            if (product == null)
                throw new Exception($"No Product exists for specified binProductKey {binProductKey}.");
            return new Product(ProductCode.FromString(product.Item3), ProgramCode.FromString(product.Item4), product.Item1, product.Item2, product.Item5, product.Item6);
        }

        public IEnumerable<string> GetProductBinsByProgramCode(ProgramCode programCode)
        {
            Func<string, List<Tuple<int, string, string, string, string, string, int, Tuple<string, string, int>>>> getAllProduct = key
                 => _lazyCache.Get(key, new TimeSpan(0, 2, 0, 0), () => GetAllProducts());
            var productTuples = getAllProduct($"PRODUCT_{nameof(GetProductBinsByProgramCode).ToUpper()}_RH");
            var bins = productTuples.Where(x =>
                    x.Item4.Equals(programCode?.ToString(), StringComparison.InvariantCultureIgnoreCase))
                .Select(x => x.Rest.Item1?.Trim());
            return bins;
        }
        
        public ProductTierData GetProductTierByProductCodeMaterialType(string productCode, bool requestPhysicalCard, string productMaterialType)
        {
            List<ProductTierData> allProductTiers = GetAllCachedProductTiers();

            List<ProductTierData> productTierDatas = allProductTiers
                .Where(o => string.Equals(o.ProductCode, productCode, StringComparison.OrdinalIgnoreCase))
                .ToList();


            if (!requestPhysicalCard && string.IsNullOrWhiteSpace(productMaterialType))
            {
                return GetDefaultVirtualTier(productTierDatas, allProductTiers, productCode);
            }

            if (string.IsNullOrWhiteSpace(productMaterialType))
            {
                return productTierDatas.Find(o => o.IsDefault);
            }

            var defaultVirtualTier = productTierDatas.FirstOrDefault(o => string.Equals(o.ProductTierClass, "Virtual", StringComparison.OrdinalIgnoreCase));
            productTierDatas = productTierDatas.FindAll(o => string.Equals(o.ProductMaterialType, productMaterialType, StringComparison.OrdinalIgnoreCase));

            if (requestPhysicalCard)
            {
                return productTierDatas
                    .FindAll(o => o.IsDefault && !string.Equals(o.ProductTierClass, "Virtual", StringComparison.OrdinalIgnoreCase))
                    .FirstOrDefault() ?? productTierDatas
                    .FindAll(o =>  !string.Equals(o.ProductTierClass, "Virtual", StringComparison.OrdinalIgnoreCase))
                    .FirstOrDefault();
            }
            else
            {
                if (string.Equals(productTierDatas.FirstOrDefault()?.ProductTierClass, "Virtual", StringComparison.OrdinalIgnoreCase))
                {
                    return productTierDatas.FirstOrDefault();
                }

                var virtualTier = GetVirtualTierByEmvProductMaterialType(productTierDatas, allProductTiers, productCode);

                return virtualTier ?? defaultVirtualTier;
            }

        }

        public ProductTierData GetProductTierByProductTierKey(int productTierKey, short processorKey)
        {
            List<ProductTierData> allProductTiers = GetAllCachedProductTiers();

            ProductTierData productTierData = allProductTiers
                .Where(o => o.ProductTierKey == productTierKey && o.ProcessorKey == processorKey)
                .FirstOrDefault();
            return productTierData;
        }


        private ProductTierData? GetDefaultVirtualTier(List<ProductTierData> productTierData,
            List<ProductTierData> allProductTiers,
            string productCode)
        {
            var virtualTiers = productTierData.Where(o => string.Equals(o.ProductTierClass, "Virtual", StringComparison.OrdinalIgnoreCase));
            
            var defaultVirtualTier = virtualTiers.FirstOrDefault();
            if (virtualTiers.Count() <= 1)
            {
                return defaultVirtualTier;
            }
            
            var defaultTier = productTierData.Find(o => o.IsDefault);
            if(defaultTier.ProductTierClass.Equals("Virtual", StringComparison.OrdinalIgnoreCase))
            {
                return defaultTier;
            }
            
            // Get all device style definitions under one product code, 25 means ACIDeviceStyleID
            var deviceStyleDefinitions =
                GetProductTierDefinitionByProductCodeAndProductTierAttributeKey(productCode, 25);

            var nonVirtualTierDefinition =
                deviceStyleDefinitions.FirstOrDefault(n => n.ProductTierKey == defaultTier.ProductTierKey);
            
            if (nonVirtualTierDefinition.ProductTierKey == 0)
                return defaultVirtualTier;

            // virtual tier has the same device style as EMV tier
            var virtualTierDefinition = deviceStyleDefinitions.FirstOrDefault(n =>
                n.Value.Equals(nonVirtualTierDefinition.Value) && n.ProductTierKey != defaultTier.ProductTierKey);

            if (virtualTierDefinition.ProductTierKey == 0)
                return defaultVirtualTier;
            
            // double confirm if the virtual tier is a virtual tier
            var virtualTierData = allProductTiers.FirstOrDefault(n =>
                n.ProductTierKey == virtualTierDefinition.ProductTierKey &&
                n.ProductTierClass.Equals("Virtual", StringComparison.OrdinalIgnoreCase));

            return virtualTierData ?? defaultVirtualTier;
        }
        
        
        private ProductTierData? GetVirtualTierByEmvProductMaterialType(List<ProductTierData> productTierData,
            List<ProductTierData> allProductTiers,
            string productCode)
        {
            if (productTierData.Count is 0 or > 1)
                return null;
            
            var tierData = productTierData.First();
            
            // Get all device style definitions under one product code, 25 means ACIDeviceStyleID
            var deviceStyleDefinitions =
                GetProductTierDefinitionByProductCodeAndProductTierAttributeKey(productCode, 25);

            var nonVirtualTierDefinition =
                deviceStyleDefinitions.FirstOrDefault(n => n.ProductTierKey == tierData.ProductTierKey);

            if (nonVirtualTierDefinition.ProductTierKey == 0)
                return null;

            // virtual tier has the same device style as EMV tier
            var virtualTierDefinition = deviceStyleDefinitions.FirstOrDefault(n =>
                n.Value.Equals(nonVirtualTierDefinition.Value) && n.ProductTierKey != tierData.ProductTierKey);

            if (virtualTierDefinition.ProductTierKey == 0)
                return null;

            // double confirm if the virtual tier is a virtual tier
            var virtualTierData = allProductTiers.FirstOrDefault(n =>
                n.ProductTierKey == virtualTierDefinition.ProductTierKey &&
                n.ProductTierClass.Equals("Virtual", StringComparison.OrdinalIgnoreCase));

            return virtualTierData;
        }

        private List<(int ProductKey, string ProductCode, string ProgramCode, string Value, int ProductTierKey)>
            GetProductTierDefinitionByProductCodeAndProductTierAttributeKey(string productCode,short productTierAttributeKey)
        {
            var productTiers =
                _lazyCache.Get($"{nameof(GetProductTierDefinitionByProductTierAttributeKey)}_{productTierAttributeKey}",
                        new TimeSpan(1,
                            0,
                            0,
                            0),
                        () => GetProductTierDefinitionByProductTierAttributeKey(productTierAttributeKey)).
                    Where(n => n.ProductCode.Equals(productCode, StringComparison.OrdinalIgnoreCase)).
                    ToList();

            return productTiers;
        }
        
        private List<(int ProductKey, string ProductCode,string ProgramCode,string Value,int ProductTierKey)> 
            GetProductTierDefinitionByProductTierAttributeKey(short productTierAttributeKey)
        {
            var returnValue = new List<(int ProductKey,string ProductCode, string ProgramCode, string Value, int ProductTierKey)>();
            
            var parameters = new[]
            {
                new SqlParameter()
                {
                    ParameterName = "ProductTierAttributeKey",
                    Value = productTierAttributeKey,
                    SqlDbType = SqlDbType.SmallInt
                }
            };
            using var reader = _dataAccess.ExecuteReader("GetProductTierDefinitionByProductTierAttributeKey",
                _dataAccess.CreateConnection(),
                parameters);

            while (reader.Read())
            {
                var productKey = reader.GetInt32(reader.GetOrdinal("ProductKey"));
                var productCode = reader.GetString(reader.GetOrdinal("ProductCode"));
                var programCode = reader.GetString(reader.GetOrdinal("ProgramCode"));
                var value = reader.GetString(reader.GetOrdinal("Value"));
                var productTierKey = reader.GetInt32(reader.GetOrdinal("ProductTierKey"));
                returnValue.Add((productKey, productCode, programCode, value, productTierKey));
            }

            return returnValue;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns>productKey, produdctName, productCode, programCode, achPrefix, abaRoutingNumber, binProductKey, bin,bankName</returns>
        private List<Tuple<int, string, string, string, string, string, int, Tuple<string, string, int>>> GetAllProducts(bool lowerCaseName = true)
        {
            var returnValue = new List<Tuple<int, string, string, string, string, string, int, Tuple<string, string, int>>>();
            using (var reader = _dataAccess.ExecuteReader("GetAllProduct", _dataAccess.CreateConnection(), null))
            {
                while (reader.Read())
                {
                    var productKey = reader.GetInt32(0);
                    var productName = lowerCaseName ? reader.GetString(1).ToLower() : reader.GetString(1);
                    var productCode = reader.GetString(2);
                    var programCode = reader.GetString(3);
                    var achPrefix = reader.IsDBNull(4) ? null : reader.GetString(4);
                    var bin = reader.IsDBNull(5) ? null : reader.GetString(5);
                    var bankName = reader.IsDBNull(6) ? string.Empty : reader.GetString(6);
                    var abaRoutingNumber = reader.IsDBNull(7) ? null : reader.GetString(7);
                    int binProductKey = reader["BINProductKey"] == DBNull.Value ? 0 : Convert.ToInt32(reader["BINProductKey"]);
                    int binProcessorKey = reader["ProcessorKey"] == DBNull.Value ? 1 : Convert.ToInt32(reader["ProcessorKey"]);

                    returnValue.Add(new Tuple<int, string, string, string, string, string, int, Tuple<string, string, int>>(productKey, productName,
                        productCode,
                        programCode,
                        achPrefix,
                        abaRoutingNumber,
                        binProductKey,
                        new Tuple<string, string, int>(bin, bankName, binProcessorKey)));
                }
            }

            return returnValue;
        }

        private List<ProductTierData> GetAllProductTiers()
        {
            var pts = new List<ProductTierData>();

            using var reader = _dataAccess.ExecuteReader("GetAllProductTiersV2", _dataAccess.CreateConnection(), null);
            while (reader.Read())
            {
                pts.Add(new()
                {
                    ProductKey = GetInt32(reader, "ProductKey"),
                    ProductCode = GetString(reader, "ProductCode"),
                    ProductClassKey = GetInt16(reader, "ProductClassKey"),
                    ProductTierKey = GetInt32(reader, "ProductTierKey"),
                    ProductTier = GetString(reader, "ProductTier"),
                    ProductTierClassKey = GetInt16(reader, "ProductTierClassKey"),
                    IsDefault = GetBoolean(reader, "IsDefault"),
                    ProductTierAttributeKey = GetInt16(reader, "ProductTierAttributeKey"),
                    CardStockValue = GetString(reader, "CardStockValue"),
                    ProductTierClass = GetString(reader, "ProducttierClass"),
                    ProductMaterialType = GetString(reader, "ProductmaterialType"),
                    BinProductKeyValue = GetString(reader, "BINProductKeyValue"),
                    ProcessorKey = GetInt16(reader, "ProcessorKey"),
                });
            }

            return pts;
        }

        public ProductTypeInfo GetProductTypeByProductKey(int productKey)
        {
            List<ProductTypeInfo> AllProductTypes(string key) => _lazyCache.Get(key, new TimeSpan(0, 2, 0, 0), GetAllProductTypes);

            List<ProductTypeInfo> allProductTypes = AllProductTypes($"PRODUCT_TYPE_RH");
            var productType = allProductTypes.FirstOrDefault(x => x.ProductKey == productKey);

            return productType;
        }

        public Product GetProductByKey(int productKey)
        {
            var products = _lazyCache.Get("PRODUCT_CODES", new TimeSpan(0, 2, 0, 0), () => GetAllProducts());
            var product = products.Find(p => p.Item1 == productKey);
            if (product == null)
                throw new Exception($"No Product exists for specified ProductKey {productKey}.");

            return new Product(ProductCode.FromString(product.Item3), ProgramCode.FromString(product.Item4), product.Item1, product.Item5, product.Item6,
                product.Rest.Item2);
        }

        private List<ProductTypeInfo> GetAllProductTypes()
        {
            List<ProductTypeInfo> pti = new List<ProductTypeInfo>();

            using (var reader = _dataAccess.ExecuteReader("GetAllProductType", _dataAccess.CreateConnection(), null))
            {
                while (reader.Read())
                {
                    ProductTypeInfo pt = new ProductTypeInfo();

                    if (reader["ProductTypeKey"] == DBNull.Value || reader["ProductType"] == DBNull.Value)
                    {
                        continue;
                    }
                    pt.ProductKey = GetInt32(reader, "ProductKey");
                    pt.ProductTypeKey = GetInt16(reader, "ProductTypeKey");
                    pt.ProductType = GetString(reader, "ProductType");

                    pti.Add(pt);
                }
            }

            return pti;
        }

        public List<ProductInfoModel> GetAllCachedProducts()
        {
            var key = $"{nameof(GetAllCachedProducts)}_ALL";
            return _lazyCache.Get(key, new TimeSpan(0, 1, 0, 0), () =>
            {
                var productInfos = new List<ProductInfoModel>();
                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAllProduct]",
                           _dataAccess.CreateConnection(), null))
                {
                    while (reader.Read())
                    {
                        var productInfo = new ProductInfoModel
                        {
                            ProductKey = Convert.ToInt32(reader["ProductKey"] == DBNull.Value ? 0 : reader["ProductKey"]),
                            ProductName = reader["ProductName"]?.ToString(),
                            ProductCode = reader["ProductCode"]?.ToString(),
                            ProgramCode = reader["ProgramCode"]?.ToString(),
                            ACHPrefix = reader["ACHPrefix"]?.ToString(),
                            ABARoutingNumber = reader["ABARoutingNumber"]?.ToString(),
                            Bin = reader["BIN"]?.ToString(),
                            BINProductKey = reader["BINProductKey"] == DBNull.Value ? null : Convert.ToInt32(reader["BINProductKey"]),
                            ProcessorKey = reader["ProcessorKey"] == DBNull.Value ? null : Convert.ToInt16(reader["ProcessorKey"]),
                            OverrideProcessorKey = reader["OverrideProcessorKey"] == DBNull.Value ? null : Convert.ToInt16(reader["OverrideProcessorKey"])
                        };
                        productInfos.Add(productInfo);
                    }
                }

                return productInfos;
            });
        }

        public List<ProductTierData> GetAllCachedProductTiers()
        {
            List<ProductTierData> AllProductTiers(string key) => _lazyCache.Get(key, new TimeSpan(0, 2, 0, 0), GetAllProductTiers);

            List<ProductTierData> allProductTiers = AllProductTiers($"PRODUCT_{nameof(GetAllCachedProductTiers).ToUpper()}_RH");

            return allProductTiers;
        }

        private readonly IDataAccess _dataAccess;
        private readonly ILazyCache _lazyCache;

        private static int GetInt32(IDataReader reader, string parameterName)
            => Get(reader, parameterName, reader.GetInt32);

        private static bool GetBoolean(IDataReader reader, string parameterName)
            => Get(reader, parameterName, reader.GetBoolean);

        private static short GetInt16(IDataReader reader, string parameterName)
            => Get(reader, parameterName, reader.GetInt16);

        private static string? GetString(IDataReader reader, string parameterName)
            => Get(reader, parameterName, reader.GetString);

        private static T Get<T>(IDataReader reader, string parameterName, Func<int, T> convertFn)
        {
            int ordinal = reader.GetOrdinal(parameterName);
            if (ordinal == -1 || reader.IsDBNull(ordinal))
            {
                return default(T);
            }

            return convertFn(ordinal);
        }
    }
}
