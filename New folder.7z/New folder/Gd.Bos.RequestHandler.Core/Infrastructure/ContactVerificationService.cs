﻿using System;
using Gd.Bos.RequestHandler.Core.Domain.Services.ContactVerification;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class ContactVerificationService : IContactVerificationService
    {
        public ContactVerificationService(IServiceInvokeProvider serviceInvokeProvider)
        {
            _serviceInvokeProvider = serviceInvokeProvider;
            _baseUrl = Configuration.Configuration.Current.ContactVerificationBaseUrl;
        }
        public SendCodeResponse SendCode(SendCodeRequest request)
        {
            var response = _serviceInvokeProvider.GetResponseAsync<SendCodeRequest, SendCodeResponse>(
                _baseUrl + _sendCodeUrl, "POST", request, null).Result;
            if (response == null)
                throw new Exception($"ContactVerification did not return a recognizable response for SendCode request.");

            return response;
        }
        public VerifyCodeResponse VerifyCode(VerifyCodeRequest request)
        {
            var response = _serviceInvokeProvider.GetResponseAsync<VerifyCodeRequest, VerifyCodeResponse>(
                _baseUrl + _verifyCodeUrl, "POST", request, null).Result;
            if (response == null)
                throw new Exception($"ContactVerification did not return a recognizable response for VerifyCode request.");

            return response;
        }

        public GetVerificationStatusResponse GetVerificationStatus(GetVerificationStatusRequest request)
        {
            var response = _serviceInvokeProvider.GetResponseAsync<GetVerificationStatusRequest, GetVerificationStatusResponse>(
                _baseUrl + _getStatusUrl, "POST", request, null).Result;
            if (response == null)
                throw new Exception($"ContactVerification did not return a recognizable response for GetVerificationStatus request.");

            return response;
        }

        public GetVerificationStatusResponse GetVerificationStatusByRetailCardId(GetVerificationStatusByRetailCardIdentifierRequest request)
        {
            var response = _serviceInvokeProvider.GetResponseAsync<GetVerificationStatusByRetailCardIdentifierRequest, GetVerificationStatusResponse>(
                    _baseUrl + _getStatusByRetailCardIdUrl, "POST", request, null).Result;
            if (response == null)
                throw new Exception($"ContactVerification did not return a recognizable response for GetVerificationStatus request.");

            return response;
        }

        public Shared.Common.ContactVerification.Contract.Message.Response.UnlockContactVerificationResponse UnlockContactVerification(Shared.Common.ContactVerification.Contract.Message.Request.UnlockContactVerificationRequest request)
        {
            var response = _serviceInvokeProvider.GetResponseAsync<Shared.Common.ContactVerification.Contract.Message.Request.UnlockContactVerificationRequest, Shared.Common.ContactVerification.Contract.Message.Response.UnlockContactVerificationResponse>(
                    _baseUrl + _unlockContactVerification, "POST", request, null).Result;
            if (response == null)
                throw new Exception($"ContactVerification did not return a recognizable response for unlockContactVerification request.");

            return response;
        }

        private readonly IServiceInvokeProvider _serviceInvokeProvider;
        private readonly string _baseUrl;
        private const string _sendCodeUrl = "/SendCode";
        private const string _verifyCodeUrl = "/VerifyCode";
        private const string _getStatusUrl = "/Status";
        private const string _getStatusByRetailCardIdUrl = "/StatusByRetailCardIdentifier";
        private const string _unlockContactVerification = "/unlockContactVerification";
    }
}
