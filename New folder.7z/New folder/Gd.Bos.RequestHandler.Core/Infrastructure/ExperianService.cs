﻿using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using RequestHandler.Core.Domain.Services.Experian;
using RequestHandler.Core.Domain.Services.Experian.Contracts;
using RequestHandler.Core.Domain.Services.Experian.Exceptions;
using System;
using System.Collections.Generic;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class ExperianService : IExperianService
    {
        private readonly IRequestHandlerSettings _settings;
        private readonly IServiceInvokeProvider _serviceInvokeProvider;
        private readonly string _experianBaseUrl;
        private const string _tokentUrl = "/oauth2/token";
        private const string _createAccountUrl = "/alliance/customer";
        private const string _getPartnerLinkUrl = "/alliance/partner/link";
        private const string _offerCheckUrl = "/alliance/offercheck";

        public ExperianService(IServiceInvokeProvider serviceInvokeProvider, IRequestHandlerSettings settings)
        {
            _serviceInvokeProvider = serviceInvokeProvider;
            _experianBaseUrl = Configuration.Configuration.Current.ExperianBaseUrl;
            _settings = settings;
        }

        public TokenResponse GetClientToken()
        {
            return GetToken("client_credentials");
        }

        public TokenResponse GetPartnerLinkToken(string customerId)
        {
            return GetToken("partner_link", customerId);
        }

        private TokenResponse GetToken(string grantType, string customerId = null)
        {
            TokenResponse tokenResponse = null;

            var token = new TokenRequest
            {
                GrantType = grantType,
                ClientId = _settings.ExperianClientId,
                ClientSecret = _settings.ExperianClientSecret,
                PartnerCustomerId = customerId
            };

            if (IsHeader("X-GD-Bos-Experian-WrongClientSecret"))
                token.ClientSecret = "ThisIsAWrongClientSecret";

            GetTimeout("X-GD-Bos-Experian-TimeOut", out var requestTimeout);

            try
            {
                tokenResponse = _serviceInvokeProvider.GetWebResponse<TokenRequest, TokenResponse>(_experianBaseUrl + _tokentUrl, "POST", token, requestTimeout);

                if (tokenResponse.AccessToken == null)
                    throw new ExperianTokenException($"{tokenResponse.Error}: {tokenResponse.ErrorDescription}");
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("Authentication Required"))
                    throw new ExperianAuthorizationRequiredException();

                throw;
            }

            return tokenResponse;
        }

        public CreateCustomerResponse CreateCustomer(TokenResponse tokenResponse, CreateCustomerRequest createCustomerRequest)
        {
            try
            {
                CreateCustomerResponse createCustomerResponse;
                if (IsHeader("X-GD-Bos-Experian-BadRequest"))
                {
                    createCustomerResponse = new CreateCustomerResponse
                    {
                        Error = "e001",
                        ErrorDescription = "This is a test for bad user input"
                    };
                }
                else
                {
                    Dictionary<string, string> options = new Dictionary<string, string>();

                    options.Add("Authorization", "Bearer " + tokenResponse.AccessToken);
                    options.Add("x-version", "V1");

                    var clientSessionIdentifier = Guid.NewGuid().ToString();
                    if (IsHeader("X-GD-UI-ClientSessionIdentifier"))
                    {
                        GetValueFromHeader("X-GD-UI-ClientSessionIdentifier", ref clientSessionIdentifier);
                    }
                    options.Add("x-sessionId", clientSessionIdentifier);

                    if (IsHeader("X-GD-Bos-Experian-SSN-Flag"))
                    {
                        var ssnFlag = "ON";
                        GetValueFromHeader("X-GD-Bos-Experian-SSN-Flag", ref ssnFlag);
                        options.Add("x-ssn", ssnFlag);
                    }

                    createCustomerResponse = _serviceInvokeProvider.GetResponse<CreateCustomerRequest, CreateCustomerResponse>(
                                                                    _experianBaseUrl + _createAccountUrl, "POST",
                                                                    createCustomerRequest, options);
                }

                if (createCustomerResponse.Error != null)
                {
                    if (string.IsNullOrWhiteSpace(createCustomerResponse.ErrorDescription))
                    {
                        createCustomerResponse.ErrorDescription = ErrorDescription(createCustomerResponse.Error);
                    }

                    switch (createCustomerResponse.Error)
                    {
                        case "e001":
                            throw new ExperianBadRequestException();
                        case "e005":
                            // in this case its good and its already created user
                            createCustomerResponse.Status = createCustomerResponse.Error;

                            return createCustomerResponse;
                    }

                    throw new ExperianCreateCustomerException($"{createCustomerResponse.Error}: {createCustomerResponse.ErrorDescription}");
                }

                return createCustomerResponse;
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("Authentication Required"))
                    throw new ExperianAuthorizationRequiredException();

                throw;
            }
        }

        public GetPartnerLinkResponse GetPartnerLink(GetPartnerLinkRequest getPartnerLinkRequest)
        {
            try
            {
                var getPartnerLinkResponse = new GetPartnerLinkResponse();

                var options = new Dictionary<string, string>
                {
                    {"Authorization", "Bearer " + getPartnerLinkRequest.TokenResponse.AccessToken},
                    {"x-version", "V1"}
                };

                var clientSessionIdentifier = Guid.NewGuid().ToString();
                if (IsHeader("X-GD-UI-ClientSessionIdentifier"))
                {
                    GetValueFromHeader("X-GD-UI-ClientSessionIdentifier", ref clientSessionIdentifier);
                }
                options.Add("x-sessionId", clientSessionIdentifier);

                if (IsHeader("X-GD-Bos-BrandChange-Error"))
                {
                    string brand = string.Empty;
                    GetValueFromHeader("X-GD-Bos-BrandChange-Error", ref brand);
                    getPartnerLinkRequest.Brand = brand;
                }

                var requestUrl = _experianBaseUrl + _getPartnerLinkUrl
                                                  + "?closeX=true"
                                                  + "&newAccountAdded=" + (getPartnerLinkRequest.NewAccountAdded ? "true" : "false")
                                                  + "&features=" + getPartnerLinkRequest.FeatureName
                                                  + "&partnerLogo=" + getPartnerLinkRequest.Brand.ToLower()
                                                  + "&partnerName=" + getPartnerLinkRequest.Brand.ToLower();

                if (!string.IsNullOrWhiteSpace(getPartnerLinkRequest.AccountId))
                    requestUrl += "&accountId=" + getPartnerLinkRequest.AccountId;

                var partnerLinkResponse = _serviceInvokeProvider.GetResponse<PartnerLinkResponse>(requestUrl, "GET", null, options);

                if (!string.IsNullOrWhiteSpace(partnerLinkResponse.Error) && string.IsNullOrWhiteSpace(partnerLinkResponse.ErrorDescription))
                {
                    partnerLinkResponse.ErrorDescription = ErrorDescription(partnerLinkResponse.Error);

                    switch (partnerLinkResponse.Error)
                    {
                        case "e001":
                            throw new ExperianBadRequestException();
                        case "e007":
                            // in this case its good and its already created user
                            getPartnerLinkResponse.Status = partnerLinkResponse.Error;

                            return getPartnerLinkResponse;
                    }
                    getPartnerLinkResponse.ErrorDescription = ErrorDescription(partnerLinkResponse.Error);

                    throw new ExperianGetPartnerLinkException($"{partnerLinkResponse.Error}: {partnerLinkResponse.ErrorDescription}");
                }

                if (string.IsNullOrWhiteSpace(partnerLinkResponse.RedirectURL))
                    throw new Exception("Empty redirectUrl response received from Experian.");

                getPartnerLinkResponse.RedirectUrl = partnerLinkResponse?.RedirectURL;

                return getPartnerLinkResponse;
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("Authentication Required"))
                    throw new ExperianAuthorizationRequiredException();

                throw;
            }
        }

        public OfferEligibleCheckResponse GetOfferCheck(TokenResponse tokenResponse, OfferEligibleCheckRequest offerEligibleCheckRequest)
        {
            try
            {
                if (IsHeader("X-GD-Bos-Experian-BadRequest"))
                {
                    return new OfferEligibleCheckResponse()
                    {
                        Error = "e001",
                        ErrorDescription = "This is a test for bad user input"
                    };
                }

                var options = new Dictionary<string, string>
                {
                    {"Authorization", "Bearer " + tokenResponse.AccessToken},
                    {"x-version", "V1"}
                };

                offerEligibleCheckRequest.OfferTag = _settings.ExperianOfferTag;

                var eligibleCheckResponse = _serviceInvokeProvider.GetResponse<OfferEligibleCheckRequest, OfferEligibleCheckResponse>(
                                                                    _experianBaseUrl + _offerCheckUrl, "POST",
                                                                    offerEligibleCheckRequest, options);

                if (eligibleCheckResponse.Error != null)
                {
                    if (string.IsNullOrWhiteSpace(eligibleCheckResponse.ErrorDescription))
                    {
                        eligibleCheckResponse.ErrorDescription = ErrorDescription(eligibleCheckResponse.Error);
                    }

                    throw new ExperianCreateCustomerException($"{eligibleCheckResponse.Error}: {eligibleCheckResponse.ErrorDescription}");
                }

                return eligibleCheckResponse;
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("Authentication Required"))
                    throw new ExperianAuthorizationRequiredException();

                throw;
            }
        }

        private static string ErrorDescription(string errorCode)
        {
            string errorDescription = string.Empty;
            switch (errorCode)
            {
                case "e00":
                    errorDescription = "too many requests";
                    break;
                case "e001":
                case "e010":
                    errorDescription = "bad request";
                    break;
                case "e003":
                    errorDescription = "validation failed";
                    break;
                case "e004":
                    errorDescription = "incorrect oauth2 token used";
                    break;
                case "e005":
                    errorDescription = "customer not allowed";
                    break;
                case "e006":
                    errorDescription = "too many request";
                    break;
                case "e007":
                    errorDescription = "no longer D2C member";
                    break;
                case "e500":
                    errorDescription = "internal error";
                    break;
                case "e011":
                    errorDescription = "invalid tag";
                    break;
                case "e012":
                    errorDescription = "invalid token";
                    break;
                case "e013":
                    errorDescription = "call not allowed";
                    break;
            }

            return errorDescription;
        }

        private static bool IsHeader(string headerName)
        {
            return OptionsContext.Current.IsDefined(headerName);
        }

        private static void GetTimeout(string headerName, out int? requestTimeout)
        {
            requestTimeout = null;
            if (!OptionsContext.Current.IsDefined(headerName))
                return;

            if (int.TryParse(OptionsContext.Current.GetString(headerName), out var rt))
                requestTimeout = rt;
            else
                requestTimeout = null;

            // 0 throws ArgumentOutOfRangeException in web client
            if (requestTimeout == 0)
                requestTimeout = 1;
        }

        private static void GetValueFromHeader(string headerName, ref string headerValue)
        {
            if (OptionsContext.Current.IsDefined(headerName))
            {
                headerValue = OptionsContext.Current.GetString(headerName).Trim().ToUpper();
            }
        }
    }
}
