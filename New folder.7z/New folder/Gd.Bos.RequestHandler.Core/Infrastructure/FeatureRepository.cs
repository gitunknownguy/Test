﻿using NLog;
using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Model.Feature;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Utils;
using Gd.Bos.Shared.Common.Core.Logic;
using Gd.Bos.Shared.Common.Caching;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Contract.Exceptions;
using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.Shared.Common.Logic.FeatureLimitsFees.Contract.Enum;
using RequestHandler.Core.Domain.Model.Program;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class FeatureRepository : IFeatureRepository
    {
        private IDataAccess _dataAccess;
        private ILazyCache _lazyCache;
        public FeatureRepository(IDataAccess dataAccess, ILazyCache lazyCache)
        {
            _dataAccess = dataAccess;
            _lazyCache = lazyCache;
        }

        public void UpdateFeature(long accountSubscriptionKey)
        {
            var actionName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            var userName = IdentityHelper.GetIdentityName();
            var parameters = new[]
            {
                new SqlParameter() { ParameterName = "AccountSubscriptionKey", SqlDbType = SqlDbType.BigInt, Value = accountSubscriptionKey },
                new SqlParameter() { ParameterName = "ChangeBy", SqlDbType = SqlDbType.NVarChar, Value =  userName},
                new SqlParameter() { ParameterName = "SubscriptionEndDate", SqlDbType = SqlDbType.DateTime, Value = DateTime.Now }

            };

            using (var connection = _dataAccess.CreateConnection())
            {
                _dataAccess.ExecuteNonQuery("[dbo].[UpdAccountSubscription]", connection, parameters);
            }
        }

        public ProductFeatureGroup GetProductFeatureGroupKeyInfoByFeature(int featureKey, int productKey)
        {
            Func<string, List<ProductFeatureGroup>> getAllVIPProductFeatureGroup = key =>
                _lazyCache.Get(key, new TimeSpan(0, 2, 0, 0), () => GetAllVIPProductFeatureGroup());
            var products = getAllVIPProductFeatureGroup("VIPFEATUREREPOSITORY_FEATURE_FEATUREKEY");
            var product = products.Find(p => p.FeatureKey == featureKey && p.ProductKey == productKey);
            if (product == null)
                throw new BaseException(55, 5, $"Features terms were not accepted or no ProductFeatureGroupKey exists for specified featureKey {featureKey}.");
            return product;
        }

        public List<ProductFeature> GetAllFeatures()
        {
            Func<string, List<ProductFeature>> getAllProductFeatures = key =>
                _lazyCache.Get(key, new TimeSpan(0, 2, 0, 0), () => GetAllFeatureInfo());
            var products = getAllProductFeatures("PRODUCT FEATURE");
            if (products == null)
                throw new BaseException(55, 5, $"Features are empty");
            return products;
        }

        private List<ProductFeature> GetAllFeatureInfo()
        {
            var returnValue = new List<ProductFeature>(100);

            using (var reader = _dataAccess.ExecuteReader("[dbo].GetAllFeature", _dataAccess.CreateConnection()))
            {
                while (reader.Read())
                {
                    var featureInfo = new ProductFeature
                    {
                        FeatureType = reader["Feature"].Cast<string>(),
                        FeatureTypeKey = reader["FeatureKey"].Cast<short>(),
                        IsAccountSubscription = reader["IsAccountSubscription"].Cast<bool>(),
                        Category = reader["Category"].Cast<string>(),
                    };
                    returnValue.Add(featureInfo);
                }
            }

            return returnValue;
        }

        private List<ProductFeatureGroup> GetAllVIPProductFeatureGroup()
        {
            var returnValue = new List<ProductFeatureGroup>();

            using (var reader = _dataAccess.ExecuteReader("[dbo].GetAllVipProductFeatureGroup", _dataAccess.CreateConnection()))
            {
                while (reader.Read())
                {
                    var featureInfo = new ProductFeatureGroup();
                    featureInfo.ProductKey = reader["ProductKey"].Cast<int>();
                    featureInfo.FeatureGroupKey = reader["FeatureGroupKey"].Cast<short>();
                    featureInfo.Feature = reader["Feature"].Cast<string>();
                    featureInfo.FeatureKey = reader["FeatureKey"].Cast<short>();
                    featureInfo.ProductFeatureGroupKey = reader["ProductFeatureGroupKey"].Cast<int>();
                    featureInfo.ProductFeatureGroupDefinitionKey = reader["ProductFeatureGroupDefinitionKey"].Cast<int>();
                    featureInfo.Category = reader["Category"].Cast<string>();
                    returnValue.Add(featureInfo);
                }
            }

            return returnValue;
        }



        public List<AccountSubProductFeatureGroup> GetFeatureInfoByAccountIdentifier(Guid accountIdentifier)
        {
            List<AccountSubscription> subscriptions = new List<AccountSubscription>();
            List<AccountSubProductFeatureGroup> currentSub = new List<AccountSubProductFeatureGroup>();
            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountSubscriptionByAccountIdentifier]",
                _dataAccess.CreateConnection(), new SqlParameter
                {
                    ParameterName = "AccountIdentifier",
                    Value = accountIdentifier.ToString()
                }))
            {
                while (reader.Read())
                {
                    var subscription = new AccountSubscription();
                    subscription.AccountSubscriptionKey = reader["AccountSubscriptionKey"] == DBNull.Value ? -1 : long.Parse(reader["AccountSubscriptionKey"].ToString());
                    subscription.AccountKey = reader["AccountKey"] == DBNull.Value ? -1 : long.Parse(reader["AccountKey"].ToString());
                    subscription.ProductFeatureGroupKey = reader["ProductFeatureGroupKey"] == DBNull.Value ? -1 : int.Parse(reader["ProductFeatureGroupKey"].ToString());
                    subscription.SubscriptionStartDateTime = reader["SubscriptionStartDateTime"] == DBNull.Value ? DateTime.MinValue : DateTime.Parse(reader["SubscriptionStartDateTime"].ToString());
                    subscription.SubscriptionEndDate = reader["SubscriptionEndDate"] == DBNull.Value ? DateTime.MinValue : DateTime.Parse(reader["SubscriptionEndDate"].ToString());
                    subscription.EnrollmentDate = reader["EnrollmentDate"] == DBNull.Value ? DateTime.MinValue : DateTime.Parse(reader["EnrollmentDate"].ToString());

                    subscriptions.Add(subscription);
                }
            }

            if (subscriptions.Count > 0)
            {
                var currentSubscription = subscriptions.FindAll(s => s.SubscriptionEndDate > DateTime.Now);
                currentSubscription.ForEach((t) =>
                {
                    currentSub.Add(new AccountSubProductFeatureGroup()
                    {
                        AccountSubscriptionKey = t.AccountSubscriptionKey,
                        ProductFeatureGroupKey = t.ProductFeatureGroupKey

                    });
                });
            }

            return currentSub;
        }

        public List<AccountSubProductFeatureGroup> GetFeatureInfoByAccountIdentifierForShowcase(Guid accountIdentifier)
        {
            List<AccountSubscription> subscriptions = new List<AccountSubscription>();
            List<AccountSubProductFeatureGroup> currentSub = new List<AccountSubProductFeatureGroup>();
            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountSubscriptionByAccountIdentifier]",
                       _dataAccess.CreateConnection(), new SqlParameter
                       {
                           ParameterName = "AccountIdentifier",
                           Value = accountIdentifier.ToString()
                       }))
            {
                while (reader.Read())
                {
                    var subscription = new AccountSubscription();
                    subscription.AccountSubscriptionKey = reader["AccountSubscriptionKey"] == DBNull.Value ? -1 : long.Parse(reader["AccountSubscriptionKey"].ToString());
                    subscription.AccountKey = reader["AccountKey"] == DBNull.Value ? -1 : long.Parse(reader["AccountKey"].ToString());
                    subscription.ProductFeatureGroupKey = reader["ProductFeatureGroupKey"] == DBNull.Value ? -1 : int.Parse(reader["ProductFeatureGroupKey"].ToString());
                    subscription.SubscriptionStartDateTime = reader["SubscriptionStartDateTime"] == DBNull.Value ? DateTime.MinValue : DateTime.Parse(reader["SubscriptionStartDateTime"].ToString());
                    subscription.SubscriptionEndDate = reader["SubscriptionEndDate"] == DBNull.Value ? DateTime.MinValue : DateTime.Parse(reader["SubscriptionEndDate"].ToString());
                    subscription.EnrollmentDate = reader["EnrollmentDate"] == DBNull.Value ? DateTime.MinValue : DateTime.Parse(reader["EnrollmentDate"].ToString());
                    subscription.SubscriptionCreateDate = reader["CreateDate"] == DBNull.Value ? DateTime.MinValue : DateTime.Parse(reader["CreateDate"].ToString());

                    subscriptions.Add(subscription);
                }
            }

            if (subscriptions.Count <= 0)
            {
                return currentSub;
            }

            {
                var orderedSubscriptions = subscriptions.OrderByDescending(s => s.SubscriptionCreateDate);
                currentSub.AddRange(orderedSubscriptions.Select(subscription => new AccountSubProductFeatureGroup() { AccountSubscriptionKey = subscription.AccountSubscriptionKey, ProductFeatureGroupKey = subscription.ProductFeatureGroupKey }));
            }

            return currentSub;
        }

        public ProductFeatureGroup GetProductFeatureGroupKeyByProductFeatureGroup(int productFeatureGroupKey)
        {
            Func<string, List<ProductFeatureGroup>> getAllVIPProductFeatureGroup = key =>
                _lazyCache.GetAsync2(key, new TimeSpan(0, 2, 0, 0), () => Task.Run(() => GetAllVIPProductFeatureGroup())).Result;
            var products = getAllVIPProductFeatureGroup("VIPFEATUREREPOSITORY_FEATURE_FEATUREKEY");
            var product = products.Find(p => p.ProductFeatureGroupKey == productFeatureGroupKey);
            if (product == null)
                throw new Exception($"No ProductFeatureGroupKey exists for specified productFeatureGroupKey {productFeatureGroupKey}.");
            return product;
        }
        public List<ProductFeatureGroup> GetVipProductFeatureGroupsByProduct(int productKey)
        {
            Func<string, List<ProductFeatureGroup>> getAllVIPProductFeatureGroup = key =>
                _lazyCache.GetAsync2(key, new TimeSpan(0, 2, 0, 0), () => Task.Run(() => GetAllVIPProductFeatureGroup())).Result;
            var allVipProductFeatureGroups = getAllVIPProductFeatureGroup("VIPFEATUREREPOSITORY_FEATURE_FEATUREKEY");
            var productFeatureGroups = allVipProductFeatureGroups.Where(p => p.ProductKey == productKey);
            return productFeatureGroups.ToList();
        }
    }
}
