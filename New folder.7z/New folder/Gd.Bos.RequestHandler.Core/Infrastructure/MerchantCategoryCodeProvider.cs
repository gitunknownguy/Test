﻿using System;
using Gd.Bos.Shared.Common.Messaging.Model;
using RequestHandler.Core.Domain.Model.MerchantCategoryCode;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

namespace RequestHandler.Core.Infrastructure
{
    public class MerchantCategoryCodeProvider : IMerchantCategoryCodeProvider
    {
        private readonly IMerchantCategoryCodeRepository _merchantCategoryCodeRepository;
        private static readonly List<MerchantCategoryCode> _merchantCategoryCodes = new List<MerchantCategoryCode>();

        public MerchantCategoryCodeProvider(IMerchantCategoryCodeRepository merchantCategoryCodeRepository)
        {
            _merchantCategoryCodeRepository = merchantCategoryCodeRepository;
        }

        public MerchantCategoryCode GetMerchantCategoryCode(string merchantCode)
        {
            return GetAll().FirstOrDefault(m => m.MerchantCode == merchantCode) ?? new MerchantCategoryCode
            {
                MccDescription = null,
                MerchantCategory = null,
                MerchantCode = merchantCode
            };
        }

        private List<MerchantCategoryCode> GetAll()
        {
            lock (_merchantCategoryCodes)
            {
                if (_merchantCategoryCodes.Any())
                {
                    return _merchantCategoryCodes;
                }

                var mccCategoryCodes = _merchantCategoryCodeRepository.GetAllMerchantCategoryCodes();
                _merchantCategoryCodes.AddRange(mccCategoryCodes);
                return _merchantCategoryCodes;
            }
        }

        public void ResetCache()
        {
            _merchantCategoryCodes.Clear();
        }
    }
}
