﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Caching;
using Gd.Bos.Shared.Common.Caching.Contract;
using RequestHandler.Core.Domain.Services.TokenManagementService;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using NLog;
using RequestHandler.Core.Domain.Services.AzureServiceBus;
using RequestHandler.Core.Domain.Services.TokenManagementService.EventMessage;
using System.Linq;

namespace RequestHandler.Core.Infrastructure;

public class TokenManagementService(
    IRequestHandlerSettings settings,
    ILazyCache lazyCache,
    IServiceInvokeProvider serviceInvokeProvider,
    IServiceBusNotificationPublisher serviceBusNotificationPublisher)
    : ITokenManagementService
{
    private const string ProgramCodesUrl = "/program";
    private const string QueueName = "q.tokenmanagementservicehandler";
    private static readonly Logger Logger = LogManager.GetCurrentClassLogger();


    public async Task PublishUserProfileUpdatedMessageAsync(Guid requestId, string programCode,
        UserProfileUpdatedMessage message)
    {
        try
        {
            var programs = GetProgramsCache(requestId);
            if (programs == null || !programs.Any(x =>
                    string.Equals(x.ProgramCode, programCode, StringComparison.InvariantCultureIgnoreCase)))
                return;

            await serviceBusNotificationPublisher.PublishAsync(QueueName, requestId.ToString(),
                nameof(UserProfileUpdatedMessage), message);
        }
        catch (Exception e)
        {
            Logger.Error(e, "Could not publish 'UserProfileUpdatedMessage'");
        }
    }

    public async Task PublishCardReplacedMessageAsync(Guid requestId, string programCode,
        CardReplacedMessage message)
    {
        try
        {
            var programs = GetProgramsCache(requestId);
            if (programs == null || !programs.Any(x =>
                    string.Equals(x.ProgramCode, programCode, StringComparison.InvariantCultureIgnoreCase)))
                return;

            await serviceBusNotificationPublisher.PublishAsync(QueueName, requestId.ToString(),
                nameof(CardReplacedMessage), message);
        }
        catch (Exception e)
        {
            Logger.Error(e, "Could not publish 'CardReplacedMessage'");
        }
    }

    public async Task PublishP2PTransferCompletedMessageAsync(Guid requestId, string programCode,
        P2PTransferCompletedMessage message)
    {
        try
        {
            var programs = GetProgramsCache(requestId);
            if (programs == null || !programs.Any(x =>
                    string.Equals(x.ProgramCode, programCode, StringComparison.InvariantCultureIgnoreCase)))
                return;

            await serviceBusNotificationPublisher.PublishAsync(QueueName, requestId.ToString(),
                nameof(P2PTransferCompletedMessage), message);
        }
        catch (Exception e)
        {
            Logger.Error(e, "Could not publish 'P2PTransferCompletedMessage'");
        }
    }

    private List<ProgramDTO> GetProgramsCache(Guid requestId)
    {
        var getAllPrograms = lazyCache.Get("programcodes_tokenmanagementservice", new TimeSpan(0, 2, 0, 0),
            GetPrograms);
        return getAllPrograms;

        List<ProgramDTO> GetPrograms()
        {
            List<ProgramDTO> programs = [];
            try
            {
                var request = new GetProgramsRequest
                {
                    RequestHeader = new TokenManagementRequestHeader { RequestId = requestId }
                };

                Logger.Debug($"P2P program code from token management service handler: Requeste ID: {requestId.ToString()} - URL: {settings.TokenManagementService}");
                var responseMessage = serviceInvokeProvider.GetResponseAsync<GetProgramsRequest, GetProgramsResponse>(
                    settings.TokenManagementService + ProgramCodesUrl, "POST", request, null).GetAwaiter().GetResult();

                if (responseMessage == null)
                {
                    Logger.Error("CBS-TokenManagementService service did not return a successful response");
                    return programs;
                }

                if (responseMessage?.ResponseHeader.StatusCode == "0")
                {
                    return responseMessage.Programs;
                }

                Logger.Error("CBS-TokenManagementService service did not return success: {Message}",
                    responseMessage.ResponseHeader.Message);
                return programs;
            }
            catch (Exception ex)
            {
                Logger.Error(ex, "Could not retrieve programs from CBS-TokenManagementService");
                return programs;
            }
        }
    }
}
