﻿using Gd.Bos.Shared.Common.Core.Data;
using NLog;
using System;
using System.Diagnostics.CodeAnalysis;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Utils;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Application.Exception;
using System.Text;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class ExternalPaymentRepository : IExternalPaymentRepository
    {

        private readonly IDataAccess _dataAccess;
        private string username = IdentityHelper.GetIdentityName();
        private static readonly Logger _logger = LogManager.GetCurrentClassLogger();
        public ExternalPaymentRepository(IDataAccess dataAccess)
        {
            _dataAccess = dataAccess;
        }

        public int DeleteExternalCard(string accountIdentifier, string externalCardIdentifier)
        {
            SqlParameter[] queryParams = new[]
            {
            new SqlParameter() { ParameterName = "AccountExternalPaymentIdentifier", Value = Guid.Parse(externalCardIdentifier) },
            new SqlParameter() { ParameterName = "ChangeBy", Value = username },
            new SqlParameter() { ParameterName = "ExternalPaymentIdentifierStatusKey", Value = ExternalPaymentStatus.InActive },
            new SqlParameter() { ParameterName = "EncryptedPAN", Value = "0" },
            new SqlParameter() { ParameterName = "EncryptedExpirationDate", Value = "0" },
            new SqlParameter() { ParameterName = "Last4PAN", Value = 0},
            new SqlParameter() { ParameterName = "PurgeDate", Value = DateTime.Now }
            };

            int rowsAffected = _dataAccess.ExecuteNonQuery("[dbo].[UpdAccountExternalPaymentIdentifierStatus]", _dataAccess.CreateConnectionWithColumnEncryption(), queryParams);
            return rowsAffected;
        }
        public List<ExternalPayment> GetAll(string accountIdentifier)
        {
            SqlParameter[] queryParams = new[]
            {
                new SqlParameter() { ParameterName = "AccountIdentifier", Value = Guid.Parse(accountIdentifier) },
            };
            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountExternalPaymentIdentifierByAccountIdentifier]", _dataAccess.CreateConnectionWithColumnEncryption(), queryParams))
            {
                List<ExternalPayment> response = new List<ExternalPayment>();
                while (reader.Read())
                {
                    if (reader["ExternalPaymentIdentifierStatusKey"].Equals(Convert.ToInt16(ExternalPaymentStatus.InActive)))
                        continue;

                    var card = new ExternalPayment
                    {
                        AccountExternalPaymentIdentifier = Guid.Parse(reader["AccountExternalPaymentIdentifier"].ToString()),
                        Network = reader["AssociationName"].ToString(),
                        BankName = reader["BankName"].ToString(),
                        FirstName = reader["FirstName"].ToString(),
                        LastName = reader["LastName"].ToString(),
                        Address = reader["Address"].ToString(),
                        City = reader["City"].ToString(),
                        State = reader["State"].ToString(),
                        Country = reader["Country"].ToString(),
                        ZipCode = reader["ZipCode"].ToString(),
                        IsFundingEligible = Convert.ToBoolean(reader["IsFundingEligible"]),
                        IsWithdrawlEligible = Convert.ToBoolean(reader["IsWithdrawlEligible"]),
                        Last4PAN = reader["Last4PAN"].ToString(),
                        EncryptedPAN = reader["EncryptedPAN"].ToString(),
                        NickName = reader["NickName"] == DBNull.Value ? "" : reader["NickName"].ToString(),
                        BIN = reader["BIN"] == DBNull.Value ? null : reader["BIN"].ToString().Trim(),
                        ProductTierKey = reader["ProductTierKey"] == DBNull.Value ? 0 : Convert.ToInt32(reader["ProductTierKey"]),
                        AccountExternalPaymentIdentifierKey = Convert.ToInt64(reader["AccountExternalPaymentIdentifierKey"])
                    };

                    if (reader["EncryptedExpirationDate"] != DBNull.Value && reader["EncryptedExpirationDate"].ToString().Length > 3)
                        card.ExpirationDate = new CardExpirationDate()
                        {
                            CardExpirationMonth = reader["EncryptedExpirationDate"].ToString().Substring(0, 2),
                            CardExpirationyear = reader["EncryptedExpirationDate"].ToString().Substring(2)
                        };

                    response.Add(card);
                }

                return response;
            }
        }

        public List<ExternalPayment> GetAllEncryptedOnly(string accountIdentifier)
        {
            SqlParameter[] queryParams = new[]
            {
                new SqlParameter() { ParameterName = "AccountIdentifier", Value = Guid.Parse(accountIdentifier) },
            };
            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountExternalPaymentIdentifierByAccountIdentifier]", _dataAccess.CreateConnectionWithColumnEncryption(), queryParams))
            {
                List<ExternalPayment> response = new List<ExternalPayment>();
                while (reader.Read())
                {
                    if (reader["PurgeDate"] != DBNull.Value) continue;

                    var card = new ExternalPayment
                    {
                        EncryptedPAN = reader["EncryptedPAN"].ToString(),
                        ExpirationDate = new CardExpirationDate()
                        {
                            CardExpirationMonth = reader["EncryptedExpirationDate"].ToString().Substring(0, 2),
                            CardExpirationyear = reader["EncryptedExpirationDate"].ToString().Substring(2)
                        },
                        AccountExternalPaymentIdentifier = Guid.Parse(reader["AccountExternalPaymentIdentifier"].ToString())
                    };

                    response.Add(card);
                }

                return response;
            }
        }


        public long GetAccountKeyByIdentifier(string accountIdentifier)
        {

            long accountKey = 0;
            SqlParameter[] queryParams = new[]
            {
                new SqlParameter() { ParameterName = "AccountIdentifier", Value = accountIdentifier }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountByAccountIdentifier]", _dataAccess.CreateConnection(), queryParams))
            {
                if (reader.Read())
                {
                    accountKey = Convert.ToInt64(reader["AccountKey"]);
                }
                return accountKey;
            }
        }

        public void Add(ExternalPayment externalPayment)
        {
            try
            {
                SqlParameter[] externalPaymentSqlParams = new[]
                {
                    new SqlParameter() { ParameterName = "ChangeBy", Value = externalPayment.ChangeBy },
                    new SqlParameter() { ParameterName = "AccountKey", Value = externalPayment.AccountKey },
                    new SqlParameter() { ParameterName = "AccountExternalPaymentIdentifier", Value = externalPayment.AccountExternalPaymentIdentifier },
                    new SqlParameter() { ParameterName = "EncryptedPAN", Value = externalPayment.EncryptedPAN },
                    new SqlParameter() { ParameterName = "EncryptedExpirationDate", Value = externalPayment.ExpirationDate.ToExprDateString() },
                    new SqlParameter() { ParameterName = "BIN", Value = externalPayment.BIN },
                    new SqlParameter() { ParameterName = "AssociationKey", Value = externalPayment.AssociationKey },
                    new SqlParameter() { ParameterName = "ExternalPaymentIdentifierStatusKey", Value = 1 },
                    new SqlParameter() { ParameterName = "BankName", Value = externalPayment.BankName },
                    new SqlParameter() { ParameterName = "NickName", Value = externalPayment.NickName },
                    new SqlParameter() { ParameterName = "FirstName", Value = externalPayment.FirstName },
                    new SqlParameter() { ParameterName = "Lastname", Value = externalPayment.LastName },
                    new SqlParameter() { ParameterName = "Address", Value = externalPayment.Address },
                    new SqlParameter() { ParameterName = "City", Value = externalPayment.City },
                    new SqlParameter() { ParameterName = "State", Value = externalPayment.State },
                    new SqlParameter() { ParameterName = "ZipCode", Value = externalPayment.ZipCode },
                    new SqlParameter() { ParameterName = "IsFundingEligible", Value = externalPayment.IsFundingEligible },
                    new SqlParameter() { ParameterName = "IsWithdrawlEligible", Value = externalPayment.IsWithdrawlEligible },
                    new SqlParameter() { ParameterName = "Last4PAN", Value = externalPayment.Last4PAN },
                    new SqlParameter() { ParameterName = "Country", Value = externalPayment.Country },
                    new SqlParameter() { ParameterName = "IsVerified", Value = externalPayment.IsVerified },
                };

                using (var reader = _dataAccess.ExecuteReader("[dbo].[InsAccountExternalPaymentIdentifier]", _dataAccess.CreateConnectionWithColumnEncryption(), externalPaymentSqlParams))
                {
                    return;
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, @"ExternalPaymentRepository.Add, error occurred when adding externalpayment : " + ex.Message);
                throw;
            }

        }
    }
}
