﻿using System;
using System.Diagnostics.CodeAnalysis;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Services.Crypto;
using Gd.Bos.RequestHandler.Core.Domain.Services.Dcpp;
using NLog;
using Org.BouncyCastle.Asn1.Ocsp;
using CardExpirationDate = Gd.Bos.RequestHandler.Core.Domain.Services.Dcpp.CardExpirationDate;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class CryptoService : ICryptoService
    {
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        public CryptoService(IServiceInvokeProvider serviceInvokeProvider, IDcppService dcppService)
        {
            _serviceInvokerProvider = serviceInvokeProvider;
            _dcppService = dcppService;
            _cryptoUrl = Configuration.Configuration.Current.CryptoUrl;
            _useHsmCvvGeneration = Configuration.Configuration.Current.UseHsmCvvGeneration;
        }

        private readonly string _cryptoUrl;
        private readonly IServiceInvokeProvider _serviceInvokerProvider;
        private readonly bool _useHsmCvvGeneration;
        private readonly IDcppService _dcppService;
        private const string GenerateCvvServiceUrl = "/generateCvv";
        private const string EncryptServiceUrl = "/encrypt";
        private const string DecryptServiceUrl = "/decrypt";
        private const string CbcEncryptServiceUrl = "/cbcEncrypt";
        private const string JwtEncryptServiceUrl = "/jwtEncrypt";
        private const string RsaOaepEncryptServiceUrl = "/rsaOaepEncrypt";
        private const string RsaGenerateSignatureServiceUrl = "/rsaGenerateSignature";
        public GenerateCvvResponse GenerateCvv(AccountIdentifier accountId, string pan, string expiration, PaymentInstrumentType paymentInstrumentType, Guid? paymentIdentifier = null, Guid? paymentInstrumentIdentifier = null)
        {
            var result = default(GenerateCvvResponse);

            if (_useHsmCvvGeneration && !_dcppService.IsRoutingToCPM(accountId))
            {
                // Try getting cvv using HSM first
                // and if it fails then fallback to retrieving from Dcpp.
                try
                {
                    var hsmResult = GenerateCvvResponseFromHsm(pan, expiration, paymentInstrumentType);
                    result = new GenerateCvvResponse
                    {
                        Cvv = hsmResult.Cvv
                    };
                }
                catch (Exception ex)
                {
                    result = null;
                    _logger.Warn(ex, "Failed to obtain cvv using HSM.  Falling back to Dcpp.");
                }
            }

            result = result ?? ObtainCvvFromDcpp(accountId, expiration, paymentIdentifier, paymentInstrumentIdentifier);

            return result;
        }

        public CbcEncryptResponse CbcEncrypt(CbcEncryptRequest request)
        {
            GetTimeout("X-GD-Bos-Crypto-CbcEncryptTimeout", out var requestTimeout);

            var cryptoResponse = _serviceInvokerProvider.GetWebResponse<CbcEncryptRequest, CbcEncryptResponse>(_cryptoUrl + CbcEncryptServiceUrl, "POST", request, requestTimeout);
            if (cryptoResponse == null)
                throw new Exception($"Crypto service did not return a successful response.");

            if (cryptoResponse.ResponseHeader.StatusCode != 200)
                throw new Exception($"Crypto service did not return success: StatusCode: {cryptoResponse.ResponseHeader.StatusCode}; StatusMessage: {cryptoResponse.ResponseHeader.StatusMessage}");

            return cryptoResponse;
        }

        public JwtEncryptResponse JwtEncrypt(JwtEncryptRequest request)
        {
            GetTimeout("X-GD-Bos-Crypto-JwtEncryptTimeout", out var requestTimeout);

            var cryptoResponse = _serviceInvokerProvider.GetWebResponse<JwtEncryptRequest, JwtEncryptResponse>(_cryptoUrl + JwtEncryptServiceUrl, "POST", request, requestTimeout);
            if (cryptoResponse == null)
                throw new Exception($"Crypto service did not return a successful response.");

            if (cryptoResponse.ResponseHeader.StatusCode != 200)
                throw new Exception($"Crypto service did not return success: StatusCode: {cryptoResponse.ResponseHeader.StatusCode}; StatusMessage: {cryptoResponse.ResponseHeader.StatusMessage}");

            return cryptoResponse;
        }

        public RsaOaepEncryptResponse RsaOaepEncrypt(RsaOaepEncryptRequest request)
        {
            GetTimeout("X-GD-Bos-Crypto-RsaOaepEncryptTimeout", out var requestTimeout);

            var cryptoResponse = _serviceInvokerProvider.GetWebResponse<RsaOaepEncryptRequest, RsaOaepEncryptResponse>(_cryptoUrl + RsaOaepEncryptServiceUrl, "POST", request, requestTimeout);
            if (cryptoResponse == null)
                throw new Exception($"Crypto service did not return a successful response.");

            if (cryptoResponse.ResponseHeader.StatusCode != 200)
                throw new Exception($"Crypto service did not return success: StatusCode: {cryptoResponse.ResponseHeader.StatusCode}; StatusMessage: {cryptoResponse.ResponseHeader.StatusMessage}");

            return cryptoResponse;
        }

        public RsaGenerateSignatureResponse RsaGenerateSignature(RsaGenerateSignatureRequest request)
        {
            GetTimeout("X-GD-Bos-Crypto-RsaGenerateSignatureTimeout", out var requestTimeout);

            var cryptoResponse = _serviceInvokerProvider.GetWebResponse<RsaGenerateSignatureRequest, RsaGenerateSignatureResponse>(_cryptoUrl + RsaGenerateSignatureServiceUrl, "POST", request, requestTimeout);
            if (cryptoResponse == null)
                throw new Exception($"Crypto service did not return a successful response.");

            if (cryptoResponse.ResponseHeader.StatusCode != 200)
                throw new Exception($"Crypto service did not return success: StatusCode: {cryptoResponse.ResponseHeader.StatusCode}; StatusMessage: {cryptoResponse.ResponseHeader.StatusMessage}");

            return cryptoResponse;
        }

        public EncryptResponse Encrypt(EncryptRequest request)
        {
            GetTimeout("X-GD-Bos-Crypto-EncryptTimeout", out var requestTimeout);

            var cryptoResponse = _serviceInvokerProvider.GetWebResponse<EncryptRequest, EncryptResponse>(_cryptoUrl + EncryptServiceUrl, "POST", request, requestTimeout);
            if (cryptoResponse == null)
                throw new Exception($"Crypto service did not return a successful response.");

            if (cryptoResponse.ResponseHeader.StatusCode != 200)
                throw new Exception($"Crypto service did not return success: StatusCode: {cryptoResponse.ResponseHeader.StatusCode}; StatusMessage: {cryptoResponse.ResponseHeader.StatusMessage}");

            return cryptoResponse;
        }

        public DecryptResponse Decrypt(DecryptRequest request)
        {
            GetTimeout("X-GD-Bos-Crypto-DecryptTimeout", out var requestTimeout);

            var cryptoResponse = _serviceInvokerProvider.GetWebResponse<DecryptRequest, DecryptResponse>(_cryptoUrl + DecryptServiceUrl, "POST", request, requestTimeout);
            if (cryptoResponse == null)
                throw new Exception($"Crypto service did not return a successful decrypt response.");

            if (cryptoResponse.ResponseHeader.StatusCode != 200)
                throw new Exception($"Crypto service did not return success for decrypt : StatusCode: {cryptoResponse.ResponseHeader.StatusCode}; StatusMessage: {cryptoResponse.ResponseHeader.StatusMessage}");

            return cryptoResponse;
        }

        private GenerateCvvResponse ObtainCvvFromDcpp(AccountIdentifier accountId, string expiration, Guid? paymentIdentifier = null, Guid? paymentInstrumentIdentifier = null)
        {
            var result = _dcppService.GetCardDetails(
                accountId,
                new Domain.Services.Dcpp.CardExpirationDate
                {
                    CardExpirationYear = $"20{expiration.Substring(0, 2)}",
                    CardExpirationMonth = expiration.Substring(2),
                },
                paymentIdentifier, paymentInstrumentIdentifier);

            return new GenerateCvvResponse
            {
                Cvv = result.Cvv
            };
        }

        private GenerateCvvResponse GenerateCvvResponseFromHsm(string pan, string expiration, PaymentInstrumentType paymentInstrumentType)
        {
            GetTimeout("X-GD-Bos-Crypto-GenerateCvvTimeout", out var requestTimeout);
            var request = new GenerateCvvRequest
            {
                RequestHeader = new RequestHeader
                {
                    RequestId = OptionsContext.Current.GetGuid("requestId", Guid.NewGuid())
                },
                Pan = pan,
                PaymentInstrumentType = paymentInstrumentType,
                Expiration = expiration
            };
            var cryptoResponse = _serviceInvokerProvider.GetWebResponse<GenerateCvvRequest, GenerateCvvResponse>(_cryptoUrl + GenerateCvvServiceUrl, "POST", request, requestTimeout);
            if (cryptoResponse == null)
                throw new Exception($"Crypto service did not return a successful response.");

            if (cryptoResponse.ResponseHeader.StatusCode != 200)
                throw new Exception($"Crypto service did not return success: StatusCode: {cryptoResponse.ResponseHeader.StatusCode}; StatusMessage: {cryptoResponse.ResponseHeader.StatusMessage}");

            return cryptoResponse;
        }

        private void GetTimeout(string headerName, out int? requestTimeout)
        {
            requestTimeout = null;
            if (OptionsContext.Current.IsDefined(headerName))
            {
                requestTimeout = 1;
                if (int.TryParse(OptionsContext.Current.GetString(headerName), out var rt))
                    requestTimeout = rt;
            }
        }
    }
}