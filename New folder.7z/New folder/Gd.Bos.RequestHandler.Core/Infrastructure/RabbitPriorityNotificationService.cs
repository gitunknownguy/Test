﻿using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Core.Common.Enum;
using Gd.Bos.Shared.Common.Core.RabbitMQ.Contract;
using Gd.Bos.Shared.Common.CoreApi.Contract.Message.Request;
using Newtonsoft.Json;
using NLog;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transfers;
using Gd.Bos.Shared.Common.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.Common.Data;
using RequestHandler.Core.Application;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    //Being used for only Customer Notification
    public class RabbitPriorityNotificationService : IPriorityNotificationService
    {
        private readonly IWriter<string> _queueWriter;
        private readonly IBaasConfiguration _baasConfiguration;
        private readonly IPaymentIdentifierRepository _paymentIdentifierRepository;
        private readonly INotificationEligibilityService _notificationEligibilityService;
        private readonly IAccountRepository _accountRepository;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();

        public RabbitPriorityNotificationService(IWriter<string> queueWriter, IBaasConfiguration baasConfiguration,
            IPaymentIdentifierRepository paymentIdentifierRepository, INotificationEligibilityService notificationEligibilityService, IAccountRepository accountRepository)
        {
            _queueWriter = queueWriter;
            _baasConfiguration = baasConfiguration;
            _paymentIdentifierRepository = paymentIdentifierRepository;
            _notificationEligibilityService = notificationEligibilityService;
            _accountRepository = accountRepository;
        }

        private bool DoesProgramAllowCnForEvent(string programCode, int notificationType)
        {
            switch ((CnNotificationType)notificationType)
            {
                case CnNotificationType.AchOutBankAccountLink:
                    return _baasConfiguration.PublishCustomerNotification(programCode, "Ach");
                case CnNotificationType.AchOutReturnReceived:
                    return _baasConfiguration.PublishCustomerNotification(programCode, "Ach");
                case CnNotificationType.AchOutTransactionSubmitted:
                    return _baasConfiguration.PublishCustomerNotification(programCode, "Ach");
                case CnNotificationType.CashBackRewards:
                case CnNotificationType.ECashLoad:
                case CnNotificationType.RewardsMarketPlaceToSender:
                case CnNotificationType.RewardsMarketPlaceToSenderDelete:
                case CnNotificationType.RewardsMarketPlaceToRecipient:
                case CnNotificationType.RewardsMarketPlaceToSelfPurchase:

                case CnNotificationType.AchPullInsufficientFunds:
                case CnNotificationType.AchPullReturnReceived:
                case CnNotificationType.AchPullCreditAppliedToAccount:
                case CnNotificationType.AchPullTransactionSubmitted:
                case CnNotificationType.AchPullCancelled:
                case CnNotificationType.AchPullFraudTransactionSubmissionFail:
                case CnNotificationType.P2PSendToRecipientAutoAccept:
                case CnNotificationType.P2PSendToRecipientManualAccept:
                case CnNotificationType.P2PSendToSenderRejected:
                case CnNotificationType.P2PSendToRecipientExpired:
                case CnNotificationType.P2PSendToRecipientCanceled:
                case CnNotificationType.P2PSendToRecipientNonAccountInitial:
                case CnNotificationType.P2PSendToRecipientNonAccountCanceled:
                case CnNotificationType.P2PSendToRecipientNonAccountExpired:
                case CnNotificationType.P2PSendToSenderAccepted:
                case CnNotificationType.P2PSendToSenderExpired:
                    return _baasConfiguration.PublishCustomerNotificationForP2PTransfers(programCode);

                case CnNotificationType.Welcome:
                    return _baasConfiguration.PublishCustomerNotification(programCode, "WelcomeEmail");
                case CnNotificationType.ProgramLaunchDecline:
                    return _baasConfiguration.PublishCustomerNotification(programCode, "ProgramLaunchDecline");
                case CnNotificationType.UpdateDeliveryAddress:
                    return _baasConfiguration.PublishCustomerNotification(programCode, "UpdateDeliveryAddress");
                case CnNotificationType.UpdatePhoneNumber:
                    return _baasConfiguration.PublishCustomerNotification(programCode, "UpdatePhoneNumber");
                case CnNotificationType.UpdateEmail:
                    return _baasConfiguration.PublishCustomerNotification(programCode, "UpdateEmail");
                case CnNotificationType.AdverseActionNotice:
                    return _baasConfiguration.PublishCustomerNotification(programCode, "AdverseActionNotice");
                case CnNotificationType.PaymentDeclined:
                case CnNotificationType.PaymentSuccessful:
                case CnNotificationType.PaymentOverPay:
                    return _baasConfiguration.PublishCustomerNotification(programCode);
                case CnNotificationType.DdaRestrictedDueToSuspiciousActivity:
                case CnNotificationType.DdaConfirmedFraudSccLockedWithCure:
                case CnNotificationType.DdaIdTheftSccLockedWithCure:
                case CnNotificationType.SccUnfrozenCureinPlace:
                case CnNotificationType.SccAccountTakeover:
                    return true;
                default:
                    return _baasConfiguration.PublishCustomerNotification(programCode);
            }
        }

        public Task PublishPriorityNotification(string programCode, SendCnMessageRequest messageRequest)
        {
            _logger.Info($"Start PublishPriorityNotification, programCode:{programCode}, SendCnMessageRequest:{Logging.Common.Managers.MaskEngine.MaskMessage(JsonConvert.SerializeObject(messageRequest))}");
            if (string.IsNullOrEmpty(programCode))
            {
                throw new ArgumentException("argument null or empty", nameof(programCode));
            }

            if (messageRequest == null)
            {
                throw new ArgumentNullException(nameof(messageRequest));
            }

            if (messageRequest.RequestHeader == null)
            {
                messageRequest.RequestHeader = new RequestHeader { RequestId = Guid.NewGuid() };
            }

            if (messageRequest.RequestHeader?.RequestId == default(Guid))
            {
                messageRequest.RequestHeader.RequestId = Guid.NewGuid();
            }

            if (!DoesProgramAllowCnForEvent(programCode, messageRequest.NotificationType))
            {
                _logger.Debug($"Request {messageRequest.RequestHeader?.RequestId}: CN is not allowed for programCode {programCode}");
                return Task.CompletedTask;
            }

            // CompleteVerification is a special case where the customer has not yet created an account
            // therefore we do not check notification eligibility or append last4Pan.
            if (messageRequest.NotificationType != (int)CnNotificationType.CompleteVerification)
            {

                if (!_notificationEligibilityService.IsNotificationEligible(messageRequest.AccountIdentifier))
                    return Task.CompletedTask;
                // Insert last4Pan in cn message
                messageRequest = AppendLast4Pan(messageRequest);
            }

            JsonSerializerSettings settings = new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore,
                Converters = new JsonConverter[]
                {
                    new IntToStringEnumConverter(),
                    new Newtonsoft.Json.Converters.IsoDateTimeConverter
                    {
                        DateTimeFormat = "yyyy-MM-ddTHH:mm:ssZ",
                        DateTimeStyles = DateTimeStyles.AdjustToUniversal
                    }
                }
            };

            var message = JsonConvert.SerializeObject(messageRequest, settings);
            var requestId = messageRequest.RequestHeader?.RequestId.ToString();
            lock (_queueWriter)
            {
                var headers = new Dictionary<string, object>()
                {
                    {"AccountIdentifier", messageRequest.AccountIdentifier},
                    {"ProgramCode", programCode},
                    {"EventType", /*eventType.ToString()*/ "PrioritySend"},
                    {"RequestId", requestId}
                };
                _queueWriter.Write(message, string.Empty, headers);
            }

            _logger.Info($"Sending message with RequestId {requestId} to Priority Queue : {Logging.Common.Managers.MaskEngine.MaskMessage(message)}");
            return Task.CompletedTask;
        }

        public Task PublishPriorityNotificationForPls(CnNotificationType notificationType, string programCode,
            string accountIdentifier, string merchantName, decimal amount)

        {
            if (!_baasConfiguration.NotifyCustomerAfterTransfer(programCode))
                return Task.CompletedTask;
            _logger.Info(
                "PublishPriorityNotification after transfer, {programCode}, {accountIdentifier}, {merchantName}, {amount}",
                programCode, accountIdentifier, merchantName, amount);

            var notifyAccount = _accountRepository.GetAccountPrimaryConsumerProfile(
                AccountIdentifier.FromString(accountIdentifier));
            string notifyEmail = notifyAccount.Email;
            string notifyPhone = notifyAccount.PhoneNumber;
            string productCode = notifyAccount.ProductCode;
            string firstName = notifyAccount.FirstName;

            MessageAttribute[] attributes;
            attributes = new MessageAttribute[]
            {
                new() { Name = "FirstName", Value = firstName }, new() { Name = "Merchant", Value = merchantName },
                new() { Name = "Amount", Value = Math.Round(amount, 2).ToString("F") },
                new() { Name = "Date", Value = DateTime.Today.ToString() }
            };


            SendCnMessageRequest request = new SendCnMessageRequest
            {
                RequestHeader =
                    new Shared.Common.Contract.Message.Request.RequestHeader() { RequestId = Guid.NewGuid() },
                AccountIdentifier = accountIdentifier,
                NotificationType = (int)notificationType,
                ProgramCode = programCode,
                ProductCode = productCode,
                Attributes = attributes,
                Contacts = new MessageContact[]
                {
                    new() { ChannelType = "1", ContactValue = notifyPhone},
                    new() { ChannelType = "2", ContactValue = notifyEmail },
                    new() { ChannelType = "3", ContactValue = "" }
                }
            };

            // remove contacts with null or empty values to prevent validation 
            // errors from CN API.
            request.Contacts = request.Contacts
                .Where(x => !string.IsNullOrEmpty(x.ContactValue) || x.ChannelType == "3").ToArray();

            return PublishPriorityNotification(programCode, request);
        }


        private SendCnMessageRequest AppendLast4Pan(SendCnMessageRequest messageRequest)
        {
            // Skip non account holders
            if (messageRequest.NotificationType == 30 || messageRequest.NotificationType == 33)
                return messageRequest;

            var last4Pan = string.Empty;
            var payments = _paymentIdentifierRepository.GetPaymentIdentifierByAccountIdentifier(messageRequest.AccountIdentifier);

            last4Pan = payments.FirstOrDefault(pi => pi?.PaymentInstrumentStatus == 1 && pi?.IsTemp == false)?.Last4Pan;
            if (string.IsNullOrEmpty(last4Pan))
                last4Pan = payments.FirstOrDefault(pi => pi?.PaymentInstrumentStatus == 2 && pi?.IsTemp == false)?.Last4Pan;

            if (!string.IsNullOrEmpty(last4Pan))
            {
                var attributeList = messageRequest.Attributes?.ToList();
                attributeList?.Add(new MessageAttribute { Name = "Last4PAN", Value = last4Pan });
                messageRequest.Attributes = attributeList?.ToArray();
            }

            return messageRequest;
        }
    }
}
