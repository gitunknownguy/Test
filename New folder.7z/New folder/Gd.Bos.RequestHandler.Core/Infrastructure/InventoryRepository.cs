﻿using Gd.Bos.Shared.Common.Core.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.Shared.Common.Caching;
using Gd.Bos.Shared.Common.Caching.Contract;
using RequestHandler.Core.Domain.Model.Inventory;
using Gd.Bos.Shared.Common.Core.Contract.Response;
using Gd.Bos.Shared.Common.Core.Contract.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.RequestHandler.Core.Utils;
using Microsoft.Data.SqlClient;
using NLog;
using RequestHandler.Core.Domain.Enums;
using ResponseHeader = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response.ResponseHeader;
using System.Threading.Tasks;
using Org.BouncyCastle.Asn1.Ocsp;

namespace RequestHandler.Core.Infrastructure
{
    public class InventoryRepository : IInventoryRepository
    {

        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();
        private readonly string _userName = IdentityHelper.GetIdentityName();

        public InventoryRepository(IDataAccess dataAccess, ILazyCache lazyCache)
        {
            _dataAccess = dataAccess;
            _lazyCache = lazyCache;
        }

        public InventoryResponse SaveRequestInventory(InventoryRequest request, string orderIdentifier)
        {
            if (request == null)
            {
                Logger.Error(
                    $"InventoryRepository.SaveRequestInventory: InventoryRequest cannot be null");

                throw new ArgumentException($"InventoryRequest cannot be null");
            }
            InventoryResponse response = new InventoryResponse();
            int deliveryMethodKey = GetDeliveryMethodKeyByDeliveryType(request.DeliveryType);
            decimal inventoryOrderKey = 0;

            try
            {

                var inventoryParams = new[]
                {
                    new SqlParameter() { ParameterName = "ClientReferenceNumber", Value = request.ClientReferenceNumber },
                    new SqlParameter() { ParameterName = "DeliveryMethodKey", Value = deliveryMethodKey },
                    new SqlParameter() { ParameterName = "OrderIdentifier", Value = orderIdentifier },
                    new SqlParameter() { ParameterName = "EmployerID", Value = request.CompanyId },
                    new SqlParameter() { ParameterName = "ChangeBy", Value = _userName },
                    new SqlParameter() { ParameterName = "Email", Value = request.Email },
                    new SqlParameter() { ParameterName = "Company", Value = request.Company },
                    new SqlParameter() { ParameterName = "Phone", Value = request.Phone },
                    new SqlParameter() { ParameterName = "InventoryOrderStatusKey", Value = InventoryOrderStatus.Pending }
                };

                using (var reader = _dataAccess.ExecuteReader("[dbo].InsInventoryOrder",
                           _dataAccess.CreateConnection(), inventoryParams))
                {
                    while (reader.Read())
                    {
                        inventoryOrderKey = Cast<decimal>(reader["InventoryOrderKey"]);
                    }
                }

                var deliveryAddressParams = new[]
                {
                    new SqlParameter() { ParameterName = "InventoryOrderKey", Value = inventoryOrderKey },
                    new SqlParameter() { ParameterName = "ContactName", Value = request.DeliveryAddress.ContactName },
                    new SqlParameter() { ParameterName = "AddressLine1", Value = request.DeliveryAddress.AddressLine1 },
                    new SqlParameter() { ParameterName = "AddressLine2", Value = request.DeliveryAddress.AddressLine2 },
                    new SqlParameter() { ParameterName = "City", Value = request.DeliveryAddress.City },
                    new SqlParameter() { ParameterName = "State", Value = request.DeliveryAddress.State },
                    new SqlParameter() { ParameterName = "PostalCode", Value = request.DeliveryAddress.PostalCode },
                    new SqlParameter() { ParameterName = "Country", Value = request.DeliveryAddress.Country },
                    new SqlParameter()
                    {
                        ParameterName = "IsResidential",
                        Value = request.DeliveryAddress.Residential == "Y" ? 1 : 0
                    },
                    new SqlParameter() { ParameterName = "ChangeBy", Value = _userName },
                };

                using (var reader = _dataAccess.ExecuteReader("[dbo].InsInventoryOrderDeliveryAddress",
                           _dataAccess.CreateConnection(), deliveryAddressParams))
                {
                    while (reader.Read())
                    {

                    }
                }

                response = new InventoryResponse()
                {
                    OrderIdentifier = orderIdentifier,
                    OrderCreated = DateTime.Now,
                    ClientReferenceNumber = request.ClientReferenceNumber,
                    Status = InventoryOrderStatus.Pending.ToString(),
                    ResponseHeader = new ResponseHeader()
                    {
                        StatusCode = 200,
                        SubStatusCode = 0,
                        Message = "Success",
                        ResponseId = request.RequestHeader.RequestId
                    }
                };

            }
            catch (SqlException ex)
            {
                Logger.Error(
                    $"InventoryRepository.SaveRequestInventory: An error occurred trying to save inventory order: {ex}");

                throw new Exception($"An error occurred trying to save inventory order: {ex}");
            }

            try
            {

                foreach (Line line in request.Lines)
                {
                    int productKey = GetProductKeyByProductCode(line.ProductCode);
                    var lineParams = new[]
                    {
                        new SqlParameter() { ParameterName = "LineType", Value = Cast<string>(line.LineType) },
                        new SqlParameter() { ParameterName = "ProductKey", Value = productKey},
                        new SqlParameter() { ParameterName = "Quantity", Value = Cast<Int64>(line.Quantity) },
                        new SqlParameter() { ParameterName = "OrderIdentifier", Value = orderIdentifier },
                        new SqlParameter() { ParameterName = "InventoryCode", Value = line.InventoryCode },
                        new SqlParameter() { ParameterName = "ChangeBy", Value = _userName }
                    };



                    object linesResult = _dataAccess.ExecuteScalar("[dbo].[InsInventoryOrderLine]",
                        _dataAccess.CreateConnection(), lineParams);

                }

            }
            catch (SqlException ex)
            {
                Logger.Error(
                    $"InventoryRepository.SaveRequestInventory: An error occurred trying to save inventory line: {ex}");

                throw new Exception($"An error occurred trying to save inventory line: {ex}");
            }

            return response;

        }

        public InventoryOrderStatusResponse GetInventoryOrderStatus(string orderId)
        {
            InventoryOrderStatusResponse orderStatus = new InventoryOrderStatusResponse();

            var inventoryParams = new[]
            {
                new SqlParameter() { ParameterName = "PurchaseOrderID", Value = orderId }
            };

            try
            {
                using (var reader = _dataAccess.ExecuteReader("[dbo].GetInventoryOrderDetailsByPurchaseOrderID",
                           _dataAccess.CreateConnection(), inventoryParams))
                {
                    while (reader.Read())
                    {
                        orderStatus = new InventoryOrderStatusResponse()
                        {
                            ClientReferenceNumber = reader.GetString(reader.GetOrdinal("ClientReferenceNumber")),
                            OrderIdentifier = reader.GetGuid(reader.GetOrdinal("PurchaseOrderId")).ToString(),
                            Status = reader.GetString(reader.GetOrdinal("Status")),
                            OrderCreated = reader.GetDateTime(reader.GetOrdinal("CreateDate")),
                        };
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex, $"Error:{ex.Message}");
            }
            return orderStatus;
        }


        private int GetProductKeyByProductCode(string productCode)
        {
            var products = _lazyCache.Get("PRODUCT_CODES", new TimeSpan(0, 2, 0, 0), () => GetAllProducts());
            var product = products.Find(p => p.Item3.ToLower().Equals(productCode.ToLower()));
            if (product == null)
                throw new Exception("No Product exists for specified ProductCode.");

            return product.Item1;
        }

        private int GetDeliveryMethodKeyByDeliveryType(string deliveryType)
        {
            var deliveriesMeth = _lazyCache.Get("METHOD_KEYS", new TimeSpan(1, 0, 0, 0), () => GetAllDeliveryMethods());
            var delivery = deliveriesMeth.Find(p => p.Item2.ToLower().Equals(deliveryType.ToLower()));
            if (delivery == null)
                throw new Exception("No Delivery methods exists for specified deliveryType.");

            return delivery.Item1;
        }

        private List<Tuple<int, string, string, string, string, string, int, Tuple<string, string>>> GetAllProducts(bool lowerCaseName = true)
        {
            var returnValue = new List<Tuple<int, string, string, string, string, string, int, Tuple<string, string>>>();
            using (var reader = _dataAccess.ExecuteReader("GetAllProduct", _dataAccess.CreateConnection(), null))
            {
                while (reader.Read())
                {
                    var productKey = reader.GetInt32(0);
                    var productName = lowerCaseName ? reader.GetString(1).ToLower() : reader.GetString(1);
                    var productCode = reader.GetString(2);
                    var programCode = reader.GetString(3);
                    var achPrefix = reader.IsDBNull(4) ? null : reader.GetString(4);
                    var bin = reader.IsDBNull(5) ? null : reader.GetString(5);
                    var bankName = reader.IsDBNull(6) ? string.Empty : reader.GetString(6);
                    var abaRoutingNumber = reader.IsDBNull(7) ? null : reader.GetString(7);
                    int binProductKey = reader["BINProductKey"] == DBNull.Value ? 0 : Convert.ToInt32(reader["BINProductKey"]);

                    returnValue.Add(new Tuple<int, string, string, string, string, string, int, Tuple<string, string>>(productKey, productName,
                        productCode, programCode, achPrefix, abaRoutingNumber, binProductKey, new Tuple<string, string>(bin, bankName)));
                }
            }

            return returnValue;
        }

        private List<Tuple<int, string>> GetAllDeliveryMethods(bool lowerCaseName = true)
        {
            var returnValue = new List<Tuple<int, string>>();
            using (var reader = _dataAccess.ExecuteReader("GetAllDeliveryMethod", _dataAccess.CreateConnection(), null))
            {
                while (reader.Read())
                {
                    var deliveryMethodKey = reader.GetInt16(0);
                    var deliveryMethod = reader.GetString(1);

                    returnValue.Add(new Tuple<int, string>(deliveryMethodKey, deliveryMethod));
                }
            }

            return returnValue;
        }

        private static T Cast<T>(object value)
        {
            if (value == DBNull.Value || value == null)
                return default(T);

            return (T)value;
        }

        private readonly IDataAccess _dataAccess;
        private readonly ILazyCache _lazyCache;

    }
}
