﻿using System;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using RequestHandler.Core.Domain.Enums;

namespace RequestHandler.Core.Infrastructure
{
    public interface ICreateLinkedAccountRepository
    {
        public void SaveRequest<T>(T request, Guid key) where T : BaseRequest;
        public void SaveRequest<T, TEnum>(T request, TEnum enumValue, Guid key) where T : BaseRequest where TEnum : Enum;
        public void UpdateRequest<T>(T request, Guid key) where T : BaseRequest;
        CreateLinkedAccountStatus GetStatusByKey(Guid accountId);
        TEnum? GetStatusByKeyWithoutException<TEnum>(Guid key) where TEnum : struct, Enum;
        CreateLinkedAccountStatus? GetStatusByKeyWithoutException(Guid key);
        void UpdateStatusByKey(Guid accountId, CreateLinkedAccountStatus status);
        void UpdateStatusByKey<T>(Guid key, T status) where T : Enum;
    }
}
