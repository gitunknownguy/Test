﻿using System;
using System.Diagnostics.CodeAnalysis;
using Gd.Bos.Shared.Common.Core.Contract;
using Gd.Bos.Shared.Common.Core.Contract.Enum;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.Logic;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.RequestHandler.Core.Domain.Services.IFT;
using Gd.Bos.RequestHandler.Core.Domain.Services.IFT.Enum;
using Gd.Bos.RequestHandler.Core.Domain.Services.IFT.Request;
using Gd.Bos.RequestHandler.Core.Domain.Services.IFT.Response;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class InstantFundTransferService : IInstantFundTransferService
    {
        private readonly string _iftBaseUrl;


        private readonly IServiceInvokeProvider _serviceInvokeProvider;

        public InstantFundTransferService(IServiceInvokeProvider serviceInvokeProvider)
        {
            _serviceInvokeProvider = serviceInvokeProvider;
            _iftBaseUrl = Configuration.Configuration.Current.InstantFundTransferBaseUrl;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="programCode"></param>
        /// <param name="amount"></param>
        /// <param name="cardHolderName"></param>
        /// <param name="cardNumber"></param>
        /// <param name="expirationDate">MMyy</param>
        /// <param name="cvv"></param>
        /// <param name="transactionReference"></param>
        /// <returns></returns>
        public Domain.Services.IFT.TransactResponse TransactCard(string programCode, Gd.Bos.Shared.Common.Core.Contract.CurrencyAmount amount, string cardHolderFirstName, string cardHolderLastName,
            string cardNumber, CardExpirationDate expirationDate, string cvv, Guid transactionReference, string merchantName,
            string zipCode, TransType transType)
        {
            int? requestTimeout = null;
            GetTimeout("X-GD-Bos-IFT-TransactTimeOut", out requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            var expr = expirationDate.CardExpirationMonth + expirationDate.CardExpirationyear.Substring(2, 2);

            var transactUrl = "/transactions/3ds/transact";
            var response = _serviceInvokeProvider
                .GetWebResponse<ThreeDimensionalTransactRequest, ThreeDimentionalTransactResponse>(
                    _iftBaseUrl + $"/programs/{programCode}{transactUrl}",
                    "POST",
                    new ThreeDimensionalTransactRequest
                    {
                        Header = new SignatureHeader { ProgramCode = programCode, RequestId = reqId.ToString() },
                        Amount = amount.Amount,
                        Currency = amount.CurrencyCode,
                        EciIndicator = "01",
                        PaymentType = PaymentType.Default,
                        ThreeDimensionalData = new ThreeDimensionalData
                        {
                            Type = "D",
                            CardHolderName = $"{cardHolderFirstName} {cardHolderLastName}",
                            CardNumber = cardNumber,
                            ExpirationDate = expr,
                            Cvv = cvv
                            //TransactionId = transactionId.ToString()
                        },
                        MerchantName = merchantName,
                        //MerchantCity = ,
                        ZipCode = zipCode,
                        TransType = transType,
                        TransactionReference = transactionReference.ToString()
                    },
                    requestTimeout);

            if (response == null)
                throw new Exception($"IFT did not return a recognizable response for {transactUrl}.");

            var iftResponse = new Domain.Services.IFT.TransactResponse()
            {
                TransactionId = response.TransactionId,
                AuthCode = response.AuthId,
                AvsFullResult = response.AvsResultCode,
                CvvResult = response.CcvResultCode,
                ProcessorResponseCode = response.ExternalResponseReasonCode,
                ProcessorResponseText = response.ExternalResponseReasonMessage,
                GatewayName = response.GatewayName,
                CardType = response.CardType
            };

            if (response.TransactionResponseReasonCode != 200)
            {
                if (response.TransactionResponseReasonCode == 202)
                    throw new IFTException(
                        3,
                        400,
                        $"IFT Service returned InsufficientFunds for {transactUrl}: TransactionResponseReasonCode: {response.TransactionResponseReasonCode}, TransactionResponseReasonMessage: {response.TransactionResponseReasonMessage}, ExternalResponseReasonCode: {response.ExternalResponseReasonCode}, ExternalResponseReasonMessage: {response.ExternalResponseReasonMessage}, ExternalResponseCodeType: {response.ExternalResponseCodeType}",
                        iftResponse);

                if (response.TransactionResponseReasonCode == 204)
                    throw new IFTException(
                        3,
                        401,
                        $"IFT Service returned Declined for {transactUrl}: TransactionResponseReasonCode: {response.TransactionResponseReasonCode}, TransactionResponseReasonMessage: {response.TransactionResponseReasonMessage}, ExternalResponseReasonCode: {response.ExternalResponseReasonCode}, ExternalResponseReasonMessage: {response.ExternalResponseReasonMessage}, ExternalResponseCodeType: {response.ExternalResponseCodeType}",
                        iftResponse);

                throw new IFTException(
                    3,
                    402,
                    $"IFT Service did not return success for {transactUrl}: TransactionResponseReasonCode: {response.TransactionResponseReasonCode}, TransactionResponseReasonMessage: {response.TransactionResponseReasonMessage}, ExternalResponseReasonCode: {response.ExternalResponseReasonCode}, ExternalResponseReasonMessage: {response.ExternalResponseReasonMessage}, ExternalResponseCodeType: {response.ExternalResponseCodeType}",
                    iftResponse);
            }

            return iftResponse;
        }

        public Domain.Services.IFT.TransactResponse InstantWithdraw(string programCode, Gd.Bos.Shared.Common.Core.Contract.CurrencyAmount amount,
            string cardHolderFirstName, string cardHolderLastName, string cardNumber, CardExpirationDate expirationDate, string cvv,
            string addressline1, string addressline2, string city, string state, string zipCode, string country,
            Guid transactionReference,
            string senderFirstName, string senderLastname, string senderAddressLine1, string senderAddressLine2,
            string senderCity, string senderState, string senderCountry, string senderZip)
        {
            int? requestTimeout = null;
            GetTimeout("X-GD-Bos-IFT-TransactTimeOut", out requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            var expr = expirationDate.CardExpirationMonth + expirationDate.CardExpirationyear.Substring(2, 2);

            var instantWithdrawUrl = "/transactions/instantwithdraw";
            var response = _serviceInvokeProvider
                .GetWebResponse<InstantWithdrawRequest, InstantWithdrawResponse>(
                    _iftBaseUrl + $"/programs/{programCode}{instantWithdrawUrl}",
                    "POST",
                    new InstantWithdrawRequest
                    {
                        Header = new SignatureHeader { ProgramCode = programCode, RequestId = reqId.ToString() },
                        Amount = amount.Amount,
                        Currency = amount.CurrencyCode,
                        EciIndicator = "01",
                        PaymentType = PaymentType.Default,
                        ReceiverCard = new Domain.Services.IFT.Request.CardData()
                        {
                            CardNumber = cardNumber,
                            ExpirationDate = expr,
                            Cvv = cvv,

                        },
                        ReceiverCardHolder = new CardHolderData()
                        {
                            FirstName = cardHolderFirstName,
                            LastName = cardHolderLastName,
                            Address1 = addressline1,
                            City = city,
                            State = state,
                            Country = country ?? "USA",
                            PostalCode = zipCode,
                            BusinessName = "BusinessName",
                            PhoneNumber = "1234567890",
                            DateOfBirth = DateTime.Now

                        },
                        SenderCardHolder = new CardHolderData()
                        {
                            FirstName = senderFirstName,
                            LastName = senderLastname,
                            Address1 = senderAddressLine1,
                            Address2 = senderAddressLine2,
                            City = senderCity,
                            State = senderState,
                            Country = senderCountry ?? " USA",
                            PostalCode = senderZip,
                            BusinessName = "BusinessName",
                            PhoneNumber = "1234567890",
                            DateOfBirth = DateTime.Now
                        },
                        TransactionReference = transactionReference.ToString()
                    },
                    requestTimeout);

            if (response == null)
                throw new Exception($"IFT did not return a recognizable response for {instantWithdrawUrl}.");

            if (response.TransactionResponseReasonCode != 200)
            {
                if (response.TransactionResponseReasonCode == 202)
                    throw new IFTException(
                        3,
                        400,
                        $"IFT Service returned InsufficientFunds for {instantWithdrawUrl}: TransactionResponseReasonCode: {response.TransactionResponseReasonCode}, TransactionResponseReasonMessage: {response.TransactionResponseReasonMessage}, ExternalResponseReasonCode: {response.ExternalResponseReasonCode}, ExternalResponseReasonMessage: {response.ExternalResponseReasonMessage}, ExternalResponseCodeType: {response.ExternalResponseCodeType}");

                if (response.TransactionResponseReasonCode == 204)
                    throw new IFTException(
                        3,
                        401,
                        $"IFT Service returned Declined for {instantWithdrawUrl}: TransactionResponseReasonCode: {response.TransactionResponseReasonCode}, TransactionResponseReasonMessage: {response.TransactionResponseReasonMessage}, ExternalResponseReasonCode: {response.ExternalResponseReasonCode}, ExternalResponseReasonMessage: {response.ExternalResponseReasonMessage}, ExternalResponseCodeType: {response.ExternalResponseCodeType}");

                throw new IFTException(
                    3,
                    402,
                    $"IFT Service did not return success for {instantWithdrawUrl}: TransactionResponseReasonCode: {response.TransactionResponseReasonCode}, TransactionResponseReasonMessage: {response.TransactionResponseReasonMessage}, ExternalResponseReasonCode: {response.ExternalResponseReasonCode}, ExternalResponseReasonMessage: {response.ExternalResponseReasonMessage}, ExternalResponseCodeType: {response.ExternalResponseCodeType}");
            }

            return new Domain.Services.IFT.TransactResponse()
            {
                TransactionId = response.TransactionId
            };
        }

        public Domain.Services.IFT.VoidResponse Void(string programCode, Gd.Bos.Shared.Common.Core.Contract.CurrencyAmount amount, Guid transactionReference)
        {
            int? requestTimeout = null;
            GetTimeout("X-GD-Bos-IFT-VoidTimeOut", out requestTimeout);
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);

            var voidUrl = "/transactions/void";
            var response = _serviceInvokeProvider
                .GetWebResponse<VoidRequest, Domain.Services.IFT.Response.VoidResponse>(
                    _iftBaseUrl + $"/programs/{programCode}{voidUrl}", "POST",
                    new VoidRequest
                    {
                        Header = new SignatureHeader { ProgramCode = programCode, RequestId = reqId.ToString() },
                        Amount = amount.Amount,
                        Currency = amount.CurrencyCode,
                        TransactionReference = transactionReference.ToString(),
                        IsBatchVoid = true,
                    },
                    requestTimeout);

            if (response == null)
                throw new Exception($"IFT did not return a recognizable response for {voidUrl}.");

            if (response.TransactionResponseReasonCode != 200)
            {
                if (response.TransactionResponseReasonCode == 202)
                    throw new IFTException(3, 400,
                        $"IFT Service returned InsufficientFunds for {voidUrl}: TransactionResponseReasonCode: {response.TransactionResponseReasonCode}, TransactionResponseReasonMessage: {response.TransactionResponseReasonMessage}, ExternalResponseReasonCode: {response.ExternalResponseReasonCode}, ExternalResponseReasonMessage: {response.ExternalResponseReasonMessage}, ExternalResponseCodeType: {response.ExternalResponseCodeType}");

                if (response.TransactionResponseReasonCode == 204)
                    throw new IFTException(3, 401,
                        $"IFT Service returned Declined for {voidUrl}: TransactionResponseReasonCode: {response.TransactionResponseReasonCode}, TransactionResponseReasonMessage: {response.TransactionResponseReasonMessage}, ExternalResponseReasonCode: {response.ExternalResponseReasonCode}, ExternalResponseReasonMessage: {response.ExternalResponseReasonMessage}, ExternalResponseCodeType: {response.ExternalResponseCodeType}");

                throw new IFTException(3, 402,
                    $"IFT Service did not return success for {voidUrl}: TransactionResponseReasonCode: {response.TransactionResponseReasonCode}, TransactionResponseReasonMessage: {response.TransactionResponseReasonMessage}, ExternalResponseReasonCode: {response.ExternalResponseReasonCode}, ExternalResponseReasonMessage: {response.ExternalResponseReasonMessage}, ExternalResponseCodeType: {response.ExternalResponseCodeType}");
            }

            return new Domain.Services.IFT.VoidResponse()
            {
                TransactionId = response.TransactionId
            };
        }

        /// <summary>
        /// Get card information by bin
        /// </summary>
        public CardDetailResponse GetCardDetail(string programCode, string bin)
        {
            CardDetailResponse cardDetail = null;
            Guid.TryParse(OptionsContext.Current.GetString("requestId"), out var reqId);
            try
            {
                GetCardDetailResponse response = _serviceInvokeProvider
                    .GetWebResponse<GetCardDetailRequest, GetCardDetailResponse>(
                        _iftBaseUrl + $"/programs/{programCode}/getCardDetail", "POST",
                        new GetCardDetailRequest
                        {
                            Header = new SignatureHeader { ProgramCode = programCode, RequestId = reqId.ToString() },
                            Pan = bin
                        });

                cardDetail = new CardDetailResponse()
                {
                    BankName = response.BankName,
                    CardBrand = response?.CardBrand,
                    CardType = response?.CardType,
                    CountryCode = response.CountryCode
                };
            }
            catch
            {
                //no action
            }

            return cardDetail;
        }

        private void GetTimeout(string headerName, out int? requestTimeout)
        {
            requestTimeout = null;
            if (OptionsContext.Current.IsDefined(headerName))
            {
                requestTimeout = 1;
                if (int.TryParse(OptionsContext.Current.GetString(headerName), out var rt))
                    requestTimeout = rt;
            }
        }
    }
}