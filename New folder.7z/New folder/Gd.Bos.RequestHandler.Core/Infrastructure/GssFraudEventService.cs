﻿using Gd.Bos.Logging.Common.Managers;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request;
using Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Response;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.Logic;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.Shared.Common.CoreApi.Contract.Message.Response;
using Newtonsoft.Json;
using NLog;
using RequestHandler.Core.Domain.Services.Risk.Data;
using RequestHandler.Core.Domain.Services.Risk.Messages.Request;
using RequestHandler.Core.Domain.Services.Risk.Messages.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using Address = Gd.Bos.RequestHandler.Core.Domain.Model.User.Address;
using Email = Gd.Bos.RequestHandler.Core.Domain.Model.User.Email;
using LogManager = NLog.LogManager;
using PhoneNumber = Gd.Bos.RequestHandler.Core.Domain.Model.User.PhoneNumber;
using User = Gd.Bos.RequestHandler.Core.Domain.Model.User.User;



namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class GssFraudEventService : IGssFraudEventService
    {
        public GssFraudEventService(IServiceInvokeProvider serviceInvokeProvider)
        {
            _serviceInvokerProvider = serviceInvokeProvider;
            _gssFraudUrl = Configuration.Configuration.Current.GssFraudEventApiUrl;
        }

        private readonly string _gssFraudUrl;
        private readonly IServiceInvokeProvider _serviceInvokerProvider;
        private const string VerifyRiskProfileUrl = "/verify/Profile";
        private const string EnrollPhoneUrl = "/enroll/phone";
        private const string SearchFraudIdentityUrl = "/search/fraudIdentity";
        private const string AddressVelocityUrl = "/{0}/validate/AddressLimit";
        private const string UpdateAddressVelocityUrl = "/update/AddressLimit/request";
        private const string GetDepositorNameUrl = "/directDepositReview/{0}/depositorName";
        private const string AddFraudIdentityUrl = "/add/fraudIdentity";
        private const string Brand = "Baas";


        private static readonly ILogger _logger = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// enroll fone book
        /// </summary>
        public EnrollPhoneResponse EnrollPhone(
            UserIdentifier consumerProfileIdentifier,
            IEnumerable<PhoneNumber> phoneNumbers)
        {
            var requestId = OptionsContext.Current.GetGuid("requestId", new Guid());
            var programCode = OptionsContext.Current.GetString("programCode");

            List<string> mobilePhones = phoneNumbers?.Where(s => s.Type == PhoneType.Mobile).Select(s => s.Number).ToList();

            EnrollPhoneRequest request = new EnrollPhoneRequest
            {
                RequestHeader = new Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request.RequestHeader { RequestId = requestId },
                ProgramCode = programCode,
                ExternalIdentifiers = new Dictionary<string, object>
                {
                    { "ConsumerProfileIdentifier",consumerProfileIdentifier.ToString()}
                },
                PhoneNumbers = mobilePhones,
                CustomData = null,
                EventType = EnrollPhoneEventType.Enrollment.ToString()
            };

            EnrollPhoneResponse enrollPhoneResponse = null;
            try
            {
                enrollPhoneResponse = _serviceInvokerProvider.GetWebResponse<EnrollPhoneRequest, EnrollPhoneResponse>(
                    _gssFraudUrl + EnrollPhoneUrl, "POST", request);
            }
            catch (Exception e)
            {
                _logger.Warn(e, $"Call Enroll in Fone Book(/enroll/phone) exception occur message.");
            }

            //error refer link:https://confluence/display/RISK/GSS+-+Fraud+Payfone+Fonebook+APIs#GSSFraudPayfoneFonebookAPIs-/enroll/phone:
            if (enrollPhoneResponse == null)
            {
                _logger.Info($"Call Enroll in Fone Book(/enroll/phone) Faild requestId: ." + requestId);
            }
            else
            {
                _logger.Info($"The EnrollPhone api has been called Request:{MaskEngine.MaskMessage(JsonConvert.SerializeObject(request))},Response:{MaskEngine.MaskMessage(JsonConvert.SerializeObject(enrollPhoneResponse))}");
            }

            return enrollPhoneResponse;
        }

        public VerifyProfileResponse VerifyProfile(
            User user,
            IEnumerable<Address> addresses,
            Email email,
            PhoneNumber phone,
            Domain.Model.Account.AccountHolder accountHolder)
        {
            var requestId = OptionsContext.Current.GetGuid("requestId", new Guid());
            var programCode = OptionsContext.Current.GetString("programCode");

            var address = addresses?.FirstOrDefault(item =>
                 string.Compare(item.Type, AddressType.Home.ToString(), StringComparison.InvariantCultureIgnoreCase) > -1);


            var request = new VerifyProfileRequest
            {
                RequestHeader = new Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request.RequestHeader { RequestId = requestId },
                IdentityInfo = new VerifyProfileIdentityInfo
                {
                    ExternalIdentifiers = new Dictionary<string, object>
                    {
                        { "AccountHolderIdentifier", accountHolder?.AccountHolderIdentifier.ToString()},
                        { "AccountIdentifier", accountHolder?.AccountIdentifier.ToString() },
                        { "VerificationRequestIdentifier", accountHolder?.VerificationRequestIdentifier.ToString() }
                    },

                    FirstName = user?.Name?.FirstName,
                    LastName = user?.Name?.LastName,
                    Address1 = address?.AddressLine1,
                    Address2 = address?.AddressLine2,
                    City = address?.City,
                    State = address?.State,
                    ZipCode = address?.ZipCode,
                    PhoneNumber = phone?.Number,
                    Email = email?.EmailAddress,
                    Program = programCode
                }
            };

            VerifyProfileResponse verifyProfileResponse = null;
            try
            {
                verifyProfileResponse = _serviceInvokerProvider.GetWebResponse<VerifyProfileRequest, VerifyProfileResponse>
                   (_gssFraudUrl + VerifyRiskProfileUrl, "POST", request);
            }
            catch (Exception e)
            {
                _logger.Warn(e, $"Call Payfone Trust Score(/Verfiy/profile) exception occur message");
            }

            if (verifyProfileResponse == null)
            {
                _logger.Info($"Call Payfone Trust Score(/Verfiy/profile) Faild requestId: ." +
                             requestId);
            }
            else
            {
                _logger.Info(
                    $"The Payfone Trust Score api has been called Request:{MaskEngine.MaskMessage(JsonConvert.SerializeObject(request))},Response:{MaskEngine.MaskMessage(JsonConvert.SerializeObject(verifyProfileResponse))}");
            }

            return verifyProfileResponse;
        }

        public SearchFraudIdentityResponse SearchFraudIdentity(
            IEnumerable<Address> addresses,
            Email email,
            IEnumerable<PhoneNumber> phones)
        {
            var requestId = OptionsContext.Current.GetGuid("requestId", new Guid());

            var addressesObj = new List<AddressObj>();
            if (addresses != null)
            {
                foreach (var p in addresses)
                {
                    string addressType;
                    switch (p.Type.ToLower())
                    {
                        case "home":
                            addressType = "Residential";
                            break;
                        case "work":
                            addressType = "Unknown";
                            break;
                        case "billing":
                            addressType = "Billing";
                            break;
                        default:
                            addressType = "Unknown";
                            break;
                    }
                    addressesObj.Add(new AddressObj
                    {
                        Address1 = p.AddressLine1,
                        Address2 = p.AddressLine2,
                        AddressType = addressType,
                        City = p.City,
                        State = p.State,
                        ZipCode = p.ZipCode
                    });
                }
            }

            var request = new SearchFraudIdentityRequest
            {
                RequestHeader = new Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request.RequestHeader
                { RequestId = requestId },
                FraudIdentities = new List<FraudIdentityObject>
                {
                    new FraudIdentityObject
                    {
                        Addresses = addressesObj.Count > 0 ? addressesObj : null,
                        Phones = GetSearchFraudIdentityPhoneList(phones),
                        Emails = new List<string> { email?.EmailAddress ?? ""},
                    }
                }
            };


            SearchFraudIdentityResponse searchFraudIdentityResponse = null;
            try
            {
                searchFraudIdentityResponse = _serviceInvokerProvider.GetWebResponse<SearchFraudIdentityRequest, SearchFraudIdentityResponse>
                   (_gssFraudUrl + SearchFraudIdentityUrl, "POST", request);
            }
            catch (Exception e)
            {
                _logger.Warn(e, $"Call Negative Match(/search/fraudIdentity) exception occur message");
            }

            if (searchFraudIdentityResponse == null)
            {
                _logger.Info($"Call Negative Match(/search/fraudIdentity) Faild requestId: ." +
                             requestId);
            }
            else
            {
                _logger.Info(
                    $"The Negative Match api has been called Request:{MaskEngine.MaskMessage(JsonConvert.SerializeObject(request))},Response:{MaskEngine.MaskMessage(JsonConvert.SerializeObject(searchFraudIdentityResponse))}");
            }

            return searchFraudIdentityResponse;

        }

        public AddFraudIdentityResponse AddFraudIdentity(string programCode, string accountIdentifier, List<NegativeMatchIdentity> identities, Email email, IEnumerable<PhoneNumber> phones, string fraudNegReason)
        {
            var requestId = OptionsContext.Current.GetGuid("requestId", new Guid());

            var request = new AddFraudIdentityRequest
            {
                RequestHeader = new RequestHeader
                { RequestId = requestId },
                FraudIdentities = new List<AddFraudIdentityObject>
                {
                    new AddFraudIdentityObject
                    {
                        Program = programCode,
                        Brand = Brand,
                        AccountIdentifier = accountIdentifier,
                        PersonalIdTokens = identities == null
                            ? null
                            : identities.Select(id => new PersonalIdTokenObj()
                                { PersonalIdToken = id.Token, PersonalIdType = id.Type }).ToList(),
                        Phones = GetSearchFraudIdentityPhoneList(phones),
                        Emails = email != null ? new List<string> { email?.EmailAddress } : null,
                        FraudIdentityReasons = new List<string>() { fraudNegReason }
                    },
                }
            };

            AddFraudIdentityResponse addFraudIdentityResponse = null;
            try
            {
                addFraudIdentityResponse = _serviceInvokerProvider.GetWebResponse<AddFraudIdentityRequest, AddFraudIdentityResponse>
                   (_gssFraudUrl + AddFraudIdentityUrl, "POST", request);
            }
            catch (Exception exception)
            {
                _logger.Error($"Call Negative Match(${AddFraudIdentityUrl}) exception occur message: {exception}");
                throw exception;
            }

            if (addFraudIdentityResponse == null)
            {
                throw new Exception($"Invalid response from fraud api {AddFraudIdentityUrl}");
            }
            else
            {
                _logger.Info(
                    $"The Negative Match api has been called Request:{MaskEngine.MaskMessage(JsonConvert.SerializeObject(request))},Response:{MaskEngine.MaskMessage(JsonConvert.SerializeObject(addFraudIdentityResponse))}");
            }

            return addFraudIdentityResponse;

        }

        public AddressVelocityResponse AddressVelocity(IEnumerable<Address> addresses, UserIdentifier userIdentifier)
        {
            var requestId = OptionsContext.Current.GetGuid("requestId", new Guid());
            var programCode = OptionsContext.Current.GetString("programCode");

            var address = addresses?.FirstOrDefault(a =>
                 string.Compare(a.Type, AddressType.Home.ToString(), StringComparison.InvariantCultureIgnoreCase) > -1);


            var request = new AddressVelocityRequest
            {
                ExternalIdentifierType = "ConsumerProfileIdentifier",
                ExternalIdentifier = userIdentifier.ToString(),
                Address = new global::RequestHandler.Core.Domain.Services.Risk.Data.Address
                {
                    AddressLine1 = address?.AddressLine1,
                    AddressLine2 = address?.AddressLine2,
                    City = address?.City,
                    State = address?.State,
                    ZipCode = address?.ZipCode,
                    AddressType = address?.Type,
                },
                RequestHeader = new Domain.Services.Risk.Messages.Request.RequestHeader
                {
                    RequestId = requestId
                },
            };

            var uri = string.Format(AddressVelocityUrl, programCode);
            AddressVelocityResponse addressVelocityResponse = null;
            try
            {
                addressVelocityResponse = _serviceInvokerProvider.GetWebResponse<AddressVelocityRequest, AddressVelocityResponse>
                   (_gssFraudUrl + uri, "POST", request);
            }
            catch (Exception e)
            {
                _logger.Warn(e, $"Exception calling GssFraudEventApi AddressVelocity");
            }

            if (addressVelocityResponse == null)
            {
                _logger.Info($"GssFraudEventApi AddressVelocity call failed, requestId: " + requestId);
            }
            else
            {
                _logger.Info(
                    $"GssFraudEventApi AddressVelocity call succeeded Request:{MaskEngine.MaskMessage(JsonConvert.SerializeObject(request))},Response:{MaskEngine.MaskMessage(JsonConvert.SerializeObject(addressVelocityResponse))}");
            }

            return addressVelocityResponse;
        }

        public AddressVelocityResponse UpdateAddressVelocity(long consumerProfileHistoryKey, long fraudEventRequestKey, bool isAddressUpdateSuccess)
        {
            var requestId = OptionsContext.Current.GetGuid("requestId", new Guid());

            var request = new UpdateAddressVelocityRequest
            {
                ChangeAddressKey = consumerProfileHistoryKey,
                IsAddressUpdateSuccess = isAddressUpdateSuccess,
                FraudEventRequestKey = fraudEventRequestKey,
                RequestHeader = new RequestHeader
                {
                    RequestId = requestId
                }
            };

            AddressVelocityResponse addressVelocityResponse = null;
            try
            {
                addressVelocityResponse = _serviceInvokerProvider.GetWebResponse<UpdateAddressVelocityRequest, AddressVelocityResponse>
                   (_gssFraudUrl + UpdateAddressVelocityUrl, "POST", request);
            }
            catch (Exception e)
            {
                _logger.Warn(e, $"Exception calling GssFraudEventApi UpdateAddressVelocity");
            }

            if (addressVelocityResponse == null)
            {
                _logger.Info($"GssFraudEventApi UpdateAddressVelocity call failed, requestId: " + requestId);
            }
            else
            {
                _logger.Info(
                    $"GssFraudEventApi UpdateAddressVelocity call succeeded Request:{MaskEngine.MaskMessage(JsonConvert.SerializeObject(request))},Response:{MaskEngine.MaskMessage(JsonConvert.SerializeObject(addressVelocityResponse))}");
            }

            return addressVelocityResponse;
        }

        public GetDepositorNameResponse GetDirectDepositor(AccountIdentifier accountIdentifier)
        {
            var requestId = OptionsContext.Current.GetGuid("requestId", new Guid());

            var request = new GetDepositorNameRequest
            {
                RequestHeader = new RequestHeader
                {
                    RequestId = requestId
                }
            };

            var uri = string.Format(GetDepositorNameUrl, accountIdentifier);
            GetDepositorNameResponse response = null;
            try
            {
                response = _serviceInvokerProvider.GetWebResponse<GetDepositorNameResponse>
                    (_gssFraudUrl + uri, "GET", null);
            }
            catch (Exception e)
            {
                _logger.Warn(e, $"Exception calling GssFraudEventApi GetDepositorName");
            }

            if (response == null || string.IsNullOrEmpty(response.DirectDepositReview?.DDCustomerName))
            {
                _logger.Info($"GssFraudEventApi GetDepositorName call failed, requestId: " + requestId);
            }
            else
            {
                _logger.Info(
                    $"GssFraudEventApi GetDepositorName call succeeded Request:{MaskEngine.MaskMessage(JsonConvert.SerializeObject(request))},Response:{MaskEngine.MaskMessage(JsonConvert.SerializeObject(response))}");
            }

            response = ParseDdCustomerName(response);
            return response;
        }

        private static GetDepositorNameResponse ParseDdCustomerName(GetDepositorNameResponse response)
        {
            var firstName = "";
            var lastName = "";

            if (response == null || response.DirectDepositReview == null || string.IsNullOrEmpty(response?.DirectDepositReview?.DDCustomerName))
            {
                return response;
            }

            var ddCustomerName = response?.DirectDepositReview?.DDCustomerName;

            if (ddCustomerName.Contains(","))
            {
                lastName = ddCustomerName.Split(',')[0];
                firstName = ddCustomerName.Split(',')[1].Trim();
            }
            else if (ddCustomerName.Contains(" "))
            {
                firstName = ddCustomerName.Split(' ')[0];
                lastName = ddCustomerName.Split(' ')[1];
            }
            else
            {
                firstName = ddCustomerName;
                lastName = ddCustomerName;
            }

            response.DirectDepositReview.FirstName = firstName;
            response.DirectDepositReview.LastName = lastName;
            return response;
        }

        private List<PhoneObj> GetSearchFraudIdentityPhoneList(IEnumerable<PhoneNumber> phones)
        {
            var phoneList = new List<PhoneObj>();
            foreach (var phone in phones)
            {
                var phoneObj = new PhoneObj
                {
                    PhoneNumber = phone.Number,
                    PhoneType = phone.Type.ToEnumMemberAttrValue()
                };

                phoneList.Add(phoneObj);
            }

            return phoneList.Count > 0 ? phoneList : null;
        }
    }

}

