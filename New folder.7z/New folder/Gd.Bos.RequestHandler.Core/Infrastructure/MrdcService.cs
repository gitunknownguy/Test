﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.RequestHandler.Core.Domain.Services.Mrdc;
using Gd.Bos.RequestHandler.Core.Domain.Services.MrdcPartial;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using RequestHandler.Core.Utils;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class MrdcService : IMrdcService
    {
        private readonly IBaasConfiguration _baasConfiguration;

        public MrdcService(IServiceInvokeProvider serviceInvokeProvider, IBaasConfiguration baasConfiguration, IHttpClientServiceInvokeProvider httpClientInvokeProvider)
        {
            _serviceInvokeProvider = serviceInvokeProvider;
            _baasConfiguration = baasConfiguration;
            _httpClientInvokeProvider = httpClientInvokeProvider;
            _mrdcBaseUrl = Configuration.Configuration.Current.MrdcBaseUrl;
        }

        public MrdcEnrollmentResponse MrdcEnrollment(string programCode, string requestId, MrdcEnrollmentRequest request)
        {
            var url = _mrdcBaseUrl + "/" + programCode + _mrdcEnrollmentUrl;
            Dictionary<string, string> options = new Dictionary<string, string>();
            options.Add("X-GD-GSS-MRDC-CorrelationId", requestId);

            var response = _serviceInvokeProvider.GetResponse<MrdcEnrollmentRequest, MrdcEnrollmentResponse>(
                url, "POST", request, options);

            if (response == null)
                throw new Exception($"Mrdc did not return a recognizable response for Mrdc Enrollment.");

            return response;
        }
        public MrdcEnrollmentResponse MrdcUpdateEnrollment(string programCode, string requestId, MrdcEnrollmentRequest request)
        {
            var url = _mrdcBaseUrl + "/" + programCode + _mrdcUpdateEnrollmentUrl;
            Dictionary<string, string> options = new Dictionary<string, string>();
            options.Add("X-GD-GSS-MRDC-CorrelationId", requestId);

            var response = _serviceInvokeProvider.GetResponse<MrdcEnrollmentRequest, MrdcEnrollmentResponse>(
                url, "PUT", request, options);

            if (response == null)
                throw new Exception($"Mrdc did not return a recognizable response for Mrdc Enrollment.");

            return response;
        }
        public MrdcDepositCheckResponse MrdcCheckDeposit(string programCode, RequestHeader requestHeaders, MrdcDepositCheckRequest request)
        {
            var url = _mrdcBaseUrl + "/" + programCode + _mrdcCheckDepositUrl;
            Dictionary<string, string> options = new Dictionary<string, string>();

            if (requestHeaders?.Options?.Count > 0)
            {
                foreach (var headersOption in requestHeaders.Options)
                {
                    switch (headersOption.Key)
                    {
                        case "X-GD-EXT-MRDC-ByPassRisk" when !string.IsNullOrEmpty(headersOption.Value):
                            options.Add("X-GD-EXT-MRDC-ByPassRisk", headersOption.Value);
                            break;
                        case "X-GD-EXT-MRDC-ByPassRiskInsta" when !string.IsNullOrEmpty(headersOption.Value):
                            options.Add("X-GD-EXT-MRDC-ByPassRiskInsta", headersOption.Value);
                            break;
                    }
                }
            }
            options.Add("X-GD-GSS-MRDC-CorrelationId", requestHeaders.RequestId.ToString());
            var response = _serviceInvokeProvider.GetResponse<MrdcDepositCheckRequest, MrdcDepositCheckResponse>(
                url, "POST", request, options, null);

            if (response == null)
                throw new Exception($"Mrdc did not return a recognizable response for Mrdc Check Deposit.");

            return response;
        }

        public MrdcPartialDepositCheckResponse MrdcCheckDepositX9(string programCode, RequestHeader requestHeaders, MrdcPartialDepositCheckRequest request)
        {
            var url = _mrdcBaseUrl + string.Format(_mrdcFulfillment, programCode);
            Dictionary<string, string> options = new Dictionary<string, string>();

            string bypassRiskMrdcX9 = _baasConfiguration.GetValueByPath($"/programs/{programCode}/BypassRisk/MrdcX9");

            if (!options.ContainsKey("X-GD-GSS-MRDC-CorrelationId"))
            {
                options.Add("X-GD-GSS-MRDC-CorrelationId", requestHeaders.RequestId.ToString());
            }

            if (!options.ContainsKey("X-GD-EXT-MRDC-ByPassRisk"))
            {
                options.Add("X-GD-EXT-MRDC-ByPassRisk", bypassRiskMrdcX9);
            }

            var response = _serviceInvokeProvider.GetResponse<MrdcPartialDepositCheckRequest, MrdcPartialDepositCheckResponse>(url, "POST", request, options, null);

            if (response == null)
                throw new Exception($"Mrdc did not return a recognizable response for Mrdc Check Deposit.");

            return response;
        }

        public MrdcUpdateCheckResponse MrdcUpdateCheckDeposit(string programCode, string requestId, string transactionReferenceId, MrdcUpdateCheckRequest request)
        {
            Dictionary<string, string> options = new Dictionary<string, string>();
            options.Add("X-GD-GSS-MRDC-CorrelationId", requestId);
            //TransactionReferenceId is passed as clientCheckDepositReferenceId in MRDC system 
            var url = _mrdcBaseUrl + "/" + programCode + _mrdcUpdateCheckUrl + "/" + transactionReferenceId;
            var response = _serviceInvokeProvider.GetResponse<MrdcUpdateCheckRequest, MrdcUpdateCheckResponse>(
                url, "PUT", request, options);
            if (response == null)
                throw new Exception($"Mrdc did not return a recognizable response for Mrdc Update Check.");
            return response;
        }

        public MrdcUpdateFundsAvailableDateResponse MrdcUpdateFundsAvailableDate(string requestId, MrdcUpdateFundsAvailableDateRequest request)
        {
            Dictionary<string, string> options = new Dictionary<string, string>();
            options.Add("X-GD-GSS-MRDC-CorrelationId", requestId);
            //TransactionReferenceId is passed as clientCheckDepositReferenceId in MRDC system 
            var url = _mrdcBaseUrl + "/" + request.PartnerProgramReferenceId + _mrdcUpdateFundsAvailableDateUrl + request.ClientCheckDepositReferenceId + "?availabilityDate=" + request.AvailabilityDate;
            var response = _serviceInvokeProvider.GetResponse<MrdcUpdateFundsAvailableDateRequest, MrdcUpdateFundsAvailableDateResponse>(
                url, "PUT", request, options);
            if (response == null)
                throw new Exception($"Mrdc did not return a recognizable response for Mrdc Update Funds Available Date.");
            return response;
        }

        public MrdcGetTransferResponse GetMrdcTransfer(string programCode, string requestId, string transactionReferenceId)
        {
            Dictionary<string, string> options = new Dictionary<string, string>();
            var url = _mrdcBaseUrl + "/" + programCode + _mrdcGetTransferUrl + transactionReferenceId;
            options.Add("X-GD-GSS-MRDC-CorrelationId", requestId);
            var response = _serviceInvokeProvider.GetResponse<MrdcGetTransferResponse>(
                url, "GET", null, options);

            if (!string.IsNullOrEmpty(response.ResponseCode.ToString()))
            {
                if (response.ResponseCode != 0)
                {
                    throw new MrdcException(response.ResponseCode, response.ResponseDetailCode, response.ResponseDetailMessage);
                }
            }

            return response;

        }

        public FundFulfillmentMrdcGetTransferResponse GetFundFulfillmentMrdcTransfer(string programCode, string requestId, string transactionReferenceId)
        {
            Dictionary<string, string> options = new Dictionary<string, string>();
            var url = _mrdcBaseUrl + "/" + programCode + _mrdcFulfillmentGetTransferUrl + transactionReferenceId;
            options.Add("X-GD-GSS-MRDC-CorrelationId", requestId);
            var response = _serviceInvokeProvider.GetResponse<FundFulfillmentMrdcGetTransferResponse>(
                url, "GET", null, options);

            if (!string.IsNullOrEmpty(response.ResponseCode.ToString()))
            {
                if (response.ResponseCode != 0)
                {
                    throw new MrdcException(response.ResponseCode, response.ResponseDetailCode, response.ResponseDetailMessage);
                }
            }

            return response;
        }

        public FundFulfillmentMrdcGetTransferResponse GetFundFulfillmentMrdcTransferAsync(string programCode, string requestId, string transactionReferenceId)
        {
            Dictionary<string, string> options = new Dictionary<string, string>();
            var url = "/" + programCode + _mrdcFulfillmentGetTransferUrl + transactionReferenceId;
            options.Add("X-GD-GSS-MRDC-CorrelationId", requestId);
            var response = _httpClientInvokeProvider.GetWebResponseAsync<FundFulfillmentMrdcGetTransferResponse>(
                url, HttpMethod.Get, null, options).ConfigureAwait(false).GetAwaiter().GetResult();

            if (!string.IsNullOrEmpty(response.ResponseCode.ToString()))
            {
                if (response.ResponseCode != 0)
                {
                    throw new MrdcException(response.ResponseCode, response.ResponseDetailCode, response.ResponseDetailMessage);
                }
            }
            return response;
        }

        public MrdcGetCheckImagesResponse GetCheckImages(string programCode, string requestId, string transactionReferenceId)
        {
            Dictionary<string, string> options = new Dictionary<string, string>();
            options.Add("X-GD-GSS-MRDC-CorrelationId", requestId);
            var url = _mrdcBaseUrl + "/" + programCode + _mrdcGetCheckImagesUrl + "/" + transactionReferenceId;
            var response = _serviceInvokeProvider.GetResponse<MrdcGetCheckImagesResponse>(
                url, "GET", null, options);

            if (response == null)
                throw new Exception($"Mrdc did not return a recognizable response for Mrdc Check image.");

            return response;
        }

        public MrdcGetCheckImagesResponse GetColorCheckImages(string programCode, string requestId, string transactionReferenceId)
        {
            Dictionary<string, string> options = new Dictionary<string, string>();
            options.Add("X-GD-GSS-MRDC-CorrelationId", requestId);
            var url = _mrdcBaseUrl + "/" + programCode + _mrdcGetColorCheckImagesUrl + "/" + transactionReferenceId;
            var response = _serviceInvokeProvider.GetResponse<MrdcGetCheckImagesResponse>(
            url, "GET", null, options);

            if (response == null)
                throw new Exception($"Mrdc did not return a recognizable response for Mrdc Check image.");

            return response;
        }

        public MrdcGetAllTransferResponse GetMrdcAllTransfers(string requestId, MrdcGetAllTransferRequest request)
        {
            Dictionary<string, string> options = new Dictionary<string, string>();
            options.Add("X-GD-GSS-MRDC-CorrelationId", requestId);
            StringBuilder queryString = new StringBuilder();
            queryString.AppendFormat("/{0}{1}{2}{3}?&StartDate={4}&EndDate={5}&pageNumber={6}&pageSize={7}",
                request.ProgramCode,
                _mrdcGetAllTransactionsUrl,
                request.CustomerReferenceId,
                _mrdcGetAllTransactions2Url,
                request.StartDate,
                request.EndDate,
                request.Offset,
                request.Limit
                );
            var response = _serviceInvokeProvider.GetResponse<MrdcGetAllTransferResponse>(_mrdcBaseUrl + queryString.ToString(), "GET", null, options);

            if (response == null)
                throw new Exception($"Mrdc did not return a recognizable response for Get all Mrdc Transfers.");

            return response;
        }

        public FundFulfillmentMrdcGetAllTransferResponse GetFundFulfillmentMrdcAllTransfers(string requestId, MrdcGetAllTransferRequest request)
        {
            Dictionary<string, string> options = new Dictionary<string, string>();
            options.Add("X-GD-GSS-MRDC-CorrelationId", requestId);
            StringBuilder queryString = new StringBuilder();
            queryString.AppendFormat("/{0}{1}{2}{3}?&StartDate={4}&EndDate={5}&pageNumber={6}&pageSize={7}",
                request.ProgramCode,
                _mrdcGetAllTransactionsUrl,
                request.CustomerReferenceId,
                _mrdcFulfillmentGetAllTransactionsUrl,
                request.StartDate,
                request.EndDate,
                request.Offset,
                request.Limit
            );
            var response = _serviceInvokeProvider.GetResponse<FundFulfillmentMrdcGetAllTransferResponse>(_mrdcBaseUrl + queryString.ToString(), "GET", null, options);

            if (response == null)
                throw new Exception($"Mrdc did not return a recognizable response for Get all Fund Fulfillment Mrdc Transfers.");

            return response;
        }

        public MrdcGetAuthCustomerSSOTokenResponse GetAuthCustomerSSOToken(string requestId, string programCode, MrdcGetAuthCustomerSSOTokenRequest request)
        {
            if (string.IsNullOrEmpty(programCode))
            {
                throw new Exception($"ProgramCode can't be null for request {requestId} when calling GSS service.");
            }

            Dictionary<string, string> options = new Dictionary<string, string>();
            options.Add("X-GD-GSS-MRDC-CorrelationId", requestId);
            var url = _mrdcBaseUrl + "/" + programCode + _mrdcGetAuthCustomerSSOTokenUrl;
            var response = _serviceInvokeProvider.GetResponse<MrdcGetAuthCustomerSSOTokenRequest, MrdcGetAuthCustomerSSOTokenResponse>(
                url, "POST", request, options, null);

            if (response == null)
                throw new Exception($"Mrdc did not return a recognizable response for Get Auth Customer SSO Token.");

            return response;
        }

        public MrdcGetCustomerEnrollmentResponse GetAuthCustomerEnrollment(string requestId, string programCode, MrdcGetCustomerEnrollmentRequest request)
        {
            if (string.IsNullOrEmpty(programCode))
                throw new Exception($"ProgramCode can't be null for request {requestId} when calling GSS service.");

            Dictionary<string, string> options = new Dictionary<string, string>();
            options.Add("X-GD-GSS-MRDC-CorrelationId", requestId);
            var url = _mrdcBaseUrl + "/" + programCode + _mrdcGetAuthCustomerEnrollmentUrl;
            var response = _serviceInvokeProvider.GetResponse<MrdcGetCustomerEnrollmentRequest, MrdcGetCustomerEnrollmentResponse>(
                url, "POST", request, options, null);

            if (response == null)
                throw new Exception($"Mrdc did not return a recognizable response for GetAuthCustomerEnrollment.");

            return response;
        }

        public MrdcX9DepositCheckResponse GetMrdcX9TransferByCheckStatus(string programCode, string requestId, string customerReferenceId, DateTime startDate, DateTime endDate, string checkDepositStatusKeys)
        {
            Dictionary<string, string> options = new Dictionary<string, string>();
            var url = string.Format(_mrdcBaseUrl + _mrdcX9TransferByCheckStatus, programCode, customerReferenceId, startDate, endDate, checkDepositStatusKeys);
            options.Add("X-GD-GSS-MRDC-CorrelationId", requestId);
            var response = _serviceInvokeProvider.GetResponse<MrdcX9DepositCheckResponse>(url, "GET", null, options);

            if (!string.IsNullOrEmpty(response.ResponseCode.ToString()))
            {
                //933: not record found
                //0: success
                if (response.ResponseCode != 0 && response.ResponseCode != 933)
                {
                    throw new MrdcException(response.ResponseCode, response.ResponseDetailCode, response.ResponseDetailMessage);
                }
            }

            return response;

        }

        public GetFulfillmentCheckDepositHistoryByAccountRoutingCheckResponse DuplicateVerification(string requestId, string programCode, string accountNumber, string routingNumber, string checkNumber, string auxOnus, int checkType)
        {
            Dictionary<string, string> options = new Dictionary<string, string>();
            options.Add("X-GD-GSS-MRDC-CorrelationId", requestId);

            var url = string.Format(_mrdcBaseUrl + _mrdcFulfillmentDuplicateVerificationUrl, programCode, accountNumber, routingNumber, checkType, checkNumber, auxOnus);
            var response = _serviceInvokeProvider.GetResponse<GetFulfillmentCheckDepositHistoryByAccountRoutingCheckResponse>(url, "GET", null, options);

            if (response == null)
                throw new Exception($"Mrdc did not return a recognizable response for Duplicate Verification Mrdc Transfers.");

            //933: not record found
            //0: success
            if (response.ResponseCode != 0 && response.ResponseCode != 933)
            {
                throw new MrdcException(response.ResponseCode, response.ResponseDetailCode, response.ResponseDetailMessage);
            }

            return response;
        }

        private readonly IServiceInvokeProvider _serviceInvokeProvider;
        private readonly IHttpClientServiceInvokeProvider _httpClientInvokeProvider;

        private readonly string _mrdcBaseUrl;
        private const string _mrdcEnrollmentUrl = "/enrollment";
        private const string _mrdcUpdateEnrollmentUrl = "/updateEnrollment";
        private const string _mrdcCheckDepositUrl = "/transaction";
        private const string _mrdcGetTransferUrl = "/transaction/clientCheckDepositReference/";
        private const string _mrdcFulfillmentGetTransferUrl = "/transaction/Fulfillment/";
        private const string _mrdcUpdateCheckUrl = "/transaction/status/clientCheckDepositReference";
        private const string _mrdcUpdateFundsAvailableDateUrl = "/transaction/FundsAvailableDate/clientCheckDepositReference/";
        private const string _mrdcGetAllTransactionsUrl = "/customer/";
        private const string _mrdcGetAllTransactions2Url = "/transactions";
        private const string _mrdcFulfillmentGetAllTransactionsUrl = "/transactions/Fulfillment";
        private const string _mrdcGetCheckImagesUrl = "/transaction/image/clientCheckDepositReference";
        private const string _mrdcGetColorCheckImagesUrl = "/transaction/originalImage/clientCheckDepositReference";
        private const string _mrdcGetAuthCustomerSSOTokenUrl = "/SignIn";
        private const string _mrdcGetAuthCustomerEnrollmentUrl = "/GetProviderEnrollment";
        private const string _mrdcFulfillment = "/{0}/fundfulfillment/mrdc";
        private const string _mrdcX9TransferByCheckStatus = "/{0}/customer/{1}/transactions/byCheckDepositStatus?startDate={2}&endDate={3}&checkDepositStatusKeys={4}";
        private const string _mrdcFulfillmentDuplicateVerificationUrl = "/{0}/transaction/fundfulfillment/{1}/{2}/{3}?checkNumber={4}&auxonus={5}";
    }
}
