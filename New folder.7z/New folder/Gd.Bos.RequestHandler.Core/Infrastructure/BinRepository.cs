using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using Gd.Bos.RequestHandler.Core.Domain;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.RequestHandler.Core.Utils;
using Gd.Bos.Shared.Common.Core.Data;

namespace RequestHandler.Core.Infrastructure
{
    public class BinRepository : IBinRepository
    {
        private readonly ICache _cache;
        private readonly IDataAccess _dataAccess;
        private const string CacheKeyBinConversions = "BinConversions";
        private const string CacheKeyBinPrograms = "CacheKeyBinPrograms";
        private readonly IRequestHandlerSettings _configuration;

        public BinRepository(ICache cache, IDataAccess dataAccess, IRequestHandlerSettings configuration)
        {
            _cache = cache;
            _dataAccess = dataAccess;
            _configuration = configuration;
        }

        public List<BinConversionSchedule> GetBinConversions()
        {
            var binConversions = _cache.Get<List<BinConversionSchedule>>(CacheKeyBinConversions);
            if (binConversions != null) return binConversions;

            binConversions = GetBinConversionsFromDb();
            _cache.Add(CacheKeyBinConversions, binConversions, _configuration.BinConversionCacheExpirationInMinutes);

            return binConversions;
        }

        public List<string> GetProductBinsByProgramCode(string programCode)
        {
            var bins = _cache.Get<List<(string ProgramCode, string Bin)>>(CacheKeyBinPrograms);
            if (bins != null)
            {
                return bins.Where(n => n.ProgramCode.Equals(programCode, StringComparison.CurrentCultureIgnoreCase))
                    .Select(n => n.Bin)
                    .ToList();
            }

            bins = GetBinFromDb();
            _cache.Add(CacheKeyBinPrograms, bins, _configuration.BinProgramsExpirationInMinutes);

            return bins.Where(n => n.ProgramCode.Equals(programCode, StringComparison.CurrentCultureIgnoreCase))
                .Select(n => n.Bin)
                .ToList();
        }

        private List<BinConversionSchedule> GetBinConversionsFromDb()
        {
            var list = new List<BinConversionSchedule>();
            using (var reader = _dataAccess.ExecuteReader("dbo.GetAllBinConversion", _dataAccess.CreateConnection(), null))
            {
                while (reader.Read())
                {
                    list.Add(new BinConversionSchedule()
                    {
                        BinConversionKey = reader.GetInt32(reader.GetOrdinal(nameof(BinConversionSchedule.BinConversionKey))),
                        BIN = reader[nameof(BinConversionSchedule.BIN)].ToString()?.Trim(),
                        Wave = reader[nameof(BinConversionSchedule.Wave)].ToString(),
                        InitialBusinessDate = reader.GetDateTime(reader.GetOrdinal(nameof(BinConversionSchedule.InitialBusinessDate))),
                        SyncStartDateTime = reader.GetDateTime(reader.GetOrdinal(nameof(BinConversionSchedule.SyncStartDateTime))),
                        ConversionWindowStartTime = reader[nameof(BinConversionSchedule.ConversionWindowStartTime)] == DBNull.Value
                            ? (DateTime?)null
                            : reader.GetDateTime(reader.GetOrdinal(nameof(BinConversionSchedule.ConversionWindowStartTime))),
                        CutoverDateTime = reader.GetDateTime(reader.GetOrdinal(nameof(BinConversionSchedule.CutoverDateTime))),
                        IsACIShadowEnvironment = reader[nameof(BinConversionSchedule.IsACIShadowEnvironment)] == DBNull.Value
                            ? (bool?)null
                            : reader.GetBoolean(reader.GetOrdinal(nameof(BinConversionSchedule.IsACIShadowEnvironment))),
                    });
                }
            }


            return list;
        }

        private List<(string ProgramCode, string Bin)> GetBinFromDb()
        {
            var list = new List<(string ProgramCode, string Bin)>();

            using (var reader = _dataAccess.ExecuteReader("dbo.GetAllProduct", _dataAccess.CreateConnection(), null))
            {
                while (reader.Read())
                {

                    var programCode = reader.GetString(reader.GetOrdinal("ProgramCode"));
                    var bin = reader["BIN"] == DBNull.Value
                        ? ""
                        : reader.GetString(reader.GetOrdinal("BIN")).Trim();

                    list.Add((programCode, bin));
                }
            }


            return list;
        }
    }
}

