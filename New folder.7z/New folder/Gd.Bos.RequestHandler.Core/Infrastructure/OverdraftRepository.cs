﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Enum;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Data;
using Microsoft.Data.SqlClient;
using NLog;
using RequestHandler.Core.Domain.Model.Brand;
using RequestHandler.Core.Domain.Model.OverDraft;

namespace RequestHandler.Core.Infrastructure
{
    public class OverdraftRepository : IOverdraftRepository
    {
        private readonly IDataAccess _dataAccess;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();

        public OverdraftRepository(IDataAccess dataAccess)
        {
            _dataAccess = dataAccess;
        }
        public GetOverdraftTransactionsResponse GetOverdraftTransactions(string accountIdentifier, string startDate, string endDate)
        {
            var response = new GetOverdraftTransactionsResponse();
            var transactions = new List<OverdraftTransaction>();
            var parameters = new[]
            {
                new SqlParameter() {ParameterName = "AccountIdentifier", Value = new Guid(accountIdentifier)},
                new SqlParameter() {ParameterName = "startDate", Value = startDate},
                new SqlParameter() {ParameterName = "endDate", Value = endDate}
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetNegativeAccountBalanceTransactionByAccountIDDate]",
                       _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    var transaction = new OverdraftTransaction()
                    {
                        TransactionIdentifier = reader["TransactionIdentifier"] == DBNull.Value
                            ? ""
                            : reader["TransactionIdentifier"].ToString(),
                        TransactionAmount =
                            reader["TransactionAmount"] == DBNull.Value
                                ? 0.0M
                                : (decimal)reader["TransactionAmount"],
                        TransactionDate = reader["ProcessorTransactionDate"] == DBNull.Value
                            ? null
                            : TimeZoneInfo.ConvertTime(
                                  DateTime.SpecifyKind((DateTime)reader["ProcessorTransactionDate"], DateTimeKind.Unspecified),
                                  TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time"),
                                  TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"))
                    };

                    transactions.Add(transaction);
                }

                if (reader.NextResult())
                {
                    while (reader.Read())
                    {
                        var preAuthTransaction = new OverdraftTransaction()
                        {
                            TransactionIdentifier = reader["TransactionIdentifier"] == DBNull.Value
                                ? ""
                                : reader["TransactionIdentifier"].ToString(),
                            TransactionAmount =
                                reader["TransactionAmount"] == DBNull.Value
                                    ? 0.0M
                                    : (decimal)reader["TransactionAmount"],
                            TransactionDate = reader["ProcessorTransactionDate"] == DBNull.Value
                                ? null
                                : TimeZoneInfo.ConvertTime(
                                  DateTime.SpecifyKind((DateTime)reader["ProcessorTransactionDate"], DateTimeKind.Unspecified),
                                  TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time"),
                                  TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"))
                        };

                        transactions.Add(preAuthTransaction);
                    }
                }

                if (reader.NextResult())
                {
                    while (reader.Read())
                    {
                        var feeCharge = new OverdraftTransaction()
                        {
                            TransactionIdentifier = reader["TransactionReferenceID"] == DBNull.Value
                                ? ""
                                : reader["TransactionReferenceID"].ToString(),
                            TransactionAmount =
                                reader["Amount"] == DBNull.Value
                                    ? 0.0M
                                    : (decimal)reader["Amount"],
                            TransactionDate = reader["TransactionDate"] == DBNull.Value
                                ? null
                                : (DateTime)reader["TransactionDate"]
                        };

                        transactions.Add(feeCharge);
                    }
                }
            }

            response.AccountIdentifier = accountIdentifier;
            response.OverdraftTransactions = transactions;
            response.LastTransactionDate = GetLastTransactionDate(transactions);
            response.TotalAllowedTransactions = "";

            return response;
        }

        public GetOverdraftTransactionsResponse GetOverdraftFeeAuthTransactions(string accountIdentifier, string startDate,
            string endDate)
        {
            var response = new GetOverdraftTransactionsResponse();
            try
            {
                var transactions = new List<OverdraftTransaction>();
                var parameters = new[]
                {
                    new SqlParameter() {ParameterName = "AccountIdentifier", Value = new Guid(accountIdentifier)},
                    new SqlParameter() {ParameterName = "startDate", Value = startDate},
                    new SqlParameter() {ParameterName = "endDate", Value = endDate}
                };

                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetOverdraftFeeAuthTransactionByAccountIDDate]",
                           _dataAccess.CreateConnection(), parameters))
                {
                    while (reader.Read())
                    {
                        var transaction = new OverdraftTransaction()
                        {
                            EstablishmentCategory =
                                reader["MerchantCategory"] == DBNull.Value ? "" : reader["MerchantCategory"].ToString(),
                            EstablishmentName =
                                reader["CardAcceptorMerchantName"] == DBNull.Value
                                    ? ""
                                    : reader["CardAcceptorMerchantName"].ToString(),
                            GracePeriodDate =
                                reader["GracePeriodDate"] == DBNull.Value
                                    ? null
                                    : (DateTime)reader["GracePeriodDate"],
                            IsNegativeOver45Days = true,
                            NextOdpPeriod = null,
                            OverdraftFee = reader["FeeAmount"] == DBNull.Value
                                ? 0.0M
                                : (decimal)reader["FeeAmount"],
                            TransactionAmount =
                                reader["TransactionAmount"] == DBNull.Value
                                    ? 0.0M
                                    : (decimal)reader["TransactionAmount"],
                            TransactionDate = reader["CreateDate"] == DBNull.Value
                                ? null
                                : (DateTime)reader["CreateDate"],
                            MerchantCategoryCode = reader["MerchantCategoryCode"] == DBNull.Value
                                ? null
                                : reader["MerchantCategoryCode"].ToString(),
                            FeatureKey = reader["FeatureKey"] == DBNull.Value
                                ? 0
                                : (int)(short)reader["FeatureKey"],
                            IsReversal = reader["IsReversal"] == DBNull.Value
                                ? false
                                : (int)reader["IsReversal"] == 1,
                            TransactionIdentifier = reader["TransactionIdentifier"] == DBNull.Value
                                ? ""
                                : reader["TransactionIdentifier"].ToString()
                        };

                        transactions.Add(transaction);
                    }
                }

                response.AccountIdentifier = accountIdentifier;
                response.OverdraftTransactions = transactions.GroupBy(x => new { x.TransactionIdentifier })
                        .Select(g => g.First())
                        .ToList();
                response.LastTransactionDate = GetLastTransactionDate(transactions);
                response.TotalAllowedTransactions = "";
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"Error occurred in {nameof(GetOverdraftFeeAuthTransactions)}: {ex.Message}");
                response = new GetOverdraftTransactionsResponse
                {
                    AccountIdentifier = accountIdentifier,
                    OverdraftTransactions = new List<OverdraftTransaction>(),
                    LastTransactionDate = null,
                    TotalAllowedTransactions = ""
                };
            }
            return response;
        }

        public List<GetAccountReinstatementInfoResponse> GetAccountSubscriptionReinstatementInfo(long accountKey, DateTime startDate, DateTime endDate,
            int reinstatementReasonType)
        {
            List<GetAccountReinstatementInfoResponse> accountReinstatementInfos = new List<GetAccountReinstatementInfoResponse>();

                _logger.Info($"Fetching account subscription reinstatement info for AccountKey: {accountKey}, StartDate: {startDate}, EndDate: {endDate}, ReinstatementReasonType: {reinstatementReasonType}");

                var parameters = new[]
                {
                    new SqlParameter() {ParameterName = "pAccountKey", Value = accountKey},
                    new SqlParameter() {ParameterName = "pStartDate", Value = startDate},
                    new SqlParameter() {ParameterName = "pEndDate", Value = endDate},
                    new SqlParameter() {ParameterName = "pAccountSubscriptionReinstatementTypeKey", Value = reinstatementReasonType}
                };

                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountSubscriptionReinstatementByAccountKey]",
                           _dataAccess.CreateConnection(), parameters))
                {
                    while (reader.Read())
                    {
                        var reinstatementReasonKey = reader["AccountSubscriptionReinstatementReasonKey"] == DBNull.Value
                            ? ""
                            : reader["AccountSubscriptionReinstatementReasonKey"].ToString();

                        var accountReinstatementInfo = new GetAccountReinstatementInfoResponse()
                        {
                            AccountKey = accountKey,
                            AccountSubscriptionReinstatementKey = reader["AccountSubscriptionReinstatementKey"] == DBNull.Value
                                ? 0
                                : (long)reader["AccountSubscriptionReinstatementKey"],
                            AccountSubscriptionKey = reader["AccountSubscriptionKey"] == DBNull.Value
                                ? 0
                                : (long)reader["AccountSubscriptionKey"],
                            ReinstatementDate = reader["ReinstatementDate"] == DBNull.Value
                                ? DateTime.MinValue
                                : (DateTime)reader["ReinstatementDate"],
                            AccountSubscriptionReinstatementReasonKey = (ReinstateReason)Enum.Parse(typeof(ReinstateReason), reinstatementReasonKey ?? string.Empty)
                        };

                        accountReinstatementInfos.Add(accountReinstatementInfo);
                    }
                }

                return accountReinstatementInfos;

        }

        public BrandAgreementType GetOverdraftBrandAgreementTypeByIdentifier(string brandAgreementTypeIdentifier, string programCode)
        {
            BrandAgreementType brandAgreementType = null;

            var parameters = new[]
            {
                    new SqlParameter() {ParameterName = "BrandAgreementTypeIdentifier", Value = brandAgreementTypeIdentifier},
                    new SqlParameter() {ParameterName = "ProgramCode", Value = programCode},
            };
            try
            {
                using (var reader = _dataAccess.ExecuteReader(
                           "[dbo].[GetBrandAgreementTypeByIdentifier]",
                           _dataAccess.CreateConnection(), parameters))
                {
                    while (reader.Read())
                    {
                        brandAgreementType = new BrandAgreementType()
                        {
                            BrandAgreementTypeKey = reader["BrandAgreementTypeKey"] == DBNull.Value
                                ? 0
                                : (Int16)reader["BrandAgreementTypeKey"],
                            BrandAgreementTypeName = reader["BrandAgreementTypeName"] == DBNull.Value
                                ? ""
                                : reader["BrandAgreementTypeName"].ToString(),
                            Description = reader["Description"] == DBNull.Value
                                ? ""
                                : reader["Description"].ToString(),
                            BrandKey = reader["BrandKey"] == DBNull.Value
                                ? 0
                                : (int)reader["BrandKey"]
                        };
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"Error:{ex.Message}");
            }
            return brandAgreementType;
        }


        private DateTime? GetLastTransactionDate(List<OverdraftTransaction> transactions)
        {
            return transactions.Count == 0 ? null : transactions.MaxBy(t => t.TransactionDate).TransactionDate;
        }
    }
}
