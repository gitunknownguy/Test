﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.RequestHandler.Core.Domain;
using Gd.Bos.RequestHandler.Core.Domain.Services.Retail;
using NLog;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using RequestHandler.Core.Domain.Services.Retail;
using Newtonsoft.Json;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    /// <summary>
    /// RetailService Class
    /// </summary>
    /// <seealso cref="Gd.Bos.RequestHandler.Core.Domain.Services.Retail.IRetailService" />
    public class RetailService : IRetailService
    {
        private readonly IServiceInvokeProvider _serviceInvokerProvider;
        private readonly string _retailUrl;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();

        public RetailService(IServiceInvokeProvider serviceInvokeProvider, IRequestHandlerSettings settings)
        {
            _serviceInvokerProvider = serviceInvokeProvider;
            _retailUrl = settings.RetailBaseUrl;
        }

        /// <summary>
        /// Gets the retail partners for ECash.
        /// </summary>
        /// <param name="transactionTypes">The transaction types.</param>
        /// <param name="requestId"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public GetRetailPartnersResponse GetRetailPartners(string transactionTypes, string requestId)
        {
            var header = new Dictionary<string, string>
            {
                { "X-GD-RequestId", string.IsNullOrEmpty(requestId)? Guid.NewGuid().ToString() : requestId }
            };

            var response = _serviceInvokerProvider.GetResponse<GetRetailPartnersResponse>(GetPartnerRetailersUrl(transactionTypes), "GET", null, header);

            return response;
        }

        /// <summary>
        /// Gets the partner retailers URL.
        /// </summary>
        /// <param name="transactionTypes">The transaction types.</param>
        /// <returns></returns>
        private string GetPartnerRetailersUrl(string transactionTypes)
        {
            return _retailUrl + $"retailers?transaction_types={transactionTypes}";
        }

        public async Task<PreSaleCheckResponse> PreSaleCheckAsync(PreSaleCheckRequest request)
        {
            var response = await _serviceInvokerProvider.GetResponseAsync<PreSaleCheckRequest, PreSaleCheckResponse>(GetPreSaleCheckUrl(), "POST",
                request, null);

            return response;
        }

        public string GetPreSaleCheckUrl()
        {
            return _retailUrl + $"presalecheck";
        }
    }
}
