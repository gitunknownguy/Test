﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Reflection;
using System.Threading.Tasks;
using Gd.Bos.Fraud.Api.Common.Utility;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.RabbitMQ.Contract;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Newtonsoft.Json;
using NLog;
using Gd.Bos.RequestHandler.Core.Domain.Model.OverDraft;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class OverDraftNotificationService : IOverDraftNotificationService
    {
        private readonly IWriter<string> _queueWriter;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        private readonly IBaasConfiguration _baasConfiguration;
        public OverDraftNotificationService(IWriter<string> queueWriter, IBaasConfiguration baasConfiguration)
        {
            _queueWriter = queueWriter;
            _baasConfiguration = baasConfiguration;
        }

        public Task PublishNotification(OverDraftMessageRequest request)
        {
            if (string.IsNullOrEmpty(request.ProgramCode))
            {
                throw new ArgumentException("argument null or empty", nameof(request.ProgramCode));
            }

            if (_baasConfiguration.SendAccountUpdatedOverDraftNotification(request.ProgramCode))
            {
                var message = JsonConvert.SerializeObject(request,
                    new JsonSerializerSettings { DateFormatHandling = DateFormatHandling.IsoDateFormat, NullValueHandling = NullValueHandling.Ignore });

                lock (_queueWriter)
                {
                    var headers = new Dictionary<string, object>()
                {
                    {"AccountIdentifier", request.AccountIdentifier },
                    {"ProgramCode", request.ProgramCode },
                    {"EventType", request.EventType },
                    {"RequestId", request?.RequestHeader?.RequestId }
                };
                    _queueWriter.Write(message, string.Empty, headers);
                }

                LogPublishNotificationRequest(request?.RequestHeader?.RequestId, message);
            }

            return Task.CompletedTask;
        }

        private void LogPublishNotificationRequest(string requestId, string message)
        {
            _logger.Info($"Sending message with request id {requestId} to OverDraftEligibility queue: {Gd.Bos.Logging.Common.Managers.MaskEngine.MaskMessage(message)}");
        }
    }
}
