﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Gd.Bos.RequestHandler.Core.Domain.Model.OverDraft;
using Gd.Bos.RequestHandler.Core.Domain.Model.Transactions;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.Shared.Common.Core.Logic;
using Microsoft.Data.SqlClient;
using NLog;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class TransactionsRORepository : ITransactionsRORepository
    {

        private readonly IDataAccess _dataAccess;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();

        public TransactionsRORepository(string connectionString)
        {
            _dataAccess = new DataAccess(connectionString);
        }


        public GetOverdraftTransactionsResponse GetOverdraftFeeAuthTransactions(string accountIdentifier, string startDate,
            string endDate)
        {
            var response = new GetOverdraftTransactionsResponse();
            try
            {
                var transactions = new List<AuthorizeOverdraftTransaction>();
                var reversalTransactions = new List<AuthorizedTransaction>();

                var parameters = new[]
                {
                    new SqlParameter() {ParameterName = "AccountIdentifier", Value = new Guid(accountIdentifier)},
                    new SqlParameter() {ParameterName = "startDate", Value = startDate},
                    new SqlParameter() {ParameterName = "endDate", Value = endDate}
                };

                using (var reader = _dataAccess.ExecuteReader("[dbo].[GetOverdraftFeeAuthTransactionByAccountIDDate]",
                           _dataAccess.CreateConnection(), parameters))
                {
                    while (reader.Read())
                    {
                        var transaction = new AuthorizeOverdraftTransaction()
                        {
                            EstablishmentCategory =
                                reader["MerchantCategory"] == DBNull.Value ? "" : reader["MerchantCategory"].ToString(),
                            EstablishmentName =
                                reader["CardAcceptorMerchantName"] == DBNull.Value
                                    ? ""
                                    : reader["CardAcceptorMerchantName"].ToString(),
                            GracePeriodDate = reader["GracePeriodDate"] == DBNull.Value ? null : (DateTime?)reader["GracePeriodDate"],
                            IsNegativeOver45Days = true,
                            NextOdpPeriod = null,
                            OverdraftFee = reader["FeeAmount"] == DBNull.Value
                                ? 0.0M
                                : (decimal)reader["FeeAmount"],
                            TransactionAmount =
                                reader["TransactionAmount"] == DBNull.Value
                                    ? 0.0M
                                    : (decimal)reader["TransactionAmount"],
                            TransactionDate = reader["CreateDate"] == DBNull.Value ? null : (DateTime?)reader["CreateDate"],
                            MerchantCategoryCode = reader["MerchantCategoryCode"] == DBNull.Value
                                ? null
                                : reader["MerchantCategoryCode"].ToString(),
                            FeatureKey = reader["FeatureKey"] == DBNull.Value
                                ? 0
                                : (int)(short)reader["FeatureKey"],
                            IsReversal = reader["IsReversal"] == DBNull.Value
                                ? false
                                : (bool)reader["IsReversal"],
                            TransactionIdentifier = reader["TransactionIdentifier"] == DBNull.Value
                                ? ""
                                : reader["TransactionIdentifier"].ToString(),
                            ApprovalCode = reader["ApprovalCode"] == DBNull.Value
                                ? null
                                : reader["ApprovalCode"].ToString(),
                            RetrievalReferenceNumber = reader["RetrievalReferenceNumber"] == DBNull.Value
                                ? null
                                : reader["RetrievalReferenceNumber"].ToString()
                        };

                        transactions.Add(transaction);
                    }

                    if (reader.NextResult())
                    {
                        while (reader.Read())
                        {
                            var postReversalTx = new AuthorizedTransaction()
                            {
                                ApprovalCode = reader["ApprovalCode"] == DBNull.Value
                                    ? null
                                    : reader["ApprovalCode"].ToString(),
                                RetrievalReferenceNumber = reader["RetrievalReferenceNumber"] == DBNull.Value
                                    ? null
                                    : reader["RetrievalReferenceNumber"].ToString()
                            };

                            reversalTransactions.Add(postReversalTx);
                        }
                    }

                    if (reader.NextResult())
                    {
                        while (reader.Read())
                        {
                            var authReversalTx = new AuthorizedTransaction()
                            {
                                ApprovalCode = reader["ApprovalCode"] == DBNull.Value
                                    ? null
                                    : reader["ApprovalCode"].ToString(),
                                RetrievalReferenceNumber = reader["RetrievalReferenceNumber"] == DBNull.Value
                                    ? null
                                    : reader["RetrievalReferenceNumber"].ToString()
                            };

                            reversalTransactions.Add(authReversalTx);
                        }
                    }

                }

                var authTransactionsFiltered = new List<AuthorizeOverdraftTransaction>();

                foreach (var authTx in transactions)
                {
                    // First result set has duplicated values when the transaction ad a reversal
                    if (!authTransactionsFiltered.Any(x =>
                            x.ApprovalCode == authTx.ApprovalCode &&
                            x.RetrievalReferenceNumber == authTx.RetrievalReferenceNumber))
                    {
                        authTransactionsFiltered.Add(new AuthorizeOverdraftTransaction
                        {
                            TransactionIdentifier = authTx.TransactionIdentifier,
                            TransactionDate = authTx.TransactionDate,
                            TransactionAmount = authTx.TransactionAmount,
                            EstablishmentName = authTx.EstablishmentName,
                            EstablishmentCategory = authTx.EstablishmentCategory,
                            MerchantCategoryCode = authTx.MerchantCategoryCode,
                            FeatureKey = authTx.FeatureKey,
                            IsReversal = reversalTransactions.Exists(x => x.ApprovalCode == authTx.ApprovalCode && x.RetrievalReferenceNumber == authTx.RetrievalReferenceNumber), //mark as reversal due exists a post reversal or auth reversal record
                            GracePeriodDate = authTx.GracePeriodDate,
                            OverdraftFee = authTx.OverdraftFee
                        });
                    }
                }
                _logger.Info($"authTransactionsFiltered {authTransactionsFiltered.Count}, StartDate: {startDate}, EndDate: {endDate} ");
                var odTransactions = authTransactionsFiltered.Select(od => od.ToOverdraftTransaction()).ToList();
                _logger.Info($"odTransactions {odTransactions.Count}, StartDate: {startDate}, EndDate: {endDate} ");
                response.AccountIdentifier = accountIdentifier;
                response.OverdraftTransactions = odTransactions.GroupBy(x => new { x.TransactionIdentifier })
                        .Select(g => g.First())
                        .ToList();
                response.LastTransactionDate = GetLastTransactionDate(odTransactions);
                response.TotalAllowedTransactions = "";
            }
            catch (SqlException sqlEx)
            {
                LogManager.GetCurrentClassLogger().Error(sqlEx, "SQL error occurred while fetching overdraft transactions for account: {0}", accountIdentifier);
                response = new GetOverdraftTransactionsResponse
                {
                    AccountIdentifier = accountIdentifier,
                    OverdraftTransactions = new List<OverdraftTransaction>(),
                    LastTransactionDate = null,
                    TotalAllowedTransactions = ""
                };
            }
            catch (FormatException formatEx)
            {
                LogManager.GetCurrentClassLogger().Error(formatEx, "Data format error occurred while processing overdraft transactions for account: {0}", accountIdentifier);
                response = new GetOverdraftTransactionsResponse
                {
                    AccountIdentifier = accountIdentifier,
                    OverdraftTransactions = new List<OverdraftTransaction>(),
                    LastTransactionDate = null,
                    TotalAllowedTransactions = ""
                };
            }
            catch (Exception ex)
            {
                response = new GetOverdraftTransactionsResponse
                {
                    AccountIdentifier = accountIdentifier,
                    OverdraftTransactions = new List<OverdraftTransaction>(),
                    LastTransactionDate = null,
                    TotalAllowedTransactions = ""
                };
            }
            return response;
        }

        private static DateTime? GetLastTransactionDate(List<OverdraftTransaction> transactions)
        {
            return transactions.Count == 0 ? null : transactions.OrderByDescending(t => t.TransactionDate).FirstOrDefault()?.TransactionDate;
        }

        public List<ODAuthGracePeriod> GetOverdraftFeeAuthStatusHistory(
          string accountIdentifier, DateTime startDate, DateTime endDateTime, string programCode)
        {
            List<ODAuthGracePeriod> list = new List<ODAuthGracePeriod>();
            SqlParameter[] parameters = new[]
            {
                new SqlParameter() {ParameterName = "AccountIdentifier", Value = Guid.Parse(accountIdentifier)},
                new SqlParameter() { ParameterName = "StartDate", Value = startDate, SqlDbType = System.Data.SqlDbType.DateTime2 },
                new SqlParameter() { ParameterName = "EndDate", Value = endDateTime, SqlDbType = System.Data.SqlDbType.DateTime2 },
                new SqlParameter() { ParameterName = "ProgramCode", Value = programCode, SqlDbType = System.Data.SqlDbType.NVarChar },
            };

            using (var reader = _dataAccess.ExecuteReader("[CRM].[GetOverdraftFeeAuthStatusHistory]",
                _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {

                    var postRow = new ODAuthGracePeriod()
                    {
                        StartDateTime = reader.GetDateTime(reader.GetOrdinal("GracePeriodDate")),
                        TransactionIdentifier = reader.GetGuid(reader.GetOrdinal("TransactionIdentifier")),
                        TransactionAmount = reader.GetDecimal(reader.GetOrdinal("TransactionAmount")),
                        AuthorizationMessageHashId = reader["AuthorizeMessageHashID"].ConvertTo<byte[]>()
                    };
                    postRow.ExpirationDateTime = postRow.StartDateTime.AddDays(1);
                    list.Add(postRow);
                }
            }
            return list;
        }

    }
}
