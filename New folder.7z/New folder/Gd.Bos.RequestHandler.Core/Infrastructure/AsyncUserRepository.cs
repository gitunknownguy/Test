﻿using Gd.Bos.RequestHandler.Core.Application.Exception;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Business;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Utils;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.Shared.Common.Core.Logic;
using Microsoft.Data.SqlClient;
using NLog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using Gd.Bos.Shared.Common.UtilityCoreApi.Contract.Enum;
using RequestHandler.Core.Domain.Model.Account;
using RequestHandler.Core.Domain.Model.User;
using Address = Gd.Bos.RequestHandler.Core.Domain.Model.User.Address;
using BusinessAddress = Gd.Bos.RequestHandler.Core.Domain.Model.Business.BusinessAddress;
using Email = Gd.Bos.RequestHandler.Core.Domain.Model.User.Email;
using PhoneNumber = Gd.Bos.RequestHandler.Core.Domain.Model.User.PhoneNumber;
using User = Gd.Bos.RequestHandler.Core.Domain.Model.User.User;
using UserProfile = Gd.Bos.RequestHandler.Core.Domain.Model.User.UserProfile;
using Gd.Bos.RequestHandler.Core.Domain.Enums;
using RequestHandler.Core.Domain.Enums;
using System.Threading.Tasks;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    [ExcludeFromCodeCoverage(Justification = "Not tested previously and currently can't be easily mocked and will be taken care of on GBOS-116633")]
    public class AsyncUserRepository : IAsyncUserRepository
    {
        private readonly IDataAccess _dataAccess;

        private readonly string _userName = IdentityHelper.GetIdentityName();
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();
        public AsyncUserRepository(IDataAccess dataAccess)
        {
            _dataAccess = dataAccess;
        }

        public void Add(Gd.Bos.RequestHandler.Core.Domain.Model.User.User user, IdentityType identityType = IdentityType.SSN)
        {
            throw new NotImplementedException();
        }

        public Tuple<bool, bool, bool> CheckChanged(Gd.Bos.RequestHandler.Core.Domain.Model.User.UserProfile userProfile, UserIdentifier userIdentifier, AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public List<AccountHolderCureData> GetAccountHolderCureData(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public string GetAccountIdentifierByProspectId(string prospectIdentifier)
        {
            throw new NotImplementedException();
        }

        public Tuple<Gd.Bos.RequestHandler.Core.Domain.Model.User.UserProfile, long> GetBusinessUser(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public List<Gd.Bos.RequestHandler.Core.Domain.Model.User.UserProfile> GetBusinessUsers(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public Tuple<List<Tuple<long, UserIdentifier>>, long> GetBusinessUsersKey(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public Tuple<long, List<Gd.Bos.RequestHandler.Core.Domain.Model.User.Address>> GetConsumerAddress(UserIdentifier userIdentifier)
        {
            throw new NotImplementedException();
        }

        public List<Gd.Bos.RequestHandler.Core.Domain.Model.User.Address> GetConsumerAddress(long paymentIdentifierKey)
        {
            throw new NotImplementedException();
        }

        public Tuple<long, List<Gd.Bos.RequestHandler.Core.Domain.Model.User.Email>> GetConsumerEmail(UserIdentifier userIdentifier)
        {
            throw new NotImplementedException();
        }

        public Tuple<long, List<Gd.Bos.RequestHandler.Core.Domain.Model.User.PhoneNumber>> GetConsumerPhone(UserIdentifier userIdentifier)
        {
            throw new NotImplementedException();
        }

        public List<ConsumerProfileAddressHistory> GetConsumerProfileAddressHistory(long consumerProfileKey)
        {
            throw new NotImplementedException();
        }

        public ConsumerProfileExpense GetConsumerProfileExpense(long consumerProfileKey)
        {
            throw new NotImplementedException();
        }

        public async Task<List<ConsumerProfileExtension>> GetConsumerProfileExtension(string consumerProfileIdentifier)
        {
            var result = new List<ConsumerProfileExtension>();
            var parameters = new[]
            {
                new SqlParameter {ParameterName = "pConsumerProfileIdentifier", Value = Guid.Parse(consumerProfileIdentifier)}
            };

            try
            {
                using var connection = _dataAccess.CreateConnection();
                using (var reader = await _dataAccess.ExecuteReaderAsync("[dbo].[GetConsumerProfileExtensionByConsumerProfileIdentifier]", CommandType.StoredProcedure,
                    connection, default, parameters))
                {
                    while (await reader.ReadAsync())
                    {
                        var consumerProfileExtension = new ConsumerProfileExtension();
                        consumerProfileExtension.ConsumerProfileExtensionAttributeKey = Cast<int>(reader["ConsumerProfileExtensionAttributeKey"]);
                        consumerProfileExtension.ConsumerProfileExtensionAttributeValue = Cast<string>(reader["ConsumerProfileExtensionAttributeValue"]);
                        result.Add(consumerProfileExtension);
                    }
                }

                return result;
            }
            catch (SqlException ex)
            {
                Logger.Error(ex, 
                    $"UserRepository.GetConsumerProfileExtension: error occurred when retrieving income for consumerProfileIdentifier {consumerProfileIdentifier} : {ex}");
                throw new Exception("An error occurred trying to retrieve consumerProfileExtension: " + ex.Message);
            }
        }

        public ConsumerProfileIncome GetConsumerProfileIncome(long consumerProfileKey)
        {
            throw new NotImplementedException();
        }

        public List<Gd.Bos.RequestHandler.Core.Domain.Model.User.UserProfile> GetUser(AccountIdentifier accountIdentifier, UserIdentifier userIdentifier)
        {
            throw new NotImplementedException();
        }

        public List<UserProfileIdentity> GetUserProfileIdentities(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public List<Gd.Bos.RequestHandler.Core.Domain.Model.User.UserProfile> GetUserProfilesByAccountIdentifier(AccountIdentifier accountIdentifier)
        {
            throw new NotImplementedException();
        }

        public void InsConsumerProfileExpense(long consumerProfileKey, decimal expense, Gd.Bos.RequestHandler.Core.Application.FrequencyType frequencyType)
        {
            throw new NotImplementedException();
        }

        public void InsConsumerProfileIncome(long consumerProfileKey, decimal income, Gd.Bos.RequestHandler.Core.Application.FrequencyType frequencyType)
        {
            throw new NotImplementedException();
        }

        public long InsertConsumerProfileIdentity(long consumerProfileKey, string identity, string identityToken, IdentityType identityType)
        {
            throw new NotImplementedException();
        }

        public UserIdentifier NextUserIdentifier()
        {
            throw new NotImplementedException();
        }

        public void SaveOrUpdateConsumerProfileExtension(long consumerProfileKey, int attributeKey, string jsonAttributeValue)
        {
            throw new NotImplementedException();
        }

        public Tuple<bool, bool, bool> Update(Gd.Bos.RequestHandler.Core.Domain.Model.User.UserProfile userProfile, UserIdentifier userIdentifier, AccountIdentifier accountIdentifier, long customerProfileKey, bool updateAllAHHomeAddress, DateTime? userIdCreateDate, DateTime? passwordChangeDate)
        {
            throw new NotImplementedException();
        }

        public void UpdateAddressReturnedFlag(UserIdentifier userIdentifier, bool isReturned)
        {
            throw new NotImplementedException();
        }

        public void UpdateConsumerIdentity(UserIdentifier userIdentifier, string identity, string tokenizedIdentity, IdentityType identityType = IdentityType.SSN)
        {
            throw new NotImplementedException();
        }

        public void UpdateConsumerProfileExpense(long consumerProfileKey, decimal expense, Gd.Bos.RequestHandler.Core.Application.FrequencyType frequencyType)
        {
            throw new NotImplementedException();
        }

        public void UpdateConsumerProfileExtension(long consumerProfileKey, ConsumerProfileExtensionAttribute attr, string consumerProfileExtensionAttributeValue)
        {
            throw new NotImplementedException();
        }

        public void UpdateConsumerProfileIncome(long consumerProfileKey, decimal income, Gd.Bos.RequestHandler.Core.Application.FrequencyType frequencyType)
        {
            throw new NotImplementedException();
        }

        public void UpdateDOBMatchedFlag(bool isDobMatched, UserIdentifier userIdentifier)
        {
            throw new NotImplementedException();
        }

        public void UpdateEncryptedDOB(UserIdentifier userIdentifier, string dateOfBirth, bool? isDobVerified = null)
        {
            throw new NotImplementedException();
        }

        public void UpdatePhoneNumber(Gd.Bos.RequestHandler.Core.Domain.Model.User.PhoneNumber newPhoneNumber, UserIdentifier userIdentifier)
        {
            throw new NotImplementedException();
        }

        public void UpdatePhoneNumberVerificationFlag(bool IsVerified, UserIdentifier userIdentifier)
        {
            throw new NotImplementedException();
        }

        public void UpdatePhoneType(long consumerProfileKey, PhoneType oldPhoneTypeKey, PhoneType newphoneTypeKey)
        {
            throw new NotImplementedException();
        }

        public void UpdateUserName(UserName newName, UserIdentifier userIdentifier)
        {
            throw new NotImplementedException();
        }

        private static T Cast<T>(object value)
        {
            if (value == DBNull.Value || value == null)
                return default(T);

            return (T)value;
        }
    }
}
