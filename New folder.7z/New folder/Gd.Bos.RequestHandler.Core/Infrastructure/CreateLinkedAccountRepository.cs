﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using Gd.Bos.RequestHandler.Core.Infrastructure;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Cassandra.Contract;
using Gd.Bos.Shared.Common.Contract.Exceptions;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.Shared.Common.Cosmos.Contract;
using Newtonsoft.Json;
using NLog;
using RequestHandler.Core.Domain.Enums;
using RequestHandler.Core.Infrastructure.Enrollment;
using RequestHandler.Core.Utils;

namespace RequestHandler.Core.Infrastructure
{
    [ExcludeFromCodeCoverage(Justification = "Due to time constraint on migration we need to revisit")]
    public class CreateLinkedAccountRepository : ICreateLinkedAccountRepository
    {
        private readonly ICassandraAccess _cassandraAccess;
        private readonly ICosmosAccess _cosmosAccess;
        private readonly IRequestHandlerSettings _configurationProvider;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        private static readonly List<string> PrivacyInfo = new() { "DateOfBirth", "DOB", "SSN" };
        private const string Key = "dFXv0dSOrXyaWrBVdt/V0w==";

        public CreateLinkedAccountRepository(ICassandraAccess cassandraAccess, ICosmosAccess cosmosAccess, IRequestHandlerSettings configurationProvider)
        {
            _cassandraAccess = cassandraAccess;
            _cosmosAccess = cosmosAccess;
            _configurationProvider = configurationProvider;
        }
        public void SaveRequest<T>(T request, Guid key) where T : BaseRequest
        {
            if (OptionsContext.Current.IsDefined("X-GD-Bos-RequestHandler-Cassandra"))
                throw new ArgumentException("Cassandra failed.");
            try
            {
                var json = JsonConvert.SerializeObject(request);

                const string cql = "insert into " +
                    "enrollment.linked_account_status(request_id,key,request,status_id,is_active,create_date,update_date) " +
                    "values(?,?,?,?,?,?,?)";

                var parms = new object[] 
                { 
                    request.RequestHeader.RequestId,
                    key, 
                    handleSenstiveData(json, true), 
                    Convert.ToInt32(CreateLinkedAccountStatus.Started),
                    1,
                    DateTime.UtcNow, 
                    DateTime.UtcNow
                };
                if (CosmosUtils.UseCosmos(_configurationProvider))
                {
                    _cosmosAccess.ExecuteStatement(cql, parms);
                }
                else
                {
                    _cassandraAccess.ExecuteStatement(cql, parms);
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, ex.Message + " requestId " + request.RequestHeader.RequestId);
                throw new RequestHandlerException(503, 0, "Connection has been timed out, pls retry");
            }
        }

        public void SaveRequest<T, TEnum>(T request, TEnum enumValue, Guid key) where T : BaseRequest where TEnum : Enum
        {
            if (OptionsContext.Current.IsDefined("X-GD-Bos-RequestHandler-Cassandra"))
                throw new ArgumentException("Cassandra failed.");
            try
            {
                var json = JsonConvert.SerializeObject(request);

                const string cql = "insert into " +
                    "enrollment.linked_account_status(request_id,key,request,status_id,is_active,create_date,update_date) " +
                    "values(?,?,?,?,?,?,?)";

                var parms = new object[]
                {
                    request.RequestHeader.RequestId,
                    key,
                    handleSenstiveData(json, true),
                    Convert.ToInt32(enumValue),
                    1,
                    DateTime.UtcNow,
                    DateTime.UtcNow
                };
                if(CosmosUtils.UseCosmos(_configurationProvider)) 
                {
                    _cosmosAccess.ExecuteStatement(cql, parms);
                }
                else
                {
                    _cassandraAccess.ExecuteStatement(cql, parms);
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, ex.Message + " requestId " + request.RequestHeader.RequestId);
                throw new RequestHandlerException(503, 0, "Connection has been timed out, pls retry");
            }
        }

        public void UpdateRequest<T>(T request, Guid key) where T : BaseRequest
        {
            if (OptionsContext.Current.IsDefined("X-GD-Bos-RequestHandler-Cassandra"))
                throw new ArgumentException("Cassandra failed.");
            try
            {
                var json = JsonConvert.SerializeObject(request);
                const string cql = "update enrollment.linked_account_status set request=?,update_date=? where key=?";

                var parms = new object[] { handleSenstiveData(json, true),  DateTime.UtcNow, key };
                if (CosmosUtils.UseCosmos(_configurationProvider))
                {
                    _cosmosAccess.ExecuteStatement(cql, parms);
                }
                else
                {
                    _cassandraAccess.ExecuteStatement(cql, parms);
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, ex.Message + " requestId " + request.RequestHeader.RequestId);
                throw new RequestHandlerException(503, 0, "Connection has been timed out, pls retry");
            }
        }

        public CreateLinkedAccountStatus GetStatusByKey(Guid key)
        {
            try
            {
                const string cql = "select * from enrollment.linked_account_status where key=?";
                var parms = new object[] { key };
                var returnData = CosmosUtils.UseCosmos(_configurationProvider) ? _cosmosAccess.ExecuteStatement(cql, parms).FirstOrDefault() : _cassandraAccess.ExecuteStatement(cql, parms).FirstOrDefault();
                
                if (returnData == null)
                {
                    throw new NotFoundException();
                }
                var status = returnData.GetValue<int>("status_id");
                return (CreateLinkedAccountStatus)status;;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, ex.Message + " key " + key);
                throw;
            }
        }

        public TEnum? GetStatusByKeyWithoutException<TEnum>(Guid key) where TEnum : struct, Enum
        {
            try
            {
                const string cql = "select * from enrollment.linked_account_status where key=?";
                var parms = new object[] { key };
                var returnData = CosmosUtils.UseCosmos(_configurationProvider) ? _cosmosAccess.ExecuteStatement(cql, parms).FirstOrDefault() : _cassandraAccess.ExecuteStatement(cql, parms).FirstOrDefault();

                if (returnData == null)
                {
                    return null;
                }
                var status = returnData.GetValue<int>("status_id");
                if (Enum.IsDefined(typeof(TEnum), status))
                {
                    return (TEnum)(object)status;
                }
                return null;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, ex.Message + " key " + key);
                throw;
            }
        }

        public CreateLinkedAccountStatus? GetStatusByKeyWithoutException(Guid key)
        {
            try
            {
                const string cql = "select * from enrollment.linked_account_status where key=?";
                var parms = new object[] { key };
                var returnData = CosmosUtils.UseCosmos(_configurationProvider) ? _cosmosAccess.ExecuteStatement(cql, parms).FirstOrDefault() : _cassandraAccess.ExecuteStatement(cql, parms).FirstOrDefault();

                if (returnData == null)
                {
                    return null;
                }
                var status = returnData.GetValue<int>("status_id");
                return (CreateLinkedAccountStatus)status; ;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, ex.Message + " key " + key);
                throw;
            }
        }

        public void UpdateStatusByKey(Guid key, CreateLinkedAccountStatus status)
        {
            try
            {
                const string cql = "update enrollment.linked_account_status set status_id=?,update_date=? where key=?";

                var parms = new object[] { Convert.ToInt32(status), DateTime.UtcNow, key };
                if (CosmosUtils.UseCosmos(_configurationProvider))
                {
                    _cosmosAccess.ExecuteStatement(cql, parms);
                }
                else
                {
                    _cassandraAccess.ExecuteStatement(cql, parms);
                }               
            }
            catch (Exception ex)
            {
                _logger.Error(ex,ex.Message + " UpdateStatusByKey key " + key);
                throw new RequestHandlerException(503, 0, "Connection has been timed out, pls retry");
            }
        }
        public void UpdateStatusByKey<T>(Guid key, T status) where T : Enum
        {
            try
            {
                const string cql = "update enrollment.linked_account_status set status_id=?,update_date=? where key=?";

                var parms = new object[] { Convert.ToInt32(status), DateTime.UtcNow, key };
                if (CosmosUtils.UseCosmos(_configurationProvider))
                {
                    _cosmosAccess.ExecuteStatement(cql, parms);
                }
                else
                {
                    _cassandraAccess.ExecuteStatement(cql, parms);
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex,ex.Message + " UpdateStatusByKey key " + key);
                throw new RequestHandlerException(503, 0, "Connection has been timed out, pls retry");
            }
        }

        private string handleSenstiveData(string json, bool isEncrypt) 
        {
            foreach(var item in PrivacyInfo)
            {
                string pattern = string.Format(@"(?<=""({0})"":"")([^""]*)(?="")", item);
                var orginal = Regex.Match(json, pattern, RegexOptions.IgnoreCase);
                string replacement = null;
                if (isEncrypt)
                {
                    replacement = AesOperation.EncryptString(Key, orginal.Value);
                }
                else
                {
                    replacement = AesOperation.DecryptString(Key, orginal.Value);
                }
                json = Regex.Replace(json, pattern, replacement, RegexOptions.IgnoreCase);
            }
            return json;
        }
    }
}
