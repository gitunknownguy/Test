﻿using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using Gd.Bos.Shared.Common.Core.Data;
using Gd.Bos.RequestHandler.Core.Domain.Model.AccountTransaction;
using Gd.Bos.RequestHandler.Core.Utils;
using Gd.Bos.Shared.Common;
using NLog;
using Microsoft.Data.SqlClient.Server;

namespace Gd.Bos.RequestHandler.Core.Infrastructure
{
    public class AccountTransactionRepository : IAccountTransactionRepository
    {
        private readonly string _userName = IdentityHelper.GetIdentityName();
        private readonly IDataAccess _dataAccess;
        private static readonly Logger _logger = LogManager.GetCurrentClassLogger();

        public AccountTransactionRepository(IDataAccess dataAccess)
        {
            _dataAccess = dataAccess;
        }


        public List<AccountTransaction> GetAccountTransactionListByTransactionToken(Guid transactionToken)
        {
            List<AccountTransaction> transactions = new List<AccountTransaction>();
            var parameters = new[]
            {
                new SqlParameter()
                {
                    ParameterName = "AccountTransactionToken",
                    Value = transactionToken
                }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountTransactionByAccountTransactionToken]",
                _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    var transaction = new AccountTransaction
                    {
                        AccountTransactionToken = transactionToken,
                        AccountTransactionKey = reader.GetInt64(reader.GetOrdinal("AccountTransactionKey")),
                        TransactionReferenceId = reader.GetGuid(reader.GetOrdinal("TransactionReferenceID")),
                        AccountIdentifier = reader.GetGuid(reader.GetOrdinal("AccountIdentifier")),
                        Amount = reader.GetDecimal(reader.GetOrdinal("Amount")),
                        CurrencyKey = reader.GetInt16(reader.GetOrdinal("CurrencyKey")),
                        CurrencyCode = "USD",
                        TransactionDate = reader.GetDateTime(reader.GetOrdinal("TransactionDate")),
                        TransClassKey = reader.GetInt32(reader.GetOrdinal("TransClassKey")),
                        TransClass = reader.GetString(reader.GetOrdinal("TransClass"))?.Trim(),
                        TransClassDescription = reader.GetString(reader.GetOrdinal("TransClassDescription"))?.Trim(),
                        AccountTransactionStatusKey = reader.GetInt16(reader.GetOrdinal("AccountTransactionStatusKey")),
                        AccountTransactionStatusReasonKey =
                            reader.IsDBNull(reader.GetOrdinal("AccountTransactionStatusReasonKey"))
                                ? (short?)null
                                : reader.GetInt16(reader.GetOrdinal("AccountTransactionStatusReasonKey")),
                        TransactionDescription = reader.IsDBNull(reader.GetOrdinal("TransactionDescription"))
                            ? null
                            : reader.GetString(reader.GetOrdinal("TransactionDescription")),
                        StatusChangeDate =
                            reader.IsDBNull(reader.GetOrdinal("StatusChangeDate"))
                                ? (DateTime?)null
                                : reader.GetDateTime(reader.GetOrdinal("StatusChangeDate")),
                        AccountTransactionTypeKey = reader.IsDBNull(reader.GetOrdinal("AccountTransactionTypeKey"))
                            ? 0
                            : reader.GetInt16(reader.GetOrdinal("AccountTransactionTypeKey")),
                        AllowNegativeBalance = reader.IsDBNull(reader.GetOrdinal("IsAllowNegativeBalance")) ? (bool?)null : reader.GetBoolean(reader.GetOrdinal("IsAllowNegativeBalance"))

                    };
                    _logger.Debug($"AccoutTransactionKey: {transaction.AccountTransactionKey},AdjustmentIdentifier: {transaction.AccountTransactionToken} AccountTransactionType: {transaction.AccountTransactionTypeKey}");
                    transactions.Add(transaction);
                }
            }

            return transactions;
        }

        public void InsertAccountTransaction(AccountTransaction transaction)
        {
            try
            {
                var accountTransactionParameters = new[]
                {
                    new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                    new SqlParameter {ParameterName = "AccountIdentifier", Value = transaction.AccountIdentifier},
                    new SqlParameter
                        {ParameterName = "AccountTransactionToken", Value = transaction.AccountTransactionToken},
                    new SqlParameter
                        {ParameterName = "TransactionReferenceID", Value = transaction.TransactionReferenceId},
                    new SqlParameter {ParameterName = "Amount", Value = transaction.Amount},
                    new SqlParameter {ParameterName = "CurrencyKey", Value = transaction.CurrencyKey},
                    new SqlParameter {ParameterName = "TransactionDate", Value = transaction.TransactionDate},
                    new SqlParameter {ParameterName = "TransClassKey", Value = transaction.TransClassKey},
                    new SqlParameter
                    {
                        ParameterName = "AccountTransactionStatusKey", Value = transaction.AccountTransactionStatusKey
                    },
                    new SqlParameter
                        {ParameterName = "TransactionDescription", Value = transaction.TransactionDescription},
                    new SqlParameter
                    {
                        ParameterName = "AccountTransactionStatusReasonKey",
                        Value = transaction.AccountTransactionStatusReasonKey
                    },
                    new SqlParameter {ParameterName = "ResponseCode", Value = transaction.ResponseCode},
                    new SqlParameter
                        {ParameterName = "AccountTransactionTypeKey", Value = transaction.AccountTransactionTypeKey},
                    new SqlParameter { ParameterName = "IsAllowNegativeBalance", Value = transaction.AllowNegativeBalance }
                };

                var accountTransactionKey = _dataAccess.ExecuteScalar("[dbo].[InsAccountTransaction]",
                    _dataAccess.CreateConnection(),
                    accountTransactionParameters);


                transaction.AccountTransactionKey = Convert.ToInt64(accountTransactionKey);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Exception occured while InsertAccountTransaction.");
                throw;
            }

        }


        public void InsertAccountTransactionWithFee(List<AccountTransaction> transactions)
        {
            try
            {
                var conn = _dataAccess.CreateConnection();
                conn.Open();
                using (var tran = conn.BeginTransaction())
                {

                    foreach (var transaction in transactions)
                    {
                        var accountTransactionParameters = new[]
                        {
                            new SqlParameter {ParameterName = "ChangeBy", Value = _userName},
                            new SqlParameter
                                {ParameterName = "AccountIdentifier", Value = transaction.AccountIdentifier},
                            new SqlParameter
                            {
                                ParameterName = "AccountTransactionToken", Value = transaction.AccountTransactionToken
                            },
                            new SqlParameter
                                {ParameterName = "TransactionReferenceID", Value = transaction.TransactionReferenceId},
                            new SqlParameter {ParameterName = "Amount", Value = transaction.Amount},
                            new SqlParameter {ParameterName = "CurrencyKey", Value = transaction.CurrencyKey},
                            new SqlParameter {ParameterName = "TransactionDate", Value = transaction.TransactionDate},
                            new SqlParameter {ParameterName = "TransClassKey", Value = transaction.TransClassKey},
                            new SqlParameter
                            {
                                ParameterName = "AccountTransactionStatusKey",
                                Value = transaction.AccountTransactionStatusKey
                            },
                            new SqlParameter
                                {ParameterName = "TransactionDescription", Value = transaction.TransactionDescription},
                            new SqlParameter
                            {
                                ParameterName = "AccountTransactionStatusReasonKey",
                                Value = transaction.AccountTransactionStatusReasonKey
                            },
                            new SqlParameter {ParameterName = "ResponseCode", Value = transaction.ResponseCode},
                            new SqlParameter
                            {
                                ParameterName = "AccountTransactionTypeKey",
                                Value = transaction.AccountTransactionTypeKey
                            },
                            new SqlParameter { ParameterName = "IsAllowNegativeBalance", Value = transaction.AllowNegativeBalance}
                        };

                        SqlCommand command = conn.CreateCommand();
                        command.CommandText = "[dbo].[InsAccountTransaction]";
                        command.CommandType = CommandType.StoredProcedure;
                        command.Transaction = tran;
                        command.Parameters.AddRange(accountTransactionParameters);

                        var accountTransactionKey = command.ExecuteScalar();
                        transaction.AccountTransactionKey = Convert.ToInt64(accountTransactionKey);
                    }

                    tran.Commit();
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"Exception occured while InsertAccountTransactionWithFee.");
                throw;
            }
        }



        public void UpdateAccountTransaction(AccountTransaction transaction)
        {
            try
            {
                var accountTransactionParameters = new[]
                {
                    new SqlParameter{ParameterName = "ChangeBy", Value = _userName},
                    new SqlParameter{ParameterName = "AccountTransactionKey", Value = transaction.AccountTransactionKey},
                    new SqlParameter{ParameterName = "AccountTransactionStatusKey", Value = transaction.AccountTransactionStatusKey},
                    new SqlParameter{ParameterName = "AccountTransactionStatusReasonKey", Value = transaction.AccountTransactionStatusReasonKey}
                };

                _dataAccess.ExecuteScalar("[dbo].[UpdAccountTransaction]", _dataAccess.CreateConnection(),
                    accountTransactionParameters);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"Exception occured while UpdateAccountTransaction {transaction.AccountTransactionKey}, statusKey {transaction.AccountTransactionStatusKey}, statusReasonKey {transaction.AccountTransactionStatusReasonKey}.");
                throw;
            }
        }

        public bool UpdateAccountTransactionStatus(AccountTransaction transaction)
        {
            try
            {
                var accountTransactionParameters = new[]
                {
                    new SqlParameter{ParameterName = "ChangeBy", Value = _userName},
                    new SqlParameter{ParameterName = "AccountTransactionKey", Value = transaction.AccountTransactionKey},
                    new SqlParameter{ParameterName = "AccountTransactionStatusKey", Value = transaction.AccountTransactionStatusKey},
                    new SqlParameter{ParameterName = "AccountTransactionStatusReasonKey", Value = transaction.AccountTransactionStatusReasonKey}
                };

                using (var reader = _dataAccess.ExecuteReader("[dbo].[UpdAccountTransactionStatusByAccountTransactionKey]", _dataAccess.CreateConnection(), accountTransactionParameters))
                {
                    reader.Read();

                    if (reader.GetInt32(reader.GetOrdinal("UpdatedRowCount")) > 0)
                    {
                        return true;
                    }
                }

            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"Exception occured while UpdAccountTransactionStatusByAccountTransactionKey {transaction.AccountTransactionKey}, statusKey {transaction.AccountTransactionStatusKey}, statusReasonKey {transaction.AccountTransactionStatusReasonKey}.");
                throw;
            }

            return false;
        }

        public Guid? InsertRequestId(Gd.Bos.RequestHandler.Core.Application.AccountTransactions.Models.RequestTypeEnum requestType, Guid requestId, Guid accountIdentifier)
        {
            SqlParameter[] parameters = null;
            Guid? returnValue = null;

            parameters = new[]
            {
                new SqlParameter() { ParameterName = "ChangeBy", SqlDbType = SqlDbType.NVarChar, Size = 200, Value = _userName },
                new SqlParameter() { ParameterName = "RequestId", SqlDbType = SqlDbType.UniqueIdentifier, Value = requestId },
                new SqlParameter() { ParameterName = "RequestTypeKey", SqlDbType = SqlDbType.SmallInt, Value = (short)requestType },
                new SqlParameter() { ParameterName = "AccountIdentifier", SqlDbType = SqlDbType.UniqueIdentifier, Value = accountIdentifier }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[InsRequest]", _dataAccess.CreateConnection(), parameters))
            {
                reader.Read();

                if (reader.GetInt32(reader.GetOrdinal("AlreadyExists")) == 1)
                {
                    returnValue = reader.GetGuid(reader.GetOrdinal("AccountIdentifier"));
                }
            }
            return returnValue;
        }

        public List<AccountTransaction> GetAccountTransactionsByTransClass(Guid accountIdentifier, int transClassKey,
            DateTime startDate, DateTime endDate)
        {
            List<AccountTransaction> transactions = new List<AccountTransaction>();
            var parameters = new[]
            {
                new SqlParameter()
                {
                    ParameterName = "AccountIdentifier",
                    Value = accountIdentifier,
                    SqlDbType = SqlDbType.UniqueIdentifier
                },

                new SqlParameter()
                {
                    ParameterName = "StartDate",
                    Value = startDate,
                    SqlDbType = SqlDbType.DateTime
                },
                new SqlParameter()
                {
                    ParameterName = "EndDate",
                    Value = endDate,
                    SqlDbType = SqlDbType.DateTime
                },
                new SqlParameter()
                {
                    ParameterName = "TransClassKey",
                    Value = CreateTransClassKeyRow([transClassKey]).Convert(),
                    SqlDbType = SqlDbType.Structured,
                    TypeName = "dbo.typeTransClassKey"
                }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountTransactionByAccountIdentifierV3]",
                _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    var transaction = new AccountTransaction
                    {

                        AccountTransactionKey = reader.GetInt64(reader.GetOrdinal("AccountTransactionKey")),
                        Amount = reader.GetDecimal(reader.GetOrdinal("Amount")),

                        TransClassKey = reader.GetInt32(reader.GetOrdinal("TransClassKey")),
                        TransactionDate = reader.GetDateTime(reader.GetOrdinal("TransactionDate")),

                    };
                    _logger.Debug($"AccoutTransactionKey: {transaction.AccountTransactionKey},AdjustmentIdentifier: {transaction.AccountTransactionToken} AccountTransactionType: {transaction.AccountTransactionTypeKey}");
                    transactions.Add(transaction);
                }
            }

            return transactions;
        }

        public List<AccountTransaction> GetAccountTransactionsByLatestStatement(Guid accountIdentifier,
            int transClassKey)
        {
            List<AccountTransaction> transactions = new List<AccountTransaction>();
            var parameters = new[]
            {
                new SqlParameter()
                {
                    ParameterName = "AccountIdentifier",
                    Value = accountIdentifier,
                    SqlDbType = SqlDbType.UniqueIdentifier
                },
                new SqlParameter()
                {
                    ParameterName = "TransClassKey",
                    Value = transClassKey,
                    SqlDbType = SqlDbType.Int
                }

            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountTransactionByLatestStatement]",
                _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    var transaction = new AccountTransaction
                    {

                        AccountTransactionToken = reader["AccountTransactionToken"] == DBNull.Value ? Guid.Empty : reader.GetGuid(reader.GetOrdinal("AccountTransactionToken")),
                        AccountTransactionKey = reader.GetInt64(reader.GetOrdinal("AccountTransactionKey")),
                        TransactionReferenceId = reader.GetGuid(reader.GetOrdinal("TransactionReferenceID")),
                        Amount = reader.GetDecimal(reader.GetOrdinal("Amount")),
                        TransactionDate = reader.GetDateTime(reader.GetOrdinal("TransactionDate")),
                        TransClassKey = reader.GetInt32(reader.GetOrdinal("TransClassKey")),

                        AccountTransactionStatusKey = reader.GetInt16(reader.GetOrdinal("AccountTransactionStatusKey")),
                        AccountTransactionStatusReasonKey =
                            reader.IsDBNull(reader.GetOrdinal("AccountTransactionStatusReasonKey"))
                                ? (short?)null
                                : reader.GetInt16(reader.GetOrdinal("AccountTransactionStatusReasonKey")),
                        TransactionDescription = reader.IsDBNull(reader.GetOrdinal("TransactionDescription"))
                            ? null
                            : reader.GetString(reader.GetOrdinal("TransactionDescription")),
                        StatusChangeDate =
                            reader.IsDBNull(reader.GetOrdinal("StatusChangeDate"))
                                ? (DateTime?)null
                                : reader.GetDateTime(reader.GetOrdinal("StatusChangeDate")),
                        AllowNegativeBalance = reader.IsDBNull(reader.GetOrdinal("IsAllowNegativeBalance")) ? (bool?)null : reader.GetBoolean(reader.GetOrdinal("IsAllowNegativeBalance"))

                    };
                    _logger.Debug($"AccoutTransactionKey: {transaction.AccountTransactionKey},TransactionReferenceId: {transaction.TransactionReferenceId} AccountTransactionType: {transaction.AccountTransactionTypeKey}");
                    transactions.Add(transaction);
                }
            }

            return transactions;
        }


        private List<SqlDataRecord> CreateTransClassKeyRow(int[] transClassKey)
        {
            List<SqlDataRecord> returnValue = new List<SqlDataRecord>();
            foreach (var key in transClassKey)
            {
                SqlMetaData[] metadata = new SqlMetaData[1];

                metadata[0] = new SqlMetaData("TransClassKey", SqlDbType.Int);

                SqlDataRecord record = new SqlDataRecord(metadata);
                record.SetInt32(0, key);
                returnValue.Add(record);
            }

            return returnValue;
        }

        public AccountTransaction GetAccountTransactionByAccountTransactionKey(long accountTransactionKey)
        {
            AccountTransaction transaction = null;
            var parameters = new[]
            {
                new SqlParameter()
                {
                    ParameterName = "AccountTransactionKey",
                    Value = accountTransactionKey
                }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountTransaction]",
                _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    transaction = new AccountTransaction
                    {
                        AccountTransactionKey = accountTransactionKey,
                        Amount = reader.GetDecimal(reader.GetOrdinal("Amount")),
                        AllowNegativeBalance = reader.IsDBNull(reader.GetOrdinal("IsAllowNegativeBalance")) ? (bool?)null : reader.GetBoolean(reader.GetOrdinal("IsAllowNegativeBalance")),
                        CurrencyCode = reader.GetString(reader.GetOrdinal("CurrencyCode"))?.Trim(),
                        TransClass = reader.GetString(reader.GetOrdinal("TransClass"))?.Trim(),
                        TransactionReferenceId = reader.GetGuid(reader.GetOrdinal("TransactionReferenceID")),
                        TransactionDescription = reader.IsDBNull(reader.GetOrdinal("TransactionDescription"))
                           ? null
                           : reader.GetString(reader.GetOrdinal("TransactionDescription")),

                        AccountBalanceIdentifier = reader.IsDBNull(reader.GetOrdinal("AccountBalanceIdentifier"))
                           ? (Guid?)null
                           : reader.GetGuid(reader.GetOrdinal("AccountBalanceIdentifier"))
                    };
                    _logger.Debug($"AccoutTransactionKey: {transaction.AccountTransactionKey},AccountBalanceIdentifier: {transaction.AccountBalanceIdentifier},AllowNegativeBalance: {transaction.AllowNegativeBalance}");
                }
            }

            return transaction;
        }

        public List<AccountTransaction> GetAccountTransactionsByTransClassV3(Guid accountIdentifier, int[] transClassKey,
            DateTime startDate, DateTime endDate)
        {
            List<AccountTransaction> transactions = new List<AccountTransaction>();
            var parameters = new[]
            {
                new SqlParameter()
                {
                    ParameterName = "AccountIdentifier",
                    Value = accountIdentifier,
                    SqlDbType = SqlDbType.UniqueIdentifier
                },

                new SqlParameter()
                {
                    ParameterName = "StartDate",
                    Value = startDate,
                    SqlDbType = SqlDbType.DateTime
                },
                new SqlParameter()
                {
                    ParameterName = "EndDate",
                    Value = endDate,
                    SqlDbType = SqlDbType.DateTime
                },
                new SqlParameter()
                {
                    ParameterName = "TransClassKey",
                    Value = CreateTransClassKeyRow(transClassKey).Convert(),
                    SqlDbType = SqlDbType.Structured,
                    TypeName = "dbo.typeTransClassKey"
                }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[GetAccountTransactionByAccountIdentifierV3]",
                _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    var transaction = new AccountTransaction
                    {
                        AccountTransactionKey = reader.GetInt64(reader.GetOrdinal("AccountTransactionKey")),
                        Amount = reader.GetDecimal(reader.GetOrdinal("Amount")),
                        TransClassKey = reader.GetInt32(reader.GetOrdinal("TransClassKey")),
                        TransactionDate = reader.GetDateTime(reader.GetOrdinal("TransactionDate")),
                        AccountTransactionStatusKey = reader.GetInt16(reader.GetOrdinal("AccountTransactionStatusKey"))
                    };
                    _logger.Debug($"AccoutTransactionKey: {transaction.AccountTransactionKey},AdjustmentIdentifier: {transaction.AccountTransactionToken} AccountTransactionType: {transaction.AccountTransactionTypeKey}");
                    transactions.Add(transaction);
                }
            }

            return transactions;
        }

        public bool ExistingTransactionHistory(Guid accountIdentifier, DateTime startTime, DateTime endTime)
        {
            var parameters = new[]
            {
                new SqlParameter()
                {
                    ParameterName = "AccountIdentifier",
                    Value = accountIdentifier,
                    SqlDbType = SqlDbType.UniqueIdentifier
                },
                new SqlParameter()
                {
                    ParameterName = "StartDate",
                    Value = startTime,
                    SqlDbType = SqlDbType.DateTime
                },
                new SqlParameter()
                {
                    ParameterName = "EndDate",
                    Value = endTime,
                    SqlDbType = SqlDbType.DateTime
                }
            };

            using (var reader = _dataAccess.ExecuteReader("[dbo].[IsTransactionExist]",
                               _dataAccess.CreateConnection(), parameters))
            {
                while (reader.Read())
                {
                    return reader.GetBoolean(reader.GetOrdinal("Exists"));
                }
            }

            return false;
        }

    }

}
