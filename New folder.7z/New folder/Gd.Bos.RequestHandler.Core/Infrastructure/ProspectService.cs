﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Security.Cryptography;
using System.Text;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Caching;
using Gd.Bos.Shared.Common.Caching.Contract;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Response;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.Shared.Common.Logic.ProcessorSelector.Model;
using NLog;
using RequestHandler.Core.Application;
using RequestHandler.Core.Domain.Services.ProspectApi;
using GetProspectDetailsByIdRequest = Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.GetProspectDetailsByIdRequest;
using GetProspectDetailsRequest = RequestHandler.Core.Domain.Services.GetProspectDetailsRequest;
using GetProspectDetailsResponse = RequestHandler.Core.Domain.Services.ProspectApi.GetProspectDetailsResponse;
using OptOutAccountByCardProxyResponse = RequestHandler.Core.Domain.Services.ProspectApi.OptOutAccountByCardProxyResponse;

namespace RequestHandler.Core.Infrastructure
{
    public class ProspectService : IProspectService
    {
        private IProductService _productService;
        public ProspectService(IServiceInvokeProvider serviceInvokeProvider, IRequestHandlerSettings requestHandlerSettings, ILazyCache lazyCache, IProductService productService)
        {
            _serviceInvokerProvider = serviceInvokeProvider;
            _gssProspectApiBaseUrl = Gd.Bos.RequestHandler.Core.Infrastructure.Configuration.Configuration.Current
                .GSSProspectApiBaseUrl;
            _configuration = requestHandlerSettings;
            _lazyCache = lazyCache;
            _productService = productService;
        }

        public OptOutAccountByCardProxyResponse OptOutAccountByCardProxy(OptOutAccountByCardProxyRequest request)
        {
            var url = _gssProspectApiBaseUrl + _prospectOptOutByCardProxy;

            GetTimeout("X-GD-Bos-Prospect-OptOutAccountByCardProxy", out var requestTimeout);

            var response = _serviceInvokerProvider.GetWebResponse<OptOutAccountByCardProxyRequest, OptOutAccountByCardProxyResponse>(
                url,
                "PUT",
                request,
                requestTimeout);

            if (response == null)
                throw new Exception($"OptOutAccountByCardProxy did not return a recognizable response.");

            if (response.ResponseHeader == null)
                throw new Exception($"OptOutAccountByCardProxy did not return a recognizable header response.");

            if (response.ResponseHeader?.StatusCode != 0)
            {
                _logger.Error("OptOutAccountByCardProxy failed", response);
            }

            return new OptOutAccountByCardProxyResponse
            {
                ResponseHeader = new ProspectApiResponseHeader
                {
                    ResponseId = response.ResponseHeader.ResponseId,
                    StatusCode = response.ResponseHeader.StatusCode,
                    StatusMessage = response.ResponseHeader.StatusMessage
                }
            };
        }

        [ExcludeFromCodeCoverage(Justification = "Clean up logs GBOS-133556")]
        public GetProspectDetailsResponse GetProspectDetails(GetProspectDetailsRequest request)
        {
            var url = _gssProspectApiBaseUrl + _prospectApiUrl + "?cardproxy=" + request.CardProxy;

            GetTimeout("X-GD-Bos-Prospect-GetProspectDetails", out var requestTimeout);
            var response = _serviceInvokerProvider.GetWebResponse<ProspectDetailApiResponse>(
                url, "GET", null, requestTimeout);

            if (response == null)
                throw new Exception($"GetProspectDetails did not return a recognizable response.");
            if (response.ResponseHeader?.StatusCode != 0)
            {
                _logger.Warn("GetProspectDetails failed", response);
                throw new Gd.Bos.RequestHandler.Core.Infrastructure.ValidationException(4, 302,
                    $"Identification Failed. No prospect card found by cardProxy:{request.CardProxy}.");
            }

            var result = new GetProspectDetailsResponse()
            {
                SsnToken = response.SSNToken,
                EmbossedName = response.EmbossName,
                CardStockCode = response.CardStock,
                IsEmv = response.IsEMV,
                Address = response.Address,
                CardProxy = response.CardProxy,
                ProductCode = response.ProductCode,
                Dob = response.DOB,
                FirstName = response.FirstName,
                LastName = response.LastName,
                Phone = response.MobileNumber,
                SampleType = response.ProspectTypeKey,
                ResponseHeader = response.ResponseHeader,
                EmailAddress = response.EmailAddress,
                ProspectIdentifier = response.ProspectIdentifier,
                ProspectStatus = response.ProspectStatus == default(int) ? null : (int?)response.ProspectStatus,
                ProspectStatusDescription = response.ProspectStatusDescription,
                OriginalACHReference = response.OriginalACHReference,
                OriginalCardReference = response.OriginalCardReference,
                OriginalAccountToken = response.OriginalAccountToken
            };

            if (!string.IsNullOrWhiteSpace(result.Address?.AddressLine2))
                result.Address.AddressLine2 +=
                    string.IsNullOrWhiteSpace(result.Address?.AddressLine3)
                        ? ""
                        : " " + result.Address?.AddressLine3;

            result.CardStockCode = GetCBSCardStockIfACILive(result.ProductCode, result.CardStockCode, result.IsEmv);

            return result;
        }

        public GetProspectDetailsByIdResponse GetProspectDetailsById(GetProspectDetailsByIdRequest request)
        {
            var cacheKey = BuildGetProspectDetailsByIdCacheKey(request.ProspectIdentifier);
            var details = _lazyCache.Get(cacheKey, new TimeSpan(0, _configuration.CacheProspectDetailsByIdExpirationInMinutes, 0), () =>
                {
                    var url = _gssProspectApiBaseUrl + _prospectApiUrl + "/" + request.ProspectIdentifier;
                    GetTimeout("X-GD-Bos-Prospect-GetProspectDetails", out var requestTimeout);
                    var response = _serviceInvokerProvider.GetWebResponse<ProspectDetailApiResponse>(
                        url, "GET", null, requestTimeout);
                    if (response?.ResponseHeader == null)
                        throw new Exception($"GetProspectDetailsById did not return a recognizable response.");
                    if (response.ResponseHeader?.StatusCode != 0)
                    {
                        _logger.Info("GetProspectDetailsById failed", response);
                    }
                    var result = new GetProspectDetailsByIdResponse()
                    {
                        ProspectDetail = new ProspectDetail()
                        {
                            SsnToken = response.SSNToken,
                            EmbossedName = response.EmbossName,
                            CardStockCode = response.CardStock,
                            IsEmv = response.IsEMV,
                            Address = response.Address,
                            CardProxy = response.CardProxy,
                            ProductCode = response.ProductCode,
                            Dob = response.DOB,
                            FirstName = response.FirstName,
                            LastName = response.LastName,
                            Phone = response.MobileNumber,
                            SampleType = response.ProspectTypeKey,
                            Last4Ssn = response.Last4Ssn,
                            EmailAddress = response.EmailAddress,
                            ProspectIdentifier = response.ProspectIdentifier,
                            AccountNumber = response.AccountNumber,
                            ProspectStatus = response.ProspectStatus,
                            ProspectStatusDescription = response.ProspectStatusDescription,
                            OriginalACHReference = response.OriginalACHReference,
                            OriginalCardReference = response.OriginalCardReference,
                            OriginalAccountToken = response.OriginalAccountToken
                        },
                        ResponseHeader = new ResponseHeader
                        {
                            StatusCode = response.ResponseHeader.StatusCode,
                            Details = response.ResponseHeader.StatusMessage,
                            SubStatusCode = 0
                        }
                    };
                    if (!string.IsNullOrWhiteSpace(result.ProspectDetail?.Address?.AddressLine2))
                        result.ProspectDetail.Address.AddressLine2 +=
                            string.IsNullOrWhiteSpace(result.ProspectDetail?.Address?.AddressLine3)
                                ? ""
                                : " " + result.ProspectDetail?.Address?.AddressLine3;

                    result.ProspectDetail.CardStockCode = GetCBSCardStockIfACILive(result.ProspectDetail.ProductCode, result.ProspectDetail.CardStockCode, result.ProspectDetail.IsEmv);

                    return result;
                }
        );
            return details;
        }

        public UpdateProspectStatusResponse UpdateProspectStatus(UpdateProspectStatusRequest request)
        {
            var url = _gssProspectApiBaseUrl + _updateProspectStatusUrl;

            GetTimeout("X-GD-Bos-Prospect-UpdateProspectStatus", out var requestTimeout);

            var response = _serviceInvokerProvider.GetWebResponse<UpdateProspectStatusRequest, UpdateProspectStatusResponse>(
                url, "PUT", request, requestTimeout);

            if (response == null)
                throw new Exception($"UpdateProspectStatus did not return a recognizable response.");

            if (response.ResponseHeader?.StatusCode != 0)
            {
                _logger.Info("UpdateProspectStatus failed", response);
                throw new Exception(
                    $"UpdateProspectStatus failed ProspectId:{request.Id}.ResponseStatusCode:{response.ResponseHeader?.StatusCode},ResponseStatusMessage:{response.ResponseHeader?.StatusMessage}");
            }

            return new UpdateProspectStatusResponse
            {
                ResponseHeader = new ProspectApiResponseHeader
                {
                    ResponseId = response.ResponseHeader.ResponseId,
                    StatusCode = response.ResponseHeader.StatusCode,
                    StatusMessage = response.ResponseHeader.StatusMessage
                }
            };
        }

        private string GetCBSCardStockIfACILive(string productCode, string cardStock, bool isEmv)
        {
            if (string.IsNullOrWhiteSpace(productCode))
                return cardStock;

            var productInfo = _productService.GetByProductCode(productCode);
            var cbsCardStock = string.Empty;
            if (productInfo != null && cardStock != null && cardStock.Length == 3
                &&
                (productInfo.ProcessorKey == (int)SupportedProcessor.ACI || productInfo.ProcessorKey == (int)SupportedProcessor.CBS)
                )
            {
                cbsCardStock = _productService.GetCbsCardStockByCardStock(productInfo.ProductCode.ToString(), productInfo.ProgramCode.ToString(), cardStock, isEmv);
            }

            _logger.Info($"Run GetCBSCardStockIfACILive in ProspectService, productCode: {productCode}, originalcardStock: {cardStock}, cbsCardStock: {cbsCardStock}, isEmv: {isEmv}");

            return string.IsNullOrWhiteSpace(cbsCardStock) ? cardStock : cbsCardStock;
        }

        private void GetTimeout(string headerName, out int? requestTimeout)
        {
            requestTimeout = null;
            if (OptionsContext.Current.IsDefined(headerName))
            {
                requestTimeout = 1;
                if (int.TryParse(OptionsContext.Current.GetString(headerName), out var rt))
                    requestTimeout = rt;
            }
        }
        public string BuildGetProspectDetailsByIdCacheKey(string prospectIdentifier)
        {
            var tmpKey = $"{prospectIdentifier}";
            //Create a byte array from source data
            var tmpSource = Encoding.UTF8.GetBytes(tmpKey);

            //Compute hash based on source data
            using (var provider = new SHA256CryptoServiceProvider())
            {
                var tmpHash = provider.ComputeHash(tmpSource);

                var hash = ByteArrayToString(tmpHash);

                return $"{ProspectDetailsByIdRedisKeyPrefix}{hash}";
            }
        }

        public string BuildProspectDetailsCardProxyCacheKey(string cardProxy)
        {
            var tmpKey = $"{cardProxy}";
            //Create a byte array from source data
            var tmpSource = Encoding.UTF8.GetBytes(tmpKey);

            //Compute hash based on source data
            using (var provider = new SHA256CryptoServiceProvider())
            {
                var tmpHash = provider.ComputeHash(tmpSource);

                var hash = ByteArrayToString(tmpHash);

                return $"{ProspectCardProxyKeyPrefix}{hash}";
            }
        }

        private static string ByteArrayToString(byte[] data)
        {
            var sBuilder = new StringBuilder();

            // Loop through each byte of the hashed data
            // and format each one as a hexadecimal string.
            foreach (var b in data)
            {
                sBuilder.Append(b.ToString("x2"));
            }

            // Return the hexadecimal string.
            return sBuilder.ToString();
        }
        private const string ProspectDetailsByIdRedisKeyPrefix = "RH_ProspectDetailsById_";
        private const string ProspectCardProxyKeyPrefix = "RH_ProspectDetails_CardProxy_";
        private readonly IProspectService _prospectService;
        private readonly string _gssProspectApiBaseUrl;
        private readonly IServiceInvokeProvider _serviceInvokerProvider;
        private const string _prospectApiUrl = "/api/prospect/details";
        private const string _prospectOptOutByCardProxy = "/api/prospect/optout";
        private const string _updateProspectStatusUrl = "/api/prospect/Status";

        private static readonly ILogger _logger = LogManager.GetCurrentClassLogger();
        private readonly IRequestHandlerSettings _configuration;
        private readonly ILazyCache _lazyCache;
    }
}
