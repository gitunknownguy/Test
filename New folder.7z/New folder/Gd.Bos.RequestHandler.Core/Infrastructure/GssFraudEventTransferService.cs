﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Gd.Bos.Logging.Common.Managers;
using Gd.Bos.RequestHandler.Core.Application;
using Gd.Bos.RequestHandler.Core.Domain.Model;
using Gd.Bos.RequestHandler.Core.Domain.Model.Account;
using Gd.Bos.RequestHandler.Core.Domain.Model.Payment;
using Gd.Bos.RequestHandler.Core.Domain.Model.User;
using Gd.Bos.RequestHandler.Core.Domain.Services.AsyncCommandService;
using RequestHandler.Core.Application.AsyncCommandHandlers.Command;
using Gd.Bos.RequestHandler.Core.Domain.Services.Tokenizer;
using Gd.Bos.RequestHandler.Core.Infrastructure.Configuration;
using Gd.Bos.Shared.Common.Core.Contract.Interface;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data;
using Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum;
using Gd.Bos.Shared.Common.Core.Logic.Options;
using Gd.Bos.Shared.Common.FraudApi.Model.FraudRuleUI;
using Gd.Bos.Shared.Common.Messaging.Logic;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using NLog;
//using Org.BouncyCastle.Asn1.Ocsp;
using RequestHandler.Core.Domain.Model.Account;
using RequestHandler.Core.Domain.Model.PublishNotification;
using RequestHandler.Core.Domain.Services.Risk;
using RequestHandler.Core.Domain.Services.Risk.Messages.Request;
using RequestHandler.Core.Domain.Services.Risk.Messages.Response;
using Address = RequestHandler.Core.Domain.Services.Risk.Data.Address;
using LogManager = NLog.LogManager;
using PhoneNumber = Gd.Bos.RequestHandler.Core.Domain.Model.User.PhoneNumber;
using ProgramCode = Gd.Bos.RequestHandler.Core.Domain.Model.ProgramCode;
using RequestHeader = Gd.Bos.RequestHandler.Core.Domain.Services.Risk.Messages.Request.RequestHeader;
using User = Gd.Bos.RequestHandler.Core.Domain.Model.User.User;
using UserProfile = Gd.Bos.RequestHandler.Core.Domain.Model.User.UserProfile;
namespace Gd.Bos.RequestHandler.Core.Infrastructure
{

    public class GssFraudEventTransferService : IGssFraudEventTransferService
    {
        public GssFraudEventTransferService(IServiceInvokeProvider serviceInvokeProvider,
            ITokenizerService tokenizerService, IUserRepository userRepository,
            IPaymentIdentifierRepository paymentIdentifierRepository, IRequestHandlerSettings requestHandlerSettings,
            IBaasConfiguration baasConfiguration, IAccountRepository accountRepository, IProductRepository productRepository, 
            IAsyncCommandService asyncCommandService)
        {
            _serviceInvokerProvider = serviceInvokeProvider;
            _gssFraudTransferUrl = Configuration.Configuration.Current.GssFraudEventTransferApiUrl;
            _tokenizerService = tokenizerService;
            _userRepository = userRepository;
            _paymentIdentifierRepository = paymentIdentifierRepository;
            _requestHandlerSettings = requestHandlerSettings;
            _baasConfiguration = baasConfiguration;
            _accountRepository = accountRepository;
            _productRepository = productRepository;
            _asyncCommandService = asyncCommandService;
        }

        private readonly string _gssFraudTransferUrl;
        private readonly IUserRepository _userRepository;
        private readonly IServiceInvokeProvider _serviceInvokerProvider;
        private readonly ITokenizerService _tokenizerService;
        private readonly IPaymentIdentifierRepository _paymentIdentifierRepository;
        private readonly IRequestHandlerSettings _requestHandlerSettings;
        private const string DemographicFeedUri = "/{0}/Demographic/Feed";
        private readonly IBaasConfiguration _baasConfiguration;
        private static readonly ILogger Logger = LogManager.GetCurrentClassLogger();
        private readonly IAccountRepository _accountRepository;
        private readonly IProductRepository _productRepository;
        private readonly IAsyncCommandService _asyncCommandService;

        /// <summary>
        /// GBOS-101346   Ensure PII Updates on Child Account Reflect on PRM
        /// </summary>
        /// <param name="demographicFeed"></param>
        /// <returns></returns>
        public async Task DemographicFeedUseParentPhone(RetryDemographicFeedEventData demographicFeed, Guid requestId, string programCode, List<PhoneNumber> phones)
        {
            //var requestId = request.RequestHeader.RequestId;
            var url = _gssFraudTransferUrl + string.Format(DemographicFeedUri, programCode);
            try
            {
                #region 
                var links = _accountRepository.GetLinkedAccountsCached(demographicFeed.AccountIdentifier);
                //if is child account Covert Phone Number by Parent's Phnoe Number
                if (links != null && links.Any(l => l.LinkAccountIdentifier == demographicFeed.AccountIdentifier && l.AccountLinkType == AccountLinkType.Custodian) && demographicFeed.PhoneNumbers.Count > 0)
                {
                    var parentAccount = _accountRepository.GetByAccountIdentifier(AccountIdentifier.FromString(links.FirstOrDefault().PrimaryAccountIdentifier));
                    Logger.Info($"query Parent's information in function DemographicFeedUseParentPhone parentAccount.AccountIdentifier:{parentAccount.AccountIdentifier}. RequestId: {requestId}");
                    var parentUser = _userRepository.GetUser(parentAccount.AccountIdentifier, parentAccount.UserIdentifier)?.Where(a => parentAccount.AccountIdentifier.ToString().Equals(a.AccountIdentifier, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();

                    phones.Clear();
                    parentUser.PhoneNumbers.ForEach(phone => phones.Add(phone));

                    var pHomePhn = phones.FirstOrDefault(p => p.Type == PhoneType.Home)?.Number;
                    var pWorkPhn = phones.FirstOrDefault(p => p.Type == PhoneType.Work)?.Number;
                    var pMblPhn = phones.FirstOrDefault(p => p.Type == PhoneType.Mobile)?.Number ==
                             null
                        ? phones.FirstOrDefault()?.Number
                        : phones.FirstOrDefault(p => p.Type == PhoneType.Mobile)?.Number;
                    Logger.Info($"replace Parent's Phone in function DemographicFeedFF. RequestId: {requestId}, pHomePhn:{pHomePhn}, pWorkPhn:{pWorkPhn}, pMblPhn:{pMblPhn}.");
                }

                //if is parent account
                if (links != null && links.Any(l => l.PrimaryAccountIdentifier == demographicFeed.AccountIdentifier && l.AccountLinkType == AccountLinkType.Custodian))
                {
                    foreach (var link in links.Where(l => l.PrimaryAccountIdentifier.Equals(demographicFeed.AccountIdentifier, StringComparison.OrdinalIgnoreCase) && l.AccountLinkType == AccountLinkType.Custodian).ToList())
                    {
                        var childIdentifier = link.LinkAccountIdentifier;

                        var existingAccount = _accountRepository.GetAccountInfoByAccountIdentifier(childIdentifier);
                        var childAccount = existingAccount.AccountHolders.Where(l => l.IsPrimary == false).FirstOrDefault();
                        var pi = _paymentIdentifierRepository.GetPaymentInstrumentByUserIdentifier(
                                           Guid.Parse(childAccount.UserIdentifier.ToString()))?.FirstOrDefault(c => c.AccountIdentifier == childIdentifier && c.IsTemp == false);
                        var childPan = pi.TokenizedPan;
                        if (childPan.Length < 16)
                            childPan = _tokenizerService.DeTokenizePan(childPan);
                        var childProductCode = existingAccount.Product.ProductCode.ToString();

                        var requestChild = new DemographicFeedRequest()
                        {
                            EventTypeKey = string.IsNullOrEmpty(demographicFeed.EventType) ? 17 : 23,
                            EventType = string.IsNullOrEmpty(demographicFeed.EventType)
                        ? "cardActivation"
                        : demographicFeed.EventType,

                            ProgramCode = programCode,
                            ProductCode = childProductCode,

                            AcctNum = childIdentifier,
                            AcctCard = childPan,

                            HomePhn = demographicFeed.PhoneNumbers?.FirstOrDefault(p => p.Type == PhoneType.Home)?.Number,
                            WorkPhn = demographicFeed.PhoneNumbers?.FirstOrDefault(p => p.Type == PhoneType.Work)?.Number,
                            MblPhn = demographicFeed.PhoneNumbers?.FirstOrDefault(p => p.Type == PhoneType.Mobile)?.Number ==
                             null
                        ? demographicFeed.PhoneNumbers?.FirstOrDefault()?.Number
                        : demographicFeed.PhoneNumbers?.FirstOrDefault(p => p.Type == PhoneType.Mobile)?.Number,

                            ExternalIdentifiers = new Dictionary<string, object>
                        {
                            { "accountIdentifier", childIdentifier }
                        },

                            RequestHeader = new RequestHeader
                            {
                                RequestId = requestId
                            }
                        };
                        var response = new DemographicFeedResponse();
                        try
                        {
                            //URL replace to qa
                            response = await _serviceInvokerProvider.GetWebResponseAsync<DemographicFeedResponse>(url, "POST", JsonConvert.SerializeObject(requestChild));
                        }
                        catch (Exception e)
                        {
                            Logger.Error(e, $"ApplicationException calling GssFraudEventTransferApi.DemographicFeedUseParentPhone. RequestId: {requestId}");
                            throw new ApplicationException($"Exception calling GssFraudEventTransferApi.DemographicFeedUseParentPhone. RequestId: {requestId}", e);
                        }

                        Logger.Info(response == null
                            ? $"Failed calling GssFraudEventTransferApi.DemographicFeedUseParentPhone FireAndForget. RequestId: {requestId}"
                            : $"Success calling GssFraudEventTransferAPi.DemographicFeedUseParentPhone FireAndForget. Request:{MaskEngine.MaskMessage(JsonConvert.SerializeObject(requestChild))},Response:{MaskEngine.MaskMessage(JsonConvert.SerializeObject(response))}");
                    }
                }
            }
            catch (ApplicationException appEx)
            {
                throw;
            }
            catch (Exception e)
            {
                Logger.Error(e, $"Exception calling GssFraudEventTransferApi.DemographicFeedUseParentPhone. demographicFeed: {MaskEngine.MaskMessage(JsonConvert.SerializeObject(demographicFeed))},RequestId: {requestId},programCode: {programCode}");
            }
            #endregion
        }

        /// <summary>
        /// Demographic Feed fire and forget
        /// </summary>
        public async Task DemographicFeedFF(RetryDemographicFeedEventData demographicFeed, Guid requestId, string programCode)
        {
            var request = new DemographicFeedRequest();
            var response = new DemographicFeedResponse();
            var url = _gssFraudTransferUrl + string.Format(DemographicFeedUri, programCode);

            try
            { 
                var programBin = Get8DigitBinByProgramCode(programCode);
                var paymentInstrumentType = string.Empty;

                var fraudAddresses = demographicFeed.Addresses.Select(address => new Address
                {
                    Address1 = address.AddressLine1,
                    Address2 = address.AddressLine2,
                    City = address.City,
                    State = address.State,
                    PostalCode = address.ZipCode,
                    AddressType = address.AddressTypeKey == 1 ? "Residential" : address.AddressTypeKey == 3 ? "Billing" : "Residential"
                });

                var externalIdentifiers = new Dictionary<string, object>
                {
                    { "accountIdentifier", demographicFeed.AccountIdentifier}
                };
                var accountIdentifier = String.IsNullOrEmpty(demographicFeed.AccountIdentifier) ? null : AccountIdentifier.FromString(demographicFeed.AccountIdentifier);
                var userIdentifier = String.IsNullOrEmpty(demographicFeed.UserIdentifier) ? null : UserIdentifier.FromString(demographicFeed.UserIdentifier);
                var paymentIdentifierIdentifier = String.IsNullOrEmpty(demographicFeed.PaymentIdentifierIdentifier) ? null : PaymentIdentifierIdentifier.FromString(demographicFeed.PaymentIdentifierIdentifier);
                var paymentInstrumentIdentifier = String.IsNullOrEmpty(demographicFeed.PaymentInstrumentIdentifier) ? null : PaymentInstrumentIdentifier.FromString(demographicFeed.PaymentInstrumentIdentifier);

                var userProfileData = _userRepository.GetUser(accountIdentifier, userIdentifier).FirstOrDefault();
                if (paymentIdentifierIdentifier != default)
                {
                    var paymentInstrumentInfo = _paymentIdentifierRepository
                        .GetPaymentIdentifierByPaymentInstrumentIdentifier(paymentInstrumentIdentifier, out var _)?.PaymentInstrument?.PaymentInstrumentType;

                    if (string.IsNullOrEmpty(programBin))
                    {
                        programBin =
                            _paymentIdentifierRepository.GetBinByPaymentIdentifier(paymentIdentifierIdentifier);
                    }

                    paymentInstrumentType = paymentInstrumentInfo.HasValue ? ((int)paymentInstrumentInfo).ToString() : "";
                }
                var phones = new List<PhoneNumber>();
                foreach (var phoneNumber in demographicFeed.PhoneNumbers)
                {
                    phones.Add(phoneNumber);
                }
                await DemographicFeedUseParentPhone(demographicFeed, requestId, programCode, phones);
                request = new DemographicFeedRequest()
                {
                    EventTypeKey = string.IsNullOrEmpty(demographicFeed.EventType) ? 17 : 23,
                    EventType = string.IsNullOrEmpty(demographicFeed.EventType)
                        ? "cardActivation"
                        : demographicFeed.EventType,

                    ProgramCode = programCode,
                    ProductCode = demographicFeed.ProductCode,

                    AcctNum = demographicFeed.AccountIdentifier,
                    AcctCard = demographicFeed.CurrentPan,
                    PrvsCardNum = string.IsNullOrEmpty(demographicFeed.oldPan)
                        ? string.Empty
                        : demographicFeed.oldPan,
                    RoutingNumber = demographicFeed.RoutingNumber,
                    Bin = programBin,
                    PaymentInstrumentType = paymentInstrumentType,
                    CardIssueDate = demographicFeed.issuedDate == default
                        ? string.Empty
                        : demographicFeed.issuedDate.Value.ToDateTimeString(),
                    CardActivationDate = demographicFeed.ActivatedDate == default
                        ? string.Empty
                        : demographicFeed.ActivatedDate.Value.ToDateTimeString(),

                    FirstName = demographicFeed.UserName?.FirstName,
                    LastName = demographicFeed.UserName?.LastName,
                    DateOfBirth = demographicFeed.DateOfBirth,

                    Email = demographicFeed.EmailAddress,
                    HomePhn = phones.FirstOrDefault(p => p.Type == PhoneType.Home)?.Number,
                    WorkPhn = phones.FirstOrDefault(p => p.Type == PhoneType.Work)?.Number,
                    MblPhn = phones.FirstOrDefault(p => p.Type == PhoneType.Mobile)?.Number ==
                             null
                        ? phones.FirstOrDefault()?.Number
                        : phones.FirstOrDefault(p => p.Type == PhoneType.Mobile)?.Number,
                    Addresses = fraudAddresses?.ToList(),
                    IdentityType = demographicFeed.IdentityType,
                    IdentityCountryCode = demographicFeed.IdentityCountryCode,

                    ExternalIdentifiers = externalIdentifiers,
                    LastAdrsChngDate = (userProfileData?.Addresses?.MaxBy(ad => ad.LastModified)?
                        .LastModified ?? DateTime.UtcNow).DateTime.ToDateTimeString(),
                    LastEmailChngeDate = (userProfileData?.Email?.LastModified ?? DateTime.UtcNow).DateTime.ToDateTimeString(),
                    LastMblPhnChngeDate = (userProfileData?.PhoneNumbers?.Where(ph => ph.Type == PhoneType.Mobile)
                        .MaxBy(ph => ph.LastModified)?.LastModified ?? DateTime.UtcNow).DateTime.ToDateTimeString(),
                    RequestHeader = new RequestHeader
                    {
                        RequestId = requestId
                    }
                };
            }
            catch (ApplicationException appEx)
            {
                throw;
            }
            catch (Exception e)
            {
                Logger.Error(e, $"Exception calling GssFraudEventTransferApi.DemographicFeed. demographicFeed: {MaskEngine.MaskMessage(JsonConvert.SerializeObject(demographicFeed))},RequestId: {requestId},programCode: {programCode}");
                return;
            }

            try
            {
                response = await _serviceInvokerProvider.GetWebResponseAsync<DemographicFeedResponse>(
                    url, "POST", JsonConvert.SerializeObject(request));
            }
            catch (Exception e)
            {
                Logger.Error(e, $"Exception calling GssFraudEventTransferApi.DemographicFeed. RequestId: {requestId}");
                throw;
            }

            Logger.Info(response == null
                ? $"Failed calling GssFraudEventTransferApi.DemographicFeed FireAndForget. RequestId: {requestId}"
                : $"Success calling GssFraudEventTransferAPi.DemographicFeed FireAndForget. Request:{MaskEngine.MaskMessage(JsonConvert.SerializeObject(request))},Response:{MaskEngine.MaskMessage(JsonConvert.SerializeObject(response))}");

        }

        private string Get8DigitBinByProgramCode(string programCode)
        {
            programCode = programCode.ToLower();

            var mappingValue = _baasConfiguration.Get8DigitBin(programCode);
            return mappingValue;
        }

        /// <summary>
        /// Demographic Feed fire and forget call
        /// </summary>
        public void DemographicFeed(DemographicFeedEventData demographicFeed)
        {
            //GBOS-98541 Enhance the solution of GBOS-81468
            var requestId = OptionsContext.Current.GetGuid("requestId", new Guid());
            var programCode = OptionsContext.Current.GetString("programCode");
            var retryId = Guid.NewGuid().ToString();

            try
            {
                var retryDemographicFeed = new RetryDemographicFeedEventData()
                {
                    UserName = demographicFeed.User?.Name,
                    PhoneNumbers = demographicFeed.User?.PhoneNumbers,
                    Addresses = demographicFeed.User?.Addresses,
                    DateOfBirth = demographicFeed.User?.UserIdentifyingData?.DateOfBirth,
                    EmailAddress = demographicFeed.User?.Email?.EmailAddress,
                    IdentityType = demographicFeed.User?.IdentityType,
                    IdentityCountryCode = demographicFeed.User?.IdentityCountryCode,
                    ProgramCode = programCode,
                    ProductCode = demographicFeed.CardAccountInfo?.ProductCode?.ToString(),
                    UserIdentifier = demographicFeed.User?.UserIdentifier?.ToString(),
                    AccountIdentifier = demographicFeed.CardAccountInfo?.AccountIdentifier?.ToString(),
                    CurrentPan = demographicFeed.CardAccountInfo?.CurrentPan,
                    PaymentIdentifierIdentifier = demographicFeed.CardAccountInfo?.PaymentIdentifier?.ToString(),
                    PaymentInstrumentIdentifier = demographicFeed.CardAccountInfo?.PaymentInstrumentIdentifier?.ToString(),
                    RoutingNumber = demographicFeed.CardAccountInfo?.RoutingNumber,
                    oldPan = demographicFeed.CardAccountInfo?.oldPan,
                    issuedDate = demographicFeed.CardAccountInfo?.issuedDate,
                    ActivatedDate = demographicFeed.CardAccountInfo?.ActivatedDate,
                    EventType = demographicFeed.EventType
                };

                Logger.Info($"DemographicFeed send to retry queue. RetryId: {retryId}, RequestId: {requestId}, " +
                            $"retryDemographicFeed: {MaskEngine.MaskMessage(JsonConvert.SerializeObject(retryDemographicFeed))}");
                _asyncCommandService.Send(new RetryDemographicFeedEventDataCommand()
                {
                    DemographicFeedEventData = retryDemographicFeed,
                    AccountIdentifier = demographicFeed.CardAccountInfo?.AccountIdentifier?.ToString(),
                    RequestHeader = new Shared.Common.Core.CoreApi.Contract.Message.Request.RequestHeader()
                    {
                        RequestId = requestId
                    },
                    RetryId = retryId,
                    WaitIntervalSeconds = _requestHandlerSettings.WaitIntervalSecondsForEnrollOrderCard,
                    RetryCount = 1,
                    MaxRetryCount = 3,
                    ProgramCode = programCode
                });
            }
            catch (System.Exception e)
            {
                Logger.Error(e, $"Error occured when calling DemographicFeed, requestId: {requestId}, demographicFeed: {MaskEngine.MaskMessage(JsonConvert.SerializeObject(demographicFeed))}");
            }
        }

        public void DemographicFeed(ProductCode productCode, AccountIdentifier accountIdentifier, string pan, UserProfile userProfile, Boolean isChildAccount = false)
        {
            var userIdentifyingData = isChildAccount ?
                new UserIdentifyingData(userProfile.DateOfBirth, null, null, null, 7):
                new UserIdentifyingData(userProfile.DateOfBirth, null, null, null);
     
            var programCode = ProgramCode.FromString(OptionsContext.Current.GetString("ProgramCode"));
            var userName = new UserName(userProfile.FirstName, userProfile.MiddleName, userProfile.LastName);

            var user = new User(userProfile.UserIdentifier, programCode, userName, userProfile.Email,
                userIdentifyingData, null);
            userProfile.Addresses.ForEach(address => user.AddAddress(address));
            userProfile.PhoneNumbers.ForEach(phone => user.AddPhoneNumber(phone));

            if (pan.Length < 16)
                pan = _tokenizerService.DeTokenizePan(pan);

            Logger.Info($"DemographicFeed accountIdentifier: {accountIdentifier}, userIdentifier: {userProfile.UserIdentifier}, requestId: {OptionsContext.Current.GetGuid("requestId", new Guid())}");

            DemographicFeed(new DemographicFeedEventData(user,
                new DemographicFeedCardAccountDetail(productCode, accountIdentifier, pan), "updateUser"));
        }

        public void DemographicFeed(string userIdentifier, ProductCode productCode, AccountIdentifier accountIdentifier, string pan, UserCreationData userCreation)
        {
            var userIdentifyingData = new UserIdentifyingData(userCreation.ProfileData.DateOfBirth, null, null, null);
            var programCode = ProgramCode.FromString(OptionsContext.Current.GetString("ProgramCode"));
            var userName = new UserName(userCreation.ProfileData.FirstName, userCreation.ProfileData.MiddleName, userCreation.ProfileData.LastName);

            var user = new User(userIdentifier, programCode, userName, new Domain.Model.User.Email(
                    userCreation.Email.EmailAddress,
                    userCreation.Email.IsVerified,
                    true),
                userIdentifyingData, null);

            userCreation.ProfileData.Addresses.ForEach(address => user.AddAddress(
                new Domain.Model.User.Address()
                {
                    AddressLine1 = address.AddressLine1,
                    AddressLine2 = address.AddressLine2,
                    City = address.City,
                    State = address.State,
                    ZipCode = address.ZipCode
                }
                ));
            userCreation.PhoneNumbers.ForEach(phone => user.AddPhoneNumber(
                new PhoneNumber()
                {
                    Type = phone.Type,
                    Number = phone.Number,
                    IsDefault = phone.IsDefault,
                    IsVerified = phone.IsVerified
                }
                ));

            if (pan.Length < 16)
                pan = _tokenizerService.DeTokenizePan(pan);
            DemographicFeed(new DemographicFeedEventData(user,
                new DemographicFeedCardAccountDetail(productCode, accountIdentifier, pan), "updateUser"));
        }
    }

}

