﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Tests")]