﻿using System.ServiceModel;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class PntResponseDetails
    {
        [MessageBodyMember]
        public int Code { get; set; } = 0;
        [MessageBodyMember]
        public int SubCode { get; set; } = 0;
        [MessageBodyMember]
        public string Description { get; set; } = "";
        [MessageBodyMember]
        public string Url { get; set; } = "";
    }
}
