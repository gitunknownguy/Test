﻿using System.Diagnostics.CodeAnalysis;

namespace Gd.Bos.Dcpp.Contract.Message
{
    public class ReportLostStolenV2Request : ReportLostStolenRequest
    {
        public bool IsProductEligibleForDigitalWallet { get; set; }
        public string source { get; set; }
        public bool CreateVirtualCard { get; set; }
    }
}
