﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.ServiceModel;
using System.Text;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class ActivateSampleCardResponse : ResponseBase
    {
        [MessageBodyMember]
        public string AccountIdentifier { get; set; }

        [MessageBodyMember]
        public string PaymentIdentifier { get; set; }

        [MessageBodyMember]
        public string PaymentInstrumentIdentifier { get; set; }

        [MessageBodyMember]
        public string Status { get; set; }

        [MessageBodyMember]
        public string AccountBalanceIdentifier { get; set; }

        [MessageBodyMember]
        public string AccountNumber { get; set; }

        [MessageBodyMember]
        public string RoutingNumber { get; set; }
    }
}
