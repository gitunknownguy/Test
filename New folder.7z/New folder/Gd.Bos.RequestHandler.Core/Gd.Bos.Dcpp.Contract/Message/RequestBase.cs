﻿using System.Diagnostics.CodeAnalysis;
using System.ServiceModel;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class RequestBase
    {
        [MessageBodyMember]
        public RequestHeader Header { get; set; }

        [MessageBodyMember]
        public string ProgramCode { get; set; }

    }
}
