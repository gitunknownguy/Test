﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class GetAccountBalanceRequest : RequestBase
    {
        [MessageBodyMember]
        public string AccountId { get; set; }
    }
}
