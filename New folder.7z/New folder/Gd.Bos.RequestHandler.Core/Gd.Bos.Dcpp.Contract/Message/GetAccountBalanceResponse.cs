﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.ServiceModel;
using Gd.Bos.Dcpp.Contract.Data;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class GetAccountBalanceResponse : ResponseBase
    {
        [MessageBodyMember]
        [Required]
        public CurrencyAmount AvailableBalance { get; set; }

        [MessageBodyMember]
        [Required]
        public CurrencyAmount CurrentBalance { get; set; }
    }
}
