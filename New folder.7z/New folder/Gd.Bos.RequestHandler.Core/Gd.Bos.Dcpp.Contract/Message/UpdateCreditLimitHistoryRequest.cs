﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class UpdateCreditLimitHistoryRequest : RequestBase
    {
        [MessageBodyMember]
        [Required]
        public Guid AccountIdentifier { get; set; }

        [MessageBodyMember]
        public decimal CreditLimit { get; set; }

        [MessageBodyMember]
        public string Source { get; set; }
    }
}
