﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.ServiceModel;
using Gd.Bos.Dcpp.Contract.Data;
using Gd.Bos.Dcpp.Contract.Enum;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class AddPurseToAccountResponse : ResponseBase
    {
        [MessageBodyMember]
        [Required]
        public string AccountIdentifier { get; set; }

        [MessageBodyMember]
        [Required]
        public string AccountBalanceIdentifier { get; set; }

        [MessageBodyMember]
        public long AccountBalanceKey { get; set; }

        [MessageBodyMember]
        public CurrencyAmount CurrentBalance { get; set; }

        [MessageBodyMember]
        public DateTime CurrentBalanceAsOfDate { get; set; }

        [MessageBodyMember]
        public CurrencyAmount AvailableBalance { get; set; }

        [MessageBodyMember]
        public DateTime AvailableBalanceAsOfDate { get; set; }

        [MessageBodyMember]
        public PurseType PurseType { get; set; }

        [MessageBodyMember]
        public string UserDescription { get; set; }

        [MessageBodyMember]
        public bool IsHidden { get; set; }

        [MessageBodyMember]
        public PurseStatus Status { get; set; }

        [MessageBodyMember]
        public decimal? GoalAmount { get; set; }

        [MessageBodyMember]
        public string IconName { get; set; }

        [MessageBodyMember]
        public DateTime CreateDate { get; set; }

        [MessageBodyMember]
        public DateTime ChangeDate { get; set; }

        [MessageBodyMember]
        public string PurseNumber { get; set; }

        [MessageBodyMember]
        public string PurseSubType { get; set; }
    }
}