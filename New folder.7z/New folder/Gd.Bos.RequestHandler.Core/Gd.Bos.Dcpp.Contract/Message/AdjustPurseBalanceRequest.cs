﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.ServiceModel;
using Gd.Bos.Dcpp.Contract.Data;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class AdjustPurseBalanceRequest : RequestBase
    {
        [MessageBodyMember]
        [Required]
        public string AccountIdentifier { get; set; }

        [MessageBodyMember]
        [Required]
        public string PurseIdentifier { get; set; }

        [MessageBodyMember]
        [Required]
        public string TransactionReferenceId { get; set; }

        [MessageBodyMember]
        [StringLength(7)]
        public string TransClass { get; set; }

        [MessageBodyMember]
        [Required]
        public CurrencyAmount Adjustment { get; set; }

        [MessageBodyMember]
        public string Description { get; set; }

        [MessageBodyMember]
        public string Comment { get; set; }

        [MessageBodyMember]
        public bool AllowNegativeBalance { get; set; }
    }
}
