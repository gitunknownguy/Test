﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class DeleteSegmentResponse : ResponseBase
    {
        [MessageBodyMember]
        [Required]
        public string PaymentIdentifier { get; set; }

        [MessageBodyMember]
        [Required]
        public string SegmentName { get; set; }
    }
}
