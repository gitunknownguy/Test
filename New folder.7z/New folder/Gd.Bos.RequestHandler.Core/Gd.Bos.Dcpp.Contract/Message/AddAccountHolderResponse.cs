﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.ServiceModel;
using Gd.Bos.Dcpp.Contract.Data;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class AddAccountHolderResponse : ResponseBase
    {
        /*public Guid PaymentIdentifierIdentifier { get; set; }

        public Guid AccountBalanceIdentifier { get; set; }

        public Guid PaymentInstrumentIdentifier { get; set; }

        public string CardNumber { get; set; }

        public DateTime Expiration { get; set; }*/

        [MessageBodyMember]
        [Required]
        public string PaymentIdentifierIdentifier { get; set; }

        [MessageBodyMember]
        [Required]
        public string AccountBalanceIdentifier { get; set; }

        [MessageBodyMember]
        [Required]
        public string PaymentInstrumentIdentifier { get; set; }

        [MessageBodyMember]
        [Required]
        public string CardNumber { get; set; }

        [MessageBodyMember]
        [Required]
        public ExpirationDate Expiration { get; set; }

        [MessageBodyMember]
        [Required]
        public string Cvv { get; set; }

        //[MessageBodyMember]
        //[Required]
        //public string AccountIdentifier { get; set; }

        //[MessageBodyMember]
        //[Required]
        //public string UserIdentifier { get; set; }

        //[MessageBodyMember]
        //[Required]
        //public string PaymentIdentifierIdentifier { get; set; }

        //[MessageBodyMember]
        //[Required]
        //public string AccountBalanceIdentifier { get; set; }

        //[MessageBodyMember]
        //[Required]
        //public string PaymentInstrumentIdentifier { get; set; }

        //[MessageBodyMember]
        //[Required]
        //public string CardNumber { get; set; }

        //[MessageBodyMember]
        //[Required]
        //public ExpirationDate Expiration { get; set; }

        //[MessageBodyMember]
        //[Required]
        //public string Cvv { get; set; }
    }
}
