﻿using System.ServiceModel;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class AuthorizePaymentRequest : RequestBase
    {
        public AuthorizePaymentRequest() { }
        public AuthorizePaymentRequest(Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.AuthorizePaymentRequest request)
        {

            Header = new RequestHeader();
            if (request.RequestHeader?.RequestId != null)
            {
                Header.RequestId = request.RequestHeader.RequestId;
            }
            if (request.RequestHeader?.Options != null && request.RequestHeader.Options.Count > 0)
            {
                foreach (var item in request.RequestHeader.Options)
                {
                    Header.Options.Add(item.Key, item.Value);
                }
            }
            MessageType = request.MessageType;
            PaymentInstrumentIdentifier = request.PaymentInstrumentIdentifier;
            EncryptedCardData = request.EncryptedCardData == null ? null : new EncryptedCardData(request.EncryptedCardData);
            TransactionIdentifier = request.TransactionIdentifier;
            SystemTraceNumber = request.SystemTraceNumber;
            TransactionCode = request.TransactionCode;
            AccountType = request.AccountType;
            PosEntryMode = request.PosEntryMode == null ? null : new PosEntryMode(request.PosEntryMode);
            TransactionAmount = request.TransactionAmount;
            TransactionCurrency = request.TransactionCurrency;
            TransactionFeeAmount = request.TransactionFeeAmount;
            TransmissionDateTime = request.TransmissionDateTime;
            LocalDateTime = request.LocalDateTime;
            SettlementDateTime = request.SettlementDateTime;
            AcquiringCountryCode = request.AcquiringCountryCode;
            CardSequenceNumber = request.CardSequenceNumber;
            FunctionCode = request.FunctionCode;
            MessageReasonCode = request.MessageReasonCode;
            Merchant = request.Merchant == null ? null : new Merchant(request.Merchant);
            OriginalAmount = request.OriginalAmount;
            AcquirerId = request.AcquirerId;
            RetrievalReferenceNumber = request.RetrievalReferenceNumber;
            TerminalIdentifier = request.TerminalIdentifier;
            OriginalTransactionForReversal = request.OriginalTransactionForReversal == null ? null : new OriginalTransactionForReversal(request.OriginalTransactionForReversal);
            ECommerceIndicator = request.ECommerceIndicator;
        }

        [MessageBodyMember]
        public string MessageType { get; set; }
        [MessageBodyMember]
        public string PaymentInstrumentIdentifier { get; set; }
        [MessageBodyMember]
        public EncryptedCardData EncryptedCardData { get; set; }
        [MessageBodyMember]
        public string TransactionIdentifier { get; set; }
        [MessageBodyMember]
        public string SystemTraceNumber { get; set; }
        [MessageBodyMember]
        public string TransactionCode { get; set; }
        [MessageBodyMember]
        public string AccountType { get; set; }
        [MessageBodyMember]
        public PosEntryMode PosEntryMode { get; set; }
        [MessageBodyMember]
        public decimal TransactionAmount { get; set; }
        [MessageBodyMember]
        public string TransactionCurrency { get; set; }
        [MessageBodyMember]
        public decimal TransactionFeeAmount { get; set; }
        [MessageBodyMember]
        public string TransmissionDateTime { get; set; }
        [MessageBodyMember]
        public string LocalDateTime { get; set; }
        [MessageBodyMember]
        public string SettlementDateTime { get; set; }
        [MessageBodyMember]
        public string AcquiringCountryCode { get; set; }
        [MessageBodyMember]
        public string CardSequenceNumber { get; set; }
        [MessageBodyMember]
        public string FunctionCode { get; set; }
        [MessageBodyMember]
        public int MessageReasonCode { get; set; }
        [MessageBodyMember]
        public Merchant Merchant { get; set; }
        [MessageBodyMember]
        public decimal OriginalAmount { get; set; }
        [MessageBodyMember]
        public string AcquirerId { get; set; }
        [MessageBodyMember]
        public string RetrievalReferenceNumber { get; set; }
        [MessageBodyMember]
        public string TerminalIdentifier { get; set; }
        [MessageBodyMember]
        public OriginalTransactionForReversal OriginalTransactionForReversal { get; set; }
        [MessageBodyMember]
        public string ECommerceIndicator { get; set; }
    }

    [MessageContract]
    public class EncryptedCardData
    {
        public EncryptedCardData() { }
        public EncryptedCardData(Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.EncryptedCardData encryptedCardData)
        {
            Version = encryptedCardData.Version;
            EphemeralPublicKey = encryptedCardData.EphemeralPublicKey;
            PublicKeyHash = encryptedCardData.PublicKeyHash;
            Data = encryptedCardData.Data;
        }
        [MessageBodyMember]
        public string Version { get; set; }
        [MessageBodyMember]
        public string EphemeralPublicKey { get; set; }
        [MessageBodyMember]
        public string PublicKeyHash { get; set; }
        [MessageBodyMember]
        public string Data { get; set; }
    }

    [MessageContract]
    public class PosEntryMode
    {
        public PosEntryMode() { }
        public PosEntryMode(Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.PosEntryMode posEntryMode)
        {
            CardInputCapability = posEntryMode.CardInputCapability;
            CardholderAuthenticationCapability = posEntryMode.CardholderAuthenticationCapability;
            CardCaptureCapability = posEntryMode.CardCaptureCapability;
            OperatingEnvironment = posEntryMode.OperatingEnvironment;
            CardholderPresence = posEntryMode.CardholderPresence;
            CardPresence = posEntryMode.CardPresence;
            CardDataInputMode = posEntryMode.CardDataInputMode;
            CardholderAuthenticationMethod = posEntryMode.CardholderAuthenticationMethod;
            CardholderAuthenticationEntity = posEntryMode.CardholderAuthenticationEntity;
            CardDataOutputCapability = posEntryMode.CardDataOutputCapability;
            TerminalOutputCapability = posEntryMode.TerminalOutputCapability;
            PinCaptureCapability = posEntryMode.PinCaptureCapability;

        }

        [MessageBodyMember]
        public string CardInputCapability { get; set; }
        [MessageBodyMember]
        public string CardholderAuthenticationCapability { get; set; }
        [MessageBodyMember]
        public string CardCaptureCapability { get; set; }
        [MessageBodyMember]
        public string OperatingEnvironment { get; set; }
        [MessageBodyMember]
        public string CardholderPresence { get; set; }
        [MessageBodyMember]
        public string CardPresence { get; set; }
        [MessageBodyMember]
        public string CardDataInputMode { get; set; }
        [MessageBodyMember]
        public string CardholderAuthenticationMethod { get; set; }
        [MessageBodyMember]
        public string CardholderAuthenticationEntity { get; set; }
        [MessageBodyMember]
        public string CardDataOutputCapability { get; set; }
        [MessageBodyMember]
        public string TerminalOutputCapability { get; set; }
        [MessageBodyMember]
        public string PinCaptureCapability { get; set; }
    }

    [MessageContract]
    public class Merchant
    {
        public Merchant() { }
        public Merchant(Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.Merchant merchant)
        {
            MerchantId = merchant.MerchantId;
            MerchantName = merchant.MerchantName;
            MerchantIndustryCode = merchant.MerchantIndustryCode;
            MerchantIndustryCategory = merchant.MerchantIndustryCategory;
            MerchantIndustryDescription = merchant.MerchantIndustryDescription;
            AddressLine1 = merchant.AddressLine1;
            City = merchant.City;
            PostalCode = merchant.PostalCode;
            StateProvReg = merchant.StateProvReg;
            Country = merchant.Country;
        }

        public string MerchantId { get; set; }
        public string MerchantName { get; set; }
        public string MerchantIndustryCode { get; set; }
        public string MerchantIndustryCategory { get; set; }
        public string MerchantIndustryDescription { get; set; }
        public string AddressLine1 { get; set; }
        public string City { get; set; }
        public string PostalCode { get; set; }
        public string StateProvReg { get; set; }
        public string Country { get; set; }
    }

    [MessageContract]
    public class OriginalTransactionForReversal
    {
        public OriginalTransactionForReversal() { }
        public OriginalTransactionForReversal(Gd.Bos.Shared.Common.Core.CoreApi.Contract.Message.Request.OriginalTransactionForReversal originalTransactionForReversal)
        {
            MessageType = originalTransactionForReversal.MessageType;
            SystemTraceNumber = originalTransactionForReversal.SystemTraceNumber;
            LocalDateTime = originalTransactionForReversal.LocalDateTime;
            AcquirerId = originalTransactionForReversal.AcquirerId;
        }
        public string MessageType { get; set; }
        public string SystemTraceNumber { get; set; }
        public string LocalDateTime { get; set; }
        public string AcquirerId { get; set; }
    }
}
