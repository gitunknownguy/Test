﻿using System.Diagnostics.CodeAnalysis;
using System.ServiceModel;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class VerifyPinResponse : ResponseBase
    {
        [MessageBodyMember]
        public string AccountIdentifier { get; set; }

        [MessageBodyMember]
        public string PaymentInstrumentIdentifier { get; set; }

        [MessageBodyMember]
        public bool IsPinValid { get; set; }
    }
}