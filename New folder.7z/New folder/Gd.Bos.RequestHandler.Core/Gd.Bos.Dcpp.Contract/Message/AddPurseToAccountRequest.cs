﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.ServiceModel;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class AddPurseToAccountRequest : RequestBase
    {
        [MessageBodyMember]
        [Required]
        public string AccountIdentifier { get; set; }

        [MessageBodyMember]
        public string UserDescription { get; set; }

        [MessageBodyMember]
        public string PurseType { get; set; }

        [MessageBodyMember]
        public decimal? GoalAmount { get; set; }

        [MessageBodyMember]
        public string GoalDate { get; set; }

        [MessageBodyMember]
        public string IconName { get; set; }

        [MessageBodyMember]
        public string PurseSubType { get; set; }
    }
}