﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.ServiceModel;
using Gd.Bos.Dcpp.Contract.Data;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class ValidateCVVRequest : RequestBase
    {
        [MessageBodyMember]
        [Required]
        public string AccountIdentifier { get; set; }

        [MessageBodyMember]
        [Required]
        public string Pan { get; set; }

        [MessageBodyMember]
        [Required]
        public ExpirationDate ExpirationDate { get; set; }


        [MessageBodyMember]
        [Required]
        [StringLength(3)]
        [RegularExpression(@"\d{3}", ErrorMessage = "CVV must be a 3-digit number.")]
        public string CVV { get; set; }

        [MessageBodyMember]
        public bool UsePan { get; set; }
    }
}
