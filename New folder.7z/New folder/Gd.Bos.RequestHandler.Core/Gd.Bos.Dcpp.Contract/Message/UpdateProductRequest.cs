﻿using System.Diagnostics.CodeAnalysis;
using System.ServiceModel;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class UpdateProductRequest : RequestBase
    {
        [MessageBodyMember]
        public string AccountIdentifier { get; set; }
        [MessageBodyMember]
        public int ProductTierKey { get; set; }
        [MessageBodyMember]
        public string ProductMaterialType { get; set; }
        [MessageBodyMember]
        public string CardStock { get; set; }
    }
}
