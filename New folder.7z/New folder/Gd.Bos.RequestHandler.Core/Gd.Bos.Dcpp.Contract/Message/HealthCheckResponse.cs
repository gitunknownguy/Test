﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.ServiceModel;
using Gd.Bos.Dcpp.Contract.Data;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class HealthCheckResponse : ResponseBase
    {
        [MessageBodyMember]
        [Required]
        public HealthCheck HealthCheck { get; set; }
    }
}
