﻿using System.ServiceModel;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class AuthorizePaymentResponse : ResponseBase
    {
        [MessageBodyMember]
        public string MessageType { get; set; }
        [MessageBodyMember]
        public string PaymentInstrumentIdentifier { get; set; }
        [MessageBodyMember]
        public string TransactionIdentifier { get; set; }
        [MessageBodyMember]
        public string SystemTraceNumber { get; set; }
        [MessageBodyMember]
        public string RetrievalReferenceNumber { get; set; }
        [MessageBodyMember]
        public decimal? TransactionAmount { get; set; }
        [MessageBodyMember]
        public string TransactionCurrency { get; set; }
        [MessageBodyMember]
        public string ApprovalCode { get; set; }
        [MessageBodyMember]
        public string ActionCode { get; set; }
        [MessageBodyMember]
        public decimal? AdditionalAmount { get; set; }
        [MessageBodyMember]
        public PntResponseDetails ResponseDetails { get; set; }
    }
}
