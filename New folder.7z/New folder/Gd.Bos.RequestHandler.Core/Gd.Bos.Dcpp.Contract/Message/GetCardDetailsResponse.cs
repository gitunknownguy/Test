﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.ServiceModel;
using Gd.Bos.Dcpp.Contract.Data;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class GetCardDetailsResponse : ResponseBase
    {
        [MessageBodyMember]
        [Required]
        public string CardNumber { get; set; }

        [MessageBodyMember]
        [Required]
        public ExpirationDate Expiration { get; set; }

        [MessageBodyMember]
        [Required]
        public string Cvv { get; set; }
    }
}
