﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [DataContract]
    public class RequestHeader
    {
        [DataMember]
        public Guid RequestId { get; set; }

        [DataMember]
        public string Source { get; set; }

        [DataMember]
        public Dictionary<string, string> Options { get; set; } = new();
    }
}
