﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.ServiceModel;
using Gd.Bos.Dcpp.Contract.Data;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class GetCardDetailsRequest : RequestBase
    {
        [MessageBodyMember]
        [Required]
        public string AccountId { get; set; }

        [MessageBodyMember]
        public ExpirationDate Expiration { get; set; }

        [MessageBodyMember]
        public Guid? PaymentIdentifierIdentifier { get; set; }
    }
}
