﻿using System.Diagnostics.CodeAnalysis;

namespace Gd.Bos.Dcpp.Contract.Message
{
    public class ReportLostStolenV2Response : ReportLostStolenResponse
    {
    }
}
