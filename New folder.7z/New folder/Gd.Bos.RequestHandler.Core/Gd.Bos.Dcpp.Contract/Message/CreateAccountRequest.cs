﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.ServiceModel;
using Gd.Bos.Dcpp.Contract.Data;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class CreateAccountRequest : RequestBase
    {
        [MessageBodyMember]
        [Required]
        public string AccountIdentifier { get; set; }

        [MessageBodyMember]
        [Required]
        public string UserIdentifier { get; set; }

        [MessageBodyMember]
        public List<string> AdditionalUserIdentifiers { get; set; }

        [MessageBodyMember]
        [Required]
        public string ProductCode { get; set; }

        [MessageBodyMember]
        [Required]
        public int ProductTierKey { get; set; }

        [MessageBodyMember]
        [Required]
        public string PhysicalCardType { get; set; }

        [MessageBodyMember]
        [Required]
        public bool Personalized { get; set; }

        [MessageBodyMember]
        public PostalAddress PostalAddress { get; set; }

        [MessageBodyMember]
        public CardholderName CardholderName { get; set; }

        [MessageBodyMember]
        public DateOfBirth DateOfBirth { get; set; }

        [MessageBodyMember]
        public string Ssn { get; set; }

        [MessageBodyMember]
        public List<PhoneNumber> PhoneNumbers { get; set; }

        [MessageBodyMember]
        public string ProductMaterialType { get; set; }

        [MessageBodyMember]
        public bool IsVirtualTierAllowed { get; set; }

        [MessageBodyMember]
        public string BusinessName { get; set; }

        [MessageBodyMember]
        public string EmbossName { get; set; }

        [MessageBodyMember]
        public string AccountNumber { get; set; }

        [MessageBodyMember]
        public int ExpirationMonths { get; set; }

        [MessageBodyMember]
        public int ExpirationRandomMonths { get; set; }

        [MessageBodyMember]
        public string RoutingNumber { get; set; }
    }
}
