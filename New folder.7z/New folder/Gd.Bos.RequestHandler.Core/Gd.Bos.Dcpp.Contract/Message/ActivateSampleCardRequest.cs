﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.ServiceModel;
using System.Text;
using Gd.Bos.Dcpp.Contract.Message;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class ActivateSampleCardRequest : RequestBase
    {
        [MessageBodyMember]
        [Required]
        public string AccountIdentifier { get; set; }

        [MessageBodyMember]
        [Required]
        public string CardProxy { get; set; }

        [MessageBodyMember]
        [Required]
        public bool? IsEmv { get; set; }

        [MessageBodyMember]
        [Required]
        public string CardStockCode { get; set; }

        [MessageBodyMember]
        [Required]
        public string EmbossedName { get; set; }

        [MessageBodyMember]
        public string Source { get; set; }

        [MessageBodyMember]
        public string AccountNumber { get; set; }

        [MessageBodyMember]
        public string ProductCode { get; set; }
    }
}
