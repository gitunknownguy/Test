﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.ServiceModel;
using Gd.Bos.Dcpp.Contract.Data;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class UpdateAccountRequest : RequestBase
    {
        [MessageBodyMember]
        [Required]
        public string AccountIdentifier { get; set; }

        [MessageBodyMember]
        public PostalAddress PostalAddress { get; set; }

        [MessageBodyMember]
        public List<PhoneNumber> PhoneNumbers { get; set; }

        [MessageBodyMember]
        public string EmailAddress { get; set; }

        [MessageBodyMember]
        public CardholderName Name { get; set; }

        [MessageBodyMember]
        public string BusinessName { get; set; }

        [MessageBodyMember]
        public Guid? PaymentIdentifierIdentifier { get; set; }

        [MessageBodyMember]
        public List<Guid> HomeAddressUpdateUsers { get; set; }

    }
}
