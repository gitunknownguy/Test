﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;
using System.ServiceModel;
using Gd.Bos.Dcpp.Contract.Enum;
using Newtonsoft.Json;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class ReportLostStolenRequest : RequestBase
    {
        [MessageBodyMember]
        [Required]
        public string AccountIdentifier { get; set; }

        [MessageBodyMember]
        [Required]
        public string PaymentInstrumentIdentifier { get; set; }

        [MessageBodyMember]
        public string DeliveryMethod { get; set; }

        [MessageBodyMember]
        public string ProductMaterialType { get; set; }

        [MessageBodyMember]
        public string LossType { get; set; }

        [MessageBodyMember]
        public string DateLastUsed { get; set; }

        [MessageBodyMember]
        public string DateDiscoveredMissing { get; set; }

        [MessageBodyMember]
        public bool? PoliceNotified { get; set; }

        [MessageBodyMember]
        public string Notes { get; set; }

        [MessageBodyMember]
        public string CustomCardImageIdentifier { get; set; }
        [MessageBodyMember]
        public int ProductTierKey { get; set; }
    }
}