﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.ServiceModel;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class OrderCardRequest : RequestBase
    {
        [MessageBodyMember]
        [Required]
        public string AccountIdentifier { get; set; }

        [MessageBodyMember]
        [Required]
        public string PaymentIdentifierIdentifier { get; set; }

        [MessageBodyMember]
        public string PaymentInstrumentIdentifier { get; set; }

        [MessageBodyMember]
        public string ReplacementReason { get; set; }

        [MessageBodyMember]
        public string DeliveryMethod { get; set; }

        [MessageBodyMember]
        public string ProductMaterialType { get; set; }

        [MessageBodyMember]
        public bool Override10DayLimit { get; set; }

        [MessageBodyMember]
        public string CustomCardImageIdentifier { get; set; }

        [MessageBodyMember]
        public Gd.Bos.Shared.Common.Core.CoreApi.Contract.Data.Enum.LossType Losstype { get; set; }
        [MessageBodyMember]
        public string Source { get; set; }
    }
}
