﻿using System.Diagnostics.CodeAnalysis;
using System.ServiceModel;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class GetPurchaseStatusRequest : RequestBase
    {
    }
}
