﻿using System.Diagnostics.CodeAnalysis;
using System.ServiceModel;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class ReportLostStolenResponse : ResponseBase
    {
        [MessageBodyMember]
        public string AccountIdentifier { get; set; }

        [MessageBodyMember]
        public string PaymentIdentifierIdentifier { get; set; }

        [MessageBodyMember]
        public string PaymentInstrumentIdentifier { get; set; }

        [MessageBodyMember]
        public string PhysicalPaymentInstrumentIdentifier { get; set; }
    }
}