﻿using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;
using Gd.Bos.Dcpp.Contract.Data;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [DataContract]
    public class ResponseHeader
    {
        [DataMember]
        public string StatusCode { get; set; }

        [DataMember]
        public ErrorInfo ErrorInfo { get; set; }
    }
}
