﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.ServiceModel;

namespace Gd.Bos.Dcpp.Contract.Message
{
    [MessageContract]
    public class ChangeAccountStatusRequest : RequestBase
    {
        [MessageBodyMember]
        [Required]
        public string AccountId { get; set; }

        [MessageBodyMember]
        public string Status { get; set; }

        [MessageBodyMember]
        public string GdAccountStatus { get; set; }
    }
}
