﻿using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Gd.Bos.Dcpp.Contract.Enum
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum PurseType
    {
        [EnumMember(Value = "primary")]
        Primary = 1,
        [EnumMember(Value = "savings")]
        Savings = 2,
        [EnumMember(Value = "holding")]
        Holding = 3,
        [EnumMember(Value = "multran")]
        Multran = 4,
        [EnumMember(Value = "loan")]
        Loan = 5
    }
}