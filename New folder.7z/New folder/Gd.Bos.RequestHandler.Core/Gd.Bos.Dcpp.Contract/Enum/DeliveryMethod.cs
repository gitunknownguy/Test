﻿namespace Gd.Bos.Dcpp.Contract.Enum
{
    public enum DeliveryMethod
    {
        Regular = 1,
        Rush = 2,
        Overnight = 3,
        USPSExpeditedOvernight = 4
    }
}
