﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Gd.Bos.Dcpp.Contract.Enum
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum PurseStatus
    {
        [EnumMember(Value = "active")]
        Active = 1,
        [EnumMember(Value = "closed")]
        Closed = 2,
        [EnumMember(Value = "purged")]
        Purged = 3
    }
}
