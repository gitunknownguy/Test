﻿using System.Runtime.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Gd.Bos.Dcpp.Contract.Enum
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum ReplacementReason
    {
        [EnumMember(Value = "newCard")]
        NewCard,
        [EnumMember(Value = "neverReceived")]
        NeverReceived,
        [EnumMember(Value = "damaged")]
        Damaged,
        [EnumMember(Value = "upgrade")]
        Upgrade,
        [EnumMember(Value = "nameChange")]
        NameChange,

        [EnumMember(Value = "virtualCardLostStolenReplacement")]
        VirtualCardLostStolenReplacement
    }
}