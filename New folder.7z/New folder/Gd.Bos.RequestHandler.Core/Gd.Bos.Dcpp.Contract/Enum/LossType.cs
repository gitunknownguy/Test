﻿namespace Gd.Bos.Dcpp.Contract.Enum
{
    public enum LossType
    {
        Lost,
        Stolen,
        UnauthorizedUse,
        Compromised
    }
}
