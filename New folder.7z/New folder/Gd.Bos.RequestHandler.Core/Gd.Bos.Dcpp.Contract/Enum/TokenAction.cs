﻿using System.Runtime.Serialization;

namespace Gd.Bos.Dcpp.Contract.Enum
{
    [DataContract]
    public enum TokenAction
    {
        [EnumMember]
        Activate,
        [EnumMember]
        Suspend,
        [EnumMember]
        Delete,
        [EnumMember]
        UnSuspend
    }
}
