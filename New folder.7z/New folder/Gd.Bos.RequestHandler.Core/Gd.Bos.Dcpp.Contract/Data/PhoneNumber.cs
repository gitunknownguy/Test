﻿using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace Gd.Bos.Dcpp.Contract.Data
{
    [DataContract]
    public class PhoneNumber
    {
        [DataMember]
        public string Number { get; set; }
        [DataMember]
        public PhoneType Type { get; set; }
        [DataMember]
        public bool IsPrimary { get; set; }

    }
}
