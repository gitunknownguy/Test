﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace Gd.Bos.Dcpp.Contract.Data
{
    [DataContract]
    public class ExpirationDate
    {
        [DataMember]
        [Required]
        [StringLength(2)]
        [RegularExpression(@"(0[1-9]|1[0-2])", ErrorMessage = "Month must be a 2-digit number between 01 and 12.")]
        public string Month { get; set; }

        [DataMember]
        [Required]
        [StringLength(4)]
        [RegularExpression(@"\d{4}", ErrorMessage = "Year must be a 4-digit number.")]
        public string Year { get; set; }
    }
}
