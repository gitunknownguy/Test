﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace Gd.Bos.Dcpp.Contract.Data
{
    [DataContract]
    public class HealthCheck
    {
        [DataMember]
        public string ServiceName { get; set; }

        [DataMember]
        public string Status { get; set; }

        [DataMember]
        public string TotalTime { get; set; }

        [DataMember]
        public Dictionary<string, string> WaitTime { get; set; }

        [DataMember]
        public List<HealthCheck> Dependencies { get; set; }
    }
}
