﻿using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace Gd.Bos.Dcpp.Contract.Data
{
    [DataContract]
    public enum ExternalProcessor
    {
        [EnumMember] Pts = 1,
        [EnumMember] Fis = 4,
        [EnumMember] Sim = 2,
    }
}