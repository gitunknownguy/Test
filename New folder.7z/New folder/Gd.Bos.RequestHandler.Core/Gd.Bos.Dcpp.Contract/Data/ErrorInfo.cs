﻿using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace Gd.Bos.Dcpp.Contract.Data
{
    [DataContract]
    public class ErrorInfo
    {
        [DataMember]
        public string Message { get; set; }

        [DataMember]
        public string Details { get; set; }

        [DataMember]
        public string SubStatusCode { get; set; }

        [DataMember]
        public string Source { get; set; }
    }
}
