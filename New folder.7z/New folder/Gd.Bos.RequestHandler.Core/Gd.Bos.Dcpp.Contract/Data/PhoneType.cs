﻿using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Gd.Bos.Dcpp.Contract.Data
{
    [DataContract]
    public enum PhoneType
    {
        [EnumMember]
        Home,
        [EnumMember]
        Mobile,
        [EnumMember]
        Work,
        [EnumMember]
        Unspecified
    }
}
