﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace Gd.Bos.Dcpp.Contract.Data
{
    [DataContract]
    public class DateOfBirth
    {
        [DataMember]
        [Required]
        public int Day { get; set; }

        [DataMember]
        [Required]
        public int Month { get; set; }

        [DataMember]
        [Required]
        public int Year { get; set; }
    }
}
