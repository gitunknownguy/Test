﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace Gd.Bos.Dcpp.Contract.Data
{
    [DataContract]
    public class CurrencyAmount
    {
        [DataMember]
        [Required]
        public decimal Amount { get; set; }

        [DataMember]
        [Required]
        public string CurrencyCode { get; set; }
    }
}
