﻿using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace Gd.Bos.Dcpp.Contract.Data
{
    [DataContract]
    public class PostalAddress
    {
        [DataMember]
        public string[] AddressLines { get; set; }

        [DataMember]
        public string City { get; set; }

        [DataMember]
        public string CountrySubdivision { get; set; }

        [DataMember]
        public string County { get; set; }

        [DataMember]
        public string PostalCode { get; set; }

        [DataMember]
        public string Country { get; set; }

        [DataMember]
        public string AddressType { get; set; }
    }
}
