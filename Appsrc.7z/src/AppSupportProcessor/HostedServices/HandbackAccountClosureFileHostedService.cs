﻿using AppSupportProcessor.Business.Handlers;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;

namespace AppSupportProcessor.HostedServices
{
    [ExcludeFromCodeCoverage]
    public class HandbackAccountClosureFileHostedService : IHostedService, IDisposable
    {
        private readonly ILogger<HandbackAccountClosureFileHostedService> _logger;
        private readonly IHandbackAccountClosureFileHandler _handler;
        private readonly IHostApplicationLifetime _hostappLifetime;

        public HandbackAccountClosureFileHostedService(ILogger<HandbackAccountClosureFileHostedService> logger,
            IHandbackAccountClosureFileHandler handler,
            IHostApplicationLifetime hostappLifeTime)
        {
            _logger = logger;
            _handler = handler;
            _hostappLifetime = hostappLifeTime;
        }

        public async Task StartAsync(CancellationToken cancellationToken)
        {
            NLog.MappedDiagnosticsLogicalContext.Set("HostedServiceId", Guid.NewGuid().ToString());
            _logger.LogInformation("Starting hosted HandbackAccountClosureFileHostedService...");
            try
            {
                _hostappLifetime.ApplicationStarted.Register(OnStarted);
                _hostappLifetime.ApplicationStopping.Register(OnStopping);
                _hostappLifetime.ApplicationStopped.Register(OnStopped);

                await _handler.ProcessAsync(cancellationToken);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to start HandbackAccountClosureFileHostedService, see error details {ex}");
            }
            finally
            {
                _hostappLifetime.StopApplication();
            }
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Stopping HandbackAccountClosureFileHostedService...");

            return Task.CompletedTask;
        }
        private void OnStarted()
        {
            _logger.LogInformation("HandbackAccountClosureFileHostedService OnStarted has been called.");
        }

        private void OnStopping()
        {
            _logger.LogInformation("HandbackAccountClosureFileHostedService OnStopping has been called.");
        }

        private void OnStopped()
        {
            _logger.LogInformation("HandbackAccountClosureFileHostedService OnStopped has been called.");
        }

        public void Dispose()
        {
        }
    }
}
