﻿using AppSupportProcessor.Business.Handlers;
using AppSupportProcessor.Common.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AppSupportProcessor.HostedServices
{
    [ExcludeFromCodeCoverage]
    public class ProcessCardTranslationInventoryExceptionRecoveryHostedService : IHostedService, IDisposable
    {
        private readonly ILogger<ProcessCardTranslationInventoryExceptionRecoveryHostedService> _logger;
        private readonly IProcessCardTranslationInventoryExceptionRecoveryHandler _handler;
        private readonly IOptionsMonitor<ProcessCardTranslationInventoryExceptionRecoveryConfiguration> _config;
        private readonly IHostApplicationLifetime _hostappLifetime;

        public ProcessCardTranslationInventoryExceptionRecoveryHostedService(ILogger<ProcessCardTranslationInventoryExceptionRecoveryHostedService> logger, IProcessCardTranslationInventoryExceptionRecoveryHandler handler, IOptionsMonitor<ProcessCardTranslationInventoryExceptionRecoveryConfiguration> config, IHostApplicationLifetime hostappLifeTime)
        {
            _logger = logger;
            _handler = handler;
            _config = config;
            _hostappLifetime = hostappLifeTime;
        }
        public async Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Starting hosted ProcessCardTranslationInventoryExceptionRecoveryHostedService...");
            try
            {
                _hostappLifetime.ApplicationStarted.Register(OnStarted);
                _hostappLifetime.ApplicationStopping.Register(OnStopping);
                _hostappLifetime.ApplicationStopped.Register(OnStopped);

                await _handler.ProcessAsync(cancellationToken);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to start ProcessCardTranslationInventoryExceptionRecoveryHostedService, see error details {ex}");
            }
            finally
            {
                _hostappLifetime.StopApplication();
            }
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Stopping ProcessCardTranslationInventoryExceptionRecoveryHostedService...");

            return Task.CompletedTask;
        }
        private void OnStarted()
        {
            //_logger.LogInformation("ProcessCardTranslationInventoryExceptionRecoveryHostedService OnStarted has been called.");
        }

        private void OnStopping()
        {
            //_logger.LogInformation("ProcessCardTranslationInventoryExceptionRecoveryHostedService OnStopping has been called.");
        }

        private void OnStopped()
        {
            //_logger.LogInformation("ProcessCardTranslationInventoryExceptionRecoveryHostedService OnStopped has been called.");
        }

        public void Dispose()
        {
        }
    }
}
