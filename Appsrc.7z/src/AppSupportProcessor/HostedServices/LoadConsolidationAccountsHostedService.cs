﻿using AppSupportProcessor.Business.Handlers;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;

namespace AppSupportProcessor.HostedServices
{
    [ExcludeFromCodeCoverage]
    public class LoadConsolidationAccountsHostedService : IHostedService, IDisposable
    {
        private readonly ILogger<LoadConsolidationAccountsHostedService> _logger;
        private readonly ILoadConsolidationAccountsHandler _handler;
        private readonly IHostApplicationLifetime _hostappLifetime;

        public LoadConsolidationAccountsHostedService(ILogger<LoadConsolidationAccountsHostedService> logger,
            ILoadConsolidationAccountsHandler handler,
            IHostApplicationLifetime hostappLifeTime)
        {
            _logger = logger;
            _handler = handler;
            _hostappLifetime = hostappLifeTime;
        }

        public async Task StartAsync(CancellationToken cancellationToken)
        {
            NLog.MappedDiagnosticsLogicalContext.Set("HostedServiceId", Guid.NewGuid().ToString());
            _logger.LogInformation("Starting hosted LoadConsolidationAccountsHostedService...");
            try
            {
                _hostappLifetime.ApplicationStarted.Register(OnStarted);
                _hostappLifetime.ApplicationStopping.Register(OnStopping);
                _hostappLifetime.ApplicationStopped.Register(OnStopped);

                await _handler.ProcessAsync(cancellationToken);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to start LoadConsolidationAccountsHostedService, see error details {ex}");
            }
            finally
            {
                _hostappLifetime.StopApplication();
            }
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Stopping LoadConsolidationAccountsHostedService...");

            return Task.CompletedTask;
        }
        private void OnStarted()
        {
            _logger.LogInformation("LoadConsolidationAccountsHostedService OnStarted has been called.");
        }

        private void OnStopping()
        {
            _logger.LogInformation("LoadConsolidationAccountsHostedService OnStopping has been called.");
        }

        private void OnStopped()
        {
            _logger.LogInformation("LoadConsolidationAccountsHostedService OnStopped has been called.");
        }

        public void Dispose()
        {
        }
    }
}
