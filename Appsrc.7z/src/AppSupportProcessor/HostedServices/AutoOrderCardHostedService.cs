﻿using AppSupportProcessor.Business.Handlers;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;

namespace AppSupportProcessor.HostedServices
{
    [ExcludeFromCodeCoverage]
    public class AutoOrderCardHostedService : IHostedService, IDisposable
    {
        private readonly ILogger<AutoOrderCardHostedService> _logger;
        private readonly IAutoOrderCardHandler _handler;
        private readonly IHostApplicationLifetime _hostappLifetime;

        public AutoOrderCardHostedService(ILogger<AutoOrderCardHostedService> logger,
            IAutoOrderCardHandler handler,
            IHostApplicationLifetime hostappLifeTime)
        {
            _logger = logger;
            _handler = handler;
            _hostappLifetime = hostappLifeTime;
        }

        public async Task StartAsync(CancellationToken cancellationToken)
        {
            NLog.MappedDiagnosticsLogicalContext.Set("HostedServiceId", Guid.NewGuid().ToString());
            _logger.LogInformation("Starting hosted AutoOrderCardHostedService...");
            try
            {
                _hostappLifetime.ApplicationStarted.Register(OnStarted);
                _hostappLifetime.ApplicationStopping.Register(OnStopping);
                _hostappLifetime.ApplicationStopped.Register(OnStopped);

                await _handler.ProcessAsync(cancellationToken);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to start AutoOrderCardHostedService, see error details {ex}");
            }
            finally
            {
                _hostappLifetime.StopApplication();
            }
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Stopping AutoOrderCardHostedService...");

            return Task.CompletedTask;
        }
        private void OnStarted()
        {
            _logger.LogInformation("AutoOrderCardHostedService OnStarted has been called.");
        }

        private void OnStopping()
        {
            _logger.LogInformation("AutoOrderCardHostedService OnStopping has been called.");
        }

        private void OnStopped()
        {
            _logger.LogInformation("AutoOrderCardHostedService OnStopped has been called.");
        }

        public void Dispose()
        {
        }
    }
}
