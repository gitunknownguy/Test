﻿using AppSupportProcessor.Business.Handlers;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;

namespace AppSupportProcessor.HostedServices
{
    [ExcludeFromCodeCoverage]
    public class GenerateAccountClosureFileHostedService : IHostedService, IDisposable
    {
        private readonly ILogger<GenerateAccountClosureFileHostedService> _logger;
        private readonly IGenerateAccountClosureFileHandler _handler;
        private readonly IHostApplicationLifetime _hostappLifetime;

        public GenerateAccountClosureFileHostedService(ILogger<GenerateAccountClosureFileHostedService> logger,
            IGenerateAccountClosureFileHandler handler,
            IHostApplicationLifetime hostappLifeTime)
        {
            _logger = logger;
            _handler = handler;
            _hostappLifetime = hostappLifeTime;
        }

        public async Task StartAsync(CancellationToken cancellationToken)
        {
            NLog.MappedDiagnosticsLogicalContext.Set("HostedServiceId", Guid.NewGuid().ToString());
            _logger.LogInformation("Starting hosted GenerateAccountClosureFileHostedService...");
            try
            {
                _hostappLifetime.ApplicationStarted.Register(OnStarted);
                _hostappLifetime.ApplicationStopping.Register(OnStopping);
                _hostappLifetime.ApplicationStopped.Register(OnStopped);

                await _handler.ProcessAsync(cancellationToken);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to start GenerateAccountClosureFileHostedService, see error details {ex}");
            }
            finally
            {
                _hostappLifetime.StopApplication();
            }
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Stopping GenerateAccountClosureFileHostedService...");

            return Task.CompletedTask;
        }
        private void OnStarted()
        {
            _logger.LogInformation("GenerateAccountClosureFileHostedService OnStarted has been called.");
        }

        private void OnStopping()
        {
            _logger.LogInformation("GenerateAccountClosureFileHostedService OnStopping has been called.");
        }

        private void OnStopped()
        {
            _logger.LogInformation("GenerateAccountClosureFileHostedService OnStopped has been called.");
        }

        public void Dispose()
        {
        }
    }
}
