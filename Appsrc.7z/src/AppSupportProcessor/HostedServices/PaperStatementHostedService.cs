﻿using AppSupportProcessor.Business.Handlers;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using NLog;

namespace AppSupportProcessor.HostedServices
{
    public class PaperStatementHostedService : IHostedService, IDisposable
    {
        private readonly ILogger<PaperStatementHostedService> _logger;
        private readonly IPaperStatementHandler _handler;
        private readonly IHostApplicationLifetime _hostappLifetime;

        public PaperStatementHostedService(ILogger<PaperStatementHostedService> logger,
            IPaperStatementHandler handler,
            IHostApplicationLifetime hostappLifeTime)
        {
            _logger = logger;
            _handler = handler;
            _hostappLifetime = hostappLifeTime;
        }
        public async Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Starting hosted PaperStatementHostedService...");
            try
            {
                _hostappLifetime.ApplicationStarted.Register(OnStarted);
                _hostappLifetime.ApplicationStopping.Register(OnStopping);
                _hostappLifetime.ApplicationStopped.Register(OnStopped);

                await _handler.ProcessAsync(cancellationToken);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to start PaperStatementHostedService, see error details {ex}");
            }
            finally
            {
                _hostappLifetime.StopApplication();
            }
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Stopping PaperStatementHostedService...");

            return Task.CompletedTask;
        }
        private void OnStarted()
        {
            _logger.LogInformation("PaperStatementHostedService OnStarted has been called.");
        }

        private void OnStopping()
        {
            _logger.LogInformation("PaperStatementHostedService OnStopping has been called.");
        }

        private void OnStopped()
        {
            _logger.LogInformation("PaperStatementHostedService OnStopped has been called.");
        }

        public void Dispose()
        {
        }
    }
}
