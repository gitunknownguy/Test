﻿using AppSupportProcessor.Business.Handlers;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AppSupportProcessor.HostedServices
{
    [ExcludeFromCodeCoverage]
    public class PingHostedService : IHostedService, IDisposable
    {
        private readonly ILogger<PingHostedService> _logger;
        private readonly IPingServiceHandler _handler;
        // private readonly IOptionsMonitor<InitializeCardTranslationInventoryExceptionRecoveryConfiguration> _config;
        private readonly IHostApplicationLifetime _hostappLifetime;

        public PingHostedService(
            ILogger<PingHostedService> logger,
            IPingServiceHandler handler,
            IHostApplicationLifetime hostappLifeTime)
        {
            _logger = logger;
            _handler = handler;
            //_config = config;
            _hostappLifetime = hostappLifeTime;
        }

        public void Dispose()
        {
           
        }

        public async Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Starting hosted PingHostService...");
            try
            {
                _hostappLifetime.ApplicationStarted.Register(OnStarted);
                _hostappLifetime.ApplicationStopping.Register(OnStopping);
                _hostappLifetime.ApplicationStopped.Register(OnStopped);

                await _handler.ProcessAsync(cancellationToken);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to start PingHostService, see error details {ex}");
            }
            finally
            {
                _hostappLifetime.StopApplication();
            }
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Stopping PingHostService...");

            return Task.CompletedTask;
        }


          private void OnStarted()
        {
            //_logger.LogInformation("InitializeCardTranslationInventoryExceptionRecoveryHostedService OnStarted has been called.");
        }

        private void OnStopping()
        {
            //_logger.LogInformation("InitializeCardTranslationInventoryExceptionRecoveryHostedService OnStopping has been called.");
        }

        private void OnStopped()
        {
            //_logger.LogInformation("InitializeCardTranslationInventoryExceptionRecoveryHostedService OnStopped has been called.");
        }
    }
}
