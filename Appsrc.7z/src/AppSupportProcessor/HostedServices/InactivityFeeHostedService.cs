﻿using AppSupportProcessor.Business.Handlers;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static AppSupportProcessor.Business.Handlers.InactivityFeeHandler;

namespace AppSupportProcessor.HostedServices
{
    public class InactivityFeeHostedService : IHostedService, IDisposable
    {
        private readonly ILogger<InactivityFeeHostedService> _logger;
        private readonly IInactivityFeeHandler _handler;
        private readonly IHostApplicationLifetime _hostappLifetime;

        public InactivityFeeHostedService(ILogger<InactivityFeeHostedService> logger,
            IInactivityFeeHandler handler,
            IHostApplicationLifetime hostappLifeTime)
        {
            _logger = logger;
            _handler = handler;
            _hostappLifetime = hostappLifeTime;
        }
        public async Task StartAsync(CancellationToken cancellationToken)
        {
            NLog.MappedDiagnosticsLogicalContext.Set("HostedServiceId", Guid.NewGuid().ToString());
            _logger.LogInformation("Starting hosted InactivityFeeHostedService...");
            try
            {
                _hostappLifetime.ApplicationStarted.Register(OnStarted);
                _hostappLifetime.ApplicationStopping.Register(OnStopping);
                _hostappLifetime.ApplicationStopped.Register(OnStopped);

                await _handler.ProcessAsync(cancellationToken);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to start InactivityFeeHostedService, see error details {ex}");
            }
            finally
            {
                _hostappLifetime.StopApplication();
            }
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Stopping InactivityFeeHostedService...");

            return Task.CompletedTask;
        }
        private void OnStarted()
        {
            _logger.LogInformation("InactivityFeeHostedService OnStarted has been called.");
        }

        private void OnStopping()
        {
            _logger.LogInformation("InactivityFeeHostedService OnStopping has been called.");
        }

        private void OnStopped()
        {
            _logger.LogInformation("InactivityFeeHostedService OnStopped has been called.");
        }

        public void Dispose()
        {
        }
    }
}
