﻿using AppSupportProcessor.Business.Handlers;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AppSupportProcessor.HostedServices
{
    public class PaperStatementConfirmationHostedService : IHostedService, IDisposable
    {
        private readonly ILogger<PaperStatementConfirmationHostedService> _logger;
        private readonly IPaperStatementConfirmationHandler _handler;
        private readonly IHostApplicationLifetime _hostAppLifetime;

        public PaperStatementConfirmationHostedService(ILogger<PaperStatementConfirmationHostedService> logger,
            IPaperStatementConfirmationHandler handler,
            IHostApplicationLifetime hostAppLifeTime)
        {
            _logger = logger;
            _handler = handler;
            _hostAppLifetime = hostAppLifeTime;
        }

        public async Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Starting hosted PaperStatementConfirmationHostedService...");
            try
            {
                _hostAppLifetime.ApplicationStarted.Register(OnStarted);
                _hostAppLifetime.ApplicationStopping.Register(OnStopping);
                _hostAppLifetime.ApplicationStopped.Register(OnStopped);

                await _handler.ProcessAsync(cancellationToken);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to start PaperStatementConfirmationHostedService, see error details {ex}");
            }
            finally
            {
                _hostAppLifetime.StopApplication();
            }
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Stopping PaperStatementConfirmationHostedService...");

            return Task.CompletedTask;
        }

        private void OnStarted()
        {
            _logger.LogInformation("PaperStatementConfirmationHostedService OnStarted has been called.");
        }

        private void OnStopping()
        {
            _logger.LogInformation("PaperStatementConfirmationHostedService OnStopping has been called.");
        }

        private void OnStopped()
        {
            _logger.LogInformation("PaperStatementConfirmationHostedService OnStopped has been called.");
        }

        public void Dispose()
        {
        }
    }
}
