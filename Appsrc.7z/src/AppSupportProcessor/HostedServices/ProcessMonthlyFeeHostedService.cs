﻿using AppSupportProcessor.Business.Handlers;
using AppSupportProcessor.Common.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;

namespace AppSupportProcessor.HostedServices
{
    [ExcludeFromCodeCoverage]
    public class ProcessMonthlyFeeHostedService : IHostedService, IDisposable
    {
        private readonly ILogger<ProcessMonthlyFeeHostedService> _logger;
        private readonly IProcessMonthlyFeeHandler _handler;
        private readonly IOptionsMonitor<ProcessMonthlyFeeConfiguration> _config;
        private readonly IHostApplicationLifetime _hostappLifetime;

        public ProcessMonthlyFeeHostedService(
            ILogger<ProcessMonthlyFeeHostedService> logger, 
            IProcessMonthlyFeeHandler handler, 
            IOptionsMonitor<ProcessMonthlyFeeConfiguration> config, 
            IHostApplicationLifetime hostappLifeTime)
        {
            _logger = logger;
            _handler = handler;
            _config = config;
            _hostappLifetime = hostappLifeTime;
        }

        public void Dispose()
        {
        }

        public async Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Starting hosted ProcessMonthlyFeeHostedService...");
            try
            {
                _hostappLifetime.ApplicationStarted.Register(OnStarted);
                _hostappLifetime.ApplicationStopping.Register(OnStopping);
                _hostappLifetime.ApplicationStopped.Register(OnStopped);

                await _handler.ProcessAsync(cancellationToken);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to start ProcessMonthlyFeeHostedService, see error details {ex}");
            }
            finally
            {
                _hostappLifetime.StopApplication();
            }
        }

        public async Task StopAsync(CancellationToken cancellationToken)
        {
            await Task.CompletedTask;
        }

        private void OnStarted()
        {
            //_logger.LogInformation("InitializeCardTranslationInventoryExceptionRecoveryHostedService OnStarted has been called.");
        }

        private void OnStopping()
        {
            //_logger.LogInformation("InitializeCardTranslationInventoryExceptionRecoveryHostedService OnStopping has been called.");
        }

        private void OnStopped()
        {
            //_logger.LogInformation("InitializeCardTranslationInventoryExceptionRecoveryHostedService OnStopped has been called.");
        }
    }
}