﻿using AppSupportProcessor.Bootstrapper;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;

namespace AppSupportProcessor
{
    [ExcludeFromCodeCoverage]
    class Program
    {
        static async Task Main(string[] args)
        {
            await ServiceBootstrapper.RunApplicationAsync(args);
        }
    }
}
