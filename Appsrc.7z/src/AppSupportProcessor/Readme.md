﻿# Prospect Procesor Readme Document

## command line

### AppSupportProcessor_LoadBIFile
dotnet.exe C:\GDC\Utils\${Environment}\AppSupportProcessor\AppSupportProcessor.dll ${Environment} --AppSupportProcessor:HostedService="InitializeCardTranslationInventoryExceptionRecoveryHostedService"
dotnet.exe C:\GDC\Utils\${Environment}\AppSupportProcessor\AppSupportProcessor.dll ${Environment} --AppSupportProcessor:HostedService="ProcessCardTranslationInventoryExceptionRecoveryHostedService"
