﻿using AppSupportProcessor.Business.Handlers;
using AppSupportProcessor.Business.LegacyApi;
using AppSupportProcessor.Business.Logic;
using AppSupportProcessor.DataAccess.Base;
using AppSupportProcessor.DataAccess.Repositories;
using Autofac;
using System.Diagnostics.CodeAnalysis;
using AppSupportProcessor.DataAccess.DataAccesses;
using Gd.Aop.Common;

namespace AppSupportProcessor.Modules
{
    [ExcludeFromCodeCoverage]
    public class AppSupportHostedServiceModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterAssemblyTypes(typeof(RepositoryBase).Assembly)
                .Where(t => t.Name.EndsWith("Repository"))
                .AsImplementedInterfaces();

            builder.RegisterType<InitializeCardTranslationInventoryExceptionRecoveryHandler>()
                .As<IInitializeCardTranslationInventoryExceptionRecoveryHandler>();

            builder.RegisterType<PingServiceHandler>()
                .As<IPingServiceHandler>();

            builder.RegisterType<ProcessCardTranslationInventoryExceptionRecoveryHandler>()
                .As<IProcessCardTranslationInventoryExceptionRecoveryHandler>();

            builder.RegisterType<InterestReimbursementHandler>()
                .As<IInterestReimbursementHandler>();

            builder.RegisterType<MMSDepositAccountRepository>()
            .As<IMMSDepositAccountRepository>();

            builder.RegisterType<InterestPayHandler>()
                .As<IInterestPayHandler>();

            builder.RegisterType<PaperStatementHandler>()
                .As<IPaperStatementHandler>();

            builder.RegisterType<PaperStatementFileHandler>()
                .As<IPaperStatementFileHandler>();

            builder.RegisterType<PaperStatementConfirmationHandler>()
                .As<IPaperStatementConfirmationHandler>();

            builder.RegisterType<Paper1099IntHandler>()
                .As<IPaper1099IntHandler>();

            builder.RegisterType<BackFillBcdForLegacyDdaAccountsHandler>()
                .As<IBackFillBcdForLegacyDdaAccountsHandler>();

            builder.RegisterType<ProcessMonthlyFeeHandler>()
                .As<IProcessMonthlyFeeHandler>();

            builder.RegisterType<InitialActivityHandler>()
                .As<IInitialActivityHandler>();

            builder.RegisterType<ActivityHandler>().As<IActivityHandler>();

            builder.RegisterType<RetryActivityHandler>().As<IRetryActivityHandler>();

            builder.RegisterType<ProcessorTransmissionRepository>()
            .As<IProcessorTransmissionRepository>();

            builder.RegisterType<AgreementRepository>()
            .As<IAgreementRepository>();

            builder.RegisterType<AccountManagementReposity>()
            .As<IAccountManagementReposity>();

            builder.RegisterType<SOAV3CardRepository>()
            .As<ISOAV3CardRepository>();

            builder.RegisterType<CardAccountTransactionServiceRepository>()
                .As<ICardAccountTransactionServiceRepository>();

            builder.RegisterType<FundTransferRepository>()
            .As<IFundTransferRepository>();

            builder.RegisterType<SavingsAccountServiceReposity>()
            .As<ISavingsAccountServiceReposity>();

            builder.RegisterType<MemoryCacheClient>()
            .As<ICache>();

            builder.RegisterType<CRMRepository>()
           .As<ICRMRepository>();

            builder.RegisterType<NotifyApiRepository>()
            .As<INotifyApiRepository>();

            builder.RegisterType<LoadConsolidationAccountsHandler>()
           .As<ILoadConsolidationAccountsHandler>();

            builder.RegisterType<AutoOrderCardHandler>()
            .As<IAutoOrderCardHandler>();

            builder.RegisterType<ConsolidationFileService>()
           .As<IConsolidationFileService>();

            builder.RegisterType<AutoOrderCardFileService>()
            .As<IAutoOrderCardFileService>();

            builder.RegisterType<ExcludeTestAccountService>()
                .As<IExcludeTestAccountService>();

            builder.RegisterAop<INecDataAccess, NecDataAccess>();
            builder.RegisterAop<INrtDataAccess, NrtDataAccess>();
            builder.RegisterAop<IReportDataAccess, ReportDataAccess>();
            builder.RegisterAop<ICarePDFMergeAPIRepository, CarePDFMergeAPIRepository>();

            builder.RegisterType<GenerateAccountClosureFileHandler>().As<IGenerateAccountClosureFileHandler>();
            builder.RegisterType<HandbackAccountClosureFileHandler>().As<IHandbackAccountClosureFileHandler>();

            builder.RegisterType<AccountClosureFileService>().As<IAccountClosureFileService>();

            builder.RegisterType<InactivityFeeHandler>().As<IInactivityFeeHandler>();
        }
    }
}
