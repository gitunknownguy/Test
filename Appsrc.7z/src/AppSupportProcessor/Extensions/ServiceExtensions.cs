﻿using AppSupportProcessor.Common.Configuration;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Diagnostics.CodeAnalysis;

namespace AppSupportProcessor.Extensions
{
    [ExcludeFromCodeCoverage]
    public static class ServiceExtensions
    {
        public static IServiceCollection AddAppSupportProcessorConfiguration(this IServiceCollection services, IConfiguration configuration)
            => services.Configure<AppSupportProcessorConfiguration>(configuration.GetSection("AppSupportProcessor"));

        public static IServiceCollection AddInitializeCardTranslationInventoryExceptionRecoveryConfiguration(this IServiceCollection services, IConfiguration configuration)
            => services.Configure<InitializeCardTranslationInventoryExceptionRecoveryConfiguration>(configuration.GetSection("InitializeCardTranslationInventoryExceptionRecovery"));
        public static IServiceCollection AddProcessCardTranslationInventoryExceptionRecoveryConfiguration(this IServiceCollection services, IConfiguration configuration)
            => services.Configure<ProcessCardTranslationInventoryExceptionRecoveryConfiguration>(configuration.GetSection("ProcessCardTranslationInventoryExceptionRecovery"));

        public static IServiceCollection AddInterestReimbursementConfiguration(this IServiceCollection services, IConfiguration configuration)
            => services.Configure<InterestReimbursementConfiguration>(configuration.GetSection("InterestReimbursement"));

        public static IServiceCollection AddInterestPayConfiguration(this IServiceCollection services, IConfiguration configuration)
          => services.Configure<InterestPayConfiguration>(configuration.GetSection("InterestPay"));

        public static IServiceCollection AddPaperStatementConfiguration(this IServiceCollection services, IConfiguration configuration)
          => services.Configure<PaperStatementConfiguration>(configuration.GetSection("PaperStatement"));

        public static IServiceCollection AddPaperStatementFileConfiguration(this IServiceCollection services, IConfiguration configuration)
            => services.Configure<PaperStatementFileConfiguration>(configuration.GetSection("PaperStatementFile"));

        public static IServiceCollection AddPaperStatementConfirmationConfiguration(this IServiceCollection services, IConfiguration configuration)
            => services.Configure<PaperStatementConfirmationConfiguration>(configuration.GetSection("PaperStatementConfirmation"));

        public static IServiceCollection AddPaper1099IntConfiguration(this IServiceCollection services, IConfiguration configuration)
            => services.Configure<Paper1099IntConfiguration>(configuration.GetSection("Paper1099Int"));

        public static IServiceCollection AddProcessMonthlyFeeConfiguration(this IServiceCollection services, IConfiguration configuration)
          => services.Configure<ProcessMonthlyFeeConfiguration>(configuration.GetSection("ProcessMonthlyFee"));

        public static IServiceCollection AddInitialActivityConfiguration(this IServiceCollection services, IConfiguration configuration)
          => services.Configure<ConsolidationConfiguration>(configuration.GetSection("Consolidation"));

        public static IServiceCollection AddAutoOrderCardConfiguration(this IServiceCollection services, IConfiguration configuration)
        => services.Configure<AutoOrderCardConfiguration>(configuration.GetSection("AutoOrderCard"));

        public static IServiceCollection AddBackFillBillCycleForLegacyDDAAccountsConfiguration(this IServiceCollection services, IConfiguration configuration)
            => services.Configure<BackfillBCDForLegacyDDAAccountsConfiguration>(configuration.GetSection("BackFillBillCycleForLegacyDDAAccounts"));

        public static IServiceCollection AddAccountClosureConfiguration(this IServiceCollection services, IConfiguration configuration)
          => services.Configure<AccountClosureConfiguration>(configuration.GetSection("AccountClosure"));

        public static IServiceCollection AddInactivityFeeConfiguration(this IServiceCollection services, IConfiguration configuration)
          => services.Configure<InactivityFeeConfiguration>(configuration.GetSection("InactivityFee"));
    }
}
