﻿using NLog;
using NLog.Web;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;

namespace AppSupportProcessor.Bootstrapper
{
    [ExcludeFromCodeCoverage]
    internal abstract class ServiceBootstrapper
    {
        internal static async Task RunApplicationAsync(string[] args)
        {
            var logger = NLogBuilder.ConfigureNLog("nlog.config").GetCurrentClassLogger();

            try
            {
                ScopeContext.PushProperty("CorrelationId", Guid.NewGuid());

                logger.Debug($"init main.Additional args from command line:{string.Join(',',args)}");

                ServiceBootstrapper bootstrapper = new GenericHostBootstrapper(FilterArguments(args), runAsConsole: true);
                
                await bootstrapper.RunAsync();
            }
            catch (OperationCanceledException)
            {
                logger.Info("Application stopped as hosted service is requested to shut down.");
            }
            catch (Exception ex)
            {
                logger.Error(ex, "Stopped program because of exception");
                throw;
            }
            finally
            {
                NLog.LogManager.Shutdown();
            }
        }

        protected abstract Task RunAsync();

        private static string[] FilterArguments(string[] args)
            => args.Where(arg => arg != "--run-as-console").ToArray();
    }
}
