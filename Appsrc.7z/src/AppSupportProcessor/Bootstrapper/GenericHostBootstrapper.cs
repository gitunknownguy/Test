﻿using AppSupportProcessor.Extensions;
using AppSupportProcessor.Modules;
using Autofac;
using Autofac.Extensions.DependencyInjection;
using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using NLog.Web;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using AppSupportProcessor.HostedServices;
using AutoMapper.Configuration;
using System.Net.Http;
using System.Net;
using AppSupportProcessor.Business.Handlers;
using Gd.Aop.Common;
using Gd.Logging.Common;

namespace AppSupportProcessor.Bootstrapper
{
    [ExcludeFromCodeCoverage]
    internal class GenericHostBootstrapper : ServiceBootstrapper
    {
        private readonly string[] _args;
        private readonly bool _runAsConsole;

        internal GenericHostBootstrapper(string[] args, bool runAsConsole = false)
        {
            _args = args;
            _runAsConsole = runAsConsole;
        }

        protected override async Task RunAsync()
        {
            var hostBuilder = CreateGenericHostBuilder();
            await hostBuilder.RunConsoleAsync();
        }

        private IHostBuilder CreateGenericHostBuilder()
            => new HostBuilder()
                .UseEnvironment(GetEnvironment(_args))
                .UseServiceProviderFactory(new AutofacServiceProviderFactory())
                .ConfigureHostConfiguration(ConfigureHostConfiguration)
                .ConfigureAppConfiguration(ConfigureAppConfiguration)
                .ConfigureServices(ConfigureServices)
                .ConfigureContainer<ContainerBuilder>(ConfigureContainer)
                .ConfigureLogging(logging =>
                {
                    logging.ClearProviders();
                    logging.SetMinimumLevel(LogLevel.Trace);
                })
                .UseNLog()
                .UseConsoleLifetime();

        private void ConfigureHostConfiguration(IConfigurationBuilder builder)
            => builder.AddCommandLine(_args);

        private void ConfigureAppConfiguration(HostBuilderContext context, IConfigurationBuilder builder)
            => builder.SetBasePath(context.HostingEnvironment.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"appsettings.{context.HostingEnvironment.EnvironmentName}.json", optional: true,
                    reloadOnChange: true).AddCommandLine(_args);

        private string GetEnvironment(string[] args)
        {
            if (args.Length == 0)
            {
                return "dev";
            }

            var e = args[0]?.Replace('"', ' ').ToLower().Trim();
            return e;
        }

        private void ConfigureServices(HostBuilderContext context, IServiceCollection services)
        {
            //services.AddHttpClient();
            var baseUrl = context.Configuration.GetValue<string>("Legacy:DepositAccountApi:BaseUrl");

            services.AddHttpClient("MMSDepositAccountService",
                     client =>
                     {
                         client.BaseAddress = new Uri(baseUrl);
                     })
                 .ConfigurePrimaryHttpMessageHandler(h =>
                 {
                     return new HttpClientHandler
                     {
                         UseDefaultCredentials = true,
                         ServerCertificateCustomValidationCallback =
                            (httpRequestMessage, cert, certChain, policyErrors) => true
                     };
                 });

            services.AddHttpClient("CrmApi",
                 client =>
                 {
                     client.BaseAddress = new Uri(context.Configuration.GetValue<string>("Legacy:CrmApi:BaseUrl"));
                 })
                 .ConfigurePrimaryHttpMessageHandler(h =>
                 {
                     return new HttpClientHandler
                     {
                         UseDefaultCredentials = true,
                         ServerCertificateCustomValidationCallback =
                            (httpRequestMessage, cert, certChain, policyErrors) => true
                     };
                 });

            services.AddHttpClient("CarePDFMergeAPI",
                    client =>
                    {
                        client.BaseAddress = new Uri(context.Configuration.GetValue<string>("Legacy:CarePDFMergeAPI:BaseUrl"));
                    })
                .ConfigurePrimaryHttpMessageHandler(h =>
                {
                    return new HttpClientHandler
                    {
                        UseDefaultCredentials = true,
                        ServerCertificateCustomValidationCallback =
                            (httpRequestMessage, cert, certChain, policyErrors) => true
                    };
                });

            services.AddHttpClient("VaultTransferApi",
             client =>
             {
                 client.BaseAddress = new Uri(context.Configuration.GetValue<string>("Legacy:VaultTransferApi:BaseUrl"));
             })
             .ConfigurePrimaryHttpMessageHandler(h =>
             {
                 return new HttpClientHandler
                 {
                     UseDefaultCredentials = true,
                     ServerCertificateCustomValidationCallback =
                        (httpRequestMessage, cert, certChain, policyErrors) => true
                 };
             });

            services.AddHttpClient("NotifyApi",
             client =>
             {
                 client.BaseAddress = new Uri(context.Configuration.GetValue<string>("Legacy:NotifyApi:BaseUrl"));
             })
             .ConfigurePrimaryHttpMessageHandler(h =>
             {
                 return new HttpClientHandler
                 {
                     UseDefaultCredentials = true,
                     ServerCertificateCustomValidationCallback =
                        (httpRequestMessage, cert, certChain, policyErrors) => true
                 };
             });

            services.AddGdLogging();
            services.AddGdAop();

            //Add AutoMapper
            services.AddAutoMapper(typeof(ServiceBootstrapper).Assembly);

            //Add Config
            services.AddAppSupportProcessorConfiguration(context.Configuration);
            services.AddInitializeCardTranslationInventoryExceptionRecoveryConfiguration(context.Configuration);
            services.AddProcessCardTranslationInventoryExceptionRecoveryConfiguration(context.Configuration);
            services.AddInterestReimbursementConfiguration(context.Configuration);
            services.AddInterestPayConfiguration(context.Configuration);
            services.AddPaperStatementConfiguration(context.Configuration);
            services.AddPaperStatementFileConfiguration(context.Configuration);
            services.AddPaperStatementConfirmationConfiguration(context.Configuration);
            services.AddPaper1099IntConfiguration(context.Configuration);
            services.AddProcessMonthlyFeeConfiguration(context.Configuration);
            services.AddInitialActivityConfiguration(context.Configuration);
            services.AddAutoOrderCardConfiguration(context.Configuration);
            services.AddBackFillBillCycleForLegacyDDAAccountsConfiguration(context.Configuration);
            services.AddAccountClosureConfiguration(context.Configuration);
            services.AddInactivityFeeConfiguration(context.Configuration);

            //Add Hosted Service
            var specificHostServiceName = context.Configuration.GetSection("AppSupportProcessor:HostedService").Value;
            if (string.IsNullOrEmpty(specificHostServiceName))
            {
                //default config
                services.AddHostedService<PingHostedService>();
            }
            else
            {
                var type = AppDomain.CurrentDomain.GetAssemblies()
                    .SelectMany(a => a.GetTypes()
                        .Where(t => t.GetInterfaces().Contains(typeof(IHostedService)) && t.Name == specificHostServiceName)).FirstOrDefault();
                if (type != null)
                {
                    services.AddTransient(typeof(Microsoft.Extensions.Hosting.IHostedService), type);
                }
            }
        }

        private void ConfigureContainer(HostBuilderContext context, ContainerBuilder builder)
        {
            builder.RegisterModule<AppSupportHostedServiceModule>();
        }
    }
}
