﻿using System;
using System.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;

namespace AppSupportProcessor.Common.Locking.Sql.InternalLocks
{
    [ExcludeFromCodeCoverage]
    internal sealed class OwnedConnectionDistributedLock : IInternalSqlDistributedLock
    {
        private readonly string _lockName;
        private readonly string _connectionString;

        public OwnedConnectionDistributedLock(string lockName, string connectionString)
        {
            _lockName = lockName;
            _connectionString = connectionString;
        }

        public IDisposable TryAcquire(int timeoutMillis, SqlApplicationLock.Mode mode, IDisposable contextHandle)
        {
            if (contextHandle != null)
            {
                return CreateContextLock(contextHandle).TryAcquire(timeoutMillis, mode, null);
            }

            IDisposable result = null;
            var connection = new SqlConnection(_connectionString);
            try
            {
                connection.Open();
                if (SqlApplicationLock.ExecuteAcquireCommand(connection, _lockName, timeoutMillis, mode))
                {
                    result = new LockScope(connection, _lockName);
                }
            }
            finally
            {
                // if we fail to acquire or throw, make sure to clean up the connection
                if (result == null)
                {
                    connection.Dispose();
                }
            }

            return result;
        }

        public async Task<IDisposable> TryAcquireAsync(int timeoutMillis, SqlApplicationLock.Mode mode,
            CancellationToken cancellationToken, IDisposable contextHandle)
        {
            if (contextHandle != null)
            {
                return
                    await CreateContextLock(contextHandle)
                        .TryAcquireAsync(timeoutMillis, mode, cancellationToken, null)
                        .ConfigureAwait(false);
            }

            IDisposable result = null;
            var connection = new SqlConnection(_connectionString);
            try
            {
                await connection.OpenAsync(cancellationToken).ConfigureAwait(false);
                if (
                    await SqlApplicationLock.ExecuteAcquireCommandAsync(connection, _lockName, timeoutMillis, mode,
                        cancellationToken).ConfigureAwait(false))
                {
                    result = new LockScope(connection, _lockName);
                }
            }
            finally
            {
                // if we fail to acquire or throw, make sure to clean up the connection
                if (result == null)
                {
                    connection.Dispose();
                }
            }

            return result;
        }

        private IInternalSqlDistributedLock CreateContextLock(IDisposable contextHandle)
        {
            var connection = ((LockScope)contextHandle).Connection;
            if (connection == null)
            {
                throw new ObjectDisposedException(nameof(contextHandle), "the provided handle is already disposed");
            }

            return new ConnectionScopedSqlDistributedLock(_lockName, connection);
        }

        private sealed class LockScope : IDisposable
        {
            private SqlConnection _connection;
            private readonly string _lockName;

            public LockScope(SqlConnection connection, string lockName)
            {
                _connection = connection;
                _lockName = lockName;
            }

            public SqlConnection Connection => Volatile.Read(ref _connection);

            public void Dispose()
            {
                var connection = Interlocked.Exchange(ref _connection, null);
                if (connection != null && !connection.IsClosedOrBroken())
                {
                    ReleaseLock(connection, _lockName);
                }
            }

            private static void ReleaseLock(SqlConnection connection, string lockName)
            {
                try
                {
                    // explicit release is required due to connection pooling. For a pooled connection,
                    // simply calling Dispose() will not release the lock: it just returns the connection
                    // to the pool
                    SqlApplicationLock.ExecuteReleaseCommand(connection, lockName);
                }
                finally
                {
                    connection.Dispose();
                }
            }
        }
    }
}