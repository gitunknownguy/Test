﻿using System;
using System.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;

namespace AppSupportProcessor.Common.Locking.Sql.InternalLocks
{
    [ExcludeFromCodeCoverage]
    internal sealed class OwnedTransactionSqlDistributedLock : IInternalSqlDistributedLock
    {
        private readonly string _lockName;
        private readonly string _connectionString;

        public OwnedTransactionSqlDistributedLock(string lockName, string connectionString)
        {
            _lockName = lockName;
            _connectionString = connectionString;
        }

        public IDisposable TryAcquire(int timeoutMillis, SqlApplicationLock.Mode mode, IDisposable contextHandle)
        {
            if (contextHandle != null)
            {
                return CreateContextLock(contextHandle).TryAcquire(timeoutMillis, mode, null);
            }

            IDisposable result = null;
            var connection = new SqlConnection(_connectionString);
            SqlTransaction transaction = null;
            try
            {
                connection.Open();
                // when creating a transaction, the isolation level doesn't matter, since we're using sp_getapplock
                transaction = connection.BeginTransaction();
                if (SqlApplicationLock.ExecuteAcquireCommand(transaction, _lockName, timeoutMillis, mode))
                {
                    result = new LockScope(transaction);
                }
            }
            finally
            {
                // if we fail to acquire or throw, make sure to clean up
                if (result == null)
                {
                    transaction?.Dispose();
                    connection.Dispose();
                }
            }

            return result;
        }

        public async Task<IDisposable> TryAcquireAsync(int timeoutMillis, SqlApplicationLock.Mode mode,
            CancellationToken cancellationToken, IDisposable contextHandle = null)
        {
            if (contextHandle != null)
            {
                return
                    await CreateContextLock(contextHandle)
                        .TryAcquireAsync(timeoutMillis, mode, cancellationToken, null)
                        .ConfigureAwait(false);
            }

            IDisposable result = null;
            var connection = new SqlConnection(_connectionString);
            SqlTransaction transaction = null;
            try
            {
                await connection.OpenAsync(cancellationToken).ConfigureAwait(false);
                // when creating a transaction, the isolation level doesn't matter, since we're using sp_getapplock
                transaction = connection.BeginTransaction();
                if (
                    await SqlApplicationLock.ExecuteAcquireCommandAsync(transaction, _lockName, timeoutMillis, mode,
                        cancellationToken).ConfigureAwait(false))
                {
                    result = new LockScope(transaction);
                }
            }
            finally
            {
                // if we fail to acquire or throw, make sure to clean up
                if (result == null)
                {
                    transaction?.Dispose();
                    connection.Dispose();
                }
            }

            return result;
        }

        private IInternalSqlDistributedLock CreateContextLock(IDisposable contextHandle)
        {
            var transaction = ((LockScope)contextHandle).Transaction;
            if (transaction == null)
            {
                throw new ObjectDisposedException(nameof(contextHandle), "the provided handle is already disposed");
            }

            return new TransactionScopedSqlDistributedLock(_lockName, transaction);
        }

        private sealed class LockScope : IDisposable
        {
            private SqlTransaction _transaction;

            public LockScope(SqlTransaction transaction)
            {
                _transaction = transaction;
            }

            public SqlTransaction Transaction => Volatile.Read(ref _transaction);

            public void Dispose()
            {
                var transaction = Interlocked.Exchange(ref _transaction, null);
                if (transaction != null)
                {
                    var connection = transaction.Connection;
                    transaction.Dispose(); // first end the transaction to release the lock
                    connection.Dispose(); // then close the connection (returns it to the pool)
                }
            }
        }
    }
}
