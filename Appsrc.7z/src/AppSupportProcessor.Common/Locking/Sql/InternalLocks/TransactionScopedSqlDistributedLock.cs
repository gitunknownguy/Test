﻿using System;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;

namespace AppSupportProcessor.Common.Locking.Sql.InternalLocks
{
    [ExcludeFromCodeCoverage]
    internal sealed class TransactionScopedSqlDistributedLock : IInternalSqlDistributedLock
    {
        private readonly string _lockName;
        private readonly IDbTransaction _transaction;

        public TransactionScopedSqlDistributedLock(string lockName, IDbTransaction transaction)
        {
            _lockName = lockName;
            _transaction = transaction;
        }

        public IDisposable TryAcquire(int timeoutMillis, SqlApplicationLock.Mode mode, IDisposable contextHandle)
        {
            CheckConnection();

            return SqlApplicationLock.ExecuteAcquireCommand(new ConnectionOrTransaction(_transaction), _lockName,
                timeoutMillis, mode)
                ? new LockScope(this)
                : null;
        }

        public async Task<IDisposable> TryAcquireAsync(int timeoutMillis, SqlApplicationLock.Mode mode,
            CancellationToken cancellationToken, IDisposable contextHandle)
        {
            CheckConnection();

            return
                await SqlApplicationLock.ExecuteAcquireCommandAsync(new ConnectionOrTransaction(_transaction), _lockName,
                    timeoutMillis, mode, cancellationToken).ConfigureAwait(false)
                    ? new LockScope(this)
                    : null;
        }

        private void CheckConnection()
        {
            if (_transaction.Connection == null)
            {
                throw new InvalidOperationException("The transaction had been disposed");
            }
            if (_transaction.Connection.State != ConnectionState.Open)
            {
                throw new InvalidOperationException("The connection is not open");
            }
        }

        private void Release()
        {
            if (_transaction.Connection?.IsClosedOrBroken() ?? true)
            {
                // lost the connection or transaction disposed, so the lock was already released released
                return;
            }

            SqlApplicationLock.ExecuteReleaseCommand(new ConnectionOrTransaction(_transaction), _lockName);
        }

        private sealed class LockScope : IDisposable
        {
            private TransactionScopedSqlDistributedLock _lock;

            public LockScope(TransactionScopedSqlDistributedLock @lock)
            {
                _lock = @lock;
            }

            public void Dispose() => Interlocked.Exchange(ref _lock, null)?.Release();
        }
    }
}
