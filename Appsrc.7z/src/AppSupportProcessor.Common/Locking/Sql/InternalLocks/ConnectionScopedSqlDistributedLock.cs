﻿using System;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;

namespace AppSupportProcessor.Common.Locking.Sql.InternalLocks
{
    [ExcludeFromCodeCoverage]
    internal sealed class ConnectionScopedSqlDistributedLock : IInternalSqlDistributedLock
    {
        private readonly string _lockName;
        private readonly IDbConnection _connection;

        public ConnectionScopedSqlDistributedLock(string lockName, IDbConnection connection)
        {
            _lockName = lockName;
            _connection = connection;
        }

        public IDisposable TryAcquire(int timeoutMillis, SqlApplicationLock.Mode mode, IDisposable contextHandle)
        {
            CheckConnection();

            return SqlApplicationLock.ExecuteAcquireCommand(new ConnectionOrTransaction(_connection), _lockName,
                timeoutMillis, mode)
                ? new LockScope(this)
                : null;
        }

        public async Task<IDisposable> TryAcquireAsync(int timeoutMillis, SqlApplicationLock.Mode mode,
            CancellationToken cancellationToken, IDisposable contextHandle)
        {
            CheckConnection();

            return
                await SqlApplicationLock.ExecuteAcquireCommandAsync(new ConnectionOrTransaction(_connection), _lockName,
                    timeoutMillis, mode, cancellationToken).ConfigureAwait(false)
                    ? new LockScope(this)
                    : null;
        }

        private void CheckConnection()
        {
            if (_connection.State != ConnectionState.Open)
            {
                throw new InvalidOperationException("The connection is not open");
            }
        }

        private void Release()
        {
            if (_connection.IsClosedOrBroken())
            {
                // lost the connection, so the lock was already released released
                return;
            }

            SqlApplicationLock.ExecuteReleaseCommand(new ConnectionOrTransaction(_connection), _lockName);
        }

        private sealed class LockScope : IDisposable
        {
            private ConnectionScopedSqlDistributedLock _lock;

            public LockScope(ConnectionScopedSqlDistributedLock @lock)
            {
                _lock = @lock;
            }

            public void Dispose() => Interlocked.Exchange(ref _lock, null)?.Release();
        }
    }
}