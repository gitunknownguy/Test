﻿using System;
using System.Data;
using System.Data.Common;
using System.Diagnostics.CodeAnalysis;

namespace AppSupportProcessor.Common.Locking.Sql
{
    [ExcludeFromCodeCoverage]
    internal struct ConnectionOrTransaction
    {
        private readonly object _connectionOrTransaction;

        public IDbTransaction Transaction => _connectionOrTransaction as IDbTransaction;
        public IDbConnection Connection => Transaction?.Connection ?? (_connectionOrTransaction as IDbConnection);

        public ConnectionOrTransaction(IDbConnection connection)
        {
            if (connection == null)
            {
                throw new ArgumentNullException(nameof(connection));
            }

            _connectionOrTransaction = connection;
        }

        public ConnectionOrTransaction(IDbTransaction transaction)
        {
            if (transaction == null)
            {
                throw new ArgumentNullException(nameof(transaction));
            }

            _connectionOrTransaction = transaction;
        }

        public static implicit operator ConnectionOrTransaction(DbTransaction transaction)
            => new ConnectionOrTransaction(transaction);

        public static implicit operator ConnectionOrTransaction(DbConnection connection)
            => new ConnectionOrTransaction(connection);
    }
}