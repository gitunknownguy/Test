﻿namespace AppSupportProcessor.Common.Locking
{
    /// <summary>
    /// Creates a new, unique sql distributed lock.
    /// </summary>
    /// <param name="connectionString">Connection string of target database on which the lock is placed.</param>
    /// <param name="lockName">The name of the lock.</param>
    /// <returns>The IDistributedLock.</returns>
    public delegate IDistributedLock SqlDistributedLockFactory(string connectionString, string lockName);
}
