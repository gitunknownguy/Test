﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using System.Linq;

namespace AppSupportProcessor.Common.Extensions
{
    [ExcludeFromCodeCoverage]
    public static class LinqExtension
    {
        public static IEnumerable<T> Except<T, V>(this IEnumerable<T> first, IEnumerable<T> second, Func<T, V> keySelector)
        {
            return first.Except(second, new CommonEqualityComparer<T, V>(keySelector));
        }
    }

    public class CommonEqualityComparer<T, V> : IEqualityComparer<T>
    {
        private Func<T, V> keySelector;

        public CommonEqualityComparer(Func<T, V> _keySelector)
        {
            this.keySelector = _keySelector;
        }

        public bool Equals([AllowNull] T x, [AllowNull] T y)
        {
            return EqualityComparer<V>.Default.Equals(keySelector(x), keySelector(y));
        }

        public int GetHashCode([DisallowNull] T obj)
        {
            return EqualityComparer<V>.Default.GetHashCode(keySelector(obj));
        }
    }
}
