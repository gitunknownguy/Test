﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using System.Text.RegularExpressions;

namespace AppSupportProcessor.Common.Extensions
{
    [ExcludeFromCodeCoverage]
    public static class StringExtension
    {
        public static int IndexOfOccurence(this string s, string match, int occurence)
        {
            int i = 1;
            int index = -1;

            while (i <= occurence && (index = s.IndexOf(match, index + 1)) != -1)
            {
                if (i == occurence)
                    return index;

                i++;
            }

            return -1;
        }

        public static string MaskWithAsterisks(this string s, int start, int length)
        {
            if (s.Length < start + length)
                return s;

            return s.Substring(0, start) + 
                Regex.Replace(s.Substring(start, length), @"\w", "*") + 
                s.Substring(start + length);
        }
    }
}
