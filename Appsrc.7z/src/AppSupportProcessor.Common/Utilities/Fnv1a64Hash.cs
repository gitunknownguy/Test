﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace AppSupportProcessor.Common.Utilities
{
    [ExcludeFromCodeCoverage]
    public static class Fnv1a64Hash
    {
        public static UInt64 Hash(byte[] buffer)
        {
            UInt64 hash = OffsetBasis;

            for (int i = 0; i < buffer.Length; i++)
                hash = (hash ^ buffer[i]) * Prime;

            return hash;
        }

        private const UInt64 OffsetBasis = 0xCBF29CE484222325;
        private const UInt64 Prime = 0x100000001B3;
    }
}
