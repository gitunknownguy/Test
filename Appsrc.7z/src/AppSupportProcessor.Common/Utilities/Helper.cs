﻿using System;
using System.Collections.Generic;

namespace AppSupportProcessor.Common.Utilities
{
    public class Helper
    {
        readonly EncryptionUsingInternalAlgorithm _internalEncryption = new EncryptionUsingInternalAlgorithm();

        /// <summary>Convert Serial number to Card number</summary>
        public string SerialNumberToCardNumber(string serialNumber)
        {
            return _internalEncryption.ToCardNumber(serialNumber);
        }
        public static IEnumerable<List<T>> Partition<T>(List<T> source, int chunkSize)
        {
            for (int i = 0; i < source.Count; i += chunkSize)
            {
                yield return source.GetRange(i, Math.Min(chunkSize, source.Count - i));
            }
        }
    }
}
