﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Common.Utilities
{
    /// <summary>Encryption using internal Green Dot algorithm</summary>
    public class EncryptionUsingInternalAlgorithm
    {
        /// <summary>Converts 16 digit Card number to Serial Number</summary>
        public string ToSerialNumber(string cardNumber)
        {
            string sNewString = null;
            string sEncString = null;
            int iLoop = 0;
            int iMod = 0;
            double dblNum = 0;

            if (string.IsNullOrWhiteSpace(cardNumber) == true || cardNumber.Length != 16)
            {
                throw new Exception("ToSerialNumber: Field length must be 16 chars");
            }

            sNewString = "";
            sEncString = "";

            for (iLoop = 15; iLoop >= 1; iLoop += -2)
            {
                sNewString = sNewString + cardNumber[iLoop];
            }

            dblNum = Convert.ToDouble(sNewString);

            for (iLoop = 0; iLoop < 5; iLoop++)
            {
                iMod = Convert.ToInt32(dblNum % 95);
                dblNum = (dblNum - iMod) / 95;
                sEncString = sEncString + Microsoft.VisualBasic.Strings.Chr(iMod + 32);
            }

            sNewString = "";
            for (iLoop = 14; iLoop >= 0; iLoop += -2)
            {
                sNewString = sNewString + cardNumber[iLoop];
            }

            dblNum = Convert.ToDouble(sNewString);

            for (iLoop = 0; iLoop < 5; iLoop++)
            {
                iMod = Convert.ToInt32(dblNum % 95);
                dblNum = (dblNum - iMod) / 95;
                sEncString = sEncString + Microsoft.VisualBasic.Strings.Chr(iMod + 32);
            }

            return EncryptString(sEncString);
        }

        /// <summary>Converts Serial Number to 16 digit Card Number</summary>
        public string ToCardNumber(string serialNumber)
        {
            StringBuilder functionReturnValue = null;
            string sNewString = null;
            string sPartString = null;
            int iLoop = 0;
            int iMod = 0;
            int iPos = 0;
            double dblNum = 0;

            if (string.IsNullOrWhiteSpace(serialNumber) == true || serialNumber.Length != 10)
            {
                throw new Exception("ToCardNumber: Field length must be 10 chars");
            }

            functionReturnValue = new StringBuilder(new String(' ', 16));

            sNewString = DecryptString(serialNumber);

            sPartString = sNewString.Substring(0, 5);

            dblNum = 0;
            for (iLoop = 0; iLoop < 5; iLoop++)
            {
                iMod = (int)(sPartString[iLoop] - 32);
                dblNum = dblNum + iMod * (Math.Pow(95, (iLoop)));
            }

            sPartString = dblNum.ToString().PadLeft(8, '0');
            iPos = 15;
            for (iLoop = 0; iLoop < 8; iLoop++)
            {
                functionReturnValue[iPos] = sPartString[iLoop];
                iPos = iPos - 2;
            }

            sPartString = sNewString.Substring(sNewString.Length - 5);//sPartString = Right(sNewString, 5)

            dblNum = 0;
            for (iLoop = 0; iLoop < 5; iLoop++)
            {
                iMod = (int)(sPartString[iLoop]) - 32;
                dblNum = dblNum + iMod * (Math.Pow(95, (iLoop)));
            }

            sPartString = dblNum.ToString().PadLeft(8, '0');
            iPos = 14;
            for (iLoop = 0; iLoop < 8; iLoop++)
            {
                functionReturnValue[iPos] = sPartString[iLoop];
                iPos = iPos - 2;
            }
            return functionReturnValue.ToString();

        }

        public string EncryptString(string tsValue)
        {
            StringBuilder functionReturnValue = null;
            int iPos = 0;
            int iAsc = 0;
            int iMod = 0;
            int iLen = 0;
            int iNewAsc = 0;

            iLen = tsValue.Length;

            iMod = 15 + iLen;

            functionReturnValue = new StringBuilder(new String(' ', iLen));

            tsValue = Scramble(tsValue).ToString();

            for (iPos = 0; iPos < iLen; iPos++)
            {
                iAsc = Microsoft.VisualBasic.Strings.Asc(tsValue[iPos]);
                if (iAsc < 32 | iAsc > 126)
                {
                    throw new Exception("EncryptString: String contains characters outside acceptable range [32-126]");
                }
                iNewAsc = (iAsc + iMod);
                while (iNewAsc > 126)
                {
                    iNewAsc = iNewAsc - 95;
                }
                iMod = iNewAsc + iLen - (iPos + 1);
                if (Microsoft.VisualBasic.Strings.Chr(iNewAsc) == '\'')
                {
                    iNewAsc = 130;
                }
                else if (Microsoft.VisualBasic.Strings.Chr(iNewAsc) == '"')
                {
                    iNewAsc = 131;
                }
                else if (Microsoft.VisualBasic.Strings.Chr(iNewAsc) == '`')
                {
                    iNewAsc = 132;
                }

                functionReturnValue[iPos] = Microsoft.VisualBasic.Strings.Chr(iNewAsc);
            }
            return functionReturnValue.ToString();
        }

        public string DecryptString(string tsValue)
        {
            StringBuilder functionReturnValue = null;
            int iPos = 0;
            int iMod = 0;
            int iLen = 0;
            int iNewAsc = 0;
            int iAsc = 0;

            iLen = tsValue.Length;

            iMod = 15 + iLen;

            functionReturnValue = new StringBuilder(new String(' ', iLen));

            for (iPos = 0; iPos < iLen; iPos++)
            {
                iAsc = Microsoft.VisualBasic.Strings.Asc(tsValue[iPos]);
                if (iAsc == 130)
                {
                    iAsc = (int)('\'');
                }
                else if (iAsc == 131)
                {
                    iAsc = (int)('"');
                }
                else if (iAsc == 132)
                {
                    iAsc = (int)('`');
                }

                if (iAsc < 32 | iAsc > 126)
                {
                    throw new Exception("DecryptString: String contains characters outside acceptable range [32-126]");
                }

                iNewAsc = iAsc - iMod;
                while (iNewAsc < 32)
                {
                    iNewAsc = iNewAsc + 95;
                }
                functionReturnValue[iPos] = Microsoft.VisualBasic.Strings.Chr(iNewAsc);
                iMod = iAsc + iLen - (iPos + 1);
            }

            functionReturnValue = Unscramble(functionReturnValue.ToString());
            return functionReturnValue.ToString();

        }

        #region Private Methods
        private StringBuilder Scramble(string tsString)
        {
            int iLen = 0;
            StringBuilder sNewString = null;
            int iLoop = 0;
            int iStart = 0;

            iLen = tsString.Length;
            iStart = iLen - 1 - (iLen % 3);
            if (iStart == 0)
            {
                iStart = 0;
            }
            sNewString = new StringBuilder(new String(' ', iLen));
            for (iLoop = 0; iLoop < iLen; iLoop++)
            {
                sNewString[iStart] = tsString[iLoop];
                iStart = iStart + 1;
                if (iStart >= iLen)
                {
                    iStart = 0;
                }
            }
            return sNewString;
        }

        private StringBuilder Unscramble(string tsString)
        {
            int iLen = 0;
            StringBuilder sNewString = null;
            int iLoop = 0;
            int iStart = 0;
            iLen = tsString.Length;
            iStart = (iLen % 3) + 1;
            if (iStart >= iLen)
            {
                iStart = 0;
            }
            sNewString = new StringBuilder(new String(' ', iLen));
            for (iLoop = 0; iLoop < iLen; iLoop++)
            {
                sNewString[iStart] = tsString[iLoop];
                iStart = iStart + 1;
                if (iStart >= iLen)
                {
                    iStart = 0;
                }
            }
            return sNewString;
        }
        #endregion
    }
}
