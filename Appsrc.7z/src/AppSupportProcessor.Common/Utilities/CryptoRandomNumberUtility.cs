﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Security.Cryptography;

namespace AppSupportProcessor.Common.Utilities
{
    [ExcludeFromCodeCoverage]
    public static class CryptoRandomNumberUtility
    {
        private static readonly RNGCryptoServiceProvider CryptoRng = new RNGCryptoServiceProvider();

        // Return a random integer between a min and max value.
        public static int RandomInt(int min, int max)
        {
            // Generate four random bytes
            byte[] bytes = new byte[sizeof(int)];
            CryptoRng.GetBytes(bytes);

            // Convert the bytes to a UInt32
            var scale = BitConverter.ToUInt32(bytes, 0);

            // And use that to pick a random number >= min and < max
            return (int)(min + (max - min) * (scale / (uint.MaxValue + 1.0)));
        }

        // Return a random double between a min and max value.
        public static long RandomLong(long min, long max)
        {
            // Generate random bytes
            byte[] bytes = new byte[sizeof(long)];
            CryptoRng.GetBytes(bytes);

            // Convert the bytes to a UInt32
            var scale = BitConverter.ToUInt64(bytes, 0);

            // And use that to pick a random number >= min and < max
            return (long)(min + (max - min) * (scale / (ulong.MaxValue + 1.0)));
        }
    }
}