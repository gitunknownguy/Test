﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace AppSupportProcessor.Common.Utilities
{
    [ExcludeFromCodeCoverage]
    public class Lcg
    {
        public Lcg(UInt64 seed)
        {
            _seed = seed;
        }

        public UInt32 Next()
        {
            _seed = (Multiplier * _seed + Increment) % Modulus;

            return (UInt32)(_seed >> 16);
        }

        private UInt64 _seed;

        private const UInt64 Multiplier = 25214903917;
        private const int Increment = 11;
        private const UInt64 Modulus = 0x0000FFFFFFFFFFFF;
    }
}
