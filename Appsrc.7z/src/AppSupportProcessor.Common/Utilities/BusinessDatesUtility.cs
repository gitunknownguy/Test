﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace AppSupportProcessor.Common.Utilities
{
    [ExcludeFromCodeCoverage]
    public class BusinessDatesUtility
    {
        public static int CalculateBusinessDays(DateTime startDate, DateTime enDate)
        {
            var totalDays = 0;
            for (var date = startDate; date <= enDate; date = date.AddDays(1))
            {
                if (date.DayOfWeek != DayOfWeek.Saturday
                    && date.DayOfWeek != DayOfWeek.Sunday
                    && !IsAHoliday(date))
                    totalDays++;
            }

            return totalDays;
        }

        public static bool IsAHoliday(DateTime date)
        {
            var bankHolidays = GetHolidays(date.Year);
            return (bankHolidays.ContainsValue(date.ToString("yyyy/MM/dd")));
        }
        public static Dictionary<string, string> GetHolidays(int year)
        {
            Dictionary<string, string> holidays = new Dictionary<string, string>
           {
               {"NEW_YEARS", GetNewYearsDay(year)},
               {"MLK_DAY", GetMLKDay(year)},
               {"PRESIDENTS_DAY", GetPresidentsDay(year)},
               {"MEMORIAL_DAY", GetMemorialDay(year)},
               {"INDEPENDENCE_DAY", GetIndependenceDay(year)},
               {"LABOR_DAY", GetLaborDay(year)},
               {"COLUMBUS_DAY", GetColumbusDay(year)},
               {"VETERANS_DAY", GetVetsDay(year)},
               {"THANKSGIVING", GetThanksGivingDay(year)},
               {"CHRISTMAS_DAY", GetChristmasDay(year)}
           };

            return holidays;
        }

        private static string GetNewYearsDay(int year)
        {
            DateTime nyDate = new DateTime(year, 1, 1);
            if (nyDate.DayOfWeek == DayOfWeek.Sunday)
                return nyDate.AddDays(1).ToString("yyyy/MM/dd");
            else
                return nyDate.ToString("yyyy/MM/dd");
        }

        private static string GetMLKDay(int year)
        {
            DateTime mlkDate = new DateTime(year, 1, 15); // Earliest Date that MLK day can be.
            while (mlkDate.DayOfWeek != DayOfWeek.Monday)
            {
                mlkDate = mlkDate.AddDays(1);
            }
            return mlkDate.ToString("yyyy/MM/dd");
        }

        private static string GetPresidentsDay(int year)
        {
            DateTime potusDate = new DateTime(year, 2, 19); // Latest Date that President's day can be.
            while (potusDate.DayOfWeek != DayOfWeek.Monday)
            {
                potusDate = potusDate.AddDays(1);
            }
            return potusDate.ToString("yyyy/MM/dd");
        }

        private static string GetMemorialDay(int year)
        {
            DateTime memDate = new DateTime(year, 5, 28); // Latest Date that Memorial day can be.
            while (memDate.DayOfWeek != DayOfWeek.Monday)
            {
                memDate = memDate.AddDays(-1);
            }
            return memDate.ToString("yyyy/MM/dd");
        }

        private static string GetIndependenceDay(int year)
        {
            DateTime indDate = new DateTime(year, 7, 4);
            if (indDate.DayOfWeek == DayOfWeek.Sunday)
                return indDate.AddDays(1).ToString("yyyy/MM/dd");
            if (indDate.DayOfWeek == DayOfWeek.Saturday)
                return indDate.AddDays(-1).ToString("yyyy/MM/dd");
            else
                return indDate.ToString("yyyy/MM/dd");
        }

        private static string GetLaborDay(int year)
        {
            DateTime laborDate = new DateTime(year, 9, 3); // Latest Date that labor day can be.
            while (laborDate.DayOfWeek != DayOfWeek.Monday)
            {
                laborDate = laborDate.AddDays(1);
            }
            return laborDate.ToString("yyyy/MM/dd");
        }

        private static string GetColumbusDay(int year)
        {
            DateTime colDate = new DateTime(year, 10, 8); // Earliest Date that Columbus day can be.
            while (colDate.DayOfWeek != DayOfWeek.Monday)
            {
                colDate = colDate.AddDays(1);
            }
            return colDate.ToString("yyyy/MM/dd");
        }

        private static string GetVetsDay(int year)
        {
            DateTime vetsDate = new DateTime(year, 11, 11);
            if (vetsDate.DayOfWeek == DayOfWeek.Sunday)
                return vetsDate.AddDays(1).ToString("yyyy/MM/dd");
            else
                return vetsDate.ToString("yyyy/MM/dd");
        }

        private static string GetThanksGivingDay(int year)
        {
            DateTime colDate = new DateTime(year, 11, 22); // Earliest Date that Thanksgiving day can be.
            while (colDate.DayOfWeek != DayOfWeek.Thursday)
            {
                colDate = colDate.AddDays(1);
            }
            return colDate.ToString("yyyy/MM/dd");
        }


        private static string GetChristmasDay(int year)
        {
            DateTime xmasDate = new DateTime(year, 12, 25);
            if (xmasDate.DayOfWeek == DayOfWeek.Sunday)
                return xmasDate.AddDays(1).ToString("yyyy/MM/dd");
            if (xmasDate.DayOfWeek == DayOfWeek.Saturday)
                return xmasDate.AddDays(-1).ToString("yyyy/MM/dd");
            else
                return xmasDate.ToString("yyyy/MM/dd");
        }
    }
}
