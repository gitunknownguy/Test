﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AppSupportProcessor.Common.Configuration
{
    public class AppSupportProcessorConfiguration
    {
        public string HostedService { get; set; }
    }
}
