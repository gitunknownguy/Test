﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AppSupportProcessor.Common.Configuration
{
    public class InitializeCardTranslationInventoryExceptionRecoveryConfiguration
    {
        public int TimeWindow { get; set; }
    }
}
