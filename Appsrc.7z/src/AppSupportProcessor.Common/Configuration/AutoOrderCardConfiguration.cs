﻿using System.Diagnostics.CodeAnalysis;

namespace AppSupportProcessor.Common.Configuration
{
    [ExcludeFromCodeCoverage]
    public class AutoOrderCardConfiguration
    {
        public string AutoOrderCardFilePath { get; set; }
        public string AutoOrderCardCompleteFilePath { get; set; }
        public int BatchSize { get; set; }
    }
}
