﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace AppSupportProcessor.Common.Configuration
{
    [ExcludeFromCodeCoverage]
    public class ProcessCardTranslationInventoryExceptionRecoveryConfiguration
    {
        public int BatchSize { get; set; }
    }
}
