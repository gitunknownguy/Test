﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Common.Configuration
{
    [ExcludeFromCodeCoverage]
    public class InactivityFeeConfiguration
    {
        public int BatchSize { get; set; }
        public bool Enabled { get; set; }
        public short MembershipGroupKey { get; set; }
        public short InactivityFeeTypeKey { get; set; }
    }
}
