﻿namespace AppSupportProcessor.Common.Configuration
{
    public class ProcessMonthlyFeeConfiguration
    {
        public string FileBasePath { get; set; }
    }
}