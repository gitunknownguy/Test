﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Common.Configuration
{
    public class AccountClosureConfiguration
    {
        public string LoadAccountClosureFilePath { get; set; }
        public string LoadAccountClosureCompleteFilePath { get; set; }
        public string InputFileToACIFilePath { get; set; }
        public string ReportFileFromACI { get; set; }
        public int BatchSize { get; set; }
    }
}
