﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Common.Configuration
{
    public class ConsolidationConfiguration
    {
        public int InitActivityBatchSize { get; set; }
        public int ExecuteActivityBatchSize { get; set; }
        public int RetryActivityBatchSize { get; set; }
        public int LoadConsolidationAccountsBatchSize { get; set; }
        public string LoadConsolidationAccountsFilePath { get; set; }
        public string LoadConsolidationAccountsCompleteFilePath { get; set; }
        public int RetryMaxCount { get; set; }
        public int ValutRetryMaxCount { get; set; }
        public int EiligibilityCheckBatchSize { get; set; }
        public int DelayTime { get; set; }
    }
}
