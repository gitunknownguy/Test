﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AppSupportProcessor.Common.RetryHelp
{
    public interface IRetryHelper
    {
        void Retry(Action action, int maxRetries = 3, Func<Exception, bool> shouldRetry = null,
            int sleepMilliseconds = 100);

        T Retry<T>(Func<T> func, int maxRetries = 3, Func<Exception, bool> shouldRetry = null, int sleepMilliseconds = 100);
    }
}
