﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using Microsoft.Extensions.Logging;
using System.Threading;

namespace AppSupportProcessor.Common.RetryHelp
{
    [ExcludeFromCodeCoverage]
    public class RetryHelper : IRetryHelper
    {
        private readonly ILogger<RetryHelper> _logger;

        public RetryHelper(ILogger<RetryHelper> logger)
        {
            _logger = logger;
        }

        public void Retry(Action action, int maxRetries = 3, Func<Exception, bool> shouldRetry = null, int sleepMilliseconds = 100)
        {
            int retries = 0;

            while (retries <= maxRetries)
            {
                try
                {
                    action();
                    return;
                }
                catch (Exception e)
                {
                    Thread.Sleep(sleepMilliseconds);
                    _logger.LogError(string.Format("Retry Error: {0},retry count:{1}", e, retries + 1));
                    if (retries == maxRetries || (shouldRetry != null && !shouldRetry(e)))
                    {
                        _logger.LogError($"Hit max retries {maxRetries}");
                        throw;
                    }
                }

                retries++;
            }
        }

        public T Retry<T>(Func<T> func, int maxRetries = 3, Func<Exception, bool> shouldRetry = null, int sleepMilliseconds = 100)
        {
            int retries = 0;

            while (retries <= maxRetries)
            {
                try
                {
                    return func();
                }
                catch (Exception e)
                {
                    Thread.Sleep(sleepMilliseconds);
                    _logger.LogError(string.Format("Retry Error: {0},retry count:{1}", e, retries + 1));
                    if (retries == maxRetries || (shouldRetry != null && !shouldRetry(e)))
                    {
                        _logger.LogError($"Hit max retries {maxRetries}");
                        throw;
                    }
                }
                retries++;
            }

            return default(T);
        }
    }
}
