﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using AppSupportProcessor.Model.DO;
using AppSupportProcessor.Model.PDS;

namespace AppSupportProcessor.DataAccess.Repositories
{
    public interface ICDSRepository
    {
        Task<List<PurseInfo>> GetPurseBalanceByAccountKeys(List<Guid> accountKeys);
    }
}
