﻿using Microsoft.Extensions.Caching.Memory;
using System;

namespace AppSupportProcessor.DataAccess.Repositories
{
    public class MemoryCacheClient : ICache
    {
        private readonly MemoryCache _memoryCache;

        public MemoryCacheClient()
        {
            _memoryCache = new MemoryCache(new MemoryCacheOptions());
        }

        public TValue GetData<TValue>(string key)
        {
            TValue retData = default(TValue);
            var data = _memoryCache.Get(key);
            if (data != null)
                retData = (TValue)data;
            return retData;
        }

        /// <summary>Inserts an item in cache which never expires</summary>
        public void InsertData<TValue>(string key, TValue value)
        {
            _memoryCache.Set(key, value, TimeSpan.MaxValue);
        }

        /// <summary>Inserts an item in cache with the specified expiration time</summary>
        public void InsertData<TValue>(string key, TValue value, TimeSpan expirationTime)
        {
            _memoryCache.Set(key, value, DateTimeOffset.Now.Add(expirationTime));
        }

        public bool RemoveData(string key)
        {
            try
            {
                _memoryCache.Remove(key);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
