﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using AppSupportProcessor.Model.DO;
using AppSupportProcessor.Model.PDS;

namespace AppSupportProcessor.DataAccess.Repositories
{
    public interface IIPSRepository
    {
        Task<int> InsertETLCardTranslationInventoryException(int interval);

        Task<List<CardTranslationInventoryExceptionHandlerInfo>> GetETL_CardTranslationInventory_ExceptionHandlerByBatch(int batchSize, string status);

        Task<List<GetCardTranslationInventoryInfo>> GetCardTranslationInventoryByCardReferenceIds(List<Guid> cardRefrenceIds);

        Task<List<GetCardTranslationInventoryInfo>> GetCardTranslationInventoryByCardExternalIDs(List<string> proxyIds, int processorKey);

        Task<List<CardTranslationInfo>> GetCardTranslationByCardExternalIDs(List<string> proxyIds, int processorKey);

        Task UpdateCardTranslationInventoryToDeprecateCardProxy(List<ExceptionHandlerKeyInfo> infos, int processorKey);

        Task<int> UpdateETL_CardTranslationInventory_ExceptionHandlerByBatch(List<ETLCardTranslationInventoryExceptionHandlerInfo> handlerInfos);

        Task PingTest();
        Task<List<AccountTranslationInfo>> GetAccountKeysByAccountReferenceIDs(List<Guid> accountReferenceIds);
        Task<List<CardTranslationInfo>> GetCardExternalIDByCardReferenceIDs(List<Guid> cardReferenceIds);
    }
}
