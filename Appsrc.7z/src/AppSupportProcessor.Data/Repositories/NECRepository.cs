﻿using AppSupportProcessor.DataAccess.Base;
using AppSupportProcessor.Model.DO;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using AppSupportProcessor.Model.NEC;
using Dapper;
using System.Data;
using AppSupportProcessor.Model.Consolidation;
using AppSupportProcessor.Model.AutoOrderCard;
using System.Xml.Linq;
using AppSupportProcessor.Model.InactivityFee;
using AppSupportProcessor.Model.Enum;
namespace AppSupportProcessor.DataAccess.Repositories
{
    [ExcludeFromCodeCoverage]
    public class NECRepository : RepositoryBaseV2, INECRepository
    {
        public NECRepository(IConfiguration _config) : base("NECDB", _config)
        {
        }

        public async Task<short?> GetAccountStatus(int accountKey)
        {
            var result = await QueryAsync<Account>("[dbo].[GetAccountByAccountKey]",
                new
                {
                    pAccountKey = accountKey
                });
            return result.FirstOrDefault()?.AccountStatusKey;
        }
        public async Task<List<CardInventoryAndCardInfo>> GetCardInventoryAndCardByCardReferenceIds(List<Guid> typeCardReferenceIds)
        {
            var dataTable = new DataTable() { Columns = { "CardReferenceID" } };
            typeCardReferenceIds.ForEach(x => dataTable.Rows.Add(x));
            var result = await QueryAsync<CardInventoryAndCardInfo>("[dbo].[GetCardInventoryAndCardByCardReferenceIds]", new
            {
                ptypeCardReferenceIDs = dataTable
            });
            if (result == null) return new List<CardInventoryAndCardInfo>();
            return result.ToList();
        }

        public async Task<int> GetNECMaxFeeWaiverStatus()
        {
            var result = await QueryAsync<int>("[dbo].[GetNECMaxFeeWaiverStatus]", new { });
            return result.FirstOrDefault();
        }

        public async Task InsertManualFeeWaiverStatus(List<ManualFeeWaiverStatus> manualFeeWaiverStatuses)
        {
            var dt = new DataTable()
            {
                Columns =
                {
                    "CustomerKey",
                    "StartWaiveDate" ,
                    "EndWaiveDate",
                    "FeeWaiverKey",
                    "CreateDate"
                }
            };

            foreach (var payout in manualFeeWaiverStatuses)
            {
                var row = dt.NewRow();
                row["CustomerKey"] = payout.CustomerKey;
                row["StartWaiveDate"] = payout.StartWaiveDate;
                row["EndWaiveDate"] = payout.EndWaiveDate;
                row["FeeWaiverKey"] = payout.FeeWaiverKey;
                row["CreateDate"] = payout.CreateDate;
                dt.Rows.Add(row);
            }

            await QueryAsync<dynamic>("[dbo].[InsertManualFeeWaiverStatus]",
               new
               {
                   @typeManualFeeWaiverStatus = dt,
               });
        }

        public async Task PingTest()
        {
            await QueryAsync<int>("[dbo].[GetAccountKey]",
                     new
                     {
                         CustomerKey = 9249688
                     });

        }


        public async Task<List<AcceptedAgreement>> GetAcceptedAgreementsByAccountKey(int accountKey)
        {
            var result = await QueryAsync<AcceptedAgreement>("[dbo].[GetAcceptedAgreementsByAccountKey]",
                new
                {
                    @pAccountKey = accountKey,
                    @pAgreementVersionTransactionStatus = "ACCEPTED"
                });
            var agreements = result.ToList();
            
            var webUserAgreement = await QueryAsync<AcceptedAgreement>("WebUser.GetWebUser_Agreement",
            new
            {
                @pAccountKey = accountKey
            });

            webUserAgreement.ToList().ForEach(a => {
                if (a.IsAccepted)
                {
                    a.AgreementExpirationDate = DateTime.MaxValue;
                }
                else
                { 
                    a.AgreementExpirationDate = DateTime.Now;
                }
            });

            agreements.AddRange(webUserAgreement.ToList());
            

            return agreements.ToList();
        }

        public async Task<LinkedAccount> GetLinkedAccountByPrimaryAccountKey(long accountKey)
        {
            var result = await QueryAsync<LinkedAccount>("[dbo].[GetLinkedAccountKeyByAccountKey]",
                new
                {
                    @pAccountkey = (int)accountKey
                });
            return result.FirstOrDefault(a=>a.IsActive==true);
        }

        public async Task<List<AccountBalanceInfo>> GetAvailableBalanceByAccountkey(long accountKey)
        {
            var result = await QueryAsync<AccountBalanceInfo>("[dbo].[GetAccountBalanceInfoByAccountkey]",
                new
                {
                    @pAccountkey=(int)accountKey
                });
            return result.ToList();
        }

        public async Task<List<ACIProductDefinition>> GetACIProductDefinition(short productKey)
        {
            var result = await QueryAsync<ACIProductDefinition>("[dbo].[GetACIProductDefinitionByProductKey]",
                new
                {
                    @pProductkey = productKey
                });
            return result.ToList();
        }

        public async Task<List<PlasticInfo>> GetGetPlasticInfoByCardreference(string cardReference)
        {
            Console.WriteLine("start to GetGetPlasticInfoByCardreference");
            var result = await QueryAsync<PlasticInfo>("[dbo].[GetPlasticInfoByCardreference]",
                new
                {
                    @pCardReference = cardReference
                });
            return result.ToList();
        }

        public async Task<CustomerMembershipAndFeeGroup> GetConsolidationSourceDetailsByCutomerkeyAndAccountkey(int customerKey, int accountKey)
        {
            var multi = await QueryMultipleAsync<Membership, FeeGroup, FeeGroup, FeeGroup>("[dbo].[GetConsolidationSourceDetailsByCutomerkeyAndAccountkey]",
                new
                {
                    @pCustomerkey = customerKey,
                    @pAccountkey = accountKey
                });

            var customerMembership = multi.Item1.OrderByDescending(c => c.CustomerMembershipKey).FirstOrDefault();
            var customerFeeGroup = multi.Item2.FirstOrDefault();
            var accountFeeGroup = multi.Item3.FirstOrDefault();
            var feeWaiver = multi.Item4.FirstOrDefault();

            var customerMembershipAndFeeGroup = new CustomerMembershipAndFeeGroup()
            {
                CustomerMembershipKey = customerMembership?.CustomerMembershipKey ?? 0,
                MembershipKey = customerMembership?.MembershipKey ?? 0,
                MembershipGroupKey = customerMembership?.MembershipGroupKey ?? 0,
                MembershipTypeKey = customerMembership?.MembershipTypeKey ?? 0,
                FeeGroupKey = customerFeeGroup?.FeeGroupKey ?? 0,
                CustomerFeeGroupKey = customerFeeGroup?.CustomerFeeGroupKey ?? 0,
                Account_FeeGroupKey = accountFeeGroup?.Account_FeeGroupKey ?? 0,
                FeeWaiverGroupKey = feeWaiver?.FeeWaiverGroupKey ?? 0,
                Customer_FeeWaiverGroupKey = feeWaiver?.Customer_FeeWaiverGroupKey ?? 0
            };
            return customerMembershipAndFeeGroup;

        }

        public async Task<bool> AddCustomerFeeGroupAndMenbershipByAccountKeyAsync(int accountKey,int customerKey, short membershipTypeKey, short targetMembershipKey)
        {
            await QueryAsync<dynamic>("[dbo].[AddCustomerFeeGroupByAccountKeyAndCustomerkey]",
               new
               {
                   @pAccountKey = accountKey,
                   @pCustomerKey = customerKey,
                   @pMembershipTypeKey = membershipTypeKey,
                   @pStartDate = DateTime.Now,
                   @pMembershipKey = targetMembershipKey
               });

            return true;

        }

        public async Task<bool> AddCustomerMembershipAsync(int customerKey, short membershipTypeKey, short targetMembershipKey)
        {
            await QueryAsync<dynamic>("[dbo].[AddCustomerMembership]",
               new
               {
                   @pCustomerKey = customerKey,
                   @pMemberShipTypeKey = membershipTypeKey,
                   @pStartDate = DateTime.Now,
                   @pMembershipKey = targetMembershipKey
               });

            return true;

        }

        public async Task<PlasticInfo> UpdateConsolidationAccountDetailAsync(int cardKey, int accountKey, int customerKey, int newProductkey, string bankCode, short assocKey)
        {
            var result = await QueryAsync<PlasticInfo>("[dbo].[UpdateConsolidationAccountDetail]",
               new
               {
                   @pCardkey = cardKey,
                   @pAccountKey = accountKey,
                   @pCustomerkey = customerKey,
                   @pNewProductkey = newProductkey,
                   @pBankCode = bankCode,
                   @pAssocKey = assocKey
               });

            return result.ToList().FirstOrDefault();

        }


        public async Task<ProcessorProductInfo> GetProcessorProductCodesByCardReferenceIDAsync(Guid cardReferenceID, short membershipTypeKey)
        {
            //NPNR
            if (membershipTypeKey == 9)
            {
                //Try get NPNR ProcessorProduct
                var processorProductInfos = await QueryAsync<ProcessorProductInfo>("[dbo].GetProcessorProductCodesByCardReferenceID", new
                {
                    @pCardReferenceID = cardReferenceID,
                    @pProcessorProductTypeKey = 3  //NPNR
                });
                if (processorProductInfos.Count() > 0)
                    return processorProductInfos.ToList().FirstOrDefault();

                //Try get Temp ProcessorProduct
                processorProductInfos = await QueryAsync<ProcessorProductInfo>("[dbo].GetProcessorProductCodesByCardReferenceID", new
                {
                    @pCardReferenceID = cardReferenceID,
                    @pProcessorProductTypeKey = 1  //Temp
                });
                return processorProductInfos.ToList().FirstOrDefault();
            }

            //Get Perso ProcessorProduct
            var result = await QueryAsync<ProcessorProductInfo>("[dbo].GetProcessorProductCodesByCardReferenceID", new
            {
                @pCardReferenceID = cardReferenceID,
                @pProcessorProductTypeKey = 2  //Perso
            });

            if(result.Count() > 0)
                return result.ToList().FirstOrDefault();

            result = await QueryAsync<ProcessorProductInfo>("[dbo].GetProcessorProductCodesByCardReferenceID", new
            {
                @pCardReferenceID = cardReferenceID,
                @pProcessorProductTypeKey = 1  //Perso
            });
                return result.ToList().FirstOrDefault();
        }

        public async Task<List<AccountDetail>> GetCustomerCreditRatingkeyByAccountKeys(List<int> accountKeys)
        {
            var dt = new DataTable()
            {
                Columns =
                {
                    "AccountKey"
                }
            };

            foreach (var accountkey in accountKeys)
            {
                var row = dt.NewRow();
                row["AccountKey"] = accountkey;
                dt.Rows.Add(row);
            }

            var result = await QueryAsync<AccountDetail>("[dbo].[GetCustomerCreditRatingkeyByAccountKeys]",
               new
               {
                   @ptypeAccountkey = dt,
               });

            return result.ToList();
        }

        public async Task<ProductDetail> GetBinInfoByProductKey(short productKey)
        {
            var result = await QueryAsync<ProductDetail>("[dbo].[GetBinInfoByProductKey]",
               new
               {
                   @pProductKey = productKey
               });

            return result.ToList().FirstOrDefault();

        }

        public async Task<ProductDetail> GetAssociationByProductKey(short productKey)
        {
            var result = await QueryAsync<ProductDetail>("[dbo].[GetAssociationByProductKey]",
               new
               {
                   @pProductKey = productKey
               });

            return result.ToList().FirstOrDefault();

        }

        public async Task<List<AccountDetail>> GetCustomerMembershipByCustomerKeys(List<int> customerKeys)
        {
            var dt = new DataTable()
            {
                Columns =
                {
                    "CustomerKey"
                }
            };

            foreach (var accountkey in customerKeys)
            {
                var row = dt.NewRow();
                row["CustomerKey"] = accountkey;
                dt.Rows.Add(row);
            }


            var result = await QueryAsync<AccountDetail>("[dbo].[GetCustomerMembershipByCustomerKeys]",
               new
               {
                   @ptypeCustomerKey = dt
               });

            return result.ToList();

        }

        public async Task<FamilyAccount> GetFamilyLinkedAccounts(int accountKey)
        {
            var result = await QueryAsync<FamilyAccount>("[dbo].[GetFamilyLinkedAccounts]",
                new
                {
                    @accountKey = accountKey
                });

            return result.ToList().FirstOrDefault();

        }

        public async Task<FamilyAccount> GetProductKeyByAccountKey(int accountKey)
        {
            var result = await QueryAsync<FamilyAccount>("[dbo].[GetProductKeyByAccountKey]",
                new
                {
                    @pAccountKey = accountKey
                });

            return result.ToList().FirstOrDefault();

        }
        public async Task<bool> UpdateCustomerCardReferenceByCustomerKey(string cardReference, int customerKey)
        {
            await QueryAsync<dynamic>("[dbo].[UpdateCustomerCardReferenceByCustomerKey]",
               new
               {
                   @pCardReference = cardReference,
                   @pCustomerKey = customerKey
               });

            return true;

        }

        public async Task<AccountCustomerBillCycle> GetBillCycleInfoByAccountKey(int customerKey, int accountKey)
        {
            var multi = await QueryMultipleAsync<BillCycleDate, BillCycleDate>("[dbo].[GetBillCycleInfoByAccountKey]",
                new
                {
                    @pCustomerkey = customerKey,
                    @pAccountKey = accountKey
                });

            var accountBillCycle = multi.Item1.FirstOrDefault();
            var customerBillCycle = multi.Item2.FirstOrDefault();

            var accountCustomerBillCycle = new AccountCustomerBillCycle()
            {
                AccountBillCycleDay = accountBillCycle?.BillCycleDay,
                AccountFirstBillCycleDate = accountBillCycle?.FirstBillCycleDate,
                CustomerBillCycleDay = customerBillCycle?.BillCycleDay,
                CustomerFirstBillCycleDate = customerBillCycle?.FirstBillCycleDate
            };

            return accountCustomerBillCycle;

        }

        public async Task<bool> SetAccountCustomerBillCycle(int customerKey, DateTime activationDate)
        {
            await QueryAsync<dynamic>("[dbo].[MonthlyFee_CreateCustomerBillCycle]",
               new
               {
                   @pActivationDate = activationDate,
                   @pCustomerKey = customerKey
               });

            return true;

        }

        public async Task<bool> SetAccountBillCycle(int accountKey, short billCycleDay, DateTime? firstBillCycleDate)
        {
            await QueryAsync<dynamic>("[dbo].[AddAccount_BillCycle]",
               new
               {
                   @pAccountKey = accountKey,
                   @pBillCycleDay = billCycleDay,
                   @pFirstBillCycleDate = firstBillCycleDate
               });

            return true;

        }


        public async Task<List<AccountSubscription>> GetActiveAccountSubscriptionsByAccountKey(int accountKey)
        {
            var result = await QueryAsync<AccountSubscription>("[dbo].[GetActiveAccountSubscriptionsByAccountKey]",
                new
                {
                    @pAccountKey = accountKey,
                });
            return result.ToList();
        }

        #region AutoOrderCard
        public async Task<List<PlasticInformation>> GetAllPlasticsByAccountKey(int accountKey)
        {
            var result = await QueryAsync<PlasticInformation>("[dbo].[GetCardByAccountKey]", new { @pAccountKey=accountKey});
            return result.ToList();
        }

        public async Task<CreditRatingInfo> GetCustomerCreditRatingKeyByAccountKey(int accountKey)
        {
            var result = await QueryAsync<CreditRatingInfo>("[dbo].[GetCustomerCreditRatingKeyByAccountKey]", new { @pAccountKey = accountKey });
            return result.FirstOrDefault();
        }

        public async Task<List<TsysQueueRequest>> GetTsysQueueRequestByCustomerKey(int customerKey, short cmdCodeKey, DateTime requestDate)
        {
            var result = await QueryAsync<TsysQueueRequest>("[dbo].[GetTsysQueueRequestByCustomerKey]",
                new { @pCustomerKey = customerKey, @pCmdCodeKey= cmdCodeKey, @pRequestDate= requestDate });
            return result.ToList();
        }
        
        public async Task<ProductDefinitionInfo> GetProductInfoByCardReferenceID(Guid cardReferenceID)
        {
            var result = await QueryAsync<ProductDefinitionInfo>("[dbo].[GetProductInfoByCardReferenceID]",
                               new { @pCardReferenceID = cardReferenceID });
            return result.FirstOrDefault();
        }
        #endregion

        public async Task<List<LinkedAccount>> GetAccountLinkInfoByPrimaryAccountKeys(List<int> accountKeys)
        {
            var dt = new DataTable()
            {
                Columns =
                {
                    "AccountKey"
                }
            };

            foreach (var accountkey in accountKeys)
            {
                var row = dt.NewRow();
                row["AccountKey"] = accountkey;
                dt.Rows.Add(row);
            }


            var result = await QueryAsync<LinkedAccount>("[dbo].[GetAccountLinkInfoByPrimaryAccountKeys]",
               new
               {
                   @ptypeAccountkey = dt
               });

            return result.ToList();

        }

        public async Task InsertACIAccountClosureProcessBatch(List<int> customerKeys, string creditRating, string note,
            string changeBy)
        {
            var dt = new DataTable()
            {
                Columns =
                {
                    "CustomerKey"
                }
            };

            foreach (var customerKey in customerKeys)
            {
                var row = dt.NewRow();
                row["CustomerKey"] = customerKey;
                dt.Rows.Add(row);
            }

            await QueryAsync<dynamic>("[dbo].[InsertACIAccountClosureProcessBatch]",
                new
                {
                    @ptypeCustomerKey = dt,
                    @pNote = note,
                    @pCreditRatingKey = creditRating,
                    @pFullName = changeBy
                });

        }

        public async Task InsertACIWriteOffProcessBatch(List<int> customerKeys, string creditRating, string note,
            string changeBy)
        {
            var dt = new DataTable()
            {
                Columns =
                {
                    "CustomerKey"
                }
            };

            foreach (var customerKey in customerKeys)
            {
                var row = dt.NewRow();
                row["CustomerKey"] = customerKey;
                dt.Rows.Add(row);
            }

            await QueryAsync<dynamic>("[dbo].[InsertACIWriteOffProcessBatch]",
                new
                {
                    @ptypeCustomerKey = dt,
                    @pNote = note,
                    @pCreditRatingKey = creditRating,
                    @pFullName = changeBy
                });
        }

        public async Task<List<MembershipFee>> GetPYGDormancyInactivityFee(short membershipGroupKey)
        {
            var result = await QueryAsync<MembershipFee>("[dbo].[GetFeeByMembershipGroupKey]", new{
                @pMembershipGroupKey = membershipGroupKey
            });
            return result.ToList();
        }

        public async Task<List<AccountBalance>> GetAccountBalanceByPinKeys(List<int> pinKeys)
        {
            var dt = new DataTable()
            {
                Columns =
                {
                    "IntValue"
                }
            };

            foreach (var pinKey in pinKeys)
            {
                var row = dt.NewRow();
                row["IntValue"] = pinKey;
                dt.Rows.Add(row);
            }

            var result = await QueryAsync<AccountBalance>("[dbo].[GetAccountBalanceByPinKeys]", new
            {
                @ptypePinkey = dt
            });

            return result.ToList();
        }

        public async Task<int> GetMaxPYGInactivityDormancyTransactionKey()
        {
            var result = await ExecuteScalar<int>("[dbo].[GetMaxPYGInactivityDormancyTransactionKey]", new { });
            return result;
        }

        public async Task InsertPYGInactivityDormancyTransactions(List<InactivityDormancyTransaction> transactions)
        {
            var dt = new DataTable()
            {
                Columns =
                {
                    "PYGInactivityDormancyTransactionKey",
                    "PINKey",
                    "CreateDate",
                    "ChangeDate",
                    "FeeAmount",
                    "FeeTypeKey",
                    "InactiveFeesCharged",
                    "SerialNbr",
                    "FeeReversed",
                    "TransactionIdentifier",
                    "PYGInactivityDormancyTransactionStatusKey"
                }
            };

            foreach (var transaction in transactions)
            {
                var row = dt.NewRow();
                row["PYGInactivityDormancyTransactionKey"] = transaction.PYGInactivityDormancyTransactionKey;
                row["PINKey"] = transaction.PINKey;
                row["CreateDate"] = transaction.CreateDate;
                row["ChangeDate"] = transaction.ChangeDate;
                row["FeeAmount"] = transaction.FeeAmount;
                row["FeeTypeKey"] = transaction.FeeTypeKey;
                row["InactiveFeesCharged"] = transaction.InActiveFeesCharged;
                row["SerialNbr"] = transaction.SerialNbr;
                row["FeeReversed"] = 0;
                row["TransactionIdentifier"] = transaction.TransactionIdentifier;
                row["PYGInactivityDormancyTransactionStatusKey"] = (short)PYGInactivityDormancyTransactionStatus.Initial;
                dt.Rows.Add(row);
            }

            await QueryAsync<dynamic>("[dbo].[InsertPYGInactivityDormancyTransactions]",
                new
                {
                    @ptypePYGInactivityDormancyTransactions = dt,
                });
        }

        public async Task InsertPYGInactivityFeeByBatch(List<InactivityDormancyTransaction> transactions, short transTypeKey, string transactionDescription, short detailAccountTransactionTypeKey)
        {
            var dt = new DataTable()
            {
                Columns =
                {
                    "PYGInactivityDormancyTransactionKey",
                    "PINKey",
                    "CreateDate",
                    "ChangeDate",
                    "FeeAmount",
                    "FeeTypeKey",
                    "InactiveFeesCharged",
                    "SerialNbr",
                    "FeeReversed",
                    "TransactionIdentifier",
                    "PYGInactivityDormancyTransactionStatusKey"
                }
            };

            foreach (var transaction in transactions)
            {
                var row = dt.NewRow();
                row["PYGInactivityDormancyTransactionKey"] = transaction.PYGInactivityDormancyTransactionKey;
                row["PINKey"] = transaction.PINKey;
                row["CreateDate"] = transaction.CreateDate;
                row["ChangeDate"] = transaction.ChangeDate;
                row["FeeAmount"] = transaction.FeeAmount;
                row["FeeTypeKey"] = transaction.FeeTypeKey;
                row["InactiveFeesCharged"] = transaction.InActiveFeesCharged;
                row["SerialNbr"] = transaction.SerialNbr;
                row["FeeReversed"] = transaction.FeeReversed;
                row["TransactionIdentifier"] = transaction.TransactionIdentifier;
                row["PYGInactivityDormancyTransactionStatusKey"] = transaction.PYGInactivityDormancyTransactionStatusKey;
                dt.Rows.Add(row);
            }

            await QueryAsync<dynamic>("[dbo].[InsertPYGInactivityFeeByBatch]",
                new
                {
                    @ptypePYGInactivityDormancyTransactions = dt,
                    @pSysUserKey = 10,
                    @pApplicationKey = 1,
                    @pSysComponentKey = 1,
                    @pTransTypeKey = transTypeKey,
                    @pTransactionDescription = transactionDescription,
                    @pAccountTransactionStatusKey = 1,
                    @pDetailAccountTransactionTypeKey = detailAccountTransactionTypeKey
                });
        }

        public async Task UpdatePYGInactivityDormancyTransactions(List<InactivityDormancyTransaction> transactions)
        {
            var dt = new DataTable()
            {
                Columns =
                {
                    "PYGInactivityDormancyTransactionKey",
                    "PINKey",
                    "CreateDate",
                    "ChangeDate",
                    "FeeAmount",
                    "FeeTypeKey",
                    "InactiveFeesCharged",
                    "SerialNbr",
                    "FeeReversed",
                    "TransactionIdentifier",
                    "PYGInactivityDormancyTransactionStatusKey"
                }
            };

            foreach (var transaction in transactions)
            {
                var row = dt.NewRow();
                row["PYGInactivityDormancyTransactionKey"] = transaction.PYGInactivityDormancyTransactionKey;
                row["PINKey"] = transaction.PINKey;
                row["CreateDate"] = transaction.CreateDate;
                row["ChangeDate"] = transaction.ChangeDate;
                row["FeeAmount"] = transaction.FeeAmount;
                row["FeeTypeKey"] = transaction.FeeTypeKey;
                row["InactiveFeesCharged"] = transaction.InActiveFeesCharged;
                row["SerialNbr"] = transaction.SerialNbr;
                row["FeeReversed"] = transaction.FeeReversed;
                row["TransactionIdentifier"] = transaction.TransactionIdentifier;
                row["PYGInactivityDormancyTransactionStatusKey"] = transaction.PYGInactivityDormancyTransactionStatusKey;
                dt.Rows.Add(row);
            }

            await QueryAsync<dynamic>("[dbo].[UpdatePYGInactivityDormancyTransactions]",
                new
                {
                    @ptypePYGInactivityDormancyTransactions = dt,
                });
        }
    }
}
