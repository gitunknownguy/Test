﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.DataAccess.Repositories
{
    public interface ICache
    {
        TValue GetData<TValue>(string key);

        /// <summary>Inserts an item in cache which never expires</summary>
        void InsertData<TValue>(string key, TValue value);

        /// <summary>Inserts an item in cache with the specified expiration time</summary>
        void InsertData<TValue>(string key, TValue value, TimeSpan expirationTime);

        bool RemoveData(string key);
    }
}
