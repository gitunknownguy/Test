﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AppSupportProcessor.DataAccess.Base;
using AppSupportProcessor.Model.AccountClosure;
using AppSupportProcessor.Model.DO;
using AppSupportProcessor.Model.InactivityFee;
using AppSupportProcessor.Model.PDS;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace AppSupportProcessor.DataAccess.Repositories
{
    public class ReportRepository : RepositoryBaseV2, IReportRepository
    {
        private int SpecialTimeoutSeconds;
        public ReportRepository(IConfiguration _config) : base("ReportDB", _config)
        {
            SpecialTimeoutSeconds = int.Parse(_config?.GetSection("DBVariables")?["SpecialTimeoutSeconds"] ?? "14400");
        }
        

        public async Task InsertPYGInactivityFee(decimal feeAmount, short feeTypeKey)
        {
           await QueryAsync<dynamic>("[dbo].[InsertPYGInactivityFee]",
              new
              {
                  @pFeeAmount = feeAmount,
                  @pFeeTypeKey = feeTypeKey,
              }, SpecialTimeoutSeconds);
        }

        public async Task<List<InactivityDormancyTransaction>> GetPYGInactivityDormancyTransactionsByBatch(int highWaterMarkKey, int batchSize)
        {
            var result = await QueryAsync<InactivityDormancyTransaction>("[dbo].[GetPYGInactivityDormancyTransactionsByBatch]",
                               new
                               {
                                   @pHighWaterMarkKey = highWaterMarkKey,
                                   @pBatchSize = batchSize
                               });

            return result.ToList();
        }
    }
}
