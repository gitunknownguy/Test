﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AppSupportProcessor.DataAccess.Base;
using AppSupportProcessor.Model.AccountClosure;
using AppSupportProcessor.Model.DO;
using AppSupportProcessor.Model.PDS;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace AppSupportProcessor.DataAccess.Repositories
{
    public class CDSRepository : RepositoryBaseV2, ICDSRepository
    {
        public CDSRepository(IConfiguration _config) : base("CDSDB", _config)
        {
        }
        

        public async Task<List<PurseInfo>> GetPurseBalanceByAccountKeys(List<Guid> accountKeys)
        {
            var dt = new DataTable()
            {
                Columns = { "AccountKey" }
            };

            foreach (var accountKey in accountKeys)
            {
                var row = dt.NewRow();
                row["AccountKey"] = accountKey;
                dt.Rows.Add(row);
            }

            var result = await QueryAsync<PurseInfo>("[dbo].[GetPurseBalanceByAccountKeys]",
                new
                {
                    @ptypeAccountKeys = dt,
                });
            return result.ToList();
        }
    }
}
