﻿using AppSupportProcessor.DataAccess.Base;
using AppSupportProcessor.Model.AccountClosure;
using AppSupportProcessor.Model.AutoOrderCard;
using AppSupportProcessor.Model.Consolidation;
using AppSupportProcessor.Model.Enum;
using AppSupportProcessor.Model.Interest;
using AppSupportProcessor.Model.NRT;
using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;

namespace AppSupportProcessor.DataAccess.Repositories
{
    [ExcludeFromCodeCoverage]
    public class NECNRTRepository : RepositoryBaseV2, INECNRTRepository
    {
        private int TimeoutSeconds;
        private int SpecialTimeoutSeconds;
        private readonly Microsoft.Extensions.Logging.ILogger<NECNRTRepository> _logger;

        public NECNRTRepository(IConfiguration _config, Microsoft.Extensions.Logging.ILogger<NECNRTRepository> logger) : base("NRTDB", _config)
        {
            Console.WriteLine("NRTDB Connection string is:" + _config.GetConnectionString("NRTDB"));
            TimeoutSeconds = int.Parse(_config?.GetSection("DBVariables")?["TimeoutSeconds"] ?? "300");
            SpecialTimeoutSeconds = int.Parse(_config?.GetSection("DBVariables")?["SpecialTimeoutSeconds"] ?? "7200");
            _logger = logger;
            _logger.LogInformation("Interest-dbconnectionstr NRTDB Connection string is:" + _config.GetConnectionString("NRTDB"));
        }

        public Task<short?> GetAccountStatus(int accountKey)
        {
            return Task.FromResult<short?>(1);
        }

        //this method has three steps within a transaction:
        //1  get high water mark
        //2  insert a batch data to new table
        //3  update high water mark
        public async Task InsertBatchDataToReimbursePayout(int tableNamekey, int batchSize)
        {
            SqlTransaction transaction = null;

            using (var conn = GetSqlConnection())
            {
                try
                {
                    conn.Open();
                    transaction = conn.BeginTransaction();


                    var highWaterMark = await conn.QueryAsync<HighWaterMarkResponse>(
                                                                 "[dbo].[GetNRTHighWaterMark]", new
                                                                 {
                                                                     @pTableNameKey = tableNamekey
                                                                 }, transaction, TimeoutSeconds, commandType: CommandType.StoredProcedure);
                    var highWatermarkKey = highWaterMark.First().HighWaterMarkKey;
                    Console.WriteLine("#2 InterestReimbursementHandler-Step-2.1 highWaterMark key is: " + highWatermarkKey);

                    var dynamicParams = new DynamicParameters();
                    dynamicParams.Add("pHighWaterMarkKey", highWatermarkKey);
                    dynamicParams.Add("pbatchSize", batchSize);
                    dynamicParams.Add("pReturnedHighWaterMarkKey", dbType: DbType.Int64, direction: ParameterDirection.Output);
                    await conn.QueryAsync<dynamic>("[dbo].[InsertDepositAccountInterestReimbursePayoutByBatch]", dynamicParams, transaction, TimeoutSeconds, commandType: CommandType.StoredProcedure);
                    var nextWatermarkKey = dynamicParams.Get<long?>("@pReturnedHighWaterMarkKey");
                    Console.WriteLine("#2 InterestReimbursementHandler-Step-2.2 next water mark key is: " + nextWatermarkKey);


                    await conn.QueryAsync<int>("[dbo].[UpdateNRTHighWaterMarkByTableNameKey]",
                                                new
                                                {
                                                    @pTableNameKey = tableNamekey,
                                                    @pHighWaterMark = nextWatermarkKey
                                                },
                                                transaction, TimeoutSeconds, commandType: CommandType.StoredProcedure);
                    Console.WriteLine("#2 InterestReimbursementHandler-Step-2.3 update high water mark success");

                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("#2 InterestReimbursementHandler-Step-2-exception: " + ex.ToString());
                    try
                    {
                        transaction.Rollback();
                    }
                    catch (Exception ex2)
                    {
                        Console.WriteLine("#2 InterestReimbursementHandler-Step-2-rollback-exception: " + ex2.ToString());
                    }
                }
            }
        }

        /// <summary>
        ///for single step test use
        /// </summary>
        /// <param name="tableNamekey"></param>
        /// <returns></returns>
        public async Task<HighWaterMarkResponse> GetHighWaterMark(int tableNamekey)
        {
            var result = await QueryAsync<HighWaterMarkResponse>("[dbo].[GetNRTHighWaterMark]",
                new
                {
                    @pTableNameKey = tableNamekey
                });
            return result.First();
        }

        /// <summary>
        /// for single step test use
        /// </summary>
        /// <param name="tableNamekey"></param>
        /// <param name="highWaterMark"></param>
        /// <returns></returns>
        public async Task UpdateNRTHighWaterMarkByTableNameKey(int tableNamekey, long highWaterMark)
        {
            await QueryAsync<dynamic>("[dbo].[UpdateNRTHighWaterMarkByTableNameKey]",
                new
                {
                    @pTableNameKey = tableNamekey,
                    @pHighWaterMark = highWaterMark
                });
        }

        /// <summary>
        /// for single step test use
        /// </summary>
        /// <param name="highWaterMark"></param>
        /// <param name="batchSize"></param>
        /// <returns></returns>
        public async Task<long?> InsertDepositAccountInterestReimbursePayoutByBatch(long highWaterMark, int batchSize)
        {
            var dynamicParams = new DynamicParameters();
            dynamicParams.Add("@pHighWaterMarkKey", highWaterMark);
            dynamicParams.Add("@pbatchSize", batchSize);
            dynamicParams.Add("@pReturnedHighWaterMarkKey", dbType: DbType.Int64, direction: ParameterDirection.Output);
            await QueryReturnOutputAsync<dynamic>("[dbo].[InsertDepositAccountInterestReimbursePayoutByBatch]", dynamicParams);
            return dynamicParams.Get<long?>("@pReturnedHighWaterMarkKey");
        }

        public async Task<List<MembershipInterestAccrual>> GetAllMembershipInterestAccrual()
        {
            var result = await QueryAsync<MembershipInterestAccrual>("[dbo].[GetAllMembershipInterestAccrual]", null);
            return result.ToList();
        }

        public async Task<List<DepositAccountInterestReimbursePayout>> GetDepositAccountInterestReimbursePayoutByBatch(int batchSize)
        {
            var result = await QueryAsync<DepositAccountInterestReimbursePayout>("[dbo].[GetDepositAccountInterestReimbursePayoutByBatch]",
                new { @pBatchSize = batchSize });
            return result.ToList();
        }

        public async Task<List<CustomerMembership>> GetDepositAccountMemberShipAndStatusByLinkedAccountKey(List<int> accountKeyList)
        {
            var dataTable = new DataTable() { Columns = { "AccountKey" } };
            accountKeyList.ForEach(x => dataTable.Rows.Add(x));

            var result = await QueryAsync<CustomerMembership>("[dbo].[GetDepositAccountMemberShipAndStatusByLinkedAccountKey]",
                new { @ptypeAccountKey = dataTable });
            return result.ToList();
        }

        public async Task UpdateDepositAccountInterestReimbursePayout(List<DepositAccountInterestReimbursePayout> updatedReimbursePayout)
        {
            var dt = new DataTable()
            {
                Columns = { "DepositAccountInterestReimbursePayoutKey",
                            "NewInterestAmount" ,
                            "DepositAccountInterestReimbursePayoutStatusKey",
                            "InterestReimburseAmount",
                            "Description",}
            };
            updatedReimbursePayout.ForEach(x =>
                dt.Rows.Add(x.DepositAccountInterestReimbursePayoutKey,
                            x.NewInterestAmount,
                            x.DepositAccountInterestReimbursePayoutStatusKey,
                            x.InterestReimburseAmount,
                            x.Description)
            );

            await QueryAsync<dynamic>("[dbo].[UpdateDepositAccountInterestReimbursePayout]",
               new
               {
                   @ptypeDepositAccountInterestReimbursePayout = dt,
               });
        }

        public async Task<List<AccountBalance>> GetDepositAccountBalance(int accountKey, DateTime startDate, DateTime endDate)
        {
            var result = await QueryAsync<AccountBalance>("[dbo].[GetDepAcctBalanceHistoryByAcctKeyforMonthlyAvgCal]",
                new
                {
                    @pAccountKey = accountKey,
                    @pStartDate = startDate.Date,// to make sure only use the date part
                    @pEndDate = endDate.Date,
                });

            return result.ToList();

        }

        public async Task<List<DepositAccountInterestReimbursePayout>> GetCalculatedDepositAccountInterestReimbursePayoutByBatch(int batchSize)
        {
            var result = await QueryAsync<DepositAccountInterestReimbursePayout>("[dbo].[GetDepositAccountInterestReimbursePayoutByPayoutStatusKey]",
               new
               {
                   @pBatchSize = batchSize
               });
            return result.ToList();
        }

        public async Task UpdateDepositAccountInterestReimbursePayoutForFunding(List<DepositAccountInterestReimbursePayout> updatedReimbursePayouts)
        {
            var dt = new DataTable()
            {
                Columns = { "DepositAccountInterestReimbursePayoutKey",
                            "AccountTransactionKey" ,
                            "PayoutDate",
                            "Description",
                            "DepositAccountInterestReimbursePayoutStatusKey",}
            };

            foreach (var payout in updatedReimbursePayouts)
            {
                var row = dt.NewRow();
                row["DepositAccountInterestReimbursePayoutKey"] = payout.DepositAccountInterestReimbursePayoutKey;
                row["AccountTransactionKey"] = payout.AccountTransactionKey;
                row["PayoutDate"] = payout.PayoutDate;
                row["Description"] = payout.Description;
                row["DepositAccountInterestReimbursePayoutStatusKey"] = payout.DepositAccountInterestReimbursePayoutStatusKey;
                dt.Rows.Add(row);
            }

            await QueryAsync<dynamic>("[dbo].[UpdateDepositAccountInterestReimbursePayoutForFunding]",
               new
               {
                   @ptypeDepositAccountInterestReimbursePayoutResult = dt,
               });
        }

        public async Task TruncateETL_ManualFeeWaiverStatus_Staging()
        {
            await QueryAsync<dynamic>("[dbo].[TruncateETL_ManualFeeWaiverStatus_Staging]", new { });
        }

        public async Task GetManualFeeWaiverStatusByEffectiveFeeDate(DateTime date, int batchSize = 10000)
        {
            await QueryAsync<dynamic>("[dbo].[GetManualFeeWaiverStatusByEffectiveFeeDate]", new
            {
                @EffectiveFeeDate = date,
                @Batchsize = batchSize
            }, SpecialTimeoutSeconds);
        }

        public async Task<List<ETL_ManualFeeWaiverStatus_Staging>> GetETL_ManualFeeWaiverStatus_Staging(int? startPk, int batchSize = 5000)
        {
            var result = await QueryAsync<ETL_ManualFeeWaiverStatus_Staging>("[dbo].[GetETL_ManualFeeWaiverStatus_Staging]", new
            {
                @pStartPK = startPk,
                @pBatchSize = batchSize
            });
            return result.ToList();
        }

        public async Task MonthlyFeeProcessorInit(DateTime effectiveFeeDate)
        {
            var dynamicParams = new DynamicParameters();
            dynamicParams.Add("@pEffectiveFeeDate", effectiveFeeDate);
            dynamicParams.Add("@pMonthlyFeeProcessingRequestKey", dbType: DbType.Int32, direction: ParameterDirection.Output);
            dynamicParams.Add("@pMonthlyFeeProcessingRequestActivityKey", dbType: DbType.Int32, direction: ParameterDirection.Output);
            await QueryReturnOutputAsync<dynamic>("[dbo].[MonthlyFeeProcessorInit]", dynamicParams);
        }

        public async Task<int> GetNRTMaxFeeWaiverStatus()
        {
            var result = await QueryAsync<int>("[dbo].[GetNRTMaxFeeWaiverStatus]", new { });
            return result.FirstOrDefault();
        }

        public async Task<MonthlyFeeProcessingRequest> MonthlyFeeGetCurrentFeeProcessingRequest(short monthlyFeeProcessingTypeKey, DateTime effectiveFeeDate)
        {
            var dynamicParams = new DynamicParameters();
            dynamicParams.Add("@MonthlyFeeProcessingTypeKey", monthlyFeeProcessingTypeKey);
            dynamicParams.Add("@EffectiveFeeDate", effectiveFeeDate);
            dynamicParams.Add("@MonthlyFeeProcessingRequestKey", dbType: DbType.Int32, direction: ParameterDirection.Output);
            dynamicParams.Add("@MonthlyFeeProcessingRequestStatusKey", dbType: DbType.Int16, direction: ParameterDirection.Output);
            dynamicParams.Add("@StartDate", dbType: DbType.DateTime, direction: ParameterDirection.Output);
            dynamicParams.Add("@EndDate", dbType: DbType.DateTime, direction: ParameterDirection.Output);
            await QueryReturnOutputAsync<dynamic>("[dbo].[MonthlyFeeGetCurrentFeeProcessingRequest]", dynamicParams);
            var monthlyFeeProcessingRequestKey = dynamicParams.Get<int?>("@MonthlyFeeProcessingRequestKey");
            var monthlyFeeProcessingRequestStatusKey = dynamicParams.Get<short?>("@MonthlyFeeProcessingRequestStatusKey");
            var startDate = dynamicParams.Get<DateTime?>("@StartDate");
            var endDate = dynamicParams.Get<DateTime?>("@EndDate");
            return new MonthlyFeeProcessingRequest()
            {
                EndDate = endDate,
                StartDate = startDate,
                MonthlyFeeProcessingRequestKey = monthlyFeeProcessingRequestKey,
                MonthlyFeeProcessingRequestStatusKey = monthlyFeeProcessingRequestStatusKey
            };
        }

        public async Task<List<ConsolidationAccount>> GetConsolidationAccountAsync(short consolidationStatus, List<short> productKeyList, int batchSize)
        {
            var dtProducts = new DataTable()
            {
                Columns = { "ProductKey", }
            };

            foreach (var productKey in productKeyList)
            {
                var row = dtProducts.NewRow();
                row["Productkey"] = productKey;
                dtProducts.Rows.Add(row);
            }

            var result = await QueryAsync<ConsolidationAccount>("[dbo].[GetConsolidationAccountByProductKeyAndConsolidationStatusKey]", new
            {
                @ptypeProductKey = dtProducts,
                @pConsolidationStatusKey = consolidationStatus,
                @pBatchSize = batchSize
            });
            return result.ToList();
        }

        public async Task<List<ConsolidationAccountActivity>> GetConsolidationActivityAsync(long consolidationAccountKey)
        {
            var result = await QueryAsync<ConsolidationAccountActivity>("[dbo].[GetConsolidationAccountActivityByConsolidationAccountKey]", new
            {
                @pConsolidationAccountKey = consolidationAccountKey
            });
            return result.ToList();
        }

        public async Task<ConsolidationAccount> UpdateConsolidationStatusAsync(long consolidationAccountkey, short oldConsolidationStatus, short newConsolidationStatus)
        {
            var result = await QueryAsync<ConsolidationAccount>("[dbo].[UpdateConsolidationAccountByConsolidationAccountKey]",
                new
                {
                    @pConsolidationAccountKey = consolidationAccountkey,
                    @pOldConsolidationStatusKey = oldConsolidationStatus,
                    @pNewConsolidationStatusKey = newConsolidationStatus
                });

            return result.ToList().FirstOrDefault();
        }


        public async Task<bool> InsertConsolidationActivitiesAsync(long consolidationAccountKey, List<short> activities)
        {
            try
            {
                var dt = new DataTable()
                {
                    Columns = { "ConsolidationActivityKey",
                            "ConsolidationActivityStatusKey" ,
                            "ActivityDetail"}
                };

                foreach (var activity in activities)
                {
                    var row = dt.NewRow();
                    row["ConsolidationActivityKey"] = activity;
                    row["ConsolidationActivityStatusKey"] = (short)ActivityStatus.Pending;
                    row["ActivityDetail"] = DBNull.Value;
                    dt.Rows.Add(row);
                }

                await QueryAsync<dynamic>("[dbo].[insertConsolidationAccountActivity]",
                   new
                   {
                       @pConsolidationAccountKey = consolidationAccountKey,
                       @ptypeConsolidationAccountActivity = dt,
                   });

                return true;
            }
            catch (Exception ex)
            {
                _logger.LogInformation("InsertConsolidationActivities failed:" + ex.Message);
            }

            return false;
        }

        public async Task<bool> UpdateConsolidationAccountActivityByConsolidationAccountActivityKeyAsync
            (long consolidationAccountActivityKey, short consolidationActivityStatusKey, string activityDetail, short retryCount)
        {
            try
            {

                await QueryAsync<dynamic>("[dbo].[UpdateConsolidationAccountActivityByConsolidationAccountActivityKey]",
                   new
                   {
                       @pConsolidationAccountActivityKey = consolidationAccountActivityKey,
                       @pConsolidationActivityStatusKey = consolidationActivityStatusKey,
                       @pActivityDetail = activityDetail,
                       @pRetryCount = retryCount
                   });

                return true;
            }
            catch (Exception ex)
            {
                _logger.LogInformation("UpdateConsolidationAccountActivityByConsolidationAccountActivityKey failed:" + ex.Message);
            }

            return false;
        }

        public async Task<List<ConsolidationProductMapping>> GetAllConsolidationProductMappingAsync()
        {
            var result = await QueryAsync<ConsolidationProductMapping>("[dbo].[GetAllConsolidationProductMapping]", null);
            return result.ToList();
        }

        public async Task<List<ConsolidationProductMapping>> GetAllTargetConsolidationProductMappingAsync()
        {
            var result = await QueryAsync<ConsolidationProductMapping>("[dbo].[GetAllTargetConsolidationProductMapping]", null);

            return result.ToList();
        }

        public async Task<ConsolidationAccountActivity> GetConsolidationAccountActivityByKeyAsync(long activityKey)
        {
            var result = await QueryAsync<ConsolidationAccountActivity>("[dbo].[GetConsolidationAccountActivityByConsolidationAccountActivityKey]",
                new
                {
                    @pConsolidationAccountActivityKey = activityKey,
                });
            return result.ToList().FirstOrDefault();
        }

        public async Task<long> AddConsolidationAccountFile(ConsolidationAccountFile consolidationAccountFile)
        {
            var consolidationAccountFileKey = await ExecuteScalar<long>("[dbo].[InsertConsolidationAccountFile]",
                new
                {
                    @pConsolidationFileName = consolidationAccountFile.ConsolidationFileName,
                    @pConsolidationFilePath = consolidationAccountFile.ConsolidationFilePath,
                    @pConsolidationFileStatusKey = consolidationAccountFile.ConsolidationFileStatusKey
                });

            if (consolidationAccountFileKey <= 0)
            {
                throw new Exception("Failed to insert ConsolidationAccountFile");
            }

            return consolidationAccountFileKey;
        }

        public async Task UpdateConsolidationAccountFile(ConsolidationAccountFile consolidationAccountFile)
        {
            await QueryAsync<dynamic>("[dbo].[UpdateConsolidationAccountFile]",
            new
            {
                @pConsolidationAccountFileKey = consolidationAccountFile.ConsolidationAccountFileKey,
                @pConsolidationFileStatusKey = consolidationAccountFile.ConsolidationFileStatusKey,
                @pConsolidationFileArchivedPath = consolidationAccountFile.ConsolidationFileArchivedPath
            });
        }

        public async Task<ConsolidationAccountFile> GetConsolidationAccountFileByFileName(string fileName)
        {
            var result = await QueryAsync<ConsolidationAccountFile>("[dbo].[GetConsolidationAccountFilebyConsolidationFileName]",
                               new
                               {
                                   @pConsolidationFileName = fileName
                               });

            return result?.FirstOrDefault();
        }

        public async Task<List<ConsolidationAccount>> GetConsolidationAccountsByBatch(List<ConsolidationAccount> accounts)
        {
            var dt = new DataTable()
            {
                Columns = { "AccountKey" }
            };

            foreach (var account in accounts)
            {
                var row = dt.NewRow();
                row["AccountKey"] = account.AccountKey;
                dt.Rows.Add(row);
            }

            var result = await QueryAsync<ConsolidationAccount>("[dbo].[GetConsolidationAccountByAccountKeys]",
                               new
                               {
                                   @ptypeAccountKey = dt
                               });

            return result.ToList();
        }


        public async Task AddConsolidationAccountsByBatch(List<ConsolidationAccount> accounts)
        {
            accounts = accounts.Distinct(new ConsolidationAccountCompare()).ToList();
            var dt = new DataTable()
            {
                Columns = { "AccountKey", "Productkey", "CustomerKey", "CardReference", "ConsolidationGroupKey", "ConsolidationStatusKey", "ConsolidationAccountFileKey" }
            };

            foreach (var account in accounts)
            {
                var row = dt.NewRow();
                row["AccountKey"] = account.AccountKey;
                row["Productkey"] = account.ProductKey;
                row["CustomerKey"] = account.CustomerKey;
                row["CardReference"] = account.CardReference;
                row["ConsolidationGroupKey"] = account.ConsolidationGroupKey;
                row["ConsolidationStatusKey"] = account.ConsolidationStatusKey;
                row["ConsolidationAccountFileKey"] = account.ConsolidationAccountFileKey;
                dt.Rows.Add(row);
            }

            await QueryAsync<dynamic>("[dbo].[InsertConsolidationAccount]",
                  new
                  {
                      @ptypeConsolidationAccount = dt
                  });

        }

        public async Task UpdateConsolidationAccountsStatusByBatch(List<ConsolidationAccount> accounts, ConsolidationStatus oldStatus)
        {
            var dt = new DataTable()
            {
                Columns = { "ConsolidationAccountKey", "AccountKey", "ConsolidationStatusKey", "ConsolidationAccountFileKey" }
            };

            foreach (var account in accounts)
            {
                var row = dt.NewRow();
                row["ConsolidationAccountKey"] = account.ConsolidationAccountKey;
                row["AccountKey"] = account.AccountKey;
                row["ConsolidationStatusKey"] = account.ConsolidationStatusKey;
                row["ConsolidationAccountFileKey"] = account.ConsolidationAccountFileKey <= 0 ? (object)null : account.ConsolidationAccountFileKey;
                dt.Rows.Add(row);
            }

            await QueryAsync<ConsolidationAccount>("[dbo].[UpdateConsolidationAccountDetail]",
                  new
                  {
                      @ptypeConsolidationAccountChange = dt,
                      @pOldConsolidationStatusKey = (short)oldStatus
                  });
        }

        public async Task<List<MembershipInterest>> GetAllMembershipInterestAccrualAsync()
        {
            var result = await QueryAsync<MembershipInterest>("[dbo].[GetAllMembershipInterestAccrual]", null);

            return result.ToList();
        }

        #region AutoOrderCard
        public async Task AddAutoOrderCardAccountsByBatch(List<AutoOrderCardAccount> accounts)
        {
            var dt = new DataTable()
            {
                Columns = { "AccountKey",  "CustomerKey"}
            };

            foreach (var account in accounts)
            {
                var row = dt.NewRow();
                row["AccountKey"] = account.AccountKey;
                row["CustomerKey"] = account.CustomerKey;
                dt.Rows.Add(row);
            }

            await QueryAsync<dynamic>("[dbo].[InsAutoOrderCardAccountByDaily]",
            new
            {
                @pTypeAutoOrderCardAccountKey = dt
            });

        }

        public async Task<List<AutoOrderCardAccount>> GetAutoOrderCardAccountByBatch(int batchSize, long minAutoOrderCardAccountKey = 0)
        {
            var result = await QueryAsync<AutoOrderCardAccount>("[dbo].[GetAutoOrderCardAccountByBatch]",
                               new { @pMinAutoOrderCardAccountKey = minAutoOrderCardAccountKey, @pBatch= batchSize });
            return result.ToList();
        }

        public async Task UpdateAutoOrderCardAccount(AutoOrderCardAccount account)
        {
            await QueryAsync<dynamic>("[dbo].[UpdateAutoOrderCardAccountByAutoOrderCardAccountKey]",
               new
               {
                   @pAutoOrderCardAccountKey = account.AutoOrderCardAccountKey,
                   @pAutoOrderCardAccountStatusKey = account.AutoOrderCardAccountStatusKey,
                   @pAutoOrderCardAccountStatusReason = account.AutoOrderCardAccountStatusReason
               });
        }

        public async Task<List<EmailInfo>> GetEmailInfoByAccountKey(int accountKey)
        {
            var result = await QueryAsync<EmailInfo>("[dbo].[GetConsumerProfileInfoByAccountKey]",
                               new { @pAccountKey = accountKey });
            return result.ToList();
        }
        #endregion


        #region BackFill BillCycle For Legacy DDAAccounts

        public async Task<List<BillCycleCustomer_Staging>> GetBackFillBillCycleCustomerStaging(int batchSize)
        {
            var result = await QueryAsync<BillCycleCustomer_Staging>("[dbo].[GetBackFillBillCycleCustomerStaging]",
                new { @pBatchSize = batchSize });
            return result.ToList();
        }

        public async Task UpdateBackFillBillCycleCustomerStagingStatus(long backFillBillCycleCustomerStagingKey)
        {
            await QueryAsync<dynamic>("[dbo].[UpdateBackFillBillCycleCustomerStaging]",
                new
                {
                    @pETL_BackFillBillCycleCustomerStagingKey = backFillBillCycleCustomerStagingKey
                });
        }
        #endregion

        #region Accountclosure
        public async Task<ACIAccountClosureRequest> GetACIAccountClosureRequestByFileName(string fileName)
        {
            var result = await QueryAsync<ACIAccountClosureRequest>("[dbo].[GetACIAccountClosureRequestByRequestFileName]",
                               new
                               {
                                   pRequestFileName = fileName
                               });

            return result?.FirstOrDefault();
        }

        public async Task<long> AddACIAccountClosureRequest(ACIAccountClosureRequest accountClosureRequest)
        {
            var aciAccountClosureRequestKey = await ExecuteScalar<long>("[dbo].[InsertACIAccountClosureRequest]",
                new
                {
                    @pACIAccountClosureRequestStatusKey = accountClosureRequest.ACIAccountClosureRequestStatusKey,
                    @pRequestFileType = accountClosureRequest.RequestFileType,
                    @pRequestFileName = accountClosureRequest.RequestFileName,
                    @pACIFileName = accountClosureRequest.ACIFileName,
                    @pRequestFilePath = accountClosureRequest.RequestFilePath,
                    @pRequestFileProcessDate = accountClosureRequest.RequestFileProcessDate,
                    @pTotalCount = accountClosureRequest.TotalCount,
                });

            if (aciAccountClosureRequestKey <= 0)
            {
                throw new Exception("Failed to insert ACIAccountClosureRequest");
            }

            return aciAccountClosureRequestKey;
        }

        public async Task UpdateACIAccountClosureRequestStatus(ACIAccountClosureRequest accountClosureRequest)
        {
            var aciAccountClosureRequestKey = await QueryAsync<dynamic>("[dbo].[UpdateACIAccountClosureRequestByACIAccountClosureRequestKey]",
               new
               {
                   @pACIAccountClosureRequestKey = accountClosureRequest.ACIAccountClosureRequestKey,
                   @pACIAccountClosureRequestStatusKey = accountClosureRequest.ACIAccountClosureRequestStatusKey,
               });
        }

        public async Task InsertACIAccountClosureByBatch(List<ACIAccountClosure> accountClosurelist)
        {
            accountClosurelist = accountClosurelist.Distinct(new ACIAccountClosureCompare()).ToList();
            var dt = new DataTable()
            {
                Columns = { "ACIAccountClosureStatusKey", "ACIAccountClosureRequestKey", "CustomerKey", "AccountKey", "ACIAccountExternalID", "FileIdentifier", "VaultBalance", "CardExternalID" }
            };

            foreach (var account in accountClosurelist)
            {
                var row = dt.NewRow();
                row["ACIAccountClosureStatusKey"] = account.ACIAccountClosureStatusKey;
                row["ACIAccountClosureRequestKey"] = account.ACIAccountClosureRequestKey;
                row["CustomerKey"] = account.CustomerKey;
                row["AccountKey"] = account.AccountKey;
                row["ACIAccountExternalID"] = account.ACIAccountExternalID;
                row["FileIdentifier"] = account.FileIdentifier;
                row["VaultBalance"] = account.VaultBalance;
                row["CardExternalID"] = account.CardExternalID;
                dt.Rows.Add(row);
            }

            await QueryAsync<dynamic>("[dbo].[InsertACIAccountClosure]",
                  new
                  {
                      @ptypeACIAccountClosure = dt
                  });
        }

        public async Task<List<ACIAccountClosure>> GetACIAccountClosuresList(long accountClosureRequestKey, int batchSize, long accountClosureKey, short accountClosureStatusKey)
        {
            var result = await QueryAsync<ACIAccountClosure>("[dbo].[GetACIAccountClosureByACIAccountClosureRequestKey]",
                               new
                               {
                                   @pCount = batchSize,
                                   @pACIAccountClosureStatusKey = accountClosureStatusKey,
                                   @pACIAccountClosureRequestKey = accountClosureRequestKey,
                                   @pACIAccountClosureKey = accountClosureKey
                               });

            return result.ToList();
        }

        public async Task<List<ACIAccountClosureRequest>> GetACIAccountClosureRequestByStatus(short requestStatusKey)
        {
            var result = await QueryAsync<ACIAccountClosureRequest>("[dbo].[GetACIAccountClosureRequestByStatusKey]",
                               new
                               {
                                   @pACIAccountClosureRequestStatusKey = requestStatusKey
                               });

            return result.ToList();
        }

        public async Task UpdateACIAccountClosureStatusByBatch(List<ACIAccountClosure> accounts)
        {
            var dt = new DataTable()
            {
                Columns = { "ACIAccountClosureStatusKey", "ACIAccountClosureKey", "ACIAccountClosureResponseKey", "ResponseCode", "ResponseMessage" }
            };

            foreach (var account in accounts)
            {
                var row = dt.NewRow();
                row["ACIAccountClosureStatusKey"] = account.ACIAccountClosureStatusKey;
                row["ACIAccountClosureKey"] = account.ACIAccountClosureKey;
                row["ACIAccountClosureResponseKey"]=account.ACIAccountClosureResponseKey;
                row["ResponseCode"] = account.ResponseCode;
                row["ResponseMessage"] = account.ResponseMessage;
                dt.Rows.Add(row);
            }

            await QueryAsync<ConsolidationAccount>("[dbo].[UpdateACIAccountClosureByACIAccountClosureKey]",
                  new
                  {
                      @ptypeACIAccountClosureResponse = dt
                  });
        }

        public async Task UpdateACIAccountClosureStatusByBatch(List<ACIAccountClosure> accounts, short statusKey)
        {
            accounts.ForEach(a => a.ACIAccountClosureStatusKey = statusKey);
            await UpdateACIAccountClosureStatusByBatch(accounts);
        }

        public async Task<List<FamilyAccount>> GetFamilyAccountInfoByAccountKeys(List<int> accountKeys)
        {
            var dt = new DataTable()
            {
                Columns =
                {
                    "AccountKey"
                }
            };

            foreach (var accountkey in accountKeys)
            {
                var row = dt.NewRow();
                row["AccountKey"] = accountkey;
                dt.Rows.Add(row);
            }


            var result = await QueryAsync<FamilyAccount>("[dbo].[GetFamilyAccountInfoByAccountKeys]",
               new
               {
                   @ptypeAccountKeys = dt
               });

            return result.ToList();

        }

        public async Task<ACIAccountClosureResponse> GetACIAccountClosureResponseByFileName(string fileName)
        {
            var result = await QueryAsync<ACIAccountClosureResponse>(
                "[dbo].[GetACIAccountClosureResponseKeyByResponseFileName]",
                new
                {
                    @pResponseFileName = fileName
                });
            return result.FirstOrDefault();
        }

        public async Task<long> AddACIAccountClosureResponse(ACIAccountClosureResponse accountClosureResponse)
        {
            var responseKey = await ExecuteScalar<long>("[dbo].[InsertACIAccountClosureResponse]",
                new
                {
                    @pACIAccountClosureRequestKey = accountClosureResponse.ACIAccountClosureRequestKey,
                    @pResponseFileName = accountClosureResponse.ResponseFileName,
                    @pResponseFilePath = accountClosureResponse.ResponseFilePath,
                    @pResponseFileProcessDate = DateTime.Now,
                    @pTotalCount = accountClosureResponse.TotalCount,
                });
            return responseKey;
        }

        public async Task<ACIAccountClosureRequest> GetACIAccountClosureRequestByACIFileName(string fileName)
        {
            var result = await QueryAsync<ACIAccountClosureRequest>(
                "[dbo].[GetACIAccountClosureRequestByACIFileName]",
                new
                {
                    @pACIFileName = fileName
                });
            return result.FirstOrDefault();
        }

        public async Task<List<ACIAccountClosure>> GetACIAccountClosureByCardExternalID(long accountClosureRequestKey, List<string> cardProxyList)
        {
            var dt = new DataTable()
            {
                Columns = { "CardProxy" }
            };

            foreach (var cardProxy in cardProxyList)
            {
                var row = dt.NewRow();
                row["CardProxy"] = cardProxy;
                dt.Rows.Add(row);
            }

            var result= await QueryAsync<ACIAccountClosure>("[dbo].[GetACIAccountClosureByCardExternalID]",
                new
                {
                    @ptypeCardProxys = dt,
                    @pACIAccountClosureRequestKey = accountClosureRequestKey,
                });
            return result.ToList();
        }

        public async Task<List<Customer>> GetCardInfoByCustomerkeys(List<int> customerKeys)
        {
            var dt = new DataTable()
            {
                Columns = { "CustomerKey" }
            };

            foreach (var customerkey in customerKeys)
            {
                var row = dt.NewRow();
                row["CustomerKey"] = customerkey;
                dt.Rows.Add(row);
            }

            var result = await QueryAsync<Customer>("[dbo].[GetCardInfoByCustomerkeys]",
                new
                {
                    @ptypeCustomerkey = dt
                });
            return result.ToList();
        }

        #endregion
    }
}

