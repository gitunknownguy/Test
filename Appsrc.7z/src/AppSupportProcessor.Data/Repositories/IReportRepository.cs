﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using AppSupportProcessor.Model.DO;
using AppSupportProcessor.Model.InactivityFee;
using AppSupportProcessor.Model.PDS;

namespace AppSupportProcessor.DataAccess.Repositories
{
    public interface IReportRepository
    {
        Task InsertPYGInactivityFee(decimal feeAmount, short feeTypeKey);
        Task<List<InactivityDormancyTransaction>> GetPYGInactivityDormancyTransactionsByBatch(int highWaterMarkKey, int batchSize);
    }
}
