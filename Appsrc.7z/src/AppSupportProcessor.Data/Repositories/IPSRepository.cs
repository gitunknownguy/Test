﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AppSupportProcessor.DataAccess.Base;
using AppSupportProcessor.Model.AccountClosure;
using AppSupportProcessor.Model.DO;
using AppSupportProcessor.Model.PDS;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace AppSupportProcessor.DataAccess.Repositories
{
    public class IPSRepository : RepositoryBaseV2, IIPSRepository
    {
        public IPSRepository(IConfiguration _config) : base("IPSDB", _config)
        {
        }
        public async Task<List<GetCardTranslationInventoryInfo>> GetCardTranslationInventoryByCardExternalIDs(List<string> proxyIds, int processorKey)        {            if (proxyIds == null || proxyIds.Count == 0) return await Task.FromResult(new List<GetCardTranslationInventoryInfo>());            var dataTable = new DataTable() { Columns = { "ProxyID" } };            proxyIds.ForEach(x => dataTable.Rows.Add(x));            var result = await QueryAsync<GetCardTranslationInventoryInfo>("[dbo].[GetCardTranslationInventoryByCardExternalIDs]", new { pProxyIDList = dataTable, pProcessorKey = processorKey });            if (result == null) return new List<GetCardTranslationInventoryInfo>();            return result.ToList();        }
        public async Task<List<CardTranslationInfo>> GetCardTranslationByCardExternalIDs(List<string> proxyIds, int processorKey)        {            if (proxyIds == null || proxyIds.Count == 0) return await Task.FromResult(new List<CardTranslationInfo>());            var dataTable = new DataTable() { Columns = { "ProxyID" } };            proxyIds.ForEach(x => dataTable.Rows.Add(x));            var result = await QueryAsync<CardTranslationInfo>("[dbo].[GetCardTranslationByCardExternalIDs]", new { pProxyIDList = dataTable, pProcessorKey = processorKey });            if (result == null) return new List<CardTranslationInfo>();            return result.ToList();
        }
        public async Task<List<CardTranslationInventoryExceptionHandlerInfo>> GetETL_CardTranslationInventory_ExceptionHandlerByBatch(int batchSize, string status)        {            var result = await QueryAsync<CardTranslationInventoryExceptionHandlerInfo>("[dbo].[GetETL_CardTranslationInventory_ExceptionHandlerByBatch]", new { pBatchSize = batchSize, pStatus = status });            if(result==null) return new List<CardTranslationInventoryExceptionHandlerInfo>();            return result.ToList();        }
        public async Task<int> InsertETLCardTranslationInventoryException(int interval)
        {
            var result = await QueryAsync<int>("[dbo].[InsertETL_CardTranslationInventory_ExceptionHandler]", new { pInterval = interval });
            return result.FirstOrDefault();
        }
        public async Task<int> UpdateETL_CardTranslationInventory_ExceptionHandlerByBatch(List<ETLCardTranslationInventoryExceptionHandlerInfo> handlerInfos)        {            if (handlerInfos == null || handlerInfos.Count == 0) return await Task.FromResult(0);            var dataTable = new DataTable() { Columns = { "ETL_CardTranslationInventory_ExceptionHandlerKey", "ExceptionHandlerStatus", "ExceptionHandlerDescription" } };            handlerInfos.ForEach(x => dataTable.Rows.Add(x.ETL_CardTranslationInventory_ExceptionHandlerKey, x.ExceptionHandlerStatus, x.ExceptionHandlerDescription));            var result = await QueryAsync<int>("[dbo].[UpdateETL_CardTranslationInventory_ExceptionHandlerByBatch]", new { @ptypeETL_CardTranslationInventory_ExceptionHandler = dataTable });
            var execCount= result.FirstOrDefault();            return execCount;        }
        public async Task UpdateCardTranslationInventoryToDeprecateCardProxy(List<ExceptionHandlerKeyInfo> infos, int processorKey)        {            if (infos == null || infos.Count == 0) return;            var dataTable = new DataTable() { Columns = { "CardReferenceID", "CardExternalID" } };            infos.ForEach(x => dataTable.Rows.Add(x.CardReferenceID, x.CardExternalID.Trim()));            await QueryAsync<dynamic>("[dbo].[UpdateCardTranslationInventoryToDeprecateCardProxy]", new { @ptypeExceptionHandler = dataTable, @pProcessorKey = processorKey });        }
        [ExcludeFromCodeCoverage]
        public async Task PingTest()
        {
            await QueryAsync<int>("[dbo].[getProcessorKey]", new { IP_ShortName = "IPS", OP_ProcessorKey = 1 });
        }
        public async Task<List<GetCardTranslationInventoryInfo>> GetCardTranslationInventoryByCardReferenceIds(List<Guid> cardRefrenceIds)        {            if (cardRefrenceIds == null || cardRefrenceIds.Count == 0) return await Task.FromResult(new List<GetCardTranslationInventoryInfo>());            var dataTable = new DataTable() { Columns = { "CardReferenceID" } };            cardRefrenceIds.ForEach(x => dataTable.Rows.Add(x));            var result = await QueryAsync<GetCardTranslationInventoryInfo>("[dbo].[GetCardTranslationInventoryByCardReferenceIds]", new { @ptypeCardReferenceId = dataTable });            if (result == null) return new List<GetCardTranslationInventoryInfo>();            return result.ToList();        }

        public async Task<List<AccountTranslationInfo>> GetAccountKeysByAccountReferenceIDs(List<Guid> accountReferenceIds)
        {
            var dt = new DataTable()
            {
                Columns = { "AccountReferenceID" }
            };

            foreach (var accountReferenceId in accountReferenceIds)
            {
                var row = dt.NewRow();
                row["AccountReferenceID"] = accountReferenceId;
                dt.Rows.Add(row);
            }

            var result = await QueryAsync<AccountTranslationInfo>("[dbo].[GetAccountKeysByAccountReferenceIDs]",
                new
                {
                    @ptypeAccountReferenceIDs = dt,
                });
            return result.ToList();
        }

        public async Task<List<CardTranslationInfo>> GetCardExternalIDByCardReferenceIDs(List<Guid> cardReferenceIds)
        {
            var dt = new DataTable()
            {
                Columns = { "CardReferenceID" }
            };

            foreach (var cardReferenceId in cardReferenceIds)
            {
                var row = dt.NewRow();
                row["CardReferenceID"] = cardReferenceId;
                dt.Rows.Add(row);
            }

            var result = await QueryAsync<CardTranslationInfo>("[dbo].[GetCardExternalIDByCardReferenceIDs]",
                new
                {
                    @typeCardReferenceID = dt,
                });
            return result.ToList();
        }
    }
}
