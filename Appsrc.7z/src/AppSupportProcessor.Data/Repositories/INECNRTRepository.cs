﻿using AppSupportProcessor.Model.AccountClosure;
using AppSupportProcessor.Model.AutoOrderCard;
using AppSupportProcessor.Model.Consolidation;
using AppSupportProcessor.Model.Enum;
using AppSupportProcessor.Model.Interest;
using AppSupportProcessor.Model.NRT;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AppSupportProcessor.DataAccess.Repositories
{
    public interface INECNRTRepository
    {
        Task<short?> GetAccountStatus(int accountKey);

        /// <summary>
        /// combine 3 steps into 1 transaction
        /// 1 GetHighWaterMark
        /// 2 InsertDepositAccountInterestReimbursePayoutByBatch
        /// 3 UpdateNRTHighWaterMarkByTableNameKey
        /// </summary>
        /// <param name="tableNamekey"></param>
        /// <param name="batchSize"></param>
        /// <returns></returns>
        Task InsertBatchDataToReimbursePayout(int tableNamekey, int batchSize);

        /// <summary>
        /// for single step test use
        /// </summary>
        /// <param name="tableNamekey"></param>
        /// <returns></returns>
        Task<HighWaterMarkResponse> GetHighWaterMark(int tableNamekey);

        /// <summary>
        /// for single step test use
        /// </summary>
        /// <param name="tableNamekey"></param>
        /// <param name="highWaterMark"></param>
        /// <returns></returns>
        Task UpdateNRTHighWaterMarkByTableNameKey(int tableNamekey, long highWaterMark);

        /// <summary>
        /// for single step test use
        /// </summary>
        /// <param name="highWaterMark"></param>
        /// <param name="batchSize"></param>
        /// <returns></returns>
        Task<long?> InsertDepositAccountInterestReimbursePayoutByBatch(long highWaterMark, int batchSize);

        Task<List<MembershipInterestAccrual>> GetAllMembershipInterestAccrual();

        Task<List<DepositAccountInterestReimbursePayout>> GetDepositAccountInterestReimbursePayoutByBatch(int batchSize);

        Task<List<CustomerMembership>> GetDepositAccountMemberShipAndStatusByLinkedAccountKey(List<int> accountKeyList);

        Task UpdateDepositAccountInterestReimbursePayout(List<DepositAccountInterestReimbursePayout> updatedReimbursePayout);

        Task<List<AccountBalance>> GetDepositAccountBalance(int accountKey, DateTime startDate, DateTime endDate);

        Task<List<DepositAccountInterestReimbursePayout>> GetCalculatedDepositAccountInterestReimbursePayoutByBatch(int batchSize);

        Task UpdateDepositAccountInterestReimbursePayoutForFunding(List<DepositAccountInterestReimbursePayout> updatedReimbursePayout);

        Task TruncateETL_ManualFeeWaiverStatus_Staging();

        Task GetManualFeeWaiverStatusByEffectiveFeeDate(DateTime date, int batchSize = 10000);

        Task<List<ETL_ManualFeeWaiverStatus_Staging>> GetETL_ManualFeeWaiverStatus_Staging(int? startPk, int batchSize = 5000);

        Task MonthlyFeeProcessorInit(DateTime effectiveFeeDate);

        Task<int> GetNRTMaxFeeWaiverStatus();

        Task<MonthlyFeeProcessingRequest> MonthlyFeeGetCurrentFeeProcessingRequest(short monthlyFeeProcessingTypeKey, DateTime effectiveFeeDate);
        Task<List<ConsolidationAccount>> GetConsolidationAccountAsync(short consolidationStatus, List<short> productKeyList, int batchSize);
        Task<List<ConsolidationAccountActivity>> GetConsolidationActivityAsync(long consolidationAccountKey);
        Task<ConsolidationAccount> UpdateConsolidationStatusAsync(long consolidationAccountkey, short oldConsolidationStatus, short newConsolidationStatus);        
        Task<bool> InsertConsolidationActivitiesAsync(long consolidationAccountkey, List<short> activities);
        Task<List<ConsolidationProductMapping>> GetAllConsolidationProductMappingAsync();
        Task<bool> UpdateConsolidationAccountActivityByConsolidationAccountActivityKeyAsync
            (long consolidationAccountActivityKey, short consolidationActivityStatusKey, string activityDetail, short retryCount);
        Task<List<ConsolidationProductMapping>> GetAllTargetConsolidationProductMappingAsync();
        Task<ConsolidationAccountActivity> GetConsolidationAccountActivityByKeyAsync(long activityKey);

        Task<long> AddConsolidationAccountFile(ConsolidationAccountFile consolidationAccountFile);
        Task UpdateConsolidationAccountFile(ConsolidationAccountFile consolidationAccountFile);
        Task<ConsolidationAccountFile> GetConsolidationAccountFileByFileName(string fileName);
        Task<List<ConsolidationAccount>> GetConsolidationAccountsByBatch(List<ConsolidationAccount> accounts);
        Task AddConsolidationAccountsByBatch(List<ConsolidationAccount> accounts);
        Task UpdateConsolidationAccountsStatusByBatch(List<ConsolidationAccount> accounts, ConsolidationStatus oldStatus);
        Task<List<MembershipInterest>> GetAllMembershipInterestAccrualAsync();

        #region AutoOrderCard
        Task AddAutoOrderCardAccountsByBatch(List<AutoOrderCardAccount> accounts);
        Task<List<AutoOrderCardAccount>> GetAutoOrderCardAccountByBatch(int batchSize, long minAutoOrderCardAccountKey = 0);
        Task UpdateAutoOrderCardAccount(AutoOrderCardAccount account);
        Task<List<EmailInfo>> GetEmailInfoByAccountKey(int accountKey);
        #endregion

        #region  BackFill BillCycle For Legacy DDAAccounts

        Task<List<BillCycleCustomer_Staging>> GetBackFillBillCycleCustomerStaging(int batchSize);

        Task UpdateBackFillBillCycleCustomerStagingStatus(long backFillBillCycleCustomerStagingKey);

        #endregion

        #region Accountclosure
        Task<ACIAccountClosureRequest> GetACIAccountClosureRequestByFileName(string fileName);
        Task<long> AddACIAccountClosureRequest(ACIAccountClosureRequest accountClosureRequest);
        Task UpdateACIAccountClosureRequestStatus(ACIAccountClosureRequest accountClosureRequest);
        Task InsertACIAccountClosureByBatch(List<ACIAccountClosure> accountClosurelist);
        Task<List<ACIAccountClosure>> GetACIAccountClosuresList(long accountClosureRequestKey, int batchSize, long accountClosureKey, short accountClosureStatusKey);
        Task<List<ACIAccountClosureRequest>> GetACIAccountClosureRequestByStatus(short requestStatusKey);
        Task<ACIAccountClosureResponse> GetACIAccountClosureResponseByFileName(string fileName);
        Task<long> AddACIAccountClosureResponse(ACIAccountClosureResponse accountClosureResponse);
        Task UpdateACIAccountClosureStatusByBatch(List<ACIAccountClosure> accounts);
        Task UpdateACIAccountClosureStatusByBatch(List<ACIAccountClosure> accounts, short statusKey);
        Task<List<FamilyAccount>> GetFamilyAccountInfoByAccountKeys(List<int> accountKeys);
        Task<ACIAccountClosureRequest> GetACIAccountClosureRequestByACIFileName(string fileName);

        Task<List<ACIAccountClosure>> GetACIAccountClosureByCardExternalID(long accountClosureRequestKey,List<string> cardProxyList);
        Task<List<Customer>> GetCardInfoByCustomerkeys(List<int> customerKeys);
        #endregion
    }
}
