﻿using AppSupportProcessor.Model.AutoOrderCard;
using AppSupportProcessor.Model.Consolidation;
using AppSupportProcessor.Model.InactivityFee;
using AppSupportProcessor.Model.NEC;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AppSupportProcessor.DataAccess.Repositories
{
    public interface INECRepository
    {
        Task<short?> GetAccountStatus(int accountKey);

        Task<List<CardInventoryAndCardInfo>> GetCardInventoryAndCardByCardReferenceIds(List<Guid> typeCardReferenceIds);

        Task PingTest();

        Task InsertManualFeeWaiverStatus(List<ManualFeeWaiverStatus> manualFeeWaiverStatuses);

        Task<int> GetNECMaxFeeWaiverStatus();

        Task<List<AcceptedAgreement>> GetAcceptedAgreementsByAccountKey(int accountKey);
        Task<LinkedAccount> GetLinkedAccountByPrimaryAccountKey(long accountKey);
        Task<List<AccountBalanceInfo>> GetAvailableBalanceByAccountkey(long accountKey);
        Task<List<ACIProductDefinition>> GetACIProductDefinition(short productKey);
        Task<List<PlasticInfo>> GetGetPlasticInfoByCardreference(string cardReference);
        Task<CustomerMembershipAndFeeGroup> GetConsolidationSourceDetailsByCutomerkeyAndAccountkey(int customerKey, int accountKey);
        Task<bool> AddCustomerFeeGroupAndMenbershipByAccountKeyAsync(int accountKey,int customerKey, short membershipTypeKey, short targetMembershipKey);
        Task<bool> AddCustomerMembershipAsync(int customerKey, short membershipTypeKey, short targetMembershipKey);
        Task<PlasticInfo> UpdateConsolidationAccountDetailAsync(int cardKey, int accountKey, int customerKey, int newProductkey, string bankCode, short assocKey);
        Task<ProcessorProductInfo> GetProcessorProductCodesByCardReferenceIDAsync(Guid cardReferenceID, short membershipTypeKey);
        Task<List<AccountDetail>> GetCustomerCreditRatingkeyByAccountKeys(List<int> accountKeys);
        Task<ProductDetail> GetBinInfoByProductKey(short productKey);
        Task<ProductDetail> GetAssociationByProductKey(short productKey);
        Task<List<AccountDetail>> GetCustomerMembershipByCustomerKeys(List<int> customerKeys);
        Task<FamilyAccount> GetFamilyLinkedAccounts(int accountKey);
        Task<FamilyAccount> GetProductKeyByAccountKey(int accountKey);
        Task<bool> UpdateCustomerCardReferenceByCustomerKey(string cardReference, int customerKey);
        Task<AccountCustomerBillCycle> GetBillCycleInfoByAccountKey(int customerKey, int accountKey);
        Task<bool> SetAccountCustomerBillCycle(int customerKey, DateTime activationDate);
        Task<bool> SetAccountBillCycle(int accountKey, short billCycleDay, DateTime? firstBillCycleDate);
        Task<List<AccountSubscription>> GetActiveAccountSubscriptionsByAccountKey(int accountKey);

        #region AutoOrderCard
        Task<List<PlasticInformation>> GetAllPlasticsByAccountKey(int accountKey);
        Task<CreditRatingInfo> GetCustomerCreditRatingKeyByAccountKey(int accountKey);
        Task<List<TsysQueueRequest>> GetTsysQueueRequestByCustomerKey(int customerKey, short cmdCodeKey, DateTime requestDate);
        Task<ProductDefinitionInfo> GetProductInfoByCardReferenceID(Guid cardReferenceID);
        #endregion

        Task<List<LinkedAccount>> GetAccountLinkInfoByPrimaryAccountKeys(List<int> accountKeys);
        Task InsertACIAccountClosureProcessBatch(List<int> customerKeys,string creditRating,string note,string changeBy);
        Task InsertACIWriteOffProcessBatch(List<int> customerKeys, string creditRating, string note, string changeBy);

        Task<List<MembershipFee>> GetPYGDormancyInactivityFee(short membershipGroupKey);
        Task<int> GetMaxPYGInactivityDormancyTransactionKey();
        Task<List<AccountBalance>> GetAccountBalanceByPinKeys(List<int> pinKeys);
        Task InsertPYGInactivityDormancyTransactions(List<InactivityDormancyTransaction> transactions);
        Task InsertPYGInactivityFeeByBatch(List<InactivityDormancyTransaction> transactions, short transTypeKey, string transactionDescription, short detailAccountTransactionTypeKey);
        Task UpdatePYGInactivityDormancyTransactions(List<InactivityDormancyTransaction> transactions);
    }
}
