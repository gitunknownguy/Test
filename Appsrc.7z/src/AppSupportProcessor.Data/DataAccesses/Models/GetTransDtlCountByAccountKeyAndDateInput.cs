﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Sql.Mappings.Models;

namespace AppSupportProcessor.DataAccess.DataAccesses.Models
{
    public class GetTransDtlCountByAccountKeyAndDateInput
    {
        [Parameter(TableValuedTypeName = "TypeAccountKeys")]
        public DataTable ptypeAccountKeys { get; set; }
        public DateTime pStartDate { get; set; }
        public DateTime pEndDate { get; set; }
    }

    public class AccountKeyInfo
    {
        public int AccountKey { get; set; }

        public override bool Equals(object obj)
        {
            AccountKeyInfo p = obj as AccountKeyInfo;
            if (p == null)
            {
                return false;
            }

            return this.AccountKey.Equals(p.AccountKey);
        }

        public override int GetHashCode()
        {
            return this.AccountKey.GetHashCode();
        }
    }
}
