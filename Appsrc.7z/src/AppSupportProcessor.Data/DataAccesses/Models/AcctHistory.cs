﻿using Gd.Sql.Mappings.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.DataAccess.DataAccesses.Models
{
    public class AcctHistory
    {
        public DateTime TransDate { get; set; }
        public short TransTypeKey { get; set; }
        public decimal TransAmt { get; set; }
        public string SerialNbr { get; set; }
        public string TransactionIdentifier { get; set; }
        public int AccountKey { get; set; }
    }
}
