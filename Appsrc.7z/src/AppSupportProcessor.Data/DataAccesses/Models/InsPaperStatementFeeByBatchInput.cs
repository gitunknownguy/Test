﻿using Gd.Sql.Mappings.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.DataAccess.DataAccesses.Models
{
    public class InsPaperStatementFeeByBatchInput
    {
        [Parameter(TableValuedTypeName = "typePaperStatementFee")]
        public DataTable ptypePaperStatementFee { get; set; }

        public string pTransactionDescription { get; set; }

        public short pAccountTransactionStatusKey { get; set; }

        public short pDetailAccountTransactionTypeKey { get; set; }
    }
}
