﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Sql.Mappings.Models;

namespace AppSupportProcessor.DataAccess.DataAccesses.Models
{
    public class InsertPaperStatementInput
    {
        [Parameter(TableValuedTypeName = "typeInsertPaperStatement")]
        public DataTable ptypeInsertPaperStatement { get; set; }
    }

    public class UpdatePaperStatementInput
    {
        [Parameter(TableValuedTypeName = "typePaperStatement")]
        public DataTable ptypePaperStatement { get; set; }
    }

    public class PaperStatementInfoNoIdentifier
    {
        public long? PaperStatementKey { get; set; }
        public int AccountKey { get; set; }
        public short? BillCycleDay { get; set; }
        public DateTime BillCycleDate { get; set; }
        public short? PaperStatementStatusKey { get; set; }
        public int? TransactionCount { get; set; }
        public string CreditRatingKey { get; set; }
        public string PaperStatementFilePath { get; set; }
        public int? RetryCount { get; set; }
        public short? PortfolioKey { get; set; }
    }


    public class PaperStatementInfo 
    {
        public long? PaperStatementKey { get; set; }
        public int AccountKey { get; set; }
        public short? BillCycleDay { get; set; }
        public DateTime BillCycleDate { get; set; }
        public short? PaperStatementStatusKey { get; set; }
        public int? TransactionCount { get; set; }
        public string CreditRatingKey { get; set; }
        public string PaperStatementFilePath { get; set; }
        public int? RetryCount { get; set; }
        public short? PortfolioKey { get; set; }
        public string PaperStatementIdentifier { get; set; }
    }

    public enum PaperStatementStatus
    {
        Pending = 1,
        Ignored = 2,
        InProgress = 3,
        Generated = 4,
        Failed = 5,
        RetryCountExceeded = 6,
        NoAvailableStatements = 7
    }

    public enum EStatementProductType
    {
        WMT,
        GDC 
    }
}
