﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gd.Sql.Mappings.Models;

namespace AppSupportProcessor.DataAccess.DataAccesses.Models
{
    public class GetPaperStatementByStatusInput
    {
        public int pBatchSize { get; set; }
        public short pPaperStatementStatusKey { get; set; }
        public int pRetryCountIncrease { get; set; }
    }
}
