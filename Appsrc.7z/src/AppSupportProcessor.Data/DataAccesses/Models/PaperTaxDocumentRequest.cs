﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.DataAccess.DataAccesses.Models
{
    public class PaperTaxDocumentRequest
    {
        public long PaperTaxDocumentRequestKey { get; set; }
        public long TaxDocumentRequestKey { get; set; }
        public string PaperTaxDocumentRequestPath { get; set; }
        public short PaperTaxDocumentRequestStatusKey { get; set; }
        public int RetryCount { get; set; }
        public int AccountKey { get; set; }
        public string DocumentPath { get; set; }
    }
}
