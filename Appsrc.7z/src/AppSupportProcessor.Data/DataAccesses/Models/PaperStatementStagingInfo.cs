﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.DataAccess.DataAccesses.Models
{
    public class PaperStatementStagingInfo
    {
        public long PaperStatementStagingKey { get; set; }
        public int AccountKey { get; set; }
        public short BillCycleDay { get;set; }
        public DateTime BillCycleDate { get; set; }
        public string CreditRatingKey { get; set; }
        public int TransactionCount { get; set; }
        public short? PortfolioKey { get; set; }
        public int? BCD1TransactionCount { get; set; }
        public short? BCD1PaperStatementStatusKey { get; set; }
        public int? BCD2TransactionCount { get; set; }
        public short? BCD2PaperStatementStatusKey { get; set; }
    }
}
