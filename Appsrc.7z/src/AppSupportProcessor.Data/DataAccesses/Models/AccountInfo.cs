﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.DataAccess.DataAccesses.Models
{
    public class AccountInfo
    {
        public int AccountKey { get; set; }
        public decimal AvailableBalance { get; set; }
        public decimal CurrentBalance { get; set; }
        public string SerialNbr { get; set; }
        public short ProductKey { get; set; }

    }
}
