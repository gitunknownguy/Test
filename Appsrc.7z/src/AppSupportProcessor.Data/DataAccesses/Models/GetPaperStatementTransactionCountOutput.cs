﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.DataAccess.DataAccesses.Models
{
    public class GetPaperStatementTransactionCountOutput
    {
        public int AccountKey { get; set; }
        public DateTime BillCycleDate { get; set; }
        public int? TransactionCount { get; set; }
        public short? PaperStatementStatusKey { get; set; }
    }
}
