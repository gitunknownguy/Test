﻿using System.Collections.Generic;

namespace AppSupportProcessor.DataAccess.DataAccesses.Models
{
    public class PaperStatementPkRangeForDelete
    {
        public long? MinPaperStatementKey { get; set; }
        public long? MaxPaperStatementKey { get; set; }

        public List<PaperStatementPkRangeForDelete> GetSplitRangeList(int rangeSize = 1000)
        {
            if (MinPaperStatementKey == null || MaxPaperStatementKey ==null)
            {
                return new List<PaperStatementPkRangeForDelete>();
            }
            List<PaperStatementPkRangeForDelete> ranges = new List<PaperStatementPkRangeForDelete>();

            // Number with full step size
            long fullRangeCount = ((long)MaxPaperStatementKey - (long)MinPaperStatementKey) / rangeSize;
            long rangeStart = (long)MinPaperStatementKey;
            long rangeEnd = (long)MinPaperStatementKey + rangeSize -1;
            for (int i = 0; i < fullRangeCount; i++)
            {
                ranges.Add(new PaperStatementPkRangeForDelete
                {
                    MinPaperStatementKey = rangeStart,
                    MaxPaperStatementKey = rangeEnd
                });
                rangeStart = rangeEnd + 1;
                rangeEnd = rangeStart + rangeSize - 1;
            }
            //  extra range
            ranges.Add(new PaperStatementPkRangeForDelete
            {
                MinPaperStatementKey = rangeStart,
                MaxPaperStatementKey = MaxPaperStatementKey
            });
            return ranges;
        }
    }
}
