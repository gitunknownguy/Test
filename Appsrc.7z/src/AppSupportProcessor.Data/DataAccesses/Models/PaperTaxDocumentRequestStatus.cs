﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.DataAccess.DataAccesses.Models
{
    public enum PaperTaxDocumentRequestStatus
    {
        Pending = 1,
        Processing = 2,
        Completed = 3,
        Failed = 4,
        Expired = 5
    }
}
