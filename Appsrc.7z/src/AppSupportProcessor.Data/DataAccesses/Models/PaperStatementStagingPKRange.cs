﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.DataAccess.DataAccesses.Models
{
    public class PaperStatementStagingPkRange
    {
        public long? MinPaperStatementStagingKey { get; set; }
        public long? MaxPaperStatementStagingKey { get; set; }
    }
}
