﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using AppSupportProcessor.DataAccess.DataAccesses.Models;
using Gd.Sql;
using Gd.Sql.Executions.Models;
using Microsoft.Extensions.Configuration;
using Gd.Aop.Common;
using Microsoft.IdentityModel.Tokens;

namespace AppSupportProcessor.DataAccess.DataAccesses
{
    public interface INecDataAccess
    {
        [LogMethodContext]
        Task<bool> IsBankHoliday(DateTime dt);
        Task<List<ConsumerInfo>> GetConsumerInfoByAccountKeys(List<AccountKeyInfo> items);
        Task<List<AccountInfo>> GetAccountInfoByAccountKeys(List<int> accountKeys);
        Task AddAcctHistory(List<AcctHistory> items);

        Task<List<ProductPaperStatementFee>> GetProductPaperStatementFee();
    }

    public class NecDataAccess : INecDataAccess
    {
        private readonly ISqlHelper _dbHelper;
        public NecDataAccess(IConfiguration config)
        {
            string connectionString = config.GetConnectionString("NECDB");
            _dbHelper = SqlHelper.GetInstance(connectionString);
        }

        public async Task<List<ConsumerInfo>> GetConsumerInfoByAccountKeys(List<AccountKeyInfo> items)
        {
            if (items.Count > 0)
            {
                DataTable dataTable = items.ToDataTable();
                var input = new GetConsumerInfoByAccountKeysInput()
                {
                    typeListOfInt = dataTable
                };

                var outputs = await _dbHelper.ExecuteReaderListAsync<ConsumerInfo>("GetConsumerInfoByAccountKeys", input);
                return outputs;
            }

            return new List<ConsumerInfo>();
        }

        public async Task<List<AccountInfo>> GetAccountInfoByAccountKeys(List<int> accountKeys)
        {
            
            if (accountKeys.Count > 0)
            {
                var input = new 
                {
                    ptypeAccountkey = accountKeys.Select(n=>new { AccountKey = n }).ToList().ToDataTable() 
                };
                var outputs = await _dbHelper.ExecuteReaderListAsync<AccountInfo>("GetAccountBalanceByAccountKeys", input);
                return outputs;
            }
            return new List<AccountInfo>();
            
            
        }

        public async Task AddAcctHistory(List<AcctHistory> items)
        {
            if (items.Count > 0)
            {
                var input = new InsPaperStatementFeeByBatchInput
                {
                    ptypePaperStatementFee = items.ToDataTable(),
                    pTransactionDescription = "Paper Statement Fee",
                    pAccountTransactionStatusKey =1,
                    pDetailAccountTransactionTypeKey = 125
                };
                 await _dbHelper.ExecuteNonQueryAsync("InsPaperStatementFeeByBatch", input);
            }
        }

        public Task<List<ProductPaperStatementFee>> GetProductPaperStatementFee()
        {
           return _dbHelper.ExecuteReaderListAsync<ProductPaperStatementFee>("GetPaperStatementFeeConfiguration");
        }

        public async Task<bool> IsBankHoliday(DateTime dt)
        {
            var result = await _dbHelper.ExecuteScalarAsync("GetHoliday", new
            {
                pHolidayDate = dt,
                pHolidayGroupKey = (byte)2
            });
            return result != null;
        }
    }
}
