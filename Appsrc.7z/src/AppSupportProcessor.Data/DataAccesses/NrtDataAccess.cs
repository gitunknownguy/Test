﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using AppSupportProcessor.DataAccess.DataAccesses.Models;
using AppSupportProcessor.Model.Consolidation;
using Gd.Sql;
using Gd.Sql.Executions.Models;
using Microsoft.Extensions.Configuration;

namespace AppSupportProcessor.DataAccess.DataAccesses
{
    public interface INrtDataAccess
    {
        Task<List<GetTransDtlCountByAccountKeyAndDateOutput>> GetTransDtlCountByAccountKeyAndDate(DateTime startDate, DateTime endDate, List<AccountKeyInfo> items); 
        Task<List<PaperTaxDocumentRequest>> GetPaperTaxDocumentRequestList(int batchSize, short statusKey, int retryCountIncrease);
        Task UpdatePaperTaxDocumentRequest(List<PaperTaxDocumentRequest> items);
    }

    public class NrtDataAccess : INrtDataAccess
    {
        private readonly ISqlHelper _dbHelper;
        public NrtDataAccess(IConfiguration config)
        {
            string connectionString = config.GetConnectionString("NRTDB");
            _dbHelper = SqlHelper.GetInstance(connectionString);
        }

        public async Task<List<GetTransDtlCountByAccountKeyAndDateOutput>> GetTransDtlCountByAccountKeyAndDate(DateTime startDate, DateTime endDate, List<AccountKeyInfo> items)
        {
            var resultInfos = new List<GetTransDtlCountByAccountKeyAndDateOutput>();
            if (items.Count > 0)
            {
                int sum = items.Count;
                int batchSize = 100;
                int batchCount = (int)Math.Ceiling((decimal)sum / batchSize);
                for (int i = 0; i < batchCount; i++)
                {
                    var infos = items.Skip(i * batchSize).Take(batchSize).ToList();

                    DataTable dataTable = infos.ToDataTable();
                    var input = new GetTransDtlCountByAccountKeyAndDateInput()
                    {
                        ptypeAccountKeys = dataTable,
                        pStartDate = startDate,
                        pEndDate = endDate
                    };

                    CommandContent commandContent = new CommandContent()
                    {
                        CommandTimeOut = 600,
                        Value = "GetTransDtlCountByAccountKeyAndDate",
                        Parameters = input
                    };

                    var outputs = await _dbHelper.ExecuteReaderListAsync<GetTransDtlCountByAccountKeyAndDateOutput>(commandContent);
                    resultInfos.AddRange(outputs);
                }
            }

            return resultInfos;
        }
        public async Task<List<PaperTaxDocumentRequest>> GetPaperTaxDocumentRequestList(int batchSize, short paperTaxDocumentRequestStatusKey, int retryCountIncrease)
        {
            return await _dbHelper.ExecuteReaderListAsync<PaperTaxDocumentRequest>("GetPaperTaxDocumentRequestByStatus",
                new { pBatchSize = batchSize, pPaperTaxDocumentRequestStatusKey = paperTaxDocumentRequestStatusKey, pRetryCountIncrease = retryCountIncrease });
        }

        public async Task UpdatePaperTaxDocumentRequest(List<PaperTaxDocumentRequest> items)
        {
            if (items.Count > 0)
            {
                DataTable dataTable = items.Select(i => new
                {
                    PaperTaxDocumentRequestKey = i.PaperTaxDocumentRequestKey,
                    PaperTaxDocumentRequestPath = i.PaperTaxDocumentRequestPath,
                    PaperTaxDocumentRequestStatusKey = i.PaperTaxDocumentRequestStatusKey,
                }).ToList().ToDataTable();

                await _dbHelper.ExecuteNonQueryAsync("UpdatePaperTaxDocumentRequest", new { @ptypePaperTaxDocumentRequest = dataTable });
            }
        }
    }
}
