﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using AppSupportProcessor.DataAccess.DataAccesses.Models;
using AppSupportProcessor.Model.Consolidation;
using Gd.Aop.Common;
using Gd.Sql;
using Gd.Sql.Executions.Models;
using Microsoft.Extensions.Configuration;

namespace AppSupportProcessor.DataAccess.DataAccesses
{
    public interface IReportDataAccess
    {
        Task TruncatePaperStatementStaging();
        Task InsertPaperStatementStaging(DateTime billCycleDate);
        [LogMethodContext]
        Task<PaperStatementStagingPkRange> GetPaperStatementStagingPkRange();
        Task<List<PaperStatementStagingInfo>> GetPaperStatementStagingByBatch(long startPk, long endPk);
        Task<List<GetPaperStatementTransactionCountOutput>> GetPaperStatementTransactionCount(List<PaperStatementInfo> items);
        Task InsertPaperStatement(List<PaperStatementInfo> items);
        Task<List<PaperStatementInfo>> GetPaperStatementByStatus(GetPaperStatementByStatusInput input);
        Task UpdatePaperStatement(List<PaperStatementInfo> items);
        [LogMethodContext]
        Task<PaperStatementPkRangeForDelete> GetPaperStatementPkRangeForDelete();
        [LogMethodContext]
        Task<int> DeletePaperStatementByBatch(long startPk, long endPk);
    }

    public class ReportDataAccess : IReportDataAccess
    {
        private readonly ISqlHelper _dbHelper;
        public ReportDataAccess(IConfiguration config)
        {
            string connectionString = config.GetConnectionString("ReportDB");
            _dbHelper = SqlHelper.GetInstance(connectionString);
        }

        public async Task TruncatePaperStatementStaging()
        {
            await _dbHelper.ExecuteNonQueryAsync("TruncatePaperStatementStaging");
        }

        public async Task InsertPaperStatementStaging(DateTime billCycleDate)
        {
            int billCycleDay = billCycleDate.Day;
            var cmdParameter = new
            {
                pBillCycleDay = (short)billCycleDay,
                pBillCycleDate = billCycleDate
            };

            var commandContent = new CommandContent()
            {
                CommandTimeOut = 3600,
                Value = "InsertPaperStatementStaging",
                Parameters = cmdParameter
            };
            await _dbHelper.ExecuteNonQueryAsync(commandContent);
        }

        public async Task<PaperStatementStagingPkRange> GetPaperStatementStagingPkRange()
        {
            return await _dbHelper.ExecuteReaderAsync<PaperStatementStagingPkRange>("GetPaperStatementStagingPKRange");
        }

        public async Task<List<PaperStatementStagingInfo>> GetPaperStatementStagingByBatch(long startPk, long endPk)
        {
            var resultInfos = await _dbHelper.ExecuteReaderListAsync<PaperStatementStagingInfo>("GetPaperStatementStagingByBatch", new
            {
                pStartPK = startPk,
                pEndPK = endPk
            });

            return resultInfos;
        }

        public async Task<List<GetPaperStatementTransactionCountOutput>> GetPaperStatementTransactionCount(List<PaperStatementInfo> items)
        {
            if (items.Count > 0)
            {
                var input = new GetPaperStatementTransactionCountInput()
                {
                    ptypePaperStatement = items.Select(MapToPaperStatementInfoNoIdentifier).ToList().ToDataTable()
                };

                var result = await _dbHelper.ExecuteReaderListAsync<GetPaperStatementTransactionCountOutput>("GetPaperStatementTransactionCount", input);

                return result;
            }

            return new List<GetPaperStatementTransactionCountOutput>();
        }

        public async Task InsertPaperStatement(List<PaperStatementInfo> items)
        {
            if (items.Count > 0)
            {
                DataTable dataTable = items.ToDataTable();
                var input = new InsertPaperStatementInput()
                {
                    ptypeInsertPaperStatement = dataTable
                };

                await _dbHelper.ExecuteNonQueryAsync("InsertPaperStatement", input);
            }
        }

        public async Task<List<PaperStatementInfo>> GetPaperStatementByStatus(GetPaperStatementByStatusInput input)
        {
            var result = await _dbHelper.ExecuteReaderListAsync<PaperStatementInfo>("GetPaperStatementByStatus", input);

            return result;
        }

        public async Task UpdatePaperStatement(List<PaperStatementInfo> items)
        {

            if (items.Count > 0)
            {
                DataTable dataTable = items.Select(MapToPaperStatementInfoNoIdentifier).ToList().ToDataTable();
                var input = new UpdatePaperStatementInput()
                {
                    ptypePaperStatement = dataTable
                };

                await _dbHelper.ExecuteNonQueryAsync("UpdatePaperStatement", input);
            }
        }

        public async Task<PaperStatementPkRangeForDelete> GetPaperStatementPkRangeForDelete()
        {
            return await _dbHelper.ExecuteReaderAsync<PaperStatementPkRangeForDelete>("GetPaperStatementPKRangeForDelete");
        }

        public async Task<int> DeletePaperStatementByBatch(long startPk,long endPk)
        {
            return await _dbHelper.ExecuteNonQueryAsync("DeletePaperStatementByBatch",
                new { pStartPK = startPk, pEndPK = endPk });
        }

        private static PaperStatementInfoNoIdentifier MapToPaperStatementInfoNoIdentifier(PaperStatementInfo item)
        {
            return new PaperStatementInfoNoIdentifier()
            {
                PaperStatementKey = item.PaperStatementKey,
                AccountKey = item.AccountKey,
                BillCycleDay = item.BillCycleDay,
                BillCycleDate = item.BillCycleDate,
                PaperStatementStatusKey = item.PaperStatementStatusKey,
                TransactionCount = item.TransactionCount,
                CreditRatingKey = item.CreditRatingKey,
                PaperStatementFilePath = item.PaperStatementFilePath,
                RetryCount = item.RetryCount,
                PortfolioKey = item.PortfolioKey
            };
        }
    }
}
