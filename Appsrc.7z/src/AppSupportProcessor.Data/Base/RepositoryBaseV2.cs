﻿using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using System.Diagnostics.CodeAnalysis;
using static Dapper.SqlMapper;

namespace AppSupportProcessor.DataAccess.Base
{
    /// <summary>
    /// V2Repository do make Transactions made in async
    /// </summary>
    [ExcludeFromCodeCoverage]
    public abstract class RepositoryBaseV2
    {
        private readonly string _connectionString;
        private readonly int TimeoutSeconds;
        public RepositoryBaseV2(string dbName, IConfiguration _config)
        {
            TimeoutSeconds = int.Parse(_config?.GetSection("DBVariables")?["TimeoutSeconds"] ?? "300");
            _connectionString = _config.GetConnectionString(dbName);
        }
        protected virtual async Task<IEnumerable<T>> QueryAsync<T>(string spName, Object @params)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var result = await connection.QueryAsync<T>(spName, @params, null, TimeoutSeconds, CommandType.StoredProcedure);
                return result;
            }
        }

        protected virtual async Task<IEnumerable<T>> QueryAsync<T>(string spName, Object @params,
            int timeoutSeconds)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var result = await connection.QueryAsync<T>(spName, @params, null, timeoutSeconds,
                    CommandType.StoredProcedure);
                return result;
            }
        }

        protected virtual async Task<Tuple<IEnumerable<T1>, IEnumerable<T2>>> QueryMultipleAsync<T1, T2>(string spName, Object @params)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var result = await connection.QueryMultipleAsync(spName, @params, null, TimeoutSeconds, CommandType.StoredProcedure);
                var result1 = result.Read<T1>();
                var result2 = result.Read<T2>();
                return new Tuple<IEnumerable<T1>, IEnumerable<T2>>(result1, result2);
            }
        }
        protected virtual async Task<Tuple<IEnumerable<T1>, IEnumerable<T2>, IEnumerable<T3>, IEnumerable<T4>>> QueryMultipleAsync<T1,T2,T3,T4>(string spName, Object @params)
        {
            using (var connection = new SqlConnection(_connectionString))
            { 
                connection.Open();
                var result = await connection.QueryMultipleAsync(spName, @params, null, TimeoutSeconds, CommandType.StoredProcedure);
                var result1 = result.Read<T1>();
                var result2 = result.Read<T2>();
                var result3 = result.Read<T3>();
                var result4 = result.Read<T4>();
                return new Tuple<IEnumerable<T1>, IEnumerable<T2>, IEnumerable<T3>, IEnumerable<T4>>(result1,result2,result3,result4);
            }
        }

        protected virtual async Task<IEnumerable<T>> QueryAsync<T>(SqlConnection connection, string spName, SqlTransaction sqlTransaction, Object @params)
        {
            
            var result = await connection.QueryAsync<T>(spName, @params, sqlTransaction, TimeoutSeconds, CommandType.StoredProcedure);
            return result;
        }

        protected virtual async Task<DynamicParameters> QueryReturnOutputAsync<T>(string spName, DynamicParameters @params)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var result = await connection.QueryAsync<T>(spName, @params, null, TimeoutSeconds, CommandType.StoredProcedure);
                return @params;
            }
        }

        protected virtual async Task<DynamicParameters> QueryReturnOutputAsync<T>(SqlConnection connection, string spName, SqlTransaction sqlTransaction, DynamicParameters @params)
        {
            var result = await connection.QueryAsync<T>(spName, @params, sqlTransaction, TimeoutSeconds, CommandType.StoredProcedure);
            return @params;
        }

        protected virtual async Task BulkCopyAsync(DataTable table, SqlBulkCopyOptions _option, List<SqlBulkCopyColumnMapping> _mappings)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var transaction = connection.BeginTransaction(IsolationLevel.ReadUncommitted))
                using (var bulkCopy = new SqlBulkCopy(connection, _option, transaction))
                {
                    bulkCopy.DestinationTableName = table.TableName;
                    bulkCopy.BulkCopyTimeout = TimeoutSeconds;
                    foreach (var mapping in _mappings)
                    {
                        bulkCopy.ColumnMappings.Add(mapping);
                    }
                    await bulkCopy.WriteToServerAsync(table);
                    transaction.Commit();
                }
            }

        }
        protected virtual async Task<int> ExcuteAsync(string spName, Object @params)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var result = await connection.ExecuteAsync(spName, @params, null, TimeoutSeconds, CommandType.StoredProcedure);
                return result;
            }
        }

        protected virtual SqlConnection GetSqlConnection()
        {
            var conn = new SqlConnection(_connectionString);
            return conn;
        }

        protected virtual async Task<T> ExecuteScalar<T>(string spName, Object @params)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                T result = await connection.ExecuteScalarAsync<T>(spName, @params, null, TimeoutSeconds, CommandType.StoredProcedure);
                return result;
            }
        }
    }
}
