﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Dapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Polly;
using AppSupportProcessor.Common.Locking;

namespace AppSupportProcessor.DataAccess.Base
{
    [ExcludeFromCodeCoverage]
    public abstract class RepositoryBase
    {
        private readonly string _connectionString;
        internal readonly int TimeoutRetryMilliseconds;
        internal readonly int TimeoutSeconds;
        protected SqlDistributedLockFactory DistributedLockFactory { get; }
        protected ILogger Logger { get; }

        protected RepositoryBase(string dbName, IConfiguration configuration, ILogger logger, SqlDistributedLockFactory appLockFactory)
        {
            _connectionString = configuration.GetConnectionString(dbName);
            TimeoutRetryMilliseconds = int.Parse(configuration?.GetSection("DBVariables")?["TimeoutRetryMilliseconds"] ?? "1000");
            TimeoutSeconds = int.Parse(configuration?.GetSection("DBVariables")?["TimeoutSeconds"] ?? "300");
            DistributedLockFactory = appLockFactory;
            Connection = new SqlConnection(_connectionString);
            Logger = logger;
        }

        protected RepositoryBase(IDbConnection connection, ILogger logger, SqlDistributedLockFactory appLockFactory)
        {
            _connectionString = connection.ConnectionString;
            DistributedLockFactory = appLockFactory;
            Connection = connection;
            Logger = logger;
        }

        protected IDbConnection Connection { get; }

        #region SP Query (Sync)

        protected IEnumerable<T> ExecuteStoredProcedure<T>(string spName, object @params = null, string applyLockName = null)
        {
            if (string.IsNullOrEmpty(applyLockName))
            {
                return InternalExecuteStoredProcedure<T>(spName, @params);
            }
            else
            {
                var distributedLock = DistributedLockFactory(_connectionString, applyLockName);
                using (AcquireLock(distributedLock))
                {
                    return InternalExecuteStoredProcedure<T>(spName, @params);
                }
            }
        }

        private IEnumerable<T> InternalExecuteStoredProcedure<T>(string spName, object @params = null)
        {
            try
            {
                Connection.Open();
                var result = Connection.Query<T>(spName, param: @params, commandType: CommandType.StoredProcedure);

                return result;
            }
            catch (Exception ex)
            {
                // Handle with exception
                Logger.LogError($"Exception occured when executing SP:{spName}. {ex}");
                throw;
            }
            finally
            {
                Connection.Close();
            }
        }

        #endregion

        #region SP Query (Async)

        protected async Task<IEnumerable<T>> ExecuteStoredProcedureAsync<T>(string spName, object @params = null, string applyLockName = null)
        {
            if (string.IsNullOrEmpty(applyLockName))
            {
                return await InternalExecuteStoredProcedureAsync<T>(spName, @params);
            }
            else
            {
                var distributedLock = DistributedLockFactory(_connectionString, applyLockName);
                using (await AcquireLockAsync(distributedLock))
                {
                    return await InternalExecuteStoredProcedureAsync<T>(spName, @params);
                }
            }
        }

        private async Task<IEnumerable<T>> InternalExecuteStoredProcedureAsync<T>(string spName, object @params = null)
        {
            try
            {
                Connection.Open();
                //timeout
                var result = await Policy.Handle<SqlException>(ex => ex.Number == -2)
                    .WaitAndRetry(3, (retryCount) => TimeSpan.FromMilliseconds(TimeoutRetryMilliseconds))
                    .Execute(() =>
                        Connection.QueryAsync<T>(spName, param: @params, commandTimeout: TimeoutSeconds, commandType: CommandType.StoredProcedure));

                return result;
            }
            catch (Exception ex)
            {
                // Handle with exception
                Logger.LogError($"Exception occured when executing SP:{spName}. {ex}");
                throw;
            }
            finally
            {
                Connection.Close();
            }
        }

        #endregion

        #region SP Non Query (Async)

        protected async Task<int> ExecuteStoredProcedureAsync(string spName, object @params = null,
            string applyLockName = null)
        {
            if (string.IsNullOrEmpty(applyLockName))
            {
                return await InternalExecuteStoredProcedureAsync(spName, @params);
            }
            else
            {
                var distributedLock = DistributedLockFactory(_connectionString, applyLockName);
                using (await AcquireLockAsync(distributedLock))
                {
                    return await InternalExecuteStoredProcedureAsync(spName, @params);
                }
            }
        }

        private async Task<int> InternalExecuteStoredProcedureAsync(string spName, object @params = null)
        {
            try
            {
                Connection.Open();
                //timeout
                var result = await Policy.Handle<SqlException>(ex => ex.Number == -2)
                    .WaitAndRetry(3, (retryCount) => TimeSpan.FromMilliseconds(TimeoutRetryMilliseconds))
                    .Execute(() =>
                        Connection.ExecuteAsync(spName, param: @params, commandTimeout: TimeoutSeconds, commandType: CommandType.StoredProcedure));

                return result;
            }
            catch (Exception ex)
            {
                // Handle with exception
                Logger.LogError($"Exception occured when executing SP:{spName}. {ex}");
                throw;
            }
            finally
            {
                Connection.Close();
            }
        }

        #endregion

        #region Bulk Copy (Async)

        public async Task BulkCopyAsync<T>(IEnumerable<T> copyDataList,
                        string targetTable, string applyLockName = null,
                        params (string SourceColumn, string DestinationColumn)[] columnMappingParams)
        {
            if (!(Connection is SqlConnection))
                throw new NotSupportedException($"Unsupported operation for your database. Operation: BulkCopy, Connection Type: {Connection.GetType()}");

            if (columnMappingParams == null || columnMappingParams.Length == 0)
                throw new NoNullAllowedException("columnMappingParams is null or empty");

            if (string.IsNullOrWhiteSpace(targetTable))
                throw new NoNullAllowedException("dbTableName is null or empty");

            if (string.IsNullOrEmpty(applyLockName))
            {
                await InternalBulkCopyAsync(copyDataList, targetTable, columnMappingParams);
            }
            else
            {
                var distributedLock = DistributedLockFactory(_connectionString, applyLockName);
                using (await AcquireLockAsync(distributedLock))
                {
                    await InternalBulkCopyAsync(copyDataList, targetTable, columnMappingParams);
                }
            }
        }

        private async Task InternalBulkCopyAsync<T>(IEnumerable<T> copyDataList,
                               string targetTable,
                               params (string SourceColumn, string DestinationColumn)[] columnMappingParams)
        {
            try
            {
                Connection.Open();

                var sqlBulkCopy = new SqlBulkCopy((SqlConnection)Connection)
                {
                    DestinationTableName = targetTable
                };

                foreach (var columnMappingParam in columnMappingParams)
                {
                    sqlBulkCopy.ColumnMappings.Add(CreateBulkCopyParameter(columnMappingParam.SourceColumn, columnMappingParam.DestinationColumn));
                }

                using (var dataReader = new ObjectDataReader<T>(copyDataList))
                {
                    await sqlBulkCopy.WriteToServerAsync(dataReader);
                }
            }
            catch (Exception ex)
            {
                Logger.LogError($"Exception occured when executing Bulk Copy. {ex}");
                throw;
            }
            finally
            {
                Connection.Close();
            }
        }

        private SqlBulkCopyColumnMapping CreateBulkCopyParameter(string sourceDataPropertyName, string destinationTableColumnName)
            => new SqlBulkCopyColumnMapping(sourceDataPropertyName, destinationTableColumnName);

        #endregion

        private async Task<IDisposable> AcquireLockAsync(IDistributedLock appLock)
        {
            var resultLock = await Policy.Handle<ArgumentException>()
                  .WaitAndRetryAsync(3, (order) => TimeSpan.FromMilliseconds(1000))
                  .ExecuteAsync(async () =>
                  {
                      IDisposable theLock = await appLock.TryAcquireAsync(TimeSpan.FromSeconds(60));
                      if (theLock == null)
                      {
                          throw new ArgumentException("The SP or bulkcopy is locked by other jobs/machine.");
                      }

                      return theLock;
                  });

            return resultLock;
        }

        private IDisposable AcquireLock(IDistributedLock appLock)
        {
            var resultLock = Policy.Handle<ArgumentException>()
                .WaitAndRetry(3, (order) => TimeSpan.FromMilliseconds(1000))
                .Execute(() =>
                {
                    IDisposable theLock = appLock.TryAcquire(TimeSpan.FromSeconds(60));
                    if (theLock == null)
                    {
                        throw new ArgumentException("The SP or bulkcopy is locked by other jobs/machine.");
                    }

                    return theLock;
                });

            return resultLock;
        }
    }
}
