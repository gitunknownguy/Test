﻿using AccountManagement;
using AppSupportProcessor.Business.LegacyApi;
using AppSupportProcessor.Model.Consolidation;
using AppSupportProcessor.Model.Enum;
using System;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.Activity
{
    public class RemoveVIPSubscription : IActivity
    {
        private readonly IAccountManagementReposity _accountManagementReposity;        
        public int Priority { get; } = 10;
        public ConsolidationAccount Account { get; set; }
        public ConsolidationAccountActivity AccountActivity { get; set; }

        public RemoveVIPSubscription(IAccountManagementReposity accountManagementReposity)
        {
            _accountManagementReposity = accountManagementReposity;
        }
        public async Task ExecuteAsync()
        {
            var result = await _accountManagementReposity.RemoveSubscriptionAsync(new RemoveSubscriptionRequest()
            {
                CustomerKey = (int)Account.CustomerKey,
                SubscriptionTypeKey = Constants.VIPSubscriptionTypeKey,                
                UserToken = "10"
            });

            if(result?.ResponseCode == ServiceFaultCode.AmSuccess || result?.ResponseCode == ServiceFaultCode.AmSubscriptionAlreadyExists)
            {
                AccountActivity.ConsolidationActivityStatusKey = (short)ActivityStatus.Success;
                AccountActivity.ActivityDetail = $"VIP subscription removed for account key {Account?.AccountKey}";
            }
            else
            {
                AccountActivity.ConsolidationActivityStatusKey = (short)ActivityStatus.Failed;
                throw new Exception($"Failed to remove VIP subscription for account key {Account?.AccountKey}, reason: {result.ResponseText}");
            }
        }
    }
}
