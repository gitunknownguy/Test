﻿using AppSupportProcessor.DataAccess.Repositories;
using AppSupportProcessor.Model.Consolidation;
using AppSupportProcessor.Model.DO;
using AppSupportProcessor.Model.Enum;
using Microsoft.VisualBasic;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.Activity
{
    public class UpdateProductAndMembershipinDB : IActivity
    {
        private readonly INECNRTRepository _nECNRTRepository;
        private readonly INECRepository _nECRepository;
        private readonly ICache _cache;
        public int Priority { get; } = 2;
        public ConsolidationAccount Account { get; set; }
        public ConsolidationAccountActivity AccountActivity { get; set; }

        public UpdateProductAndMembershipinDB(INECNRTRepository nECNRTRepository, INECRepository nECRepository, ICache cache)
        {
            _nECNRTRepository = nECNRTRepository;
            _nECRepository = nECRepository;
            _cache = cache;
        }

        public async Task ExecuteAsync()
        {
            Console.WriteLine("UpdateProductAndMembershipinDB.ExecuteAsync");

            var activity = await _nECNRTRepository.GetConsolidationAccountActivityByKeyAsync(AccountActivity.ConsolidationAccountActivityKey);
            if (activity.ConsolidationActivityStatusKey == (short)ActivityStatus.Success)
                return;

            //Get plastic list by card reference, return plastic isPersonalized, isActive, IsEMV..
            var plasticList = await _nECRepository.GetGetPlasticInfoByCardreference(Account.CardReference);
            var activePlastic = plasticList?.MaxBy(it=>it.CardKey);

            if (activePlastic == null)
                throw new Exception("No active plastic found");

            await BackfillCustomerCardReference(activePlastic, Account.CustomerKey, Account.CardReference, AccountActivity);

            var productMappingList = _cache.GetData<List<ConsolidationProductMapping>>("AppSupport_ConsolidationProductMapping");
            if (productMappingList == null || productMappingList.Count == 0)
            {
                productMappingList = await _nECNRTRepository.GetAllConsolidationProductMappingAsync();
                _cache.InsertData("AppSupport_ConsolidationProductMapping", productMappingList, TimeSpan.FromDays(1));
            }

            var productMembershipMappingList = _cache.GetData<List<ConsolidationProductMapping>>("AppSupport_ConsolidationTargetProductMembership");
            if (productMembershipMappingList == null || productMembershipMappingList.Count == 0)
            {
                productMembershipMappingList = await _nECNRTRepository.GetAllTargetConsolidationProductMappingAsync();
                _cache.InsertData("AppSupport_ConsolidationTargetProductMembership", productMembershipMappingList, TimeSpan.FromDays(1));
            }
            // Get current membershipgroup by account key
            var customerMembershipAndFeeGroup = await _nECRepository.GetConsolidationSourceDetailsByCutomerkeyAndAccountkey(Account.CustomerKey, Account.AccountKey);//(3697054, 2121654);

            //Get target membershipgroupkey by current membershipgroupkey and productkey
            var targetProductMapping = productMappingList.Where(p => p.SourceProductKey == Account.ProductKey && p.SourceMembershipGroupKey == customerMembershipAndFeeGroup.MembershipGroupKey).FirstOrDefault();
            //COFO-107611: Some account did not have membership
            if (customerMembershipAndFeeGroup.MembershipGroupKey == 0)
            {
                targetProductMapping = productMappingList.Where(p => p.SourceProductKey == Account.ProductKey).FirstOrDefault();
            }
            

            //special case for product 7009, If primary account productkey = 7727 or 7719
            //Then consolidate this account product to 7720
            if (Account.ProductKey == 7009)
            {
                if (Account.LinkedProductKey == 0)
                {
                    var primaryAccountProductKey = await GetFamilyAccountProductKey(Account.AccountKey);
                    if (primaryAccountProductKey == 7727 || primaryAccountProductKey == 7719)
                    {
                        targetProductMapping = productMappingList.Where(p => p.TargetProductKey == 7720).ToList().FirstOrDefault();
                        Account.LinkedProductKey = primaryAccountProductKey;
                    }
                }
                else if (Account.LinkedProductKey == 7727 || Account.LinkedProductKey == 7719)
                {
                    targetProductMapping = productMappingList.Where(p => p.TargetProductKey == 7720).ToList().FirstOrDefault();
                }
            }

            if (targetProductMapping == null)
                throw new Exception("No target product mapping found");

            //Get target membershipkey by target membershipgroupkey and current membershipTypekey
            var targetMembership = productMembershipMappingList.Where(p => p.TargetMembershipGroupKey == targetProductMapping.TargetMembershipGroupKey && p.MembershipTypeKey == customerMembershipAndFeeGroup.MembershipTypeKey).FirstOrDefault();
            //COFO-107611: Some account did not have membership
            if(customerMembershipAndFeeGroup.MembershipTypeKey == 0)
            {
                targetMembership = productMembershipMappingList.Where(p => p.TargetMembershipGroupKey == targetProductMapping.TargetMembershipGroupKey && p.MembershipTypeKey == 1).FirstOrDefault();
            }
            if (targetMembership == null)
                throw new Exception("No target membership found");

            //Get target product bankcode and asscokey by target productkey
            var targetProductDetail = await _nECRepository.GetAssociationByProductKey(targetProductMapping.TargetProductKey);
            if (targetProductDetail == null)
                throw new Exception("No target product detail found");

            // Update productkey, membershipkey and Feegroupkey by accountkey
            if(targetProductMapping.TargetProductKey != targetProductMapping.SourceProductKey)
                await _nECRepository.UpdateConsolidationAccountDetailAsync(activePlastic.CardKey, Account.AccountKey, Account.CustomerKey, targetProductMapping.TargetProductKey, targetProductDetail.BankCode, targetProductDetail.AssocKey);

            //if current membership is same as target membership, do not update membership
            if(customerMembershipAndFeeGroup.MembershipGroupKey != targetMembership.TargetMembershipGroupKey)
                await _nECRepository.AddCustomerMembershipAsync(Account.CustomerKey, targetMembership.MembershipTypeKey, targetMembership.MembershipKey);
            
            await _nECRepository.AddCustomerFeeGroupAndMenbershipByAccountKeyAsync(Account.AccountKey, Account.CustomerKey, targetMembership.MembershipTypeKey, targetMembership.MembershipKey);

           
            AccountActivity.ActivityDetail = JsonConvert.SerializeObject(new object[] { 
                new 
                {
                    CustomerMembershipKey = customerMembershipAndFeeGroup.CustomerMembershipKey,
                    MembershipKey = customerMembershipAndFeeGroup.MembershipKey,
                    MembershipGroupKey = customerMembershipAndFeeGroup.MembershipGroupKey,
                    MembershipTypeKey = customerMembershipAndFeeGroup.MembershipTypeKey,
                    FeeGroupKey = customerMembershipAndFeeGroup.FeeGroupKey,
                    CustomerFeeGroupKey = customerMembershipAndFeeGroup.CustomerFeeGroupKey,
                    Account_FeeGroupKey = customerMembershipAndFeeGroup.Account_FeeGroupKey,
                    FeeWaiverGroupKey = customerMembershipAndFeeGroup.FeeWaiverGroupKey,
                    Customer_FeeWaiverGroupKey = customerMembershipAndFeeGroup.Customer_FeeWaiverGroupKey,
                    CardKey = activePlastic.CardKey,
                    BankCode = activePlastic.BankCode,
                    AssocKey = activePlastic.AssocKey,
                } 
            });
            activity.ConsolidationActivityStatusKey = (short)ActivityStatus.Success;
        }


        private async Task BackfillCustomerCardReference(PlasticInfo plastic, int customerKey, string cardReference, ConsolidationAccountActivity activity)
        {
            if (string.IsNullOrEmpty(plastic.CardReference))
            {
                await _nECRepository.UpdateCustomerCardReferenceByCustomerKey(cardReference, customerKey);
                activity.ActivityDetail = $"Card reference updated for customer key {customerKey};";
            }
        }

        private async Task<short> GetFamilyAccountProductKey(int accountKey)
        {
            var linkedAccount = await _nECRepository.GetFamilyLinkedAccounts(accountKey);
            if (linkedAccount == null)
                throw new Exception("No family account found");
            var primaryAccountProduct = await _nECRepository.GetProductKeyByAccountKey(linkedAccount.PrimaryAccountKey);
            return primaryAccountProduct.ProductKey;
        }
    }
}
