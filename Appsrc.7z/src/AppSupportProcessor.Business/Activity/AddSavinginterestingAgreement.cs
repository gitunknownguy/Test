﻿using AppSupportProcessor.Business.LegacyApi;
using AppSupportProcessor.DataAccess.Repositories;
using AppSupportProcessor.Model.Consolidation;
using AppSupportProcessor.Model.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.Activity
{
    public class AddSavinginterestingAgreement : IActivity
    {
        public readonly IAgreementRepository _agreementRepository;
        private readonly INECRepository _necRepository;
        public int Priority { get; } = 6;
        public ConsolidationAccount Account { get; set; }
        public ConsolidationAccountActivity AccountActivity { get; set; }

        public AddSavinginterestingAgreement(IAgreementRepository agreementRepository, INECRepository necRepository)
        {
            _agreementRepository = agreementRepository;
            _necRepository = necRepository;
        }

        public async Task ExecuteAsync()
        {
            var acceptedAgreements = await _necRepository.GetAcceptedAgreementsByAccountKey(Account.AccountKey);
            if (!acceptedAgreements.Any(a => a.AgreementKey == Constants.SavingsAccountInterestAgreementKey && (a.AgreementExpirationDate > DateTime.Now || a.AgreementExpirationDate == DateTime.MinValue)))
            {
                var result = await _agreementRepository.SetAccountAgreementAsync(new AgreementService.SetAccountAgreementRequest()
                {
                    AccountToken = Account.AccountKey.ToString(),
                    AgreementToken = Constants.SavingsAccountInterestAgreementKey.ToString(),
                    ApplicationToken = "8017",
                    EnumApplicationTypeKey = 7,
                    EnumAgreementChannelKey = 1,
                    UserToken = "",
                    EnumAgreementStatusKey = 1,
                    SystemComponentToken = "25",
                    TransactionDate = DateTime.UtcNow
                });

                if (result.EnumResponseCodeKey == 0)
                {
                    AccountActivity.ConsolidationActivityStatusKey = (short)ActivityStatus.Success;
                    AccountActivity.ActivityDetail = $"Saving interesting agreement added for account key {Account?.AccountKey}";
                }
                else
                {   
                    AccountActivity.ConsolidationActivityStatusKey = (short)ActivityStatus.Failed;
                    throw new Exception($"Failed to add saving interesting agreement for account key {Account?.AccountKey}, reason: {result.ResponseText}");
                }
            }
            else
            {
                AccountActivity.ConsolidationActivityStatusKey = (short)ActivityStatus.Skipped;
            }

        }
    }
}
