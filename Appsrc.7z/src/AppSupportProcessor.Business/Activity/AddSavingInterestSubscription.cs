﻿using AccountManagement;
using AppSupportProcessor.Business.LegacyApi;
using AppSupportProcessor.Model.Consolidation;
using AppSupportProcessor.Model.Enum;
using System;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.Activity
{
    public class AddSavingInterestSubscription : IActivity
    {
        private readonly IAccountManagementReposity _accountManagementReposity;        
        public int Priority { get; } = 7;
        public ConsolidationAccount Account { get; set; }
        public ConsolidationAccountActivity AccountActivity { get; set; }

        public AddSavingInterestSubscription(IAccountManagementReposity accountManagementReposity)
        {
            _accountManagementReposity = accountManagementReposity;
        }
        public async Task ExecuteAsync()
        {
            var result = await _accountManagementReposity.AddSubscriptionAsync(new AddSubscriptionRequest()
            {
                CustomerKey = (int)Account.CustomerKey,
                SubscriptionShortName = "SAVINT",
                SubscriptionTypeKey = Constants.SavingsInterestSubscriptionTypeKey,
                IsConsolidationRequest = true,
                UserToken = "10"
            });

            if(result?.ResponseCode == ServiceFaultCode.AmSuccess || result?.ResponseCode == ServiceFaultCode.AmSubscriptionAlreadyExists)
            {
                AccountActivity.ConsolidationActivityStatusKey = (short)ActivityStatus.Success;
                AccountActivity.ActivityDetail = $"Saving interest subscription added for account key {Account?.AccountKey}";
            }
            else
            {
                AccountActivity.ConsolidationActivityStatusKey = (short)ActivityStatus.Failed;
                throw new Exception($"Failed to add saving interest subscription for account key {Account?.AccountKey}, reason: {result.ResponseText}");
            }
        }
    }
}
