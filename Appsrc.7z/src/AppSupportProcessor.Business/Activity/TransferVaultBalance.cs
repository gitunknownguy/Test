﻿using AgreementService;
using AppSupportProcessor.Business.LegacyApi;
using AppSupportProcessor.DataAccess.Repositories;
using AppSupportProcessor.Model.Consolidation;
using AppSupportProcessor.Model.Enum;
using AppSupportProcessor.Model.LegacyApi;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.Activity
{
    public class TransferVaultBalance : IActivity
    {
        private readonly IFundTransferRepository _fundTransferRepository;
        private readonly INECRepository _necRepository;
        private readonly INECNRTRepository _nECNRTRepository;

        public int Priority { get; } = 8;
        public ConsolidationAccount Account { get; set; }
        public ConsolidationAccountActivity AccountActivity { get; set; }

        public TransferVaultBalance(IFundTransferRepository fundTransferRepository, INECRepository necRepository, INECNRTRepository nECNRTRepository)
        {
            _fundTransferRepository = fundTransferRepository;
            _necRepository = necRepository;
            _nECNRTRepository = nECNRTRepository;
        }

        public async Task ExecuteAsync()
        {
            var activity = await _nECNRTRepository.GetConsolidationAccountActivityByKeyAsync(AccountActivity.ConsolidationAccountActivityKey);

            if (activity.ConsolidationActivityStatusKey == (short)ActivityStatus.Success)
                return;

            var acceptedAgreements = await _necRepository.GetAcceptedAgreementsByAccountKey(Account.AccountKey);
            if (acceptedAgreements.Any(a => a.AgreementKey == Constants.W9CertificationAgreementKey && (a.AgreementExpirationDate > DateTime.Now || a.AgreementExpirationDate == DateTime.MinValue)))
            {
                AccountActivity.ConsolidationActivityStatusKey = (short)ActivityStatus.Skipped;
                AccountActivity.ActivityDetail = $"W9 Certification agreement is accepted for account key {Account?.AccountKey}";
                return;
            }

            var linkedAccount = await _necRepository.GetLinkedAccountByPrimaryAccountKey(Account.AccountKey);
            if (linkedAccount == null) throw new System.Exception("No linked account found");
            var accountBalances = await _necRepository.GetAvailableBalanceByAccountkey(linkedAccount.LinkedAccountKey);
            decimal vaultBalance = accountBalances?.FirstOrDefault()?.AvailableBalance ?? 0;

            // If the vault balance is zero or negative before consolidation, set the status to success
            if (activity.ConsolidationActivityStatusKey == (short)ActivityStatus.Pending && vaultBalance <= 0)
            {
                AccountActivity.ConsolidationActivityStatusKey = (short)ActivityStatus.Success;
                AccountActivity.ActivityDetail = "Vault balance is zero or negative before consolidation";
                return;
            }

            // If the vault balance is zero or negative after last failed execution, need to wait for 48 hours
            if (activity.ConsolidationActivityStatusKey == (short)ActivityStatus.Failed && activity.RetryCount > 1 && vaultBalance <= 0 && activity?.ChangeDate > DateTime.Now.AddHours(-48))
            {
                throw new TimeNotReachedException("TransferVault activity failed in last execution, need to check balance after 48 hours.");
            }
            // If the vault balance is zero or negative after 48 hours of last failed execution, set the status to success
            else if (activity.ConsolidationActivityStatusKey == (short)ActivityStatus.Failed && activity.RetryCount > 1 && vaultBalance <= 0 && activity?.ChangeDate <= DateTime.Now.AddHours(-48))
            {
                AccountActivity.ConsolidationActivityStatusKey = (short)ActivityStatus.Success;
                AccountActivity.ActivityDetail = "Vault balance is zero or negative after 48 hours of last failed execution";
                return;
            }

            if (activity.ConsolidationActivityStatusKey == (short)ActivityStatus.Pending)
                throw new System.Exception($"Transfer Vault Transfer activity to retry job");

            var request = new TransferRequest()
            {
                ApplicationTypeKey = 7,
                SystemComponentKey = 25,
                SysUserKey = 10,
                TransferInfo = new TransferInfo()
                {
                    Amount = System.Math.Round(vaultBalance, 2),
                    Description = "Transfer Vault Balance",
                    SourceAccountKey = linkedAccount.LinkedAccountKey,
                    TargetAccountKey = (int)Account.AccountKey,
                    TransferType = TransferType.SavingsToCard
                }
            };
            var result = await _fundTransferRepository.VaultTransfer(request);

            if (result?.ResponseCode == TransferResponseCode.Success && result?.TransferStatus == TransferStatus.Posted)
            {
                AccountActivity.ConsolidationActivityStatusKey = (short)ActivityStatus.Success;
                AccountActivity.ActivityDetail = $"Vault balance transferred successfully from account key {linkedAccount.LinkedAccountKey} to account key {Account?.AccountKey}";
            }
            else
            {
                AccountActivity.ConsolidationActivityStatusKey = (short)ActivityStatus.Failed;
                throw new System.Exception($"Vault Transfer failed, reason: {result.ResponseText}");
            }
        }
    }
}
