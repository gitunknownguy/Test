﻿using AppSupportProcessor.Business.LegacyApi;
using AppSupportProcessor.DataAccess.Repositories;
using AppSupportProcessor.Model.Consolidation;
using AppSupportProcessor.Model.Enum;
using System;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.Activity
{
    public class CreateSavingAccount : IActivity
    {
        public readonly ISavingsAccountServiceReposity _savingsAccountServiceReposity;
        private readonly INECRepository _necRepository;        
        public int Priority { get; } = 4;
        public ConsolidationAccount Account { get; set; }
        public ConsolidationAccountActivity AccountActivity { get; set; }

        public CreateSavingAccount(ISavingsAccountServiceReposity savingsAccountServiceReposity, INECRepository necRepository)
        {
            _savingsAccountServiceReposity = savingsAccountServiceReposity;
            _necRepository = necRepository;
        }

        public async Task ExecuteAsync()
        {
            var linkedAccount = await _necRepository.GetLinkedAccountByPrimaryAccountKey(Account.AccountKey);
            if (linkedAccount == null || linkedAccount.LinkedAccountKey == 0)
            {
                var result = await _savingsAccountServiceReposity.CreateAccountAsync((int)Account.AccountKey);
                if (result.ResponseCode == SavingsAccountService.SavingsAccountResponseCode.Success)
                {
                    AccountActivity.ConsolidationActivityStatusKey = (short)ActivityStatus.Success;
                    AccountActivity.ActivityDetail = $"Saving account created for account key {Account?.AccountKey}";
                }
                else
                {
                    AccountActivity.ConsolidationActivityStatusKey = (short)ActivityStatus.Failed;
                    throw new Exception($"Failed to create saving account for account key {Account?.AccountKey}, reason: {result.ResponseText}");
                }
            }
            else
            {
                AccountActivity.ConsolidationActivityStatusKey = (short)ActivityStatus.Skipped;
            }
               
        }
    }
}
