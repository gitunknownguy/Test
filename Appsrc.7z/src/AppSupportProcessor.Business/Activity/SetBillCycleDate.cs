﻿using AppSupportProcessor.DataAccess.Repositories;
using AppSupportProcessor.Model.Consolidation;
using AppSupportProcessor.Model.DO;
using AppSupportProcessor.Model.Enum;
using Microsoft.VisualBasic;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.Activity
{
    public class SetBillCycleDate : IActivity
    {
        private readonly INECRepository _nECRepository;
        public int Priority { get; } = 9;
        public ConsolidationAccount Account { get; set; }
        public ConsolidationAccountActivity AccountActivity { get; set; }

        public SetBillCycleDate(INECRepository nECRepository)
        {
            _nECRepository = nECRepository;
        }

        public async Task ExecuteAsync()
        {
            //Get bill cycle date from BillCycle_Customer and account_billcycle
            var bcd = await _nECRepository.GetBillCycleInfoByAccountKey(Account.CustomerKey, Account.AccountKey);


            //If both are null, get the first card's activation date from customer table
            if (bcd == null || (bcd.CustomerBillCycleDay == null && bcd.AccountBillCycleDay == null))
            {
                var plasticList = await _nECRepository.GetGetPlasticInfoByCardreference(Account.CardReference);
                var firstPlastic = plasticList.FirstOrDefault();
                //set the bill cycle date to the first card's activation date
                if (firstPlastic != null)
                {
                    var activationDate = firstPlastic.CardActivationDate;
                    //Update account_billcycle with the activation date
                    await _nECRepository.SetAccountCustomerBillCycle(Account.CustomerKey, activationDate);

                    AccountActivity.ActivityDetail = $"Bill cycle date set to the first card's activation date";
                }
            }
            else
            {
                //If account_billcycle is null, get the bill cycle date from BillCycle_Customer
                if(bcd.AccountBillCycleDay == null && bcd.CustomerBillCycleDay != null)
                {
                    //Update account_billcycle with the bill cycle date from BillCycle_Customer
                    await _nECRepository.SetAccountBillCycle(Account.AccountKey, bcd.CustomerBillCycleDay.Value, bcd.CustomerFirstBillCycleDate);

                    AccountActivity.ActivityDetail = $"Bill cycle date set to the bill cycle date from BillCycle_Customer";
                }
            }

            AccountActivity.ConsolidationActivityStatusKey = (short)ActivityStatus.Success;
        }

    }
}
