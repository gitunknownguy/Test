﻿using AppSupportProcessor.Business.LegacyApi;
using AppSupportProcessor.DataAccess.Repositories;
using AppSupportProcessor.Model.Consolidation;
using AppSupportProcessor.Model.DO;
using AppSupportProcessor.Model.Enum;
using Newtonsoft.Json;
using System;
using System.Linq;
using System.Threading.Tasks;
using Constants = AppSupportProcessor.Model.Consolidation.Constants;

namespace AppSupportProcessor.Business.Activity
{
    public class AddSAAAgreement : IActivity
    {
        private readonly IAgreementRepository _agreementRepository;
        private readonly INECRepository _necRepository;
        public int Priority { get; } = 5;
        public ConsolidationAccount Account { get; set; }
        public ConsolidationAccountActivity AccountActivity { get; set; }

        public AddSAAAgreement(IAgreementRepository agreementRepository, INECRepository necRepository)
        {
            _agreementRepository = agreementRepository;
            _necRepository = necRepository;
        }
        public async Task ExecuteAsync()
        {
            var acceptedAgreements = await _necRepository.GetAcceptedAgreementsByAccountKey(Account.AccountKey);
            if (!acceptedAgreements.Any(a => a.AgreementKey == Constants.SavingsAccountAgreementKey && (a.AgreementExpirationDate > DateTime.Now || a.AgreementExpirationDate == DateTime.MinValue)))
            {
                var request = new AgreementService.SetAccountAgreementRequest()
                {
                    AccountToken = Account.AccountKey.ToString(),
                    AgreementToken = Constants.SavingsAccountAgreementKey.ToString(),
                    ApplicationToken = "8017",
                    EnumAgreementChannelKey = 1,
                    EnumAgreementStatusKey = 1,
                    EnumApplicationTypeKey = 7,
                    SystemComponentToken = "25",
                    UserToken = "",
                    TransactionDate = DateTime.UtcNow
                };
                var result = await _agreementRepository.SetAccountAgreementAsync(request);
                if (result.EnumResponseCodeKey == 0)
                {
                    AccountActivity.ConsolidationActivityStatusKey = (short)ActivityStatus.Success;
                    AccountActivity.ActivityDetail = $"Savings account agreement added for account key {Account?.AccountKey}";
                }
                else
                {
                    AccountActivity.ConsolidationActivityStatusKey = (short)ActivityStatus.Failed;
                    throw new Exception($"Failed to add savings account agreement for account key {Account?.AccountKey}, reason: {result.ResponseText}");
                }
            }
            else
            {
                AccountActivity.ConsolidationActivityStatusKey = (short)ActivityStatus.Skipped;
            }
        }
    }
}
