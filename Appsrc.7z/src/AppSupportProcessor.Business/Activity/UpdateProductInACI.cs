﻿using AppSupportProcessor.Business.LegacyApi;
using AppSupportProcessor.Common.Utilities;
using AppSupportProcessor.DataAccess.Repositories;
using AppSupportProcessor.Model.Consolidation;
using AppSupportProcessor.Model.Enum;
using Newtonsoft.Json;
using ProcessorTransmission;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace AppSupportProcessor.Business.Activity
{
    public class UpdateProductInACI : IActivity
    {
        private readonly IProcessorTransmissionRepository _processorTransmissionRepository;
        private readonly INECNRTRepository _nECNRTRepository;
        private readonly INECRepository _nECRepository;
        private readonly ICache _cache;

        public int Priority { get; } = 1;
        public ConsolidationAccount Account { get; set; }
        public ConsolidationAccountActivity AccountActivity { get; set; }

        public UpdateProductInACI(IProcessorTransmissionRepository processorTransmissionRepository, INECNRTRepository nECNRTRepository, INECRepository nECRepository, ICache cache)
        {
            _processorTransmissionRepository = processorTransmissionRepository;
            _nECNRTRepository = nECNRTRepository;
            _nECRepository = nECRepository;
            _cache = cache;
        }

        public async Task ExecuteAsync()
        {
            Console.WriteLine("UpdateProductInACI.ExecuteAsync");
            
            var activity = await _nECNRTRepository.GetConsolidationAccountActivityByKeyAsync(AccountActivity.ConsolidationAccountActivityKey);
            if (activity.ConsolidationActivityStatusKey == (short)ActivityStatus.Success)
                return;

            //Get plastic list by card reference, return plastic isPersonalized, isActive, IsEMV, bin..
            var plasticList = await _nECRepository.GetGetPlasticInfoByCardreference(Account.CardReference);
           
            var activePlastic = plasticList?.MaxBy(it=>it.CardKey);

            if (activePlastic == null) 
                throw new Exception("No active plastic found");

            var processorProductType = activePlastic.IsPersonalized ? 2 : 1;
            var pan = new Helper().SerialNumberToCardNumber(activePlastic.SerialNbr);
            var bin = pan.Substring(0, 6);

            //get target product code 
            var productMappingList = _cache.GetData<List<ConsolidationProductMapping>>("AppSupport_ConsolidationProductMapping");
            if (productMappingList == null || productMappingList.Count == 0)
            {
                productMappingList = await _nECNRTRepository.GetAllConsolidationProductMappingAsync();
                _cache.InsertData("AppSupport_ConsolidationProductMapping", productMappingList, TimeSpan.FromDays(1));
            }

            //Get original product information and log it in activity details
            var customerMembershipAndFeeGroup = await _nECRepository.GetConsolidationSourceDetailsByCutomerkeyAndAccountkey(Account.CustomerKey, Account.AccountKey);//(3697054, 2121654);
            if (customerMembershipAndFeeGroup == null)
                throw new Exception($"No membership group found for customer: {Account.CustomerKey}");

            var targetProduct = productMappingList.Where(p => p.SourceProductKey == Account.ProductKey && p.SourceMembershipGroupKey == customerMembershipAndFeeGroup.MembershipGroupKey).ToList().FirstOrDefault();
            //COFO-107611: Some account did not have membership
            if (customerMembershipAndFeeGroup.MembershipGroupKey == 0)
            {
                targetProduct = productMappingList.Where(p => p.SourceProductKey == Account.ProductKey).FirstOrDefault();
            }


            //special case for product 7009, If primary account productkey = 7727 or 7719
            //Then consolidate this account product to 7720
            if (Account.ProductKey == 7009)
            {
                var primaryAccountProductKey = await GetFamilyAccountProductKey(Account.AccountKey);
                if (primaryAccountProductKey == 7727 || primaryAccountProductKey == 7719)
                {
                    targetProduct = productMappingList.Where(p => p.TargetProductKey == 7720).ToList().FirstOrDefault();
                    Account.LinkedProductKey = primaryAccountProductKey;
                }
            }

            if (targetProduct == null)
            {
                throw new Exception("No target product found");
            }

            var aciProductDefinitionList = await _nECRepository.GetACIProductDefinition(targetProduct.TargetProductKey); 

            var processorProduct = await _nECRepository.GetProcessorProductCodesByCardReferenceIDAsync(activePlastic.CardReferenceID, customerMembershipAndFeeGroup.MembershipTypeKey);
            if(processorProduct == null)
                throw new Exception("No processor product found");

            var aciOriginalProductDefinitionList = await _nECRepository.GetACIProductDefinition(Account.ProductKey);
            var origialproductDefinition = aciOriginalProductDefinitionList.Where(p => p.ProcessorProductKey == processorProduct.ProcessorProductKey && p.ProductKey == Account.ProductKey && p.BIN == bin).FirstOrDefault();

            //Get FAB5 from ACI definition by product code, bin and ProcessorProductType(1: temp, 2: perso)
            var productDefinition = aciProductDefinitionList.Where(p => p.ProcessorProductTypeKey == 2 && p.BIN == bin).FirstOrDefault();
            if (productDefinition == null)
            {
                productDefinition = aciProductDefinitionList.Where(p => p.ProcessorProductTypeKey == processorProductType && p.BIN == bin).FirstOrDefault();
                if (productDefinition == null)
                    throw new Exception("No target product definition found");
            }


            //update product in ACI
            var response = await _processorTransmissionRepository.UpdateProductAsync(new UpdateProductRequest()
            {
                CardReferenceID = new CardReferenceID() { Value = activePlastic.CardReferenceID.ToString() },
                CallChainID = new CallChainID() { value = Guid.NewGuid() },
                ProductCode = new ProductCode()
                {
                    ACIAccountTypeId = new ACIAccountTypeId() { Value = productDefinition.ACIAccountType },
                    ACIProductId = new ACIProductId() { Value = productDefinition.ACIProductID },
                }
            });

            if(!response.Success)
                 throw new Exception($"Update product in ACI failed. Errormessage: {response.ErrorDescription}, requestId: {response.CallChainID.value}");
            AccountActivity.ActivityDetail = JsonConvert.SerializeObject(new object[] { new { OldProductDetail = origialproductDefinition } });
            AccountActivity.ConsolidationActivityStatusKey = (short)ActivityStatus.Success;
        }

        private async Task<short> GetFamilyAccountProductKey(int accountKey)
        {
            var linkedAccount = await _nECRepository.GetFamilyLinkedAccounts(accountKey);
            if (linkedAccount == null)
                throw new Exception("No family account found");
            var primaryAccountProduct = await _nECRepository.GetProductKeyByAccountKey(linkedAccount.PrimaryAccountKey);
            return primaryAccountProduct.ProductKey;
        }
    }
}
