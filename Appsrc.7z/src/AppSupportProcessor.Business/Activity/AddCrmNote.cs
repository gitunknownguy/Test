﻿using AppSupportProcessor.Business.LegacyApi;
using AppSupportProcessor.Model.Consolidation;
using AppSupportProcessor.Model.Enum;
using AppSupportProcessor.Model.LegacyApi;
using System;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.Activity
{
    public class AddCrmNote : IActivity
    {
        private readonly ICRMRepository _crmRepository;
        public int Priority { get; } = 11;
        public ConsolidationAccount Account { get; set; }
        public ConsolidationAccountActivity AccountActivity { get; set; }

        public AddCrmNote(ICRMRepository crmRepository)
        {
            _crmRepository = crmRepository;
        }

        public async Task ExecuteAsync()
        {
            var result = await _crmRepository.AddNote(new AddNoteRequest
            {
                RequestId = Guid.NewGuid(),
                TablePk = (int)Account.CustomerKey,
                Type = NoteTypeEnum.ProdConsolidate,
                UserToken = "10",
                Note = $"Migration Account(AccountKey:{Account.AccountKey},Source ProductKey:{Account.ProductKey}, CustomerKey:{Account.CustomerKey}) at {DateTime.Now}"
            });

            if (result?.NoteKey != null && result?.NoteKey != 0)
            {
                AccountActivity.ConsolidationActivityStatusKey = (short)ActivityStatus.Success;
                AccountActivity.ActivityDetail = $"Note added to CRM with NoteKey: {result.NoteKey}";
            }
            else
            {
                AccountActivity.ConsolidationActivityStatusKey = (short)ActivityStatus.Failed;
                throw new Exception($"Failed to add note to CRM, reason: {result.ErrorMessage}");
            }
        }
    }
}
