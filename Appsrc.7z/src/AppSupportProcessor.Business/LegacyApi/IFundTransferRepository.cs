﻿using AppSupportProcessor.Business.WebApi;
using AppSupportProcessor.Model.LegacyApi;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.LegacyApi
{
    public interface IFundTransferRepository
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<TransferResponse> VaultTransfer(TransferRequest request);
    }
}
