﻿using AccountManagement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CardAccountTransactionService;
using AppSupportProcessor.Model.LegacyApi;
using AppSupportProcessor.Business.WebApi;
using Microsoft.Extensions.Logging;
using System.Net.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Gd.Aop.Common;

namespace AppSupportProcessor.Business.LegacyApi
{
    public interface ICarePDFMergeAPIRepository
    {
        [LogMethodContext]
        Task<GenerateMultipleEStatementResponse> GenerateMultipleEStatementAsync(GenerateMultipleEStatementRequest request);

        [LogMethodContext]
        Task<GenerateLegacyPaper1099IntResponse> GeneratePaper1099IntAsync(GenerateLegacyPaper1099IntRequest request);
    }

    public class CarePDFMergeAPIRepository : WebApiClientBase, ICarePDFMergeAPIRepository
    {
        private readonly IConfiguration _configuration;
        protected override string ApiBaseUrl { get; }
        protected override HttpClient InnerHttpClient { get; }

        private readonly int _timeout;
        public CarePDFMergeAPIRepository(
            IConfiguration configuration,
            ILogger<CarePDFMergeAPIRepository> logger,
            IHttpClientFactory httpClientFactory)
            : base(logger)
        {
            _configuration = configuration;
            InnerHttpClient = httpClientFactory.CreateClient("CarePDFMergeAPI");
            _timeout = _configuration.GetSection("Legacy:CarePDFMergeAPI:GenerateMultipleEStatement:TimeOutInMs").Get<int>();
        }

        public async Task<GenerateMultipleEStatementResponse> GenerateMultipleEStatementAsync(GenerateMultipleEStatementRequest request)
        {
            var apiUrl = _configuration.GetSection("Legacy:CarePDFMergeAPI:GenerateMultipleEStatement:RelativeUrl").Get<string>();
            var response = await CallService<GenerateMultipleEStatementRequest, GenerateMultipleEStatementResponse>(request, apiUrl, _timeout, HttpMethod.Post, 0);

            return response;
        }


        public async Task<GenerateLegacyPaper1099IntResponse> GeneratePaper1099IntAsync(GenerateLegacyPaper1099IntRequest request)
        {
            var apiUrl = _configuration.GetSection("Legacy:CarePDFMergeAPI:GeneratePaper1099Int:RelativeUrl").Get<string>();
            var response = await CallService<GenerateLegacyPaper1099IntRequest, GenerateLegacyPaper1099IntResponse>(request, apiUrl, _timeout, HttpMethod.Post, 0);

            return response;
        }
    }
}
