﻿using AgreementService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.LegacyApi
{
    public interface IAgreementRepository
    {
        Task<SetAccountAgreementResponse> SetAccountAgreementAsync(SetAccountAgreementRequest request);
    }
}
