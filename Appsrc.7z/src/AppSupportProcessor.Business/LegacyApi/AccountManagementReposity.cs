﻿using AccountManagement;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Polly;
using Polly.Retry;
using System;
using System.ServiceModel;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.LegacyApi
{
    public class AccountManagementReposity : IAccountManagementReposity
    {
        private readonly ILogger<AccountManagementReposity> _logManager;
        private readonly ChannelFactory<IAccountSubscription> _factory;
        private readonly ChannelFactory<ICard> _cardFactory;
        private readonly IConfiguration _configuration;
        private readonly AsyncRetryPolicy _retryPolicy;

        public AccountManagementReposity(
            ILogger<AccountManagementReposity> logManager,
            IConfiguration configuration
            )
        {
            _logManager = logManager;
            _configuration = configuration;

            _factory = ServiceClientFactory.Factory.CreateAccountSubscriptionClient(_configuration.GetSection("Legacy:AccountManagementApi:BaseUrl").Get<string>());
            _cardFactory = ServiceClientFactory.Factory.CreateAMCardClient(_configuration.GetSection("Legacy:AccountManagementApi:BaseUrl").Get<string>());
           
            _retryPolicy = Policy.Handle<Exception>().RetryAsync(3, (exception, retryCount, context) =>
            {
                Task.Delay(TimeSpan.FromSeconds(retryCount)).Wait();
            });
        }

        public async Task<AddSubscriptionResponse> AddSubscriptionAsync(AddSubscriptionRequest request)
        {
            var channel = _factory.CreateChannel();
            var resp = await channel.AddSubscriptionAsync(request);
            return resp;
        }

        public async Task<RemoveSubscriptionResponse> RemoveSubscriptionAsync(RemoveSubscriptionRequest request)
        {
            var channel = _factory.CreateChannel();
            var resp = await channel.RemoveSubscriptionAsync(request);
            return resp;
        }

        public async Task<ReplaceResponse> ReplaceCardAsync(ReplaceRequest request)
        {
            var channel = _cardFactory.CreateChannel();
            var resp = await channel.ReplaceAsync(request);
            return resp;
        }

    }
}
