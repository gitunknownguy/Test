﻿using AppSupportProcessor.Business.WebApi;
using AppSupportProcessor.Model.LegacyApi;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.LegacyApi
{
    [ExcludeFromCodeCoverage]
    public class MMSDepositAccountRepository : WebApiClientBase, IMMSDepositAccountRepository
    {

        private readonly IConfiguration _configuration;
        protected override HttpClient InnerHttpClient { get; }
        protected override string ApiBaseUrl { get; }
        private readonly ILogger<MMSDepositAccountRepository> _logger;

        private readonly int _timeout;
        public MMSDepositAccountRepository(
            IConfiguration configuration,
            ILogger<MMSDepositAccountRepository> logger,
            IHttpClientFactory httpClientFactory)
            : base(logger)
        {
            _configuration = configuration;
            InnerHttpClient = httpClientFactory.CreateClient("MMSDepositAccountService");
            ApiBaseUrl = _configuration.GetSection("Legacy:DepositAccountApi:BaseUrl").Get<string>();
            _timeout = _configuration.GetSection("Legacy:DepositAccountApi:Credit:TimeOutInMs").Get<int>();
            _logger = logger;
        }
        public async Task<DepositAccountCreditResponse> Credit(DepositAccountCreditRequest request)
        {
            var apiUrl = _configuration.GetSection("Legacy:DepositAccountApi:Credit:RelativeUrl").Get<string>();
            request.DetailAccountTransactionType = DetailAccountTransactionType.InterestPayment;
            request.TransactionDescription = "Reimbursement Interest To Vault";

            _logger.LogInformation($"InterestPayHandler-Start DepositAccountCreditRequest is {JsonConvert.SerializeObject(request)}");
            var response = await CallService<DepositAccountCreditRequest, DepositAccountCreditResponse>(request, apiUrl, _timeout, HttpMethod.Post);
            _logger.LogInformation($"InterestPayHandler-End DepositAccountCreditRequest is {JsonConvert.SerializeObject(response)}");

            return response;
        }
    }
}
