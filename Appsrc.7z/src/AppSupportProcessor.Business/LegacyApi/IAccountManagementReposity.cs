﻿using AccountManagement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.LegacyApi
{
    public interface IAccountManagementReposity
    {
        Task<AddSubscriptionResponse> AddSubscriptionAsync(AddSubscriptionRequest request);
        Task<RemoveSubscriptionResponse> RemoveSubscriptionAsync(RemoveSubscriptionRequest request);
        Task<ReplaceResponse> ReplaceCardAsync(ReplaceRequest request);
    }
}
