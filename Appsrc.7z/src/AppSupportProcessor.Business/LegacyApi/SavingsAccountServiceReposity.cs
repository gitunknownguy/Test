﻿using AccountManagement;
using Microsoft.Extensions.Logging;
using Polly.Retry;
using Polly;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using SavingsAccountService;

namespace AppSupportProcessor.Business.LegacyApi
{
    public class SavingsAccountServiceReposity: ISavingsAccountServiceReposity
    {
        private readonly ILogger<SavingsAccountServiceReposity> _logManager;
        private readonly ChannelFactory<ISavingsAccount> _factory;
        private readonly IConfiguration _configuration;
        private readonly AsyncRetryPolicy _retryPolicy;

        public SavingsAccountServiceReposity(
            ILogger<SavingsAccountServiceReposity> logManager,
            IConfiguration configuration
            )
        {
            _logManager = logManager;
            _configuration = configuration;

            _factory = ServiceClientFactory.Factory.CreateSavingsAccountClient(_configuration.GetSection("Legacy:SavingsAccountServiceApi:BaseUrl").Get<string>());

            _retryPolicy = Policy.Handle<Exception>().RetryAsync(3, (exception, retryCount, context) =>
            {
                Task.Delay(TimeSpan.FromSeconds(retryCount)).Wait();
            });
        }

        public async Task<CreateAccountResponse> AddSubscriptionAsync(CreateAccountRequest request)
        {
            var excutionResult = await _retryPolicy.ExecuteAndCaptureAsync(async () =>
            {
                var channel = _factory.CreateChannel();
                var resp = await channel.CreateAccountAsync(request.AccountKey);
                return resp;
            });

            if (excutionResult.Outcome == OutcomeType.Successful)
            {
                return excutionResult.Result;
            }
            else
            {
                _logManager.LogError(
                    "Unexcepted error happened when try to set account agreement.");
                return new CreateAccountResponse()
                {

                };
            }

        }

        public async Task<CreateAccountResponse> CreateAccountAsync(int accountKey)
        {
            _logManager.LogInformation($"CreateAccountAsync-Start is {accountKey}");
            var channel = _factory.CreateChannel();
            var resp = await channel.CreateAccountAsync(accountKey);
            return resp;

        }
    }
}
