﻿using SavingsAccountService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.LegacyApi
{
    public interface ISavingsAccountServiceReposity
    {
        Task<CreateAccountResponse> CreateAccountAsync(int accountKey);
    }
}
