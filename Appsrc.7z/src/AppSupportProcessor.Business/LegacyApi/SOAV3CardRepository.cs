﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SOAV3CardService;
using System;
using System.Diagnostics.CodeAnalysis;
using System.ServiceModel;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.LegacyApi
{
    public interface ISOAV3CardRepository
    {
        Task<ReplacementResponse> ReplaceCardAsync(ReplacementRequest request);
    }

    [ExcludeFromCodeCoverage]
    public class SOAV3CardRepository: ISOAV3CardRepository
    {
        private readonly ChannelFactory<ICardService> _factory;
        private readonly IConfiguration _configuration;
        private readonly ILogger<SOAV3CardRepository> _logManager;

        public SOAV3CardRepository(
            ILogger<SOAV3CardRepository> logManager,
            IConfiguration configuration
            )
        {
            _configuration = configuration;
            _factory = ServiceClientFactory.Factory.CreateCardServiceClient(_configuration.GetSection("Legacy:CardApi:BaseUrl").Get<string>());
            _factory.Credentials.Windows.ClientCredential = System.Net.CredentialCache.DefaultNetworkCredentials;
            _logManager = logManager;
        }

        public async Task<ReplacementResponse> ReplaceCardAsync(ReplacementRequest request)
        {
            try
            {
                var channel = _factory.CreateChannel();
                var resp = await channel.ReplaceCardAsync(request);
                return resp;
            }
            catch(Exception ex)
            {
                _logManager.LogError(ex, "Replace card failed");
                return new ReplacementResponse
                {
                    CardReplaced = false
                };
            }
        }
    }
}
