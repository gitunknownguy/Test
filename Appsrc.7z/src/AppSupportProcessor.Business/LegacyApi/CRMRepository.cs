﻿using AppSupportProcessor.Business.WebApi;
using AppSupportProcessor.Model.LegacyApi;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.LegacyApi
{
    public interface ICRMRepository
    {
        Task<AddNoteResponse> AddNote(AddNoteRequest request);
    }

    [ExcludeFromCodeCoverage]
    public class CRMRepository: WebApiClientBase, ICRMRepository
    {
        private readonly IConfiguration _configuration;
        protected override HttpClient InnerHttpClient { get; }
        protected override string ApiBaseUrl { get; }
        private readonly ILogger<FundTransferRepository> _logger;

        private readonly int _timeout;
        public CRMRepository(
            IConfiguration configuration,
            ILogger<FundTransferRepository> logger,
            IHttpClientFactory httpClientFactory)
            : base(logger)
        {
            _configuration = configuration;
            InnerHttpClient = httpClientFactory.CreateClient("CrmApi");
            _timeout = _configuration.GetSection("Legacy:CrmApi:AddNote:TimeOutInMs").Get<int>();
            _logger = logger;
        }

        public async Task<AddNoteResponse> AddNote(AddNoteRequest request)
        {
            var apiUrl = _configuration.GetSection("Legacy:CrmApi:AddNote:RelativeUrl").Get<string>();

            _logger.LogInformation($"AddNote-Start is {JsonConvert.SerializeObject(request)}");
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("x-sysuserKey", request.UserToken);
            var response = await CallService<AddNoteRequest, AddNoteResponse>(request, apiUrl, _timeout, HttpMethod.Post,0, headers);
            _logger.LogInformation($"AddNote-End is {JsonConvert.SerializeObject(response)}");

            return response;
        }
    }
}
