﻿using AppSupportProcessor.Business.WebApi;
using AppSupportProcessor.Model.LegacyApi;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Net.Http;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.LegacyApi
{
    public interface INotifyApiRepository
    {
        Task<SendCnResponse> Send(SendCnRequest request);
    }

    [ExcludeFromCodeCoverage]
    public class NotifyApiRepository: WebApiClientBase, INotifyApiRepository
    {
        private readonly IConfiguration _configuration;
        protected override HttpClient InnerHttpClient { get; }
        protected override string ApiBaseUrl { get; }
        private readonly ILogger<FundTransferRepository> _logger;

        private readonly int _timeout;
        public NotifyApiRepository(
            IConfiguration configuration,
            ILogger<FundTransferRepository> logger,
            IHttpClientFactory httpClientFactory)
            : base(logger)
        {
            _configuration = configuration;
            InnerHttpClient = httpClientFactory.CreateClient("NotifyApi");
            _timeout = _configuration.GetSection("Legacy:NotifyApi:Send:TimeOutInMs").Get<int>();
            _logger = logger;
        }

        public async Task<SendCnResponse> Send(SendCnRequest request)
        {
            var apiUrl = _configuration.GetSection("Legacy:NotifyApi:Send:RelativeUrl").Get<string>();

            _logger.LogInformation($"Send-Start is {JsonConvert.SerializeObject(request)}");
            var response = await CallService<SendCnRequest, SendCnResponse>(request, apiUrl, _timeout, HttpMethod.Post, 0);
            _logger.LogInformation($"Send-End is {JsonConvert.SerializeObject(response)}");

            return response;
        }
    }
}
