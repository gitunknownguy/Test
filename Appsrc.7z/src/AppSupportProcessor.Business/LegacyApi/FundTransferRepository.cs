﻿using AppSupportProcessor.Business.WebApi;
using AppSupportProcessor.Model.LegacyApi;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.LegacyApi
{
    [ExcludeFromCodeCoverage]
    public class FundTransferRepository : WebApiClientBase, IFundTransferRepository
    {

        private readonly IConfiguration _configuration;
        protected override HttpClient InnerHttpClient { get; }
        protected override string ApiBaseUrl { get; }
        private readonly ILogger<FundTransferRepository> _logger;

        private readonly int _timeout;
        public FundTransferRepository(
            IConfiguration configuration,
            ILogger<FundTransferRepository> logger,
            IHttpClientFactory httpClientFactory)
            : base(logger)
        {
            _configuration = configuration;
            InnerHttpClient = httpClientFactory.CreateClient("VaultTransferApi");
            _timeout = _configuration.GetSection("Legacy:VaultTransferApi:VaultTransfer:TimeOutInMs").Get<int>();
            _logger = logger;
        }

        public async Task<TransferResponse> VaultTransfer(TransferRequest request)
        {
            var apiUrl = _configuration.GetSection("Legacy:VaultTransferApi:VaultTransfer:RelativeUrl").Get<string>();

            _logger.LogInformation($"VaultTransfer-Start is {JsonConvert.SerializeObject(request)}");
            var response = await CallService(request, apiUrl, _timeout, HttpMethod.Post);
            _logger.LogInformation($"VaultTransfer-End is {JsonConvert.SerializeObject(response)}");

            return response;
        }


    }
}
