﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.Channels;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using AppSupportProcessor.Business.LegacyApi;
using Microsoft.IdentityModel.Protocols;
using AgreementService;
using Microsoft.Extensions.Configuration;
using AccountManagement;
using SavingsAccountService;
using SOAV3CardService;

namespace AppSupportProcessor.Business.LegacyApi
{
    public class ServiceClientFactory
    {
        private static ServiceClientFactory _factory;
        private AddressHeader[] _addressHeader;
        private BasicHttpBinding _binding;

        private ServiceClientFactory()
        {
            _addressHeader = new[] {
                                      AddressHeader.CreateAddressHeader("X-GDC-ApplicationID", "", "8017")
                                   };
            _binding = new BasicHttpBinding(BasicHttpSecurityMode.TransportCredentialOnly);
            _binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Ntlm;
            _binding.Security.Transport.ProxyCredentialType = HttpProxyCredentialType.Ntlm;
        }

        public static ServiceClientFactory Factory
        {
            get
            {
                if (_factory == null)
                {
                    _factory = new ServiceClientFactory();
                }
                return _factory;
            }
        }

        public ChannelFactory<IAgreement> CreateAgreementClient(string url)
        {
            EndpointAddress address = new EndpointAddress(new Uri(url), _addressHeader);
            return new ChannelFactory<IAgreement>(_binding, address);
        }

        public ChannelFactory<IAccountSubscription> CreateAccountSubscriptionClient(string url)
        {
            EndpointAddress address = new EndpointAddress(new Uri(url), _addressHeader);
            return new ChannelFactory<IAccountSubscription>(_binding, address);
        }

        public ChannelFactory<ISavingsAccount> CreateSavingsAccountClient(string url)
        {
            EndpointAddress address = new EndpointAddress(new Uri(url), _addressHeader);
            return new ChannelFactory<ISavingsAccount>(_binding, address);
        }

        public ChannelFactory<T> CreateClient<T>(string url)
        {
            EndpointAddress address = new EndpointAddress(new Uri(url), _addressHeader);
            return new ChannelFactory<T>(_binding, address);
        }

        public ChannelFactory<ICardService> CreateCardServiceClient(string url)
        {
            EndpointAddress address = new EndpointAddress(new Uri(url), _addressHeader);
            return new ChannelFactory<ICardService>(_binding, address);
        }

        public ChannelFactory<ICard> CreateAMCardClient(string url)
        {
            EndpointAddress address = new EndpointAddress(new Uri(url), _addressHeader);
            return new ChannelFactory<ICard>(_binding, address);
        }
    }
}
