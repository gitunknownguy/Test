﻿using ProcessorTransmission;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.LegacyApi
{
    public interface IProcessorTransmissionRepository
    {
        Task<UpdateProductResponse> UpdateProductAsync(UpdateProductRequest request);
    }
}
