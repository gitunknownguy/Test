﻿using Microsoft.Extensions.Logging;
using Polly.Retry;
using Polly;
using ProcessorTransmission;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using AgreementService;
using AccountManagement;
using CardAccountTransactionService;

namespace AppSupportProcessor.Business.LegacyApi
{
    public interface ICardAccountTransactionServiceRepository
    {

        Task<GetAvailableStatementsResponse> GetAvailableStatementsAsync(GetAvailableStatementsRequest request);
    }
    public class CardAccountTransactionServiceRepository : ICardAccountTransactionServiceRepository
    {
        private readonly ChannelFactory<ICardAccountTransaction> _factory;

        public CardAccountTransactionServiceRepository(IConfiguration configuration)
        {
            _factory = ServiceClientFactory.Factory.CreateClient<ICardAccountTransaction>(configuration.GetSection("Legacy:CardAccountTransactionServiceApi:BaseUrl").Get<string>());
        }

        public async Task<GetAvailableStatementsResponse> GetAvailableStatementsAsync(GetAvailableStatementsRequest request)
        {
            var channel = _factory.CreateChannel();
            var resp = await channel.GetAvailableStatementsAsync(request);
            return resp;
        }
    }
}
