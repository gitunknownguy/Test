﻿using AppSupportProcessor.Business.WebApi;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Polly;
using Polly.Retry;
using ProcessorTransmission;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.LegacyApi
{
    public class ProcessorTransmissionRepository: IProcessorTransmissionRepository
    {
        private readonly ILogger<ProcessorTransmissionRepository> _logManager;
        private readonly ChannelFactory<IProcessorTransmission> _factory;
        private readonly IConfiguration _configuration;
        private readonly bool _nonProductEnvironment;
        private readonly AsyncRetryPolicy _retryPolicy;

        public ProcessorTransmissionRepository(
            ILogger<ProcessorTransmissionRepository> logManager,
            IConfiguration configuration
            )
        {
            _logManager = logManager;
            _configuration = configuration;
            var binding = new WSHttpBinding(SecurityMode.None);
            var endpoint = new EndpointAddress(_configuration.GetSection("Legacy:ProcessorTransmissionApi:BaseUrl").Get<string>());
            binding.SendTimeout = TimeSpan.FromSeconds(_configuration.GetSection("Legacy:ProcessorTransmissionApi:UpdateProduct:TimeOutInMs").Get<int>());

            var client = new ProcessorTransmissionClient(binding, endpoint);
            _factory = client.ChannelFactory;

            _retryPolicy = Policy.Handle<Exception>().RetryAsync(3, (exception, retryCount, context) =>
             {
                Task.Delay(TimeSpan.FromSeconds(retryCount)).Wait();
             });
        }

        public async Task<UpdateProductResponse> UpdateProductAsync(UpdateProductRequest request)
        {
            var channel = _factory.CreateChannel();
            var resp = await channel.UpdateProductAsync(request);
            return resp;

        }

    }
}
