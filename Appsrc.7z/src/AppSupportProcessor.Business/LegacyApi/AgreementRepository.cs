﻿using Microsoft.Extensions.Logging;
using Polly.Retry;
using Polly;
using ProcessorTransmission;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using AgreementService;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using System.ServiceModel.Channels;

namespace AppSupportProcessor.Business.LegacyApi
{
    public class AgreementRepository : IAgreementRepository
    {
        private readonly ILogger<AgreementRepository> _logManager;
        private readonly ChannelFactory<IAgreement> _factory;
        private readonly IConfiguration _configuration;
        private readonly AsyncRetryPolicy _retryPolicy;

        public AgreementRepository(
            ILogger<AgreementRepository> logManager,
            IConfiguration configuration
            )
        {
            _logManager = logManager;
            _configuration = configuration;

            _factory = ServiceClientFactory.Factory.CreateAgreementClient(_configuration.GetSection("Legacy:AgreementApi:BaseUrl").Get<string>());

            _retryPolicy = Policy.Handle<Exception>().RetryAsync(3, (exception, retryCount, context) =>
            {
                Task.Delay(TimeSpan.FromSeconds(retryCount)).Wait();
            });
        }

        public async Task<SetAccountAgreementResponse> SetAccountAgreementAsync(SetAccountAgreementRequest request)
        {
            var channel = _factory.CreateChannel();
            var resp = await channel.SetAccountAgreementAsync(request);
            return resp;

        }
    }
}


