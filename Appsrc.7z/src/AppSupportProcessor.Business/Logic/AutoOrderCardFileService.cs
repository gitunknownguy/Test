﻿using AppSupportProcessor.Model.AutoOrderCard;
using AppSupportProcessor.Model.Consolidation;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;

namespace AppSupportProcessor.Business.Logic
{
    public interface IAutoOrderCardFileService
    {
        void MoveFile(string sourcePath, string targetPath);
        List<string> GetFiles(string directoryPath);
        List<AutoOrderCardAccount> GetFileData(string filePath);
        void Delete(string filePath);
    }

    [ExcludeFromCodeCoverage]
    public class AutoOrderCardFileService: IAutoOrderCardFileService
    {
        private ILogger<AutoOrderCardFileService> _logger;
        public AutoOrderCardFileService(ILogger<AutoOrderCardFileService> logger)
        {
            _logger = logger;
        }

        public void MoveFile(string sourcePath, string targetPath)
        {
            File.Move(sourcePath, targetPath);
        }

        public List<string> GetFiles(string directoryPath)
        {
            return Directory.GetFiles(directoryPath, "*.csv", SearchOption.TopDirectoryOnly).ToList();
        }

        public List<AutoOrderCardAccount> GetFileData(string filePath)
        {
            List<AutoOrderCardAccount> accounts = new List<AutoOrderCardAccount>();

            using (CsvFileReader reader = new CsvFileReader(filePath))
            {
                CsvRow row = new CsvRow();
                while (reader.ReadRow(row))
                {
                    if (row[0].Trim().ToLower() == "accountkey")//header
                        continue;

                    if (row.Count < 2)
                    {
                        _logger.LogWarning($"Invalid row found in file {filePath}. Row: {row.LineText}");
                        continue;
                    }

                    int.TryParse(row[0].Trim(), out int accountKey);
                    int.TryParse(row[1].Trim(), out int customerKey);

                    if (accountKey == 0 || customerKey == 0)
                    {
                        _logger.LogWarning($"Invalid row found in file {filePath}. Row: {row.LineText}");
                        continue;
                    }

                    AutoOrderCardAccount account = new AutoOrderCardAccount()
                    {
                        AccountKey = accountKey,
                        CustomerKey = customerKey,
                        AutoOrderCardAccountStatusKey = (short)AutoOrderCardAccountStatus.Pending
                    };
                    accounts.Add(account);
                }
            }

            return accounts;
        }

        public void Delete(string filePath)
        {
            try
            {
                if (File.Exists(filePath))
                    File.Delete(filePath);
            }
            catch { }
        }
    }
}
