using AppSupportProcessor.DataAccess.DataAccesses;
using AppSupportProcessor.DataAccess.DataAccesses.Models;
using AppSupportProcessor.Model.AutoOrderCard;
using AppSupportProcessor.Model.Consolidation;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.Logic
{
    public interface IExcludeTestAccountService
    {
        Task RemoveAllTestAccountPaperStatement(List<PaperStatementStagingInfo> paperStatementStagingInfos);
    }

    [ExcludeFromCodeCoverage]
    public class ExcludeTestAccountService : IExcludeTestAccountService
    {
        private readonly INecDataAccess _necDataAccess;

        public ExcludeTestAccountService(INecDataAccess necDataAccess)
        {
            _necDataAccess = necDataAccess;
        }

        public async Task RemoveAllTestAccountPaperStatement(List<PaperStatementStagingInfo> paperStatementStagingInfos)
        {
            var accountKeyInfos = paperStatementStagingInfos.Select(o => new AccountKeyInfo()
            {
                AccountKey = o.AccountKey
            }).Distinct().ToList();
            var consumerInfos = await _necDataAccess.GetConsumerInfoByAccountKeys(accountKeyInfos);
            foreach (var consumerInfo in consumerInfos)
            {
                if (!string.IsNullOrEmpty(consumerInfo.FirstName) && !string.IsNullOrEmpty(consumerInfo.LastName))
                {
                    if (string.Equals(consumerInfo.FirstName, "Vauled", StringComparison.OrdinalIgnoreCase)
                        && consumerInfo.LastName.EndsWith("GDCustomer", StringComparison.OrdinalIgnoreCase))
                    {
                        paperStatementStagingInfos.RemoveAll(o => o.AccountKey == consumerInfo.AccountKey);
                    }
                }
            }
        }
    }
}
