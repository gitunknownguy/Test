﻿using AppSupportProcessor.Model.Interest;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.Logic
{
    public interface IRecalculatePayout
    {
        DepositAccountInterestReimbursePayout SingleInterestReimbursement(DepositAccountInterestReimbursePayout payout,
                                                    List<MembershipInterestAccrual> membershipMetaData,
                                                    List<CustomerMembership> customerMemberships,
                                                    List<AccountBalance> balances);
    }


    /// <summary>
    /// this class does not has any exteral api depend
    /// </summary>
    public class RecalculatePayout: IRecalculatePayout
    {
        private static readonly List<string> BadCreditRatings = new List<string>
         {
             "B4" ,"C5" ,"M9", "B3" ,  "B7" , "R1",  "B5", "B9" ,"F1" ,"P9"
        };
         public RecalculatePayout()
        {

        }

        public DepositAccountInterestReimbursePayout SingleInterestReimbursement(
                                                    DepositAccountInterestReimbursePayout payout,
                                                    List<MembershipInterestAccrual> membershipMetaData,
                                                    List<CustomerMembership> customerMemberships,
                                                    List<AccountBalance> balances)
        {

            var adjustCustomerMemberships = AdjustCustomerMembershipInEdgeDate(payout.PayoutStartDate.Date, payout.PayoutEndDate.Date, customerMemberships, membershipMetaData);
            var toUpdatePayout = new DepositAccountInterestReimbursePayout
            {
                DepositAccountInterestReimbursePayoutKey = payout.DepositAccountInterestReimbursePayoutKey
            };

            //todo a question, does in a payout, can some month have interest, some month not?
            if (!adjustCustomerMemberships.Any() || !adjustCustomerMemberships.All(m => membershipMetaData.Any(mm => mm.MembershipKey == m.MembershipKey)))
            {
                toUpdatePayout.SetValue((int)ReimbursementStatus.Failed, "customer membership invalid");
                return toUpdatePayout;
            }

            //loop each membership
            var payoutInterestNew = 0M;
            foreach (var cm in adjustCustomerMemberships)
            {
                //get balance change point for current cm
                //now the balance change point have been converted to a list of time range with no overlap
                var balanceInMembership = GetBalancesInMembership(cm, balances);
                var metaData = membershipMetaData.Single(m => m.MembershipInterestAccrualKey == cm.MembershipInterestAccrualKey);

                //calc current membership's balance sum
                var balanceSumOfMembership = CalcBalanceSumOfMembership(metaData, balanceInMembership);
                var membershipDays = (cm.EndDate.Date - cm.StartDate.Date).Days + 1;

                var payoutElapsedDays = (payout.PayoutEndDate.Date - payout.PayoutStartDate.Date).Days + 1;
                payoutElapsedDays = payoutElapsedDays >= 366 ? 366 : 365;
                //current membership's interest
                var interestOfMembership = balanceSumOfMembership == 0 ? 0 : balanceSumOfMembership * metaData.APY /100/ payoutElapsedDays;
                payoutInterestNew += interestOfMembership;
            }

            payoutInterestNew = Math.Round(payoutInterestNew, 2);
            var reimbursementAmount = Math.Round(payoutInterestNew - payout.ExistingInterestAmount, 2);
            var validCsutomer  = customerMemberships.Where(c => c.SerialNbr != null)
                                                .OrderByDescending(c => c.CustomerKey)
                                                .First();
            if (BadCreditRatings.Contains(validCsutomer.CreditRatingKey))
            {
                toUpdatePayout.SetValue((int)ReimbursementStatus.Skipped, "bad credit rating", payoutInterestNew, reimbursementAmount);
            }
            else
            {
                if(reimbursementAmount > 0)
                {
                    toUpdatePayout.SetValue((int)ReimbursementStatus.Calculated, "Calculate success, need to pay customer", payoutInterestNew, reimbursementAmount);
                }
                else
                {
                    toUpdatePayout.SetValue((int)ReimbursementStatus.NoFundingRequired, "Calculate success, original amount is correct", payoutInterestNew, reimbursementAmount);
                }
            }
            
            return toUpdatePayout;


        }

        #region detail method


        /// <summary>
        /// adjust customerMemberships by 3 step 
        ///  #1  1 account can find 2 or more customers, the SerialNbr maybe null
        ///  #2  get rows only in the payout time range
        ///  #3  make the end and start date not overlapped
        /// </summary>
        /// <param name="strat"></param>
        /// <param name="end"></param>
        /// <param name="customerMemberships"></param>
        List<CustomerMembershipAdjust> AdjustCustomerMembershipInEdgeDate(DateTime payoutStart, DateTime payoutEnd, List<CustomerMembership> customerMemberships, List<MembershipInterestAccrual> medaData)
        {

            var list = new List<CustomerMembershipAdjust>();

            //try to find the customerkey with rule:
            //largest key with SerialNbr is not null 
            var oneVaildCusotmerMembership = customerMemberships.Where(c => c.SerialNbr != null)
                                                .OrderByDescending(c => c.CustomerKey)
                                                .FirstOrDefault();

            if (oneVaildCusotmerMembership == null)
            {
                return list;
            }

            //this is all the valid memerships for 1 customer
            var validCustomerMemberships = customerMemberships.Where(c => c.CustomerKey == oneVaildCusotmerMembership.CustomerKey).ToList();

            //overlap with current payout time range is what we need
            var customerMembershipsInPayoutRange = validCustomerMemberships.Where(c => c.StartDate.Date <= payoutEnd.Date && payoutStart.Date <= c.EndDate.Date)
                                .OrderBy(c => c.StartDate).ToList();


            foreach (var cm in customerMembershipsInPayoutRange)
            {
                //1 or more and cmAcct should be overlap with payout
                var cmAccts = medaData.Where(m => m.MembershipKey == cm.MembershipKey && m.StartDate.Date <= payoutEnd.Date && (!m.EndDate.HasValue || payoutStart.Date <= m.EndDate.Value.Date)).ToList();
                foreach (var cmAcct in cmAccts)
                {
                    //if the cmAcct is overlap with the cm
                    if ((!cmAcct.EndDate.HasValue || cm.StartDate.Date <= cmAcct.EndDate.Value.Date) && cmAcct.StartDate.Date <= cm.EndDate.Date)
                    {
                        var cmAdjust = new CustomerMembershipAdjust
                        {
                            MembershipKey = cmAcct.MembershipKey,
                            MembershipInterestAccrualKey = cmAcct.MembershipInterestAccrualKey,
                        };

                        var startList = new List<DateTime> { payoutStart.Date, cm.StartDate.Date, cmAcct.StartDate.Date };
                        cmAdjust.StartDate = startList.Max();
                        //if (cmAcct.StartDate.Date < payoutStart.Date)
                        //{
                        //    cmAdjust.StartDate = Math.Max(payoutStart.Date, Math.Max(cm.StartDate.Date, cmAcct.StartDate.Date));
                        //}
                        //else
                        //{
                        //    cmAdjust.StartDate = cmAcct.StartDate.Date;
                        //}
                        var endList = new List<DateTime> { payoutEnd.Date, cm.EndDate.Date.AddDays(-1), cmAcct.EndDate.HasValue ? cmAcct.EndDate.Value : DateTime.MaxValue};
                        cmAdjust.EndDate = endList.Min();
                        //if (!cmAcct.EndDate.HasValue || cmAcct.EndDate.Value.Date > payoutEnd.Date)
                        //{
                        //    cmAdjust.EndDate = payoutEnd.Date;
                        //}
                        //else
                        //{
                        //    cmAdjust.EndDate = cmAcct.EndDate.Value.Date;
                        //}
                        list.Add(cmAdjust);
                    }

                }
            }

            //var length = customerMembershipsInPayoutRange.Count();
            //for(var i=0; i< length; i++)
            //{
            //    var cmAdjust = new CustomerMembershipAdjust
            //    {
            //        MembershipKey = customerMembershipsInPayoutRange[i].MembershipKey,
            //        StartDate = customerMembershipsInPayoutRange[i].StartDate,
            //        EndDate = customerMembershipsInPayoutRange[i].EndDate,
            //    };
            //    //adjust first membership's start date 
            //    if (i == 0) { cmAdjust.StartDate = payoutStart.Date; }

            //    //in database, the nth's membership end date is same day with the next memership's start date
            //    //adjust the end date except the last one.
            //    if(i < length -1 && cmAdjust.EndDate.Date >= customerMemberships[i +1].StartDate.Date)
            //            { cmAdjust.EndDate = customerMemberships[i + 1].StartDate.Date.AddDays(-1); }

            //    //adjust last membership's end date
            //    if (i == length - 1) { cmAdjust.EndDate = payoutEnd.Date; }
            //    list.Add(cmAdjust);
            //}

            return list;
        }

        /// <summary>
        /// get the balance range list for a customer membership
        /// </summary>
        /// <param name="balances"></param>
        /// <returns></returns>
        List<BalanceRange> GetBalancesInMembership(CustomerMembershipAdjust cma, List<AccountBalance> balances)
        {
            var balancesInCm = balances.Where(b => b.EndingBalanceAsOf.Date >= cma.StartDate.Date && b.EndingBalanceAsOf.Date <= cma.EndDate.Date).ToList();
            //try to add head and tail change point
            if (!balancesInCm.Any(b => b.EndingBalanceAsOf.Date == cma.StartDate.Date))
            {
                var maxInSamll = balances.Where(b => b.EndingBalanceAsOf.Date < cma.StartDate.Date).OrderByDescending(b => b.EndingBalanceAsOf.Date).FirstOrDefault();
                if (maxInSamll != null)
                {
                    balancesInCm.Add(new AccountBalance { EndingBalance = maxInSamll.EndingBalance, EndingBalanceAsOf = cma.StartDate });
                }
                else
                {
                    balancesInCm.Add(new AccountBalance { EndingBalance = 0, EndingBalanceAsOf = cma.StartDate });
                }
            }

            //make the new add balance to the head
            balancesInCm = balancesInCm.OrderBy(b => b.EndingBalanceAsOf.Date).ToList();

            if (!balancesInCm.Any(b => b.EndingBalanceAsOf.Date == cma.EndDate.Date))
            {
                 balancesInCm.Add(new AccountBalance { EndingBalance = balancesInCm[balancesInCm.Count-1].EndingBalance, EndingBalanceAsOf = cma.EndDate });
                //var minInLager = balances.Where(b => b.EndingBalanceAsOf.Date > cma.EndDate.Date).OrderBy(b => b.EndingBalanceAsOf.Date).FirstOrDefault();
                //if (minInLager != null)
                //{
                //    balancesInCm.Add(new AccountBalance { EndingBalance = minInLager.EndingBalance, EndingBalanceAsOf = cma.EndDate });
                //}
                //else
                //{
                //    balancesInCm.Add(new AccountBalance { EndingBalance = 0, EndingBalanceAsOf = cma.EndDate });
                //}
            }

            
            var list = new List<BalanceRange>();
           
            var previous = balancesInCm[0];
            //the first range's start date is membership's start date, and the end date is itself
            var balanceRange = new BalanceRange { EndingBalance = balancesInCm[0].EndingBalance, Start = cma.StartDate.Date, End = cma.StartDate.Date };
            foreach (var item in balancesInCm)
            {
                //if balance is same, do nothing(end date expand), if current and previous balance is not same, a range added to list
                if (item.EndingBalance != previous.EndingBalance)
                {
                    balanceRange.End = item.EndingBalanceAsOf.Date.AddDays(-1);
                    list.Add(balanceRange);
                    balanceRange = new BalanceRange { EndingBalance = item.EndingBalance, Start = item.EndingBalanceAsOf.Date, End = item.EndingBalanceAsOf.Date };
                    previous = item;
                }
            }
            //the last range ends with the membership
            balanceRange.End = cma.EndDate.Date;
            list.Add(balanceRange);
            return list;
        }

        decimal CalcBalanceSumOfMembership(MembershipInterestAccrual metaData, List<BalanceRange> balanceInMembership)
        {
            decimal balanceSumOfMembership = 0M;
            foreach (var balanceRange in balanceInMembership)
            {
                var balance = balanceRange.EndingBalance >= metaData.MaximumDailyBalance
                                ? metaData.MaximumDailyBalance
                                : balanceRange.EndingBalance;

                var days = (balanceRange.End.Date - balanceRange.Start.Date).Days + 1;
                balanceSumOfMembership += balance * days;
            }

            return balanceSumOfMembership;
        }

        #endregion

    }
}
