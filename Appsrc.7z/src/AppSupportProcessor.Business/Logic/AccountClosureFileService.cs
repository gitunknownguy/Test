﻿using AppSupportProcessor.Model.AccountClosure;
using AppSupportProcessor.Model.Consolidation;
using AppSupportProcessor.Model.Enum;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;

namespace AppSupportProcessor.Business.Logic
{
    public interface IAccountClosureFileService
    {
        void MoveFile(string sourcePath, string targetPath);
        bool GenerateFile(List<string> alterPans, string targetPath, string fileName, string headfileName);
        List<string> GetFiles(string directoryPath);
        List<string> GetFiles(string directoryPath,string searchPattern);
        List<ACIAccountClosure> GetFileData(string filePath);
        IEnumerable<string> GetAllLines(string filePath);
    }

    [ExcludeFromCodeCoverage]
    public class AccountClosureFileService : IAccountClosureFileService
    {
        private ILogger<AccountClosureFileService> _logger;
        public AccountClosureFileService(ILogger<AccountClosureFileService> logger)
        {
            _logger = logger;
        }

        public void MoveFile(string sourcePath, string targetPath)
        {
            File.Move(sourcePath, targetPath);
        }

        public bool GenerateFile(List<string> alterPans, string targetPath, string fileName, string headfileName)
        {
            try
            {
                //create a file with the list of alterPans, and using given file name and filepath
                //check if file is existed, if yes, then delete it, if not, then create it
                
                if (File.Exists(Path.Combine(targetPath, fileName)))
                {
                    File.Delete(Path.Combine(targetPath, fileName));
                }

                if (File.Exists(Path.Combine(targetPath, headfileName)))
                {
                    File.Delete(Path.Combine(targetPath, headfileName));
                }

                using (var stream = File.Create(Path.Combine(targetPath, fileName)))
                using (var writer = new StreamWriter(stream))
                {
                    foreach (var pan in alterPans)
                    {
                        writer.WriteLine(pan.Trim());
                    }
                }

                using (var stream = File.Create(Path.Combine(targetPath, headfileName)))
                using (var writer = new StreamWriter(stream))
                {
                    writer.WriteLine("TotalCardNumber");
                    writer.Write(alterPans.Count);
                }

                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error occured while generating file. Error: {ex.Message}");
                return false;
            }
        }

        public List<string> GetFiles(string directoryPath)
        {
            return Directory.GetFiles(directoryPath,"*.csv", SearchOption.TopDirectoryOnly).ToList();
        }

        public List<string> GetFiles(string directoryPath, string searchPattern)
        {
            return Directory.GetFiles(directoryPath, searchPattern, SearchOption.TopDirectoryOnly).ToList();
        }

        public List<ACIAccountClosure> GetFileData(string filePath)
        {
            List<ACIAccountClosure> accounts= new List<ACIAccountClosure>();

            using (CsvFileReader reader = new CsvFileReader(filePath))
            {
                CsvRow row = new CsvRow();
                while (reader.ReadRow(row))
                {
                    if (row[0].Trim().ToLower() == "accountkey")//header
                        continue;

                    if (row.Count < 4)
                    {
                        _logger.LogWarning($"Invalid row found in file {filePath}. Row: {row.LineText}");
                        continue;
                    }
                    
                    int.TryParse(row[0].Trim(), out int accountKey);
                    int.TryParse(row[1].Trim(), out int customerKey);
                    string externalId = row[2].Trim();
                    Guid.TryParse(row[3].Trim(), out Guid fileIdentifier);

                    if(accountKey == 0 || customerKey == 0 || string.IsNullOrEmpty(externalId) || fileIdentifier == Guid.Empty)
                    {
                        _logger.LogWarning($"Invalid row found in file {filePath}. Row: {row.LineText}");
                        continue;
                    }

                    ACIAccountClosure account = new ACIAccountClosure()
                    {
                        AccountKey = accountKey,
                        CustomerKey = customerKey,
                        ACIAccountExternalID = externalId,
                        FileIdentifier = fileIdentifier,
                        ACIAccountClosureStatusKey = (short)AccountClosureStatus.Pending
                    };
                    accounts.Add(account);
                }
            }

            return accounts;
        }

        public IEnumerable<string> GetAllLines(string filePath)
        {
            return File.ReadLines(filePath);
        }
    }
}
