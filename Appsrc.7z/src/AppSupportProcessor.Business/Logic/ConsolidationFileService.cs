﻿using AppSupportProcessor.Model.Consolidation;
using AppSupportProcessor.Model.Enum;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;

namespace AppSupportProcessor.Business.Logic
{
    public interface IConsolidationFileService
    {
        void MoveFile(string sourcePath, string targetPath);
        List<string> GetFiles(string directoryPath);
        List<ConsolidationAccount> GetFileData(string filePath, long consolidationFileKey);
    }

    [ExcludeFromCodeCoverage]
    public class ConsolidationFileService : IConsolidationFileService
    {
        private ILogger<ConsolidationFileService> _logger;
        public ConsolidationFileService(ILogger<ConsolidationFileService> logger)
        {
            _logger = logger;
        }

        public void MoveFile(string sourcePath, string targetPath)
        {
            File.Move(sourcePath, targetPath);
        }

        public List<string> GetFiles(string directoryPath)
        {
            return Directory.GetFiles(directoryPath,"*.csv", SearchOption.TopDirectoryOnly).ToList();
        }

        public List<ConsolidationAccount> GetFileData(string filePath, long consolidationFileKey)
        {
            List<ConsolidationAccount> accounts= new List<ConsolidationAccount>();

            using (CsvFileReader reader = new CsvFileReader(filePath))
            {
                CsvRow row = new CsvRow();
                while (reader.ReadRow(row))
                {
                    if (row[0].Trim().ToLower() == "accountkey")//header
                        continue;

                    if (row.Count < 5)
                    {
                        _logger.LogWarning($"Invalid row found in file {filePath}. Row: {row.LineText}");
                        continue;
                    }
                    
                    int.TryParse(row[0].Trim(), out int accountKey);
                    short.TryParse(row[1].Trim(), out short productKey);
                    int.TryParse(row[2].Trim(), out int customerKey);
                    string cardReference = row[3].Trim();
                    short.TryParse(row[4].Trim(), out short consolidationGroupKey);

                    if(accountKey == 0 || productKey == 0 || customerKey == 0 || string.IsNullOrEmpty(cardReference) || consolidationGroupKey == 0)
                    {
                        _logger.LogWarning($"Invalid row found in file {filePath}. Row: {row.LineText}");
                        continue;
                    }

                    ConsolidationAccount account = new ConsolidationAccount()
                    {
                        AccountKey = accountKey,
                        ProductKey = productKey,
                        CustomerKey = customerKey,
                        CardReference = cardReference,
                        ConsolidationGroupKey = consolidationGroupKey,
                        ConsolidationStatusKey =(short)ConsolidationStatus.Pending,
                        ConsolidationAccountFileKey = consolidationFileKey
                    };
                    accounts.Add(account);
                }
            }

            return accounts;
        }
    }

    [ExcludeFromCodeCoverage]
    public class CsvRow : List<string>
    {
        public string LineText { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class CsvFileReader : StreamReader
    {
        public CsvFileReader(Stream stream) : base(stream)
        {
        }

        public CsvFileReader(string filename) : base(filename)
        {
        }

        public bool ReadRow(CsvRow row)
        {
            row.LineText = ReadLine();
            if (String.IsNullOrEmpty(row.LineText))
                return false;

            row.LineText = row.LineText + " ";
            int pos = 0;
            int rows = 0;

            while (pos < row.LineText.Length)
            {
                string value;

                // Special handling for quoted field
                if (row.LineText[pos] == '"')
                {
                    // Skip initial quote
                    pos++;

                    // Parse quoted value
                    int start = pos;
                    while (pos < row.LineText.Length)
                    {
                        // Test for quote character
                        if (row.LineText[pos] == '"')
                        {
                            // Found one
                            pos++;

                            // If two quotes together, keep one
                            // Otherwise, indicates end of value
                            if (pos >= row.LineText.Length || row.LineText[pos] != '"')
                            {
                                pos--;
                                break;
                            }
                        }
                        pos++;
                    }
                    value = row.LineText.Substring(start, pos - start);
                    value = value.Replace("\"\"", "\"");
                }
                else
                {
                    // Parse unquoted value
                    int start = pos;
                    while (pos < row.LineText.Length && row.LineText[pos] != ',')
                        pos++;
                    value = row.LineText.Substring(start, pos - start);
                }

                // Add field to list
                if (rows < row.Count)
                    row[rows] = value;
                else
                    row.Add(value);
                rows++;

                // Eat up to and including next comma
                while (pos < row.LineText.Length && row.LineText[pos] != ',')
                    pos++;
                if (pos < row.LineText.Length)
                    pos++;
            }
            // Delete any unused items
            while (row.Count > rows)
                row.RemoveAt(rows);

            // Return true if any columns read
            return (row.Count > 0);
        }
    }

}
