﻿using AppSupportProcessor.Business.Logic;
using AppSupportProcessor.Common.Configuration;
using AppSupportProcessor.DataAccess.Repositories;
using AppSupportProcessor.Model.Interest;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.Handlers
{
    public interface IInterestReimbursementHandler
    {
        Task ProcessAsync(CancellationToken cancellationToken);
    }

    [ExcludeFromCodeCoverage]
    public class InterestReimbursementHandler : IInterestReimbursementHandler
    {

        private ILogger<InterestReimbursementHandler> _logger;
        private InterestReimbursementConfiguration _config;
        private readonly INECRepository _necRepository;
        private readonly INECNRTRepository _necNRTRepository;
        private readonly int InternalBatchSize = 50;
        private readonly int InterestTablekey = 71;
        private RecalculatePayout recalculatePayout;
        //big batch size is 5000, internal batch size is 50, usually it will run 100 times at most if everything work well.
        //think about a scenario, there are exception make calculation or update fail. we cannot allow the loop conitnue running several hundrund times
        private readonly int MaxInternalLoop = 100;

        public InterestReimbursementHandler(INECRepository necRepository,
            INECNRTRepository nECNRTRepository,
            ILogger<InterestReimbursementHandler> logger, 
            IOptionsMonitor<InterestReimbursementConfiguration> config)
        {
            _necRepository = necRepository;
            _logger = logger;
            _config = config.CurrentValue;
            _necNRTRepository = nECNRTRepository;
            recalculatePayout = new RecalculatePayout();
        }


        public async Task ProcessAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("InterestReimbursementHandler is running.");

            // TestConnection();
            try
            {
                 await BatchInterestReimbursement();
                //await _necNRTRepository.InsertBatchDataToReimbursePayout(InterestTablekey, _config.BatchSize);
            }
            catch (Exception ex)
            {
                _logger.LogError("InterestReimbursementHandler-error: " + ex.ToString());
            }
          //  return Task.CompletedTask;
        }

        /// <summary>
        /// one activebatch call run a big batch for 5000 payout
        /// </summary>
        private async Task BatchInterestReimbursement()
        {
            try
            {


                var runTimes = 0;

                //get all memberships
                var membershipMetadata = _necNRTRepository.GetAllMembershipInterestAccrual().Result;
                Console.WriteLine("InterestReimbursementHandler-Step-1 membershipkey row numnber is: " + membershipMetadata.Count);
                _logger.LogInformation("InterestReimbursementHandler-Step-1 membershipkey row numnber is: " + membershipMetadata.Count);

                //batch insert to new table
                await _necNRTRepository.InsertBatchDataToReimbursePayout(InterestTablekey, _config.BatchSize);
                _logger.LogInformation("InterestReimbursementHandler-Step-2 batch insert sucess");

                //begin to resolve all rows with initiate status in new table
                while (true)
                {
                    //get 50 payouts from new table
                    var payouts = _necNRTRepository.GetDepositAccountInterestReimbursePayoutByBatch(InternalBatchSize).Result;
                    Console.WriteLine("InterestReimbursementHandler-Step-3 get a internal batch row numnber is: " + payouts.Count);
                    _logger.LogInformation("InterestReimbursementHandler-Step-3 get a internal batch row numnber is: " + payouts.Count);

                    //no record returns, all rows have been resolved; or has run 100 times
                    if (!payouts.Any() || runTimes > MaxInternalLoop)
                    {
                        Console.WriteLine("#finish InterestReimbursementHandler-finished");
                        _logger.LogInformation("finish InterestReimbursementHandler-finished");
                        break;
                    }

                    var accountKeyList = payouts.Select(p => p.AccountKey).Distinct().ToList();
                    //get customer membership list for current internal batch's customers (membership filter only by account keys)
                    var customerMembershipListForBatch = _necNRTRepository.GetDepositAccountMemberShipAndStatusByLinkedAccountKey(accountKeyList).Result;
                    Console.WriteLine("InterestReimbursementHandler-Step-4 all customers membership row number: " + customerMembershipListForBatch.Count);
                    _logger.LogInformation("InterestReimbursementHandler-Step-4 all customers membership row number: " + customerMembershipListForBatch.Count);

                    var toUpdatedReimbursementList = new List<DepositAccountInterestReimbursePayout>();

                    //one payout may have several memberships.
                    //one membership may have several APY changes.
                    //one membership  APY changes period has several balance changes point
                    foreach (var payout in payouts)
                    {
                        var customerMemberships = customerMembershipListForBatch.Where(c => c.AccountKey == payout.AccountKey).ToList();
                        var balances = await _necNRTRepository.GetDepositAccountBalance(payout.AccountKey, payout.PayoutStartDate.Date, payout.PayoutEndDate.Date);
                        Console.WriteLine("InterestReimbursementHandler-Step-5 get account key :" + payout.AccountKey + " balance row number is " + balances.Count);
                        _logger.LogInformation("InterestReimbursementHandler-Step-5 get account key :" + payout.AccountKey + " balance row number is " + balances.Count);

                        //begin recalculate 1 payout
                        //this method wont have any database connection
                        var payoutAfterRecalculate = recalculatePayout.SingleInterestReimbursement(
                                                    payout,
                                                    membershipMetadata,
                                                    customerMemberships,
                                                    balances);
                        toUpdatedReimbursementList.Add(payoutAfterRecalculate);
                    }

                    //batch update 
                    await _necNRTRepository.UpdateDepositAccountInterestReimbursePayout(toUpdatedReimbursementList);
                    Console.WriteLine("InterestReimbursementHandler-Step-6 update new payout table success");

                    runTimes++;
                }
            }
            catch (Exception ex) { _logger.LogError("InterestReimbursementHandler-error: " + ex.ToString()); }
        }

      

        #region console test code do not delete it
        /// <summary>
        /// just a test
        /// </summary>
        private void TestConnection()
        {
            try
            {
                Console.WriteLine("config batch size is : " + _config.BatchSize) ;
                //test getwatermark  1
                var watermakr = _necNRTRepository.GetHighWaterMark(InterestTablekey);
                Console.WriteLine("#1  Here is a membershipkey from db: " + watermakr.Result);

                //test updatewatermark  2
                _necNRTRepository.UpdateNRTHighWaterMarkByTableNameKey(InterestTablekey, 1000);
                Console.WriteLine("#2  update highwatermark success");

                //test get all membership 3
                var memberships = _necNRTRepository.GetAllMembershipInterestAccrual();
                Console.WriteLine("#3 total membership number is :" + memberships.Result.Count + " Here is a membershipkey from db: " + memberships.Result.First().MembershipKey);

                //test insert new table 4
                //var watermark = _necNRTRepository.InsertDepositAccountInterestReimbursePayoutByBatch(1, _config.BatchSize);
                //Console.WriteLine("#4 Here inserted into new table, returned highwatermark: " + watermark.Result);

                //test get from new table 5
                var smallbatch = _necNRTRepository.GetDepositAccountInterestReimbursePayoutByBatch(InternalBatchSize);
                Console.WriteLine("#5 get small batch : " + smallbatch.Result.Count);

                //get balance  6
                var firstCustomer = smallbatch.Result.First();
                var balance = _necNRTRepository.GetDepositAccountBalance(firstCustomer.AccountKey, firstCustomer.PayoutStartDate, firstCustomer.PayoutEndDate);
                Console.WriteLine("#6 customer'balance list number: " + balance.Result.Count);

                //get customer's membership 7
                var membership = _necNRTRepository.GetDepositAccountMemberShipAndStatusByLinkedAccountKey(new List<int> { firstCustomer.AccountKey });
                Console.WriteLine("#7 customer'membership number: " + membership.Result.Count + "membership key:" + membership.Result.First().MembershipKey);

                //update new table 8
                firstCustomer.DepositAccountInterestReimbursePayoutStatusKey = 3;
                firstCustomer.Description = "just a test";
                firstCustomer.NewInterestAmount = 1;
                firstCustomer.InterestReimburseAmount = 0.5M;
                _necNRTRepository.UpdateDepositAccountInterestReimbursePayout(new List<Model.Interest.DepositAccountInterestReimbursePayout> { firstCustomer });
                Console.WriteLine("#8 update new payout table success");
            }
            catch  (Exception ex) {
                Console.WriteLine(ex.ToString());   
            }
        }
        #endregion
    }
}
