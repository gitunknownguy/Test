﻿using AccountManagement;
using AppSupportProcessor.Business.LegacyApi;
using AppSupportProcessor.Business.Logic;
using AppSupportProcessor.Common.Configuration;
using AppSupportProcessor.Common.Utilities;
using AppSupportProcessor.DataAccess.Repositories;
using AppSupportProcessor.Model.AccountClosure;
using AppSupportProcessor.Model.Consolidation;
using AppSupportProcessor.Model.DO;
using AppSupportProcessor.Model.Enum;
using AppSupportProcessor.Model.LegacyApi;
using Azure.Core;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using NLog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.Handlers
{
    public interface IGenerateAccountClosureFileHandler
    {
        Task ProcessAsync(CancellationToken cancellationToken);
    }

    public class GenerateAccountClosureFileHandler : IGenerateAccountClosureFileHandler
    {
        private ILogger<GenerateAccountClosureFileHandler> _logger;
        private readonly INECNRTRepository _necNRTRepository;
        private readonly INECRepository _necRepository;
        private readonly IIPSRepository _ipsRepository;
        private readonly ICDSRepository _cdsRepository;
        private readonly IAccountClosureFileService _accountClosureFileService;
        private readonly IFundTransferRepository _fundTransferRepository;
        private AccountClosureConfiguration _config;
        private const string HeaderFilePattern = "Header_*";
        private const string writeoffFilePattern = "AccountClosure_WriteOff_*";
        private const string accountClosureFilePattern = "AccountClosure_Close_*";
        private readonly List<string> _declinedCreditRating = new List<string> { "B4", "C5", "P9" };

        public GenerateAccountClosureFileHandler(
           INECNRTRepository nECNRTRepository,
           INECRepository necRepository,
           IIPSRepository ipsRepository,
           ICDSRepository cdsRepository,
           IAccountClosureFileService accountClosureFileService,
           IFundTransferRepository fundTransferRepository,
           ILogger<GenerateAccountClosureFileHandler> logger,
           IOptionsMonitor<AccountClosureConfiguration> config)
        {
            _logger = logger;
            _necNRTRepository = nECNRTRepository;
            _necRepository = necRepository;
            _ipsRepository = ipsRepository;
            _cdsRepository = cdsRepository;
            _config = config.CurrentValue;
            _accountClosureFileService = accountClosureFileService;
            _fundTransferRepository = fundTransferRepository;
        }

        public async Task ProcessAsync(CancellationToken cancellationToken)
        {
            Console.WriteLine("GenerateAccountClosureFileHandler is running.");

            await ProcessFile();

            await ValidateAccountbyRequestType();

            await GenerateACIFile();
        }

        private async Task ProcessFile()
        {
            try
            {
                //1. check folder if file exists
                var files = _accountClosureFileService.GetFiles(_config.LoadAccountClosureFilePath);
                if (files.Count == 0)
                {
                    _logger.LogInformation("No files found in the directory.");
                    return;
                }

                foreach (var file in files)
                {
                    var fileName = Path.GetFileName(file);
                    try
                    {
                        //2. if file existes, use file name to get data from ACIAccountClosureRequest table                        
                        var accountClosureRequest = await _necNRTRepository.GetACIAccountClosureRequestByFileName(fileName);

                        //3. check file type is writeoff or accountclosure
                        var requestType = fileName.Contains("WriteOff", StringComparison.CurrentCultureIgnoreCase) ? "WriteOff" : "AccountClosure";

                        var accountsInFile = _accountClosureFileService.GetFileData(file);

                        //4. if data is not exist, then insert one record into ACIAccountClosureRequest table and set status to 'Processing'
                        if (accountClosureRequest == null)
                        {
                            //generate file name based on data
                            string aciFileName = "";
                            string dataStamps = "Request_" + accountsInFile.Count() + "_" + DateTime.Now.ToString("yyyyMMddHHmmss");
                            if (requestType == "WriteOff")
                            {
                                aciFileName = writeoffFilePattern.Replace("*", dataStamps);
                            }
                            else
                            {
                                aciFileName = accountClosureFilePattern.Replace("*", dataStamps);
                            }

                            accountClosureRequest = new ACIAccountClosureRequest()
                            {
                                RequestFileName = fileName,
                                RequestFilePath = file,
                                ACIAccountClosureRequestStatusKey = (short)AccountClosureRequestStatus.FileImporting,
                                ACIFileName = aciFileName,
                                RequestFileType = requestType,
                                RequestFileProcessDate = DateTime.Now,
                                TotalCount = accountsInFile.Count()
                            };
                            var accountClosureRequestKey = await _necNRTRepository.AddACIAccountClosureRequest(accountClosureRequest);
                            accountClosureRequest.ACIAccountClosureRequestKey = accountClosureRequestKey;
                        }
                        //if data is exist and status is completed, then move file to archive folder
                        else if (accountClosureRequest.ACIAccountClosureRequestStatusKey == (short)AccountClosureRequestStatus.FileImported)
                        {
                            await MoveFileToArchive(file, fileName);
                            _logger.LogInformation($"File already processed: {fileName}");
                            continue;
                        }

                        var batches = Helper.Partition(accountsInFile, _config.BatchSize);
                        foreach (var batch in batches)
                        {
                            var accountkeys = batch.Select(a => a.AccountKey).ToList();
                            var linkedAccounts = await _necRepository.GetAccountLinkInfoByPrimaryAccountKeys(accountkeys);
                            batch.ForEach((a) =>
                            {
                                var linkedAccount = linkedAccounts.FirstOrDefault(l => l.PrimaryAccountKey == a.AccountKey);
                                if (linkedAccount != null)
                                {
                                    a.VaultBalance = linkedAccount.AvailableBalance;
                                }
                                a.ACIAccountClosureRequestKey = accountClosureRequest.ACIAccountClosureRequestKey;
                            });

                            await GetCardProxys(batch);
                            await _necNRTRepository.InsertACIAccountClosureByBatch(batch);
                        }

                        //7. after finish reading file, update ACIAccountClosureRequest table status to 'FileImported' and move file to achive folder
                        accountClosureRequest.ACIAccountClosureRequestStatusKey = (short)AccountClosureRequestStatus.FileImported;
                        await _necNRTRepository.UpdateACIAccountClosureRequestStatus(accountClosureRequest);
                        await MoveFileToArchive(file, fileName);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Error processing file: {FileName} Error", fileName);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GenerateAccountClosureFileHandler error");
            }


        }

        private async Task MoveFileToArchive(string file, string fileName)
        {
            var archivePath = Path.Combine(_config.LoadAccountClosureCompleteFilePath, fileName);
            _accountClosureFileService.MoveFile(file, archivePath);
        }

        private async Task GenerateACIFile()
        {
            try
            {
                //1. get data from ACIAccountClosureRequest table which status is 'Completed'
                var accountClosureRequests = await _necNRTRepository.GetACIAccountClosureRequestByStatus((short)AccountClosureRequestStatus.ValidationCompleted);
                //2. get data from ACIAccountClosure table which belongs to ACIAccountClosureRequestkey and status is valid
                foreach (var request in accountClosureRequests)
                {
                    try
                    {
                        var totalRecords = new List<ACIAccountClosure>();
                        int aciAccountClosureKey = 0;
                        while (true)
                        {
                            var accountClosures = await _necNRTRepository.GetACIAccountClosuresList(request.ACIAccountClosureRequestKey, _config.BatchSize, aciAccountClosureKey, (short)AccountClosureStatus.Egilible);
                            if (accountClosures == null || accountClosures.Count == 0)
                                break;
                            totalRecords.AddRange(accountClosures);
                            aciAccountClosureKey = accountClosures.Select(x => x.ACIAccountClosureKey).Max();
                        }

                        if (totalRecords.Count > 0)
                        {
                            //3. generate file based on data
                            string fileName = "";
                            string headfileName = "";
                            headfileName = HeaderFilePattern.Replace("*", request.ACIFileName);
                            fileName = request.ACIFileName + ".csv";

                            var alterPans = totalRecords.Select(a => a.CardExternalID).ToList();
                            var result = _accountClosureFileService.GenerateFile(alterPans, _config.InputFileToACIFilePath, fileName, headfileName);

                            if (result)
                            {
                                request.ACIAccountClosureRequestStatusKey = (short)AccountClosureRequestStatus.FileSentToACI;
                                await _necNRTRepository.UpdateACIAccountClosureRequestStatus(request);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError($"GenerateACIFile failed for ACIAccountClosureRequestKey: {request.ACIAccountClosureRequestKey}, error: " + ex.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GenerateACIFile error");
            }
        }

        private async Task ValidateAccountbyRequestType()
        {
            try
            {
                var accountClosureRequests = await _necNRTRepository.GetACIAccountClosureRequestByStatus((short)AccountClosureRequestStatus.FileImported);
                if (accountClosureRequests != null)
                {
                    foreach (var request in accountClosureRequests)
                    {
                        if (request.RequestFileType == "AccountClosure")
                        {
                            await ValidateAccountClosure(request.ACIAccountClosureRequestKey);
                        }
                        else
                        {
                            await ValidateWriteOff(request.ACIAccountClosureRequestKey);
                        }

                        request.ACIAccountClosureRequestStatusKey = (short)AccountClosureRequestStatus.ValidationCompleted;
                        await _necNRTRepository.UpdateACIAccountClosureRequestStatus(request);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ValidateAccountbyRequestType error");
            }
        }

        private async Task ValidateAccountClosure(long requestKey)
        {
            try
            {
                int aciAccountClosureKey = 0;
                while (true)
                {
                    var accounts = await _necNRTRepository.GetACIAccountClosuresList(requestKey, _config.BatchSize, aciAccountClosureKey, (short)AccountClosureStatus.Pending);
                    if (accounts.Count == 0)
                        break;
                    aciAccountClosureKey = accounts.Select(x => x.ACIAccountClosureKey).Max();

                    await GetAccountBalance(accounts);

                    //Credit rating status is not  P9/ C5/ B4
                    //Account Balance = 0, Vault balance = 0
                    //COFO-129580: remove condition The first card was activated 13 months ago.
                    var accountkeys = accounts.Select(a => a.AccountKey).ToList();
                    var invalidAccounts = accounts.Where(a => _declinedCreditRating.Contains(a.CreditRatingKey?.Trim()) || a.AvailableBalance != 0 || a.VaultBalance != 0)
                        .Select(a => a.AccountKey).ToList();
                    accountkeys = accountkeys.Where(a => !invalidAccounts.Contains(a)).ToList();

                    //Not exists active secondary family account.
                    var familyAccounts = await _necNRTRepository.GetFamilyAccountInfoByAccountKeys(accountkeys);
                    var familyAccountKeys = familyAccounts.Where(a => !_declinedCreditRating.Contains(a.CreditRatingKey?.Trim())).Select(a => a.PrimaryAccountKey).ToList();
                    invalidAccounts.AddRange(familyAccountKeys);
                    accountkeys = accountkeys.Where(a => !familyAccountKeys.Contains(a)).ToList();

                    if (invalidAccounts.Count > 0)
                    {
                        //Find invalid accounts based on invalid account keys and update status to not eligible
                        var invalidAccountDetails = accounts.Where(a => invalidAccounts.Contains(a.AccountKey)).ToList();
                        invalidAccountDetails.ForEach(a => a.ACIAccountClosureStatusKey = (short)AccountClosureStatus.NotEgilible);
                        await _necNRTRepository.UpdateACIAccountClosureStatusByBatch(invalidAccountDetails, (short)AccountClosureStatus.NotEgilible);

                        accounts = accounts.Where(a => !invalidAccounts.Contains(a.AccountKey)).ToList();
                    }

                    await _necNRTRepository.UpdateACIAccountClosureStatusByBatch(accounts, (short)AccountClosureStatus.Egilible);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ValidateAccountClosure error");
            }
        }
               
        private async Task ValidateWriteOff(long requestKey)
        {
            try
            {
                int aciAccountClosureKey = 0;
                while (true)
                {
                    var accounts = await _necNRTRepository.GetACIAccountClosuresList(requestKey, _config.BatchSize, aciAccountClosureKey, (short)AccountClosureStatus.Pending);
                    if (accounts.Count == 0) break;

                    aciAccountClosureKey = accounts.Max(x => x.ACIAccountClosureKey);
                    await GetAccountBalance(accounts);
                    accounts.ForEach(a => a.ACIAccountClosureStatusKey = (short)AccountClosureStatus.Egilible);

                    var validAccounts = await FilterInvalidAccounts(accounts);
                    await ProcessVaultTransfers(validAccounts);

                    await _necNRTRepository.UpdateACIAccountClosureStatusByBatch(validAccounts);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ValidateWriteOff error");
            }
        }

        private async Task<List<ACIAccountClosure>> FilterInvalidAccounts(List<ACIAccountClosure> accounts)
        {
            var accountKeys = accounts.Select(a => a.AccountKey).ToList();
            var invalidAccounts = accounts
                .Where(a => _declinedCreditRating.Contains(a.CreditRatingKey?.Trim()) || (a.AvailableBalance + a.VaultBalance) > 0)
                .Select(a => a.AccountKey)
                .ToHashSet();

            accountKeys = accountKeys.Where(a => !invalidAccounts.Contains(a)).ToList();

            var familyAccounts = await _necNRTRepository.GetFamilyAccountInfoByAccountKeys(accountKeys);
            var familyAccountKeys = familyAccounts
                .Where(a => !_declinedCreditRating.Contains(a.CreditRatingKey?.Trim()))
                .Select(a => a.PrimaryAccountKey)
                .ToHashSet();

            invalidAccounts.UnionWith(familyAccountKeys);

            var invalidAccountDetails = accounts.Where(a => invalidAccounts.Contains(a.AccountKey)).ToList();

            if (invalidAccountDetails.Count > 0)
            {
                await _necNRTRepository.UpdateACIAccountClosureStatusByBatch(invalidAccountDetails, (short)AccountClosureStatus.NotEgilible);
            }

            return accounts.Where(a => !invalidAccounts.Contains(a.AccountKey)).ToList();
        }

        private async Task ProcessVaultTransfers(List<ACIAccountClosure> validAccounts)
        {
            var vaultAccounts = validAccounts.Where(a => a.VaultBalance > 0).ToList();
            if (!vaultAccounts.Any()) return;

            var vaultAccountKeys = vaultAccounts.Select(a => a.AccountKey).ToList();
            var linkedAccounts = await _necRepository.GetAccountLinkInfoByPrimaryAccountKeys(vaultAccountKeys);

            foreach (var account in vaultAccounts)
            {
                var linkedAccount = linkedAccounts.FirstOrDefault(a => a.PrimaryAccountKey == account.AccountKey);
                if (linkedAccount == null) continue;

                account.VaultBalance = linkedAccount.AvailableBalance;
                if (account.AvailableBalance + account.VaultBalance > 0)
                {
                    account.ACIAccountClosureStatusKey = (short)AccountClosureStatus.NotEgilible;
                    continue;
                }

                if (account.VaultBalance > 0)
                {
                    var request = new Model.LegacyApi.TransferRequest()
                    {
                        ApplicationTypeKey = 7,
                        SystemComponentKey = 25,
                        SysUserKey = 10,
                        TransferInfo = new TransferInfo
                        {
                            Amount = Math.Round(account.VaultBalance, 2),
                            Description = "Transfer Vault Balance",
                            SourceAccountKey = linkedAccount.LinkedAccountKey,
                            TargetAccountKey = account.AccountKey,
                            TransferType = TransferType.SavingsToCard
                        }
                    };

                    try
                    {
                        var result = await _fundTransferRepository.VaultTransfer(request);
                        if (result?.ResponseCode != TransferResponseCode.Success || result?.TransferStatus != TransferStatus.Posted)
                        {
                            account.ACIAccountClosureStatusKey = (short)AccountClosureStatus.VaultTansferFailed;
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Transfer Vault Balance failed for AccountKey: {Accountkey}", account.AccountKey);
                        account.ACIAccountClosureStatusKey = (short)AccountClosureStatus.VaultTansferFailed;
                    }
                }
            }
        }
               
        private async Task GetAccountBalance(List<ACIAccountClosure> accounts)
        {
            var accountReferenceIds = accounts.Select(a => a.AccountReferenceID).ToList();

            var accountkeys = await _ipsRepository.GetAccountKeysByAccountReferenceIDs(accountReferenceIds);
            accounts.ForEach(a => a.PdsAccountKey = accountkeys.FirstOrDefault(k => k.AccountReferenceID == a.AccountReferenceID)?.AccountKey ?? Guid.Empty);

            var accountKeys = accounts.Select(a => a.PdsAccountKey).ToList();

            var purseBalances = await _cdsRepository.GetPurseBalanceByAccountKeys(accountKeys);
            accounts.ForEach(a => a.AvailableBalance = purseBalances.FirstOrDefault(p => p.AccountKey == a.PdsAccountKey)?.LedgerBalance ?? 0);
        }

        private async Task GetCardProxys(List<ACIAccountClosure> accounts)
        {
            var customerKeys = accounts.Select(a => a.CustomerKey).ToList();
            var cardInfo = await _necNRTRepository.GetCardInfoByCustomerkeys(customerKeys);
            accounts.ForEach(a => a.CardReferenceID = cardInfo.FirstOrDefault(c => c.CustomerKey == a.CustomerKey)?.CardReferenceID ?? Guid.Empty);

            var cardReferenceIds = accounts.Select(a => a.CardReferenceID).ToList();
            var cardTransInfo = await _ipsRepository.GetCardExternalIDByCardReferenceIDs(cardReferenceIds);
            accounts.ForEach(a => a.CardExternalID = cardTransInfo.FirstOrDefault(c => c.CardReferenceID == a.CardReferenceID)?.CardExternalID ?? "");
        }
    }
}
