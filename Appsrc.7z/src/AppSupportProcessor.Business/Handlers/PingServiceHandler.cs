﻿using AppSupportProcessor.Business.LegacyApi;
using AppSupportProcessor.DataAccess.Repositories;
using AppSupportProcessor.Model.LegacyApi;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.Handlers
{
    public interface IPingServiceHandler
    {
        Task ProcessAsync(CancellationToken cancellationToken);
    }
    [ExcludeFromCodeCoverage]
    public class PingServiceHandler : IPingServiceHandler
    {

        private ILogger<PingServiceHandler> _logger;
        private readonly INECRepository _necRepository;
        private readonly IIPSRepository _ipsRepository;
        private readonly IMMSDepositAccountRepository _mMSDepositAccountRepository;


        public PingServiceHandler(
            INECRepository necRepository,
            IIPSRepository ipsRepository,
            ILogger<PingServiceHandler> logger,
            IMMSDepositAccountRepository mMSDepositAccountRepository
        )
        {
            _necRepository = necRepository;
            _logger = logger;
            _ipsRepository = ipsRepository;
            _mMSDepositAccountRepository = mMSDepositAccountRepository;
        }

        public async Task ProcessAsync(CancellationToken cancellationToken)
        {
            try
            {
                //var response = await _mMSDepositAccountRepository.Credit(new Model.LegacyApi.DepositAccountCreditRequest
                //{
                //    AccountKey = 7209568,
                //    Amount = 1,
                //    DetailAccountTransactionType = DetailAccountTransactionType.TransferToDepositAccount,
                //    TransactionDescription = "string",
                //    TransactionIdentifier = "string",
                //    IsAllowNegative = true,
                //    SysUserKey = 10,
                //    SystemComponentKey = 16,
                //    ApplicationTypeKey = 1
                //});

                await _ipsRepository.PingTest();
                _logger.LogInformation($"Ping Test IPS Succeed");
            }
            catch (Exception e)
            {
                _logger.LogInformation($"Ping Test IPS Failed Error is {e.StackTrace} {e.Message}");
            }

            try
            {
                await _necRepository.PingTest();
                _logger.LogInformation($"Ping Test NEC Succeed");
            }
            catch (Exception e)
            {
                _logger.LogInformation($"Ping Test NEC Failed Error is {e.StackTrace} {e.Message}");
            }
        }
    }
}