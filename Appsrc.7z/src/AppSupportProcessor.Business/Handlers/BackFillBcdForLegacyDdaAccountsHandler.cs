﻿using AppSupportProcessor.Common.Configuration;
using Microsoft.Extensions.Options;
using System;
using System.Threading;
using System.Threading.Tasks;
using Gd.Logging.Common;
using AppSupportProcessor.DataAccess.Repositories;
using System.Collections.Generic;
using AppSupportProcessor.Model.NRT;
using AppSupportProcessor.DataAccess.DataAccesses.Models;

namespace AppSupportProcessor.Business.Handlers
{
    public interface IBackFillBcdForLegacyDdaAccountsHandler
    {
        Task ProcessAsync(CancellationToken cancellationToken);
        Task ParallellyProcess(List<BillCycleCustomer_Staging> billCycleCustomerInfos);
    }

    public class BackFillBcdForLegacyDdaAccountsHandler : IBackFillBcdForLegacyDdaAccountsHandler
    {
        private IGdLogger<IBackFillBcdForLegacyDdaAccountsHandler> _logger;
        private BackfillBCDForLegacyDDAAccountsConfiguration _config;
        private readonly INECNRTRepository _nEcnrtRepository;
        private readonly INECRepository _necRepository;

        public BackFillBcdForLegacyDdaAccountsHandler(
            INECRepository necRepository,
            INECNRTRepository nEcNrtRepository,
            IGdLogger<IBackFillBcdForLegacyDdaAccountsHandler> logger,
            IOptionsMonitor<BackfillBCDForLegacyDDAAccountsConfiguration> config)
        {
            _necRepository = necRepository;
            _nEcnrtRepository = nEcNrtRepository;
            _logger = logger;
            _config = config.CurrentValue;

        }

        public async Task ProcessAsync(CancellationToken cancellationToken)
        {
            try
            {
                _logger.Info($"BackFillBcdForLegacyDdaAccountsHandler is running. BatchSize: {_config.BatchSize}, Enabled: {_config.Enabled}");

                if (!_config.Enabled)
                {
                    _logger.Info("BackFillBcdForLegacyDdaAccountsHandler aborting because current env is not enabled.");
                    return;
                }

                //Get accountkey/CustomerKey/ActivationDate for NEC_NRT and Back Fill BillCycle
                await BackFillBcdForLegacyDdaAccounts(_config.BatchSize);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "BackFillBcdForLegacyDdaAccountsHandler-error: {message}, {@ex}", ex.Message, ex);
            }
        }

        private async Task BackFillBcdForLegacyDdaAccounts(int batchSize)
        {
            _logger.Info(
                $"BackFillBcdForLegacyDdaAccountsHandler-BackFillBcdForLegacyDdaAccounts is running. BatchSize: {batchSize}");

            var batchStagingData = await _nEcnrtRepository.GetBackFillBillCycleCustomerStaging(batchSize);

            if (batchStagingData == null || batchStagingData.Count == 0)
            {
                _logger.Info(
                    $"BackFillBcdForLegacyDdaAccountsHandler-BackFillBcdForLegacyDdaAccounts: There is no Legacy DdaAccounts need to back fill BCD");
                return;
            }

            await ParallellyProcess(batchStagingData);

        }

        /// <summary>
        /// Parallelly Process with default SemaphoreSlim=25
        /// </summary>
        /// <param name="billCycleCustomerInfos"></param>
        /// <returns></returns>
        public async Task ParallellyProcess(List<BillCycleCustomer_Staging> billCycleCustomerInfos)
        {
            var semaphore = new SemaphoreSlim(25);
            var tasks = new List<Task>();

            foreach (var billCycleCustomerInfo in billCycleCustomerInfos)
            {
                await semaphore.WaitAsync();

                tasks.Add(Task.Run(async () =>
                {
                    try
                    {
                        await ProcessBackFillBcdForLegacyDdaAccounts(billCycleCustomerInfo);
                    }
                    finally
                    {
                        semaphore.Release();
                    }
                }));
            }
            await Task.WhenAll(tasks);
        }

        /// <summary>
        /// Process BackFillBcd For LegacyDda Accounts
        /// </summary>
        /// <param name="billCycleCustomerInfo"></param>
        /// <returns></returns>
        private async Task ProcessBackFillBcdForLegacyDdaAccounts(BillCycleCustomer_Staging billCycleCustomerInfo)
        {
            //Get bill cycle date from BillCycle_Customer and account_billcycle
            var bcd = await _necRepository.GetBillCycleInfoByAccountKey(billCycleCustomerInfo.CustomerKey, billCycleCustomerInfo.AccountKey);

            //If both are null, call SP=MonthlyFee_CreateCustomerBillCycle to do BackFill
            if (bcd == null || (bcd.CustomerBillCycleDay == null && bcd.AccountBillCycleDay == null))
            {
                // call SP=MonthlyFee_CreateCustomerBillCycle to do BackFill
                // Note: The ActivationDate are not null here get from SP=GetBackFillBillCycleCustomerStaging
                await _necRepository.SetAccountCustomerBillCycle(billCycleCustomerInfo.CustomerKey, billCycleCustomerInfo.ActivationDate);
                _logger.Info($"BackFillBcdForLegacyDdaAccountsHandler-BackFillBcdForLegacyDdaAccounts: Done to Call SP=MonthlyFee_CreateCustomerBillCycle to BackFill Account_BillCycle" +
                             $" and BillCycle_Customer for AccountKey={billCycleCustomerInfo.AccountKey},CustomerKey={billCycleCustomerInfo.CustomerKey},ETL_BackFillBillCycleCustomerStagingKey={billCycleCustomerInfo.ETL_BackFillBillCycleCustomerStagingKey}");

            }
            else
            {
                if (bcd.AccountBillCycleDay == null && bcd.CustomerBillCycleDay != null)
                {
                    //Update account_billcycle with the bill cycle date from BillCycle_Customer
                    await _necRepository.SetAccountBillCycle(billCycleCustomerInfo.AccountKey, bcd.CustomerBillCycleDay.Value, bcd.CustomerFirstBillCycleDate);
                    _logger.Info($"BackFillBcdForLegacyDdaAccountsHandler-BackFillBcdForLegacyDdaAccounts: Done to BackFill Account_BillCycle with the bill cycle date from BillCycle_Customer for AccountKey={billCycleCustomerInfo.AccountKey}," +
                                 $"CustomerKey={billCycleCustomerInfo.CustomerKey},ETL_BackFillBillCycleCustomerStagingKey={billCycleCustomerInfo.ETL_BackFillBillCycleCustomerStagingKey}");
                }
            }

            // update the IsProcessed to true
            await _nEcnrtRepository.UpdateBackFillBillCycleCustomerStagingStatus(billCycleCustomerInfo.ETL_BackFillBillCycleCustomerStagingKey);
            _logger.Info($"BackFillBcdForLegacyDdaAccountsHandler-BackFillBcdForLegacyDdaAccounts: Done to Update BackFillBillCycleCustomerStaging Status for ETL_BackFillBillCycleCustomerStagingKey={billCycleCustomerInfo.ETL_BackFillBillCycleCustomerStagingKey}");
        }

    }
}
