﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using AppSupportProcessor.Business.Logic;
using AppSupportProcessor.Common.Configuration;
using AppSupportProcessor.DataAccess.Repositories;
using AppSupportProcessor.Model.AccountClosure;
using AppSupportProcessor.Model.Enum;
using Azure.Core.GeoJson;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace AppSupportProcessor.Business.Handlers
{
    public interface IHandbackAccountClosureFileHandler
    {
        Task ProcessAsync(CancellationToken cancellationToken);
    }

    public class HandbackAccountClosureFileHandler : IHandbackAccountClosureFileHandler
    {
        private ILogger<HandbackAccountClosureFileHandler> _logger;
        private readonly INECNRTRepository _necNRTRepository;
        private readonly INECRepository _necRepository;
        private readonly IAccountClosureFileService _accountClosureFileService;
        private AccountClosureConfiguration _config;
        private const string AccountClosureFilePattern = "AccountClosure_*";
        private const string ReportFileExtension= "_report";
        private const string RejectFileExtension = "_reject";
        private const string CreditRatingAccountClosure = "C5";
        private const string CreditRatingWriteOff = "B4";
        private const string SysUserFullName = "AccountClosure";

        private const string NotesWriteOff =
            "B4 added due to a Negative Balance Expiration Write Off. Please direct any questions concerning an associated account to the Financial Processing Operations distribution (FinProcOps-ProdIssue)";
        private const string NotesAccountClosure =
            "Account Closure - This account has been closed due to inactivity. The customer can open a new account.";


        public HandbackAccountClosureFileHandler(
            INECNRTRepository nECNRTRepository,
            INECRepository necRepository,
            IAccountClosureFileService accountClosureFileService,
            ILogger<HandbackAccountClosureFileHandler> logger,
            IOptionsMonitor<AccountClosureConfiguration> config)
        {
            _logger = logger;
            _necNRTRepository = nECNRTRepository;
            _necRepository= necRepository;
            _config = config.CurrentValue;
            _accountClosureFileService = accountClosureFileService;
        }

        public async Task ProcessAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("HandbackAccountClosureFileHandler Starting.");
            await ProcessReportFile();
            await ProcessRejectFile();
            _logger.LogInformation("HandbackAccountClosureFileHandler Completed.");
        }

        public async Task ProcessReportFile()
        {
            _logger.LogInformation("ProcessReportFile Starting.");
            //1. check folder if report file exists
            var files = _accountClosureFileService.GetFiles(_config.LoadAccountClosureFilePath,
                AccountClosureFilePattern+ReportFileExtension);
            if (files==null ||files.Count == 0)
            {
                _logger.LogInformation("No report files found in the directory.");
                return;
            }

            foreach (var file in files)
            {
                var fileName = Path.GetFileName(file);
                var requestFileName = fileName.Replace(ReportFileExtension, "");
                try
                {
                    //2. if file exists, use file name to get data from ACIAccountClosureRequest table
                    var request = await _necNRTRepository.GetACIAccountClosureRequestByACIFileName(requestFileName);
                    if (request == null)
                    {
                        _logger.LogWarning($"No record found for file {fileName} in ACIAccountClosureRequest table.");
                        continue;
                    }

                    //3. If  report file response exists, update ACIAccountClosureResponse table with file status
                    var response = await _necNRTRepository.GetACIAccountClosureResponseByFileName(fileName);
                 
                    //4. Get report file details, update ACIAccountClosure table,update credit rating to C5/B4
                    List<ReportFileDetail> toCLoseAccounts = new List<ReportFileDetail>();
                    List<ReportFileDetail> toWriteoffAccounts = new List<ReportFileDetail>();

                    var lines = _accountClosureFileService.GetAllLines(file); 
                    if (lines == null || lines.Count() < 2)
                    {
                        _logger.LogError($"Invalid row found in file {file}.");
                        continue;
                    }
                    if (response == null)
                    {
                        response = new ACIAccountClosureResponse()
                        {
                            ACIAccountClosureRequestKey = request.ACIAccountClosureRequestKey,
                            ResponseFileName = fileName,
                            ResponseFilePath = file,
                            ResponseFileProcessDate = DateTime.Now,
                            TotalCount = lines.Count()-4
                        };
                        await _necNRTRepository.AddACIAccountClosureResponse(response);
                    }
                    foreach (var line in lines)
                    {
                        var columns = line.Split(',');

                        if (columns[0].Trim() != "D")
                        {
                            _logger.LogInformation($"Skip file summary Row: {line}");
                            continue;
                        }
                        
                        if (columns.Length != 4
                            || !decimal.TryParse(columns[3].Trim(), out var writeoffAmount))
                        {
                            _logger.LogWarning($"Invalid row found in file {file}. Row: {line}");
                            continue;
                        }


                        ReportFileDetail reportFileDetail = new ReportFileDetail()
                        {
                            CardExternalID = columns[1].Trim(),
                            AciAccountExternalId = columns[2].Trim(),
                            WriteOffAmount = writeoffAmount,
                            ResponseCode = "0",
                            ResponseMessage = $"Account closure transaction amount {writeoffAmount}"
                            
                        };
                        if (writeoffAmount > 0)
                        {
                            toWriteoffAccounts.Add(reportFileDetail);
                        }
                        else
                        {
                            toCLoseAccounts.Add(reportFileDetail);
                        }


                        if (toWriteoffAccounts.Count >= _config.BatchSize)
                        {
                            await UpdateCreditRatingForWriteOff(request.ACIAccountClosureRequestKey, response.ACIAccountClosureResponseKey,
                                toWriteoffAccounts);
                            toWriteoffAccounts.Clear();
                        }
                        if (toCLoseAccounts.Count >= _config.BatchSize)
                        {
                            await UpdateCreditRatingForAccountClosure(request.ACIAccountClosureRequestKey, response.ACIAccountClosureResponseKey,
                                toCLoseAccounts);
                            toCLoseAccounts.Clear();
                        }
                    }

                    if (toWriteoffAccounts.Count > 0)
                    {
                        await UpdateCreditRatingForWriteOff(request.ACIAccountClosureRequestKey, response.ACIAccountClosureResponseKey,
                            toWriteoffAccounts);
                        toWriteoffAccounts.Clear();
                    }
                    if (toCLoseAccounts.Count > 0)
                    {
                        await UpdateCreditRatingForAccountClosure(request.ACIAccountClosureRequestKey, response.ACIAccountClosureResponseKey,
                            toCLoseAccounts);
                        toCLoseAccounts.Clear();
                    }

                    //5. Update ACIAccountClosureRequest status
                    request.ACIAccountClosureRequestStatusKey = (short)AccountClosureRequestStatus.RecievedACIReportFile;
                    await _necNRTRepository.UpdateACIAccountClosureRequestStatus(request);
                    //6. Move file to complete folder
                    if (!Directory.Exists(_config.LoadAccountClosureCompleteFilePath))
                    {
                        Directory.CreateDirectory(_config.LoadAccountClosureCompleteFilePath);
                    }

                    _accountClosureFileService.MoveFile(file,Path.Combine(_config.LoadAccountClosureCompleteFilePath,fileName));
                }
                catch (Exception ex)
                {
                    _logger.LogError($"Failed to process file {fileName}, see error details {ex}");
                }
            }
        }

        public async Task ProcessRejectFile()
        {
            _logger.LogInformation("ProcessRejectFile Starting.");
            //1. check folder if report file exists
            var files = _accountClosureFileService.GetFiles(_config.LoadAccountClosureFilePath,
                AccountClosureFilePattern + RejectFileExtension);
            if (files==null || files.Count == 0)
            {
                _logger.LogInformation("No reject files found in the directory.");
                return;
            }

            foreach (var file in files)
            {
                var fileName = Path.GetFileName(file);
                var requestFileName = fileName.Replace(RejectFileExtension, "");
                try
                {
                    //2. if file exists, use file name to get data from ACIAccountClosureRequest table
                    var request = await _necNRTRepository.GetACIAccountClosureRequestByACIFileName(requestFileName);
                    if (request == null)
                    {
                        _logger.LogWarning($"No record found for file {fileName} in ACIAccountClosureRequest table.");
                        continue;
                    }

                    //3. If  report file response exists, update ACIAccountClosureResponse table with file status
                    var response = await _necNRTRepository.GetACIAccountClosureResponseByFileName(fileName);

                    //4. Get report file details, update ACIAccountClosure table with reject message
                    List<ReportFileDetail> rejectAccounts = new List<ReportFileDetail>();

                    var lines = _accountClosureFileService.GetAllLines(file);
                    if (lines == null || lines.Count() < 2)
                    {
                        _logger.LogError($"Invalid row found in file {file}.");
                        continue;
                    }
                    if (response == null)
                    {
                        response = new ACIAccountClosureResponse()
                        {
                            ACIAccountClosureRequestKey = request.ACIAccountClosureRequestKey,
                            ResponseFileName = fileName,
                            ResponseFilePath = file,
                            ResponseFileProcessDate = DateTime.Now,
                            TotalCount = lines.Count() - 2
                        };
                        var responseKey=await _necNRTRepository.AddACIAccountClosureResponse(response);
                        response.ACIAccountClosureResponseKey=responseKey;
                    }
                    foreach (var line in lines.Skip(2))
                    {
                        var columns = line.Split(',');
                        
                        if (columns.Length< 3)
                        {
                            _logger.LogWarning($"Invalid row found in file {file}. Row: {line}");
                            continue;
                        }


                        ReportFileDetail reportFileDetail = new ReportFileDetail()
                        {
                            CardExternalID = columns[0].Trim(),
                            ResponseCode = columns[1].Trim(),
                            ResponseMessage = columns[2].Trim()

                        };
                        rejectAccounts.Add(reportFileDetail);

                        if (rejectAccounts.Count >= _config.BatchSize)
                        {
                            await UpdateCreditRatingForReject(request.ACIAccountClosureRequestKey,response.ACIAccountClosureResponseKey,
                                rejectAccounts);
                            rejectAccounts.Clear();
                        }
                    }

                    if (rejectAccounts.Count > 0)
                    {
                        await UpdateCreditRatingForReject(request.ACIAccountClosureRequestKey, response.ACIAccountClosureResponseKey,
                            rejectAccounts);
                        rejectAccounts.Clear();
                    }

                    //5. Update ACIAccountClosureRequest status
                    //accountClosureRequest.ACIAccountClosureRequestStatusKey = (short)AccountClosureRequestStatus.RecievedACIReportFile;
                    //await _necNRTRepository.UpdateACIAccountClosureRequestStatus(accountClosureRequest);
                    //6. Move file to complete folder

                    _accountClosureFileService.MoveFile(file, Path.Combine(_config.LoadAccountClosureCompleteFilePath, fileName));
                }
                catch (Exception ex)
                {
                    _logger.LogError($"Failed to process file {fileName}, see error details {ex}");
                }
            }
        }

        private async Task UpdateCreditRatingForAccountClosure(long accountClosureRequestKey,long accountClosureResponseKey, List<ReportFileDetail> list)
        {
            var accountCloseList = await _necNRTRepository.GetACIAccountClosureByCardExternalID(accountClosureRequestKey, list.Select(it => it.CardExternalID).ToList());
            accountCloseList.ForEach(it =>
            {
                var account = list.FirstOrDefault(l => l.CardExternalID.Equals(it.CardExternalID.Trim()));
                it.ACIAccountClosureResponseKey = accountClosureResponseKey;
                it.ResponseCode = account?.ResponseCode;
                it.ResponseMessage = account?.ResponseMessage;
            });
            await _necNRTRepository.UpdateACIAccountClosureStatusByBatch(accountCloseList, (short)AccountClosureStatus.Closed);
            await _necRepository.InsertACIAccountClosureProcessBatch(
                accountCloseList.Select(it => it.CustomerKey).ToList(), CreditRatingAccountClosure,
                NotesAccountClosure, SysUserFullName);
            _logger.LogInformation($"Account closure information, report rows {list.Count}, update DB rows {accountCloseList.Count}.");
        }
        private async Task UpdateCreditRatingForWriteOff(long accountClosureRequestKey, long accountClosureResponseKey, List<ReportFileDetail> list)
        {
            var accountCloseList = await _necNRTRepository.GetACIAccountClosureByCardExternalID(accountClosureRequestKey, list.Select(it => it.CardExternalID).ToList()); 
            accountCloseList.ForEach(it =>
            {
                var account = list.FirstOrDefault(l => l.CardExternalID.Equals(it.CardExternalID.Trim()));
                it.ACIAccountClosureResponseKey = accountClosureResponseKey;
                it.ResponseCode = account?.ResponseCode;
                it.ResponseMessage = account?.ResponseMessage;
            });
            await _necNRTRepository.UpdateACIAccountClosureStatusByBatch(accountCloseList, (short)AccountClosureStatus.WriteOff);
            await _necRepository.InsertACIWriteOffProcessBatch(
                accountCloseList.Select(it => it.CustomerKey).ToList(), CreditRatingWriteOff,
                NotesWriteOff, SysUserFullName);

            _logger.LogInformation($"WriteOff information, report rows {list.Count}, update DB rows {accountCloseList.Count}.");
        }

        private async Task UpdateCreditRatingForReject(long accountClosureRequestKey, long accountClosureResponseKey, List<ReportFileDetail> list)
        {
            var accountCloseList = await _necNRTRepository.GetACIAccountClosureByCardExternalID(accountClosureRequestKey, list.Select(it => it.CardExternalID).ToList()); 
            accountCloseList.ForEach(it =>
            {
                var account = list.FirstOrDefault(l => l.CardExternalID.Equals(it.CardExternalID.Trim()));
                it.ACIAccountClosureResponseKey = accountClosureResponseKey;
                it.ResponseCode = account?.ResponseCode;
                it.ResponseMessage = account?.ResponseMessage;
            });
            await _necNRTRepository.UpdateACIAccountClosureStatusByBatch(accountCloseList, (short)AccountClosureStatus.Failed);
            _logger.LogInformation($"Reject information, report rows {list.Count}, update DB rows {accountCloseList.Count}.");
        }
    }
}