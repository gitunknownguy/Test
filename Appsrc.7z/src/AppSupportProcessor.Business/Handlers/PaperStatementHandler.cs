﻿using AppSupportProcessor.Common.Configuration;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AppSupportProcessor.DataAccess.DataAccesses;
using AppSupportProcessor.DataAccess.DataAccesses.Models;
using Gd.Logging.Common;
using AppSupportProcessor.Model.Consolidation;
using AppSupportProcessor.Business.Logic;

namespace AppSupportProcessor.Business.Handlers
{
    public interface IPaperStatementHandler
    {
        Task ProcessAsync(CancellationToken cancellationToken);
        Task BatchProcessPaperStatement(DateTime billCycleDate, PaperStatementStagingPkRange pkRange);
        Task GeneratePaperStatementsWithTransactions(List<PaperStatementStagingInfo> stagingInfosWithTrans);
        Task GeneratePaperStatementsWithoutTransaction(List<PaperStatementStagingInfo> stagingInfosWithoutTrans);

        Task GetTransactionCountInLast2BillCycleDate(DateTime billCycleDate,
            List<PaperStatementStagingInfo> stagingInfosWithoutTrans);

        Task GetTransactionCount(DateTime billCycleDate, List<PaperStatementStagingInfo> paperStatementStagingInfos);
    }

    public class PaperStatementHandler : IPaperStatementHandler
    {
        private IGdLogger<PaperStatementHandler> _logger;
        private PaperStatementConfiguration _config;
        private readonly INecDataAccess _necDataAccess;
        private readonly INrtDataAccess _nrtDataAccess;
        private readonly IReportDataAccess _reportDataAccess;
        private readonly IExcludeTestAccountService _excludeTestAccountService;


        public PaperStatementHandler(
            INecDataAccess necDataAccess,
            INrtDataAccess nrtDataAccess,
            IReportDataAccess reportDataAccess,
            IGdLogger<PaperStatementHandler> logger,
            IOptionsMonitor<PaperStatementConfiguration> config,
            IExcludeTestAccountService excludeTestAccountService)
        {
            _necDataAccess = necDataAccess;
            _nrtDataAccess = nrtDataAccess;
            _reportDataAccess = reportDataAccess;
            _logger = logger;
            _config = config.CurrentValue;
            _excludeTestAccountService = excludeTestAccountService;
        }

        public async Task ProcessAsync(CancellationToken cancellationToken)
        {
            try
            {
                if (!_config.Enabled)
                {
                    _logger.Info("PaperStatementHandler aborting because current env is not enabled.");
                    return;
                }

                _logger.Info($"PaperStatementHandler is running. BatchSize: {_config.BatchSize}");
                DateTime runDate = DateTime.Today;
                bool isHoliday = await IsHoliday(runDate);
                if (isHoliday)
                {
                    _logger.Info("PaperStatementHandler aborting because runDate {rundate} is a bank holiday", runDate.ToString("yyyy-MM-dd"));
                    return;
                }

                List<DateTime> billCycleDates = await GetBillCycleDates(runDate);
                if (billCycleDates.Count == 0)
                {
                    _logger.Info("PaperStatementHandler aborting because cannot get any valid bill cycle dates by this run date: {rundate}", runDate.ToString("yyyy-MM-dd"));
                    return;
                }
                _logger.Info("PaperStatementHandler get the target BillCycleDates: {billCycleDates}", string.Join(",", billCycleDates.Select(i => i.ToString("yyyy-MM-dd"))));
                foreach (var billCycleDate in billCycleDates)
                {
                    await _reportDataAccess.TruncatePaperStatementStaging();
                    await _reportDataAccess.InsertPaperStatementStaging(billCycleDate);
                    var pkRange = await _reportDataAccess.GetPaperStatementStagingPkRange();
                    await BatchProcessPaperStatement(billCycleDate, pkRange);
                }
            }
            catch (Exception ex)
            {
                _logger.Info(ex, "PaperStatementHandler-error: {message}, {@ex}", ex.Message, ex);
            }
        }

        public async Task BatchProcessPaperStatement(DateTime billCycleDate, PaperStatementStagingPkRange pkRange)
        { 
            long minKey = pkRange.MinPaperStatementStagingKey ?? 0;
            long maxKey = pkRange.MaxPaperStatementStagingKey ?? 0;

            _logger.Info("Start BatchProcessPaperStatement {minKey}, {maxKey}, {count}", minKey, maxKey, maxKey - minKey + 1);

            if (minKey == 0 || maxKey == 0)
            {   
                _logger.Info("PaperStatementHandler aborting because PaperStatementStaging has no data.");
                return;
            }

            long sum = maxKey - minKey + 1;
            int batchSize = _config.BatchSize;
            int batchCount = (int)Math.Ceiling((decimal)sum / batchSize);
            for (int i = 0; i < batchCount; i++)
            {
                long start = i * batchSize + minKey;
                long end = start + batchSize - 1;
                if (end > maxKey)
                {
                    end = maxKey;
                }

                var paperStatementStagingInfos = await _reportDataAccess.GetPaperStatementStagingByBatch(start, end);

                await _excludeTestAccountService.RemoveAllTestAccountPaperStatement(paperStatementStagingInfos);

                await GetTransactionCount(billCycleDate, paperStatementStagingInfos);

                var stagingInfosWithTrans = paperStatementStagingInfos.FindAll(o => o.TransactionCount != 0);
                await GeneratePaperStatementsWithTransactions(stagingInfosWithTrans);

                var stagingInfosWithoutTrans = paperStatementStagingInfos.FindAll(o => o.TransactionCount == 0);
                await GetTransactionCountInLast2BillCycleDate(billCycleDate, stagingInfosWithoutTrans);
                await GeneratePaperStatementsWithoutTransaction(stagingInfosWithoutTrans);
            }
        }

        public async Task GeneratePaperStatementsWithTransactions(List<PaperStatementStagingInfo> stagingInfosWithTrans)
        {
            var paperStatementInfos = stagingInfosWithTrans.Select(o => new PaperStatementInfo()
            {
                AccountKey = o.AccountKey,
                PaperStatementIdentifier = Guid.NewGuid().ToString().Replace("-",""),
                BillCycleDate = o.BillCycleDate,
                BillCycleDay = o.BillCycleDay,
                CreditRatingKey = o.CreditRatingKey,
                TransactionCount = o.TransactionCount,
                RetryCount = 0,
                PortfolioKey = o.PortfolioKey,
                PaperStatementStatusKey = (short)PaperStatementStatus.Pending,
            }).ToList();
            await _reportDataAccess.InsertPaperStatement(paperStatementInfos);
        }

        public async Task GeneratePaperStatementsWithoutTransaction(List<PaperStatementStagingInfo> stagingInfosWithoutTrans)
        {
            var paperStatementInfosWithoutTrans = stagingInfosWithoutTrans.Select(o => new PaperStatementInfo()
            {
                AccountKey = o.AccountKey,
                PaperStatementIdentifier = Guid.NewGuid().ToString().Replace("-", ""),
                BillCycleDate = o.BillCycleDate,
                BillCycleDay = o.BillCycleDay,
                CreditRatingKey = o.CreditRatingKey,
                TransactionCount = o.TransactionCount,
                RetryCount = 0,
                PortfolioKey = o.PortfolioKey,
                PaperStatementStatusKey = (short)(o.BCD1TransactionCount == 0 
                                                  && o.BCD1PaperStatementStatusKey == (short)PaperStatementStatus.Ignored
                                                  && o.BCD2TransactionCount == 0 
                                                  && o.BCD2PaperStatementStatusKey == (short)PaperStatementStatus.Ignored
                    ? PaperStatementStatus.Pending
                    : PaperStatementStatus.Ignored)
            }).ToList();
            await _reportDataAccess.InsertPaperStatement(paperStatementInfosWithoutTrans);
        }

        public async Task GetTransactionCountInLast2BillCycleDate(DateTime billCycleDate,
            List<PaperStatementStagingInfo> stagingInfosWithoutTrans)
        {
            DateTime billCycleDate1 = billCycleDate.AddMonths(-1);
            DateTime billCycleDate2 = billCycleDate.AddMonths(-2);

            List<PaperStatementInfo> accountKeyBillCycleDates = new List<PaperStatementInfo>();
            
            foreach (var stagingInfo in stagingInfosWithoutTrans)
            {
                var item1 = new PaperStatementInfo()
                {
                    AccountKey = stagingInfo.AccountKey,
                    BillCycleDate = billCycleDate1
                };
                var item2 = new PaperStatementInfo()
                {
                    AccountKey = stagingInfo.AccountKey,
                    BillCycleDate = billCycleDate2
                };
                accountKeyBillCycleDates.Add(item1);
                accountKeyBillCycleDates.Add(item2);
            }

            var accountHistoryTransCount =
                await _reportDataAccess.GetPaperStatementTransactionCount(accountKeyBillCycleDates);
            foreach (var stagingInfo in stagingInfosWithoutTrans)
            {
                var accountTransCount1 = accountHistoryTransCount.Find(o => o.AccountKey == stagingInfo.AccountKey && o.BillCycleDate == billCycleDate1);
                if (accountTransCount1 != null)
                {
                    stagingInfo.BCD1TransactionCount = accountTransCount1.TransactionCount;
                    stagingInfo.BCD1PaperStatementStatusKey = accountTransCount1.PaperStatementStatusKey;
                }

                var accountTransCount2 = accountHistoryTransCount.Find(o => o.AccountKey == stagingInfo.AccountKey && o.BillCycleDate == billCycleDate2);
                if (accountTransCount2 != null)
                {
                    stagingInfo.BCD2TransactionCount = accountTransCount2.TransactionCount;
                    stagingInfo.BCD2PaperStatementStatusKey = accountTransCount2.PaperStatementStatusKey;
                }
            }
        }

        public async Task GetTransactionCount(DateTime billCycleDate, List<PaperStatementStagingInfo> paperStatementStagingInfos)
        {
            DateTime startDate = billCycleDate.AddMonths(-1);
            DateTime endDate = billCycleDate;

            List<AccountKeyInfo> infos = paperStatementStagingInfos.Select(o => new AccountKeyInfo()
            {
                AccountKey = o.AccountKey
            }).Distinct().ToList();
            var accountAndTransCount = await _nrtDataAccess.GetTransDtlCountByAccountKeyAndDate(startDate, endDate, infos);
            foreach (var stagingInfo in paperStatementStagingInfos)
            {
                var accountTransCount = accountAndTransCount.Find(o => o.AccountKey == stagingInfo.AccountKey);
                if (accountTransCount != null)
                {
                    stagingInfo.TransactionCount = accountTransCount.TransactionCount ?? 0;
                }
            }
        }


        private async Task<bool> IsHoliday(DateTime dt)
        {
            if (dt.DayOfWeek == DayOfWeek.Saturday || dt.DayOfWeek == DayOfWeek.Sunday)
            {
                return true;
            }
            bool isBankHoliday = await _necDataAccess.IsBankHoliday(dt);
            if (isBankHoliday)
            {
                return true;
            }
            return false;
        }
        private async Task<List<DateTime>> GetBillCycleDates(DateTime startDate)
        {
            // e.g., today is 9/25; if we select people whose bill cycle starts on 9/22
            List<DateTime> ret = new List<DateTime>();
            int i = 0;
            int offsetDays = 3;
            while (i < offsetDays)
            {
                startDate = startDate.AddDays(-1);
                bool isHoliday = await IsHoliday(startDate);
                if (isHoliday)
                    continue;
                i += 1;
            }
            ret.Add(startDate);
            // have to check if the day before was a holiday; if so, it has to be included also
            var daysBeforeBCD = startDate.AddDays(-1);
            while (await IsHoliday(daysBeforeBCD))
            {
                ret.Add(daysBeforeBCD);
                daysBeforeBCD = daysBeforeBCD.AddDays(-1);
            }
            ret.RemoveAll(item => item.Day > 28);
            if (ret.Count > 1)
            {
                ret.Sort();
            }
            return ret;
        }
    }
}
