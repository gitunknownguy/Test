﻿using AppSupportProcessor.Common.Configuration;
using AppSupportProcessor.DataAccess.Repositories;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.Handlers
{
    public interface IInitializeCardTranslationInventoryExceptionRecoveryHandler
    {
        Task ProcessAsync(CancellationToken cancellationToken);
    }

    public class InitializeCardTranslationInventoryExceptionRecoveryHandler : IInitializeCardTranslationInventoryExceptionRecoveryHandler
    {
        private ILogger<InitializeCardTranslationInventoryExceptionRecoveryHandler> _logger;
        private InitializeCardTranslationInventoryExceptionRecoveryConfiguration _config;
        private readonly INECRepository _necRepository;
        private readonly IIPSRepository _ipsRepository;

        public InitializeCardTranslationInventoryExceptionRecoveryHandler(
            INECRepository necRepository,
            IIPSRepository ipsRepository,
            ILogger<InitializeCardTranslationInventoryExceptionRecoveryHandler> logger,
            IOptionsMonitor<InitializeCardTranslationInventoryExceptionRecoveryConfiguration> config)
        {
            _necRepository = necRepository;
            _logger = logger;
            _config = config.CurrentValue;
            _ipsRepository = ipsRepository;

        }
        public async Task ProcessAsync(CancellationToken cancellationToken)
        {
            var insertedRows = await _ipsRepository.InsertETLCardTranslationInventoryException( _config.TimeWindow);

            _logger.LogInformation($"InitializeCardTranslationInventoryExceptionRecoveryHandler completed. InsertedRows is {insertedRows}");
        }
    }
}

