﻿using AgreementService;
using AppSupportProcessor.Business.Activity;
using AppSupportProcessor.Business.LegacyApi;
using AppSupportProcessor.Common.Configuration;
using AppSupportProcessor.DataAccess.Repositories;
using AppSupportProcessor.Model.Consolidation;
using AppSupportProcessor.Model.DO;
using AppSupportProcessor.Model.Enum;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.Handlers
{
    public interface IInitialActivityHandler
    {
        Task ProcessAsync(CancellationToken cancellationToken);
    }

    public class InitialActivityHandler : IInitialActivityHandler
    {
        private ILogger<InitialActivityHandler> _logger;
        private readonly INECNRTRepository _necNRTRepository;
        private readonly INECRepository _necRepository;
        private ConsolidationConfiguration _config;
        private ICache _cache;
        private const string checkingBinType = "checking";
        public InitialActivityHandler(
           INECNRTRepository nECNRTRepository,
           INECRepository nECRepository,
           ILogger<InitialActivityHandler> logger,
           IOptionsMonitor<ConsolidationConfiguration> config,
           ICache cache)
        {
            _logger = logger;
            _necNRTRepository = nECNRTRepository;
            _necRepository = nECRepository;
            _config = config.CurrentValue;
            _cache = cache;
        }

        public async Task ProcessAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("InitialActivityHandler is running.");
            try
            {

                var productMappingList = _cache.GetData<List<ConsolidationProductMapping>>("AppSupport_ConsolidationProductMapping");
                if (productMappingList == null || productMappingList.Count == 0)
                {
                    productMappingList = await _necNRTRepository.GetAllConsolidationProductMappingAsync();
                    _cache.InsertData("AppSupport_ConsolidationProductMapping", productMappingList, TimeSpan.FromDays(1));
                }

                var productKeys = productMappingList.Where(p => p.EffectiveDate != null && p.EffectiveDate < DateTime.Now && p.ExpirationDate != null && p.ExpirationDate > DateTime.Now).Select(p => p.SourceProductKey).Distinct().ToList(); 
                await EiligibilityCheck(productKeys);

                foreach (var productMapping in productMappingList)
                {
                    if (productMapping.EffectiveDate != null && productMapping.EffectiveDate < DateTime.Now && productMapping.ExpirationDate != null && productMapping.ExpirationDate > DateTime.Now)
                    {
                        var accounts = await _necNRTRepository.GetConsolidationAccountAsync((short)ConsolidationStatus.Eligible, new List<short>() { productMapping.SourceProductKey }, _config.InitActivityBatchSize);

                        //add consolidation activity
                        foreach (var account in accounts)
                        {
                            try
                            {
                                var activities = await AddConsolidationActivity(account);
                                await _necNRTRepository.InsertConsolidationActivitiesAsync(account.ConsolidationAccountKey, activities);
                                await _necNRTRepository.UpdateConsolidationStatusAsync(account.ConsolidationAccountKey, (short)ConsolidationStatus.Eligible, (short)ConsolidationStatus.Initiated);
                            }
                            catch (Exception ex)
                            {
                                _logger.LogError("AddConsolidationActivity error: " + ex.ToString());
                                await _necNRTRepository.UpdateConsolidationStatusAsync(account.ConsolidationAccountKey, (short)ConsolidationStatus.Eligible, (short)ConsolidationStatus.NotEligible);
                            }
                        }
                    }
                }
                

            }
            catch (Exception ex)
            {
                _logger.LogError("InitialActivityHandlerror: " + ex.ToString());
            }
        }

        protected async Task EiligibilityCheck(List<short> productKeys)
        {
            var accounts = await _necNRTRepository.GetConsolidationAccountAsync((short)ConsolidationStatus.Pending, productKeys, _config.EiligibilityCheckBatchSize);
            var eligibleAccounts = accounts;

            if (eligibleAccounts.Count > 0)
            {
                eligibleAccounts.ForEach(a => a.ConsolidationStatusKey = (short)ConsolidationStatus.Eligible);

                var accountkeys = accounts.Select(a => a.AccountKey).ToList();
                var customerKeys = accounts.Select(a => a.CustomerKey).ToList();
                var accountDetails = await _necRepository.GetCustomerCreditRatingkeyByAccountKeys(accountkeys);
                var accountDetailsByCustomer = accountDetails.Where(a => customerKeys.Contains(a.CustomerKey)).ToList();

                var invalidAccounts = accountDetailsByCustomer.Where(a => a.CreditRatingKey == "C5" || a.CreditRatingKey == "B4").Select(a => a.Accountkey).ToList();

                if (invalidAccounts.Count > 0)
                {
                    //Find invalid accounts based on invalid account keys and update status to not eligible
                    var invalidAccountDetails = accounts.Where(a => invalidAccounts.Contains(a.AccountKey)).ToList();
                    invalidAccountDetails.ForEach(a => a.ConsolidationStatusKey = (short)ConsolidationStatus.NotEligible);
                    await _necNRTRepository.UpdateConsolidationAccountsStatusByBatch(invalidAccountDetails, ConsolidationStatus.Pending);
                }

                //Find valid accounts based on invalid account keys
                var validAccountDetails = invalidAccounts.Count > 0? accounts.Where(a => !invalidAccounts.Contains(a.AccountKey)).ToList() : accounts;
                if (validAccountDetails.Count > 0)
                {
                    //check membershiptype if account is NPNR
                    var customerMembershipDetails = await _necRepository.GetCustomerMembershipByCustomerKeys(validAccountDetails.Select(a => a.CustomerKey).ToList());
                    var npnrCustomers = customerMembershipDetails.Where(a => a.MembershipTypeKey == 9).Select(c => c.CustomerKey).ToList();
                    if (npnrCustomers.Count > 0)
                    {
                        var npnrAccountsDetails = accounts.Where(a => npnrCustomers.Contains(a.CustomerKey)).ToList();
                        npnrAccountsDetails.ForEach(a => a.ConsolidationStatusKey = (short)ConsolidationStatus.NotEligible);
                        await _necNRTRepository.UpdateConsolidationAccountsStatusByBatch(npnrAccountsDetails, ConsolidationStatus.Pending);
                    }

                    eligibleAccounts = npnrCustomers.Count > 0 ? validAccountDetails.Where(a => !npnrCustomers.Contains(a.CustomerKey)).ToList() : validAccountDetails;
                }

                await _necNRTRepository.UpdateConsolidationAccountsStatusByBatch(eligibleAccounts, ConsolidationStatus.Pending);
            }
        }


        private async Task<List<short>> AddConsolidationActivity(ConsolidationAccount account)
        {
            bool isInterestSupport = true;
            List<short> activities = new List<short>
            {
                (short)WorkflowActivity.UpdateProductInACI,
                (short)WorkflowActivity.UpdateProductAndMembershipinDB,
                (short)WorkflowActivity.AddCRMNote
            };

            if (account.ConsolidationGroupKey == (short)ConsolidationType.GD)
                isInterestSupport = await CheckIfTargetProductSupportInterest(account);

            //check target product bintype
            var targetBin = new ProductDetail() { BinType = checkingBinType };
            if(account.TargetProductKey > 0)
                targetBin = await _necRepository.GetBinInfoByProductKey(account.TargetProductKey);

            //Check if BCD need to be set
            var bcd = await _necRepository.GetBillCycleInfoByAccountKey(account.CustomerKey, account.AccountKey);
            if (bcd == null || bcd.CustomerBillCycleDay == null || bcd.AccountBillCycleDay == null)
            {
                activities.Add((short)WorkflowActivity.SetBillCycleDay);
            }

            var accountSubscriptions = await _necRepository.GetActiveAccountSubscriptionsByAccountKey(account.AccountKey);
            //Check VIP subscription exists?
            if (accountSubscriptions != null && accountSubscriptions.Where(s => s.SubscriptionTypeKey == Constants.VIPSubscriptionTypeKey).Count() > 0)
                activities.Add((short)WorkflowActivity.RemoveVIPSubscription);


            if (string.IsNullOrEmpty(targetBin?.BinType) || targetBin?.BinType.ToLower() == checkingBinType)
            {
                //Check DAA agreement is accepted?
                var acceptedAgreements = await _necRepository.GetAcceptedAgreementsByAccountKey(account.AccountKey);
                if (acceptedAgreements.Where(a => a.AgreementKey == Constants.DepositAccountAgreementKey && (a.AgreementExpirationDate > DateTime.Now || a.AgreementExpirationDate == DateTime.MinValue)).Count() == 0)
                    activities.Add((short)WorkflowActivity.AddDAAAgreement);

                //Check SAA agreement is accepted?
                if (acceptedAgreements.Where(a => a.AgreementKey == Constants.SavingsAccountAgreementKey && (a.AgreementExpirationDate > DateTime.Now || a.AgreementExpirationDate == DateTime.MinValue)).Count() == 0)
                    activities.Add((short)WorkflowActivity.AddSAAAgreement);

                //Check saving account interest agreement is accepted?
                if (acceptedAgreements.Where(a => a.AgreementKey == Constants.SavingsAccountInterestAgreementKey && (a.AgreementExpirationDate > DateTime.Now || a.AgreementExpirationDate == DateTime.MinValue)).Count() == 0 && isInterestSupport)
                    activities.Add((short)WorkflowActivity.AddSavinginterestingAgreement);

                //only WMMC products need to add saving account interest subscription
                if (account.ConsolidationGroupKey == (short)ConsolidationType.WMMC)
                {
                    //Check saving account interest subscription exists?
                    if (accountSubscriptions == null || accountSubscriptions.Where(s => s.SubscriptionTypeKey == Constants.SavingsInterestSubscriptionTypeKey).Count() == 0)
                        activities.Add((short)WorkflowActivity.AddSavingInterestSubscription);
                }

                //Check saving account exists?
                var linkedAccount = await _necRepository.GetLinkedAccountByPrimaryAccountKey(account.AccountKey);
                if (linkedAccount == null || linkedAccount.LinkedAccountKey == 0)
                {
                    activities.Add((short)WorkflowActivity.CreateSavingAccount);

                    return activities;
                }

                //Check W9 is accepted?
                bool isW9Accepted = acceptedAgreements.Where(a => a.AgreementKey == Constants.W9CertificationAgreementKey && (a.AgreementExpirationDate > DateTime.Now || a.AgreementExpirationDate == DateTime.MinValue)).Count() > 0;
                if (!isW9Accepted && isInterestSupport)
                {
                    var balanceInfo = await _necRepository.GetAvailableBalanceByAccountkey(linkedAccount.LinkedAccountKey);
                    var currentBalance = balanceInfo.OrderByDescending(b => b.AvailableBalanceLastUpdated).FirstOrDefault().AvailableBalance;
                    if (currentBalance > 0)
                        activities.Add((short)WorkflowActivity.TransferVaultBalance);
                }
            }           


            return activities;
        }

        private async Task<bool> CheckIfTargetProductSupportInterest(ConsolidationAccount account)
        {
            // Get current membershipgroup by account key
            var customerMembershipAndFeeGroup = await _necRepository.GetConsolidationSourceDetailsByCutomerkeyAndAccountkey(account.CustomerKey, account.AccountKey);
            
            //Get target membershipgroupkey list
            var productMembershipMappingList = _cache.GetData<List<ConsolidationProductMapping>>("AppSupport_ConsolidationTargetProductMembership");
            if (productMembershipMappingList == null || productMembershipMappingList.Count == 0)
            {
                productMembershipMappingList = await _necNRTRepository.GetAllTargetConsolidationProductMappingAsync();
                _cache.InsertData("AppSupport_ConsolidationTargetProductMembership", productMembershipMappingList, TimeSpan.FromDays(1));
            }

            //Get target membership by current membershipgroupkey and productkey
            var targetProductMapping = productMembershipMappingList.Where(p => p.SourceProductKey == account.ProductKey && p.SourceMembershipGroupKey == customerMembershipAndFeeGroup.MembershipGroupKey).ToList();
            if(targetProductMapping == null || targetProductMapping.Count == 0)
            {
                throw new Exception("No target product found by current membershipgroupkey and productkey");
            }

            account.TargetProductKey = targetProductMapping.FirstOrDefault().TargetProductKey;

            //Get all MembershipInterest list
            var membershipInterestAccrualList = _cache.GetData<List<MembershipInterest>>("AppSupport_ConsolidationMembershipInterest");
            if (membershipInterestAccrualList == null || membershipInterestAccrualList.Count == 0)
            {
                membershipInterestAccrualList = await _necNRTRepository.GetAllMembershipInterestAccrualAsync();
                membershipInterestAccrualList = membershipInterestAccrualList.Where(m => (m.EndDate > DateTime.Now || m.EndDate == null) && m.InterestAccrualStartDateTypeKey == 1).ToList();
                _cache.InsertData("AppSupport_ConsolidationMembershipInterest", membershipInterestAccrualList, TimeSpan.FromDays(1));
            }

            if (membershipInterestAccrualList.Find(m => m.MembershipKey == targetProductMapping.Where(t => t.MembershipTypeKey == 1).FirstOrDefault().MembershipKey) != null)
                return true;

            return false;
        }
    }
}
