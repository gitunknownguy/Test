﻿using AppSupportProcessor.Business.Activity;
using AppSupportProcessor.Business.LegacyApi;
using AppSupportProcessor.Common.Configuration;
using AppSupportProcessor.Common.Utilities;
using AppSupportProcessor.DataAccess.DataAccesses;
using AppSupportProcessor.DataAccess.Repositories;
using AppSupportProcessor.Model.Consolidation;
using AppSupportProcessor.Model.DO;
using AppSupportProcessor.Model.Enum;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using static AppSupportProcessor.Business.Handlers.InactivityFeeHandler;

namespace AppSupportProcessor.Business.Handlers
{
    public interface IInactivityFeeHandler
    {
        Task ProcessAsync(CancellationToken cancellationToken);
    }
    public class InactivityFeeHandler : IInactivityFeeHandler
    {
        private ILogger<InactivityFeeHandler> _logger;
        private readonly IReportRepository _reportRepository;
        private readonly INECRepository _necRepository;
        private InactivityFeeConfiguration _config;
        public InactivityFeeHandler(
           IReportRepository reportRepository,
           INECRepository necRepository,           
           ILogger<InactivityFeeHandler> logger,
           IOptionsMonitor<InactivityFeeConfiguration> config)
        {
            _reportRepository = reportRepository;
            _necRepository = necRepository;
            _logger = logger;
            _config = config.CurrentValue;
        }

        public async Task ProcessAsync(CancellationToken cancellationToken)
        {
            Console.WriteLine("InactivityFeeHandler is running.");

            try
            {
                if (_config.Enabled)
                {
                    //1.Get PYG dormancy fee amount from NEC
                    var membershipFee = await _necRepository.GetPYGDormancyInactivityFee(_config.MembershipGroupKey);
                    var inactivityFee = membershipFee.Where(x => x.FeeTypeKey == _config.InactivityFeeTypeKey).FirstOrDefault();

                    //2.Populate PYG inactivity fee in ReportDB
                    await _reportRepository.InsertPYGInactivityFee(inactivityFee.Fee, inactivityFee.FeeTypeKey);
                    _logger.LogInformation("Inactivity Fee populated in ReportDB");

                    //3.Get PYGInactivityDormancyTransactions_REPSQL by batch from ReportDB
                    while (true)
                    {
                        var highWaterMarkKey = await _necRepository.GetMaxPYGInactivityDormancyTransactionKey();
                        var transactions = await _reportRepository.GetPYGInactivityDormancyTransactionsByBatch(highWaterMarkKey, _config.BatchSize);
                        if (transactions.Count == 0)
                        {
                            break;
                        }

                        //4.Get inactivity fee (FeeTypeKey=15) and inactivefeeCharged is null, Copy to NEC table PYGInactivityDormancyTransactions 
                        var inactivityTransactions = transactions.Where(x => x.FeeTypeKey == _config.InactivityFeeTypeKey).ToList();

                        //5.Get account balance and vault balance from NEC
                        var pinKeys = inactivityTransactions.Select(x => x.PINKey).ToList();
                        var accountBalances = await _necRepository.GetAccountBalanceByPinKeys(pinKeys);

                        //set account balance and vault balance to transactions
                        foreach (var transaction in inactivityTransactions)
                        {
                            var accountBalance = accountBalances.Where(x => x.PinKey == transaction.PINKey).FirstOrDefault();
                            transaction.AvailableBalance = accountBalance.AvailableBalance;
                            transaction.VaultAvailableBalance = accountBalance.Vault_AvailableBalance;
                            transaction.TransactionIdentifier = Guid.NewGuid().ToString("N");
                        }

                        await _necRepository.InsertPYGInactivityDormancyTransactions(inactivityTransactions);
                        _logger.LogInformation($"Inactivity Fee copyed {inactivityTransactions.Count } count from ReportDB to NEC");

                        //7.Insert into AcctHistory table when accountbalance + vaultbalance > 0
                        var acctHistoryTransactions = inactivityTransactions.Where(x => x.AvailableBalance + x.VaultAvailableBalance > 0).ToList();
                        if (acctHistoryTransactions.Count > 0)
                        {
                            //if accountbalance + vaultbalance < feeamount, then charge accountbalance + vaultbalance
                            acctHistoryTransactions.ForEach(x => x.FeeAmount = Math.Min(x.AvailableBalance + x.VaultAvailableBalance, x.FeeAmount));
                            await _necRepository.InsertPYGInactivityFeeByBatch(acctHistoryTransactions, inactivityFee.TransTypeKey, inactivityFee.TransType, inactivityFee.DetailAccountTransactionTypeKey);

                            acctHistoryTransactions.ForEach(x => x.PYGInactivityDormancyTransactionStatusKey = (short)PYGInactivityDormancyTransactionStatus.Completed);
                            await _necRepository.UpdatePYGInactivityDormancyTransactions(acctHistoryTransactions);
                        }

                        //find data in transactions where accountbalance + vaultbalance <= 0, and update status to skipped
                        var inactivityTransactionsSkipToCharge = inactivityTransactions.Where(x => x.AvailableBalance + x.VaultAvailableBalance <= 0).ToList();
                        if (inactivityTransactionsSkipToCharge.Count > 0)
                        {
                            inactivityTransactionsSkipToCharge.ForEach(x => x.PYGInactivityDormancyTransactionStatusKey = (short)PYGInactivityDormancyTransactionStatus.Skipped);
                            await _necRepository.UpdatePYGInactivityDormancyTransactions(inactivityTransactionsSkipToCharge);
                        }
                    }
                }
                else
                {
                    _logger.LogInformation("InactivityFeeHandler is disabled");
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in InactivityFeeHandler");
            }
        }
    }
}
