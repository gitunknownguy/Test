﻿using AppSupportProcessor.Business.LegacyApi;
using AppSupportProcessor.Business.Logic;
using AppSupportProcessor.Common.Configuration;
using AppSupportProcessor.Common.Utilities;
using AppSupportProcessor.DataAccess.Repositories;
using AppSupportProcessor.Model.AutoOrderCard;
using AppSupportProcessor.Model.Enum;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.Handlers
{
    public interface IAutoOrderCardHandler
    {
        Task ProcessAsync(CancellationToken cancellationToken);
    }

    public class AutoOrderCardHandler : IAutoOrderCardHandler
    {
        private ILogger<AutoOrderCardHandler> _logger;
        private AutoOrderCardConfiguration _config;
        private IAutoOrderCardFileService _autoOrderCardFileService;
        private readonly INECNRTRepository _necNRTRepository;
        private readonly INECRepository _necRepository;
        private readonly INotifyApiRepository _notifyApiRepository;
        private readonly ISOAV3CardRepository _soaV3CardRepository;
        private readonly IAccountManagementReposity _accountManagementReposity;

        public AutoOrderCardHandler(
            ILogger<AutoOrderCardHandler> logger,
            IOptionsMonitor<AutoOrderCardConfiguration> config,
            IAutoOrderCardFileService autoOrderCardFileService,
            INECNRTRepository nECNRTRepository,
            INECRepository necRepository,
            INotifyApiRepository notifyApiRepository,
            ISOAV3CardRepository soaV3CardRepository,
            IAccountManagementReposity accountManagementReposity
           )
        {
            _logger = logger;
            _config = config.CurrentValue;
            _autoOrderCardFileService = autoOrderCardFileService;
            _necRepository = necRepository;
            _necNRTRepository = nECNRTRepository;
            _notifyApiRepository = notifyApiRepository;
            _soaV3CardRepository = soaV3CardRepository;
            _accountManagementReposity = accountManagementReposity;
        }

        public async Task ProcessAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("AutoOrderCardHandler is running.");
            try
            {
                //Generate AutoOrderCardAccount table data
                await LoadAutoOrderCardAccounts();

                #region Handle data
                _logger.LogInformation("DoReplaceCard begin");
                //Pick up AutoOrderCardAccount which is Pending and Failed
                long minAutoOrderCardAccountKey = 0;
                var accounts = await _necNRTRepository.GetAutoOrderCardAccountByBatch(_config.BatchSize, minAutoOrderCardAccountKey);
                while (!(accounts == null || accounts.Count == 0))
                {
                    await ProcessAutoOrderCardAccounts(accounts);
                    minAutoOrderCardAccountKey = accounts.Max(x => x.AutoOrderCardAccountKey);
                    accounts = await _necNRTRepository.GetAutoOrderCardAccountByBatch(_config.BatchSize, minAutoOrderCardAccountKey);
                }
                _logger.LogInformation("DoReplaceCard end");
                #endregion
            }
            catch (Exception ex)
            {
                _logger.LogError("AutoOrderCardHandler error: " + ex.ToString());
            }
            finally
            {
                _logger.LogInformation("AutoOrderCardHandler is end.");
            }
        }

        #region load accounts
        private async Task LoadAutoOrderCardAccounts()
        {
            try
            {
                _logger.LogInformation("LoadAutoOrderCardAccounts begin.");
                var files = _autoOrderCardFileService.GetFiles(_config.AutoOrderCardFilePath);
                if (files.Count == 0)
                {
                    _logger.LogInformation("No files found in the directory.");
                    return;
                }

                foreach (var file in files)
                {
                    var fileName = Path.GetFileName(file);
                    try
                    {
                        #region get account from file
                        var accounts = _autoOrderCardFileService.GetFileData(file);
                        if (accounts.Count == 0)
                        {
                            ArchiveFile(file, fileName);
                            _logger.LogInformation($"No data found in the file: {fileName}");
                            continue;
                        }
                        #endregion

                        #region add accounts
                        accounts = accounts.Distinct(new AutoOrderCardAccountCompare()).ToList();
                        var batches = Helper.Partition(accounts, 3000);
                        foreach (var batch in batches)
                        {
                            await _necNRTRepository.AddAutoOrderCardAccountsByBatch(batch);
                        }
                        #endregion

                        #region archive file and update file status
                        ArchiveFile(file, fileName);
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError($"Error processing file(LoadAutoOrderCardAccounts): {fileName} Error: " + ex.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("LoadAutoOrderCardAccounts error: " + ex.ToString());
            }
            finally
            {
                _logger.LogInformation("LoadAutoOrderCardAccounts end.");
            }
        }

        private void ArchiveFile(string filePath, string fileName)
        {
            var archivePath = Path.Combine(_config.AutoOrderCardCompleteFilePath, fileName);
            _autoOrderCardFileService.Delete(archivePath);
            _autoOrderCardFileService.MoveFile(filePath, archivePath);
        }
        #endregion

        #region process accounts
        private async Task ProcessAutoOrderCardAccounts(List<AutoOrderCardAccount> accounts)
        {
            foreach (var account in accounts)
            {
                try
                {
                    #region Has EMV card checking
                    var allPlastics = await _necRepository.GetAllPlasticsByAccountKey(account.AccountKey);
                    if (allPlastics == null || allPlastics.Count == 0)
                    {
                        await _necNRTRepository.UpdateAutoOrderCardAccount(
                              new AutoOrderCardAccount()
                              {
                                  AutoOrderCardAccountKey = account.AutoOrderCardAccountKey,
                                  AutoOrderCardAccountStatusKey = (short)AutoOrderCardAccountStatus.Stopped,
                                  AutoOrderCardAccountStatusReason = "No plastics"
                              });
                        continue;
                    }

                    if (allPlastics != null && allPlastics.Any(p => p.IsEMV == true))
                    {
                        await _necNRTRepository.UpdateAutoOrderCardAccount(
                            new AutoOrderCardAccount()
                            {
                                AutoOrderCardAccountKey = account.AutoOrderCardAccountKey,
                                AutoOrderCardAccountStatusKey = (short)AutoOrderCardAccountStatus.Skipped,
                                AutoOrderCardAccountStatusReason = "Account already has EMV card"
                            });
                        continue;
                    }
                    #endregion

                    #region CreditRating checking
                    var creditRating = await _necRepository.GetCustomerCreditRatingKeyByAccountKey(account.AccountKey);
                    if (creditRating?.CreditRatingKey != null &&
                        (CreditRating.C5.ToString().Equals(creditRating.CreditRatingKey, StringComparison.OrdinalIgnoreCase) ||
                         CreditRating.B4.ToString().Equals(creditRating.CreditRatingKey, StringComparison.OrdinalIgnoreCase))
                        )
                    {
                        await _necNRTRepository.UpdateAutoOrderCardAccount(
                              new AutoOrderCardAccount()
                              {
                                  AutoOrderCardAccountKey = account.AutoOrderCardAccountKey,
                                  AutoOrderCardAccountStatusKey = (short)AutoOrderCardAccountStatus.Stopped,
                                  AutoOrderCardAccountStatusReason = $"Account has CreditRating {creditRating?.CreditRatingKey}"
                              });
                        continue;
                    }
                    #endregion

                    #region Has ReplaceCard Request checking
                    var replaceCardRequests = await _necRepository.GetTsysQueueRequestByCustomerKey(account.CustomerKey, 200, account.CreateDate);
                    if (replaceCardRequests != null && replaceCardRequests.Any(r => r.ResponseDate == null))
                    {
                        _logger.LogInformation($"Account {account.AccountKey} has ReplaceCard request");
                        continue;
                    }
                    #endregion

                    #region CreditRating M9/P9/B5 checking
                    if (creditRating?.CreditRatingKey != null &&
                       (CreditRating.B5.ToString().Equals(creditRating.CreditRatingKey, StringComparison.OrdinalIgnoreCase) ||
                        CreditRating.M9.ToString().Equals(creditRating.CreditRatingKey, StringComparison.OrdinalIgnoreCase) ||
                        CreditRating.P9.ToString().Equals(creditRating.CreditRatingKey, StringComparison.OrdinalIgnoreCase))
                       )
                    {
                        await _necNRTRepository.UpdateAutoOrderCardAccount(
                              new AutoOrderCardAccount()
                              {
                                  AutoOrderCardAccountKey = account.AutoOrderCardAccountKey,
                                  AutoOrderCardAccountStatusKey = (short)AutoOrderCardAccountStatus.Pending,
                                  AutoOrderCardAccountStatusReason = $"Account has CreditRating {creditRating?.CreditRatingKey}, waiting fix"
                              });
                        continue;
                    }
                    #endregion

                    #region Replace Card
                    var lastPlastic = allPlastics.OrderByDescending(p => p.PlasticKey).First();
                    Guid replaceCardRequestId=Guid.NewGuid();
                    _logger.LogInformation($"ReplaceCard card for Account {account.AccountKey}, replaceCardRequestId {replaceCardRequestId}");
                    var replaceCardResult = await _accountManagementReposity.ReplaceCardAsync(new AccountManagement.ReplaceRequest()
                    {
                        CardToken = lastPlastic.PlasticKey.ToString(),//plastic Key
                        ReplacementRequestType = AccountManagement.ReplacementRequestType.Reissue,
                        WaiveReplacementFee = true,
                        DeliveryType = AccountManagement.DeliveryType.Regular,
                        WaiveDeliveryFee = true,
                        FeeWaiveReason = AccountManagement.FeeWaiverReason.None,
                        ForceUpdate = true,
                        IsDowngrade = false,
                        SuppressCRVBlock = false,
                        UserToken = "10",
                        Note = "Auto order card for temp card",
                        RequestId= replaceCardRequestId.ToString(),
                        InterviewResponse = new AccountManagement.InterviewResponse()
                        {
                            CreateReplacementAccount = false,
                            DiscoveredDate = DateTime.Now.AddDays(-1),
                            IsBelongingsMissing = false,
                            IsCardSecured = true,
                            IsPinWrittenOnCard = false,
                            IsPoliceNotified = false,
                            IsUnauthorizedCharge = false,
                            LastUsedAmount = 0,
                            LastUsedDate = DateTime.Now.AddDays(-1),
                            PoliceNotificationDate = DateTime.Now.AddDays(-1),
                            LastUsedMerchant = "",
                            MissingCardType = "",
                            PoliceNotificationAgency = "",
                            PoliceNotificationCity = ""
                        }
                    });
                    if (replaceCardResult?.ReplaceSuccess == true)
                    {
                        await _necNRTRepository.UpdateAutoOrderCardAccount(
                              new AutoOrderCardAccount()
                              {
                                  AutoOrderCardAccountKey = account.AutoOrderCardAccountKey,
                                  AutoOrderCardAccountStatusKey = (short)AutoOrderCardAccountStatus.Complete,
                                  AutoOrderCardAccountStatusReason = "Replace card success"
                              });

                        #region Sent NT16 
                        await SendNotification(account, lastPlastic);
                        #endregion
                    }
                    else
                    {
                        await _necNRTRepository.UpdateAutoOrderCardAccount(
                              new AutoOrderCardAccount()
                              {
                                  AutoOrderCardAccountKey = account.AutoOrderCardAccountKey,
                                  AutoOrderCardAccountStatusKey = (short)AutoOrderCardAccountStatus.Failed,
                                  AutoOrderCardAccountStatusReason = "Replace card failed"
                              });
                    }
                    #endregion
                }
                catch (Exception ex)
                {
                    _logger.LogError($"Error processing account(ProcessAutoOrderCardAccounts): {account.AccountKey} Error: " + ex.ToString());
                }
            }
        }

        private async Task SendNotification(AutoOrderCardAccount account, PlasticInformation plastic)
        {
            var productInfo = await _necRepository.GetProductInfoByCardReferenceID(plastic.CardReferenceID.Value);
            var emailList = await _necNRTRepository.GetEmailInfoByAccountKey(account.AccountKey);
            var email = emailList.FirstOrDefault(e => e.IsPrimary);
            if (email == null) email = emailList.FirstOrDefault();

            if (productInfo != null && !string.IsNullOrEmpty(email?.Email))
            {
                await _notifyApiRepository.Send(new Model.LegacyApi.SendCnRequest()
                {
                    AccountIdentifier = account.AccountKey.ToString(),
                    IsRuleEvaluated = false,
                    NotificationRequestIdentifier = Guid.NewGuid().ToString(),
                    NotificationTypeToken = "16",
                    BrandIdentifier = 0,
                    ProductToken = productInfo.ProductKey.ToString(),
                    ProductDefinitionToken = productInfo.ProductDefinitionKey.ToString(),
                    PortfolioToken = productInfo.PortfolioKey.ToString(),
                    Attributes = new List<Model.LegacyApi.NotificationAttribute>()
                      {
                           new Model.LegacyApi.NotificationAttribute()
                           {
                                NotificationAttributeKey="39",
                                NotificationAttributeName= null,
                                NotificationAttributeValue= email.Email,
                                isSystemDefined= false
                           },
                           new Model.LegacyApi.NotificationAttribute()
                           {
                                NotificationAttributeKey="21",
                                NotificationAttributeName= null,
                                NotificationAttributeValue= email.FirstName,
                                isSystemDefined= false
                           }
                      },
                    Contacts = new List<Model.LegacyApi.CnContact>()
                       {
                           new Model.LegacyApi.CnContact()
                           {
                               ContactName=email.Email,
                               ChannelType= 2
                           }
                       },
                    IsRetry = false,
                    RequestId = Guid.NewGuid()
                });
            }

        }
        #endregion

    }
}
