﻿using AppSupportProcessor.Business.Activity;
using AppSupportProcessor.Business.LegacyApi;
using AppSupportProcessor.Common.Configuration;
using AppSupportProcessor.Common.Utilities;
using AppSupportProcessor.DataAccess.Repositories;
using AppSupportProcessor.Model.Consolidation;
using AppSupportProcessor.Model.DO;
using AppSupportProcessor.Model.Enum;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.Handlers
{
    public interface IRetryActivityHandler
    {
        Task ProcessAsync(CancellationToken cancellationToken);
    }

    public class RetryActivityHandler : BaseActivityHandler,  IRetryActivityHandler
    {

        public RetryActivityHandler(
           INECNRTRepository nECNRTRepository,
           INECRepository necRepository,
           IProcessorTransmissionRepository processorTransmissionRepository,
           IAgreementRepository agreementRepository,
           IAccountManagementReposity accountManagementReposity,
           IFundTransferRepository fundTransferRepository,
           ISavingsAccountServiceReposity savingsAccountServiceReposity,
           ICRMRepository crmRepository,
           ILogger<RetryActivityHandler> logger,
           IOptionsMonitor<ConsolidationConfiguration> config,
           ICache cache) :
            base(nECNRTRepository, necRepository, processorTransmissionRepository, agreementRepository, accountManagementReposity,
               fundTransferRepository, savingsAccountServiceReposity, crmRepository, logger, cache, config)
        {
            
        }


        protected override Task<string> GetActionName()
        {
            return Task.FromResult("RetryActivityHandler");
        }

        protected override async Task<List<ConsolidationAccount>> GetConsolidationAccountAsync(List<short> productList)
        {
            var accounts = await _necNRTRepository.GetConsolidationAccountAsync((short)ConsolidationStatus.Failed, productList, _config.RetryActivityBatchSize);

            return accounts;
        }

        protected override Task<short> GetConsolidationAccountStatusAsync(long consolidationAccountKey)
        {
            return Task.FromResult((short)ConsolidationStatus.Failed);
        }

        protected override async Task<bool> PreCheckConsolidationAccountActivityAsync(ConsolidationAccount account, List<ConsolidationAccountActivity> activities)
        {
            if (activities.Where(a => a.ConsolidationActivityStatusKey == (short)ActivityStatus.Success).Count() == activities.Count())
            {
                _logger.LogInformation($"No pending or failed activities found for account: {account.AccountKey}");
                await _necNRTRepository.UpdateConsolidationStatusAsync(account.ConsolidationAccountKey, (short)ConsolidationStatus.Failed, (short)ConsolidationStatus.Success);
                return false;
            }

            if (activities.Select(a => a.ConsolidationActivityStatusKey).ToList().Contains((short)ActivityStatus.Expired))
            {
                _logger.LogInformation($"Expired activities found for account: {account.AccountKey}");
                await _necNRTRepository.UpdateConsolidationStatusAsync(account.ConsolidationAccountKey, (short)ConsolidationStatus.Failed, (short)ConsolidationStatus.Expired);
                return false;
            }

            return true;
        }

        protected override Task<List<ConsolidationAccountActivity>> FilterConsolidationAccountActivityAsync(List<ConsolidationAccountActivity> activities)
        {
            return Task.FromResult(activities.Where(p => p.ConsolidationActivityStatusKey == (short)ActivityStatus.Pending || p.ConsolidationActivityStatusKey == (short)ActivityStatus.Failed).ToList());
        }

        protected override async Task HandlerConsolidationAccountActivityExceptionAsync(ConsolidationAccount account, ConsolidationAccountActivity activity)
        {
            if (activity.ConsolidationActivityStatusKey == (short)ActivityStatus.Failed)
                activity.RetryCount++;

            bool expired = false;
            if (activity.RetryCount >= _config.ValutRetryMaxCount && activity.ConsolidationActivityKey == (short)WorkflowActivity.TransferVaultBalance)
            { 
                expired = true;
            }
            else if(activity.RetryCount >= _config.RetryMaxCount && activity.ConsolidationActivityKey != (short)WorkflowActivity.TransferVaultBalance)
            {
                expired = true;
            }

            if (expired)
            {
                await _necNRTRepository.UpdateConsolidationAccountActivityByConsolidationAccountActivityKeyAsync(activity.ConsolidationAccountActivityKey, (short)ActivityStatus.Expired, activity.ActivityDetail, activity.RetryCount); // Update status as expired
                await _necNRTRepository.UpdateConsolidationStatusAsync(account.ConsolidationAccountKey, (short)ConsolidationStatus.Failed, (short)ConsolidationStatus.Expired);// Update status as expired

                return;
            }

            await _necNRTRepository.UpdateConsolidationAccountActivityByConsolidationAccountActivityKeyAsync(activity.ConsolidationAccountActivityKey, (short)ActivityStatus.Failed, activity.ActivityDetail, activity.RetryCount); // Update status as failed

        }

        protected override async Task UpdateConsolidationAccountActivityStatusAsync(ConsolidationAccountActivity activity)
        {
            activity.RetryCount++;
            await _necNRTRepository.UpdateConsolidationAccountActivityByConsolidationAccountActivityKeyAsync(activity.ConsolidationAccountActivityKey,
                        activity.ConsolidationActivityStatusKey, activity.ActivityDetail, activity.RetryCount); // Update status as success
        }
    }
}

