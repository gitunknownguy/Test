﻿using AppSupportProcessor.Business.Logic;
using AppSupportProcessor.Common.Configuration;
using AppSupportProcessor.Common.Utilities;
using AppSupportProcessor.DataAccess.Repositories;
using AppSupportProcessor.Model.Consolidation;
using AppSupportProcessor.Model.Enum;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.Handlers
{
    public interface ILoadConsolidationAccountsHandler
    {
        Task ProcessAsync(CancellationToken cancellationToken);
    }

    public class LoadConsolidationAccountsHandler : ILoadConsolidationAccountsHandler
    {
        private ILogger<LoadConsolidationAccountsHandler> _logger;
        private readonly INECNRTRepository _necNRTRepository;
        private readonly IConsolidationFileService _consolidationFileService;
        private ConsolidationConfiguration _config;

        public LoadConsolidationAccountsHandler(
           INECNRTRepository nECNRTRepository,
           IConsolidationFileService consolidationFileService,
           ILogger<LoadConsolidationAccountsHandler> logger,
           IOptionsMonitor<ConsolidationConfiguration> config)
        {
            _logger = logger;
            _necNRTRepository = nECNRTRepository;
            _config = config.CurrentValue;
            _consolidationFileService = consolidationFileService;
        }

        public async Task ProcessAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("LoadConsolidationAccountsHandler is running.");
            try
            {
                var files = _consolidationFileService.GetFiles(_config.LoadConsolidationAccountsFilePath);
                if (files.Count == 0)
                {
                    _logger.LogInformation("No files found in the directory.");
                    return;
                }

                foreach (var file in files)
                {
                    var fileName = Path.GetFileName(file);
                    try
                    {
                        #region get or add consolidation account file
                        var consolidationAccountFile = await _necNRTRepository.GetConsolidationAccountFileByFileName(fileName);
                        if (consolidationAccountFile == null)
                        {
                            consolidationAccountFile = new ConsolidationAccountFile()
                            {
                                ConsolidationFileName = fileName,
                                ConsolidationFilePath = file,
                                ConsolidationFileStatusKey = (short)ConsolidationFileStatus.FileImportStart
                            };
                           var consolidationAccountFileKey = await _necNRTRepository.AddConsolidationAccountFile(consolidationAccountFile);
                           consolidationAccountFile.ConsolidationAccountFileKey = consolidationAccountFileKey;
                        }
                        else if (consolidationAccountFile.ConsolidationFileStatusKey == (short)ConsolidationFileStatus.FileImportComplete)
                        {
                            var archivePath = Path.Combine(_config.LoadConsolidationAccountsCompleteFilePath, fileName);
                            _consolidationFileService.MoveFile(file, archivePath);
                            _logger.LogInformation($"File already processed: {fileName}");
                            continue;
                        }
                        #endregion

                        #region get account from file
                        var accounts = _consolidationFileService.GetFileData(file, consolidationAccountFile.ConsolidationAccountFileKey);//todo
                        if (accounts.Count == 0)
                        {
                            await ArchiveFile(file, fileName, consolidationAccountFile.ConsolidationAccountFileKey);
                            _logger.LogInformation($"No data found in the file: {fileName}");
                            continue;
                        }
                        #endregion

                        #region add or update accounts
                        var batches = Helper.Partition(accounts, _config.LoadConsolidationAccountsBatchSize);
                        foreach (var batch in batches)
                        {
                            await AddOrUpdateAccounts(batch);
                        }
                        #endregion

                        #region archive file and update file status
                        await ArchiveFile(file, fileName, consolidationAccountFile.ConsolidationAccountFileKey);
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError($"Error processing file: {fileName} Error: " + ex.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("LoadConsolidationAccountsHandler error: " + ex.ToString());
            }
            finally
            {
                _logger.LogInformation("LoadConsolidationAccountsHandler is end.");
            }
        }

        private async Task AddOrUpdateAccounts(List<ConsolidationAccount> accounts)
        {
            long consolidationFileKey = accounts[0].ConsolidationAccountFileKey; 
            var dbAccounts = await _necNRTRepository.GetConsolidationAccountsByBatch(accounts);
            var accountsForInsert = accounts.Where(x => !dbAccounts.Any(y => x.AccountKey == y.AccountKey)).ToList();
            var accountsForUpdate = (from dbAccount in dbAccounts
                                     where dbAccount.ConsolidationAccountKey > 0 && dbAccount.ConsolidationStatusKey == (short)ConsolidationStatus.NotEligible
                                     select new ConsolidationAccount()
                                     {
                                         ConsolidationAccountKey = dbAccount.ConsolidationAccountKey,
                                         ConsolidationStatusKey = (short)ConsolidationStatus.Pending,
                                         ConsolidationAccountFileKey = consolidationFileKey,
                                         AccountKey = dbAccount.AccountKey
                                     }).ToList();

            if (accountsForInsert.Count > 0)
            {
                foreach (var account in accountsForInsert)
                {
                    account.ConsolidationStatusKey = (short)ConsolidationStatus.Pending;
                }
                await _necNRTRepository.AddConsolidationAccountsByBatch(accountsForInsert);
            }

            if (accountsForUpdate.Count > 0)
            {
                await _necNRTRepository.UpdateConsolidationAccountsStatusByBatch(accountsForUpdate, ConsolidationStatus.NotEligible);
            }
        }

        private async Task ArchiveFile(string filePath, string fileName, long consolidationAccountFileKey)
        {
            var archivePath = Path.Combine(_config.LoadConsolidationAccountsCompleteFilePath, fileName);
            _consolidationFileService.MoveFile(filePath, archivePath);
            await _necNRTRepository.UpdateConsolidationAccountFile(new ConsolidationAccountFile()
            {
                ConsolidationAccountFileKey = consolidationAccountFileKey,
                ConsolidationFileStatusKey = (short)ConsolidationFileStatus.FileImportComplete,
                ConsolidationFileArchivedPath = archivePath
            });
        }
    }
}
