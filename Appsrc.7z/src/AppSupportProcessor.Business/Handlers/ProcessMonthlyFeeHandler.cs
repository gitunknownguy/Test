﻿using AppSupportProcessor.Common.Configuration;
using AppSupportProcessor.DataAccess.Repositories;
using AppSupportProcessor.Model.NEC;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.Handlers
{
    public interface IProcessMonthlyFeeHandler
    {
        Task ProcessAsync(CancellationToken cancellationToken);
    }

    public class ProcessMonthlyFeeHandler : IProcessMonthlyFeeHandler
    {
        private ILogger<ProcessMonthlyFeeHandler> _logger;
        private ProcessMonthlyFeeConfiguration _config;
        private readonly INECRepository _necRepository;
        private readonly INECNRTRepository _necNrtRepository;

        public ProcessMonthlyFeeHandler(
            INECRepository necRepository,
            INECNRTRepository nECNRTRepository,
            ILogger<ProcessMonthlyFeeHandler> logger,
            IOptionsMonitor<ProcessMonthlyFeeConfiguration> config)
        {
            _necRepository = necRepository;
            _necNrtRepository = nECNRTRepository;
            _logger = logger;
            _config = config.CurrentValue;
        }

        public async Task ProcessAsync(CancellationToken cancellationToken)
        {
            var date = GetEffectiveDateFromFile();
            _logger.LogInformation($"ProcessMonthlyFeeHandler-ProcessAsync GetEffectiveDateFromFile:{date}");
            if (!date.HasValue)
                return;

            var existingRequest = await _necNrtRepository.MonthlyFeeGetCurrentFeeProcessingRequest(1, date.Value);
            if (existingRequest?.MonthlyFeeProcessingRequestKey > 0)
                return;

            //truncate staging table
            await _necNrtRepository.TruncateETL_ManualFeeWaiverStatus_Staging();
            //calc feewaiver
            await _necNrtRepository.GetManualFeeWaiverStatusByEffectiveFeeDate(date.Value.Date);
            //migrate NRT ManualFeeWaiverStatus to NEC FeeWaiverStatus Table
            await MigrateFeeWaiverStatus(null);
            //wait database nec is replacated to nrt(10 min)
            var isTimeOut = !WaitDBReplecated().Wait(10 * 60 * 1000);
            if (isTimeOut)
            {
                _logger.LogError($"ProcessMonthlyFeeHandler-WaitDBReplecated timeout");
                return;
            }
            //start fee processor init
            _logger.LogInformation($"ProcessMonthlyFeeHandler-Start MonthlyFeeProcessorInit, date={date.Value.ToString("yyyy-MM-dd")}");
            await _necNrtRepository.MonthlyFeeProcessorInit(date.Value.Date);
            //ReName file
            ReNameFile();
        }

        private DateTime? GetEffectiveDateFromFile()
        {
            try
            {
                _logger.LogInformation($"ProcessMonthlyFeeHandler-GetEffectiveDateFromFile file base path:{_config.FileBasePath}");

                if (!Directory.Exists(_config.FileBasePath))
                    Directory.CreateDirectory(_config.FileBasePath);
                var fileName = Path.Combine(_config.FileBasePath, "ManualRunMMF_Initial.txt");
                if (!File.Exists(fileName)) return null;

                var content = File.ReadAllText(fileName);
                _logger.LogInformation($"ProcessMonthlyFeeHandler-GetEffectiveDateFromFile file content:{_config.FileBasePath}");

                DateTime date = DateTime.Today;
                if (DateTime.TryParse(content, out date))
                {
                    if (date.Date > DateTime.Today)
                    {
                        return null;
                    }
                    return date;
                }
                return null;
            }
            catch (Exception ex)
            {
                _logger.LogError($"ProcessMonthlyFeeHandler-GetEffectiveDateFromFile failed:{ex}");
                return null;
            }
        }

        private async Task WaitDBReplecated()
        {
            do
            {
                var necMaxKey = await _necRepository.GetNECMaxFeeWaiverStatus();
                var nrtMaxKey = await _necNrtRepository.GetNRTMaxFeeWaiverStatus();
                if (necMaxKey == nrtMaxKey) break;

                await Task.Delay(1000);
            } while (true);
        }

        private void ReNameFile()
        {
            try
            {
                _logger.LogInformation($"ProcessMonthlyFeeHandler-ReNameFile Start rename ManualRunMMF_Initial.txt file to ManualRunMMF_Start.txt");
                if (!Directory.Exists(_config.FileBasePath))
                    Directory.CreateDirectory(_config.FileBasePath);
                var fileName = Path.Combine(_config.FileBasePath, "ManualRunMMF_Initial.txt");
                if (!File.Exists(fileName)) return;
                var newFileName = Path.Combine(_config.FileBasePath, "ManualRunMMF_Start.txt");
                File.Move(fileName, newFileName);
            }
            catch (Exception ex)
            {
                _logger.LogError($"ProcessMonthlyFeeHandler-ReNameFile failed:{ex}");
            }
        }

        private async Task MigrateFeeWaiverStatus(int? startPk)
        {
            _logger.LogInformation($"Start MigrateFeeWaiverStatus, startPk={startPk}");
            var feeWaiverStatusStagingData = await _necNrtRepository.GetETL_ManualFeeWaiverStatus_Staging(startPk);
            if (feeWaiverStatusStagingData.Count == 0) return;

            _logger.LogInformation($"Start MigrateFeeWaiverStatus, startPk={startPk} MigrationDataCount={feeWaiverStatusStagingData.Count}");
            var insertData = feeWaiverStatusStagingData.Select(x => new ManualFeeWaiverStatus()
            {
                CreateDate = x.CreateDate,
                CustomerKey = x.CustomerKey,
                EndWaiveDate = x.EndWaiveDate,
                FeeWaiverKey = x.FeeWaiverKey,
                StartWaiveDate = x.StartWaiveDate
            }).ToList();
            await _necRepository.InsertManualFeeWaiverStatus(insertData);
            await MigrateFeeWaiverStatus(feeWaiverStatusStagingData.Max(x => x.ETLFeeWaiverStatusStagingKey) + 1);
        }
    }
}