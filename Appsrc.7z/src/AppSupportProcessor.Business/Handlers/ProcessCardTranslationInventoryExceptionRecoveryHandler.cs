﻿using AppSupportProcessor.Common.Configuration;
using AppSupportProcessor.Common.Extensions;

using AppSupportProcessor.DataAccess.Repositories;
using AppSupportProcessor.Model.PDS;

using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.Handlers
{
    public interface IProcessCardTranslationInventoryExceptionRecoveryHandler
    {
        Task ProcessAsync(CancellationToken cancellationToken);
    }

    [ExcludeFromCodeCoverage]
    public class ProcessCardTranslationInventoryExceptionRecoveryHandler : IProcessCardTranslationInventoryExceptionRecoveryHandler
    {
        private ILogger<ProcessCardTranslationInventoryExceptionRecoveryHandler> _logger;
        private ProcessCardTranslationInventoryExceptionRecoveryConfiguration _config;
        private readonly INECRepository _necRepository;
        private readonly IIPSRepository _ipsRepository;

        public ProcessCardTranslationInventoryExceptionRecoveryHandler(INECRepository necRepository, IIPSRepository iPSRepository, ILogger<ProcessCardTranslationInventoryExceptionRecoveryHandler> logger, IOptionsMonitor<ProcessCardTranslationInventoryExceptionRecoveryConfiguration> config)
        {
            _necRepository = necRepository;
            _logger = logger;
            _config = config.CurrentValue;
            _ipsRepository = iPSRepository;
        }

        public async Task ProcessAsync(CancellationToken cancellationToken)
        {
            var allHandleEntities = new List<ETLCardTranslationInventoryExceptionHandlerInfo>();
            var allEntities = await _ipsRepository.GetETL_CardTranslationInventory_ExceptionHandlerByBatch(_config.BatchSize, "Initial");

            _logger.LogInformation($"GetExceptionHandlerBatchSize:{allEntities.Count}");

            var useEntities = allEntities.Where(x => x.TransformationErrorDescription == "RCM must have new, unique Card Proxy").ToList();

            _logger.LogInformation($"GetExceptionHandler Description Correct BatchSize:{useEntities.Count}");

            //Error Record1>if description is not 'RCM must have new, unique Card Proxy' should be ignore 
            var filterEntities = allEntities.Where(x => x.TransformationErrorDescription != "RCM must have new, unique Card Proxy").ToList();

            allHandleEntities.AddRange(filterEntities.Select(x => new ETLCardTranslationInventoryExceptionHandlerInfo()
            {
                ETL_CardTranslationInventory_ExceptionHandlerKey = x.ETL_CardTranslationInventory_ExceptionHandlerKey,
                ExceptionHandlerDescription = "ErrorDescription",//x.TransformationErrorDescription,
                ExceptionHandlerStatus = "Ignore"
            }));

            var necCheckEntities = await _necRepository.GetCardInventoryAndCardByCardReferenceIds(useEntities.Select(x => x.CardReferenceID).ToList());
            var filterStatus = new List<int>() { 1, 2, 3, 4 };

            var existNecEntities = useEntities.Where(x => necCheckEntities.Exists(q => q.CardReferenceID == x.CardReferenceID
                                                        && filterStatus.Contains(q.CardInventoryStatusKey)))
                                                        .ToList();

            //Error Record2>not in NEC or Status not in(1,2,3,4) should be update to error
            var notExistNecEntities = useEntities.Except(existNecEntities, x => x.CardReferenceID).ToList();
            if (notExistNecEntities != null && notExistNecEntities.Count > 0)
            {
                _logger.LogInformation($"notExistNecEntities Count :{notExistNecEntities.Count}");
                allHandleEntities.AddRange(notExistNecEntities.Select(x => new ETLCardTranslationInventoryExceptionHandlerInfo()
                {
                    ETL_CardTranslationInventory_ExceptionHandlerKey = x.ETL_CardTranslationInventory_ExceptionHandlerKey,
                    ExceptionHandlerStatus = "Ignore",
                    ExceptionHandlerDescription = "NotExistOrInValidNEC"
                }));
            }

            var matchCardProxyIdEntities = new List<CardTranslationInventoryExceptionHandlerInfo>();
            var notMatchCardProxyIdEntities = new List<CardTranslationInventoryExceptionHandlerInfo>();
            if (existNecEntities != null && existNecEntities.Count > 0)
            {
                _logger.LogInformation($"existNecEntities Count :{existNecEntities.Count}");
                var externalIds = existNecEntities.Select(x => x.CardExternalID).ToList();
                var proxyIdCheckEntities = await _ipsRepository.GetCardTranslationByCardExternalIDs(externalIds, 2);
                matchCardProxyIdEntities = existNecEntities.Where(x => proxyIdCheckEntities.Count(q => q.CardExternalID == x.CardExternalID) > 0)
                                                                            .ToList();
                notMatchCardProxyIdEntities = existNecEntities.Except(matchCardProxyIdEntities, x => x.CardExternalID).ToList();
            }

            //Error Record3>Exist CardProxyId
            if (matchCardProxyIdEntities.Count > 0)
            {
                _logger.LogInformation($"matchCardProxyIdEntities Count :{matchCardProxyIdEntities.Count}");
                allHandleEntities.AddRange(matchCardProxyIdEntities.Select(x => new ETLCardTranslationInventoryExceptionHandlerInfo()
                {
                    ExceptionHandlerDescription = "ExistCardProxyInCardTranslation",
                    ExceptionHandlerStatus = "Ignore",
                    ETL_CardTranslationInventory_ExceptionHandlerKey = x.ETL_CardTranslationInventory_ExceptionHandlerKey
                }));
            }

            var matchCardRefrenceIdEntities = new List<CardTranslationInventoryExceptionHandlerInfo>();
            var notmatchCardRefrenceIdEntities = new List<CardTranslationInventoryExceptionHandlerInfo>();
            var inventoryEntities = new List<GetCardTranslationInventoryInfo>();
            if (notMatchCardProxyIdEntities.Count > 0)
            {
                _logger.LogInformation($"notMatchCardProxyIdEntities Count :{notMatchCardProxyIdEntities.Count}");
                var externalIds = notMatchCardProxyIdEntities.Select(x => x.CardExternalID).ToList();
                inventoryEntities = await _ipsRepository.GetCardTranslationInventoryByCardExternalIDs(externalIds, 2);

                matchCardRefrenceIdEntities = notMatchCardProxyIdEntities.Where(x => inventoryEntities.Exists(q => q.CardExternalID == x.CardExternalID)).ToList();
                notmatchCardRefrenceIdEntities = notMatchCardProxyIdEntities.Except(matchCardRefrenceIdEntities, x => x.CardExternalID).ToList();
            }

            //Not Match inventoryEntities shoule be Ignore
            if (notmatchCardRefrenceIdEntities.Count > 0)
            {
                _logger.LogInformation($"notmatchCardRefrenceIdEntities Count :{notmatchCardRefrenceIdEntities.Count}");
                allHandleEntities.AddRange(notmatchCardRefrenceIdEntities.Select(x => new ETLCardTranslationInventoryExceptionHandlerInfo()
                {
                    ETL_CardTranslationInventory_ExceptionHandlerKey = x.ETL_CardTranslationInventory_ExceptionHandlerKey,
                    ExceptionHandlerDescription = "CardProxyNotExistInCardTranslationInventory",
                    ExceptionHandlerStatus = "Ignore"
                }));
            }

            if (matchCardRefrenceIdEntities.Count > 0)
            {
                _logger.LogInformation($"matchCardReferenceIdEntities Count :{matchCardRefrenceIdEntities.Count}");
                var matchUseEntities = useEntities.Where(x => inventoryEntities.Exists(q => q.CardReferenceID == x.CardReferenceID)).ToList();
                _logger.LogInformation($"matchUseEntities Count :{matchUseEntities.Count}");
                var matchedCardReferenceIds = matchUseEntities.Select(x => x.CardReferenceID).ToList();
                allHandleEntities.AddRange(matchUseEntities.Select(x => new ETLCardTranslationInventoryExceptionHandlerInfo()
                {
                    ETL_CardTranslationInventory_ExceptionHandlerKey = x.ETL_CardTranslationInventory_ExceptionHandlerKey,
                    ExceptionHandlerStatus = "Complete",
                    ExceptionHandlerDescription = "MatchCardReferenceId"
                }));

                var notMachedCardTranslationInventoryEntities = inventoryEntities.Where(x => !matchedCardReferenceIds.Contains(x.CardReferenceID)).ToList();

                //matchCardRefrenceIdEntities Mapping With useEntities by CardReferenceID, if not exist 
                _logger.LogInformation($"notMachedCardTranslationInventoryEntities Count :{notMachedCardTranslationInventoryEntities.Count}");
                var newMatchCardRefrenceIdEntities = matchCardRefrenceIdEntities
                    .Where(x => !matchUseEntities.Exists(q => q.ETL_CardTranslationInventory_ExceptionHandlerKey == x.ETL_CardTranslationInventory_ExceptionHandlerKey)).ToList();

                await UpdateCardTranslationInventoryToDeprecateCardProxy(allHandleEntities, newMatchCardRefrenceIdEntities, notMachedCardTranslationInventoryEntities);
            }

            await _ipsRepository.UpdateETL_CardTranslationInventory_ExceptionHandlerByBatch(allHandleEntities);

            _logger.LogInformation($"UpdateETL_CardTranslationInventory_ExceptionHandlerByBatch Count:{allHandleEntities.Count}");
        }

        private async Task UpdateCardTranslationInventoryToDeprecateCardProxy(
            List<ETLCardTranslationInventoryExceptionHandlerInfo> allHandleEntities,
            List<CardTranslationInventoryExceptionHandlerInfo> notmatchCardRefrenceIdEntities,
            List<GetCardTranslationInventoryInfo> cardTranslationInventoryInfos)
        {
            try
            {
                var result = await _necRepository.GetCardInventoryAndCardByCardReferenceIds(cardTranslationInventoryInfos.Select(x => x.CardReferenceID).ToList());

                //Not Null Card Key Should Be Updated Ignore
                var notNullCardKeyEntites = result.Where(x => x.Cardkey != 0 && x.CardExpDate >= DateTime.Now).ToList();
                var notNullCardExternalIds = cardTranslationInventoryInfos.Where(x => notNullCardKeyEntites.Exists(q => q.CardReferenceID == x.CardReferenceID))
                    .Select(x => x.CardExternalID)
                    .ToList();

                var notNullEntites = notmatchCardRefrenceIdEntities.Where(x => notNullCardExternalIds.Contains(x.CardExternalID))
                    .Select(x => new ETLCardTranslationInventoryExceptionHandlerInfo()
                    {
                        ETL_CardTranslationInventory_ExceptionHandlerKey = x.ETL_CardTranslationInventory_ExceptionHandlerKey,
                        ExceptionHandlerDescription = "OldCardRefrenceIdExistInNECCard",
                        ExceptionHandlerStatus = "Ignore",
                    });

                _logger.LogInformation($"notNullEntites Count :{notNullEntites.Count()}");
                allHandleEntities.AddRange(notNullEntites);

                var nullEntities = notmatchCardRefrenceIdEntities
                    .Where(x => !notNullCardExternalIds.Contains(x.CardExternalID));
                var updateEntities = nullEntities.Select(x => new ExceptionHandlerKeyInfo()
                {
                    CardExternalID = x.CardExternalID,
                    CardReferenceID = x.CardReferenceID,
                }).ToList();

                _logger.LogInformation($"nullEntities Count :{nullEntities.Count()}");

                await _ipsRepository.UpdateCardTranslationInventoryToDeprecateCardProxy(updateEntities, 2);

                //Complete Record2
                allHandleEntities.AddRange(nullEntities.Select(x => new ETLCardTranslationInventoryExceptionHandlerInfo()
                {
                    ETL_CardTranslationInventory_ExceptionHandlerKey = x.ETL_CardTranslationInventory_ExceptionHandlerKey,
                    ExceptionHandlerStatus = "Complete",
                    ExceptionHandlerDescription = "AfterUpdatedCardTranslationInventory"
                }));
            }
            catch (Exception ex)
            {
                _logger.LogError($"ProcessCardTranslationInventoryExceptionRecoveryHandler _ipsRepository.UpdateCardTranslationInventoryToDeprecateCardProxy Error:{ex}");
                allHandleEntities.AddRange(notmatchCardRefrenceIdEntities.Select(x => new ETLCardTranslationInventoryExceptionHandlerInfo()
                {
                    ETL_CardTranslationInventory_ExceptionHandlerKey = x.ETL_CardTranslationInventory_ExceptionHandlerKey,
                    ExceptionHandlerStatus = "Ignore",
                    ExceptionHandlerDescription = ex.Message
                }));
            }
        }
    }
}
