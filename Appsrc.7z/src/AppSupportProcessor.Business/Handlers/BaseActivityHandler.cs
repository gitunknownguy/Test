using AppSupportProcessor.Business.Activity;
using AppSupportProcessor.Business.LegacyApi;
using AppSupportProcessor.Common.Configuration;
using AppSupportProcessor.Common.Utilities;
using AppSupportProcessor.DataAccess.Repositories;
using AppSupportProcessor.Model.Consolidation;
using AppSupportProcessor.Model.Enum;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.Handlers
{
    public interface IActivityHandler
    {
        Task ProcessAsync(CancellationToken cancellationToken);
    }

    public abstract class BaseActivityHandler
    {
        protected ILogger<BaseActivityHandler> _logger;
        protected INECNRTRepository _necNRTRepository;
        protected INECRepository _necRepository;
        protected IProcessorTransmissionRepository _processorTransmissionRepository;
        protected IAgreementRepository _agreementRepository;
        protected IAccountManagementReposity _accountManagementReposity;
        protected IFundTransferRepository _fundTransferRepository;
        protected ISavingsAccountServiceReposity _savingsAccountServiceReposity;
        protected ICRMRepository _crmRepository;
        protected ICache _cache;
        protected ConsolidationConfiguration _config;

        public BaseActivityHandler(
            INECNRTRepository nECNRTRepository,
            INECRepository necRepository,
            IProcessorTransmissionRepository processorTransmissionRepository,
            IAgreementRepository agreementRepository,
            IAccountManagementReposity accountManagementReposity,
            IFundTransferRepository fundTransferRepository,
            ISavingsAccountServiceReposity savingsAccountServiceReposity,
            ICRMRepository crmRepository,
            ILogger<BaseActivityHandler> logger,
            ICache cache,
            IOptionsMonitor<ConsolidationConfiguration> config)
        {
            _logger = logger;
            _processorTransmissionRepository = processorTransmissionRepository;
            _agreementRepository = agreementRepository;
            _accountManagementReposity = accountManagementReposity;
            _fundTransferRepository = fundTransferRepository;
            _savingsAccountServiceReposity = savingsAccountServiceReposity;
            _necNRTRepository = nECNRTRepository;
            _necRepository = necRepository;
            _crmRepository = crmRepository;
            _cache = cache;
            _config = config.CurrentValue;
        }
                
        public async Task ProcessAsync(CancellationToken cancellationToken)
        {
            var handlerName = await GetActionName();
            _logger.LogInformation($"{handlerName} is running.");
            try
            {
                var productMappingList = _cache.GetData<List<ConsolidationProductMapping>>("AppSupport_ConsolidationProductMapping");
                if (productMappingList == null || productMappingList.Count == 0)
                {
                    productMappingList = await _necNRTRepository.GetAllConsolidationProductMappingAsync();
                    _cache.InsertData("AppSupport_ConsolidationProductMapping", productMappingList, TimeSpan.FromDays(1));
                }

                var activeProductList = productMappingList
                    .Where(p => p.EffectiveDate != null && p.EffectiveDate < DateTime.Now && p.ExpirationDate != null && p.ExpirationDate > DateTime.Now).ToList()
                    .Select(p => p.SourceProductKey).Distinct().ToList();

               var accounts = await GetConsolidationAccountAsync(activeProductList);
               
                foreach (var account in accounts)
                {
                    await ProcessAccountActivities(account);

                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"{handlerName} error: " + ex.ToString());
            }
        }
        protected abstract Task<string> GetActionName();
        protected abstract Task<List<ConsolidationAccount>> GetConsolidationAccountAsync(List<short> productList);
        protected abstract Task<bool> PreCheckConsolidationAccountActivityAsync(ConsolidationAccount account, List<ConsolidationAccountActivity> activities);
        protected abstract Task<List<ConsolidationAccountActivity>> FilterConsolidationAccountActivityAsync(List<ConsolidationAccountActivity> activities);
        protected abstract Task HandlerConsolidationAccountActivityExceptionAsync(ConsolidationAccount account, ConsolidationAccountActivity activity);
        protected abstract Task UpdateConsolidationAccountActivityStatusAsync(ConsolidationAccountActivity activity);
        private async Task ProcessAccountActivities(ConsolidationAccount account)
        {
            Console.WriteLine($"Processing account: {account.AccountKey}, consolidationaccountkey: {account.ConsolidationAccountKey}.");
            var activityDataFromDatabase = await _necNRTRepository.GetConsolidationActivityAsync(account.ConsolidationAccountKey);
            var checkResult = await PreCheckConsolidationAccountActivityAsync(account, activityDataFromDatabase);
            if (!checkResult)
                return;

            var executedActivities = await FilterConsolidationAccountActivityAsync(activityDataFromDatabase);
            var activities = CreateActivities(executedActivities);
            var consolidationAccountStatus = await GetConsolidationAccountStatusAsync(account.ConsolidationAccountKey);

            // Execute activities
            foreach (var activity in activities)
            {
                try
                {
                    activity.Account = account;
                    activity.AccountActivity.ConsolidationActivityStatusKey = (short)ActivityStatus.Success;
                    Console.WriteLine($"{activity.GetType().Name} start executed.{DateTime.Now}");

                    await activity.ExecuteAsync();

                    await UpdateConsolidationAccountActivityStatusAsync(activity.AccountActivity); // Update status as success
                }
                catch (TimeNotReachedException e)
                {
                    _logger.LogInformation($"TimeNotReached executing activity: {e.Message}");
                    return;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"{activity.GetType().Name} executed successfully.");
                    _logger.LogInformation($"Error executing activity: {ex.Message}");

                    activity.AccountActivity.ConsolidationActivityStatusKey = (short)ActivityStatus.Failed;
                    activity.AccountActivity.ActivityDetail = ex.Message;

                    await HandlerConsolidationAccountActivityExceptionAsync(account, activity.AccountActivity);
                    return;
                }
            }

            if (activities.Where(a => a.AccountActivity.ConsolidationActivityStatusKey == (short)ActivityStatus.Success || a.AccountActivity.ConsolidationActivityStatusKey == (short)ActivityStatus.Skipped).Count() == activities.Count())
                await _necNRTRepository.UpdateConsolidationStatusAsync(account.ConsolidationAccountKey,
                    consolidationAccountStatus, (short)ConsolidationStatus.Success);// Update status as success
        }

        protected abstract Task<short> GetConsolidationAccountStatusAsync(long consolidationAccountKey);
        private List<IActivity> CreateActivities(List<ConsolidationAccountActivity> activityData)
        {
            var activities = new List<IActivity>();
            foreach (var activityEnum in activityData)
            {
                var activity = GetActivityFromEnum(activityEnum);
                activities.Add(activity);
            }
            
            return activities.OrderBy(a => a.Priority).ToList();
        }

        private IActivity GetActivityFromEnum(ConsolidationAccountActivity activity)
        {
            switch ((WorkflowActivity)activity.ConsolidationActivityKey)
            {
                case WorkflowActivity.UpdateProductInACI:
                    return new UpdateProductInACI(_processorTransmissionRepository, _necNRTRepository, _necRepository, _cache) { AccountActivity = activity };
                case WorkflowActivity.AddDAAAgreement:
                    return new AddDAAAgreement(_agreementRepository, _necRepository) { AccountActivity = activity };
                case WorkflowActivity.UpdateProductAndMembershipinDB:
                    return new UpdateProductAndMembershipinDB(_necNRTRepository, _necRepository, _cache) { AccountActivity = activity };
                case WorkflowActivity.CreateSavingAccount:
                    return new CreateSavingAccount(_savingsAccountServiceReposity, _necRepository) { AccountActivity = activity };
                case WorkflowActivity.AddSAAAgreement:
                    return new AddSAAAgreement(_agreementRepository, _necRepository) { AccountActivity = activity };
                case WorkflowActivity.AddSavinginterestingAgreement:
                    return new AddSavinginterestingAgreement(_agreementRepository, _necRepository) { AccountActivity = activity };
                case WorkflowActivity.AddSavingInterestSubscription:
                    return new AddSavingInterestSubscription(_accountManagementReposity) { AccountActivity = activity };
                case WorkflowActivity.TransferVaultBalance:
                    return new TransferVaultBalance(_fundTransferRepository, _necRepository, _necNRTRepository) { AccountActivity = activity };
                case WorkflowActivity.AddCRMNote:
                    return new AddCrmNote(_crmRepository) { AccountActivity = activity };
                case WorkflowActivity.SetBillCycleDay:
                    return new SetBillCycleDate(_necRepository) { AccountActivity = activity };
                case WorkflowActivity.RemoveVIPSubscription:
                    return new RemoveVIPSubscription(_accountManagementReposity) { AccountActivity = activity };
                default:
                    throw new ArgumentException("Invalid activity type.");
            }
        }
    }
}