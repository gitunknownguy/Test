﻿using CardAccountTransactionService;
using AppSupportProcessor.Business.LegacyApi;
using AppSupportProcessor.Common.Configuration;
using AppSupportProcessor.DataAccess.DataAccesses;
using AppSupportProcessor.Model.LegacyApi;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AppSupportProcessor.DataAccess.DataAccesses.Models;
using CustomerInfo = AppSupportProcessor.Model.LegacyApi.CustomerInfo;
using Gd.Logging.Common;

namespace AppSupportProcessor.Business.Handlers
{
    public interface IPaperStatementFileHandler
    {
        Task ProcessAsync(CancellationToken cancellationToken);
        Task BatchDeletePaperStatement();
        Task BatchProcessPaperStatementFileAndChargeFee(PaperStatementStatus paperStatementStatus);
        Task ParallellyProcess(List<PaperStatementInfo> paperStatementInfos, List<ConsumerInfo> consumerInfos);
        Task ProcessPaperStatement(PaperStatementInfo paperStatementInfo, List<ConsumerInfo> consumerInfos);
        Task<GetAvailableStatementsResponse> GenerateStatementDetails(PaperStatementInfo paperStatementInfo);
        Task<GenerateMultipleEStatementResponse> GeneratePaperStatementPdf(PaperStatementInfo paperStatementInfo, ConsumerInfo consumerInfo, GetAvailableStatementsResponse getAvailableStatementsResponse);

        Task ChargePaperStatementFee(List<PaperStatementInfo> paperStatementInfos);
    }

    public class PaperStatementFileHandler : IPaperStatementFileHandler
    {
        private IGdLogger<PaperStatementFileHandler> _logger;
        private PaperStatementFileConfiguration _config;
        private readonly INecDataAccess _necDataAccess;
        private readonly IReportDataAccess _reportDataAccess;
        private readonly ICardAccountTransactionServiceRepository _cardAccountTransactionServiceRepository;
        private readonly ICarePDFMergeAPIRepository _carePdfMergeApiRepository;
        private List<ProductPaperStatementFee> _productPaperStatementFees;

        public PaperStatementFileHandler(
            INecDataAccess necDataAccess,
            IReportDataAccess reportDataAccess,
            ICardAccountTransactionServiceRepository cardAccountTransactionServiceRepository,
            ICarePDFMergeAPIRepository carePdfMergeApiRepository,
            IGdLogger<PaperStatementFileHandler> logger,
            IOptionsMonitor<PaperStatementFileConfiguration> config)
        {
            _necDataAccess = necDataAccess;
            _reportDataAccess = reportDataAccess;
            _cardAccountTransactionServiceRepository = cardAccountTransactionServiceRepository;
            _carePdfMergeApiRepository = carePdfMergeApiRepository;
            _logger = logger;
            _config = config.CurrentValue;
           
        }

        public async Task ProcessAsync(CancellationToken cancellationToken)
        {
            try
            {
                if (!_config.Enabled)
                {
                    _logger.Info("PaperStatementFileHandler aborting because current env is not enabled.");
                    return;
                }

                _logger.Info($"PaperStatementFileHandler is running. BatchSize: {_config.BatchSize}");

                await BatchProcessPaperStatementFileAndChargeFee(PaperStatementStatus.Pending);
                await BatchProcessPaperStatementFileAndChargeFee(PaperStatementStatus.Failed);
                await BatchDeletePaperStatement();
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "PaperStatementFileHandler-error: {message}, {@ex}", ex.Message, ex);
            }
        }

        public async Task BatchDeletePaperStatement()
        {
            var paperStatementPkRanges = await _reportDataAccess.GetPaperStatementPkRangeForDelete();
            if (paperStatementPkRanges.MinPaperStatementKey == null || paperStatementPkRanges.MaxPaperStatementKey == null)
                return;
            foreach (var paperStatementPkRange in paperStatementPkRanges.GetSplitRangeList())
            {
                await _reportDataAccess.DeletePaperStatementByBatch(paperStatementPkRange.MinPaperStatementKey ?? 0, paperStatementPkRange.MaxPaperStatementKey ?? 0);
            }
        }
        public async Task BatchProcessPaperStatementFileAndChargeFee(PaperStatementStatus paperStatementStatus)
        {
            var getPaperStatementByStatusInput = new GetPaperStatementByStatusInput()
            {
                pBatchSize = _config.BatchSize,
                pPaperStatementStatusKey = (short)paperStatementStatus
            };

            if (paperStatementStatus == PaperStatementStatus.Pending)
            {
                getPaperStatementByStatusInput.pRetryCountIncrease = 0;
            }
            else if (paperStatementStatus == PaperStatementStatus.Failed)
            {
                getPaperStatementByStatusInput.pRetryCountIncrease = 1;
            }

            while (true)
            {
                List<PaperStatementInfo> paperStatementInfos = await _reportDataAccess.GetPaperStatementByStatus(getPaperStatementByStatusInput);
                _logger.Info("Start GetPaperStatementByStatus {paperStatementStatus}, {count}", paperStatementStatus, paperStatementInfos.Count);
               
                if (paperStatementInfos.Count == 0)
                {
                    break;
                }

                var accountKeyInfos = paperStatementInfos.Select(o => new AccountKeyInfo()
                {
                    AccountKey = o.AccountKey
                }).Distinct().ToList();
                var consumerInfos = await _necDataAccess.GetConsumerInfoByAccountKeys(accountKeyInfos);

                await ParallellyProcess(paperStatementInfos, consumerInfos);

                await _reportDataAccess.UpdatePaperStatement(paperStatementInfos);

                await ChargePaperStatementFee(paperStatementInfos);
            }
        }

        public async Task ParallellyProcess(List<PaperStatementInfo> paperStatementInfos, List<ConsumerInfo> consumerInfos)
        {
            var semaphore = new SemaphoreSlim(25);
            var tasks = new List<Task>();

            foreach (var paperStatementInfo in paperStatementInfos)
            {
                await semaphore.WaitAsync();

                tasks.Add(Task.Run(async () =>
                {
                    try
                    {
                        await ProcessPaperStatement(paperStatementInfo, consumerInfos);
                    }
                    finally
                    {
                        semaphore.Release();
                    }
                }));
            }
            await Task.WhenAll(tasks);
        }

        public async Task ChargePaperStatementFee(List<PaperStatementInfo> paperStatementInfos)
        {
            const short walmartPortfolioKey = 2; // Walmart don't need charge fee
            const short paperStatementFeeTransTypeKey = 8380;
            string[] closedCreditRatingKeys = { "C5", "B4" };
          
            var needChargeFeeList = paperStatementInfos.Where(p =>
                p.PortfolioKey != walmartPortfolioKey &&
                p.PaperStatementStatusKey == (int)PaperStatementStatus.Generated).ToList();
            if (!needChargeFeeList.Any())
                return;

            if (_productPaperStatementFees == null)
                _productPaperStatementFees = await _necDataAccess.GetProductPaperStatementFee();

            var needChargeFeeAccountInfos = await _necDataAccess.GetAccountInfoByAccountKeys(needChargeFeeList.Select(p => p.AccountKey).ToList());
            var addAcctHistoryList = needChargeFeeList.Select(p =>
            {
                var accountInfo = needChargeFeeAccountInfos.FirstOrDefault(c => c.AccountKey == p.AccountKey);
                if (accountInfo == null || string.IsNullOrWhiteSpace(accountInfo.SerialNbr) )
                {
                    _logger.Error("Account Info can not be found. The PaperStatementInfo is {@paperStatementInfo}", p);
                    return null;
                }

                const decimal defaultPaperStatementFee = 2.5m;
                var transAmt = _productPaperStatementFees.FirstOrDefault(fee => fee.ProductKey == accountInfo.ProductKey)?.Fee ?? defaultPaperStatementFee;
                if (transAmt == 0)
                {
                    _logger.Info("There is no setup fee for this product. ProductKey {ProductKey}", accountInfo.ProductKey);
                    return null;
                }

                var isClosedAccount = closedCreditRatingKeys.Contains(p.CreditRatingKey);
                if (isClosedAccount)
                {
                    if (accountInfo.AvailableBalance <= 0m)
                        return null;
                    transAmt = accountInfo.AvailableBalance < transAmt ? accountInfo.AvailableBalance : transAmt;
                }

                _logger.Info("Charge Paper Statement Fee for this account {AccountKey}, {PaperStatementIdentifier}, {transAmt}, {BillCycleDate}", p.AccountKey, p.PaperStatementIdentifier, transAmt, p.BillCycleDate);
                  return new AcctHistory()
                {
                    TransAmt = transAmt,
                    TransDate = DateTime.Now,
                    SerialNbr = accountInfo.SerialNbr,
                    TransTypeKey = paperStatementFeeTransTypeKey,
                    TransactionIdentifier = p.PaperStatementIdentifier,
                    AccountKey = p.AccountKey
                };
            }).Where(p => p != null).ToList();
            await _necDataAccess.AddAcctHistory(addAcctHistoryList);
        }

        public async Task ProcessPaperStatement(PaperStatementInfo paperStatementInfo, List<ConsumerInfo> consumerInfos)
        {
            paperStatementInfo.PaperStatementStatusKey = (short)PaperStatementStatus.Failed;
            if (paperStatementInfo.RetryCount > 3)
            {
                paperStatementInfo.PaperStatementStatusKey = (short)PaperStatementStatus.RetryCountExceeded;
            }

            var consumerInfo = consumerInfos.Find(o => o.AccountKey == paperStatementInfo.AccountKey);
            if (consumerInfo != null)
            {
                try
                {
                    GetAvailableStatementsResponse getAvailableStatementsResponse = await GenerateStatementDetails(paperStatementInfo);
                    if (getAvailableStatementsResponse.Statements is null || getAvailableStatementsResponse.Statements.Length == 0)
                    {
                        paperStatementInfo.PaperStatementStatusKey = (short)PaperStatementStatus.NoAvailableStatements;
                    }
                    else
                    {
                        GenerateMultipleEStatementResponse generateMultipleEStatementResponse = await GeneratePaperStatementPdf(paperStatementInfo, consumerInfo, getAvailableStatementsResponse);

                        if (generateMultipleEStatementResponse.EStatementResultList.Count > 0)
                        {
                            var eStatementResult = generateMultipleEStatementResponse.EStatementResultList[0];
                            if (eStatementResult.StatusCode == "0" && eStatementResult.SubStatusCode == "0")
                            {
                                paperStatementInfo.PaperStatementStatusKey = (short)PaperStatementStatus.Generated;
                                paperStatementInfo.PaperStatementFilePath =
                                    eStatementResult.FilePath + @"\" + eStatementResult.StatementFileName;
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    _logger.Error(e, "Generate PaperStatementPDF file failed: {message}, {@ex}. The PaperStatementInfo is {@paperStatementInfo}", e.Message, e, paperStatementInfo);
                }
            }
            else
            {
                _logger.Error("Customer Info cannot be found. The PaperStatementInfo is {@paperStatementInfo}", paperStatementInfo);
            }

            if (paperStatementInfo.PaperStatementStatusKey == (short)PaperStatementStatus.RetryCountExceeded)
            {
                _logger.Info("Generate PaperStatementPDF file RetryCountExceeded: The PaperStatementInfo is {@paperStatementInfo}", paperStatementInfo);
            }
        }

        public async Task<GetAvailableStatementsResponse> GenerateStatementDetails(PaperStatementInfo paperStatementInfo)
        {
            var getAvailableStatementsRequest = new GetAvailableStatementsRequest()
            {
                AccountToken = paperStatementInfo.AccountKey.ToString(),
                StatementsFromDate = paperStatementInfo.BillCycleDate.AddMonths(-1),
                StatementsToDate = paperStatementInfo.BillCycleDate
            };

            if (paperStatementInfo.TransactionCount == 0)
            {
                getAvailableStatementsRequest.StatementsFromDate =
                    paperStatementInfo.BillCycleDate.AddMonths(-3);
            }

            var getAvailableStatementsResponse =
                await _cardAccountTransactionServiceRepository.GetAvailableStatementsAsync(
                    getAvailableStatementsRequest);
            return getAvailableStatementsResponse;
        }

        public async Task<GenerateMultipleEStatementResponse> GeneratePaperStatementPdf(PaperStatementInfo paperStatementInfo, ConsumerInfo consumerInfo, GetAvailableStatementsResponse getAvailableStatementsResponse)
        {
            var requestId = Guid.NewGuid();
            var generateMultipleEStatementRequest = new GenerateMultipleEStatementRequest()
            {
                RequestId = requestId,

                RequestHeader = new RequestHeader()
                {
                    RequestId = requestId.ToString()
                },
                EStatementDataList = new List<EStatementData>()
                                {
                                    new EStatementData()
                                    {
                                        AccountKey = paperStatementInfo.AccountKey.ToString(),
                                        CustomerInfo = new CustomerInfo()
                                        {
                                            FirstName = consumerInfo.FirstName,
                                            LastName = consumerInfo.LastName,
                                            Address1 = consumerInfo.Address1,
                                            Address2 = consumerInfo.Address2,
                                            City = consumerInfo.City,
                                            State = consumerInfo.State,
                                            ZipCode = consumerInfo.ZipCode
                                        },
                                        StatementInfos = new List<StatementInfo>(),
                                        Product = paperStatementInfo.PortfolioKey == 2 ? EStatementProductType.WMT.ToString() : EStatementProductType.GDC.ToString()
                                    }
                                },
            };

            foreach (var statement in getAvailableStatementsResponse.Statements)
            {
                var statementInfo = new StatementInfo
                {
                    StatementDetailsToken = statement.StatementDetailsToken,
                    StatementStartDate = statement.StatementStartDate?.ToString("yyyy-MM-dd"),
                    StatementEndDate = statement.StatementEndDate?.ToString("yyyy-MM-dd")
                };
                generateMultipleEStatementRequest.EStatementDataList[0].StatementInfos
                    .Add(statementInfo);
            }

            var generateMultipleEStatementResponse =
                await _carePdfMergeApiRepository.GenerateMultipleEStatementAsync(
                    generateMultipleEStatementRequest);
            return generateMultipleEStatementResponse;
        }
    }
}
