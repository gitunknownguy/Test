﻿using AppSupportProcessor.Business.Activity;
using AppSupportProcessor.Business.LegacyApi;
using AppSupportProcessor.Common.Configuration;
using AppSupportProcessor.Common.Utilities;
using AppSupportProcessor.DataAccess.Repositories;
using AppSupportProcessor.Model.Consolidation;
using AppSupportProcessor.Model.DO;
using AppSupportProcessor.Model.Enum;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.Handlers
{
    public class ActivityHandler : BaseActivityHandler, IActivityHandler
    {
        public interface IActivityHandler
        {
            Task ProcessAsync(CancellationToken cancellationToken);
        }

        public ActivityHandler(
           INECNRTRepository nECNRTRepository,
           INECRepository necRepository,
           IProcessorTransmissionRepository processorTransmissionRepository,
           IAgreementRepository agreementRepository,
           IAccountManagementReposity accountManagementReposity,
           IFundTransferRepository  fundTransferRepository,
           ISavingsAccountServiceReposity savingsAccountServiceReposity,
           ICRMRepository crmRepository,
           ILogger<ActivityHandler> logger,
           IOptionsMonitor<ConsolidationConfiguration> config,
           ICache cache): 
            base(nECNRTRepository, necRepository, processorTransmissionRepository, agreementRepository, accountManagementReposity, 
               fundTransferRepository, savingsAccountServiceReposity, crmRepository,logger, cache, config)
        {
            
        }

        protected override Task<string> GetActionName()
        {
            return Task.FromResult("ActivityHandler");
        }

        protected override async Task<List<ConsolidationAccount>> GetConsolidationAccountAsync(List<short> productList)
        {
            var accounts = await _necNRTRepository.GetConsolidationAccountAsync((short)ConsolidationStatus.Initiated, productList, _config.ExecuteActivityBatchSize);

            return accounts;
        }

        protected override Task<short> GetConsolidationAccountStatusAsync(long consolidationAccountKey)
        {
            return Task.FromResult((short)ConsolidationStatus.Initiated);
        }

        protected override async Task<bool> PreCheckConsolidationAccountActivityAsync(ConsolidationAccount account, List<ConsolidationAccountActivity> activities)
        {
            if (activities.Where(a => a.ConsolidationActivityStatusKey == (short)ActivityStatus.Success).Count() == activities.Count())
            {
                _logger.LogInformation($"No pending activities found for account: {account.AccountKey}");
                await _necNRTRepository.UpdateConsolidationStatusAsync(account.ConsolidationAccountKey, (short)ConsolidationStatus.Initiated, (short)ConsolidationStatus.Success);
                return false;
            }

            if (activities.Select(a => a.ConsolidationActivityStatusKey).ToList().Contains((short)ActivityStatus.Failed))
            {
                _logger.LogInformation($"Failed activities found for account: {account.AccountKey}");
                await _necNRTRepository.UpdateConsolidationStatusAsync(account.ConsolidationAccountKey, (short)ConsolidationStatus.Initiated, (short)ConsolidationStatus.Failed);
                return false;
            }

            return true;
        }

        protected override Task<List<ConsolidationAccountActivity>> FilterConsolidationAccountActivityAsync(List<ConsolidationAccountActivity> activities)
        {
            return Task.FromResult(activities.Where(p => p.ConsolidationActivityStatusKey == (short)ActivityStatus.Pending).ToList());
        }

        protected override async Task HandlerConsolidationAccountActivityExceptionAsync(ConsolidationAccount account, ConsolidationAccountActivity activity)
        {
            await _necNRTRepository.UpdateConsolidationAccountActivityByConsolidationAccountActivityKeyAsync(activity.ConsolidationAccountActivityKey, (short)ActivityStatus.Failed, activity.ActivityDetail, activity.RetryCount); // Update status as failed

            await _necNRTRepository.UpdateConsolidationStatusAsync(account.ConsolidationAccountKey, (short)ConsolidationStatus.Initiated, (short)ConsolidationStatus.Failed);// Update status as failed
                       
        }

        protected override async Task UpdateConsolidationAccountActivityStatusAsync(ConsolidationAccountActivity activity)
        {
            await _necNRTRepository.UpdateConsolidationAccountActivityByConsolidationAccountActivityKeyAsync(activity.ConsolidationAccountActivityKey,
                        activity.ConsolidationActivityStatusKey, activity.ActivityDetail, activity.RetryCount); // Update status as success
        }
    }
}
