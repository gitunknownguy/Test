﻿using CardAccountTransactionService;
using AppSupportProcessor.Business.LegacyApi;
using AppSupportProcessor.Common.Configuration;
using AppSupportProcessor.DataAccess.DataAccesses;
using AppSupportProcessor.Model.LegacyApi;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AppSupportProcessor.DataAccess.DataAccesses.Models;
using CustomerInfo = AppSupportProcessor.Model.LegacyApi.CustomerInfo;
using Gd.Logging.Common;
using System.IO;

namespace AppSupportProcessor.Business.Handlers
{
    public interface IPaperStatementConfirmationHandler
    {
        Task ProcessAsync(CancellationToken cancellationToken);
    }

    public class PaperStatementConfirmationHandler : IPaperStatementConfirmationHandler
    {
        private IGdLogger<PaperStatementConfirmationHandler> _logger;
        private PaperStatementConfirmationConfiguration _config;

        public PaperStatementConfirmationHandler(
            IGdLogger<PaperStatementConfirmationHandler> logger,
            IOptionsMonitor<PaperStatementConfirmationConfiguration> config)
        {
            _logger = logger;
            _config = config.CurrentValue;
        }

        public async Task ProcessAsync(CancellationToken cancellationToken)
        {
            try
            {
                if (_config.Enabled)
                {
                    _logger.Info($"PaperStatementConfirmationHandler starts. ConfirmationReportFolder is {_config.ConfirmationReportFolder}");

                    if (!Directory.Exists(_config.ConfirmationReportFolder))
                    {
                        _logger.Info($"The folder {_config.ConfirmationReportFolder} does not exist.");
                        return;
                    }

                    string archiveFolder = Path.Combine(_config.ConfirmationReportFolder, "Archive");
                    if (!Directory.Exists(archiveFolder))
                    {
                        _logger.Info($"PaperStatementConfirmationHandler: The folder {archiveFolder} does not exist. Creating it now.");
                        Directory.CreateDirectory(archiveFolder);
                    }

                    string[] files = Directory.GetFiles(_config.ConfirmationReportFolder);
                    foreach (var file in files)
                    {
                        string fileName = Path.GetFileName(file);
                        string destinationFilePath = Path.Combine(archiveFolder, fileName);

                        _logger.Info($"Moving file from {file} to {destinationFilePath}");
                        File.Move(file, destinationFilePath, true);
                        _logger.Info("File moved successfully.");
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "PaperStatementConfirmationHandler-error: {message}, {@ex}", ex.Message, ex);
            }
        }
    }
}
