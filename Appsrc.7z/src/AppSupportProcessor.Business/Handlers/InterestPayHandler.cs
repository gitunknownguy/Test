﻿using AppSupportProcessor.Business.LegacyApi;
using AppSupportProcessor.Business.Logic;
using AppSupportProcessor.Common.Configuration;
using AppSupportProcessor.DataAccess.Repositories;
using AppSupportProcessor.Model.Interest;
using AppSupportProcessor.Model.LegacyApi;
using AutoMapper.Configuration.Annotations;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.Handlers
{
    public interface IInterestPayHandler
    {
        Task ProcessAsync(CancellationToken cancellationToken);
    }

    [ExcludeFromCodeCoverage]
    public class InterestPayHandler: IInterestPayHandler
    {
        private ILogger<InterestPayHandler> _logger;
        private InterestPayConfiguration _config;
        private readonly INECRepository _necRepository;
        private readonly INECNRTRepository _necNRTRepository;
        private readonly int InternalBatchSize = 50;
        private readonly int InterestTablekey = 71;
        private readonly IMMSDepositAccountRepository _mmsDepositAccountRepository;
        //todo add real transaction type here
        private readonly DetailAccountTransactionType TransactionType = DetailAccountTransactionType.InterestPayment;
        

        private readonly List<int> StatusToPay = new List<int> { 2, 5}; 
        private static readonly List<string> BadCreditRatings = new List<string>
         {
             "B4" ,"C5" ,"M9", "B3" ,  "B7" , "R1",  "B5", "B9" ,"F1" ,"P9"
        };

        public InterestPayHandler(
            INECRepository necRepository,
            INECNRTRepository nECNRTRepository,
            ILogger<InterestPayHandler> logger,
            IMMSDepositAccountRepository mmsDepositAccountRepository,
            IOptionsMonitor<InterestPayConfiguration> config)
        {
            _necRepository = necRepository;
            _logger = logger;
            _config = config.CurrentValue;
            _necNRTRepository = nECNRTRepository;
            _mmsDepositAccountRepository = mmsDepositAccountRepository;
        }


        public async Task ProcessAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("InterestPayHandler is running.");
            try
            {
                await BatchInterestPay();
                
            }
            catch (Exception ex)
            {
                _logger.LogError("InterestPayHandler-error: " + ex.ToString());
            }
            
        }

        async private Task BatchInterestPay()
        {
            //get calculated status payout rows.
            var calculatedPayouts = await _necNRTRepository.GetCalculatedDepositAccountInterestReimbursePayoutByBatch(_config.BatchSize);
            _logger.LogInformation("InterestPayHandler-info: " + "calculatedPayouts number is " + calculatedPayouts.Count);
            //get creditratings from nec
            var vaultAccountKeys = calculatedPayouts.Select(c => c.AccountKey).ToList();
            var customerInfos = await _necNRTRepository.GetDepositAccountMemberShipAndStatusByLinkedAccountKey(vaultAccountKeys);

            var logCustomerInfos = customerInfos.Select(c => new { c.AccountKey, c.CustomerKey, c.CreditRatingKey }).ToList();
            var logs = JsonConvert.SerializeObject(logCustomerInfos, Formatting.None);
            _logger.LogInformation("InterestPayHandler-info-customerinfo: " + logs);

            _logger.LogInformation("InterestPayHandler-info: " + "customerInfos number is " + customerInfos.Count);
            var updatedPayouts = new List<DepositAccountInterestReimbursePayout>();
            //call account transaction api for each row
            foreach (var calculatedPayout in calculatedPayouts)
            {
                updatedPayouts.Add(await PayInterest(calculatedPayout, customerInfos));
            }

            //update payout status by batch
            await _necNRTRepository.UpdateDepositAccountInterestReimbursePayoutForFunding(updatedPayouts);
            _logger.LogInformation("InterestPayHandler-info: " + "UpdateDepositAccountInterestReimbursePayoutForFunding success");

        }

        async Task<DepositAccountInterestReimbursePayout> PayInterest(DepositAccountInterestReimbursePayout calculatedPayout, List<CustomerMembership> customerInfos)
        {
            

            var toUpdatePayout = new DepositAccountInterestReimbursePayout
            {
                DepositAccountInterestReimbursePayoutKey = calculatedPayout.DepositAccountInterestReimbursePayoutKey
            };


            if (calculatedPayout.ExistingDepositAccountInterestPayoutStatusKey != 2)
            {
                //update payout with payskipped status
                toUpdatePayout.SetValueForPay((int)ReimbursementStatus.FundingSkipped, "Existing pay status is not 2");
                return toUpdatePayout;
            }

            var accountKey = calculatedPayout.AccountKey;

            //use 1 vault accountkey, we should find the customer credit rating key in nec database
            //var vaildCusotmer = customerInfos.Where(c => c.SerialNbr != null)
            //                              .OrderByDescending(c => c.CustomerKey)
            //                              .FirstOrDefault();

            var vaildCusotmer = customerInfos.Where(c => c.AccountKey == calculatedPayout.AccountKey && c.SerialNbr != null)
                                         .OrderByDescending(c => c.CustomerKey)
                                         .FirstOrDefault();

            if (vaildCusotmer == null)
            {
                toUpdatePayout.SetValueForPay((int)ReimbursementStatus.Failed, "customer not found");
                return toUpdatePayout;
            }

            _logger.LogInformation("InterestPayHandler-info: " + "valid customer key is " + vaildCusotmer.CustomerKey);

            if (BadCreditRatings.Contains(vaildCusotmer.CreditRatingKey))
            {
                //update payout with payskipped status
                toUpdatePayout.SetValueForPay((int)ReimbursementStatus.FundingSkipped, "bad credit rating");
                return toUpdatePayout;
            }

            //status = 5 picked by the sp, to check the value again
            if(!calculatedPayout.InterestReimburseAmount.HasValue ||
                calculatedPayout.InterestReimburseAmount.Value <= 0) 
            {
                //update payout with payskipped status
                toUpdatePayout.SetValueForPay((int)ReimbursementStatus.FundingSkipped, "interest amount is null or equal less than 0");
                return toUpdatePayout;
            }

            try {
                var transactionIdentifier = BuildTransactionIdentifier(calculatedPayout.DepositAccountInterestReimbursePayoutKey);
                //call vault credit API
                var legacyCreditRequest = new DepositAccountCreditRequest
                {
                    AccountKey = calculatedPayout.AccountKey,
                    Amount =  Math.Round(calculatedPayout.InterestReimburseAmount.Value,2),
                    DetailAccountTransactionType = DetailAccountTransactionType.InterestPayment, 
                    TransactionDescription = "interest",
                    TransactionIdentifier = transactionIdentifier,
                    IsAllowNegative = true,
                    SysUserKey = 10,
                    SystemComponentKey = 16,
                    ApplicationTypeKey = 1,

                    RequestId = Guid.NewGuid(),
                };
                var creditResult = await _mmsDepositAccountRepository.Credit(legacyCreditRequest);

                if (creditResult.IsSuccess)
                {
                    //update payout with success status
                    toUpdatePayout.SetValueForPay((int)ReimbursementStatus.FundingSuccess, "FundingSuccess", creditResult.AccountTransactionKey, DateTime.Now);
                    return toUpdatePayout;
                }

                var errorMessage = string.IsNullOrEmpty(creditResult.ErrorMessage) ? "ErrorOccurs" : creditResult.ErrorMessage.Substring(0, Math.Min(creditResult.ErrorMessage.Length, 200));
                //pay fail
                toUpdatePayout.SetValueForPay((int)ReimbursementStatus.FundingFail, errorMessage);
                return toUpdatePayout;

            }
            catch (Exception ex)
            {
                _logger.LogInformation("InterestPayHandler-error: " + ex.ToString());
                var exceptionMessage = ex.ToString().Substring(0, 200);
                toUpdatePayout.SetValueForPay((int)ReimbursementStatus.FundingFail, exceptionMessage);
                return toUpdatePayout;
            }
            
        }

        string BuildTransactionIdentifier(long reimburstmentPayoutKey)
        {
            return $"{reimburstmentPayoutKey}xDAIRP";
        }

    }
}
