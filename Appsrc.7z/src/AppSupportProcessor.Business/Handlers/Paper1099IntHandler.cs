﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AppSupportProcessor.Business.LegacyApi;
using AppSupportProcessor.Common.Configuration;
using AppSupportProcessor.DataAccess.DataAccesses;
using AppSupportProcessor.DataAccess.DataAccesses.Models;
using AppSupportProcessor.Model.LegacyApi;
using Gd.Logging.Common;
using Microsoft.Extensions.Options;
using NLog;
using CustomerInfo = AppSupportProcessor.Model.LegacyApi.CustomerInfo;

namespace AppSupportProcessor.Business.Handlers
{
    public interface IPaper1099IntHandler
    {
        Task ProcessAsync(CancellationToken cancellationToken);
    }

    public class Paper1099IntHandler : IPaper1099IntHandler
    {
        private IGdLogger<Paper1099IntHandler> _logger;
        private Paper1099IntConfiguration _config;
        private readonly ICarePDFMergeAPIRepository _carePdfMergeApiRepository;
        private readonly INrtDataAccess _nrtDataAccess;
        private readonly INecDataAccess _necDataAccess;

        public Paper1099IntHandler(
            ICarePDFMergeAPIRepository carePdfMergeApiRepository,
            INrtDataAccess nrtDataAccess,
            INecDataAccess necDataAccess,
            IGdLogger<Paper1099IntHandler> logger,
            IOptionsMonitor<Paper1099IntConfiguration> config)
        {
            _carePdfMergeApiRepository = carePdfMergeApiRepository;
            _logger = logger;
            _config = config.CurrentValue;
            _nrtDataAccess = nrtDataAccess;
            _necDataAccess = necDataAccess;
        }

        public async Task ProcessAsync(CancellationToken cancellationToken)
        {
            try
            {
                if (!_config.Enabled)
                {
                    _logger.Info("Paper1099IntHandler aborting because current env is not enabled.");
                    return;
                }

                await ProcessPaper1099Requests(cancellationToken, PaperTaxDocumentRequestStatus.Pending);
                await ProcessPaper1099Requests(cancellationToken, PaperTaxDocumentRequestStatus.Failed);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Paper1099IntHandler-error: {message}, {@ex}", ex.Message, ex);
            }
        }

        private async Task ProcessPaper1099Requests(CancellationToken cancellationToken, PaperTaxDocumentRequestStatus status)
        {
            _logger.Info("Paper1099IntHandler.ProcessPaper1099Requests start. BatchSize: {BatchSize}, the Paper1099Request status: {status}", _config.BatchSize, status.ToString());

            int retryCountIncrease = 0;
            if (status == PaperTaxDocumentRequestStatus.Failed)
            {
                retryCountIncrease = 1;
            }

            while (!cancellationToken.IsCancellationRequested)
            {
                var requests = await _nrtDataAccess.GetPaperTaxDocumentRequestList(_config.BatchSize, (short)status, retryCountIncrease);

                _logger.Info("Paper1099IntHandler.ProcessPaper1099Requests GetPaperTaxDocumentRequestList finished. The count of requests to be processed is {Count}.", requests.Count);

                if (requests.Count == 0)
                {
                    break;
                }

                List<ConsumerInfo> consumerInfos = await GetConsumerInfos(requests);

                _logger.Info("Paper1099IntHandler.ProcessPaper1099Requests GetConsumerInfos finished. The count of consumers is {Count}.", consumerInfos.Count);

                await ParallellyProcess(requests, consumerInfos);

                _logger.Info("Paper1099IntHandler.ProcessPaper1099Requests ParallellyProcess finished.");

                await _nrtDataAccess.UpdatePaperTaxDocumentRequest(requests);

                _logger.Info("Paper1099IntHandler.ProcessPaper1099Requests UpdatePaperTaxDocumentRequest finished.");
            }

            _logger.Info("Paper1099IntHandler.ProcessPaper1099Requests end.");
        }

        private async Task<List<ConsumerInfo>> GetConsumerInfos(List<PaperTaxDocumentRequest> requests)
        {
            var accountKeyInfos = requests.Select(o => new AccountKeyInfo()
            {
                AccountKey = o.AccountKey
            }).Distinct().ToList();
            var consumerInfos = await _necDataAccess.GetConsumerInfoByAccountKeys(accountKeyInfos);
            return consumerInfos;
        }

        public async Task ParallellyProcess(List<PaperTaxDocumentRequest> requests, List<ConsumerInfo> consumerInfos)
        {
            var semaphore = new SemaphoreSlim(25);
            var tasks = new List<Task>();

            foreach (var request in requests)
            {
                await semaphore.WaitAsync();

                tasks.Add(Task.Run(async () =>
                {
                    try
                    {
                        await ProcessPaperTaxDocumentRequest(request, consumerInfos);
                    }
                    finally
                    {
                        semaphore.Release();
                    }
                }));
            }
            await Task.WhenAll(tasks);
        }

        private async Task ProcessPaperTaxDocumentRequest(PaperTaxDocumentRequest request, List<ConsumerInfo> consumerInfos)
        {
            request.PaperTaxDocumentRequestStatusKey = (short)PaperTaxDocumentRequestStatus.Failed;
            if (request.RetryCount > 3)
            {
                request.PaperTaxDocumentRequestStatusKey = (short)PaperTaxDocumentRequestStatus.Expired;
            }

            var consumerInfo = consumerInfos.Find(o => o.AccountKey == request.AccountKey);
            if (consumerInfo == null)
            {
                _logger.Error("Customer Info cannot be found. The PaperTaxDocumentRequest is {@request}", request);

                CheckExpiredStatusAndLog(request);

                return;
            }

            if (string.IsNullOrWhiteSpace(request.DocumentPath))
            {
                _logger.Error("The 1099 int file path is empty. The PaperTaxDocumentRequest is {@request}", request);

                CheckExpiredStatusAndLog(request);

                return;
            }

            Guid requestId = Guid.NewGuid();
            ScopeContext.TryGetProperty("CorrelationId", out object correlationId);
            if (correlationId != null)
            {
                Guid.TryParse(correlationId.ToString(), out requestId);
            }
            
            var request1099Int = new GenerateLegacyPaper1099IntRequest()
            {
                RequestId = requestId,
                RequestHeader = new RequestHeader()
                {
                    RequestId = requestId.ToString()
                },
                AccountKey = request.AccountKey.ToString(),
                DocumentFullPath = request.DocumentPath,
                CustomerInfo = new CustomerInfo()
                {
                    FirstName = consumerInfo.FirstName,
                    LastName = consumerInfo.LastName,
                    State = consumerInfo.State,
                    City = consumerInfo.City,
                    ZipCode = consumerInfo.ZipCode,
                    Address1 = consumerInfo.Address1,
                    Address2 = consumerInfo.Address2
                }
            };
            var response = await _carePdfMergeApiRepository.GeneratePaper1099IntAsync(request1099Int);
            if (response != null && !string.IsNullOrWhiteSpace(response.DocumentFullPath))
            {
                request.PaperTaxDocumentRequestStatusKey = (short)PaperTaxDocumentRequestStatus.Completed;
                request.PaperTaxDocumentRequestPath = response.DocumentFullPath;
                return;
            }

            CheckExpiredStatusAndLog(request);
        }

        private void CheckExpiredStatusAndLog(PaperTaxDocumentRequest request)
        {
            if (request.PaperTaxDocumentRequestStatusKey == (short)PaperTaxDocumentRequestStatus.Expired)
            {
                _logger.Error("This request failed and expired. The PaperTaxDocumentRequest is {@request}", request);
            }
        }
    }
}
