﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Threading.Tasks;
using AppSupportProcessor.Model.LegacyApi;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace AppSupportProcessor.Business.WebApi
{
    [ExcludeFromCodeCoverage]
    public abstract class WebApiClientBase
    {
        private readonly ILogger<WebApiClientBase> _logManager;       
        private readonly JsonSerializerSettings _serializerSettings;
        private readonly JsonSerializer _serializer;

      
        protected WebApiClientBase(ILogger<WebApiClientBase> logManager )
        {
            _logManager = logManager;            
            _serializerSettings = new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore
            };
            _serializer = JsonSerializer.Create(_serializerSettings);
        }

        protected abstract HttpClient InnerHttpClient { get; }
        protected abstract string ApiBaseUrl { get;  }

        protected async Task<TResponse> CallService<TRequest, TResponse>(
            TRequest request,
            string apiUri,
            double apiTimeout,
            HttpMethod method,
            int retryCount = 0,
            Dictionary<string, string> headers = null)
            where TResponse : ResponseBase, new()
            where TRequest : RequestBase
        {
            var requestMessage = new HttpRequestMessage
            {
                RequestUri = new Uri(InnerHttpClient.BaseAddress + apiUri),
                Method = method
            };

            if(headers != null)
            {
                foreach (var header in headers)
                {
                    requestMessage.Headers.Add(header.Key, header.Value);
                }
            }

            // create request message content to send
            requestMessage.Content = new StringContent(JsonConvert.SerializeObject(request, _serializerSettings), System.Text.Encoding.UTF8,
            "application/json");

            _logManager.LogInformation($"Calling {requestMessage.RequestUri} Method: {requestMessage.Method} Content: {requestMessage.Content} RequestId:{request.RequestId}");
            _logManager.LogInformation($"InterestPayHandler—mmsurl {InnerHttpClient.BaseAddress}");
            try
            {
                using (var cts = new CancellationTokenSource(TimeSpan.FromMilliseconds(apiTimeout)))
                {
                    using (var response = await InnerHttpClient.SendAsync(requestMessage, cts.Token))
                    {
                        
                        // check status code to know if response needs to be cut short
                        if (response?.StatusCode == HttpStatusCode.InternalServerError ||
                            response?.StatusCode == HttpStatusCode.BadRequest ||
                            response?.StatusCode == HttpStatusCode.ServiceUnavailable ||
                            response?.StatusCode == HttpStatusCode.NotFound ||
                            response?.StatusCode == HttpStatusCode.Unauthorized)
                        {
                            return await Task.FromResult(new TResponse
                            {
                                ErrorCode = ((int)response.StatusCode).ToString(),
                                ErrorMessage = response.StatusCode.ToString()
                            });
                        }

                        //if (response?.Content == null)
                        //{
                        //    throw new Exception($"Error occurred receiving response from service calling {apiUri}");
                        //}

                        using (var reader = new System.IO.StreamReader(await response.Content.ReadAsStreamAsync()))
                        using (var jsonReader = new JsonTextReader(reader))
                        {
                            return _serializer.Deserialize<TResponse>(jsonReader);
                        }
                    }
                }
            }
            catch (Exception requestException)
            {
                _logManager.LogError($"InterestPayHandler-{request.RequestId.ToString()} ,{requestException}");

                throw;
            }
        }


        protected async Task<TransferResponse> CallService(
            TransferRequest request,
            string apiUri,
            double apiTimeout,
            HttpMethod method,
            int retryCount = 0)
        {
            var requestMessage = new HttpRequestMessage
            {
                RequestUri = new Uri(InnerHttpClient.BaseAddress + apiUri),
                Method = method
            };

            // create request message content to send
            requestMessage.Content = new StringContent(JsonConvert.SerializeObject(request, _serializerSettings), System.Text.Encoding.UTF8,
            "application/json");

            _logManager.LogInformation($"Calling {requestMessage.RequestUri} Method: {requestMessage.Method} Content: {requestMessage.Content} ");
            _logManager.LogInformation($"TransferVault- {InnerHttpClient.BaseAddress}");
            try
            {
                using (var cts = new CancellationTokenSource(TimeSpan.FromMilliseconds(apiTimeout)))
                {
                    using (var response = await InnerHttpClient.SendAsync(requestMessage, cts.Token))
                    {

                        // check status code to know if response needs to be cut short
                        if (response?.StatusCode == HttpStatusCode.InternalServerError ||
                            response?.StatusCode == HttpStatusCode.BadRequest ||
                            response?.StatusCode == HttpStatusCode.ServiceUnavailable ||
                            response?.StatusCode == HttpStatusCode.NotFound ||
                            response?.StatusCode == HttpStatusCode.Unauthorized)
                        {
                            return await Task.FromResult(new TransferResponse
                            {
                                ResponseCode = TransferResponseCode.GeneralSystemException,
                                ErrorCode = ((int)response.StatusCode).ToString(),
                                ErrorMessage = response.StatusCode.ToString()
                            });
                        }

                        using (var reader = new System.IO.StreamReader(await response.Content.ReadAsStreamAsync()))
                        using (var jsonReader = new JsonTextReader(reader))
                        {
                            return _serializer.Deserialize<TransferResponse>(jsonReader);
                        }
                    }
                }
            }
            catch (Exception requestException)
            {
                _logManager.LogError($"{requestException}");

                throw;
            }
        }
    }
}
