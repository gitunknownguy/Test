﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Business.WebApi
{
    public static class ChannelExtensions
    {
        public static void CloseChannel(this ICommunicationObject channel, ILogger logger)
        {
            try
            {
                channel.Close();
            }
            catch (CommunicationException ex)
            {
                logger.LogError($"CommunicationException thrown while trying to close a channel", null);
                channel.Abort();
            }
            catch (TimeoutException ex)
            {
                logger.LogError($"TimeoutException thrown while trying to close a channel", null);
                channel.Abort();
            }
            catch (Exception ex)
            {
                logger.LogError($"Exception thrown while trying to close a channel", null);
                channel.Abort();
                throw;
            }
        }
    }
}
