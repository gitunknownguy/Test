﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.Consolidation
{
    public class FamilyAccount
    {
        public int PrimaryAccountKey { get; set; }
        public int SecondaryAccountKey { get; set; }
        public short ProductKey { get; set; }
        public string CreditRatingKey { get; set; }
    }
}
