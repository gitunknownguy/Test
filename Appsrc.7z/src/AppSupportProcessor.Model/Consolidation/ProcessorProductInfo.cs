﻿

namespace AppSupportProcessor.Model.Consolidation
{
    public class ProcessorProductInfo
    {
        public short ProductKey { get; set; }

        public short ProcessorProductKey { get; set; }

        public string ProcessorProduct { get; set; }

        public short ProcessorProductTypeKey { get; set; }
    }
}
