﻿using AppSupportProcessor.Model.DO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.Consolidation
{
    public class Constants
    {
        public const int DepositAccountAgreementKey = 6;
        public const int SavingsAccountInterestAgreementKey = 32;
        public const int W9CertificationAgreementKey = 33;
        public const int SavingsAccountAgreementKey = 5;
        
        public const short SavingsInterestSubscriptionTypeKey = 34;
        public const short VIPSubscriptionTypeKey = 6;
    }
}
