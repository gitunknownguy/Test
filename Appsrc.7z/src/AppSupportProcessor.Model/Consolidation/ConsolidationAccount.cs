﻿using AppSupportProcessor.Model.Enum;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.Consolidation
{
    [ExcludeFromCodeCoverage]
    public class ConsolidationAccount
    {
        public long ConsolidationAccountKey { get; set; }
        public int AccountKey { get; set; }
        public short ProductKey { get; set; }
        public int CustomerKey { get; set; }
        public string CardReference { get; set; }
        public short ConsolidationStatusKey { get; set; }
        public short ConsolidationGroupKey { get; set; }
        public long ConsolidationAccountFileKey { get; set; }
        public short LinkedProductKey { get; set; }
        public short TargetProductKey { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class ConsolidationAccountCompare : IEqualityComparer<ConsolidationAccount>
    {
        public bool Equals(ConsolidationAccount x, ConsolidationAccount y)
        {
            if (x.AccountKey == y.AccountKey)
                return true;
            else
                return false;
        }
        public int GetHashCode(ConsolidationAccount obj)
        {
            return obj.AccountKey.GetHashCode();
        }
    }
}
