﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.Consolidation
{
    [ExcludeFromCodeCoverage]
    public class ConsolidationAccountActivity
    {
        public long ConsolidationAccountActivityKey { get; set; }
        public long ConsolidationAccountKey { get; set; }
        public short ConsolidationActivityKey { get; set; }
        public short ConsolidationActivityStatusKey { get; set; }
        public string ActivityDetail { get; set; }
        public short RetryCount { get; set; }
        public DateTime ChangeDate { get; set; }
    }
}
