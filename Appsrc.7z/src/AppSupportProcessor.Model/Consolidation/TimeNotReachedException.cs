﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.Consolidation
{
    public class TimeNotReachedException: Exception
    {
        public TimeNotReachedException(): base() { }
        public TimeNotReachedException(string message): base(message)
        {
        }
    }
}
