﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.Consolidation
{
    public class AccountSubscription
    {
        public short SubscriptionKey    { get; set; }
        public short SubscriptionTypeKey { get; set; }
        public string ShortName { get; set; }
        public string Subscription    { get; set; }
    }
}
