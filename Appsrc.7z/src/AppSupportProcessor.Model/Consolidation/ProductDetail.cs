﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.Consolidation
{
    public class ProductDetail
    {
        public short ProductKey { get; set; }
        public string BankCode { get; set; }
        public short AssocKey { get; set; }
        public short BinKey { get; set; }
        public string BinType { get; set; }
    }
}
