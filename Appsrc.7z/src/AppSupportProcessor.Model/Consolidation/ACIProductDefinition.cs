﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.Consolidation
{
    public class ACIProductDefinition
    {
        public string ACIProductID { get; set; }
        public string ACIAccountType { get; set; }
        public string ACIPaymentDeviceID { get; set; }
        public string ACIDeviceStyleID { get; set; }
        public string ACICreditCheckDefinitionID { get; set; }
        public int ProductKey { get; set; }
        public int ProcessorProductKey { get; set; }
        public string BIN { get; set; }
        public bool? IsDefaultBIN { get; set; }
        public int ProcessorProductTypeKey { get; set; }
    }
}
