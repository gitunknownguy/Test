﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace AppSupportProcessor.Model.Consolidation
{
    [ExcludeFromCodeCoverage]
    public class AccountBalanceInfo
    {
        public decimal AvailableBalance { get; set; }
        public DateTime AvailableBalanceLastUpdated { get; set; }
        public decimal CurrentBalance { get; set; }
        public DateTime CurrentBalanceLastUpdated { get; set; }
    }
}
