﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.Consolidation
{
    public class PlasticInfo
    {
        public int CardKey { get; set; }
        public short ProductKey { get; set; }
        public bool IsPersonalized { get; set; }
        public bool IsActive { get; set; }
        public bool IsEmv { get; set; }
        public string SerialNbr { get; set; }
        public string BankCode { get; set; }
        public short AssocKey { get; set; }
        public Guid CardReferenceID { get; set; }
        public bool HasCRV { get; set; }
        public string CardReference { get; set; }
        public DateTime CardActivationDate { get; set; }
    }
}
