﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.Consolidation
{
    public class AccountDetail
    {
        public int Accountkey { get; set; }
        public int CustomerKey { get; set; }
        public string CreditRatingKey { get; set; }
        public short MembershipKey { get; set; }
        public short MembershipTypeKey { get; set; }
    }
}
