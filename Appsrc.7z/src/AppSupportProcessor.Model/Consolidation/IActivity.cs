﻿using AppSupportProcessor.Model.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.Consolidation
{
    public interface IActivity 
    {
        //long ActivityKey { get; set; }
        //short ActivityType { get; set; }
        //ActivityStatus Status { get; set; }
        //string ActivityName { get; set; }
        int Priority { get; }
        //string ActivityDetails { get; set; }
        ConsolidationAccount Account { get; set; }
        ConsolidationAccountActivity AccountActivity { get; set; }
        Task ExecuteAsync();
    }
}
