﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.Consolidation
{
    public class AccountCustomerBillCycle
    {
        public DateTime? AccountFirstBillCycleDate { get; set; }
        public short? AccountBillCycleDay { get; set; }
        public DateTime? CustomerFirstBillCycleDate { get; set; }
        public short? CustomerBillCycleDay { get; set; }
    }
}
