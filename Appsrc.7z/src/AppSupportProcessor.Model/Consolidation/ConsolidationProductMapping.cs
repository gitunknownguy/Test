﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.Consolidation
{
    public class ConsolidationProductMapping
    {
        public short SourceProductKey { get; set; }
        public short TargetProductKey { get; set; }
        public short SourceMembershipGroupKey { get; set; }
        public short TargetMembershipGroupKey { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public short MembershipKey { get; set; }
        public short MembershipTypeKey { get; set; }
        public DateTime StartActivationDate { get; set; }
        public DateTime EndActivationDate { get; set; }

    }
}
