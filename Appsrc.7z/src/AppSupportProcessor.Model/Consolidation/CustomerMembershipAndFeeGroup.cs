﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.Consolidation
{
    public class CustomerMembershipAndFeeGroup
    {
        public int CustomerMembershipKey { get; set; }
        public int MembershipKey { get; set; }
        public int MembershipGroupKey { get; set; }
        public short MembershipTypeKey { get; set; }
        public int FeeGroupKey { get; set; }
        public int CustomerFeeGroupKey { get; set; }
        public int Account_FeeGroupKey { get; set; }
        public int FeeWaiverGroupKey { get; set; }
        public int Customer_FeeWaiverGroupKey { get; set; }

    }
}
