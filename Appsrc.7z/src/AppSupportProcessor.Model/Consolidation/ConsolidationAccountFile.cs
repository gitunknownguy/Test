﻿using System.Diagnostics.CodeAnalysis;

namespace AppSupportProcessor.Model.Consolidation
{
    [ExcludeFromCodeCoverage]
    public class ConsolidationAccountFile
    {
        public long ConsolidationAccountFileKey{ get;set;}
        public string ConsolidationFileName { get; set; }
        public string ConsolidationFilePath { get; set; }
        public short ConsolidationFileStatusKey { get; set; }
        public string ConsolidationFileArchivedPath { get; set; }
    }
}
