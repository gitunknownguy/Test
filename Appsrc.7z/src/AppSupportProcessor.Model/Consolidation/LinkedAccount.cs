﻿using System.Diagnostics.CodeAnalysis;

namespace AppSupportProcessor.Model.Consolidation
{
    [ExcludeFromCodeCoverage]
    public class LinkedAccount
    {
        public int PrimaryAccountKey { get; set; }
        public int LinkedAccountKey { get; set; }
        public bool IsActive { get; set; }
        public decimal AvailableBalance { get; set; }

    }
}
