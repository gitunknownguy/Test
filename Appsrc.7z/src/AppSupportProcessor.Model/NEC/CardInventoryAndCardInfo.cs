﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace AppSupportProcessor.Model.NEC
{
    [ExcludeFromCodeCoverage]
    public class CardInventoryAndCardInfo
    {
        public Guid CardReferenceID { get; set; }
        public int CardInventoryStatusKey { get; set; }
        public int CardStatusKey { get; set; }
        public int CustomerKey { get; set; }
        public int AccountKey { get; set; }
        public int Cardkey { get; set; }

        public DateTime? CardExpDate{get;set;}
    }
}
