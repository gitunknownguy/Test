﻿using System;

namespace AppSupportProcessor.Model.NEC
{
    public class ManualFeeWaiverStatus
    {
        public int CustomerKey { get; set; }
        public DateTime StartWaiveDate { get; set; }
        public DateTime EndWaiveDate { get; set; }
        public short FeeWaiverKey { get; set; }
        public DateTime CreateDate { get; set; }
    }
}
