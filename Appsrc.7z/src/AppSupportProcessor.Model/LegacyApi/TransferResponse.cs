﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.LegacyApi
{
    public class TransferResponse
    {
        public string ErrorCode { get; set; }
        public string ErrorMessage { get; set; }
        public int TransferKey { get; set; }
        public decimal SourceAccountBalance { get; set; }
        public decimal TargetAccountBalance { get; set; }
        public TransferStatus TransferStatus { get; set; }
        public TransferResponseCode ResponseCode { get; set; }
        public string ResponseText { get; set; }
    }

    public enum TransferStatus
    {

        Initiated = 1,

        Posted = 2,

        Declined = 3,

        Pending = 4,

        PendingFunding = 5
    }

    public enum TransferResponseCode
    {
        Success = 0,

        InvalidParameter = 1,

        Declined = 2,

        AmountLessThanZero = 3,

        LowBalance = 4,

        AccountsNotLinked = 5,

        CardToCardTransferNotAllowed = 6,

        SavingToSavingTransferNotAllowed = 7,

        SavingAccountStatusInvalid = 8,

        InvalidTransferType = 9,

        AccountFundTransferInsertFailed = 10,

        CardAccountCreditDeclined = 11,

        CardAccountDebitDeclined = 12,

        SavingsAccountCreditDeclined = 13,

        SavingsAccountDebitDeclined = 14,

        CardLoadLimitExceeded = 15,

        SavingsAccountTransactionLimitExceeded = 16,

        ExceededTransferInboundLimit = 21,

        ExceededTransferDailyOutMax = 22,

        ExceededTransferDailyOutMaxExternal = 23,

        ExceededTransferMonthlyOutMaxExternal = 24,

        InvalidAmountToTransfer = 26,

        ExceededAccountAvailableBalance = 27,

        ExceededTransferDailyOutMin = 28,

        ExceededAccountBalanceLimit = 29,

        CardAccountStatusSpendDown = 30,

        ExceededTransferDailyLimit = 31,

        SystemUnavailable = 100,

        OperationNotAllowed = 200,

        OperationNotImplemented = 210,

        ProviderSystemException = 500,

        RetrieveAccountStatusFailed = 501,

        AssociatedCardsNotFound = 502,

        AccountAPIErrorResponse = 503,

        CreditRatingBlocked = 504,

        TransTypeKeyNotFound = 505,

        FundAcctTypeKeyNotFound = 506,

        CardServiceGetCardFailed = 507,

        AssociatedPrimaryActiveCardsNotFound = 508,

        PurseServiceTransactionDeclined = 509,

        GeneralSystemException = 1000
    }
}
