﻿using System;
using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace AppSupportProcessor.Model.LegacyApi
{
    [ExcludeFromCodeCoverage]
    public class RequestBase
    {
        [JsonProperty("requestid")]
       public Guid RequestId { get; set; }
    }
}
