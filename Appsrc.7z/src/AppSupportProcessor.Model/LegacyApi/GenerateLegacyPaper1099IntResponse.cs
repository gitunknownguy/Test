﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace AppSupportProcessor.Model.LegacyApi
{
    [ExcludeFromCodeCoverage]
    public class GenerateLegacyPaper1099IntResponse : ResponseBase
    {
        [JsonProperty("responseHeader")]
        public ResponseHeader ResponseHeader { get; set; }
        [JsonProperty("documentFullPath")]
        public string DocumentFullPath { get; set; }
    }

    public class ResponseHeader
    {
        [JsonProperty("responseId")]
        public string ResponseId { get; set; }

        [JsonProperty("statusCode")]
        public int StatusCode { get; set; }

        [JsonProperty("subStatusCode")]
        public int SubStatusCode { get; set; }

        [JsonProperty("statusMessage")]
        public string StatusMessage { get; set; }

        [JsonProperty("details")]
        public string DetailsMessage { get; set; }
    }
}
