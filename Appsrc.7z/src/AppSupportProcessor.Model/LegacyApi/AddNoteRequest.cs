﻿using System.Diagnostics.CodeAnalysis;

namespace AppSupportProcessor.Model.LegacyApi
{
    [ExcludeFromCodeCoverage]
    public class AddNoteRequest:RequestBase
    {
        public NoteTypeEnum Type { get; set; }
        public int TablePk { get; set; }
        public string Note { get; set; }
        public string UserToken { get; set; }
    }

    public enum NoteTypeEnum
    {
        All = 0,
        Account = 24,
        ProdConsolidate = 57
    }
}
