﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.LegacyApi
{
    [ExcludeFromCodeCoverage]
    public class DepositAccountCreditResponse : ResponseBase
    {
        public long AccountTransactionKey { get; set; }

        public decimal Balance { get; set; }

        public AccountTransactionStatus AccountTransactionStatus { get; set; }

        public AccountTransactionDeclineReason AccountTransactionDeclineReason { get; set; }


        public bool IsSuccess
        {
            get
            {
                if (ErrorCode != default(int).ToString() ||
                    AccountTransactionKey.Equals(default(long)) ||
                    AccountTransactionStatus != AccountTransactionStatus.Posted)
                {
                    return false;
                }

                return true;
            }
        }
    }
    public enum AccountTransactionDeclineReason
    {
        None = 0,
        InsufficientFund = 1,
        SystemException = 2,
        TransactionCountLimitForDebitExceeded = 3,
        CreditRatingBlocked = 4
    }
    public enum AccountTransactionStatus
    {
        None = 0,
        Initiated = 1,
        Pending = 2,
        Posted = 3,
        Declined = 4
    }
}
