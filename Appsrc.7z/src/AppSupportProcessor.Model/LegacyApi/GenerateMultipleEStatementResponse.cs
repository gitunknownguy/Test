﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace AppSupportProcessor.Model.LegacyApi
{
    [ExcludeFromCodeCoverage]
    public class GenerateMultipleEStatementResponse : ResponseBase
    {
        [JsonProperty("responseId")]
        public string ResponseId { get; set; }
        [JsonProperty("eStatementResultList")]
        public List<EStatementResult> EStatementResultList { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class EStatementResult
    {
        [JsonProperty("AccountKey")]
        public string AccountKey { get; set; }
        [JsonProperty("StatementFileName")]
        public string StatementFileName { get; set; }
        [JsonProperty("statusCode")]
        public string StatusCode { get; set; }
        [JsonProperty("subStatusCode")]
        public string SubStatusCode { get; set; }
        [JsonProperty("statusMessage")]
        public string StatusMessage { get; set; }
        [JsonProperty("detailsMessage")]
        public string DetailsMessage { get; set; }
        [JsonProperty("filePath")]
        public string FilePath { get; set; }
        [JsonProperty("archiveFilePath")]
        public string ArchiveFilePath { get; set; }
    }
}
