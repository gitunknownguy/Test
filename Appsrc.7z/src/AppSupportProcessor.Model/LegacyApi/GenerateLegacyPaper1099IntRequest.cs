﻿using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace AppSupportProcessor.Model.LegacyApi
{
    [ExcludeFromCodeCoverage]
    public class GenerateLegacyPaper1099IntRequest : RequestBase
    {
        [JsonProperty("requestHeader")]
        public RequestHeader RequestHeader { get; set; }
        [JsonProperty("accountKey")]
        public string AccountKey { get; set; }
        [JsonProperty("customerInfo")]
        public CustomerInfo CustomerInfo { get; set; }
        [JsonProperty("documentFullPath")]
        public string DocumentFullPath { get; set; }
    }
}
