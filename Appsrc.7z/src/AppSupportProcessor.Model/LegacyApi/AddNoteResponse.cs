﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.LegacyApi
{
    [ExcludeFromCodeCoverage]
    public class AddNoteResponse:ResponseBase
    {
        public int NoteKey { get; set; }
    }
}
