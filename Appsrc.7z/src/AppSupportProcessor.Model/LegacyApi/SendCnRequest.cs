﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.LegacyApi
{
    [ExcludeFromCodeCoverage]
    public class SendCnRequest: RequestBase
    {
        public string AccountIdentifier { get; set; }
        public string ConsumerIdentifier { get; set; }
        public bool IsRuleEvaluated { get; set; }
        public string NotificationRequestIdentifier { get; set; }
        public string NotificationTypeToken { get; set; }
        public int BrandIdentifier { get; set; }
        public string ProductToken { get; set; }
        public string ProductDefinitionToken { get; set; }
        public string PortfolioToken { get; set; }
        public List<NotificationAttribute> Attributes { get; set; }
        public List<CnContact> Contacts { get; set; }
        public bool IsRetry { get; set; } = false;
    }

    [ExcludeFromCodeCoverage]
    public class NotificationAttribute
    {
        public string NotificationAttributeKey { get; set; }
        public string NotificationAttributeName { get; set; }
        public string NotificationAttributeValue { get; set; }
        public bool isSystemDefined { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class CnContact
    {
        public string ContactName { get; set; }
        public int ChannelType { get; set; }
    }
}
