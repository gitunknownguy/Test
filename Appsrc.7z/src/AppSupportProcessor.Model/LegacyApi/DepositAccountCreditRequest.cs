﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.LegacyApi
{
    [ExcludeFromCodeCoverage]
    public class DepositAccountCreditRequest : RequestBase
    {
        [Required]
        public int AccountKey { get; set; }

        [Required(ErrorMessage = "Amount is Required")]
        [DataType(DataType.Currency)]
        public decimal Amount { get; set; }

        [Required]
        public DetailAccountTransactionType DetailAccountTransactionType { get; set; }

        [Required(ErrorMessage = "TransactionDescription is Required")]
        public string TransactionDescription { get; set; }

        public string TransactionIdentifier { get; set; }

        public bool IsAllowNegative { get; set; }

        public int SysUserKey { get; set; }
        public int SystemComponentKey { get; set; }
        public int ApplicationTypeKey { get; set; }
    }


    public enum DetailAccountTransactionType
    {
        [DataMember]
        None = 0,

        [DataMember]
        TransferFromDepositAccount = 1,

        [DataMember]
        TransferToDepositAccount = 2,

        [DataMember]
        InterestPayment = 5,

        [DataMember]
        DepositAccountRefund = 6,

        [DataMember]
        CreditAdjustments = 15,

        [DataMember]
        DepositAccountSpendDown = 177,

        [DataMember]
        DepositAccountSpendDownToCard = 178
    }
}
