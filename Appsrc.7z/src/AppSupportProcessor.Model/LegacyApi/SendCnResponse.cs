﻿using System.Diagnostics.CodeAnalysis;

namespace AppSupportProcessor.Model.LegacyApi
{
    [ExcludeFromCodeCoverage]
    public class SendCnResponse: ResponseBase
    {
        public CNResponseCode ResponseCode { get; set; }
        public string ResponseText { get; set; }
        public string NotificationRequestIdentifier { get; set; }
    }

    
    public enum CNResponseCode
    {
        #region Generic        
        None = 0,
        Success = 1,
        Timeout = 2,
        SystemException = 3,

        #endregion

        #region "Notification Core APi codes"
        NoMatch = 4,
        NotEligible = 5,
        NeedLastFour = 6,
        //  NoMatchFoundWithLastFour =7,
        InvalidRequest = 8,
        // PhoneNumberMissing = 9,

        #endregion

        #region NotifyApiResponsecodes
        RabbitMQError = 9,
        DatabaseError = 10
        #endregion
    }
}
