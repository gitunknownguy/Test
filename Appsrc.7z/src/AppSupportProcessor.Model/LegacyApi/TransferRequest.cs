﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.LegacyApi
{
    public class TransferRequest
    {
        public TransferInfo TransferInfo { get; set; }

        public int SysUserKey { get; set; }

        public short SystemComponentKey { get; set; }

        public short ApplicationTypeKey { get; set; }
    }

    public class TransferInfo
    {
        public int SourceAccountKey { get; set; }

        public int TargetAccountKey { get; set; }

        public decimal Amount { get; set; }

        public string Description { get; set; }
        public TransferType TransferType { get; set; }
    }

    public enum TransferType
    {
        CardToSavings = 1,

        SavingsToCard = 2,

        SavingsRefundToCard = 5,

        CardToCard = 8,

        SavingsSpendDownToCard = 9
    }
}
