﻿using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace AppSupportProcessor.Model.LegacyApi
{
    /// <summary>
    /// Base response header required in all responses
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class ResponseBase
    {
        [JsonProperty("errorCode")]
        public string ErrorCode { get; set; }

        [JsonProperty("errorMessage")]
        public string ErrorMessage { get; set; }    
    }
}
