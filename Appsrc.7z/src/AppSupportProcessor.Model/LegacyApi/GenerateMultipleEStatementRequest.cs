﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace AppSupportProcessor.Model.LegacyApi
{
    [ExcludeFromCodeCoverage]
    public class GenerateMultipleEStatementRequest : RequestBase
    {
        [JsonProperty("requestHeader")]
        public RequestHeader RequestHeader { get; set; }
        [JsonProperty("eStatementDataList")]
        public List<EStatementData> EStatementDataList { get; set; }

    }

    [ExcludeFromCodeCoverage]
    public class EStatementData
    {
        [JsonProperty("accountKey")]
        public string AccountKey { get; set; }

        [JsonProperty("statementInfos")]
        public List<StatementInfo> StatementInfos { get; set; }

        [JsonProperty("customerInfo")]
        public CustomerInfo CustomerInfo { get; set; }

        [JsonProperty("product")]
        public string Product { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class StatementInfo
    {
        [JsonProperty("statementDetailsToken")]
        public string StatementDetailsToken { get; set; }
        [JsonProperty("statementStartDate")]
        public string StatementStartDate { get; set; }
        [JsonProperty("statementEndDate")]
        public string StatementEndDate { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class CustomerInfo
    {
        [JsonProperty("firstName")]
        public string FirstName { get; set; }
        [JsonProperty("lastName")]
        public string LastName { get; set; }
        [JsonProperty("address1")]
        public string Address1 { get; set; }
        [JsonProperty("address2")]
        public string Address2 { get; set; }
        [JsonProperty("city")]
        public string City { get; set; }
        [JsonProperty("state")]
        public string State { get; set; }
        [JsonProperty("zipCode")]
        public string ZipCode { get; set; }
    }
}
