﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace AppSupportProcessor.Model.AutoOrderCard
{
    [ExcludeFromCodeCoverage]
    public class TsysQueueRequest
    {
        public int TSysQueueKey { get; set; }
        public DateTime? ResponseDate { get; set; }
        public short? TSysResponseCodeKey { get; set; }

    }
}
