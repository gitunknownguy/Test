﻿using System.Diagnostics.CodeAnalysis;

namespace AppSupportProcessor.Model.AutoOrderCard
{
    [ExcludeFromCodeCoverage]
    public class EmailInfo
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public bool IsPrimary { get; set; }
        public short EmailTypeKey { get; set; }
    }
}
