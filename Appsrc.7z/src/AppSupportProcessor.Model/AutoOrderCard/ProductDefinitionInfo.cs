﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.AutoOrderCard
{
    [ExcludeFromCodeCoverage]
    public class ProductDefinitionInfo
    {
        public short ProductKey { get; set; }
        public short ProductDefinitionKey { get; set; }
        public short PortfolioKey { get; set; }
    }
}
