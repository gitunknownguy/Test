﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.AutoOrderCard
{
    public enum AutoOrderCardAccountStatus
    {
        Pending=1,
        Failed=2,
        Complete=3,
        Skipped=4,
        Stopped=5
    }
}
