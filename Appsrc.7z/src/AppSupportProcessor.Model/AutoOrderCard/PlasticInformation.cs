﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace AppSupportProcessor.Model.AutoOrderCard
{
    [ExcludeFromCodeCoverage]
    public class PlasticInformation
    {
        public int CardKey { get; set; }
        public string CardReference { get; set; }
        public Guid? CardReferenceID { get; set; }
        public int? CustomerKey { get; set; }
        public short? CardStatusKey { get; set; }
        public int PlasticKey { get; set; }
        public bool IsPersonalized { get; set; }
        public bool HasCRV { get; set; }
        public bool IsActive { get; set; }
        public bool? IsEMV { get; set; }
    }
}
