﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace AppSupportProcessor.Model.AutoOrderCard
{
    [ExcludeFromCodeCoverage]
    public class AutoOrderCardAccount
    {
        public long AutoOrderCardAccountKey { get; set; }
        public int AccountKey { get; set; }
        public int CustomerKey { get; set; }
        public short AutoOrderCardAccountStatusKey { get; set; }
        public string AutoOrderCardAccountStatusReason { get; set; }

        public DateTime CreateDate { get; set; }
        public DateTime ChangeDate { get; set; }
        public string ChangeBy { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class AutoOrderCardAccountCompare : IEqualityComparer<AutoOrderCardAccount>
    {
        public bool Equals(AutoOrderCardAccount x, AutoOrderCardAccount y)
        {
            if (x.AccountKey == y.AccountKey)
                return true;
            else
                return false;
        }
        public int GetHashCode(AutoOrderCardAccount obj)
        {
            return obj.AccountKey.GetHashCode();
        }
    }
}
