﻿using System.Diagnostics.CodeAnalysis;

namespace AppSupportProcessor.Model.AutoOrderCard
{
    [ExcludeFromCodeCoverage]
    public class CreditRatingInfo
    {
        public string CreditRatingKey { get; set; }
    }
}
