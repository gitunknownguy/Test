﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.Enum
{
    public enum AccountClosureRequestStatus
    {
        FileImporting = 1,
        FileImported = 2,
        ValidationCompleted = 3,
        FileSentToACI = 4,
        RecievedACIReportFile = 5,
    }
}
