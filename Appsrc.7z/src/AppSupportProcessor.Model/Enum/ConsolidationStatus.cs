﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.Enum
{
    public enum ConsolidationStatus
    {
        Pending = 1,
        Eligible = 2,
        NotEligible = 3,
        Initiated=4,
        Success=5,
        Failed=6,
        Expired=7
    }
}
