﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.Enum
{
    public enum ConsolidationType
    {
        WMMC=1,
        GD=2,
    }
}
