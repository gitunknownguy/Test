﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.Enum
{
    public enum WorkflowActivity
    {
        UpdateProductInACI=1,
        AddDAAAgreement=2,
        UpdateProductAndMembershipinDB=3,
        CreateSavingAccount=4,
        AddSAAAgreement=5,
        AddSavinginterestingAgreement=6,
        AddSavingInterestSubscription=7,
        TransferVaultBalance=8,
        AddCRMNote=9,
        SetBillCycleDay= 11,
        RemoveVIPSubscription=12,

    }
}
