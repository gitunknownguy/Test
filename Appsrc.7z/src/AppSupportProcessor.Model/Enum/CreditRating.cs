﻿namespace AppSupportProcessor.Model.Enum
{
    public enum CreditRating
    {
        C5,
        B4,
        M9,
        P9,
        B5
    }
}
