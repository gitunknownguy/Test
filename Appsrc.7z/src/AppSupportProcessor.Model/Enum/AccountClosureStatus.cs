﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.Enum
{
    public enum AccountClosureStatus
    {
        Pending = 1,
        NotEgilible = 2,
        Egilible = 3,
        VaultTansferFailed = 4,
        FileSentToACI = 5,
        Closed=6,
        Failed=7,
        WriteOff=8
    }
}
