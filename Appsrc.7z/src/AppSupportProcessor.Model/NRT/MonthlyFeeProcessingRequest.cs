﻿using System;

namespace AppSupportProcessor.Model.NRT
{
    public class MonthlyFeeProcessingRequest
    {
        public int? MonthlyFeeProcessingRequestKey { get; set; }
        public short? MonthlyFeeProcessingRequestStatusKey { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}