﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.NRT
{
    [ExcludeFromCodeCoverage]
    public class BillCycleCustomer_Staging
    {
        public long ETL_BackFillBillCycleCustomerStagingKey { get; set; }
        public int AccountKey { get; set; }
        public int CustomerKey { get; set; }
        public bool IsProcessed { get; set; }
        public DateTime ActivationDate { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime ChangeDate { get; set; }
        public string ChangeBy { get; set; }
    }
}

