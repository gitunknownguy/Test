﻿using System;

namespace AppSupportProcessor.Model.NRT
{
    public class ETL_ManualFeeWaiverStatus_Staging
    {
        public int ETLFeeWaiverStatusStagingKey { get; set; }
        public int CustomerKey { get; set; }
        public DateTime StartWaiveDate { get; set; }
        public DateTime EndWaiveDate { get; set; }
        public short FeeWaiverKey { get; set; }
        public DateTime CreateDate { get; set; }
    }
}