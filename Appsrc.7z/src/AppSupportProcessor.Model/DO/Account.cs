﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace AppSupportProcessor.Model.DO
{
    [ExcludeFromCodeCoverage]
    public class Account
    {
        public int AccountKey { get; set; }

        public short AccountStatusKey { get; set; }
    }
}
