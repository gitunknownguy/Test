﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.PDS
{
    public class AccountTranslationInfo
    {
        public Guid AccountReferenceID { get; set; }
        public Guid AccountKey { get; set; }
    }
}
