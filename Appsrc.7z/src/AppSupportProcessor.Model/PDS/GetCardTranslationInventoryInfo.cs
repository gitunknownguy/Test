﻿using System;
using System.Collections.Generic;
using System.Text;
namespace AppSupportProcessor.Model.PDS
{
    public class GetCardTranslationInventoryInfo
    {
        public string CardExternalID { get; set; }
        public Guid CardReferenceID { get; set; }
        public DateTime CreatedutcDate { get; set; }
    }
}
