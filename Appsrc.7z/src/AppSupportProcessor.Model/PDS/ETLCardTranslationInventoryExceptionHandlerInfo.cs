﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AppSupportProcessor.Model.PDS
{
    public class ETLCardTranslationInventoryExceptionHandlerInfo
    {
        public int ETL_CardTranslationInventory_ExceptionHandlerKey { get; set; }
        public string ExceptionHandlerStatus { get; set; }
        public string ExceptionHandlerDescription { get; set; }
    }
}
