﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AppSupportProcessor.Model.PDS
{
    public class ExceptionHandlerKeyInfo
    {
        public Guid CardReferenceID { get; set; }
        public string CardExternalID { get; set; }
    }
}
