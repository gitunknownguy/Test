﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace AppSupportProcessor.Model.PDS
{
    [ExcludeFromCodeCoverage]
    public class CardTranslationInventoryExceptionHandlerInfo
    {
        public int ETL_CardTranslationInventory_ExceptionHandlerKey { get; set; }
        public int ETLCardTranslationInventoryExceptionKey { get; set; }
        public Guid CardReferenceID { get; set; }
        public string CardExternalID { get; set; }
        public string TransformationErrorDescription { get; set; }
    }
}
