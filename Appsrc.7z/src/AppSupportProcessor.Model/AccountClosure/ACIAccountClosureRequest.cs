﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.AccountClosure
{
    public class ACIAccountClosureRequest
    {
        public long ACIAccountClosureRequestKey { get; set; }
        public short ACIAccountClosureRequestStatusKey { get; set; }
        public string RequestFileType { get; set; }
        public string RequestFileName { get; set; }
        public string ACIFileName { get; set; }
        public string RequestFilePath { get; set; }
        public DateTime RequestFileProcessDate { get; set; }
        public int TotalCount { get; set; }
    }
}
