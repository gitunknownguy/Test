﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.AccountClosure
{
    public class Customer
    {
        public int CustomerKey { get; set; }
        public Guid CardReferenceID { get; set; }
    }
}
