﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.AccountClosure
{
    public class ACIAccountClosureResponse
    {
        public long ACIAccountClosureResponseKey { get; set; }
        public long ACIAccountClosureRequestKey { get; set; }
        public string ResponseFileName { get; set; }
        public string ResponseFilePath { get; set; }
        public DateTime ResponseFileProcessDate { get; set; }
        public int TotalCount { get; set; }
    }
}
