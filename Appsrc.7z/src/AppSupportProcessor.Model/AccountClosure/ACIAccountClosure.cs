﻿using AppSupportProcessor.Model.Consolidation;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.AccountClosure
{
    public class ACIAccountClosure
    {
        public int ACIAccountClosureKey { get; set; }
        public short ACIAccountClosureStatusKey { get; set; }
        public long ACIAccountClosureRequestKey { get; set; }
        public int CustomerKey { get; set; }
        public int AccountKey { get; set; }
        public string ACIAccountExternalID { get; set; }
        public string CardExternalID { get; set; }
        public Guid FileIdentifier { get; set; }
        public decimal VaultBalance { get; set; }
        public long ACIAccountClosureResponseKey { get; set; }
        public string ResponseCode { get; set; }
        public string ResponseMessage { get; set; }
        public decimal AvailableBalance { get; set; }
        public DateTime CardActivationDate { get; set; }
        public string CreditRatingKey { get; set; }
        public Guid AccountReferenceID { get; set; }
        public Guid CardReferenceID { get; set; }
        public Guid PdsAccountKey { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class ACIAccountClosureCompare : IEqualityComparer<ACIAccountClosure>
    {
        public bool Equals(ACIAccountClosure x, ACIAccountClosure y)
        {
            if (x.AccountKey == y.AccountKey)
                return true;
            else
                return false;
        }
        public int GetHashCode(ACIAccountClosure obj)
        {
            return obj.AccountKey.GetHashCode();
        }
    }
}
