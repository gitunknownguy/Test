﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.InactivityFee
{
    public class MembershipFee
    {
        public short MembershipKey { get; set; }
        public string FeeType { get; set; }
        public short FeeTypeKey { get; set; }
        public decimal Fee { get; set; }
        public DateTime FeeGracePeriod { get; set; }
        public short TransTypeKey { get; set; }
        public string TransType { get; set; }
        public short DetailAccountTransactionTypeKey { get; set; }

    }
}
