﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.InactivityFee
{
    public class AccountBalance
    {
        public int PinKey { get; set; }
        public int AccountKey { get; set; }
        public decimal AvailableBalance { get; set; }
        public decimal CurrentBalance { get; set; }
        public int LinkedAccountKey { get; set; }
        public decimal Vault_AvailableBalance { get; set; }
        public decimal Vault_CurrentBalance { get; set; }
    }
}
