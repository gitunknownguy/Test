﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.InactivityFee
{
    public class InactivityDormancyTransaction
    {
        public int PYGInactivityDormancyTransactionKey { get; set; }
        public int PINKey { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime ChangeDate { get; set; }
        public decimal FeeAmount { get; set; }
        public short FeeTypeKey { get; set; }
        public bool InActiveFeesCharged { get; set; }
        public string SerialNbr { get; set; }
        public bool FeeReversed { get; set; }
        public string TransactionIdentifier { get; set; }
        public short PYGInactivityDormancyTransactionStatusKey { get; set; }
        public decimal AvailableBalance { get; set; }
        public decimal VaultAvailableBalance { get; set; }
    }
}
