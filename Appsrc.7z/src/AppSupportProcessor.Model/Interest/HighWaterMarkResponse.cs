﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.Interest
{
    public class HighWaterMarkResponse
    {
        public long HighWaterMarkKey { get; set; }
        public DateTime CreateDate { get; set;}
    }
}
