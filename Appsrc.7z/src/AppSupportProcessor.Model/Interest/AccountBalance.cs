﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.Interest
{
    public class AccountBalance
    {
        public  int AccountKey { get; set; }
        public DateTime EndingBalanceAsOf { get; set; }
        public decimal EndingBalance { get; set; }
    }

    public class BalanceRange
    {
        public decimal EndingBalance { get; set; }
        public DateTime Start { get; set; }
        public DateTime End { get; set; }
    }
}
