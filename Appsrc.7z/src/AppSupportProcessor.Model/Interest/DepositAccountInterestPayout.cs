﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.Interest
{
    public class DepositAccountInterestPayout
    {
        public int AccountKey { get; set; }

        public DateTime PayoutStartDate { get; set; }
        public DateTime PayoutEndDate { get; set; }
        public decimal ExistingInterestAmount { get; set; }
        public decimal NewInterestAmount { get; set; }
        public decimal InterestReimburseAmount { get; set; }
        public int DepositAccountInterestReimbursePayoutStatusKey { get; set; }
        public int AccountTransactionKey { get; set; }
        public DateTime PayoutDate { get; set; }
        public int RetryCount { get; set; }

        public string Description { get; set; }
    }
}
