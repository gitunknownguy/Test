﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.Interest
{
    public class DepositAccountInterestReimbursePayout
    {
        public long DepositAccountInterestReimbursePayoutKey { get; set; }
        public int AccountKey { get; set; }

        public DateTime PayoutStartDate { get; set; }
        public DateTime PayoutEndDate { get; set; }
        public decimal ExistingInterestAmount { get; set; }
        public decimal? NewInterestAmount { get; set; }
        public decimal? InterestReimburseAmount { get; set; }
        public int DepositAccountInterestReimbursePayoutStatusKey { get; set; }
        
        public string Description { get; set; }

        public int ExistingDepositAccountInterestPayoutStatusKey { get; set; }

        #region  some field designed for real pay
        public long? AccountTransactionKey { get; set; }
        public DateTime? PayoutDate { get; set; }
        public int RetryCount { get; set; }
        #endregion

        public void SetValue(int depositAccountInterestReimbursePayoutStatusKey,
                             string description,
                             decimal? newInterestAmount = null,
                             decimal? interestReimburseAmount = null)
        {
            DepositAccountInterestReimbursePayoutStatusKey = depositAccountInterestReimbursePayoutStatusKey;
            Description = description;
            NewInterestAmount = newInterestAmount;
            InterestReimburseAmount= interestReimburseAmount;
        }

        public void SetValueForPay(int depositAccountInterestReimbursePayoutStatusKey,
                             string description,
                             long? accountTransactionKey = null,
                             DateTime? payoutDate = null)
        {
            DepositAccountInterestReimbursePayoutStatusKey = depositAccountInterestReimbursePayoutStatusKey;
            Description = description;
            AccountTransactionKey = accountTransactionKey;
            PayoutDate = payoutDate;
        }
    }
}
