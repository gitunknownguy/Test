﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.Interest
{
    public class MembershipInterestAccrual
    {
        public int MembershipInterestAccrualKey { get; set; }
        public int MembershipKey { get; set; }
        public int FrequencyTypeKey { get; set; }
        public int InterestAccrualStartDateTypeKey { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public decimal APY { get; set; }
        public int MinimumDailyBalance { get; set; }
        public int MaximumDailyBalance { get; set; }
    }
}
