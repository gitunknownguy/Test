﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.Interest
{
    /// <summary>
    /// this is used for database model
    /// </summary>
    public  class CustomerMembership
    {
        public int AccountKey { get;set; }
        public string CreditRatingKey { get; set; }
        public int MembershipKey { get; set; }
        public int ProductKey { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public string SerialNbr { get; set; }
        public int CustomerKey { get; set; }    

        //the customer membership will cross different payout, need a deep copy here. dont want modify the item's value
        public CustomerMembership DeepClone()
        { 
            return new CustomerMembership
            {
                AccountKey = AccountKey,
                CreditRatingKey = CreditRatingKey,
                MembershipKey = MembershipKey,
                ProductKey = ProductKey,
                StartDate = StartDate,
                EndDate = EndDate,
                SerialNbr = SerialNbr,
                CustomerKey = CustomerKey
            };
        }
    }
    
    /// <summary>
    /// this is used to adjust the first membership's start date and the last membership's end date
    /// </summary>
    public class CustomerMembershipAdjust
    {
        public int MembershipKey { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public int MembershipInterestAccrualKey { get; set; }
    }
}
