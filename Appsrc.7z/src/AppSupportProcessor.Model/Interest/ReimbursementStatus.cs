﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSupportProcessor.Model.Interest
{
    public enum ReimbursementStatus
    {

        Initial = 1,

        /// <summary>
        /// the calculation success, and GD pay customer less than should pay
        /// </summary>
        Calculated = 2,

        /// <summary>
        /// something wrong, e.g. excepiton due to dirty data, cannot find membership
        /// </summary>
        Failed = 3,

        /// <summary>
        /// the calculation success, and GD pay customer equal or even greater than the correct value
        /// </summary>
        NoFundingRequired = 4,

        /// <summary>
        /// APY never changes, or in bad credit rating 
        /// </summary>
        Skipped = 5,

        FundingSuccess = 6,

        FundingFail = 7,

        /// <summary>
        /// we skipped the funding if customer's credit rating is in bad status
        /// </summary>
        FundingSkipped = 8

    }
}
